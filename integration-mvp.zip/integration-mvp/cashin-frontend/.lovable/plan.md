## Rebranding PayFort → Cashyin

Aplicar a identidade visual da Cashyin ao painel já construído. Sem mudanças de funcionalidade — só visual, logos e tokens.

### Identidade extraída do kit
- **Nome:** Cashyin
- **Cor primária (escura):** `#073A4B` (teal-petróleo profundo)
- **Cor de acento (clara):** `#30E6C8` (mint/turquesa)
- **Branca:** `#FFFFFF`
- **Marca:** símbolo "C" estilizado (arco + quadradinho) + wordmark "cashyin"

### O que muda

1. **Assets de marca** — copiar do zip para `src/assets/brand/`:
   - `logo-dark.svg` (Logo escura.svg) — para fundos claros
   - `logo-light.svg` (Logo clara.svg) — para fundos escuros
   - `logo-white.svg` (Logo branca.svg)
   - `icon.svg` (Icon escuro + claro.svg) — símbolo isolado
   - `favicon.svg` — para `public/favicon.svg`

2. **Design tokens** (`src/styles.css`) — substituir paleta atual:
   - `--primary`: oklch equivalente de `#073A4B`
   - `--accent` / novo `--brand-accent`: oklch de `#30E6C8`
   - `--ring`, `--sidebar-primary`, `--chart-1`, `--sidebar-accent-foreground` realinhados
   - `--success` mantém verde, mas botões/realces principais passam a usar o mint quando fizer sentido (CTAs secundários, badges "ativo")
   - Tipografia: manter sans atual (manual da marca usa sans geométrica — sem fonte custom para evitar dependência nova; opcional adicionar Inter/Plus Jakarta se desejar)

3. **Sidebar** (`src/components/app-sidebar.tsx`):
   - Substituir o quadradinho `Wallet` + texto "PayFort" pelo SVG `logo-dark.svg` (ou ícone + wordmark "cashyin")
   - Iniciais do avatar continuam dinâmicas

4. **Topbar / banner / metadados:**
   - `__root.tsx`: `<title>` e meta description trocam "PayFort" → "Cashyin"
   - `account-banner.tsx`: "A PayFort deseja…" → "A Cashyin deseja…"
   - Qualquer string "PayFort" em rotas (`/documentacao`, `/chaves-api`, footer de docs) → "Cashyin"
   - `public/favicon.svg` substituído

5. **Documentação** (`/documentacao`): exemplos de código `payfort.*` viram `cashyin.*` (apenas strings).

### Fora de escopo
- Sem mudanças de layout, rotas ou comportamento
- Sem nova fonte custom (a menos que peça)
- Sem dark mode dedicado (já existia preset, não será ajustado a fundo)

### Resultado esperado
Mesmo painel, agora com marca Cashyin: logo no sidebar, paleta teal-petróleo + mint turquesa, favicon e títulos coerentes.
