/**
 * Unit tests for PgNotifyWatcher.
 *
 * The pg Client is injected via `_clientFactory` option — no module-level
 * mocking needed. Each test controls exactly which client(s) are used.
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';
import type { Client } from 'pg';
import type { Logger } from 'pino';
import { PgNotifyWatcher } from '../../src/workers/runtime/pg-notify-watcher.js';

// ─── Mock client helpers ─────────────────────────────────────────────────────

type NotificationHandler = (msg: { channel: string; payload?: string }) => void;
type ErrorHandler = (err: Error) => void;
type EndHandler = () => void;

type MockClient = {
  connect: ReturnType<typeof vi.fn>;
  query: ReturnType<typeof vi.fn>;
  end: ReturnType<typeof vi.fn>;
  on: ReturnType<typeof vi.fn>;
  _emit: (event: 'notification' | 'error' | 'end', arg?: unknown) => void;
};

function makeMockClient(opts: { connectError?: Error } = {}): MockClient {
  let notificationHandler: NotificationHandler | null = null;
  let errorHandler: ErrorHandler | null = null;
  let endHandler: EndHandler | null = null;

  const client: MockClient = {
    connect: vi.fn(async () => {
      if (opts.connectError) throw opts.connectError;
    }),
    query: vi.fn(async () => {}),
    end: vi.fn(async () => {}),
    on: vi.fn((event: string, handler: unknown) => {
      if (event === 'notification') notificationHandler = handler as NotificationHandler;
      if (event === 'error') errorHandler = handler as ErrorHandler;
      if (event === 'end') endHandler = handler as EndHandler;
    }),
    _emit(event, arg) {
      if (event === 'notification' && notificationHandler)
        notificationHandler(arg as { channel: string; payload?: string });
      if (event === 'error' && errorHandler) errorHandler(arg as Error);
      if (event === 'end' && endHandler) endHandler();
    }
  };
  return client;
}

function makeFactory(...clients: MockClient[]): (cs: string) => Client {
  let idx = 0;
  return (_cs: string) => {
    const c = clients[idx] ?? clients[clients.length - 1];
    idx++;
    return c as unknown as Client;
  };
}

function silentLogger(): Logger {
  const noop = (): void => undefined;
  const logger = {
    info: noop,
    warn: noop,
    error: noop,
    debug: noop,
    trace: noop,
    fatal: noop,
    level: 'silent',
    child(): Logger {
      return logger;
    }
  } as unknown as Logger;
  return logger;
}

beforeEach(() => {
  vi.clearAllMocks();
});

// ─── Tests ───────────────────────────────────────────────────────────────────

describe('PgNotifyWatcher', () => {
  it('connects and issues LISTEN on start()', async () => {
    const client = makeMockClient();

    const watcher = new PgNotifyWatcher({
      connectionString: 'postgres://localhost/test',
      channels: ['cashyin_outbox_events_ready'],
      onNotify: vi.fn(),
      logger: silentLogger(),
      _clientFactory: makeFactory(client)
    });

    await watcher.start();

    expect(client.connect).toHaveBeenCalledOnce();
    expect(client.query).toHaveBeenCalledWith('LISTEN "cashyin_outbox_events_ready"');
  });

  it('issues LISTEN for each channel', async () => {
    const client = makeMockClient();

    const watcher = new PgNotifyWatcher({
      connectionString: 'postgres://localhost/test',
      channels: ['cashyin_webhook_events_ready', 'cashyin_outbox_events_ready'],
      onNotify: vi.fn(),
      logger: silentLogger(),
      _clientFactory: makeFactory(client)
    });

    await watcher.start();

    expect(client.query).toHaveBeenCalledWith('LISTEN "cashyin_webhook_events_ready"');
    expect(client.query).toHaveBeenCalledWith('LISTEN "cashyin_outbox_events_ready"');
  });

  it('calls onNotify when a notification arrives', async () => {
    const client = makeMockClient();
    const onNotify = vi.fn();

    const watcher = new PgNotifyWatcher({
      connectionString: 'postgres://localhost/test',
      channels: ['cashyin_outbox_events_ready'],
      onNotify,
      logger: silentLogger(),
      _clientFactory: makeFactory(client)
    });

    await watcher.start();
    client._emit('notification', { channel: 'cashyin_outbox_events_ready', payload: 'abc-123' });

    expect(onNotify).toHaveBeenCalledOnce();
    expect(onNotify).toHaveBeenCalledWith('cashyin_outbox_events_ready', 'abc-123');
  });

  it('calls onNotify with empty string when payload is undefined', async () => {
    const client = makeMockClient();
    const onNotify = vi.fn();

    const watcher = new PgNotifyWatcher({
      connectionString: 'postgres://localhost/test',
      channels: ['cashyin_outbox_events_ready'],
      onNotify,
      logger: silentLogger(),
      _clientFactory: makeFactory(client)
    });

    await watcher.start();
    client._emit('notification', { channel: 'cashyin_outbox_events_ready', payload: undefined });

    expect(onNotify).toHaveBeenCalledWith('cashyin_outbox_events_ready', '');
  });

  it('stops cleanly and calls client.end()', async () => {
    const client = makeMockClient();

    const watcher = new PgNotifyWatcher({
      connectionString: 'postgres://localhost/test',
      channels: ['cashyin_outbox_events_ready'],
      onNotify: vi.fn(),
      logger: silentLogger(),
      _clientFactory: makeFactory(client)
    });

    await watcher.start();
    await watcher.stop();

    expect(client.end).toHaveBeenCalledOnce();
  });

  it('start() is idempotent — second call is a no-op', async () => {
    const client = makeMockClient();

    const watcher = new PgNotifyWatcher({
      connectionString: 'postgres://localhost/test',
      channels: ['cashyin_outbox_events_ready'],
      onNotify: vi.fn(),
      logger: silentLogger(),
      _clientFactory: makeFactory(client)
    });

    await watcher.start();
    await watcher.start(); // second call

    expect(client.connect).toHaveBeenCalledOnce();
  });

  it('schedules reconnect when client emits error', async () => {
    const failClient = makeMockClient();
    const goodClient = makeMockClient();

    const watcher = new PgNotifyWatcher({
      connectionString: 'postgres://localhost/test',
      channels: ['cashyin_outbox_events_ready'],
      onNotify: vi.fn(),
      logger: silentLogger(),
      reconnectDelayMs: 5,
      _clientFactory: makeFactory(failClient, goodClient)
    });

    await watcher.start();
    expect(failClient.connect).toHaveBeenCalledOnce();

    failClient._emit('error', new Error('connection reset'));

    await new Promise((r) => setTimeout(r, 50));

    expect(goodClient.connect).toHaveBeenCalledOnce();
    await watcher.stop();
  });

  it('schedules reconnect when client emits end while not stopped', async () => {
    const failClient = makeMockClient();
    const goodClient = makeMockClient();

    const watcher = new PgNotifyWatcher({
      connectionString: 'postgres://localhost/test',
      channels: ['cashyin_outbox_events_ready'],
      onNotify: vi.fn(),
      logger: silentLogger(),
      reconnectDelayMs: 5,
      _clientFactory: makeFactory(failClient, goodClient)
    });

    await watcher.start();
    failClient._emit('end');

    await new Promise((r) => setTimeout(r, 50));

    expect(goodClient.connect).toHaveBeenCalledOnce();
    await watcher.stop();
  });

  it('does NOT reconnect after stop() even if end event fires', async () => {
    const client = makeMockClient();
    const client2 = makeMockClient();

    const watcher = new PgNotifyWatcher({
      connectionString: 'postgres://localhost/test',
      channels: ['cashyin_outbox_events_ready'],
      onNotify: vi.fn(),
      logger: silentLogger(),
      reconnectDelayMs: 5,
      _clientFactory: makeFactory(client, client2)
    });

    await watcher.start();
    expect(client.connect).toHaveBeenCalledOnce();

    await watcher.stop();
    client._emit('end'); // fires after stop

    await new Promise((r) => setTimeout(r, 50));

    expect(client2.connect).not.toHaveBeenCalled();
  });

  it('applies exponential backoff on consecutive connect failures', async () => {
    const fail1 = makeMockClient({ connectError: new Error('ECONNREFUSED') });
    const fail2 = makeMockClient({ connectError: new Error('ECONNREFUSED') });
    const good  = makeMockClient();

    const watcher = new PgNotifyWatcher({
      connectionString: 'postgres://localhost/test',
      channels: ['cashyin_outbox_events_ready'],
      onNotify: vi.fn(),
      logger: silentLogger(),
      reconnectDelayMs: 5,
      maxReconnectDelayMs: 1_000,
      _clientFactory: makeFactory(fail1, fail2, good)
    });

    await watcher.start(); // fail1 → delay 5 ms
    await new Promise((r) => setTimeout(r, 30)); // fail2 retries, delay doubles to 10 ms
    await new Promise((r) => setTimeout(r, 30)); // good connects

    expect(good.connect).toHaveBeenCalledOnce();
    await watcher.stop();
  });

  it('nudge() on the WorkerLoop is called by onNotify', async () => {
    const client = makeMockClient();
    const nudge = vi.fn();

    const watcher = new PgNotifyWatcher({
      connectionString: 'postgres://localhost/test',
      channels: ['cashyin_outbox_events_ready'],
      onNotify: nudge,
      logger: silentLogger(),
      _clientFactory: makeFactory(client)
    });

    await watcher.start();
    client._emit('notification', { channel: 'cashyin_outbox_events_ready', payload: 'row-id-1' });
    client._emit('notification', { channel: 'cashyin_outbox_events_ready', payload: 'row-id-2' });

    expect(nudge).toHaveBeenCalledTimes(2);
  });
});
