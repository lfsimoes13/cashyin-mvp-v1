import { describe, expect, it, vi } from 'vitest';
import {
  CashoutService,
  type CashoutStatusUpdateEvent,
  type ReconciliationEvent
} from '../../src/modules/cashouts/cashout.service.js';
import { ProviderError } from '../../src/providers/contracts/provider-errors.js';
import { BentsWebhookAdapter } from '../../src/providers/bents/bents-webhook.adapter.js';
import { AppError } from '../../src/shared/errors/app-error.js';
import type {
  CashoutInsertInput,
  CashoutRecord,
  CashoutRepository,
  MarkCashoutStatusResult,
  ProviderConfirmationPatch,
  TerminalCashoutStatus
} from '../../src/modules/cashouts/cashout.repository.js';
import type { OutboxEventInsertInput } from '../../src/modules/outbox/outbox.repository.js';
import type { ProviderName } from '../../src/providers/contracts/provider-types.js';
import type { IdempotencyService } from '../../src/modules/idempotency/idempotency.service.js';
import type { ProviderAssignmentService } from '../../src/modules/providers/provider-assignment.service.js';
import type { ProviderRegistry } from '../../src/modules/providers/provider-registry.js';
import type { OutboxService } from '../../src/modules/outbox/outbox.service.js';
import type { LiquidityService } from '../../src/modules/liquidity/liquidity.service.js';
import type { LiquidityReservationRecord } from '../../src/modules/liquidity/liquidity.repository.js';
import type { LedgerService } from '../../src/modules/ledger/ledger.service.js';
import type { ClientBalanceService } from '../../src/modules/balances/client-balance.service.js';
import type { Database } from '../../src/shared/db/database.js';
import type { PaymentProvider } from '../../src/providers/contracts/payment-provider.js';
import type { Sql } from '../../src/shared/db/sql.js';
import type {
  IdempotencyAcquireInput,
  IdempotencyAcquireResult
} from '../../src/modules/idempotency/idempotency.types.js';
import type { CreateCashoutInput } from '../../src/modules/cashouts/cashout.schemas.js';
import type {
  CashoutPricingAssessment,
  PricingService
} from '../../src/modules/pricing/pricing.service.js';
import type { FeeAssessmentRecord } from '../../src/modules/pricing/fee-assessment.repository.js';

const VALID_INPUT: CreateCashoutInput = {
  clientId: '22222222-2222-4222-8222-222222222222',
  externalRef: 'cashout-ext-1',
  amountCents: 2500,
  pixKey: 'merchant@example.test',
  pixKeyType: 'EMAIL',
  receiverName: null,
  receiverDocument: null
};

function buildDeps(overrides: Partial<{
  provider: Partial<PaymentProvider>;
  acquireResult: IdempotencyAcquireResult;
  existingRecord: CashoutRecord | null;
  pricing: PricingService;
  ledger: LedgerService;
  balances: ClientBalanceService;
  findByProviderPaymentIdResult: CashoutRecord | null;
  markStatusResult: MarkCashoutStatusResult;
  activeReservation: LiquidityReservationRecord | null;
}> = {}) {
  const tx = { __tx: true } as unknown as Sql;
  const pool = { __pool: true } as unknown as Sql;

  const acquire = vi.fn(
    async (_input: IdempotencyAcquireInput): Promise<IdempotencyAcquireResult> =>
      overrides.acquireResult ?? { kind: 'fresh', recordId: 'idem-1', wasStale: false }
  );
  const release = vi.fn(async () => undefined);
  const finalize = vi.fn(async () => undefined);
  const finalizeWith = vi.fn(async () => undefined);

  const idempotency: IdempotencyService = {
    acquire,
    release,
    finalize,
    finalizeWith,
    defaultLockTtlMs: 30_000
  } as unknown as IdempotencyService;

  const providerAssignment: ProviderAssignmentService = {
    requireActive: vi.fn(async () => ({
      id: 'assignment-co',
      clientId: VALID_INPUT.clientId,
      providerName: 'bents',
      providerAccountId: 'acc-1',
      operationType: 'cash_out',
      version: 1
    }))
  } as unknown as ProviderAssignmentService;

  const providerStub: PaymentProvider = {
    name: 'bents',
    createPixCharge: vi.fn(),
    getPixCharge: vi.fn(),
    createPixPayment: vi.fn(async () => ({
      provider: 'bents',
      providerPaymentId: 'pay_1',
      status: 'processing',
      amountCents: 2500,
      e2eId: 'E2E',
      feeAmountCents: 12,
      raw: {}
    })),
    getBalance: vi.fn(),
    ...(overrides.provider ?? {})
  } as unknown as PaymentProvider;

  const providerRegistry: ProviderRegistry = {
    get: vi.fn(() => providerStub)
  } as unknown as ProviderRegistry;

  const baseCashout: CashoutRecord = {
    id: 'cashout-1',
    clientId: VALID_INPUT.clientId,
    providerName: 'bents',
    providerAccountId: 'acc-1',
    externalId: VALID_INPUT.externalRef,
    providerPaymentId: 'pay_1',
    amountCents: 2500,
    currency: 'BRL',
    pixKey: VALID_INPUT.pixKey,
    pixKeyType: 'EMAIL',
    receiverName: null,
    receiverDocument: null,
    receiverBank: null,
    receiverIspb: null,
    receiverBranch: null,
    receiverAccount: null,
    receiverAccountType: null,
    status: 'processing',
    e2eId: 'E2E',
    feeAmountCents: 12,
    failureReason: null,
    createdAt: new Date('2026-05-22T00:00:00Z'),
    completedAt: null,
    failedAt: null,
    returnedAt: null,
    updatedAt: new Date('2026-05-22T00:00:00Z')
  };

  // Tracks the latest record materialised by markStatus so the stateful
  // `applyProviderConfirmation` mock can COALESCE the provider receiver/e2e
  // onto it while preserving the freshly-transitioned status.
  let lastMarkedRecord: CashoutRecord | null = null;

  const applyProviderConfirmation = vi.fn(
    async (
      _sql: Sql,
      _id: string,
      confirmation: ProviderConfirmationPatch
    ): Promise<CashoutRecord | null> => {
      const base =
        lastMarkedRecord ?? overrides.findByProviderPaymentIdResult ?? baseCashout;
      const patched: CashoutRecord = {
        ...base,
        receiverName: base.receiverName ?? confirmation.receiverName ?? null,
        receiverDocument: base.receiverDocument ?? confirmation.receiverDocument ?? null,
        receiverBank: base.receiverBank ?? confirmation.receiverBank ?? null,
        receiverIspb: base.receiverIspb ?? confirmation.receiverIspb ?? null,
        receiverBranch: base.receiverBranch ?? confirmation.receiverBranch ?? null,
        receiverAccount: base.receiverAccount ?? confirmation.receiverAccount ?? null,
        receiverAccountType: base.receiverAccountType ?? confirmation.receiverAccountType ?? null,
        e2eId: base.e2eId ?? confirmation.e2eId ?? null
      };
      lastMarkedRecord = patched;
      return patched;
    }
  );

  const cashoutRepository: CashoutRepository = {
    insert: vi.fn(async (_sql: Sql, input: CashoutInsertInput) => ({
      ...baseCashout,
      providerPaymentId: input.providerPaymentId,
      status: input.status,
      e2eId: input.e2eId,
      feeAmountCents: input.feeAmountCents,
      receiverName: input.receiverName,
      receiverDocument: input.receiverDocument,
      receiverBank: input.receiverBank,
      receiverIspb: input.receiverIspb,
      receiverBranch: input.receiverBranch,
      receiverAccount: input.receiverAccount,
      receiverAccountType: input.receiverAccountType,
      completedAt: input.status === 'completed' ? baseCashout.createdAt : null,
      failedAt: input.status === 'failed' ? baseCashout.createdAt : null,
      returnedAt: input.status === 'returned' ? baseCashout.createdAt : null
    })),
    findById: vi.fn(async () => null),
    findByClientExternalId: vi.fn(async () => overrides.existingRecord ?? null),
    findByProviderPaymentId: vi.fn(
      async (_sql: Sql, _provider: ProviderName, _paymentId: string) =>
        overrides.findByProviderPaymentIdResult ?? null
    ),
    markStatus: vi.fn(
      async (
        _sql: Sql,
        _id: string,
        status: TerminalCashoutStatus,
        opts?: { failureReason?: string | null; occurredAt?: Date }
      ): Promise<MarkCashoutStatusResult> => {
        if (overrides.markStatusResult) {
          if (overrides.markStatusResult.kind === 'updated') {
            lastMarkedRecord = overrides.markStatusResult.record;
          }
          return overrides.markStatusResult;
        }
        // Default: mutate-in-place on whatever the lookup returned, so the
        // outbox payload built by the service reflects the caller's
        // fixture (e.g. a custom providerPaymentId) rather than the
        // generic `baseCashout` snapshot. Stamp the matching lifecycle
        // timestamp from the provider's occurredAt for fidelity.
        const source = overrides.findByProviderPaymentIdResult ?? baseCashout;
        const stamp = opts?.occurredAt ?? new Date();
        const record: CashoutRecord = {
          ...source,
          status,
          completedAt: status === 'completed' ? (source.completedAt ?? stamp) : source.completedAt,
          failedAt: status === 'failed' ? (source.failedAt ?? stamp) : source.failedAt,
          returnedAt: status === 'returned' ? (source.returnedAt ?? stamp) : source.returnedAt
        };
        lastMarkedRecord = record;
        return { kind: 'updated', record };
      }
    ),
    applyProviderConfirmation
  };

  const reserveForCashout = vi.fn(async () => ({
    id: 'reservation-1',
    clientId: VALID_INPUT.clientId,
    providerAccountId: 'acc-1',
    cashoutId: null,
    amountCents: VALID_INPUT.amountCents,
    status: 'reserved' as const,
    expiresAt: new Date('2026-05-22T01:00:00Z'),
    createdAt: new Date('2026-05-22T00:00:00Z'),
    updatedAt: new Date('2026-05-22T00:00:00Z')
  }));
  const liquidityRelease = vi.fn(async () => undefined);
  const liquidityAttach = vi.fn(async () => undefined);
  const liquidityFindActive = vi.fn(
    async (_sql: Sql, _cashoutId: string): Promise<LiquidityReservationRecord | null> =>
      overrides.activeReservation ?? null
  );
  const liquidityConsume = vi.fn(async () => undefined);

  const liquidity: LiquidityService = {
    reserveForCashout,
    release: liquidityRelease,
    attachCashout: liquidityAttach,
    findActiveByCashout: liquidityFindActive,
    consume: liquidityConsume
  } as unknown as LiquidityService;

  const outbox: OutboxService = {
    enqueue: vi.fn(async () => undefined)
  } as unknown as OutboxService;

  const withTransaction = vi.fn(async (fn: (tx: Sql) => Promise<unknown>) => fn(tx));

  const db: Database = {
    pool,
    withTransaction,
    ping: vi.fn(),
    close: vi.fn()
  } as unknown as Database;

  const reconciliationEvents: ReconciliationEvent[] = [];

  const service = new CashoutService({
    db,
    idempotency,
    providerAssignment,
    providerRegistry,
    cashoutRepository,
    liquidity,
    outbox,
    ...(overrides.pricing !== undefined ? { pricing: overrides.pricing } : {}),
    ...(overrides.ledger !== undefined ? { ledger: overrides.ledger } : {}),
    ...(overrides.balances !== undefined ? { balances: overrides.balances } : {}),
    log: (event) => {
      reconciliationEvents.push(event);
    }
  });

  return {
    service,
    providerStub,
    cashoutRepository,
    applyProviderConfirmation,
    providerAssignment,
    liquidity,
    liquidityRelease,
    liquidityFindActive,
    liquidityConsume,
    reserveForCashout,
    release,
    finalize,
    finalizeWith,
    reconciliationEvents,
    withTransaction,
    outbox,
    baseCashout
  };
}

describe('CashoutService.createCashout — happy path', () => {
  it('reserves liquidity, calls provider, persists with the provider payment id, attaches the reservation', async () => {
    const deps = buildDeps();
    const response = await deps.service.createCashout(VALID_INPUT, 'idem-co');

    expect(response.providerPaymentId).toBe('pay_1');
    expect(response.reservationId).toBe('reservation-1');
    expect(deps.reserveForCashout).toHaveBeenCalledTimes(1);
    expect(deps.cashoutRepository.insert).toHaveBeenCalledTimes(1);
    expect(deps.liquidity.attachCashout).toHaveBeenCalledWith(
      expect.anything(),
      'reservation-1',
      'cashout-1'
    );
    expect(deps.finalizeWith).toHaveBeenCalledTimes(1);
    expect(deps.release).not.toHaveBeenCalled();
    expect(deps.liquidityRelease).not.toHaveBeenCalled();
  });
});

describe('CashoutService.createCashout — synchronous provider terminal status', () => {
  it('runs financial closure and enqueues pix.cash_out.completed (never initiated/processing) when the provider settles on create', async () => {
    const { ledger, postFeeAssessment } = stubLedger();
    const { pricing, promoteAssessmentStatus } = stubPricingForFinancialClosure();
    const deps = buildDeps({
      provider: {
        createPixPayment: vi.fn(async () => ({
          provider: 'bents',
          providerPaymentId: 'pay_sync',
          status: 'completed',
          amountCents: VALID_INPUT.amountCents,
          e2eId: 'E4397869720260529201719529c238ca',
          feeAmountCents: 10,
          raw: {}
        }))
      },
      pricing,
      ledger,
      activeReservation: buildReservation()
    });

    const response = await deps.service.createCashout(VALID_INPUT, 'idem-sync');

    expect(response.status).toBe('completed');

    const enqueueSpy = vi.mocked(deps.outbox.enqueue);
    const eventTypes = enqueueSpy.mock.calls.map((call) => call[1].eventType);
    expect(eventTypes).toContain('pix.cash_out.completed');
    expect(eventTypes).not.toContain('pix.cash_out.initiated');
    expect(eventTypes).not.toContain('pix.cash_out.processing');

    // The terminal public snapshot mirrors the persisted FINAL state.
    const completedEvent = enqueueSpy.mock.calls.find(
      (call) => call[1].eventType === 'pix.cash_out.completed'
    )?.[1] as OutboxEventInsertInput;
    expect(completedEvent.payload).toMatchObject({
      cashoutId: 'cashout-1',
      status: 'completed',
      amountCents: VALID_INPUT.amountCents,
      e2eId: 'E4397869720260529201719529c238ca'
    });
    // Provider cost / fee never leak into the terminal outbox snapshot.
    expect(completedEvent.payload).not.toHaveProperty('feeAmountCents');
    expect(completedEvent.payload).not.toHaveProperty('providerCostCents');

    // Financial closure executed exactly once at create time.
    expect(deps.liquidityConsume).toHaveBeenCalledTimes(1);
    expect(promoteAssessmentStatus).toHaveBeenCalledWith(
      expect.anything(),
      'fee-assessment-1',
      'posted'
    );
    expect(postFeeAssessment).toHaveBeenCalledTimes(1);
    // The create path inserts the row already terminal — no markStatus.
    expect(deps.cashoutRepository.markStatus).not.toHaveBeenCalled();
  });

  it('enqueues pix.cash_out.initiated (no public processing webhook) when the provider returns processing', async () => {
    const deps = buildDeps(); // default provider stub returns `processing`
    await deps.service.createCashout(VALID_INPUT, 'idem-proc');

    const enqueueSpy = vi.mocked(deps.outbox.enqueue);
    expect(enqueueSpy).toHaveBeenCalledTimes(1);
    const event = enqueueSpy.mock.calls[0]?.[1] as OutboxEventInsertInput;
    expect(event.eventType).toBe('pix.cash_out.initiated');
    expect(deps.liquidityConsume).not.toHaveBeenCalled();
  });

  it('persists the synchronous provider receiver block (bank/ispb/account…) on create', async () => {
    const deps = buildDeps({
      provider: {
        createPixPayment: vi.fn(async () => ({
          provider: 'bents',
          providerPaymentId: 'pay_sync_recv',
          status: 'completed',
          amountCents: VALID_INPUT.amountCents,
          e2eId: 'E_SYNC_RECV',
          feeAmountCents: 10,
          receiver: {
            name: 'DAYANE JAQUELINE MARINS ALCANTES 41530170869',
            document: '**.921.710/****-**',
            bank: 'A55 SCD S.A.',
            ispb: '48756121'
          },
          raw: {}
        }))
      }
    });

    const response = await deps.service.createCashout(VALID_INPUT, 'idem-sync-recv');

    // The synchronous receiver block lands on the persisted/returned record.
    expect(response.status).toBe('completed');
    expect(response.receiverName).toBe('DAYANE JAQUELINE MARINS ALCANTES 41530170869');
    expect(response.receiverDocument).toBe('**.921.710/****-**');
    expect(response.receiverBank).toBe('A55 SCD S.A.');
    expect(response.receiverIspb).toBe('48756121');

    // The insert received the provider-only receiver fields too.
    const insertArg = vi.mocked(deps.cashoutRepository.insert).mock.calls[0]?.[1] as CashoutInsertInput;
    expect(insertArg.receiverBank).toBe('A55 SCD S.A.');
    expect(insertArg.receiverIspb).toBe('48756121');
  });
});

describe('CashoutService.createCashoutWithDisposition — HTTP status semantics', () => {
  it('reports replayed=false for a newly created cash-out (route maps to 201 Created)', async () => {
    const deps = buildDeps(); // default provider stub returns `processing`
    const { cashout, replayed } = await deps.service.createCashoutWithDisposition(
      VALID_INPUT,
      'idem-disp-new'
    );
    expect(replayed).toBe(false);
    // A newly accepted async cash-out carries `processing` in the body — the
    // 201 reflects resource creation, NOT payment finality.
    expect(cashout.status).toBe('processing');
  });

  it('reports replayed=true on an idempotency replay (route maps to 200 OK)', async () => {
    const cached = { id: 'cashout-1', status: 'completed' };
    const deps = buildDeps({ acquireResult: { kind: 'replay', response: cached } });
    const { cashout, replayed } = await deps.service.createCashoutWithDisposition(
      VALID_INPUT,
      'idem-disp-replay'
    );
    expect(replayed).toBe(true);
    expect(cashout).toBe(cached);
    expect(deps.providerStub.createPixPayment).not.toHaveBeenCalled();
  });
});

describe('CashoutService.createCashout — replay & stale lock', () => {
  it('returns the cached idempotency response without calling the provider', async () => {
    const cached = { id: 'cashout-1', providerPaymentId: 'pay_cached' };
    const deps = buildDeps({ acquireResult: { kind: 'replay', response: cached } });

    const response = await deps.service.createCashout(VALID_INPUT, 'idem-co');
    expect(response).toBe(cached);
    expect(deps.providerStub.createPixPayment).not.toHaveBeenCalled();
    expect(deps.reserveForCashout).not.toHaveBeenCalled();
  });

  it('on stale-lock with no local row, refuses with 409 and does NOT touch provider or liquidity', async () => {
    const deps = buildDeps({
      acquireResult: { kind: 'fresh', recordId: 'idem-co', wasStale: true }
    });

    await expect(deps.service.createCashout(VALID_INPUT, 'idem-co')).rejects.toMatchObject({
      code: 'cashout_stale_lock_requires_reconciliation',
      statusCode: 409
    });

    expect(deps.providerStub.createPixPayment).not.toHaveBeenCalled();
    expect(deps.reserveForCashout).not.toHaveBeenCalled();
    expect(deps.release).not.toHaveBeenCalled();
  });

  it('on stale-lock with an existing local cashout, returns the cached row', async () => {
    const existing: CashoutRecord = {
      id: 'cashout-existing',
      clientId: VALID_INPUT.clientId,
      providerName: 'bents',
      providerAccountId: 'acc-1',
      externalId: VALID_INPUT.externalRef,
      providerPaymentId: 'pay_existing',
      amountCents: 2500,
      currency: 'BRL',
      pixKey: VALID_INPUT.pixKey,
      pixKeyType: 'EMAIL',
      receiverName: null,
      receiverDocument: null,
      status: 'processing',
      e2eId: 'E2E_old',
      feeAmountCents: 0,
      createdAt: new Date('2026-05-22T00:00:00Z'),
      updatedAt: new Date('2026-05-22T00:00:00Z')
    };
    const deps = buildDeps({
      acquireResult: { kind: 'fresh', recordId: 'idem-co', wasStale: true },
      existingRecord: existing
    });

    const response = await deps.service.createCashout(VALID_INPUT, 'idem-co');

    expect(response.id).toBe('cashout-existing');
    expect(response.providerPaymentId).toBe('pay_existing');
    expect(deps.finalize).toHaveBeenCalledWith(
      'idem-co',
      expect.objectContaining({ id: 'cashout-existing' })
    );
    expect(deps.providerStub.createPixPayment).not.toHaveBeenCalled();
  });
});

describe('CashoutService.createCashout — provider failures', () => {
  it('releases reservation AND idempotency on definite client error', async () => {
    const definite = new ProviderError(
      'provider_request_failed',
      '422 bad pix key',
      502,
      'definite_client_error'
    );
    const deps = buildDeps({
      provider: {
        createPixPayment: vi.fn(async () => {
          throw definite;
        })
      }
    });

    await expect(deps.service.createCashout(VALID_INPUT, 'idem-co')).rejects.toBe(definite);

    expect(deps.liquidityRelease).toHaveBeenCalledTimes(1);
    expect(deps.release).toHaveBeenCalledTimes(1);
    expect(deps.reconciliationEvents).toHaveLength(0);
  });

  it('does NOT release reservation on ambiguous timeout (provider may have sent the Pix)', async () => {
    const ambiguous = new ProviderError(
      'provider_timeout',
      'timeout',
      504,
      'ambiguous_timeout'
    );
    const deps = buildDeps({
      provider: {
        createPixPayment: vi.fn(async () => {
          throw ambiguous;
        })
      }
    });

    await expect(deps.service.createCashout(VALID_INPUT, 'idem-co')).rejects.toBe(ambiguous);

    expect(deps.liquidityRelease).not.toHaveBeenCalled();
    expect(deps.release).not.toHaveBeenCalled();
    expect(deps.reconciliationEvents[0]).toMatchObject({
      code: 'cashout_provider_state_requires_reconciliation',
      reservationId: 'reservation-1',
      providerState: 'ambiguous'
    });
  });

  it('does NOT release reservation when persistence fails after provider success', async () => {
    const dbFailure = new Error('db down');
    const deps = buildDeps();
    vi.mocked(deps.cashoutRepository.insert).mockImplementationOnce(async () => {
      throw dbFailure;
    });

    await expect(deps.service.createCashout(VALID_INPUT, 'idem-co')).rejects.toBe(dbFailure);

    expect(deps.liquidityRelease).not.toHaveBeenCalled();
    expect(deps.release).not.toHaveBeenCalled();
    expect(deps.reconciliationEvents[0]?.providerState).toBe('settled_success');
  });

  it('releases idempotency when assignment lookup fails before any reservation', async () => {
    const deps = buildDeps();
    vi.mocked(deps.providerAssignment.requireActive).mockImplementationOnce(async () => {
      throw new AppError('provider_assignment_not_found', 'no assignment', 422);
    });

    await expect(deps.service.createCashout(VALID_INPUT, 'idem-co')).rejects.toMatchObject({
      code: 'provider_assignment_not_found'
    });

    expect(deps.reserveForCashout).not.toHaveBeenCalled();
    expect(deps.liquidityRelease).not.toHaveBeenCalled();
    expect(deps.release).toHaveBeenCalledTimes(1);
  });
});

// -----------------------------------------------------------------------------
// Multi-tenant hardening: ledger balance check before liquidity reservation
// -----------------------------------------------------------------------------

function stubBalances(availableCents: number): {
  service: ClientBalanceService;
  getAvailableCents: ReturnType<typeof vi.fn>;
} {
  const getAvailableCents = vi.fn(async (_clientId: string) => availableCents);
  const service = { getAvailableCents } as unknown as ClientBalanceService;
  return { service, getAvailableCents };
}

describe('CashoutService.createCashout — ledger balance check', () => {
  it('rejects with 422 insufficient_funds when ledger balance is below amount + clientFee', async () => {
    const { pricing } = stubPricingService({
      // amount=2500 + clientFee=20 ⇒ required=2520; available=2000
      assessment: stubAssessment({ clientFeeCents: 20, providerCostCents: 10 })
    });
    const { service: balances } = stubBalances(2_000);
    const deps = buildDeps({ pricing, balances });

    await expect(deps.service.createCashout(VALID_INPUT, 'idem-bal-1')).rejects.toMatchObject({
      code: 'insufficient_funds',
      statusCode: 422,
      details: {
        clientId: VALID_INPUT.clientId,
        requiredCents: 2_520,
        availableCents: 2_000,
        amountCents: 2_500,
        clientFeeCents: 20,
        currency: 'BRL'
      }
    });

    // Must short-circuit BEFORE reserving liquidity or calling the provider.
    expect(deps.reserveForCashout).not.toHaveBeenCalled();
    expect(deps.providerStub.createPixPayment).not.toHaveBeenCalled();
    expect(deps.cashoutRepository.insert).not.toHaveBeenCalled();
    expect(deps.release).toHaveBeenCalledTimes(1);
  });

  it('allows the cash-out when balance equals exactly the required total debit', async () => {
    const { pricing } = stubPricingService({
      assessment: stubAssessment({ clientFeeCents: 0, providerCostCents: 10 })
    });
    const { service: balances, getAvailableCents } = stubBalances(2_500);
    const deps = buildDeps({ pricing, balances });

    const response = await deps.service.createCashout(VALID_INPUT, 'idem-bal-2');

    expect(response.providerPaymentId).toBe('pay_1');
    expect(deps.reserveForCashout).toHaveBeenCalledTimes(1);
    expect(getAvailableCents).toHaveBeenCalledWith(VALID_INPUT.clientId);
  });

  it('uses the realised clientFee from the pricing assessment, not zero', async () => {
    // Balance is enough for amount alone (2500) but NOT for amount+fee (2550).
    // This proves the check uses the assessment's clientFee, not just amount.
    const { pricing } = stubPricingService({
      assessment: stubAssessment({ clientFeeCents: 50, providerCostCents: 10 })
    });
    const { service: balances } = stubBalances(2_500);
    const deps = buildDeps({ pricing, balances });

    await expect(deps.service.createCashout(VALID_INPUT, 'idem-bal-3')).rejects.toMatchObject({
      code: 'insufficient_funds',
      details: {
        requiredCents: 2_550,
        availableCents: 2_500
      }
    });
  });

  it('skips the check entirely when no balance service is wired', async () => {
    // Preserves the pre-existing test surface and non-financial deployments.
    const { pricing } = stubPricingService();
    const deps = buildDeps({ pricing /* no balances */ });

    const response = await deps.service.createCashout(VALID_INPUT, 'idem-bal-4');

    expect(response.providerPaymentId).toBe('pay_1');
    expect(deps.reserveForCashout).toHaveBeenCalledTimes(1);
  });

  it('compares against amount alone when pricing is not wired (no clientFee)', async () => {
    // Without pricing, clientFeeCents=0, so the required debit equals
    // the principal amount.
    const { service: balances } = stubBalances(VALID_INPUT.amountCents - 1);
    const deps = buildDeps({ balances /* no pricing */ });

    await expect(deps.service.createCashout(VALID_INPUT, 'idem-bal-5')).rejects.toMatchObject({
      code: 'insufficient_funds',
      details: {
        requiredCents: VALID_INPUT.amountCents,
        clientFeeCents: 0
      }
    });
  });
});

// -----------------------------------------------------------------------------
// Phase 3: pricing integration
// -----------------------------------------------------------------------------

type StubAssessmentOverrides = Partial<{
  clientFeeCents: number;
  providerCostCents: number;
  marginCents: number;
  subsidyCents: number;
  chargedFromProviderBalance: boolean;
  policyDecision: CashoutPricingAssessment['policyDecision'];
}>;

function stubAssessment(overrides: StubAssessmentOverrides = {}): CashoutPricingAssessment {
  const clientFeeCents = overrides.clientFeeCents ?? 20;
  const providerCostCents = overrides.providerCostCents ?? 10;
  const marginCents = overrides.marginCents ?? clientFeeCents - providerCostCents;
  const subsidyCents = overrides.subsidyCents ?? Math.max(0, providerCostCents - clientFeeCents);
  return {
    clientFeeCents,
    providerCostCents,
    marginCents,
    subsidyCents,
    billingMode: 'add_to_debit',
    roundingMode: 'round_half_up',
    pricingRuleId: 'rule-pricing-1',
    providerCostRuleId: 'rule-cost-1',
    pricingRuleSnapshot: {
      id: 'rule-pricing-1',
      pricingPlanVersionId: 'ppv-1',
      operationType: 'cash_out',
      triggerEvent: 'cash_out_created',
      fixedFeeCents: clientFeeCents,
      variableFeeBps: 0,
      minFeeCents: null,
      maxFeeCents: null,
      billingMode: 'add_to_debit',
      roundingMode: 'round_half_up',
      allowNegativeMargin: false,
      maxNegativeMarginCentsPerTxn: null,
      dailySubsidyLimitCents: null,
      monthlySubsidyLimitCents: null
    },
    providerCostRuleSnapshot: {
      id: 'rule-cost-1',
      providerAccountId: 'acc-1',
      operationType: 'cash_out',
      triggerEvent: 'cash_out_created',
      fixedCostCents: providerCostCents,
      variableCostBps: 0,
      minCostCents: null,
      maxCostCents: null,
      chargedFromProviderBalance: overrides.chargedFromProviderBalance ?? true,
      roundingMode: 'round_half_up'
    },
    policy: {
      allowNegativeMargin: false,
      maxNegativeMarginCentsPerTxn: null,
      dailySubsidyLimitCents: null,
      monthlySubsidyLimitCents: null
    },
    policyDecision: overrides.policyDecision ?? {
      kind: 'approved',
      subsidyCents: 0,
      dailySubsidyTotalBeforeCents: 0,
      monthlySubsidyTotalBeforeCents: 0
    }
  };
}

function feeAssessmentRecord(
  overrides: Partial<FeeAssessmentRecord> = {}
): FeeAssessmentRecord {
  return {
    id: 'fee-assessment-1',
    transactionType: 'cashout',
    transactionId: 'cashout-1',
    clientId: VALID_INPUT.clientId,
    providerAccountId: 'acc-1',
    operationType: 'cash_out',
    triggerEvent: 'cash_out_created',
    principalAmountCents: VALID_INPUT.amountCents,
    clientFeeCents: 20,
    providerCostCents: 10,
    marginCents: 10,
    subsidyCents: 0,
    pricingRuleId: 'rule-pricing-1',
    providerCostRuleId: 'rule-cost-1',
    billingMode: 'add_to_debit',
    roundingMode: 'round_half_up',
    status: 'estimated',
    createdAt: new Date('2026-05-22T00:00:00Z'),
    updatedAt: new Date('2026-05-22T00:00:00Z'),
    ...overrides
  };
}

function stubPricingService(opts: {
  assessment?: CashoutPricingAssessment | null;
} = {}): {
  pricing: PricingService;
  assessForCashout: ReturnType<typeof vi.fn>;
  persistAssessment: ReturnType<typeof vi.fn>;
  persistSubsidyEvent: ReturnType<typeof vi.fn>;
} {
  const assessment = opts.assessment === undefined ? stubAssessment() : opts.assessment;
  const assessForCashout = vi.fn(async () => assessment);
  const persistAssessment = vi.fn(async () => feeAssessmentRecord());
  const persistSubsidyEvent = vi.fn(async () => ({
    id: 'subsidy-1',
    feeAssessmentId: 'fee-assessment-1',
    clientId: VALID_INPUT.clientId,
    transactionType: 'cashout' as const,
    transactionId: 'cashout-1',
    subsidyCents: 5,
    status: 'approved' as const,
    reason: null,
    createdAt: new Date('2026-05-22T00:00:00Z')
  }));
  const pricing = {
    assessForCashout,
    persistAssessment,
    persistSubsidyEvent,
    evaluatePolicyWithAggregates: vi.fn()
  } as unknown as PricingService;
  return { pricing, assessForCashout, persistAssessment, persistSubsidyEvent };
}

describe('CashoutService.createCashout — pricing integration', () => {
  it('runs without pricing changes when assessForCashout returns null', async () => {
    const { pricing, assessForCashout, persistAssessment, persistSubsidyEvent } =
      stubPricingService({ assessment: null });
    const deps = buildDeps({ pricing });

    const response = await deps.service.createCashout(VALID_INPUT, 'idem-co');

    expect(assessForCashout).toHaveBeenCalledTimes(1);
    expect(persistAssessment).not.toHaveBeenCalled();
    expect(persistSubsidyEvent).not.toHaveBeenCalled();
    expect(response.clientFeeCents).toBe(0);
    expect(response.providerCostCents).toBe(0);
    expect(response.marginCents).toBe(0);
    expect(response.totalDebitAmountCents).toBe(VALID_INPUT.amountCents);
    expect(response.feeAssessmentId).toBeNull();
    expect(deps.reserveForCashout).toHaveBeenCalledWith(
      expect.anything(),
      expect.objectContaining({
        principalAmountCents: VALID_INPUT.amountCents,
        expectedProviderCostCents: 0
      })
    );
  });

  it('persists a fee_assessment and exposes fee fields when assessment is approved', async () => {
    const { pricing, persistAssessment, persistSubsidyEvent } = stubPricingService();
    const deps = buildDeps({ pricing });

    const response = await deps.service.createCashout(VALID_INPUT, 'idem-co');

    expect(persistAssessment).toHaveBeenCalledTimes(1);
    expect(persistAssessment).toHaveBeenCalledWith(
      expect.anything(),
      expect.objectContaining({
        transactionType: 'cashout',
        transactionId: 'cashout-1',
        triggerEvent: 'cash_out_created',
        principalAmountCents: VALID_INPUT.amountCents,
        status: 'estimated'
      })
    );
    expect(persistSubsidyEvent).not.toHaveBeenCalled();
    expect(response.clientFeeCents).toBe(20);
    expect(response.providerCostCents).toBe(10);
    expect(response.marginCents).toBe(10);
    expect(response.totalDebitAmountCents).toBe(VALID_INPUT.amountCents + 20);
    expect(response.feeAssessmentId).toBe('fee-assessment-1');
  });

  it('reserves principal + expected provider cost when charged_from_provider_balance is true', async () => {
    const { pricing } = stubPricingService();
    const deps = buildDeps({ pricing });

    await deps.service.createCashout(VALID_INPUT, 'idem-co');

    expect(deps.reserveForCashout).toHaveBeenCalledWith(
      expect.anything(),
      expect.objectContaining({
        principalAmountCents: VALID_INPUT.amountCents,
        expectedProviderCostCents: 10
      })
    );
  });

  it('reserves only principal when provider cost is charged out-of-band', async () => {
    const { pricing } = stubPricingService({
      assessment: stubAssessment({ chargedFromProviderBalance: false })
    });
    const deps = buildDeps({ pricing });

    await deps.service.createCashout(VALID_INPUT, 'idem-co');

    expect(deps.reserveForCashout).toHaveBeenCalledWith(
      expect.anything(),
      expect.objectContaining({
        principalAmountCents: VALID_INPUT.amountCents,
        expectedProviderCostCents: 0
      })
    );
  });

  it('rejects with 422 before the provider call when policy decision is rejected', async () => {
    const rejected = stubAssessment({
      clientFeeCents: 0,
      providerCostCents: 10,
      marginCents: -10,
      subsidyCents: 10,
      policyDecision: {
        kind: 'rejected',
        code: 'pricing_negative_margin_not_allowed',
        subsidyCents: 10,
        reason: 'not allowed',
        dailySubsidyTotalBeforeCents: 0,
        monthlySubsidyTotalBeforeCents: 0
      }
    });
    const { pricing, persistAssessment } = stubPricingService({ assessment: rejected });
    const deps = buildDeps({ pricing });

    await expect(deps.service.createCashout(VALID_INPUT, 'idem-co')).rejects.toMatchObject({
      code: 'pricing_negative_margin_not_allowed',
      statusCode: 422
    });

    expect(deps.reserveForCashout).not.toHaveBeenCalled();
    expect(deps.providerStub.createPixPayment).not.toHaveBeenCalled();
    expect(persistAssessment).not.toHaveBeenCalled();
    // idempotency is released because no provider side-effect happened
    expect(deps.release).toHaveBeenCalledTimes(1);
  });

  it('persists a subsidy_event when policy approves a positive subsidy', async () => {
    const approved = stubAssessment({
      clientFeeCents: 5,
      providerCostCents: 10,
      marginCents: -5,
      subsidyCents: 5,
      policyDecision: {
        kind: 'approved',
        subsidyCents: 5,
        dailySubsidyTotalBeforeCents: 0,
        monthlySubsidyTotalBeforeCents: 0
      }
    });
    const { pricing, persistAssessment, persistSubsidyEvent } = stubPricingService({
      assessment: approved
    });
    const deps = buildDeps({ pricing });

    const response = await deps.service.createCashout(VALID_INPUT, 'idem-co');

    expect(persistAssessment).toHaveBeenCalledTimes(1);
    expect(persistSubsidyEvent).toHaveBeenCalledTimes(1);
    expect(persistSubsidyEvent).toHaveBeenCalledWith(
      expect.anything(),
      expect.objectContaining({
        feeAssessmentId: 'fee-assessment-1',
        clientId: VALID_INPUT.clientId,
        subsidyCents: 5,
        status: 'approved'
      })
    );
    expect(response.marginCents).toBe(-5);
  });
});

// ────────────────────────────────────────────────────────────────────
// Phase 7 — handleCashoutStatusUpdate
// ────────────────────────────────────────────────────────────────────

describe('CashoutService.handleCashoutStatusUpdate', () => {
  const PROVIDER: ProviderName = 'bents';
  const PROVIDER_PAYMENT_ID = 'pay_999';
  const occurredAt = new Date('2026-05-22T03:00:00Z');

  function baseEvent(
    overrides: Partial<CashoutStatusUpdateEvent> = {}
  ): CashoutStatusUpdateEvent {
    return {
      providerName: PROVIDER,
      providerPaymentId: PROVIDER_PAYMENT_ID,
      status: 'completed',
      occurredAt,
      ...overrides
    };
  }

  it('returns noop:cashout_not_found when the row is missing', async () => {
    const deps = buildDeps({ findByProviderPaymentIdResult: null });
    const result = await deps.service.handleCashoutStatusUpdate(baseEvent());
    expect(result).toEqual({ status: 'noop', reason: 'cashout_not_found' });
    expect(deps.cashoutRepository.markStatus).not.toHaveBeenCalled();
    expect(deps.outbox.enqueue).not.toHaveBeenCalled();
  });

  it('returns noop:already_in_status when the cashout already has the target status', async () => {
    const deps = buildDeps({
      findByProviderPaymentIdResult: {
        ...buildDeps().baseCashout,
        status: 'completed',
        providerPaymentId: PROVIDER_PAYMENT_ID
      }
    });
    const result = await deps.service.handleCashoutStatusUpdate(baseEvent({ status: 'completed' }));
    expect(result).toMatchObject({ status: 'noop', reason: 'already_in_status' });
    expect(deps.cashoutRepository.markStatus).not.toHaveBeenCalled();
    expect(deps.outbox.enqueue).not.toHaveBeenCalled();
  });

  it('returns noop:invalid_transition when markStatus reports the row already advanced', async () => {
    const deps = buildDeps({
      findByProviderPaymentIdResult: {
        ...buildDeps().baseCashout,
        status: 'processing',
        providerPaymentId: PROVIDER_PAYMENT_ID
      },
      markStatusResult: { kind: 'transition_not_allowed', currentStatus: 'failed' }
    });
    const result = await deps.service.handleCashoutStatusUpdate(baseEvent({ status: 'completed' }));
    expect(result).toMatchObject({
      status: 'noop',
      reason: 'invalid_transition',
      fromStatus: 'failed',
      toStatus: 'completed'
    });
    expect(deps.outbox.enqueue).not.toHaveBeenCalled();
  });

  it.each<TerminalCashoutStatus>(['completed', 'failed', 'returned'])(
    'transitions processing → %s and enqueues a pix.cash_out.%s outbox event',
    async (target) => {
      const existing = {
        ...buildDeps().baseCashout,
        status: 'processing' as const,
        providerPaymentId: PROVIDER_PAYMENT_ID
      };
      const deps = buildDeps({ findByProviderPaymentIdResult: existing });
      const result = await deps.service.handleCashoutStatusUpdate(baseEvent({ status: target }));

      expect(result).toMatchObject({
        status: 'updated',
        cashoutId: existing.id,
        previousStatus: 'processing',
        newStatus: target,
        financial: {
          ledger: 'none',
          ledgerEntriesPosted: 0,
          // No `pricing` and no `ledger` injected: every branch resolves
          // to `not_found` / `none` / 0 entries.
          reservation: 'not_found',
          feeAssessment: 'none',
          feeAssessmentId: null
        }
      });
      expect(deps.cashoutRepository.markStatus).toHaveBeenCalledWith(
        expect.anything(),
        existing.id,
        target,
        { failureReason: target === 'completed' ? null : 'provider_rejected', occurredAt }
      );
      expect(deps.outbox.enqueue).toHaveBeenCalledTimes(1);
      const enqueueSpy = vi.mocked(deps.outbox.enqueue);
      const enqueueArgs = enqueueSpy.mock.calls[0]?.[1] as OutboxEventInsertInput;
      expect(enqueueArgs.aggregateType).toBe('cashout');
      expect(enqueueArgs.aggregateId).toBe(existing.id);
      expect(enqueueArgs.eventType).toBe(`pix.cash_out.${target}`);
      expect(enqueueArgs.payload).toMatchObject({
        cashoutId: existing.id,
        externalId: existing.externalId,
        clientId: existing.clientId,
        provider: existing.providerName,
        providerPaymentId: PROVIDER_PAYMENT_ID,
        status: target,
        amountCents: existing.amountCents,
        createdAt: existing.createdAt.toISOString(),
        occurredAt: occurredAt.toISOString(),
        e2eId: existing.e2eId
      });
    }
  );

  // ── P0 regression — inbound Bents terminal cash-out must NOT degrade to
  // `processing`. A `pix.payment.sent` notification that also carries an
  // explicit `status: SUCCESS` is a TERMINAL settlement: the explicit status
  // MUST win over the `sent` event verb (which on its own maps to
  // `processing`). The full inbound chain (real Bents adapter → domain
  // service) must therefore enqueue `pix.cash_out.completed`, and never
  // `pix.cash_out.processing`.
  it('inbound Bents pix.payment.sent + SUCCESS enqueues pix.cash_out.completed, never pix.cash_out.processing', async () => {
    const adapter = new BentsWebhookAdapter();
    const inboundPayload = {
      event: 'pix.payment.sent',
      event_id: 'evt_cashout_success_001',
      timestamp: occurredAt.toISOString(),
      data: {
        transaction_id: PROVIDER_PAYMENT_ID,
        status: 'SUCCESS',
        e2e_id: 'E18236120202505011545002efgh'
      }
    };
    const parsed = await adapter.parse({
      rawBody: Buffer.from(JSON.stringify(inboundPayload)),
      payload: inboundPayload,
      headers: {}
    });
    const normalized = await adapter.normalize(parsed);

    // Mapping layer: explicit SUCCESS wins over the `sent` verb → completed.
    expect(parsed.operationType).toBe('cash_out');
    expect(normalized.normalizedStatus).toEqual({ kind: 'cash_out', status: 'completed' });
    if (normalized.normalizedStatus.kind !== 'cash_out') {
      throw new Error('expected a cash_out normalized status');
    }
    // Sanity guard: the bug would surface as `processing` here.
    expect(normalized.normalizedStatus.status).not.toBe('processing');
    const terminalStatus = normalized.normalizedStatus.status as TerminalCashoutStatus;

    // Translate the normalized terminal status into the domain event exactly
    // as WebhookEventProcessor.dispatchCashOut does, then run the REAL service
    // so the assertion is on the actually-enqueued outbox event_type.
    const existing = {
      ...buildDeps().baseCashout,
      status: 'processing' as const,
      providerPaymentId: PROVIDER_PAYMENT_ID
    };
    const deps = buildDeps({ findByProviderPaymentIdResult: existing });

    const result = await deps.service.handleCashoutStatusUpdate(
      baseEvent({ status: terminalStatus })
    );

    expect(result).toMatchObject({
      status: 'updated',
      previousStatus: 'processing',
      newStatus: 'completed'
    });

    const enqueueSpy = vi.mocked(deps.outbox.enqueue);
    expect(enqueueSpy).toHaveBeenCalledTimes(1);
    const enqueued = enqueueSpy.mock.calls[0]?.[1] as OutboxEventInsertInput;
    expect(enqueued.eventType).toBe('pix.cash_out.completed');
    expect(enqueued.eventType).not.toBe('pix.cash_out.processing');
    expect(enqueued.payload).toMatchObject({ status: 'completed' });
  });

  it('backfills receiver_name/receiver_document from the provider webhook when the row has none', async () => {
    const existing = {
      ...buildDeps().baseCashout,
      status: 'processing' as const,
      providerPaymentId: PROVIDER_PAYMENT_ID,
      receiverName: null,
      receiverDocument: null
    };
    const deps = buildDeps({ findByProviderPaymentIdResult: existing });

    await deps.service.handleCashoutStatusUpdate(
      baseEvent({
        status: 'completed',
        receiverName: 'DAYANE JAQUELINE MARINS ALCANTES 41530170869',
        receiverDocument: '**.921.710/****-**'
      })
    );

    expect(deps.applyProviderConfirmation).toHaveBeenCalledWith(expect.anything(), existing.id, {
      receiverName: 'DAYANE JAQUELINE MARINS ALCANTES 41530170869',
      receiverDocument: '**.921.710/****-**'
    });

    const enqueueArgs = vi.mocked(deps.outbox.enqueue).mock.calls[0]?.[1] as OutboxEventInsertInput;
    expect(enqueueArgs.payload).toMatchObject({
      receiverName: 'DAYANE JAQUELINE MARINS ALCANTES 41530170869',
      receiverDocument: '**.921.710/****-**'
    });
  });

  it('backfills the full receiver block and e2e_id from an async confirmation webhook', async () => {
    const existing = {
      ...buildDeps().baseCashout,
      status: 'processing' as const,
      providerPaymentId: PROVIDER_PAYMENT_ID,
      receiverName: null,
      receiverDocument: null,
      receiverBank: null,
      receiverIspb: null,
      e2eId: null
    };
    const deps = buildDeps({ findByProviderPaymentIdResult: existing });

    await deps.service.handleCashoutStatusUpdate(
      baseEvent({
        status: 'completed',
        receiverName: 'DAYANE JAQUELINE MARINS ALCANTES 41530170869',
        receiverDocument: '**.921.710/****-**',
        receiverBank: 'A55 SCD S.A.',
        receiverIspb: '48756121',
        e2eId: 'E_ASYNC_BACKFILL'
      })
    );

    expect(deps.applyProviderConfirmation).toHaveBeenCalledWith(expect.anything(), existing.id, {
      receiverName: 'DAYANE JAQUELINE MARINS ALCANTES 41530170869',
      receiverDocument: '**.921.710/****-**',
      receiverBank: 'A55 SCD S.A.',
      receiverIspb: '48756121',
      e2eId: 'E_ASYNC_BACKFILL'
    });

    // The committed outbox snapshot reflects the backfilled detail, so the
    // public `pix.cash_out.completed` webhook carries the receiver + e2e_id.
    const enqueueArgs = vi.mocked(deps.outbox.enqueue).mock.calls[0]?.[1] as OutboxEventInsertInput;
    expect(enqueueArgs.payload).toMatchObject({
      receiverBank: 'A55 SCD S.A.',
      receiverIspb: '48756121',
      e2eId: 'E_ASYNC_BACKFILL'
    });
  });

  it('does not overwrite an existing e2e_id with a stale webhook value', async () => {
    const existing = {
      ...buildDeps().baseCashout,
      status: 'processing' as const,
      providerPaymentId: PROVIDER_PAYMENT_ID,
      e2eId: 'E_FROM_CREATE'
    };
    const deps = buildDeps({ findByProviderPaymentIdResult: existing });

    await deps.service.handleCashoutStatusUpdate(
      baseEvent({ status: 'completed', e2eId: 'E_FROM_WEBHOOK' })
    );

    // COALESCE in the repository keeps the create-time e2e_id; the fake
    // mirrors that semantics, so the outbox snapshot keeps the original.
    const enqueueArgs = vi.mocked(deps.outbox.enqueue).mock.calls[0]?.[1] as OutboxEventInsertInput;
    expect(enqueueArgs.payload).toMatchObject({ e2eId: 'E_FROM_CREATE' });
  });

  it('does not overwrite a request-supplied receiver with the provider value', async () => {
    const existing = {
      ...buildDeps().baseCashout,
      status: 'processing' as const,
      providerPaymentId: PROVIDER_PAYMENT_ID,
      receiverName: 'Request Receiver',
      receiverDocument: '111.111.111-11'
    };
    const deps = buildDeps({ findByProviderPaymentIdResult: existing });

    await deps.service.handleCashoutStatusUpdate(
      baseEvent({
        status: 'completed',
        receiverName: 'Provider Receiver',
        receiverDocument: '**.921.710/****-**'
      })
    );

    const enqueueArgs = vi.mocked(deps.outbox.enqueue).mock.calls[0]?.[1] as OutboxEventInsertInput;
    expect(enqueueArgs.payload).toMatchObject({
      receiverName: 'Request Receiver',
      receiverDocument: '111.111.111-11'
    });
  });

  it('allows the completed → returned chargeback transition', async () => {
    const existing = {
      ...buildDeps().baseCashout,
      status: 'completed' as const,
      providerPaymentId: PROVIDER_PAYMENT_ID
    };
    const deps = buildDeps({ findByProviderPaymentIdResult: existing });
    const result = await deps.service.handleCashoutStatusUpdate(baseEvent({ status: 'returned' }));
    expect(result).toMatchObject({
      status: 'updated',
      cashoutId: existing.id,
      previousStatus: 'completed',
      newStatus: 'returned',
      financial: { ledger: 'none', reservation: 'not_found', feeAssessment: 'none' }
    });
    const enqueueSpy = vi.mocked(deps.outbox.enqueue);
    const enqueueArgs = enqueueSpy.mock.calls[0]?.[1] as OutboxEventInsertInput;
    expect(enqueueArgs.eventType).toBe('pix.cash_out.returned');
  });
});

// ────────────────────────────────────────────────────────────────────
// Phase 8 — financial closure (ledger + liquidity + fee_assessment)
// ────────────────────────────────────────────────────────────────────

const PROVIDER_PAYMENT_ID_FIN = 'pay_fin';
const occurredAtFin = new Date('2026-05-22T04:00:00Z');

function buildReservation(
  overrides: Partial<LiquidityReservationRecord> = {}
): LiquidityReservationRecord {
  return {
    id: 'reservation-fin',
    clientId: VALID_INPUT.clientId,
    providerAccountId: 'acc-1',
    cashoutId: 'cashout-1',
    amountCents: 2500,
    principalAmountCents: 2500,
    expectedProviderCostCents: 0,
    feeAssessmentId: 'fee-assessment-1',
    releaseReason: null,
    status: 'reserved',
    expiresAt: new Date('2026-05-22T05:00:00Z'),
    createdAt: new Date('2026-05-22T00:00:00Z'),
    releasedAt: null,
    ...overrides
  };
}

function stubPricingForFinancialClosure(opts: {
  existing?: FeeAssessmentRecord | null;
  promotedStatus?: 'posted' | 'cancelled';
} = {}) {
  const existing =
    opts.existing === undefined ? feeAssessmentRecord({ status: 'estimated' }) : opts.existing;
  const findAssessmentByTransaction = vi.fn(async () => existing);
  const promoteAssessmentStatus = vi.fn(
    async (_sql: Sql, id: string, status: 'posted' | 'cancelled') =>
      feeAssessmentRecord({ id, status })
  );
  const assessForCashout = vi.fn();
  const persistAssessment = vi.fn();
  const pricing = {
    findAssessmentByTransaction,
    promoteAssessmentStatus,
    assessForCashout,
    persistAssessment
  } as unknown as PricingService;
  return {
    pricing,
    findAssessmentByTransaction,
    promoteAssessmentStatus,
    assessForCashout,
    persistAssessment,
    promotedStatus: opts.promotedStatus ?? 'posted'
  };
}

function stubLedger() {
  const postFeeAssessment = vi.fn(async () => ({
    kind: 'first_post' as const,
    entries: [
      { id: 'ledger-1' },
      { id: 'ledger-2' },
      { id: 'ledger-3' },
      { id: 'ledger-4' }
    ]
  }));
  const postCashoutReturnReversal = vi.fn(async () => [
    { id: 'ledger-r1' },
    { id: 'ledger-r2' }
  ]);
  const ledger = {
    postFeeAssessment,
    postCashoutReturnReversal
  } as unknown as LedgerService;
  return { ledger, postFeeAssessment, postCashoutReturnReversal };
}

describe('CashoutService.handleCashoutStatusUpdate — financial closure', () => {
  it('completed: consumes the reservation, promotes fee_assessment to posted, posts cash_out_completed', async () => {
    const reservation = buildReservation();
    const { pricing, findAssessmentByTransaction, promoteAssessmentStatus } =
      stubPricingForFinancialClosure();
    const { ledger, postFeeAssessment } = stubLedger();
    const existing = {
      ...buildDeps().baseCashout,
      status: 'processing' as const,
      providerPaymentId: PROVIDER_PAYMENT_ID_FIN
    };
    const deps = buildDeps({
      pricing,
      ledger,
      activeReservation: reservation,
      findByProviderPaymentIdResult: existing
    });

    const result = await deps.service.handleCashoutStatusUpdate({
      providerName: 'bents',
      providerPaymentId: PROVIDER_PAYMENT_ID_FIN,
      status: 'completed',
      occurredAt: occurredAtFin
    });

    expect(deps.liquidityFindActive).toHaveBeenCalledWith(expect.anything(), existing.id);
    expect(deps.liquidityConsume).toHaveBeenCalledWith(
      expect.anything(),
      reservation.id,
      expect.objectContaining({ reason: 'cashout_completed' })
    );
    expect(findAssessmentByTransaction).toHaveBeenCalledWith(
      expect.anything(),
      'cashout',
      existing.id,
      'cash_out_created'
    );
    expect(promoteAssessmentStatus).toHaveBeenCalledWith(
      expect.anything(),
      'fee-assessment-1',
      'posted'
    );
    expect(postFeeAssessment).toHaveBeenCalledWith(
      expect.anything(),
      expect.objectContaining({
        transactionId: existing.id,
        triggerEvent: 'cash_out_completed',
        operationType: 'cash_out',
        clientId: existing.clientId,
        providerName: existing.providerName,
        providerAccountId: existing.providerAccountId,
        providerReferenceId: PROVIDER_PAYMENT_ID_FIN,
        principalAmountCents: existing.amountCents,
        feeAssessmentId: 'fee-assessment-1'
      })
    );
    expect(deps.liquidityRelease).not.toHaveBeenCalled();

    expect(result).toMatchObject({
      status: 'updated',
      financial: {
        ledger: 'cash_out_completed',
        ledgerEntriesPosted: 4,
        reservation: 'consumed',
        feeAssessment: 'posted',
        feeAssessmentId: 'fee-assessment-1'
      }
    });
  });

  it('failed: releases the reservation and cancels the estimated fee_assessment', async () => {
    const reservation = buildReservation();
    const { pricing, findAssessmentByTransaction, promoteAssessmentStatus } =
      stubPricingForFinancialClosure();
    const { ledger, postFeeAssessment, postCashoutReturnReversal } = stubLedger();
    const existing = {
      ...buildDeps().baseCashout,
      status: 'processing' as const,
      providerPaymentId: PROVIDER_PAYMENT_ID_FIN
    };
    const deps = buildDeps({
      pricing,
      ledger,
      activeReservation: reservation,
      findByProviderPaymentIdResult: existing
    });

    const result = await deps.service.handleCashoutStatusUpdate({
      providerName: 'bents',
      providerPaymentId: PROVIDER_PAYMENT_ID_FIN,
      status: 'failed',
      occurredAt: occurredAtFin
    });

    expect(deps.liquidityRelease).toHaveBeenCalledWith(
      expect.anything(),
      reservation.id,
      expect.objectContaining({ reason: 'cashout_failed' })
    );
    expect(deps.liquidityConsume).not.toHaveBeenCalled();
    expect(findAssessmentByTransaction).toHaveBeenCalledTimes(1);
    expect(promoteAssessmentStatus).toHaveBeenCalledWith(
      expect.anything(),
      'fee-assessment-1',
      'cancelled'
    );
    expect(postFeeAssessment).not.toHaveBeenCalled();
    expect(postCashoutReturnReversal).not.toHaveBeenCalled();

    expect(result).toMatchObject({
      status: 'updated',
      financial: {
        ledger: 'none',
        ledgerEntriesPosted: 0,
        reservation: 'released',
        feeAssessment: 'cancelled',
        feeAssessmentId: 'fee-assessment-1'
      }
    });
  });

  it('processing → returned: net-zero closure, releases reservation with the pre-completion reason', async () => {
    const reservation = buildReservation();
    const { pricing, promoteAssessmentStatus } = stubPricingForFinancialClosure();
    const { ledger, postCashoutReturnReversal } = stubLedger();
    const existing = {
      ...buildDeps().baseCashout,
      status: 'processing' as const,
      providerPaymentId: PROVIDER_PAYMENT_ID_FIN
    };
    const deps = buildDeps({
      pricing,
      ledger,
      activeReservation: reservation,
      findByProviderPaymentIdResult: existing
    });

    const result = await deps.service.handleCashoutStatusUpdate({
      providerName: 'bents',
      providerPaymentId: PROVIDER_PAYMENT_ID_FIN,
      status: 'returned',
      occurredAt: occurredAtFin
    });

    expect(deps.liquidityRelease).toHaveBeenCalledWith(
      expect.anything(),
      reservation.id,
      expect.objectContaining({ reason: 'cashout_returned_pre_completion' })
    );
    expect(promoteAssessmentStatus).toHaveBeenCalledWith(
      expect.anything(),
      'fee-assessment-1',
      'cancelled'
    );
    expect(postCashoutReturnReversal).not.toHaveBeenCalled();

    expect(result).toMatchObject({
      status: 'updated',
      financial: {
        ledger: 'none',
        reservation: 'released',
        feeAssessment: 'cancelled'
      }
    });
  });

  it('completed → returned: posts full reversal (principal + fee), reports feeAssessment reversed, no reservation action', async () => {
    const postedAssessment = feeAssessmentRecord({ status: 'posted' });
    const { pricing, findAssessmentByTransaction, promoteAssessmentStatus } =
      stubPricingForFinancialClosure({ existing: postedAssessment });
    const { ledger, postCashoutReturnReversal, postFeeAssessment } = stubLedger();
    const existing = {
      ...buildDeps().baseCashout,
      status: 'completed' as const,
      providerPaymentId: PROVIDER_PAYMENT_ID_FIN
    };
    const deps = buildDeps({
      pricing,
      ledger,
      findByProviderPaymentIdResult: existing
    });

    const result = await deps.service.handleCashoutStatusUpdate({
      providerName: 'bents',
      providerPaymentId: PROVIDER_PAYMENT_ID_FIN,
      status: 'returned',
      occurredAt: occurredAtFin
    });

    expect(deps.liquidityFindActive).not.toHaveBeenCalled();
    expect(deps.liquidityRelease).not.toHaveBeenCalled();
    expect(deps.liquidityConsume).not.toHaveBeenCalled();
    expect(findAssessmentByTransaction).toHaveBeenCalledWith(
      expect.anything(),
      'cashout',
      existing.id,
      'cash_out_created'
    );
    // Fee refund policy: the posted assessment row is NOT mutated (immutable
    // audit trail), but the service passes clientFeeCents so the ledger
    // includes fee-reversal entries in the same idempotent batch.
    expect(promoteAssessmentStatus).not.toHaveBeenCalled();
    expect(postFeeAssessment).not.toHaveBeenCalled();
    expect(postCashoutReturnReversal).toHaveBeenCalledWith(
      expect.anything(),
      expect.objectContaining({
        transactionId: existing.id,
        clientId: existing.clientId,
        providerName: existing.providerName,
        providerAccountId: existing.providerAccountId,
        providerReferenceId: PROVIDER_PAYMENT_ID_FIN,
        principalAmountCents: existing.amountCents,
        clientFeeCents: postedAssessment.clientFeeCents,
        feeAssessmentId: postedAssessment.id
      })
    );

    expect(result).toMatchObject({
      status: 'updated',
      previousStatus: 'completed',
      newStatus: 'returned',
      financial: {
        ledger: 'cash_out_returned',
        ledgerEntriesPosted: 2,
        reservation: 'not_found',
        feeAssessment: 'reversed',
        feeAssessmentId: postedAssessment.id
      }
    });
  });

  it('completed: backfills a posted fee_assessment when none was created at cash-out creation time', async () => {
    const { pricing, findAssessmentByTransaction, persistAssessment, assessForCashout } =
      stubPricingForFinancialClosure({ existing: null });
    const backfilled = feeAssessmentRecord({ id: 'fee-backfilled', status: 'posted' });
    vi.mocked(persistAssessment).mockResolvedValueOnce(backfilled);
    vi.mocked(assessForCashout).mockResolvedValueOnce({
      clientFeeCents: 20,
      providerCostCents: 10,
      marginCents: 10,
      subsidyCents: 0,
      pricingRuleId: 'rule-pricing-1',
      providerCostRuleId: 'rule-cost-1',
      billingMode: 'add_to_debit',
      roundingMode: 'round_half_up',
      chargedFromProviderBalance: true,
      policyDecision: {
        kind: 'approved',
        subsidyCents: 0,
        dailySubsidyTotalBeforeCents: 0,
        monthlySubsidyTotalBeforeCents: 0
      }
    });
    const { ledger, postFeeAssessment } = stubLedger();
    const existing = {
      ...buildDeps().baseCashout,
      status: 'processing' as const,
      providerPaymentId: PROVIDER_PAYMENT_ID_FIN
    };
    const deps = buildDeps({
      pricing,
      ledger,
      activeReservation: buildReservation(),
      findByProviderPaymentIdResult: existing
    });

    const result = await deps.service.handleCashoutStatusUpdate({
      providerName: 'bents',
      providerPaymentId: PROVIDER_PAYMENT_ID_FIN,
      status: 'completed',
      occurredAt: occurredAtFin
    });

    expect(findAssessmentByTransaction).toHaveBeenCalledTimes(1);
    expect(assessForCashout).toHaveBeenCalledWith(
      expect.anything(),
      expect.objectContaining({
        clientId: existing.clientId,
        providerAccountId: existing.providerAccountId,
        amountCents: existing.amountCents
      })
    );
    expect(persistAssessment).toHaveBeenCalledWith(
      expect.anything(),
      expect.objectContaining({
        transactionType: 'cashout',
        transactionId: existing.id,
        triggerEvent: 'cash_out_created',
        status: 'posted'
      })
    );
    const persistArgs = vi.mocked(persistAssessment).mock.calls[0]?.[1] as {
      metadata?: Record<string, unknown>;
    };
    expect(persistArgs.metadata).toMatchObject({ backfilled: true });
    expect(postFeeAssessment).toHaveBeenCalledTimes(1);

    expect(result).toMatchObject({
      status: 'updated',
      financial: {
        ledger: 'cash_out_completed',
        feeAssessmentId: 'fee-backfilled',
        feeAssessment: 'posted'
      }
    });
  });

  it('completed without ledger wiring: still settles the reservation and promotes the assessment, but skips ledger', async () => {
    const reservation = buildReservation();
    const { pricing, promoteAssessmentStatus } = stubPricingForFinancialClosure();
    const existing = {
      ...buildDeps().baseCashout,
      status: 'processing' as const,
      providerPaymentId: PROVIDER_PAYMENT_ID_FIN
    };
    const deps = buildDeps({
      pricing,
      activeReservation: reservation,
      findByProviderPaymentIdResult: existing
    });

    const result = await deps.service.handleCashoutStatusUpdate({
      providerName: 'bents',
      providerPaymentId: PROVIDER_PAYMENT_ID_FIN,
      status: 'completed',
      occurredAt: occurredAtFin
    });

    expect(deps.liquidityConsume).toHaveBeenCalledTimes(1);
    expect(promoteAssessmentStatus).toHaveBeenCalledWith(
      expect.anything(),
      'fee-assessment-1',
      'posted'
    );
    expect(result).toMatchObject({
      status: 'updated',
      financial: {
        ledger: 'none',
        ledgerEntriesPosted: 0,
        reservation: 'consumed',
        feeAssessment: 'posted'
      }
    });
  });

  it('completed with no active reservation found (duplicate webhook): does not blow up', async () => {
    const { pricing } = stubPricingForFinancialClosure();
    const { ledger } = stubLedger();
    const existing = {
      ...buildDeps().baseCashout,
      status: 'processing' as const,
      providerPaymentId: PROVIDER_PAYMENT_ID_FIN
    };
    const deps = buildDeps({
      pricing,
      ledger,
      activeReservation: null,
      findByProviderPaymentIdResult: existing
    });

    const result = await deps.service.handleCashoutStatusUpdate({
      providerName: 'bents',
      providerPaymentId: PROVIDER_PAYMENT_ID_FIN,
      status: 'completed',
      occurredAt: occurredAtFin
    });

    expect(deps.liquidityConsume).not.toHaveBeenCalled();
    expect(result).toMatchObject({
      status: 'updated',
      financial: {
        ledger: 'cash_out_completed',
        reservation: 'not_found'
      }
    });
  });
});

describe('CashoutService.getCashoutById — identifier contract', () => {
  it('returns the cashout when the UUID id matches and belongs to the caller', async () => {
    const deps = buildDeps();
    const cashoutRecord = {
      ...deps.baseCashout,
      id: 'cashout-uuid-123',
      clientId: VALID_INPUT.clientId
    };
    vi.mocked(deps.cashoutRepository.findById).mockResolvedValueOnce(cashoutRecord);

    const result = await deps.service.getCashoutById(VALID_INPUT.clientId, 'cashout-uuid-123');

    expect(result).not.toBeNull();
    expect(result?.id).toBe('cashout-uuid-123');
    // The response does NOT carry a `txid` field — cash-out has no Pix txid.
    expect(result).not.toHaveProperty('txid');
  });

  it('returns null when the cashout id belongs to a different client (ownership guard)', async () => {
    const deps = buildDeps();
    const cashoutRecord = {
      ...deps.baseCashout,
      id: 'cashout-uuid-123',
      clientId: 'other-client-id'
    };
    vi.mocked(deps.cashoutRepository.findById).mockResolvedValueOnce(cashoutRecord);

    const result = await deps.service.getCashoutById(VALID_INPUT.clientId, 'cashout-uuid-123');

    expect(result).toBeNull();
  });

  it('returns null when no row exists for the given id', async () => {
    const deps = buildDeps();
    vi.mocked(deps.cashoutRepository.findById).mockResolvedValueOnce(null);

    const result = await deps.service.getCashoutById(VALID_INPUT.clientId, 'nonexistent-uuid');

    expect(result).toBeNull();
  });
});
