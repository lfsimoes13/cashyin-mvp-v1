import type { FastifyRequest } from 'fastify';
import Fastify from 'fastify';
import { describe, expect, it, vi } from 'vitest';
import {
  buildResolveAuthContext,
  type AuthPreHandlers
} from '../../src/modules/auth/auth-enforcement.js';
import { registerCashoutRoutes } from '../../src/modules/cashouts/cashout.routes.js';
import {
  CashoutStepUpService,
  canonicalCashoutHash,
  STEP_UP_PROOF_HEADER,
  type CashoutStepUpMode,
  type CashoutStepUpRepository
} from '../../src/modules/cashouts/cashout-step-up.js';
import type { CashoutService } from '../../src/modules/cashouts/cashout.service.js';
import type { CreateCashoutBody } from '../../src/modules/cashouts/cashout.schemas.js';
import { toHttpError } from '../../src/shared/errors/app-error.js';

const BODY: CreateCashoutBody = {
  amount: 10_000,
  pix: { key_type: 'EMAIL', key: 'user@example.com' }
};

describe('canonicalCashoutHash', () => {
  it('is deterministic for the same client + binding fields', () => {
    expect(canonicalCashoutHash('tenant-1', BODY)).toBe(canonicalCashoutHash('tenant-1', BODY));
  });

  it('changes when the amount changes', () => {
    expect(canonicalCashoutHash('tenant-1', BODY)).not.toBe(
      canonicalCashoutHash('tenant-1', { ...BODY, amount: 10_001 })
    );
  });

  it('changes when the destination changes', () => {
    expect(canonicalCashoutHash('tenant-1', BODY)).not.toBe(
      canonicalCashoutHash('tenant-1', { ...BODY, pix: { ...BODY.pix, key: 'other@example.com' } })
    );
  });

  it('is scoped per client', () => {
    expect(canonicalCashoutHash('tenant-1', BODY)).not.toBe(canonicalCashoutHash('tenant-2', BODY));
  });

  it('ignores cosmetic fields (description, receiver.name)', () => {
    expect(
      canonicalCashoutHash('tenant-1', { ...BODY, description: 'lunch', receiver: { name: 'Ana' } })
    ).toBe(canonicalCashoutHash('tenant-1', BODY));
  });
});

function buildService(overrides: Partial<CashoutStepUpRepository> = {}, now = () => 1_000): CashoutStepUpService {
  const repository: CashoutStepUpRepository = {
    insert: async () => ({ id: 'proof-1' }),
    consumeMatching: async () => null,
    findValid: async () => null,
    ...overrides
  };
  return new CashoutStepUpService({ repository, sql: {} as never, ttlMs: 60_000, now });
}

describe('CashoutStepUpService', () => {
  it('issues a proof with the configured TTL', async () => {
    const insert = vi.fn().mockResolvedValue({ id: 'proof-1' });
    const service = buildService({ insert });
    const issued = await service.issue({ clientId: 'tenant-1', transactionHash: 'h', amr: ['otp'] });
    expect(issued.proofId).toBe('proof-1');
    expect(issued.expiresAt).toEqual(new Date(61_000));
    expect(insert).toHaveBeenCalledWith(
      expect.anything(),
      expect.objectContaining({ clientId: 'tenant-1', transactionHash: 'h', amr: ['otp'], expiresAt: new Date(61_000) })
    );
  });

  it('consume maps a matched row to a StepUpProof', async () => {
    const service = buildService({
      consumeMatching: async () => ({
        amr: ['otp'],
        transaction_hash: 'h',
        issued_at: new Date(1_000),
        expires_at: new Date(61_000)
      })
    });
    const proof = await service.consume({ proofId: 'proof-1', clientId: 'tenant-1', transactionHash: 'h' });
    expect(proof).toEqual({ amr: ['otp'], transactionHash: 'h', issuedAt: 1_000, expiresAt: 61_000 });
  });

  it('consume returns null when nothing matched (single-use / mismatch / expiry)', async () => {
    const service = buildService({ consumeMatching: async () => null });
    expect(await service.consume({ proofId: 'x', clientId: 't', transactionHash: 'h' })).toBeNull();
  });

  it('peek is true only when a valid proof has the same hash', async () => {
    const matching = buildService({
      findValid: async () => ({
        amr: [],
        transaction_hash: 'h',
        issued_at: new Date(1_000),
        expires_at: new Date(61_000)
      })
    });
    expect(await matching.peek({ proofId: 'p', clientId: 't', transactionHash: 'h' })).toBe(true);
    expect(await matching.peek({ proofId: 'p', clientId: 't', transactionHash: 'other' })).toBe(false);

    const absent = buildService({ findValid: async () => null });
    expect(await absent.peek({ proofId: 'p', clientId: 't', transactionHash: 'h' })).toBe(false);
  });
});

// ── Route enforcement ──────────────────────────────────────────────────────

const CLIENT_ID = 'tenant-1';

function fakeAuth(channel: 'frontend_bff' | 'api_direct'): AuthPreHandlers {
  return {
    authenticate: async (request: FastifyRequest) => {
      request.authPrincipal = {
        channel,
        principalType: channel === 'frontend_bff' ? 'user' : 'api_client',
        principalId: 'p',
        clientId: CLIENT_ID,
        scopes: [],
        credentialId: 'cred',
        ...(channel === 'frontend_bff' ? { actorUserId: 'user-1' } : {})
      };
      request.client = { clientId: CLIENT_ID, apiKeyId: 'k', keyPrefix: 'kp', label: null, scopes: [] };
    },
    resolveAuthContext: buildResolveAuthContext(),
    requireScope: () => async () => undefined
  };
}

function fakeCashoutService() {
  const createCashoutWithDisposition = vi.fn().mockResolvedValue({
    cashout: {
      id: 'co-1',
      externalRef: null,
      status: 'processing',
      amountCents: 10_000,
      currency: 'BRL',
      pixKey: 'user@example.com',
      pixKeyType: 'EMAIL',
      createdAt: new Date('2026-01-01T00:00:00.000Z')
    },
    replayed: false
  });
  return { createCashoutWithDisposition } as unknown as CashoutService & {
    createCashoutWithDisposition: ReturnType<typeof vi.fn>;
  };
}

async function buildApp(
  mode: CashoutStepUpMode,
  channel: 'frontend_bff' | 'api_direct',
  stepUpOverrides: Partial<CashoutStepUpRepository> = {}
) {
  const app = Fastify();
  app.setErrorHandler((error, _request, reply) => {
    const httpError = toHttpError(error);
    void reply.status(httpError.statusCode).send({ error: { code: httpError.code, details: (error as { details?: unknown }).details } });
  });
  const cashoutService = fakeCashoutService();
  const service = buildService(stepUpOverrides);
  const issueSpy = vi.spyOn(service, 'issue');
  await registerCashoutRoutes(app, {
    cashoutService,
    auth: fakeAuth(channel),
    stepUp: { mode, service }
  });
  return { app, cashoutService, service, issueSpy };
}

function createCashout(app: Awaited<ReturnType<typeof buildApp>>['app'], proofId?: string) {
  return app.inject({
    method: 'POST',
    url: '/v1/pix/cash-out',
    headers: {
      'idempotency-key': 'idem-1',
      ...(proofId ? { [STEP_UP_PROOF_HEADER]: proofId } : {})
    },
    payload: BODY
  });
}

describe('cash-out step-up enforcement', () => {
  it('enforce + frontend_bff + no proof ⇒ 403 and never creates the cash-out', async () => {
    const { app, cashoutService } = await buildApp('enforce', 'frontend_bff');
    const res = await createCashout(app);
    expect(res.statusCode).toBe(403);
    expect(res.json<{ error: { code: string } }>().error.code).toBe('auth_step_up_required');
    expect(cashoutService.createCashoutWithDisposition).not.toHaveBeenCalled();
    await app.close();
  });

  it('enforce + frontend_bff + invalid proof ⇒ 403 (consume returned null)', async () => {
    const { app, cashoutService } = await buildApp('enforce', 'frontend_bff', {
      consumeMatching: async () => null
    });
    const res = await createCashout(app, 'proof-x');
    expect(res.statusCode).toBe(403);
    expect(cashoutService.createCashoutWithDisposition).not.toHaveBeenCalled();
    await app.close();
  });

  it('enforce + frontend_bff + valid proof ⇒ 201 and creates the cash-out', async () => {
    const { app, cashoutService } = await buildApp('enforce', 'frontend_bff', {
      consumeMatching: async () => ({
        amr: ['otp'],
        transaction_hash: canonicalCashoutHash(CLIENT_ID, BODY),
        issued_at: new Date(1_000),
        expires_at: new Date(61_000)
      })
    });
    const res = await createCashout(app, 'proof-ok');
    expect(res.statusCode).toBe(201);
    expect(cashoutService.createCashoutWithDisposition).toHaveBeenCalledTimes(1);
    await app.close();
  });

  it('enforce + api_direct ⇒ exempt, 201 without any proof', async () => {
    const { app, cashoutService } = await buildApp('enforce', 'api_direct');
    const res = await createCashout(app);
    expect(res.statusCode).toBe(201);
    expect(cashoutService.createCashoutWithDisposition).toHaveBeenCalledTimes(1);
    await app.close();
  });

  it('off ⇒ inert, 201 even for frontend_bff without proof', async () => {
    const { app, cashoutService } = await buildApp('off', 'frontend_bff');
    const res = await createCashout(app);
    expect(res.statusCode).toBe(201);
    expect(cashoutService.createCashoutWithDisposition).toHaveBeenCalledTimes(1);
    await app.close();
  });

  it('shadow ⇒ never blocks, creates the cash-out even without a proof', async () => {
    const { app, cashoutService } = await buildApp('shadow', 'frontend_bff');
    const res = await createCashout(app);
    expect(res.statusCode).toBe(201);
    expect(cashoutService.createCashoutWithDisposition).toHaveBeenCalledTimes(1);
    await app.close();
  });
});

describe('POST /v1/pix/cash-out/step-up', () => {
  it('issues a proof bound to the canonical hash of the request', async () => {
    const { app, issueSpy } = await buildApp('enforce', 'frontend_bff');
    const res = await app.inject({ method: 'POST', url: '/v1/pix/cash-out/step-up', payload: BODY });
    expect(res.statusCode).toBe(201);
    expect(res.json<{ proof_id: string }>().proof_id).toBe('proof-1');
    expect(issueSpy).toHaveBeenCalledWith(
      expect.objectContaining({
        clientId: CLIENT_ID,
        actorUserId: 'user-1',
        transactionHash: canonicalCashoutHash(CLIENT_ID, BODY)
      })
    );
    await app.close();
  });

  it('rejects an invalid payload with 422', async () => {
    const { app } = await buildApp('enforce', 'frontend_bff');
    const res = await app.inject({ method: 'POST', url: '/v1/pix/cash-out/step-up', payload: { amount: -1 } });
    expect(res.statusCode).toBe(422);
    await app.close();
  });
});
