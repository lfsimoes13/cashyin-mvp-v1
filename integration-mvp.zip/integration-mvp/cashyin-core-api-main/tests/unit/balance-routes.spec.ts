import { createHash } from 'node:crypto';
import Fastify from 'fastify';
import { describe, expect, it } from 'vitest';
import { registerBalanceRoutes } from '../../src/modules/balances/balance.routes.js';
import { buildAuthPreHandlers, type AuthEnforcementMode } from '../../src/modules/auth/auth-enforcement.js';
import {
  API_KEY_PREFIX,
  ClientApiKeyService,
  type ClientApiKeyRepository
} from '../../src/modules/auth/client-api-key.service.js';
import type { ClientBalanceService } from '../../src/modules/balances/client-balance.service.js';
import { AUTH_SCOPES } from '../../src/shared/auth/auth-scopes.js';
import { toHttpError } from '../../src/shared/errors/app-error.js';

const TAIL = '00112233445566778899aabbccddeeff00112233445566778899aabbccddeeff';
const RAW_KEY = `${API_KEY_PREFIX}${TAIL}`;
const HASH = createHash('sha256').update(RAW_KEY).digest('hex');

function repoForKey(scopes: readonly string[]): ClientApiKeyRepository {
  return {
    findActiveByPrefix: async (_sql, prefix) =>
      prefix === TAIL.slice(0, 8)
        ? [
            {
              id: 'key-1',
              client_id: 'client-1',
              key_prefix: TAIL.slice(0, 8),
              key_hash: HASH,
              label: null,
              scopes: scopes as string[],
              expires_at: null
            }
          ]
        : [],
    findById: async () => null,
    listByClient: async () => [],
    insert: async () => ({ id: 'unused' }),
    touchLastUsed: async () => undefined,
    revoke: async () => undefined
  };
}

const fakeBalanceService = {
  getPublicBalance: async (clientId: string) => ({
    client_id: clientId,
    available_balance: 1000,
    blocked_balance: 0,
    total_balance: 1000,
    currency: 'BRL',
    updated_at: '2026-01-01T00:00:00.000Z'
  })
} as unknown as ClientBalanceService;

function buildApp(mode: AuthEnforcementMode, scopes: readonly string[]) {
  const app = Fastify();
  app.setErrorHandler((error, _request, reply) => {
    const httpError = toHttpError(error);
    void reply.status(httpError.statusCode).send({ error: { code: httpError.code } });
  });
  const service = new ClientApiKeyService({ repository: repoForKey(scopes), sql: {} as never });
  const auth = buildAuthPreHandlers({ mode, clientApiKeyService: service, bffMode: 'off' });
  void registerBalanceRoutes(app, { clientBalanceService: fakeBalanceService, auth });
  return app;
}

function call(app: ReturnType<typeof buildApp>) {
  return app.inject({ method: 'GET', url: '/v1/balance', headers: { authorization: `Bearer ${RAW_KEY}` } });
}

describe('GET /v1/balance scope guard (D5)', () => {
  it('enforce: allows with balance:read', async () => {
    const app = buildApp('enforce', [AUTH_SCOPES.BALANCE_READ]);
    const res = await call(app);
    expect(res.statusCode).toBe(200);
    expect(res.json<{ currency: string }>().currency).toBe('BRL');
    await app.close();
  });

  it('enforce: denies (403) without balance:read', async () => {
    const app = buildApp('enforce', [AUTH_SCOPES.PIX_CASH_IN_READ]);
    const res = await call(app);
    expect(res.statusCode).toBe(403);
    expect(res.json()).toEqual({ error: { code: 'auth_insufficient_scope' } });
    await app.close();
  });

  it('off: allows even without balance:read (scope layer inert)', async () => {
    const app = buildApp('off', [AUTH_SCOPES.PIX_CASH_IN_READ]);
    const res = await call(app);
    expect(res.statusCode).toBe(200);
    await app.close();
  });

  it('enforce: rejects an unauthenticated request (401)', async () => {
    const app = buildApp('enforce', [AUTH_SCOPES.BALANCE_READ]);
    const res = await app.inject({ method: 'GET', url: '/v1/balance' });
    expect(res.statusCode).toBe(401);
    await app.close();
  });
});
