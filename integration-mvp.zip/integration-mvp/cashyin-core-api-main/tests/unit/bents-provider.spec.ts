import { describe, expect, it, vi } from 'vitest';
import { BentsProvider } from '../../src/providers/bents/bents.provider.js';
import {
  buildBentsRequestUrl,
  type BentsClient
} from '../../src/providers/bents/bents.client.js';

describe('buildBentsRequestUrl', () => {
  it('preserves the /api/v2/public path on the base URL when the endpoint starts with /', () => {
    // Regression guard: `new URL('/pix/charge', 'https://host/api/v2/public')`
    // collapses to `https://host/pix/charge`. Bents 405s in that case.
    expect(buildBentsRequestUrl('https://finance.bents.com.br/api/v2/public', '/pix/charge')).toBe(
      'https://finance.bents.com.br/api/v2/public/pix/charge'
    );
  });

  it('tolerates a trailing slash on the base URL', () => {
    expect(buildBentsRequestUrl('https://host/api/v2/public/', '/balance')).toBe(
      'https://host/api/v2/public/balance'
    );
  });

  it('inserts the missing slash when the endpoint does not lead with one', () => {
    expect(buildBentsRequestUrl('https://host/api/v2/public', 'pix/charge')).toBe(
      'https://host/api/v2/public/pix/charge'
    );
  });

  it('passes through the dynamic charge UUID segment unchanged', () => {
    expect(
      buildBentsRequestUrl(
        'https://host/api/v2/public',
        '/pix/charge/01234567-89ab-cdef-0123-456789abcdef'
      )
    ).toBe('https://host/api/v2/public/pix/charge/01234567-89ab-cdef-0123-456789abcdef');
  });
});

type Captured = { method: string; path: string; body: unknown };

function buildClient(stub: (capture: Captured) => unknown): BentsClient {
  const request = vi.fn(async (method: string, path: string, body?: unknown) => {
    return stub({ method, path, body });
  });
  return { request } as unknown as BentsClient;
}

describe('BentsProvider.createPixCharge body shape', () => {
  it('sends only amount_cents and description; no txid/external_ref/idempotency_key', async () => {
    let captured: Captured | null = null;
    const client = buildClient((c) => {
      captured = c;
      return {
        charge_uuid: 'ch_1',
        status: 'pending',
        amount_cents: 1500,
        txid: 'tx_bents_generated',
        pix_copia_e_cola: 'br-code',
        expires_at: '2026-05-22T12:00:00.000Z',
        qr_code: { png_base64: 'iVBORw0KGgo' }
      };
    });
    const provider = new BentsProvider(client);

    const result = await provider.createPixCharge({
      idempotency_key: 'idem-1',
      client_id: 'c-1',
      external_ref: 'ext-1',
      amount: 1500,
      description: 'Order #42',
      txid: 'should-be-dropped'
    });

    expect(captured).not.toBeNull();
    expect(captured!.method).toBe('POST');
    expect(captured!.path).toBe('/pix/charge');
    expect(captured!.body).toEqual({
      amount_cents: 1500,
      description: 'Order #42'
    });
    // Bents-returned txid is mapped to provider_tx_id (internal); no public txid here
    expect(result.provider_tx_id).toBe('tx_bents_generated');
    expect(result.provider_charge_id).toBe('ch_1');
  });

  it('omits description when not provided', async () => {
    let captured: Captured | null = null;
    const client = buildClient((c) => {
      captured = c;
      return {
        charge_uuid: 'ch_2',
        status: 'pending',
        amount_cents: 100,
        txid: 'tx_2'
      };
    });
    const provider = new BentsProvider(client);

    await provider.createPixCharge({
      idempotency_key: 'idem-2',
      client_id: 'c-1',
      external_ref: 'ext-2',
      amount: 100
    });

    expect(captured!.body).toEqual({ amount_cents: 100 });
  });
});

describe('BentsProvider.createPixPayment body shape', () => {
  it('forwards amount_cents, pix_key, pix_key_type, receiver identity and description', async () => {
    let captured: Captured | null = null;
    const client = buildClient((c) => {
      captured = c;
      return {
        transaction_id: 'pay_1',
        status: 'processing',
        e2e_id: 'E2E123',
        fee_amount_cents: 50
      };
    });
    const provider = new BentsProvider(client);

    await provider.createPixPayment({
      idempotencyKey: 'idem-3',
      clientId: 'c-1',
      externalId: 'ext-3',
      amountCents: 2500,
      pixKey: 'owner@example.test',
      pixKeyType: 'EMAIL',
      receiverName: 'Owner Example',
      receiverDocument: '12345678901',
      description: 'Withdrawal'
    });

    expect(captured!.method).toBe('POST');
    expect(captured!.path).toBe('/pix/payment');
    expect(captured!.body).toEqual({
      amount_cents: 2500,
      pix_key: 'owner@example.test',
      pix_key_type: 'EMAIL',
      receiver_name: 'Owner Example',
      receiver_document: '12345678901',
      description: 'Withdrawal'
    });
  });

  it('omits optional fields when not provided', async () => {
    let captured: Captured | null = null;
    const client = buildClient((c) => {
      captured = c;
      return {
        transaction_id: 'pay_2',
        status: 'processing'
      };
    });
    const provider = new BentsProvider(client);

    await provider.createPixPayment({
      idempotencyKey: 'idem-4',
      clientId: 'c-1',
      externalId: 'ext-4',
      amountCents: 1000,
      pixKey: 'owner@example.test',
      pixKeyType: 'EVP'
    });

    expect(captured!.body).toEqual({
      amount_cents: 1000,
      pix_key: 'owner@example.test',
      pix_key_type: 'EVP'
    });
  });
});
