import { describe, expect, it } from 'vitest';
import {
  categoriseHttpStatus,
  classifyProviderHttpFailure,
  classifyProviderNetworkError,
  ProviderError
} from '../../src/providers/contracts/provider-errors.js';

describe('categoriseHttpStatus', () => {
  it.each([
    [400, 'definite_client_error'],
    [401, 'definite_client_error'],
    [403, 'definite_client_error'],
    [404, 'definite_client_error'],
    [409, 'definite_client_error'],
    [422, 'definite_client_error']
  ])('treats %i as definite_client_error', (status, expected) => {
    expect(categoriseHttpStatus(status)).toBe(expected);
  });

  it.each([
    [408, 'ambiguous_server_status'],
    [425, 'ambiguous_server_status'],
    [429, 'ambiguous_server_status']
  ])('treats %i as ambiguous (retryable client status)', (status, expected) => {
    expect(categoriseHttpStatus(status)).toBe(expected);
  });

  it.each([
    [500, 'ambiguous_server_status'],
    [502, 'ambiguous_server_status'],
    [503, 'ambiguous_server_status'],
    [504, 'ambiguous_server_status']
  ])('treats %i as ambiguous server status', (status, expected) => {
    expect(categoriseHttpStatus(status)).toBe(expected);
  });
});

describe('classifyProviderHttpFailure', () => {
  it('returns ProviderError with category and provider context', () => {
    const error = classifyProviderHttpFailure('bents', 422, { message: 'bad' });
    expect(error).toBeInstanceOf(ProviderError);
    expect(error.category).toBe('definite_client_error');
    expect(error.statusCode).toBe(502);
    expect(error.isDefinite).toBe(true);
    expect(error.details).toMatchObject({
      providerName: 'bents',
      providerStatusCode: 422,
      body: { message: 'bad' }
    });
  });

  it('marks 5xx as not definite', () => {
    const error = classifyProviderHttpFailure('bents', 503, null);
    expect(error.category).toBe('ambiguous_server_status');
    expect(error.isDefinite).toBe(false);
  });

  it('marks 429 as not definite', () => {
    const error = classifyProviderHttpFailure('bents', 429, null);
    expect(error.category).toBe('ambiguous_server_status');
    expect(error.isDefinite).toBe(false);
  });
});

describe('classifyProviderNetworkError', () => {
  it.each([
    'UND_ERR_HEADERS_TIMEOUT',
    'UND_ERR_BODY_TIMEOUT',
    'UND_ERR_CONNECT_TIMEOUT',
    'ETIMEDOUT'
  ])('classifies %s as ambiguous_timeout', (code) => {
    const networkError = Object.assign(new Error('boom'), { code });
    const error = classifyProviderNetworkError('bents', networkError);
    expect(error.category).toBe('ambiguous_timeout');
    expect(error.isDefinite).toBe(false);
    expect(error.code).toBe('provider_timeout');
    expect(error.statusCode).toBe(504);
  });

  it.each([
    'UND_ERR_ABORTED',
    'UND_ERR_SOCKET',
    'UND_ERR_CLOSED',
    'ECONNRESET',
    'ECONNREFUSED',
    'EPIPE',
    'ENETUNREACH',
    'EAI_AGAIN'
  ])('classifies %s as ambiguous_network', (code) => {
    const networkError = Object.assign(new Error('boom'), { code });
    const error = classifyProviderNetworkError('bents', networkError);
    expect(error.category).toBe('ambiguous_network');
    expect(error.isDefinite).toBe(false);
    expect(error.code).toBe('provider_network_error');
    expect(error.statusCode).toBe(502);
  });

  it('treats unknown errors as ambiguous (category=unknown)', () => {
    const error = classifyProviderNetworkError('bents', new Error('mystery'));
    expect(error.category).toBe('unknown');
    expect(error.isDefinite).toBe(false);
  });

  it('reads `code` from error.cause when not on top-level error', () => {
    const cause = Object.assign(new Error('inner'), { code: 'ECONNRESET' });
    const wrapped = Object.assign(new Error('outer'), { cause });
    const error = classifyProviderNetworkError('bents', wrapped);
    expect(error.category).toBe('ambiguous_network');
  });
});
