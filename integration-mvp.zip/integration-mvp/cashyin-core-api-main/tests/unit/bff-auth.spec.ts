import { createHash } from 'node:crypto';
import Fastify from 'fastify';
import { describe, expect, it } from 'vitest';
import { buildAuthPreHandlers } from '../../src/modules/auth/auth-enforcement.js';
import {
  BFF_ACTOR_USER_HEADER,
  BFF_CLIENT_HEADER,
  BFF_TOKEN_HEADER,
  DEFAULT_BFF_SCOPES
} from '../../src/modules/auth/authenticate.js';
import {
  API_KEY_PREFIX,
  ClientApiKeyService,
  type ClientApiKeyRepository
} from '../../src/modules/auth/client-api-key.service.js';
import { toHttpError } from '../../src/shared/errors/app-error.js';

const BFF_SECRET = 'bff-shared-secret-value-0123456789abcd';

const BEARER_TAIL = '00112233445566778899aabbccddeeff00112233445566778899aabbccddeeff';
const BEARER_RAW = `${API_KEY_PREFIX}${BEARER_TAIL}`;
const BEARER_HASH = createHash('sha256').update(BEARER_RAW).digest('hex');

function repoWithBearerKey(): ClientApiKeyRepository {
  return {
    findActiveByPrefix: async (_sql, prefix) =>
      prefix === BEARER_TAIL.slice(0, 8)
        ? [
            {
              id: 'key-row-1',
              client_id: 'bearer-client',
              key_prefix: BEARER_TAIL.slice(0, 8),
              key_hash: BEARER_HASH,
              label: null,
              scopes: ['pix:cash_in:create'],
              expires_at: null
            }
          ]
        : [],
    findById: async () => null,
    listByClient: async () => [],
    insert: async () => ({ id: 'unused' }),
    touchLastUsed: async () => undefined,
    revoke: async () => undefined
  };
}

function buildApp(bffMode: 'off' | 'enforce') {
  const app = Fastify();
  app.setErrorHandler((error, _request, reply) => {
    const httpError = toHttpError(error);
    void reply.status(httpError.statusCode).send({ error: { code: httpError.code } });
  });
  const service = new ClientApiKeyService({ repository: repoWithBearerKey(), sql: {} as never });
  const auth = buildAuthPreHandlers({
    mode: 'shadow',
    clientApiKeyService: service,
    bffMode,
    bffSecret: BFF_SECRET
  });
  app.post('/v1/pix/cash-in/qrcode', { preHandler: [auth.authenticate, auth.resolveAuthContext] }, async (request) => ({
    channel: request.authContext?.channel ?? null,
    clientId: request.authContext?.clientId ?? null,
    actorUserId: request.authContext?.actorUserId ?? null,
    scopes: request.authContext?.scopes ?? null
  }));
  return app;
}

type Body = {
  channel: string | null;
  clientId: string | null;
  actorUserId: string | null;
  scopes: string[] | null;
};

describe('BFF trusted channel', () => {
  it('authenticates a valid BFF call and represents the actor + tenant', async () => {
    const app = buildApp('enforce');
    const res = await app.inject({
      method: 'POST',
      url: '/v1/pix/cash-in/qrcode',
      headers: {
        [BFF_TOKEN_HEADER]: BFF_SECRET,
        [BFF_ACTOR_USER_HEADER]: 'user-42',
        [BFF_CLIENT_HEADER]: 'tenant-7'
      }
    });
    expect(res.statusCode).toBe(200);
    const body = res.json<Body>();
    expect(body.channel).toBe('frontend_bff');
    expect(body.clientId).toBe('tenant-7');
    expect(body.actorUserId).toBe('user-42');
    expect(body.scopes).toEqual(DEFAULT_BFF_SCOPES);
    await app.close();
  });

  it('rejects a wrong BFF token (401) without falling back to Bearer', async () => {
    const app = buildApp('enforce');
    const res = await app.inject({
      method: 'POST',
      url: '/v1/pix/cash-in/qrcode',
      headers: {
        [BFF_TOKEN_HEADER]: 'not-the-secret-but-same-length-padxxxxx',
        [BFF_ACTOR_USER_HEADER]: 'user-42',
        [BFF_CLIENT_HEADER]: 'tenant-7'
      }
    });
    expect(res.statusCode).toBe(401);
    expect(res.json()).toEqual({ error: { code: 'auth_invalid' } });
    await app.close();
  });

  it('rejects a BFF call missing the actor header (401)', async () => {
    const app = buildApp('enforce');
    const res = await app.inject({
      method: 'POST',
      url: '/v1/pix/cash-in/qrcode',
      headers: { [BFF_TOKEN_HEADER]: BFF_SECRET, [BFF_CLIENT_HEADER]: 'tenant-7' }
    });
    expect(res.statusCode).toBe(401);
    await app.close();
  });

  it('rejects a BFF call missing the client header (401)', async () => {
    const app = buildApp('enforce');
    const res = await app.inject({
      method: 'POST',
      url: '/v1/pix/cash-in/qrcode',
      headers: { [BFF_TOKEN_HEADER]: BFF_SECRET, [BFF_ACTOR_USER_HEADER]: 'user-42' }
    });
    expect(res.statusCode).toBe(401);
    await app.close();
  });

  it('falls through to the Bearer (api_direct) channel when no BFF token is present', async () => {
    const app = buildApp('enforce');
    const res = await app.inject({
      method: 'POST',
      url: '/v1/pix/cash-in/qrcode',
      headers: { authorization: `Bearer ${BEARER_RAW}` }
    });
    expect(res.statusCode).toBe(200);
    const body = res.json<Body>();
    expect(body.channel).toBe('api_direct');
    expect(body.clientId).toBe('bearer-client');
    await app.close();
  });

  it('ignores the BFF token entirely when BFF_AUTH_MODE=off (requires Bearer)', async () => {
    const app = buildApp('off');
    const res = await app.inject({
      method: 'POST',
      url: '/v1/pix/cash-in/qrcode',
      headers: {
        [BFF_TOKEN_HEADER]: BFF_SECRET,
        [BFF_ACTOR_USER_HEADER]: 'user-42',
        [BFF_CLIENT_HEADER]: 'tenant-7'
      }
    });
    // No Bearer credential ⇒ the Bearer path rejects with 401.
    expect(res.statusCode).toBe(401);
    await app.close();
  });
});
