import { describe, expect, it } from 'vitest';
import {
  PUBLIC_WEBHOOK_CURRENCY,
  buildCashInWebhookEnvelope,
  buildCashOutWebhookEnvelope,
  formatAmountFromCents
} from '../../src/modules/transactions/payload-builder.js';

const CREATED = new Date('2026-03-15T14:28:00.000Z');
const PAID = new Date('2026-03-15T14:30:00.000Z');
const EMITTED = new Date('2026-03-15T14:30:00.250Z');

describe('formatAmountFromCents', () => {
  it('formats integer reais with exactly two decimals', () => {
    expect(formatAmountFromCents(15000)).toBe('150.00');
  });

  it('formats sub-real values with zero padding', () => {
    expect(formatAmountFromCents(99)).toBe('0.99');
    expect(formatAmountFromCents(1)).toBe('0.01');
    expect(formatAmountFromCents(10)).toBe('0.10');
  });

  it('formats zero as 0.00', () => {
    expect(formatAmountFromCents(0)).toBe('0.00');
  });

  it('throws TypeError on non-integer input', () => {
    expect(() => formatAmountFromCents(150.5)).toThrow(TypeError);
  });

  it('throws RangeError on negative input', () => {
    expect(() => formatAmountFromCents(-1)).toThrow(RangeError);
  });
});

describe('buildCashInWebhookEnvelope', () => {
  const baseInput = {
    eventId: 'evt_01HZY6Z9W4R2F9A8EMN2A4S7QK',
    txid: 'tx_abc123',
    externalRef: 'order-12345',
    amount: 15000,
    emittedAt: EMITTED,
    createdAt: CREATED,
    emv: null,
    description: null,
    expiresAt: null,
    paidAt: null,
    e2eId: null,
    payer: null
  } as const;

  it('emits `pix.cash_in.paid` with `paid_at`, `pix.e2e_id` and a nested payer block', () => {
    const env = buildCashInWebhookEnvelope({
      ...baseInput,
      status: 'paid',
      paidAt: PAID,
      e2eId: 'E2E_CASH_IN_1',
      payer: {
        name: 'John Doe',
        documentNumber: '123.456.789-00',
        bank: 'Banco do Brasil',
        ispb: '00000000',
        branch: '0001',
        account: '12345-6',
        accountType: null
      }
    });
    expect(env.event).toBe('pix.cash_in.paid');
    expect(env.data.status).toBe('paid');
    expect(env.data.paid_at).toBe(PAID.toISOString());
    expect(env.data.pix.e2e_id).toBe('E2E_CASH_IN_1');
    expect(env.data.payer).toEqual({
      name: 'John Doe',
      document_number: '123.456.789-00',
      bank_name: 'Banco do Brasil',
      bank_ispb: '00000000',
      branch: '0001',
      account: '12345-6',
      account_type: null
    });
  });

  it('emits `pix.cash_in.expired` with status `expired`', () => {
    const env = buildCashInWebhookEnvelope({ ...baseInput, status: 'expired' });
    expect(env.event).toBe('pix.cash_in.expired');
    expect(env.data.status).toBe('expired');
    expect(env.data.paid_at).toBeUndefined();
  });

  it('emits `pix.cash_in.cancelled` with status `cancelled`', () => {
    const env = buildCashInWebhookEnvelope({ ...baseInput, status: 'cancelled' });
    expect(env.event).toBe('pix.cash_in.cancelled');
    expect(env.data.status).toBe('cancelled');
  });

  it('emits `pix.cash_in.failed` with status `failed`', () => {
    const env = buildCashInWebhookEnvelope({ ...baseInput, status: 'failed' });
    expect(env.event).toBe('pix.cash_in.failed');
    expect(env.data.status).toBe('failed');
  });

  it('emits `pix.cash_in.refunded` with status `refunded` and null paid_at', () => {
    const env = buildCashInWebhookEnvelope({ ...baseInput, status: 'refunded' });
    expect(env.event).toBe('pix.cash_in.refunded');
    expect(env.data.status).toBe('refunded');
    expect(env.data.paid_at).toBeUndefined();
  });

  it('rejects an amount that is not an integer', () => {
    expect(() =>
      buildCashInWebhookEnvelope({ ...baseInput, status: 'pending', amount: 150.5 })
    ).toThrow(TypeError);
  });

  it('rejects a negative amount', () => {
    expect(() =>
      buildCashInWebhookEnvelope({ ...baseInput, status: 'pending', amount: -1 })
    ).toThrow(RangeError);
  });

  it('rejects an eventId missing the `evt_` prefix', () => {
    expect(() =>
      buildCashInWebhookEnvelope({ ...baseInput, status: 'pending', eventId: 'abc' })
    ).toThrow(TypeError);
  });

  it('rejects an eventId of just `evt_` with no suffix', () => {
    expect(() =>
      buildCashInWebhookEnvelope({ ...baseInput, status: 'pending', eventId: 'evt_' })
    ).toThrow(TypeError);
  });

  it('rejects an empty txid', () => {
    expect(() =>
      buildCashInWebhookEnvelope({ ...baseInput, status: 'pending', txid: '' })
    ).toThrow(TypeError);
  });

  it('omits null timestamps/e2e_id/payer; emv is null under pix when absent', () => {
    const env = buildCashInWebhookEnvelope({ ...baseInput, status: 'pending' });
    expect(env.data.pix.emv).toBeNull();
    expect(env.data.pix).not.toHaveProperty('expires_at');
    expect(env.data.pix).not.toHaveProperty('e2e_id');
    expect(env.data).not.toHaveProperty('paid_at');
    expect(env.data).not.toHaveProperty('payer');
    expect(env.data).not.toHaveProperty('qr_code');
    expect(env.data).not.toHaveProperty('qr_code_image');
    expect(env.data.description).toBeNull();
  });

  it('carries emv, description and expires_at under pix when provided', () => {
    const env = buildCashInWebhookEnvelope({
      ...baseInput,
      status: 'pending',
      emv: 'br-code-string',
      description: 'Cobrança teste',
      expiresAt: new Date('2026-03-16T14:28:00.000Z')
    });
    expect(env.data.pix.emv).toBe('br-code-string');
    expect(env.data.description).toBe('Cobrança teste');
    expect(env.data.pix.expires_at).toBe('2026-03-16T14:28:00.000Z');
  });

  it('produces deterministic output for the same input (idempotency for retries)', () => {
    const first = buildCashInWebhookEnvelope({ ...baseInput, status: 'pending' });
    const second = buildCashInWebhookEnvelope({ ...baseInput, status: 'pending' });
    expect(first).toEqual(second);
  });
});

describe('buildCashOutWebhookEnvelope', () => {
  const baseInput = {
    eventId: 'evt_CASHOUT_01',
    transactionId: 'txo_xyz789',
    externalRef: 'payout-9876',
    amount: 27345,
    pixKey: 'alice@example.com',
    pixKeyType: 'EMAIL',
    emittedAt: EMITTED,
    timestamps: { createdAt: CREATED }
  } as const;

  it('emits `pix.cash_out.processing` for the initial Cash-Out status', () => {
    const env = buildCashOutWebhookEnvelope({ ...baseInput, status: 'processing' });
    expect(env.event).toBe('pix.cash_out.processing');
    expect(env.data).not.toHaveProperty('type');
    expect(env.data.status).toBe('processing');
    expect(env.data.amount).toBe(27345);
    expect(env.data).not.toHaveProperty('amount_cents');
    expect(env.data.external_ref).toBe('payout-9876');
    expect(env.data.pix.key).toBe('alice@example.com');
    // `pix.key_type` echoes the request value (uppercase) on every event.
    expect(env.data.pix.key_type).toBe('EMAIL');
    expect(env.data).not.toHaveProperty('pix_key');
    expect(env.data).not.toHaveProperty('pix_key_type');
    expect(env.data.currency).toBe(PUBLIC_WEBHOOK_CURRENCY);
    // `failure_reason` is reserved for non-success terminals.
    expect(env.data).not.toHaveProperty('failure_reason');
  });

  it('emits `pix.cash_out.completed` with `completed_at` and `pix.e2e_id`', () => {
    const env = buildCashOutWebhookEnvelope({
      ...baseInput,
      status: 'completed',
      timestamps: { createdAt: CREATED, completedAt: PAID },
      counterparty: { e2eId: 'E2E_OUT_1' }
    });
    expect(env.event).toBe('pix.cash_out.completed');
    expect(env.data.completed_at).toBe(PAID.toISOString());
    expect(env.data.pix.e2e_id).toBe('E2E_OUT_1');
  });

  it('emits `pix.cash_out.returned` with `returned_at`', () => {
    const env = buildCashOutWebhookEnvelope({
      ...baseInput,
      status: 'returned',
      timestamps: { createdAt: CREATED, returnedAt: PAID }
    });
    expect(env.event).toBe('pix.cash_out.returned');
    expect(env.data.returned_at).toBe(PAID.toISOString());
  });

  it('emits `pix.cash_out.failed` with `failed_at`, `pix_key_type` and `failure_reason`', () => {
    const env = buildCashOutWebhookEnvelope({
      ...baseInput,
      status: 'failed',
      timestamps: { createdAt: CREATED, failedAt: PAID },
      failureReason: 'provider_rejected'
    });
    expect(env.event).toBe('pix.cash_out.failed');
    expect(env.data.failed_at).toBe(PAID.toISOString());
    expect(env.data.pix.key_type).toBe('EMAIL');
    expect(env.data.failure_reason).toBe('provider_rejected');
  });

  it('emits the nested receiver block (document_number) with no flat mirrors', () => {
    const env = buildCashOutWebhookEnvelope({
      ...baseInput,
      status: 'completed',
      timestamps: { createdAt: CREATED, completedAt: PAID },
      receiver: {
        name: 'Alice Souza',
        document: '12345678901',
        bank: 'A55 SCD S.A.',
        ispb: '48756121',
        branch: null,
        account: null,
        accountType: null
      }
    });
    // Canonical nested receiver (always present, nullable children).
    expect(env.data.receiver).toEqual({
      name: 'Alice Souza',
      document_number: '12345678901',
      bank_name: 'A55 SCD S.A.',
      bank_ispb: '48756121',
      branch: null,
      account: null,
      account_type: null
    });
    // Receiver identity is exposed only via the nested `receiver` object —
    // there are no flat `receiver_name`/`receiver_document` mirrors.
    expect(env.data).not.toHaveProperty('receiver_name');
    expect(env.data).not.toHaveProperty('receiver_document');
  });

  it('always includes a receiver object with null children when none supplied', () => {
    const env = buildCashOutWebhookEnvelope({ ...baseInput, status: 'processing' });
    expect(env.data.receiver).toEqual({
      name: null,
      document_number: null,
      bank_name: null,
      bank_ispb: null,
      branch: null,
      account: null,
      account_type: null
    });
    expect(env.data).not.toHaveProperty('receiver_name');
    expect(env.data).not.toHaveProperty('receiver_document');
  });

  it('emits a null `external_ref` when none was supplied', () => {
    const env = buildCashOutWebhookEnvelope({
      ...baseInput,
      externalRef: null,
      status: 'processing'
    });
    expect(env.data.external_ref).toBeNull();
  });

  it('rejects an empty pixKey', () => {
    expect(() =>
      buildCashOutWebhookEnvelope({ ...baseInput, status: 'processing', pixKey: '' })
    ).toThrow(TypeError);
  });

  it('does not surface Cash-In-only fields on Cash-Out envelopes', () => {
    const env = buildCashOutWebhookEnvelope({ ...baseInput, status: 'processing' });
    expect(env.data).not.toHaveProperty('payer_name');
    expect(env.data).not.toHaveProperty('payer_document');
    expect(env.data).not.toHaveProperty('paid_at');
    expect(env.data).not.toHaveProperty('expired_at');
    expect(env.data).not.toHaveProperty('cancelled_at');
    expect(env.data).not.toHaveProperty('expires_at');
  });

  it('produces deterministic output for the same input', () => {
    const first = buildCashOutWebhookEnvelope({ ...baseInput, status: 'processing' });
    const second = buildCashOutWebhookEnvelope({ ...baseInput, status: 'processing' });
    expect(first).toEqual(second);
  });

  it('rejects non-integer amounts', () => {
    expect(() =>
      buildCashOutWebhookEnvelope({ ...baseInput, status: 'processing', amount: 0.5 })
    ).toThrow(TypeError);
  });
});
