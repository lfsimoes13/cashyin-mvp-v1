import { describe, expect, it, vi } from 'vitest';
import { ClientConfigService } from '../../src/modules/admin/client-config.service.js';
import type { PricingRuleRecord, PricingRuleRepository } from '../../src/modules/pricing/pricing-rule.repository.js';
import type { ProviderAssignment, ProviderAssignmentRepository } from '../../src/modules/providers/provider-assignment.repository.js';
import type { Sql } from '../../src/shared/db/sql.js';

const SQL = {} as Sql;
const CLIENT_ID = 'tenant-1';

function rule(overrides: Partial<PricingRuleRecord> = {}): PricingRuleRecord {
  return {
    id: 'rule-1',
    pricingPlanVersionId: 'ppv-1',
    operationType: 'cash_in',
    triggerEvent: 'cash_in_paid',
    fixedFeeCents: 15,
    variableFeeBps: 0,
    minFeeCents: null,
    maxFeeCents: null,
    billingMode: 'deduct_from_settlement',
    roundingMode: 'round_half_up',
    allowNegativeMargin: false,
    maxNegativeMarginCentsPerTxn: null,
    dailySubsidyLimitCents: 1000,
    monthlySubsidyLimitCents: 5000,
    ...overrides
  };
}

function assignment(overrides: Partial<ProviderAssignment> = {}): ProviderAssignment {
  return {
    id: 'assign-1',
    clientId: CLIENT_ID,
    operationType: 'cash_in',
    providerName: 'bents',
    providerAccountId: 'acct-secret-1',
    weight: 100,
    version: 3,
    ...overrides
  };
}

function build(
  pricing: Partial<PricingRuleRepository> = {},
  routing: Partial<ProviderAssignmentRepository> = {}
): ClientConfigService {
  return new ClientConfigService({
    pricingRuleRepository: { findActiveForClient: vi.fn().mockResolvedValue(null), ...pricing },
    providerAssignmentRepository: { findActive: vi.fn().mockResolvedValue(null), ...routing },
    sql: SQL
  });
}

describe('ClientConfigService.listFees', () => {
  it('returns one entry per operation that has an active rule, with the right trigger', async () => {
    const findActiveForClient = vi
      .fn()
      .mockImplementation(async (_sql, lookup: { operationType: string; triggerEvent: string }) =>
        lookup.operationType === 'cash_in'
          ? rule()
          : rule({ operationType: 'cash_out', triggerEvent: 'cash_out_created', billingMode: 'add_to_debit' })
      );
    const svc = build({ findActiveForClient });
    const fees = await svc.listFees(CLIENT_ID);

    expect(fees).toHaveLength(2);
    expect(findActiveForClient).toHaveBeenNthCalledWith(1, SQL, {
      clientId: CLIENT_ID,
      operationType: 'cash_in',
      triggerEvent: 'cash_in_paid'
    });
    expect(findActiveForClient).toHaveBeenNthCalledWith(2, SQL, {
      clientId: CLIENT_ID,
      operationType: 'cash_out',
      triggerEvent: 'cash_out_created'
    });
  });

  it('omits operations without an active rule', async () => {
    const svc = build({
      findActiveForClient: vi
        .fn()
        .mockImplementation(async (_sql, lookup: { operationType: string }) =>
          lookup.operationType === 'cash_in' ? rule() : null
        )
    });
    const fees = await svc.listFees(CLIENT_ID);
    expect(fees).toHaveLength(1);
    expect(fees[0]!.operationType).toBe('cash_in');
  });

  it('projects only the client-facing fee fields (no margin/subsidy/internal ids)', async () => {
    const svc = build({ findActiveForClient: vi.fn().mockResolvedValue(rule()) });
    const [fee] = await svc.listFees(CLIENT_ID);
    expect(Object.keys(fee!).sort()).toEqual(
      [
        'billingMode',
        'fixedFeeCents',
        'maxFeeCents',
        'minFeeCents',
        'operationType',
        'roundingMode',
        'triggerEvent',
        'variableFeeBps'
      ].sort()
    );
    const serialized = JSON.stringify(fee);
    expect(serialized).not.toContain('ubsidy');
    expect(serialized).not.toContain('argin');
    expect(serialized).not.toContain('pricingPlanVersionId');
    expect(serialized).not.toContain('rule-1');
  });
});

describe('ClientConfigService.listRouting', () => {
  it('exposes only operationType and providerName (no account id/weight/version)', async () => {
    const svc = build(
      {},
      {
        findActive: vi
          .fn()
          .mockImplementation(async (_sql, _clientId, op: string) =>
            op === 'cash_in' ? assignment() : null
          )
      }
    );
    const routing = await svc.listRouting(CLIENT_ID);
    expect(routing).toEqual([{ operationType: 'cash_in', providerName: 'bents' }]);
    const serialized = JSON.stringify(routing);
    expect(serialized).not.toContain('acct-secret-1');
    expect(serialized).not.toContain('weight');
    expect(serialized).not.toContain('version');
  });
});
