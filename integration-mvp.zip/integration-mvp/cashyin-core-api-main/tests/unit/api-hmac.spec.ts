import { createHash, createHmac } from 'node:crypto';
import type { FastifyRequest } from 'fastify';
import Fastify from 'fastify';
import { describe, expect, it, vi } from 'vitest';
import {
  ApiHmacVerifier,
  HMAC_NONCE_HEADER,
  HMAC_SIGNATURE_HEADER,
  HMAC_TIMESTAMP_HEADER,
  buildCanonicalString,
  canonicalBodyDigest,
  stableStringify,
  type ApiHmacMode
} from '../../src/modules/auth/api-hmac.js';
import { InMemoryApiHmacNonceStore } from '../../src/modules/auth/api-hmac-nonce-store.js';
import { buildAuthPreHandlers } from '../../src/modules/auth/auth-enforcement.js';
import {
  API_KEY_PREFIX,
  ClientApiKeyService,
  type ClientApiKeyRepository
} from '../../src/modules/auth/client-api-key.service.js';
import { toHttpError } from '../../src/shared/errors/app-error.js';

const SECRET = 'signing-secret-value';
const KEY_ID = 'key-1';
const NOW = 1_000_000;

describe('stableStringify', () => {
  it('sorts object keys deterministically regardless of insertion order', () => {
    expect(stableStringify({ b: 1, a: 2 })).toBe(stableStringify({ a: 2, b: 1 }));
    expect(stableStringify({ a: 2, b: 1 })).toBe('{"a":2,"b":1}');
  });

  it('handles nested objects and arrays', () => {
    expect(stableStringify({ z: [{ y: 1, x: 2 }] })).toBe('{"z":[{"x":2,"y":1}]}');
  });

  // Locked vector — the canonical-JSON contract documented for api_direct
  // clients (docs/auth/api-direct-hmac-signing.md §3). Changing this output is
  // a breaking change to the request-signing contract.
  it('matches the documented cash-out signing vector', () => {
    const body = {
      amount: 7500,
      external_ref: 'payout-1',
      pix: { key_type: 'CNPJ', key: '60311124000110' }
    };
    expect(stableStringify(body)).toBe(
      '{"amount":7500,"external_ref":"payout-1","pix":{"key":"60311124000110","key_type":"CNPJ"}}'
    );
  });
});

describe('canonicalBodyDigest', () => {
  it('hashes the empty string for an undefined body', () => {
    expect(canonicalBodyDigest(undefined)).toBe(canonicalBodyDigest(undefined));
    expect(canonicalBodyDigest(undefined)).not.toBe(canonicalBodyDigest({}));
  });
});

function signed(headers: Record<string, string>, body: unknown, url = '/v1/pix/cash-out'): FastifyRequest {
  return {
    method: 'POST',
    url,
    headers,
    body,
    routeOptions: { url },
    log: { warn: vi.fn(), info: vi.fn(), error: vi.fn() }
  } as unknown as FastifyRequest;
}

function makeSignature(opts: {
  secret?: string;
  timestamp: string;
  nonce: string;
  body: unknown;
  url?: string;
  method?: string;
}): string {
  const canonical = buildCanonicalString({
    method: opts.method ?? 'POST',
    url: opts.url ?? '/v1/pix/cash-out',
    timestamp: opts.timestamp,
    nonce: opts.nonce,
    bodyDigest: canonicalBodyDigest(opts.body)
  });
  return `sha256=${createHmac('sha256', opts.secret ?? SECRET).update(canonical).digest('hex')}`;
}

function buildVerifier(mode: ApiHmacMode, secret: string | null = SECRET): ApiHmacVerifier {
  return new ApiHmacVerifier({
    mode,
    clockSkewMs: 300_000,
    getSigningSecret: async () => secret,
    now: () => NOW
  });
}

function validHeaders(body: unknown, nonce = 'nonce-1'): Record<string, string> {
  const timestamp = String(NOW);
  return {
    [HMAC_TIMESTAMP_HEADER]: timestamp,
    [HMAC_NONCE_HEADER]: nonce,
    [HMAC_SIGNATURE_HEADER]: makeSignature({ timestamp, nonce, body })
  };
}

describe('ApiHmacVerifier', () => {
  it('off: no-op even without signature headers', async () => {
    const verifier = buildVerifier('off');
    await expect(verifier.assert(signed({}, { a: 1 }), KEY_ID)).resolves.toBeUndefined();
  });

  it('enforce: accepts a valid signature', async () => {
    const verifier = buildVerifier('enforce');
    const body = { amount: 100 };
    await expect(verifier.assert(signed(validHeaders(body), body), KEY_ID)).resolves.toBeUndefined();
  });

  it('enforce: rejects missing signature headers (401)', async () => {
    const verifier = buildVerifier('enforce');
    await expect(verifier.assert(signed({}, { a: 1 }), KEY_ID)).rejects.toMatchObject({
      statusCode: 401,
      code: 'auth_invalid'
    });
  });

  it('enforce: rejects a stale timestamp', async () => {
    const verifier = buildVerifier('enforce');
    const body = { amount: 100 };
    const timestamp = String(NOW - 600_000); // beyond 5-min skew
    const nonce = 'n';
    const headers = {
      [HMAC_TIMESTAMP_HEADER]: timestamp,
      [HMAC_NONCE_HEADER]: nonce,
      [HMAC_SIGNATURE_HEADER]: makeSignature({ timestamp, nonce, body })
    };
    await expect(verifier.assert(signed(headers, body), KEY_ID)).rejects.toMatchObject({ statusCode: 401 });
  });

  it('enforce: rejects when the key has no signing secret', async () => {
    const verifier = buildVerifier('enforce', null);
    const body = { amount: 100 };
    await expect(verifier.assert(signed(validHeaders(body), body), KEY_ID)).rejects.toMatchObject({
      statusCode: 401
    });
  });

  it('enforce: rejects a tampered body (signature mismatch)', async () => {
    const verifier = buildVerifier('enforce');
    const headers = validHeaders({ amount: 100 });
    // Body differs from what was signed.
    await expect(verifier.assert(signed(headers, { amount: 999 }), KEY_ID)).rejects.toMatchObject({
      statusCode: 401
    });
  });

  it('enforce: rejects a replayed nonce on the second use', async () => {
    const verifier = buildVerifier('enforce');
    const body = { amount: 100 };
    const headers = validHeaders(body, 'replay-me');
    await expect(verifier.assert(signed(headers, body), KEY_ID)).resolves.toBeUndefined();
    await expect(verifier.assert(signed(headers, body), KEY_ID)).rejects.toMatchObject({ statusCode: 401 });
  });

  it('shadow: never throws, even for an invalid signature, but logs', async () => {
    const verifier = buildVerifier('shadow');
    const request = signed({}, { a: 1 });
    await expect(verifier.assert(request, KEY_ID)).resolves.toBeUndefined();
    expect(request.log.warn).toHaveBeenCalledTimes(1);
  });

  it('shadow: a valid signature does not log a denial', async () => {
    const verifier = buildVerifier('shadow');
    const body = { amount: 100 };
    const request = signed(validHeaders(body), body);
    await expect(verifier.assert(request, KEY_ID)).resolves.toBeUndefined();
    expect(request.log.warn).not.toHaveBeenCalled();
  });

  it('enforce: a shared nonce store rejects a replay across instances (D16)', async () => {
    // Two verifiers (simulating two replicas) backed by ONE shared store.
    const shared = new InMemoryApiHmacNonceStore();
    const mk = (): ApiHmacVerifier =>
      new ApiHmacVerifier({
        mode: 'enforce',
        clockSkewMs: 300_000,
        getSigningSecret: async () => SECRET,
        now: () => NOW,
        nonceStore: shared
      });
    const replicaA = mk();
    const replicaB = mk();
    const body = { amount: 100 };
    const headers = validHeaders(body, 'cross-instance');
    await expect(replicaA.assert(signed(headers, body), KEY_ID)).resolves.toBeUndefined();
    // Same signed request hitting a different replica must be rejected.
    await expect(replicaB.assert(signed(headers, body), KEY_ID)).rejects.toMatchObject({
      statusCode: 401
    });
  });
});

// ── Wiring through the authenticator (api_direct Bearer + HMAC) ──

const TAIL = '00112233445566778899aabbccddeeff00112233445566778899aabbccddeeff';
const RAW_KEY = `${API_KEY_PREFIX}${TAIL}`;
const HASH = createHash('sha256').update(RAW_KEY).digest('hex');

function bearerRepo(): ClientApiKeyRepository {
  return {
    findActiveByPrefix: async (_sql, prefix) =>
      prefix === TAIL.slice(0, 8)
        ? [
            {
              id: 'key-1',
              client_id: 'client-1',
              key_prefix: TAIL.slice(0, 8),
              key_hash: HASH,
              label: null,
              scopes: ['pix:cash_out:create'],
              expires_at: null
            }
          ]
        : [],
    findById: async () => null,
    listByClient: async () => [],
    insert: async () => ({ id: 'x' }),
    touchLastUsed: async () => undefined,
    revoke: async () => undefined
  };
}

function buildApp(mode: ApiHmacMode) {
  const app = Fastify();
  app.setErrorHandler((error, _request, reply) => {
    const httpError = toHttpError(error);
    void reply.status(httpError.statusCode).send({ error: { code: httpError.code } });
  });
  const service = new ClientApiKeyService({ repository: bearerRepo(), sql: {} as never });
  const verifier = new ApiHmacVerifier({
    mode,
    clockSkewMs: 300_000,
    getSigningSecret: async () => SECRET,
    now: () => NOW
  });
  const auth = buildAuthPreHandlers({ mode: 'off', clientApiKeyService: service, bffMode: 'off', apiHmac: verifier });
  app.post('/v1/pix/cash-out', { preHandler: [auth.authenticate] }, async (request) => ({
    clientId: request.client?.clientId
  }));
  return app;
}

describe('authenticator + HMAC wiring', () => {
  it('enforce: a correctly signed Bearer request is accepted', async () => {
    const app = buildApp('enforce');
    const body = { amount: 100 };
    const headers = validHeaders(body);
    const res = await app.inject({
      method: 'POST',
      url: '/v1/pix/cash-out',
      headers: { authorization: `Bearer ${RAW_KEY}`, ...headers },
      payload: body
    });
    expect(res.statusCode).toBe(200);
    expect(res.json<{ clientId: string }>().clientId).toBe('client-1');
    await app.close();
  });

  it('enforce: an authenticated but unsigned request is rejected (401)', async () => {
    const app = buildApp('enforce');
    const res = await app.inject({
      method: 'POST',
      url: '/v1/pix/cash-out',
      headers: { authorization: `Bearer ${RAW_KEY}` },
      payload: { amount: 100 }
    });
    expect(res.statusCode).toBe(401);
    await app.close();
  });
});
