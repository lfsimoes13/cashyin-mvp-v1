import { describe, expect, it, vi } from 'vitest';
import { ProviderWebhookAdapterRegistry } from '../../src/modules/webhooks/provider-webhook-adapter-registry.js';
import type {
  WebhookEventInsertInput,
  WebhookEventRepository,
  WebhookInsertResult
} from '../../src/modules/webhooks/webhook-event.repository.js';
import { WebhookService } from '../../src/modules/webhooks/webhook.service.js';
import type {
  ProviderWebhookAdapter,
  ProviderWebhookNormalizedEvent,
  ProviderWebhookParseInput,
  ProviderWebhookParsedEvent,
  ProviderWebhookVerificationInput,
  ProviderWebhookVerificationResult
} from '../../src/providers/contracts/provider-webhook-adapter.js';
import type { Database } from '../../src/shared/db/database.js';

/**
 * Lightweight in-memory webhook event repository.
 *
 * Deduplicates on `(providerName, providerEventId)` the same way the
 * Postgres repository does via its unique constraint. Keeps a public
 * `inserts` log so tests can assert on payload shape and field
 * promotion.
 */
class FakeWebhookEventRepository implements WebhookEventRepository {
  readonly inserts: WebhookEventInsertInput[] = [];
  private readonly store = new Map<string, WebhookInsertResult['record']>();

  async insert(_sql: unknown, input: WebhookEventInsertInput): Promise<WebhookInsertResult> {
    this.inserts.push(input);

    const dedupeKey =
      input.providerEventId !== null ? `${input.providerName}:${input.providerEventId}` : null;
    if (dedupeKey && this.store.has(dedupeKey)) {
      const record = this.store.get(dedupeKey);
      if (!record) {
        throw new Error('unreachable');
      }
      return { duplicate: true, record };
    }

    const kind = input.normalizedStatus.kind;
    const record: WebhookInsertResult['record'] = {
      id: `we_${this.inserts.length}`,
      providerName: input.providerName,
      eventType: input.eventType,
      providerEventId: input.providerEventId,
      providerTransactionId: input.providerTransactionId,
      providerStatus: input.providerStatus,
      operationType: input.operationType,
      occurredAt: input.occurredAt,
      normalizedStatusKind: kind,
      normalizedStatus: kind === 'unknown' ? null : input.normalizedStatus.status,
      unknownReason: kind === 'unknown' ? input.normalizedStatus.reason : null,
      signatureValid: input.signatureValid,
      payload: input.payload,
      rawPayloadHash: input.rawPayloadHash,
      redactedHeaders: input.redactedHeaders,
      receivedAt: input.receivedAt,
      processedAt: null,
      createdAt: new Date('2026-05-23T21:00:00Z')
    };

    if (dedupeKey) this.store.set(dedupeKey, record);
    return { duplicate: false, record };
  }
}

/**
 * Stubbed adapter whose three steps are driven by per-test fixtures.
 * Provides defaults that yield a healthy `cash_in/paid` event so each
 * test only overrides what it actually wants to exercise.
 */
function fakeAdapter(
  overrides: Partial<{
    verify: ProviderWebhookVerificationResult;
    parsed: ProviderWebhookParsedEvent;
    normalized: ProviderWebhookNormalizedEvent;
  }> = {}
): ProviderWebhookAdapter {
  const defaultParsed: ProviderWebhookParsedEvent = {
    providerName: 'bents',
    rawPayloadHash: 'deadbeef',
    redactedHeaders: { 'x-bents-signature': '[redacted]' },
    rawPayload: { event: 'charge.paid' },
    providerEventId: 'evt_001',
    providerEventType: 'charge.paid',
    providerTransactionId: 'ch_001',
    providerStatus: 'PAID',
    operationType: 'cash_in',
    occurredAt: new Date('2026-05-23T19:00:00Z'),
    fields: {
      e2e_id: 'E2E_001',
      realised_amount: 1500,
      payer_name: null,
      payer_document: null,
      payer_document_type: null,
      payer_bank_name: null,
      payer_bank_ispb: null,
      payer_bank_branch: null,
      payer_bank_account: null
    }
  };
  const parsed = overrides.parsed ?? defaultParsed;
  const normalized: ProviderWebhookNormalizedEvent =
    overrides.normalized ?? {
      ...parsed,
      normalizedStatus: { kind: 'cash_in', status: 'paid' }
    };

  return {
    providerName: 'bents',
    verify: vi.fn(
      async (_input: ProviderWebhookVerificationInput) => overrides.verify ?? { valid: true }
    ),
    parse: vi.fn(async (_input: ProviderWebhookParseInput) => parsed),
    normalize: vi.fn(async (_input: ProviderWebhookParsedEvent) => normalized)
  };
}

function fakeDb(): Database {
  return {
    withTransaction: async <T>(fn: (tx: unknown) => Promise<T>): Promise<T> => fn({})
  } as unknown as Database;
}

function buildService(
  adapter: ProviderWebhookAdapter,
  repo: WebhookEventRepository = new FakeWebhookEventRepository(),
  db: Database = fakeDb()
): { service: WebhookService; repo: WebhookEventRepository } {
  const registry = new ProviderWebhookAdapterRegistry([adapter]);
  const service = new WebhookService(db, registry, repo);
  return { service, repo };
}

describe('WebhookService.ingest — signature verification', () => {
  it('returns invalid_signature without persisting when the adapter rejects the signature', async () => {
    const adapter = fakeAdapter({
      verify: { valid: false, reason: 'invalid_signature' }
    });
    const repo = new FakeWebhookEventRepository();
    const { service } = buildService(adapter, repo);

    const result = await service.ingest({
      providerName: 'bents',
      rawBody: Buffer.from('{}'),
      headers: {},
      signature: null,
      payload: {}
    });

    expect(result).toEqual({ outcome: 'invalid_signature', reason: 'invalid_signature' });
    expect(repo.inserts).toHaveLength(0);
    expect(adapter.parse).not.toHaveBeenCalled();
    expect(adapter.normalize).not.toHaveBeenCalled();
  });

  it('propagates the verification reason and optional detail to the caller', async () => {
    const adapter = fakeAdapter({
      verify: {
        valid: false,
        reason: 'malformed_signature',
        detail: 'expected sha256= prefix'
      }
    });
    const { service } = buildService(adapter);

    const result = await service.ingest({
      providerName: 'bents',
      rawBody: Buffer.from('{}'),
      headers: {},
      signature: null,
      payload: {}
    });

    expect(result).toEqual({
      outcome: 'invalid_signature',
      reason: 'malformed_signature',
      detail: 'expected sha256= prefix'
    });
  });

  it('omits the optional detail field when the adapter does not provide one', async () => {
    const adapter = fakeAdapter({
      verify: { valid: false, reason: 'missing_secret' }
    });
    const { service } = buildService(adapter);

    const result = await service.ingest({
      providerName: 'bents',
      rawBody: Buffer.from('{}'),
      headers: {},
      signature: null,
      payload: {}
    });

    expect(result).toEqual({ outcome: 'invalid_signature', reason: 'missing_secret' });
    expect(result).not.toHaveProperty('detail');
  });

  it('forwards rawBody, headers, signature and receivedAt to the adapter verify call', async () => {
    const adapter = fakeAdapter();
    const { service } = buildService(adapter);
    const rawBody = Buffer.from('{"event":"charge.paid"}');
    const headers = { 'x-bents-signature': 'sha256=abc' };
    const receivedAt = new Date('2026-05-23T20:00:00Z');

    await service.ingest({
      providerName: 'bents',
      rawBody,
      headers,
      signature: 'sha256=abc',
      payload: { event: 'charge.paid' },
      receivedAt
    });

    expect(adapter.verify).toHaveBeenCalledWith({
      rawBody,
      headers,
      signature: 'sha256=abc',
      receivedAt
    });
  });
});

describe('WebhookService.ingest — happy path persistence', () => {
  it('persists every audit field surfaced by parse + normalize', async () => {
    const adapter = fakeAdapter();
    const repo = new FakeWebhookEventRepository();
    const { service } = buildService(adapter, repo);
    const receivedAt = new Date('2026-05-23T20:00:00Z');

    const result = await service.ingest({
      providerName: 'bents',
      rawBody: Buffer.from('{"event":"charge.paid"}'),
      headers: { 'x-bents-signature': 'sha256=abc' },
      signature: null,
      payload: { event: 'charge.paid' },
      receivedAt
    });

    expect(result.outcome).toBe('persisted');
    expect(repo.inserts).toHaveLength(1);
    const stored = repo.inserts[0];
    expect(stored).toMatchObject({
      providerName: 'bents',
      eventType: 'charge.paid',
      providerEventId: 'evt_001',
      providerTransactionId: 'ch_001',
      providerStatus: 'PAID',
      operationType: 'cash_in',
      occurredAt: new Date('2026-05-23T19:00:00Z'),
      normalizedStatus: { kind: 'cash_in', status: 'paid' },
      signatureValid: true,
      rawPayloadHash: 'deadbeef',
      redactedHeaders: { 'x-bents-signature': '[redacted]' },
      receivedAt
    });
  });

  it('returns the normalized status discriminator alongside the persisted record', async () => {
    const adapter = fakeAdapter();
    const { service } = buildService(adapter);
    const result = await service.ingest({
      providerName: 'bents',
      rawBody: Buffer.from('{}'),
      headers: {},
      signature: null,
      payload: {}
    });
    expect(result.outcome).toBe('persisted');
    if (result.outcome === 'persisted' || result.outcome === 'duplicate') {
      expect(result.normalizedStatus).toEqual({ kind: 'cash_in', status: 'paid' });
      expect(result.event.id).toBe('we_1');
      expect(result.event.normalizedStatusKind).toBe('cash_in');
      expect(result.event.normalizedStatus).toBe('paid');
    }
  });

  it('persists `signatureValid=true` for every accepted event (the row attests verification)', async () => {
    const adapter = fakeAdapter();
    const repo = new FakeWebhookEventRepository();
    const { service } = buildService(adapter, repo);
    await service.ingest({
      providerName: 'bents',
      rawBody: Buffer.from('{}'),
      headers: {},
      signature: null,
      payload: {}
    });
    expect(repo.inserts[0]!.signatureValid).toBe(true);
  });

  it('uses the supplied receivedAt and forwards it to parse and persistence', async () => {
    const adapter = fakeAdapter();
    const repo = new FakeWebhookEventRepository();
    const { service } = buildService(adapter, repo);
    const receivedAt = new Date('2026-05-23T22:00:00Z');
    await service.ingest({
      providerName: 'bents',
      rawBody: Buffer.from('{}'),
      headers: {},
      signature: null,
      payload: {},
      receivedAt
    });
    expect(repo.inserts[0]!.receivedAt).toBe(receivedAt);
  });

  it('defaults receivedAt to "now" when the caller does not supply one', async () => {
    const adapter = fakeAdapter();
    const repo = new FakeWebhookEventRepository();
    const { service } = buildService(adapter, repo);
    const before = Date.now();
    await service.ingest({
      providerName: 'bents',
      rawBody: Buffer.from('{}'),
      headers: {},
      signature: null,
      payload: {}
    });
    const after = Date.now();
    const persistedAt = repo.inserts[0]!.receivedAt.getTime();
    expect(persistedAt).toBeGreaterThanOrEqual(before);
    expect(persistedAt).toBeLessThanOrEqual(after);
  });
});

describe('WebhookService.ingest — deduplication', () => {
  it('returns duplicate=true on the second ingest with the same providerEventId', async () => {
    const adapter = fakeAdapter();
    const repo = new FakeWebhookEventRepository();
    const { service } = buildService(adapter, repo);
    const input = {
      providerName: 'bents' as const,
      rawBody: Buffer.from('{}'),
      headers: {},
      signature: null,
      payload: {}
    };

    const first = await service.ingest(input);
    const second = await service.ingest(input);

    expect(first.outcome).toBe('persisted');
    expect(second.outcome).toBe('duplicate');
    if (second.outcome === 'duplicate') {
      expect(second.event.id).toBe('we_1');
      expect(second.normalizedStatus).toEqual({ kind: 'cash_in', status: 'paid' });
    }
    // Both attempts hit the insert path; deduplication is the repository's job.
    expect(repo.inserts).toHaveLength(2);
  });

  it('does NOT deduplicate when providerEventId is null (no stable id from the provider)', async () => {
    const adapter = fakeAdapter({
      parsed: {
        providerName: 'bents',
        rawPayloadHash: 'h',
        redactedHeaders: {},
        rawPayload: {},
        providerEventId: null,
        providerEventType: 'charge.paid',
        providerTransactionId: 'ch_001',
        providerStatus: 'PAID',
        operationType: 'cash_in',
        occurredAt: null,
        fields: { e2e_id: null, realised_amount: null, payer_name: null, payer_document: null, payer_document_type: null, payer_bank_name: null, payer_bank_ispb: null, payer_bank_branch: null, payer_bank_account: null }
      }
    });
    const repo = new FakeWebhookEventRepository();
    const { service } = buildService(adapter, repo);
    const input = {
      providerName: 'bents' as const,
      rawBody: Buffer.from('{}'),
      headers: {},
      signature: null,
      payload: {}
    };

    const first = await service.ingest(input);
    const second = await service.ingest(input);

    expect(first.outcome).toBe('persisted');
    expect(second.outcome).toBe('persisted');
  });
});

describe('WebhookService.ingest — unknown / orphan events', () => {
  it('persists `unknown` normalized status without raising', async () => {
    const parsed: ProviderWebhookParsedEvent = {
      providerName: 'bents',
      rawPayloadHash: 'hh',
      redactedHeaders: {},
      rawPayload: { event: 'fraud.alert' },
      providerEventId: 'evt_unknown_1',
      providerEventType: 'fraud.alert',
      providerTransactionId: null,
      providerStatus: null,
      operationType: null,
      occurredAt: null,
      fields: { e2e_id: null, realised_amount: null, payer_name: null, payer_document: null, payer_document_type: null, payer_bank_name: null, payer_bank_ispb: null, payer_bank_branch: null, payer_bank_account: null }
    };
    const adapter = fakeAdapter({
      parsed,
      normalized: {
        ...parsed,
        normalizedStatus: { kind: 'unknown', reason: 'missing_operation_type' }
      }
    });
    const repo = new FakeWebhookEventRepository();
    const { service } = buildService(adapter, repo);

    const result = await service.ingest({
      providerName: 'bents',
      rawBody: Buffer.from('{}'),
      headers: {},
      signature: null,
      payload: { event: 'fraud.alert' }
    });

    expect(result.outcome).toBe('persisted');
    if (result.outcome === 'persisted') {
      expect(result.event.normalizedStatusKind).toBe('unknown');
      expect(result.event.normalizedStatus).toBeNull();
      expect(result.event.unknownReason).toBe('missing_operation_type');
    }
    expect(repo.inserts[0]!.normalizedStatus).toEqual({
      kind: 'unknown',
      reason: 'missing_operation_type'
    });
  });
});
