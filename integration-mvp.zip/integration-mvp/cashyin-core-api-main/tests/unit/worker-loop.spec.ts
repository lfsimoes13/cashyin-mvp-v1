import { describe, expect, it, vi } from 'vitest';
import type { Logger } from 'pino';
import {
  WorkerLoop,
  defaultSleep,
  type WorkerLoopIntervals,
  type WorkerTickOutcome
} from '../../src/workers/runtime/worker-loop.js';

/**
 * The loop is intentionally fully injected: we never touch real timers
 * or process signals here. `sleep` is a queue we control deterministically,
 * `now` is monotonic, and the tick is a hand-rolled queue of outcomes
 * (or sentinel errors) so we can assert the exact cadence the loop chose
 * for each scenario.
 */

function silentLogger(): Logger {
  const noop = (): void => undefined;
  const logger = {
    info: noop,
    warn: noop,
    error: noop,
    debug: noop,
    trace: noop,
    fatal: noop,
    level: 'silent',
    child(): Logger {
      return logger;
    }
  } as unknown as Logger;
  return logger;
}

const DEFAULT_INTERVALS: WorkerLoopIntervals = {
  busyMs: 10,
  idleStartMs: 100,
  idleMaxMs: 1_000,
  errorBaseMs: 50,
  errorMaxMs: 800,
  shutdownTimeoutMs: 5_000
};

type SleepCall = { ms: number; release: () => void };

function buildHarness(opts: {
  intervals?: Partial<WorkerLoopIntervals>;
  ticks: ReadonlyArray<WorkerTickOutcome | Error>;
}) {
  const intervals: WorkerLoopIntervals = { ...DEFAULT_INTERVALS, ...(opts.intervals ?? {}) };
  const queue = [...opts.ticks];
  const observedSleeps: number[] = [];
  const pendingSleeps: SleepCall[] = [];

  let currentTime = 0;
  const now = (): number => currentTime;

  const sleep = (ms: number): Promise<void> => {
    observedSleeps.push(ms);
    return new Promise<void>((resolve) => {
      pendingSleeps.push({
        ms,
        release: () => {
          currentTime += ms;
          resolve();
        }
      });
    });
  };

  const tick = vi.fn(async (): Promise<WorkerTickOutcome> => {
    const next = queue.shift();
    if (next === undefined) {
      // Out of fixtures — return idle forever so the loop parks waiting
      // for stop(). Tests should drain `queue` before asserting and
      // then call `stop()`.
      return { idle: true, outcome: 'drained' };
    }
    if (next instanceof Error) {
      throw next;
    }
    return next;
  });

  const loop = new WorkerLoop({
    name: 'test-worker',
    logger: silentLogger(),
    tick,
    intervals,
    sleep,
    now
  });

  const releaseNextSleep = async (): Promise<void> => {
    // Wait until the loop is parked in `sleep()` before releasing.
    // The loop schedules `sleep(ms)` synchronously after each tick,
    // but we still need a microtask flush for the awaited promise.
    while (pendingSleeps.length === 0) {
      await Promise.resolve();
    }
    const next = pendingSleeps.shift();
    next?.release();
    // Give the loop a chance to advance into the next tick.
    await Promise.resolve();
  };

  const advanceTimeBy = (deltaMs: number): void => {
    currentTime += deltaMs;
  };

  return {
    loop,
    tick,
    observedSleeps,
    pendingSleeps,
    releaseNextSleep,
    advanceTimeBy,
    queue
  };
}

describe('WorkerLoop — happy path', () => {
  it('processes a sequence of events and sleeps the busy interval between them', async () => {
    const harness = buildHarness({
      ticks: [
        { idle: false, outcome: 'processed', details: { eventId: 'ev-1' } },
        { idle: false, outcome: 'processed', details: { eventId: 'ev-2' } },
        { idle: false, outcome: 'processed', details: { eventId: 'ev-3' } }
      ]
    });

    const running = harness.loop.run();

    // Tick 1 → busy sleep
    await harness.releaseNextSleep();
    // Tick 2 → busy sleep
    await harness.releaseNextSleep();
    // Tick 3 → busy sleep
    await harness.releaseNextSleep();
    // Tick 4 (no fixture; loop returns idle 'drained') → idle sleep
    await harness.releaseNextSleep();

    await harness.loop.stop();
    const stats = await running;

    expect(stats.processed).toBeGreaterThanOrEqual(3);
    // The first three observed sleeps must be the busy interval (10ms).
    expect(harness.observedSleeps.slice(0, 3)).toEqual([10, 10, 10]);
  });
});

describe('WorkerLoop — idle backoff', () => {
  it('grows the sleep exponentially up to idleMaxMs across consecutive idle ticks', async () => {
    const idleOutcome: WorkerTickOutcome = { idle: true, outcome: 'empty' };
    const harness = buildHarness({
      intervals: { idleStartMs: 100, idleMaxMs: 500 },
      ticks: [idleOutcome, idleOutcome, idleOutcome, idleOutcome, idleOutcome]
    });

    const running = harness.loop.run();
    for (let i = 0; i < 5; i += 1) {
      await harness.releaseNextSleep();
    }
    await harness.loop.stop();
    await running;

    // Expected sequence: 100, 200, 400, 500 (capped), 500 (capped)
    expect(harness.observedSleeps.slice(0, 5)).toEqual([100, 200, 400, 500, 500]);
  });

  it('resets the backoff to busy interval as soon as a tick processes work', async () => {
    const harness = buildHarness({
      intervals: { idleStartMs: 100, idleMaxMs: 1_000, busyMs: 25 },
      ticks: [
        { idle: true, outcome: 'empty' },
        { idle: true, outcome: 'empty' },
        { idle: false, outcome: 'processed' }, // ← resets cadence
        { idle: true, outcome: 'empty' }
      ]
    });

    const running = harness.loop.run();
    for (let i = 0; i < 4; i += 1) {
      await harness.releaseNextSleep();
    }
    await harness.loop.stop();
    await running;

    expect(harness.observedSleeps.slice(0, 4)).toEqual([100, 200, 25, 100]);
  });
});

describe('WorkerLoop — error backoff', () => {
  it('catches thrown errors, increments the error counter and backs off exponentially', async () => {
    const harness = buildHarness({
      intervals: { errorBaseMs: 50, errorMaxMs: 300 },
      ticks: [
        new Error('boom-1'),
        new Error('boom-2'),
        new Error('boom-3'),
        new Error('boom-4'),
        { idle: false, outcome: 'processed' } // ← recovery resets cadence
      ]
    });

    const running = harness.loop.run();
    for (let i = 0; i < 5; i += 1) {
      await harness.releaseNextSleep();
    }
    await harness.loop.stop();
    const stats = await running;

    // 50, 100, 200, 300 (capped), then busy after recovery.
    expect(harness.observedSleeps.slice(0, 5)).toEqual([50, 100, 200, 300, 10]);
    expect(stats.errors).toBe(4);
    expect(stats.processed).toBe(1);
  });

  it('does not crash the loop on repeated throws (workers must stay alive)', async () => {
    const harness = buildHarness({
      ticks: [new Error('e1'), new Error('e2'), new Error('e3')]
    });

    const running = harness.loop.run();
    for (let i = 0; i < 3; i += 1) {
      await harness.releaseNextSleep();
    }
    await harness.loop.stop();
    const stats = await running;

    expect(stats.errors).toBe(3);
    // Loop reached `stop()` cleanly even though every tick threw.
    expect(stats.stoppedAt).not.toBeNull();
  });
});

describe('WorkerLoop — graceful shutdown', () => {
  it('stop() waits for the in-flight tick before resolving', async () => {
    let resolveTick: ((value: WorkerTickOutcome) => void) | null = null;
    const tickStarted = new Promise<void>((resolve) => {
      // Captured during the first tick invocation.
      const orig = () => resolve();
      orig();
    });

    const harness = buildHarness({ ticks: [] });
    // Override the tick to block until we choose to release it.
    harness.tick.mockImplementationOnce(
      () =>
        new Promise<WorkerTickOutcome>((resolve) => {
          resolveTick = resolve;
        })
    );

    const running = harness.loop.run();
    await tickStarted;

    // While the tick is in-flight, stop() must NOT resolve.
    let stopped = false;
    const stopPromise = harness.loop.stop().then(() => {
      stopped = true;
    });
    await Promise.resolve();
    expect(stopped).toBe(false);

    // Release the tick → stop() resolves; the loop sees `stopping` and exits.
    resolveTick?.({ idle: false, outcome: 'processed' });
    await stopPromise;

    const stats = await running;
    expect(stopped).toBe(true);
    expect(stats.processed).toBe(1);
    expect(stats.stoppedAt).not.toBeNull();
  });

  it('stop() during a long sleep wakes the loop immediately', async () => {
    const harness = buildHarness({
      intervals: { ...DEFAULT_INTERVALS, idleStartMs: 60_000, idleMaxMs: 60_000 },
      ticks: [{ idle: true, outcome: 'empty' }]
    });

    const running = harness.loop.run();
    // Wait until the loop parks in sleep().
    while (harness.pendingSleeps.length === 0) {
      await Promise.resolve();
    }
    // Call stop without releasing the sleep manually — the loop must
    // wake from the interruptible sleep and exit cleanly.
    await harness.loop.stop();
    const stats = await running;

    // The pending sleep is left orphaned (its resolve fires later) but
    // the loop does not block on it, which is exactly what we want
    // during SIGTERM.
    expect(stats.stoppedAt).not.toBeNull();
    expect(stats.idle).toBe(1);
  });

  it('stop() is idempotent and safe to call before run()', async () => {
    const harness = buildHarness({ ticks: [{ idle: true, outcome: 'empty' }] });
    await harness.loop.stop();
    await harness.loop.stop();
    expect(harness.loop.isStopping()).toBe(true);

    // Calling run() after stop() should resolve immediately without
    // executing any tick (loop sees `stopping` before the first body).
    const stats = await harness.loop.run();
    expect(stats.ticks).toBe(0);
    expect(harness.tick).not.toHaveBeenCalled();
  });
});

describe('WorkerLoop — observability', () => {
  it('emits an empty-outcome log details object for idle ticks', async () => {
    const childLog = vi.fn();
    const childLogger = {
      info: childLog,
      warn: vi.fn(),
      error: vi.fn(),
      debug: vi.fn(),
      trace: vi.fn(),
      fatal: vi.fn(),
      level: 'info'
    } as unknown as Logger;
    const rootLogger = {
      child: () => childLogger,
      info: childLog,
      warn: vi.fn(),
      error: vi.fn(),
      debug: vi.fn(),
      trace: vi.fn(),
      fatal: vi.fn(),
      level: 'info'
    } as unknown as Logger;

    const loop = new WorkerLoop({
      name: 'observability-test',
      logger: rootLogger,
      intervals: DEFAULT_INTERVALS,
      tick: async () => ({ idle: false, outcome: 'delivered', details: { eventId: 'e' } }),
      sleep: async (): Promise<void> => undefined,
      now: () => 0
    });

    const running = loop.run();
    // Allow one tick to fire, then stop.
    await Promise.resolve();
    await loop.stop();
    await running;

    expect(childLog).toHaveBeenCalled();
  });
});

describe('WorkerLoop — defaultSleep keep-alive', () => {
  // Regression guard for the production crash-loop where the worker
  // entrypoint exited every ~30s with "Detected unsettled top-level
  // await": the previous implementation `unref()`'d the setTimeout
  // handle, so during an idle backoff the loop had no remaining
  // refs and Node 22 considered the event loop drained.
  it('returns a promise backed by a ref-counted timer (keeps the event loop alive)', async () => {
    const spy = vi.spyOn(global, 'setTimeout');
    try {
      const sleeping = defaultSleep(15);
      expect(spy).toHaveBeenCalledTimes(1);
      const handle = spy.mock.results[0]?.value as NodeJS.Timeout;
      expect(typeof handle.hasRef).toBe('function');
      expect(handle.hasRef()).toBe(true);
      await sleeping;
    } finally {
      spy.mockRestore();
    }
  });

  it('resolves after the requested duration so loops actually advance', async () => {
    const start = Date.now();
    await defaultSleep(20);
    const elapsed = Date.now() - start;
    // Allow a generous lower bound (15ms) for slow CI hosts; the
    // upper bound is intentionally absent — we only care that the
    // timer fired.
    expect(elapsed).toBeGreaterThanOrEqual(15);
  });
});

describe('WorkerLoop — registerShutdownSignals', () => {
  it('attaches once per signal and detaches itself after firing', async () => {
    const loop = new WorkerLoop({
      name: 'signals-test',
      logger: silentLogger(),
      intervals: DEFAULT_INTERVALS,
      tick: async () => ({ idle: true, outcome: 'empty' }),
      sleep: async (): Promise<void> => undefined,
      now: () => 0
    });

    const sigBefore = process.listenerCount('SIGINT');
    const termBefore = process.listenerCount('SIGTERM');
    const dispose = loop.registerShutdownSignals(['SIGINT', 'SIGTERM']);
    expect(process.listenerCount('SIGINT')).toBe(sigBefore + 1);
    expect(process.listenerCount('SIGTERM')).toBe(termBefore + 1);

    // Cleanup without firing the signals: dispose must remove them.
    dispose();
    expect(process.listenerCount('SIGINT')).toBe(sigBefore);
    expect(process.listenerCount('SIGTERM')).toBe(termBefore);
  });
});

// ────────────────────────────────────────────────────────────────────
// nudge() / wakeReason
// ────────────────────────────────────────────────────────────────────

describe('WorkerLoop — nudge() and wakeReason', () => {
  it('nudge() wakes an in-progress sleep immediately', async () => {
    // Tick queue: one busy outcome, then stop.
    const h = buildHarness({ ticks: [{ idle: false }] });

    const runPromise = h.loop.run();

    // First tick runs synchronously; loop then enters sleep for busyMs.
    // Wait for the sleep to be registered.
    await Promise.resolve();
    await Promise.resolve();

    // There should be one pending sleep (busyMs = 10).
    const sleepBefore = h.pendingSleeps.length;
    expect(sleepBefore).toBeGreaterThanOrEqual(1);

    // Nudge wakes the loop without waiting for the timer.
    h.loop.nudge();

    // Stop so the loop can exit cleanly.
    await h.loop.stop();
    await runPromise;

    // Loop ran and stopped without error.
    expect(h.loop.snapshot().ticks).toBeGreaterThanOrEqual(1);
  });

  it('nudge() during a tick is handled — loop starts next tick immediately', async () => {
    // Tick 1 returns idle; we nudge during its sleep; tick 2 should fire.
    const h = buildHarness({ ticks: [{ idle: true }, { idle: false }] });

    const runPromise = h.loop.run();
    await Promise.resolve();
    await Promise.resolve();

    // First tick is done; loop sleeps for idleStartMs.
    h.loop.nudge();

    // Let pending sleeps drain so tick 2 can run.
    while (h.pendingSleeps.length > 0) {
      h.pendingSleeps.shift()!.release();
      await Promise.resolve();
      await Promise.resolve();
    }

    await h.loop.stop();
    await runPromise;

    expect(h.loop.snapshot().processed).toBeGreaterThanOrEqual(1);
  });

  it('nudge() is a no-op when the loop is stopping', async () => {
    const h = buildHarness({ ticks: [{ idle: true }] });
    const runPromise = h.loop.run();
    await Promise.resolve();
    await h.loop.stop();

    // After stop, nudge should not throw or restart the loop.
    expect(() => h.loop.nudge()).not.toThrow();
    await runPromise;
    expect(h.loop.isStopping()).toBe(true);
  });
});
