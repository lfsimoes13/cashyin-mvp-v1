import { describe, expect, it, vi } from 'vitest';
import {
  WebhookEventProcessor,
  type WebhookEventProcessorDeps,
  type WebhookRetryPolicy
} from '../../src/modules/webhooks/webhook-event.processor.js';
import type {
  WebhookEventClaimFilter,
  WebhookEventClaimInput,
  WebhookEventFinaliseInput,
  WebhookEventRecord,
  WebhookEventRepository,
  WebhookEventRetryInput
} from '../../src/modules/webhooks/webhook-event.repository.js';
import type {
  WebhookProcessingAttemptInsertInput,
  WebhookProcessingAttemptRepository
} from '../../src/modules/webhooks/webhook-processing-attempt.repository.js';
import type { Sql } from '../../src/shared/db/sql.js';
import type {
  ChargePaidEvent,
  ChargePaidResult,
  ChargeTerminalEvent,
  ChargeTerminalResult,
  PaymentService
} from '../../src/modules/payments/payment.service.js';
import type {
  CashoutService,
  CashoutStatusUpdateEvent,
  CashoutStatusUpdateResult
} from '../../src/modules/cashouts/cashout.service.js';
import type { Database } from '../../src/shared/db/database.js';

// ────────────────────────────────────────────────────────────────────
// Fixtures
// ────────────────────────────────────────────────────────────────────

function baseEvent(overrides: Partial<WebhookEventRecord> = {}): WebhookEventRecord {
  return {
    id: 'we_1',
    providerName: 'bents',
    eventType: 'charge.paid',
    providerEventId: 'evt_001',
    providerTransactionId: 'ch_001',
    providerStatus: 'PAID',
    operationType: 'cash_in',
    occurredAt: new Date('2026-05-22T11:59:58Z'),
    normalizedStatusKind: 'cash_in',
    normalizedStatus: 'paid',
    unknownReason: null,
    signatureValid: true,
    payload: {},
    rawPayloadHash: 'hash',
    redactedHeaders: {},
    receivedAt: new Date('2026-05-22T12:00:00Z'),
    processedAt: null,
    createdAt: new Date('2026-05-22T12:00:00Z'),
    processingStatus: 'processing', // after claim
    processingError: null,
    attemptCount: 1,
    lastAttemptAt: new Date('2026-05-23T20:00:00Z'),
    nextAttemptAt: null,
    ...overrides
  };
}

type Calls = {
  finalise: Array<{ id: string; status: string; error: string | null | undefined }>;
  scheduleRetry: Array<{ id: string; error: string; nextAttemptAt: Date }>;
  attempts: WebhookProcessingAttemptInsertInput[];
};

function buildHarness(opts: {
  claimed: WebhookEventRecord | null;
  paymentService?: Partial<PaymentService>;
  cashoutService?: Partial<CashoutService>;
  retryPolicy?: WebhookRetryPolicy;
  now?: () => Date;
  workerId?: string;
  workerName?: string;
  claimFilter?: WebhookEventClaimFilter;
} = { claimed: null }) {
  const calls: Calls = { finalise: [], scheduleRetry: [], attempts: [] };

  const webhookEventRepository: WebhookEventRepository = {
    insert: vi.fn(),
    claimNextPending: vi.fn(async () => opts.claimed),
    finalise: vi.fn(async (_sql: Sql, input: WebhookEventFinaliseInput): Promise<void> => {
      calls.finalise.push({ id: input.id, status: input.status, error: input.error ?? null });
    }),
    scheduleRetry: vi.fn(async (_sql: Sql, input: WebhookEventRetryInput): Promise<void> => {
      calls.scheduleRetry.push({
        id: input.id,
        error: input.error,
        nextAttemptAt: input.nextAttemptAt
      });
    }),
    reclaimStaleProcessing: vi.fn(async () => 0)
  };

  const attemptRepository: WebhookProcessingAttemptRepository = {
    insert: vi.fn(
      async (_sql: Sql, input: WebhookProcessingAttemptInsertInput): Promise<void> => {
        calls.attempts.push(input);
      }
    )
  };

  const handleChargePaid =
    opts.paymentService?.handleChargePaid ??
    vi.fn(
      async (_event: ChargePaidEvent): Promise<ChargePaidResult> => ({
        status: 'updated',
        charge_id: 'charge-1',
        fee_assessment_id: null,
        ledger_entries_posted: 0
      })
    );
  const handleChargeTerminal =
    opts.paymentService?.handleChargeTerminal ??
    vi.fn(
      async (event: ChargeTerminalEvent): Promise<ChargeTerminalResult> => ({
        status: 'updated',
        charge_id: 'charge-1',
        previous_status: 'pending',
        new_status: event.status
      })
    );

  const paymentService = {
    handleChargePaid,
    handleChargeTerminal
  } as unknown as PaymentService;

  const handleCashoutStatusUpdate =
    opts.cashoutService?.handleCashoutStatusUpdate ??
    vi.fn(
      async (event: CashoutStatusUpdateEvent): Promise<CashoutStatusUpdateResult> => ({
        status: 'updated',
        cashoutId: 'cashout-1',
        previousStatus: 'processing',
        newStatus: event.status
      })
    );

  const cashoutService = {
    handleCashoutStatusUpdate
  } as unknown as CashoutService;

  const db: Database = {
    withTransaction: async <T>(fn: (tx: unknown) => Promise<T>): Promise<T> => fn({}),
    pool: {} as unknown
  } as unknown as Database;

  const depsObj: WebhookEventProcessorDeps = {
    db,
    webhookEventRepository,
    attemptRepository,
    paymentService,
    cashoutService,
    ...(opts.retryPolicy !== undefined ? { retryPolicy: opts.retryPolicy } : {}),
    ...(opts.now !== undefined ? { now: opts.now } : {}),
    ...(opts.workerId !== undefined ? { workerId: opts.workerId } : {}),
    ...(opts.workerName !== undefined ? { workerName: opts.workerName } : {}),
    ...(opts.claimFilter !== undefined ? { claimFilter: opts.claimFilter } : {})
  };

  const processor = new WebhookEventProcessor(depsObj);

  return {
    processor,
    webhookEventRepository,
    attemptRepository,
    paymentService,
    cashoutService,
    handleChargePaid,
    handleChargeTerminal,
    handleCashoutStatusUpdate,
    calls
  };
}

// ────────────────────────────────────────────────────────────────────
// Empty queue
// ────────────────────────────────────────────────────────────────────

describe('WebhookEventProcessor.processNext — empty queue', () => {
  it('returns {kind:"empty"} when nothing is due', async () => {
    const h = buildHarness({ claimed: null });
    const result = await h.processor.processNext();
    expect(result).toEqual({ kind: 'empty' });
    expect(h.handleChargePaid).not.toHaveBeenCalled();
    expect(h.handleChargeTerminal).not.toHaveBeenCalled();
    expect(h.calls.finalise).toHaveLength(0);
    expect(h.calls.attempts).toHaveLength(0);
  });
});

// ────────────────────────────────────────────────────────────────────
// Cash-In paid
// ────────────────────────────────────────────────────────────────────

describe('WebhookEventProcessor.processNext — cash_in/paid', () => {
  it('delegates to PaymentService.handleChargePaid and finalises as processed', async () => {
    const h = buildHarness({ claimed: baseEvent() });
    const result = await h.processor.processNext();

    expect(h.handleChargePaid).toHaveBeenCalledWith({
      provider_name: 'bents',
      provider_charge_id: 'ch_001',
      paid_at: new Date('2026-05-22T11:59:58Z')
    });
    expect(result).toMatchObject({
      kind: 'processed',
      eventId: 'we_1',
      detail: { flow: 'cash_in_paid', chargeId: 'charge-1', ledgerEntriesPosted: 0 }
    });
    expect(h.calls.finalise).toEqual([{ id: 'we_1', status: 'processed', error: null }]);
    expect(h.calls.attempts).toHaveLength(1);
    expect(h.calls.attempts[0]!.outcome).toBe('success');
    expect(h.calls.attempts[0]!.attemptNumber).toBe(1);
  });

  it('falls back to receivedAt when the parsed event has no occurredAt', async () => {
    const h = buildHarness({ claimed: baseEvent({ occurredAt: null }) });
    await h.processor.processNext();
    expect(h.handleChargePaid).toHaveBeenCalledWith(
      expect.objectContaining({ paid_at: new Date('2026-05-22T12:00:00Z') })
    );
  });

  it('propagates the BACEN e2e_id from data.e2e_id into the ChargePaidEvent', async () => {
    const h = buildHarness({
      claimed: baseEvent({
        payload: {
          event: 'pix.charge.paid',
          data: {
            charge_uuid: 'ch_001',
            status: 'PAID',
            e2e_id: 'E43978697202605292340152433138b0'
          }
        }
      })
    });
    await h.processor.processNext();
    expect(h.handleChargePaid).toHaveBeenCalledWith(
      expect.objectContaining({ e2e_id: 'E43978697202605292340152433138b0' })
    );
  });

  it('also accepts the legacy end_to_end_id provider key and emits canonical e2e_id', async () => {
    const h = buildHarness({
      claimed: baseEvent({
        payload: {
          event: 'pix.charge.paid',
          data: {
            charge_uuid: 'ch_001',
            status: 'PAID',
            end_to_end_id: 'E43978697202605292340152433138b0'
          }
        }
      })
    });
    await h.processor.processNext();
    expect(h.handleChargePaid).toHaveBeenCalledWith(
      expect.objectContaining({ e2e_id: 'E43978697202605292340152433138b0' })
    );
  });

  it('translates a noop:already_paid from the service into a kind:"noop" outcome and finalises as processed', async () => {
    const handleChargePaid = vi.fn(
      async (): Promise<ChargePaidResult> => ({ status: 'noop', reason: 'already_paid' })
    );
    const h = buildHarness({
      claimed: baseEvent(),
      paymentService: { handleChargePaid }
    });
    const result = await h.processor.processNext();
    expect(result).toMatchObject({
      kind: 'noop',
      eventId: 'we_1',
      reason: 'already_paid'
    });
    expect(h.calls.finalise).toEqual([{ id: 'we_1', status: 'processed', error: null }]);
    expect(h.calls.attempts[0]!.outcome).toBe('success');
  });

  it('translates a noop:charge_not_found from the service into a kind:"noop" outcome', async () => {
    const handleChargePaid = vi.fn(
      async (): Promise<ChargePaidResult> => ({ status: 'noop', reason: 'charge_not_found' })
    );
    const h = buildHarness({
      claimed: baseEvent(),
      paymentService: { handleChargePaid }
    });
    const result = await h.processor.processNext();
    expect(result).toMatchObject({ kind: 'noop', eventId: 'we_1', reason: 'charge_not_found' });
  });
});

// ────────────────────────────────────────────────────────────────────
// Cash-In terminal failures
// ────────────────────────────────────────────────────────────────────

describe('WebhookEventProcessor.processNext — cash_in terminal failures', () => {
  it.each(['expired', 'cancelled', 'failed'] as const)(
    'routes %s to PaymentService.handleChargeTerminal',
    async (status) => {
      const h = buildHarness({
        claimed: baseEvent({
          eventType: `charge.${status}`,
          normalizedStatus: status,
          providerStatus: status.toUpperCase()
        })
      });
      const result = await h.processor.processNext();
      expect(h.handleChargeTerminal).toHaveBeenCalledWith({
        provider_name: 'bents',
        provider_charge_id: 'ch_001',
        status,
        occurred_at: new Date('2026-05-22T11:59:58Z')
      });
      expect(result).toMatchObject({
        kind: 'processed',
        eventId: 'we_1',
        detail: { flow: 'cash_in_terminal', chargeId: 'charge-1', status }
      });
      expect(h.calls.finalise).toEqual([{ id: 'we_1', status: 'processed', error: null }]);
    }
  );

  it('returns noop and finalises as processed when the charge is already terminal', async () => {
    const handleChargeTerminal = vi.fn(
      async (): Promise<ChargeTerminalResult> => ({ status: 'noop', reason: 'already_terminal' })
    );
    const h = buildHarness({
      claimed: baseEvent({ normalizedStatus: 'expired' }),
      paymentService: { handleChargeTerminal }
    });
    const result = await h.processor.processNext();
    expect(result).toMatchObject({ kind: 'noop', eventId: 'we_1', reason: 'already_terminal' });
    expect(h.calls.finalise[0]).toMatchObject({ status: 'processed' });
  });
});

// ────────────────────────────────────────────────────────────────────
// Skips
// ────────────────────────────────────────────────────────────────────

describe('WebhookEventProcessor.processNext — cash_out terminal updates', () => {
  function cashOutEvent(overrides: Partial<WebhookEventRecord> = {}): WebhookEventRecord {
    return baseEvent({
      eventType: 'payment.completed',
      normalizedStatusKind: 'cash_out',
      normalizedStatus: 'completed',
      operationType: 'cash_out',
      providerTransactionId: 'pay_001',
      providerStatus: 'COMPLETED',
      ...overrides
    });
  }

  it.each(['completed', 'failed', 'returned'] as const)(
    'routes %s to CashoutService.handleCashoutStatusUpdate',
    async (status) => {
      const h = buildHarness({
        claimed: cashOutEvent({
          eventType: `payment.${status}`,
          normalizedStatus: status,
          providerStatus: status.toUpperCase()
        })
      });
      const result = await h.processor.processNext();
      expect(h.handleCashoutStatusUpdate).toHaveBeenCalledWith({
        providerName: 'bents',
        providerPaymentId: 'pay_001',
        status,
        occurredAt: new Date('2026-05-22T11:59:58Z'),
        // Non-success terminals carry the raw provider status as a
        // best-effort failure reason; success carries none.
        failureReason: status === 'completed' ? null : status.toUpperCase()
      });
      expect(result).toMatchObject({
        kind: 'processed',
        eventId: 'we_1',
        detail: {
          flow: 'cash_out_status_update',
          cashoutId: 'cashout-1',
          previousStatus: 'processing',
          newStatus: status
        }
      });
      expect(h.calls.finalise).toEqual([{ id: 'we_1', status: 'processed', error: null }]);
    }
  );

  it('forwards the full provider receiver block and e2e_id from data.receiver', async () => {
    const h = buildHarness({
      claimed: cashOutEvent({
        normalizedStatus: 'completed',
        providerStatus: 'SUCCESS',
        payload: {
          event: 'pix.payment.sent',
          data: {
            transaction_id: 'pay_001',
            status: 'SUCCESS',
            e2e_id: 'E4397869720260529201719529c238ca',
            fee_amount_cents: 10,
            receiver: {
              name: 'DAYANE JAQUELINE MARINS ALCANTES 41530170869',
              document: '**.921.710/****-**',
              bank: 'A55 SCD S.A.',
              ispb: '48756121',
              branch: '0001',
              account: '12345-6',
              account_type: 'CACC'
            }
          }
        }
      })
    });
    await h.processor.processNext();
    expect(h.handleCashoutStatusUpdate).toHaveBeenCalledWith(
      expect.objectContaining({
        status: 'completed',
        receiverName: 'DAYANE JAQUELINE MARINS ALCANTES 41530170869',
        receiverDocument: '**.921.710/****-**',
        receiverBank: 'A55 SCD S.A.',
        receiverIspb: '48756121',
        receiverBranch: '0001',
        receiverAccount: '12345-6',
        receiverAccountType: 'CACC',
        // The BACEN e2e id must be backfilled onto the cash-out so an
        // asynchronous provider's late `e2e_id` is persisted, not dropped.
        e2eId: 'E4397869720260529201719529c238ca'
      })
    );
  });

  it('returns noop:cashout_not_found when the cashout row is missing', async () => {
    const handleCashoutStatusUpdate = vi.fn(
      async (): Promise<CashoutStatusUpdateResult> => ({
        status: 'noop',
        reason: 'cashout_not_found'
      })
    );
    const h = buildHarness({
      claimed: cashOutEvent({ normalizedStatus: 'completed' }),
      cashoutService: { handleCashoutStatusUpdate }
    });
    const result = await h.processor.processNext();
    expect(result).toMatchObject({ kind: 'noop', eventId: 'we_1', reason: 'cashout_not_found' });
    expect(h.calls.finalise[0]).toMatchObject({ status: 'processed' });
  });

  it('returns noop:already_in_status when the cashout is already in the target state', async () => {
    const handleCashoutStatusUpdate = vi.fn(
      async (): Promise<CashoutStatusUpdateResult> => ({
        status: 'noop',
        reason: 'already_in_status',
        cashoutId: 'cashout-1'
      })
    );
    const h = buildHarness({
      claimed: cashOutEvent({ normalizedStatus: 'failed' }),
      cashoutService: { handleCashoutStatusUpdate }
    });
    const result = await h.processor.processNext();
    expect(result).toMatchObject({ kind: 'noop', eventId: 'we_1', reason: 'already_in_status' });
  });

  it('returns noop:invalid_transition when the cashout cannot advance', async () => {
    const handleCashoutStatusUpdate = vi.fn(
      async (): Promise<CashoutStatusUpdateResult> => ({
        status: 'noop',
        reason: 'invalid_transition',
        cashoutId: 'cashout-1',
        fromStatus: 'failed',
        toStatus: 'completed'
      })
    );
    const h = buildHarness({
      claimed: cashOutEvent({ normalizedStatus: 'completed' }),
      cashoutService: { handleCashoutStatusUpdate }
    });
    const result = await h.processor.processNext();
    expect(result).toMatchObject({ kind: 'noop', eventId: 'we_1', reason: 'invalid_transition' });
  });

  it('falls back to receivedAt when occurredAt is missing', async () => {
    const h = buildHarness({
      claimed: cashOutEvent({ normalizedStatus: 'completed', occurredAt: null })
    });
    await h.processor.processNext();
    expect(h.handleCashoutStatusUpdate).toHaveBeenCalledWith(
      expect.objectContaining({ occurredAt: new Date('2026-05-22T12:00:00Z') })
    );
  });

  it('skips cash_out events with no providerTransactionId', async () => {
    const h = buildHarness({
      claimed: cashOutEvent({ providerTransactionId: null })
    });
    const result = await h.processor.processNext();
    expect(result).toMatchObject({ kind: 'skipped', reason: 'missing_provider_transaction_id' });
    expect(h.handleCashoutStatusUpdate).not.toHaveBeenCalled();
  });

  it('skips cash_out events with an unrecognised normalized status', async () => {
    const h = buildHarness({
      claimed: cashOutEvent({ normalizedStatus: 'frobnicated' })
    });
    const result = await h.processor.processNext();
    expect(result).toMatchObject({ kind: 'skipped', reason: 'unsupported_cash_out_status' });
    expect(h.handleCashoutStatusUpdate).not.toHaveBeenCalled();
  });
});

describe('WebhookEventProcessor.processNext — skips', () => {
  it('skips unknown normalized status', async () => {
    const h = buildHarness({
      claimed: baseEvent({
        normalizedStatusKind: 'unknown',
        normalizedStatus: null,
        unknownReason: 'missing_operation_type'
      })
    });
    const result = await h.processor.processNext();
    expect(result).toMatchObject({
      kind: 'skipped',
      eventId: 'we_1',
      reason: 'unknown_normalized_status'
    });
    expect(h.calls.finalise).toEqual([
      { id: 'we_1', status: 'skipped', error: 'unknown_normalized_status' }
    ]);
    expect(h.calls.attempts[0]!.outcome).toBe('permanent_failure');
    expect(h.calls.attempts[0]!.errorMessage).toBe('unknown_normalized_status');
  });

  it('skips cash_out re-confirmations of the `processing` status', async () => {
    const h = buildHarness({
      claimed: baseEvent({
        eventType: 'payment.processing',
        normalizedStatusKind: 'cash_out',
        normalizedStatus: 'processing',
        operationType: 'cash_out'
      })
    });
    const result = await h.processor.processNext();
    expect(result).toMatchObject({
      kind: 'skipped',
      reason: 'cash_out_processing_reconfirm'
    });
    expect(h.handleCashoutStatusUpdate).not.toHaveBeenCalled();
  });

  it('skips cash_out with no normalized status (sanity guard)', async () => {
    const h = buildHarness({
      claimed: baseEvent({
        eventType: 'payment.received',
        normalizedStatusKind: 'cash_out',
        normalizedStatus: null,
        operationType: 'cash_out'
      })
    });
    const result = await h.processor.processNext();
    expect(result).toMatchObject({
      kind: 'skipped',
      reason: 'unsupported_cash_out_status'
    });
  });

  it('skips when the parsed event has no providerTransactionId to resolve', async () => {
    const h = buildHarness({
      claimed: baseEvent({ providerTransactionId: null })
    });
    const result = await h.processor.processNext();
    expect(result).toMatchObject({ kind: 'skipped', reason: 'missing_provider_transaction_id' });
  });

  it('skips an unrecognised cash_in status that bypassed normalisation', async () => {
    const h = buildHarness({
      claimed: baseEvent({ normalizedStatus: 'frobnicated' })
    });
    const result = await h.processor.processNext();
    expect(result).toMatchObject({ kind: 'skipped', reason: 'unsupported_cash_in_status' });
  });
});

// ────────────────────────────────────────────────────────────────────
// Retry & DLQ
// ────────────────────────────────────────────────────────────────────

describe('WebhookEventProcessor.processNext — failures', () => {
  const fixedNow = new Date('2026-05-23T20:00:00Z');

  it('schedules a retry with exponential backoff when the handler throws', async () => {
    const handleChargePaid = vi.fn(async () => {
      throw new Error('boom');
    });
    const h = buildHarness({
      claimed: baseEvent({ attemptCount: 1 }),
      paymentService: { handleChargePaid },
      now: () => fixedNow,
      retryPolicy: { baseDelayMs: 30_000, maxDelayMs: 3_600_000, maxAttempts: 8 }
    });
    const result = await h.processor.processNext();

    expect(result).toMatchObject({
      kind: 'retry',
      eventId: 'we_1',
      attemptNumber: 1,
      error: 'boom',
      nextAttemptAt: new Date(fixedNow.getTime() + 30_000)
    });
    expect(h.calls.scheduleRetry).toEqual([
      { id: 'we_1', error: 'boom', nextAttemptAt: new Date(fixedNow.getTime() + 30_000) }
    ]);
    expect(h.calls.attempts).toHaveLength(1);
    expect(h.calls.attempts[0]).toMatchObject({
      attemptNumber: 1,
      outcome: 'retryable_failure',
      errorMessage: 'boom'
    });
    expect(h.calls.finalise).toHaveLength(0);
  });

  it('doubles the backoff on each subsequent attempt', async () => {
    const handleChargePaid = vi.fn(async () => {
      throw new Error('boom');
    });
    const h = buildHarness({
      claimed: baseEvent({ attemptCount: 3 }),
      paymentService: { handleChargePaid },
      now: () => fixedNow,
      retryPolicy: { baseDelayMs: 30_000, maxDelayMs: 3_600_000, maxAttempts: 8 }
    });
    const result = await h.processor.processNext();
    // attempt 3 → 30_000 * 2^(3-1) = 120_000ms = 2min
    expect(result).toMatchObject({
      kind: 'retry',
      nextAttemptAt: new Date(fixedNow.getTime() + 120_000)
    });
  });

  it('caps the backoff at maxDelayMs', async () => {
    const handleChargePaid = vi.fn(async () => {
      throw new Error('boom');
    });
    const h = buildHarness({
      claimed: baseEvent({ attemptCount: 20 }),
      paymentService: { handleChargePaid },
      now: () => fixedNow,
      // Max delay 10s; raw would be huge.
      retryPolicy: { baseDelayMs: 30_000, maxDelayMs: 10_000, maxAttempts: 100 }
    });
    const result = await h.processor.processNext();
    expect(result).toMatchObject({
      kind: 'retry',
      nextAttemptAt: new Date(fixedNow.getTime() + 10_000)
    });
  });

  it('routes to DLQ once attempt_count reaches maxAttempts', async () => {
    const handleChargePaid = vi.fn(async () => {
      throw new Error('still broken');
    });
    const h = buildHarness({
      claimed: baseEvent({ attemptCount: 8 }),
      paymentService: { handleChargePaid },
      now: () => fixedNow,
      retryPolicy: { baseDelayMs: 30_000, maxDelayMs: 3_600_000, maxAttempts: 8 }
    });
    const result = await h.processor.processNext();
    expect(result).toMatchObject({
      kind: 'dlq',
      eventId: 'we_1',
      attemptNumber: 8,
      error: 'still broken'
    });
    expect(h.calls.finalise).toEqual([
      { id: 'we_1', status: 'dlq', error: 'still broken' }
    ]);
    expect(h.calls.scheduleRetry).toHaveLength(0);
    expect(h.calls.attempts[0]).toMatchObject({
      outcome: 'permanent_failure',
      errorCode: 'max_attempts_exceeded'
    });
  });

  it('stringifies non-Error throws into the recorded error message', async () => {
    const handleChargePaid = vi.fn(async () => {
      // Deliberately throw a non-Error to verify the `String(error)`
      // fallback in the processor's errorMessage helper.
      // eslint-disable-next-line @typescript-eslint/only-throw-error
      throw 'string thrown';
    });
    const h = buildHarness({
      claimed: baseEvent({ attemptCount: 1 }),
      paymentService: { handleChargePaid },
      now: () => fixedNow,
      retryPolicy: { baseDelayMs: 1_000, maxDelayMs: 60_000, maxAttempts: 5 }
    });
    const result = await h.processor.processNext();
    expect(result).toMatchObject({ kind: 'retry', error: 'string thrown' });
  });
});

// ────────────────────────────────────────────────────────────────────
// processBatch
// ────────────────────────────────────────────────────────────────────

describe('WebhookEventProcessor.processBatch', () => {
  it('throws on non-positive limit', async () => {
    const h = buildHarness({ claimed: null });
    await expect(h.processor.processBatch(0)).rejects.toThrow(/positive integer/);
    await expect(h.processor.processBatch(-1)).rejects.toThrow(/positive integer/);
    await expect(h.processor.processBatch(1.5)).rejects.toThrow(/positive integer/);
  });

  it('stops on the first empty outcome', async () => {
    const h = buildHarness({ claimed: null });
    const results = await h.processor.processBatch(10);
    expect(results).toEqual([{ kind: 'empty' }]);
    expect(h.webhookEventRepository.claimNextPending).toHaveBeenCalledTimes(1);
  });

  it('runs up to `limit` events when the queue stays non-empty', async () => {
    // claim returns the same row on every call; not realistic but enough
    // to verify the loop respects `limit`.
    const claimed = baseEvent();
    const h = buildHarness({ claimed });
    const results = await h.processor.processBatch(3);
    expect(results).toHaveLength(3);
    for (const r of results) {
      expect(r.kind).toBe('processed');
    }
    expect(h.webhookEventRepository.claimNextPending).toHaveBeenCalledTimes(3);
  });
});

// ────────────────────────────────────────────────────────────────────
// Claim partition filter (Fase 1)
// ────────────────────────────────────────────────────────────────────

describe('WebhookEventProcessor claim partition filter', () => {
  it('forwards the configured filter to claimNextPending', async () => {
    const filter: WebhookEventClaimFilter = { operationType: 'cash_in', normalizedStatus: 'paid' };
    const h = buildHarness({ claimed: baseEvent(), claimFilter: filter });

    await h.processor.processNext();

    const call = (h.webhookEventRepository.claimNextPending as unknown as {
      mock: { calls: Array<[Sql, WebhookEventClaimInput]> };
    }).mock.calls[0]!;
    expect(call[1].filter).toEqual(filter);
  });

  it('omits the filter entirely when none is configured (drains whole queue)', async () => {
    const h = buildHarness({ claimed: baseEvent() });

    await h.processor.processNext();

    const call = (h.webhookEventRepository.claimNextPending as unknown as {
      mock: { calls: Array<[Sql, WebhookEventClaimInput]> };
    }).mock.calls[0]!;
    expect(call[1].filter).toBeUndefined();
  });
});

// ────────────────────────────────────────────────────────────────────
// Worker id passthrough
// ────────────────────────────────────────────────────────────────────

describe('WebhookEventProcessor — workerId tagging', () => {
  it('stamps the configured workerId on every attempt row', async () => {
    const h = buildHarness({ claimed: baseEvent(), workerId: 'worker-7' });
    await h.processor.processNext();
    expect(h.calls.attempts[0]!.workerId).toBe('worker-7');
  });

  it('falls back to a null workerId when not configured', async () => {
    const h = buildHarness({ claimed: baseEvent() });
    await h.processor.processNext();
    expect(h.calls.attempts[0]!.workerId).toBeNull();
  });
});

// ────────────────────────────────────────────────────────────────────
// Stale processing reaper
// ────────────────────────────────────────────────────────────────────

describe('WebhookEventProcessor — stale processing reaper', () => {
  it('calls reclaimStaleProcessing before claiming the next row', async () => {
    const fixedNow = new Date('2026-05-28T10:00:00Z');
    const h = buildHarness({ claimed: null, now: () => fixedNow });

    await h.processor.processNext();

    expect(h.webhookEventRepository.reclaimStaleProcessing).toHaveBeenCalledOnce();
    // staleBefore should be fixedNow - 5 min = 09:55:00
    const [, staleBefore] = (
      h.webhookEventRepository.reclaimStaleProcessing as ReturnType<typeof vi.fn>
    ).mock.calls[0] as [unknown, Date];
    expect(staleBefore).toEqual(new Date('2026-05-28T09:55:00Z'));
  });

  it('does not throw if reclaimStaleProcessing rejects (non-fatal)', async () => {
    const h = buildHarness({ claimed: null });
    (h.webhookEventRepository.reclaimStaleProcessing as ReturnType<typeof vi.fn>).mockRejectedValueOnce(
      new Error('db connection lost')
    );
    await expect(h.processor.processNext()).resolves.toEqual({ kind: 'empty' });
  });
});

// ────────────────────────────────────────────────────────────────────
// claimLatencyMs
// ────────────────────────────────────────────────────────────────────

describe('WebhookEventProcessor — claimLatencyMs', () => {
  it('includes claimLatencyMs in non-empty outcomes', async () => {
    const receivedAt = new Date('2026-05-28T10:00:00.000Z');
    const claimedAt = new Date('2026-05-28T10:00:00.300Z');
    const h = buildHarness({
      claimed: baseEvent({ receivedAt }),
      now: () => claimedAt
    });
    const result = await h.processor.processNext();
    expect(result.kind).toBe('processed');
    // claimLatencyMs ≈ 300ms (claimedAt - receivedAt)
    expect((result as { claimLatencyMs?: number }).claimLatencyMs).toBe(300);
  });

  it('does not include claimLatencyMs in empty outcome', async () => {
    const h = buildHarness({ claimed: null });
    const result = await h.processor.processNext();
    expect(result).toEqual({ kind: 'empty' });
  });
});
