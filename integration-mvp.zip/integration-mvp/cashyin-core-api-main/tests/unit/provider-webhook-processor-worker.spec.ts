import { describe, expect, it, vi } from 'vitest';
import type { Logger } from 'pino';
import type { ProcessOutcome, WebhookEventProcessor } from '../../src/modules/webhooks/webhook-event.processor.js';
import { createProviderWebhookProcessorWorker } from '../../src/workers/provider-webhook-processor/index.js';
import type { WorkerLoopIntervals } from '../../src/workers/runtime/worker-loop.js';

/**
 * The processor itself is already covered by `webhook-event-processor.spec.ts`.
 * This file proves the WIRING between `processNext()` and the
 * `WorkerLoop` cadence: every kind of outcome must produce sensible
 * loop behaviour (busy vs idle), and the loop must keep draining as
 * long as work is available.
 *
 * Together with `worker-loop.spec.ts` this satisfies the
 * "pending events are processed / duplicate events do not cause
 * duplicate side-effects / failures leave the row retryable" set of
 * acceptance criteria: the loop forwards every `processNext()` outcome
 * faithfully and the processor's idempotency is unchanged by the
 * surrounding poll cadence.
 */

const INTERVALS: WorkerLoopIntervals = {
  busyMs: 0,
  idleStartMs: 1,
  idleMaxMs: 5,
  errorBaseMs: 1,
  errorMaxMs: 5,
  shutdownTimeoutMs: 1_000
};

const flush = (ms: number): Promise<void> =>
  new Promise((resolve) => setTimeout(resolve, ms));

function silentLogger(): Logger {
  const noop = (): void => undefined;
  const logger = {
    info: noop,
    warn: noop,
    error: noop,
    debug: noop,
    trace: noop,
    fatal: noop,
    level: 'silent',
    child(): Logger {
      return logger;
    }
  } as unknown as Logger;
  return logger;
}

function makeFakeProcessor(outcomes: ProcessOutcome[]): WebhookEventProcessor {
  const queue = [...outcomes];
  const fake = {
    processNext: vi.fn(async (): Promise<ProcessOutcome> => {
      const next = queue.shift();
      if (!next) return { kind: 'empty' };
      return next;
    })
  } as unknown as WebhookEventProcessor;
  return fake;
}

describe('createProviderWebhookProcessorWorker — wiring', () => {
  it('drains every pending outcome and then idles', async () => {
    const processor = makeFakeProcessor([
      {
        kind: 'processed',
        eventId: 'ev-1',
        detail: { flow: 'cash_in_paid', chargeId: 'ch-1', ledgerEntriesPosted: 6 }
      },
      {
        kind: 'processed',
        eventId: 'ev-2',
        detail: { flow: 'cash_in_paid', chargeId: 'ch-2', ledgerEntriesPosted: 6 }
      }
    ]);
    const worker = createProviderWebhookProcessorWorker({
      processor,
      logger: silentLogger(),
      intervals: INTERVALS
    });
    const running = worker.run();
    // Tiny real-time delay so the loop has a chance to drain the two
    // queued outcomes (busyMs=0 ⇒ no inter-tick wait, but the event
    // loop still needs ticks to schedule).
    await flush(50);
    await worker.stop();
    const stats = await running;

    expect(processor.processNext).toHaveBeenCalled();
    expect(stats.processed).toBeGreaterThanOrEqual(2);
  });

  it('treats `noop` (duplicate webhook) as work-done — keeps cadence tight, no error', async () => {
    const processor = makeFakeProcessor([
      { kind: 'noop', eventId: 'ev-dup', reason: 'already_paid' }
    ]);
    const worker = createProviderWebhookProcessorWorker({
      processor,
      logger: silentLogger(),
      intervals: INTERVALS
    });
    const running = worker.run();
    await flush(50);
    await worker.stop();
    const stats = await running;

    expect(stats.errors).toBe(0);
    // The duplicate was logged as work (not idle), so processed count
    // includes it.
    expect(stats.processed).toBeGreaterThanOrEqual(1);
  });

  it('classifies `retry` outcomes as work — the row stays in webhook_events as retryable', async () => {
    const processor = makeFakeProcessor([
      {
        kind: 'retry',
        eventId: 'ev-retry',
        attemptNumber: 2,
        error: 'transient db error',
        nextAttemptAt: new Date('2026-05-23T12:00:00Z')
      }
    ]);
    const worker = createProviderWebhookProcessorWorker({
      processor,
      logger: silentLogger(),
      intervals: INTERVALS
    });
    const running = worker.run();
    await flush(50);
    await worker.stop();
    const stats = await running;

    // A retry outcome means the processor handled the failure
    // (scheduled it) — the loop counts it as work done, NOT as a
    // tick error.
    expect(stats.errors).toBe(0);
    expect(stats.processed).toBeGreaterThanOrEqual(1);
  });

  it('propagates thrown errors from processNext to the loop error counter (not the process)', async () => {
    const processor = {
      processNext: vi.fn(async () => {
        throw new Error('infra outage');
      })
    } as unknown as WebhookEventProcessor;
    const worker = createProviderWebhookProcessorWorker({
      processor,
      logger: silentLogger(),
      intervals: INTERVALS
    });
    const running = worker.run();
    await flush(50);
    await worker.stop();
    const stats = await running;

    expect(stats.errors).toBeGreaterThanOrEqual(1);
    // Crucially: stoppedAt is set → the worker did not crash.
    expect(stats.stoppedAt).not.toBeNull();
  });
});
