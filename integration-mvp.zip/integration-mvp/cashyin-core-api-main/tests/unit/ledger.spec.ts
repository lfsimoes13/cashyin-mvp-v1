import { describe, expect, it, vi } from 'vitest';
import { LedgerService } from '../../src/modules/ledger/ledger.service.js';
import type {
  LedgerAccountRepository,
  LedgerAccountRecord,
  LedgerAccountScope
} from '../../src/modules/ledger/ledger-account.repository.js';
import type { LedgerIdempotencyKeyRepository } from '../../src/modules/ledger/ledger-idempotency.repository.js';
import type {
  LedgerEntryInsertInput,
  LedgerEntryRecord,
  LedgerEntryRepository
} from '../../src/modules/ledger/ledger.repository.js';
import type { Sql } from '../../src/shared/db/sql.js';
import { AppError } from '../../src/shared/errors/app-error.js';

class AlwaysAcceptIdempotencyRepository implements LedgerIdempotencyKeyRepository {
  public attempts: string[] = [];
  async tryAcquire(_sql: Sql, key: string): Promise<boolean> {
    this.attempts.push(key);
    return true;
  }
}

class AlwaysRejectIdempotencyRepository implements LedgerIdempotencyKeyRepository {
  public attempts: string[] = [];
  async tryAcquire(_sql: Sql, key: string): Promise<boolean> {
    this.attempts.push(key);
    return false;
  }
}

class StubAccountRepository implements LedgerAccountRepository {
  async ensure(_sql: Sql, scope: LedgerAccountScope): Promise<LedgerAccountRecord> {
    const id =
      scope.kind === 'system'
        ? `account-system-${scope.accountType}`
        : `account-${scope.kind}-${scope.accountType}`;
    return {
      id,
      clientId: scope.kind === 'client' ? scope.clientId : null,
      providerAccountId: scope.kind === 'provider' ? scope.providerAccountId : null,
      accountType: scope.accountType,
      currency: 'BRL'
    };
  }
}

class CapturingEntryRepository implements LedgerEntryRepository {
  public lastBatch: LedgerEntryInsertInput[] = [];

  async appendBatch(_sql: Sql, entries: LedgerEntryInsertInput[]): Promise<LedgerEntryRecord[]> {
    this.lastBatch = entries;
    return entries.map((entry, index) => ({
      id: `entry-${index + 1}`,
      transactionId: entry.transactionId,
      accountId: entry.accountId,
      clientId: entry.clientId,
      providerName: entry.providerName,
      providerReferenceId: entry.providerReferenceId,
      direction: entry.direction,
      amountCents: entry.amountCents,
      currency: 'BRL',
      reason: entry.reason,
      createdAt: new Date('2026-05-22T00:00:00.000Z')
    }));
  }
}

const stubSql = {} as Sql;

describe('LedgerService.appendEntries', () => {
  it('persists a balanced double-entry batch', async () => {
    const entries = new CapturingEntryRepository();
    const service = new LedgerService(entries, new StubAccountRepository());

    const inserted = await service.appendEntries(stubSql, [
      {
        transactionId: 'tx-1',
        accountId: 'a-1',
        clientId: 'c-1',
        direction: 'debit',
        amountCents: 1500,
        reason: 'pix_charge.confirmed'
      },
      {
        transactionId: 'tx-1',
        accountId: 'a-2',
        clientId: 'c-1',
        direction: 'credit',
        amountCents: 1500,
        reason: 'pix_charge.confirmed'
      }
    ]);

    expect(inserted).toHaveLength(2);
    expect(entries.lastBatch).toHaveLength(2);
    expect(entries.lastBatch[0]?.metadata).toEqual({});
    expect(entries.lastBatch[0]?.providerName).toBeNull();
  });

  it('rejects unbalanced batches', async () => {
    const entries = new CapturingEntryRepository();
    const service = new LedgerService(entries, new StubAccountRepository());

    const promise = service.appendEntries(stubSql, [
      {
        transactionId: 'tx-1',
        accountId: 'a-1',
        clientId: 'c-1',
        direction: 'debit',
        amountCents: 1500,
        reason: 'pix_charge.confirmed'
      },
      {
        transactionId: 'tx-1',
        accountId: 'a-2',
        clientId: 'c-1',
        direction: 'credit',
        amountCents: 1499,
        reason: 'pix_charge.confirmed'
      }
    ]);

    await expect(promise).rejects.toBeInstanceOf(AppError);
    await expect(promise).rejects.toMatchObject({ code: 'ledger_not_balanced' });
  });

  it('requires at least two entries', async () => {
    const service = new LedgerService(
      new CapturingEntryRepository(),
      new StubAccountRepository()
    );

    const promise = service.appendEntries(stubSql, [
      {
        transactionId: 'tx-1',
        accountId: 'a-1',
        clientId: 'c-1',
        direction: 'debit',
        amountCents: 1500,
        reason: 'pix_charge.confirmed'
      }
    ]);

    await expect(promise).rejects.toMatchObject({ code: 'ledger_double_entry_required' });
  });

  it('rejects non-positive amounts', async () => {
    const service = new LedgerService(
      new CapturingEntryRepository(),
      new StubAccountRepository()
    );

    const promise = service.appendEntries(stubSql, [
      {
        transactionId: 'tx-1',
        accountId: 'a-1',
        clientId: 'c-1',
        direction: 'debit',
        amountCents: 0,
        reason: 'pix_charge.confirmed'
      },
      {
        transactionId: 'tx-1',
        accountId: 'a-2',
        clientId: 'c-1',
        direction: 'credit',
        amountCents: 0,
        reason: 'pix_charge.confirmed'
      }
    ]);

    await expect(promise).rejects.toMatchObject({ code: 'ledger_amount_invalid' });
  });

  it('forwards the configured executor and metadata to the repository', async () => {
    const entries = new CapturingEntryRepository();
    const appendSpy = vi.spyOn(entries, 'appendBatch');
    const service = new LedgerService(entries, new StubAccountRepository());

    await service.appendEntries(stubSql, [
      {
        transactionId: 'tx-1',
        accountId: 'a-1',
        clientId: 'c-1',
        direction: 'debit',
        amountCents: 1500,
        reason: 'cashout.reserved',
        metadata: { source: 'test' }
      },
      {
        transactionId: 'tx-1',
        accountId: 'a-2',
        clientId: 'c-1',
        direction: 'credit',
        amountCents: 1500,
        reason: 'cashout.reserved'
      }
    ]);

    expect(appendSpy).toHaveBeenCalledTimes(1);
    expect(entries.lastBatch[0]?.metadata).toEqual({ source: 'test' });
    expect(entries.lastBatch[1]?.metadata).toEqual({});
  });
});

// -----------------------------------------------------------------------------
// Phase 5: LedgerService.postFeeAssessment
// -----------------------------------------------------------------------------

import type { FeeAssessmentPosting } from '../../src/modules/ledger/ledger.service.js';

function basePosting(overrides: Partial<FeeAssessmentPosting> = {}): FeeAssessmentPosting {
  return {
    transactionId: 'charge-1',
    triggerEvent: 'cash_in_paid',
    operationType: 'cash_in',
    clientId: 'client-1',
    providerName: 'bents',
    providerAccountId: 'acc-1',
    providerReferenceId: 'ch_1',
    principalAmountCents: 1500,
    clientFeeCents: 15,
    providerCostCents: 5,
    subsidyCents: 0,
    feeAssessmentId: 'fee-1',
    ...overrides
  };
}

function sumByDirection(batch: LedgerEntryInsertInput[]): { debit: number; credit: number } {
  let debit = 0;
  let credit = 0;
  for (const entry of batch) {
    if (entry.direction === 'debit') debit += entry.amountCents;
    else credit += entry.amountCents;
  }
  return { debit, credit };
}

describe('LedgerService.postFeeAssessment — cash-in', () => {
  it('builds a balanced 6-entry batch for principal + client_fee + provider_cost', async () => {
    const entries = new CapturingEntryRepository();
    const service = new LedgerService(entries, new StubAccountRepository());

    await service.postFeeAssessment(stubSql, basePosting());

    expect(entries.lastBatch).toHaveLength(6);
    const totals = sumByDirection(entries.lastBatch);
    expect(totals.debit).toBe(totals.credit);
    expect(totals.debit).toBe(1500 + 15 + 5);

    const reasons = entries.lastBatch.map((e) => e.reason);
    expect(reasons).toEqual(
      expect.arrayContaining([
        'cash_in.principal.debit',
        'cash_in.principal.credit',
        'cash_in.client_fee.debit',
        'cash_in.client_fee.credit',
        'cash_in.provider_cost.debit',
        'cash_in.provider_cost.credit'
      ])
    );
  });

  it('debits provider_clearing and credits client_liability for principal in cash-in', async () => {
    const entries = new CapturingEntryRepository();
    const service = new LedgerService(entries, new StubAccountRepository());

    await service.postFeeAssessment(stubSql, basePosting());

    const principalDebit = entries.lastBatch.find((e) => e.reason === 'cash_in.principal.debit');
    const principalCredit = entries.lastBatch.find((e) => e.reason === 'cash_in.principal.credit');
    expect(principalDebit?.accountId).toBe('account-provider-provider_clearing');
    expect(principalCredit?.accountId).toBe('account-client-client_liability');
  });

  it('skips the client_fee pair when fee is zero (no subsidy when cost is also zero)', async () => {
    const entries = new CapturingEntryRepository();
    const service = new LedgerService(entries, new StubAccountRepository());

    await service.postFeeAssessment(
      stubSql,
      basePosting({ clientFeeCents: 0, providerCostCents: 0, subsidyCents: 0 })
    );

    const reasons = entries.lastBatch.map((e) => e.reason);
    expect(reasons.filter((r) => r.includes('client_fee'))).toHaveLength(0);
    expect(entries.lastBatch).toHaveLength(2);
    const totals = sumByDirection(entries.lastBatch);
    expect(totals.debit).toBe(totals.credit);
  });

  it('skips the provider_cost pair when cost is zero', async () => {
    const entries = new CapturingEntryRepository();
    const service = new LedgerService(entries, new StubAccountRepository());

    await service.postFeeAssessment(stubSql, basePosting({ providerCostCents: 0 }));

    const reasons = entries.lastBatch.map((e) => e.reason);
    expect(reasons.filter((r) => r.includes('provider_cost'))).toHaveLength(0);
    expect(entries.lastBatch).toHaveLength(4);
    const totals = sumByDirection(entries.lastBatch);
    expect(totals.debit).toBe(totals.credit);
  });

  it('adds the subsidy pair when subsidy > 0 and keeps the batch balanced', async () => {
    const entries = new CapturingEntryRepository();
    const service = new LedgerService(entries, new StubAccountRepository());

    await service.postFeeAssessment(
      stubSql,
      basePosting({ clientFeeCents: 0, providerCostCents: 10, subsidyCents: 10 })
    );

    expect(entries.lastBatch).toHaveLength(6);
    const reasons = entries.lastBatch.map((e) => e.reason);
    expect(reasons).toEqual(
      expect.arrayContaining(['cash_in.subsidy.debit', 'cash_in.subsidy.credit'])
    );
    const totals = sumByDirection(entries.lastBatch);
    expect(totals.debit).toBe(totals.credit);
  });

  it('rejects an inconsistent subsidy magnitude', async () => {
    const service = new LedgerService(
      new CapturingEntryRepository(),
      new StubAccountRepository()
    );
    await expect(
      service.postFeeAssessment(
        stubSql,
        basePosting({ clientFeeCents: 0, providerCostCents: 10, subsidyCents: 5 })
      )
    ).rejects.toMatchObject({ code: 'ledger_subsidy_inconsistent' });
  });
});

describe('LedgerService.postFeeAssessment — cash-out', () => {
  it('debits client_liability and credits provider_clearing for principal in cash-out', async () => {
    const entries = new CapturingEntryRepository();
    const service = new LedgerService(entries, new StubAccountRepository());

    await service.postFeeAssessment(
      stubSql,
      basePosting({ operationType: 'cash_out', triggerEvent: 'cash_out_confirmed' })
    );

    const principalDebit = entries.lastBatch.find((e) => e.reason === 'cash_out.principal.debit');
    const principalCredit = entries.lastBatch.find((e) => e.reason === 'cash_out.principal.credit');
    expect(principalDebit?.accountId).toBe('account-client-client_liability');
    expect(principalCredit?.accountId).toBe('account-provider-provider_clearing');
    const totals = sumByDirection(entries.lastBatch);
    expect(totals.debit).toBe(totals.credit);
  });
});

describe('LedgerService.postFeeAssessment — metadata propagation', () => {
  it('stamps every entry with the feeAssessmentId, triggerEvent and operationType', async () => {
    const entries = new CapturingEntryRepository();
    const service = new LedgerService(entries, new StubAccountRepository());

    await service.postFeeAssessment(
      stubSql,
      basePosting({
        metadata: { chargeExternalId: 'ext-42' }
      })
    );

    for (const entry of entries.lastBatch) {
      expect(entry.metadata).toMatchObject({
        feeAssessmentId: 'fee-1',
        triggerEvent: 'cash_in_paid',
        operationType: 'cash_in',
        chargeExternalId: 'ext-42'
      });
    }
  });
});

// -----------------------------------------------------------------------------
// Phase 8: LedgerService.postCashoutReturnReversal
// -----------------------------------------------------------------------------

import type { CashoutReturnReversalPosting } from '../../src/modules/ledger/ledger.service.js';

function baseReversal(
  overrides: Partial<CashoutReturnReversalPosting> = {}
): CashoutReturnReversalPosting {
  return {
    transactionId: 'cashout-1',
    clientId: 'client-1',
    providerName: 'bents',
    providerAccountId: 'acc-1',
    providerReferenceId: 'pay_1',
    principalAmountCents: 2500,
    feeAssessmentId: 'fee-cashout-1',
    ...overrides
  };
}

describe('LedgerService.postCashoutReturnReversal', () => {
  it('debits provider_clearing and credits client_liability for the principal', async () => {
    const entries = new CapturingEntryRepository();
    const service = new LedgerService(entries, new StubAccountRepository());

    await service.postCashoutReturnReversal(stubSql, baseReversal());

    expect(entries.lastBatch).toHaveLength(2);
    const debit = entries.lastBatch.find((e) => e.direction === 'debit');
    const credit = entries.lastBatch.find((e) => e.direction === 'credit');
    expect(debit?.accountId).toBe('account-provider-provider_clearing');
    expect(credit?.accountId).toBe('account-client-client_liability');
    expect(debit?.reason).toBe('cash_out.principal.reversal.debit');
    expect(credit?.reason).toBe('cash_out.principal.reversal.credit');
    expect(debit?.amountCents).toBe(2500);
    expect(credit?.amountCents).toBe(2500);
  });

  it('keeps the reversal batch balanced (sum of debit = sum of credit)', async () => {
    const entries = new CapturingEntryRepository();
    const service = new LedgerService(entries, new StubAccountRepository());

    await service.postCashoutReturnReversal(stubSql, baseReversal({ principalAmountCents: 9999 }));

    const totals = sumByDirection(entries.lastBatch);
    expect(totals.debit).toBe(totals.credit);
    expect(totals.debit).toBe(9999);
  });

  it('stamps every entry with cash_out_returned metadata and the audit fee_assessment id', async () => {
    const entries = new CapturingEntryRepository();
    const service = new LedgerService(entries, new StubAccountRepository());

    await service.postCashoutReturnReversal(
      stubSql,
      baseReversal({
        feeAssessmentId: 'fee-cashout-42',
        metadata: { cashoutExternalId: 'ext-42' }
      })
    );

    for (const entry of entries.lastBatch) {
      expect(entry.metadata).toMatchObject({
        triggerEvent: 'cash_out_returned',
        operationType: 'cash_out',
        feeAssessmentId: 'fee-cashout-42',
        cashoutExternalId: 'ext-42'
      });
    }
  });

  it('omits feeAssessmentId from metadata when the original assessment was not found', async () => {
    const entries = new CapturingEntryRepository();
    const service = new LedgerService(entries, new StubAccountRepository());

    await service.postCashoutReturnReversal(stubSql, baseReversal({ feeAssessmentId: null }));

    for (const entry of entries.lastBatch) {
      expect(entry.metadata).not.toHaveProperty('feeAssessmentId');
    }
  });

  it('rejects a non-positive principal', async () => {
    const service = new LedgerService(
      new CapturingEntryRepository(),
      new StubAccountRepository()
    );

    await expect(
      service.postCashoutReturnReversal(stubSql, baseReversal({ principalAmountCents: 0 }))
    ).rejects.toMatchObject({ code: 'ledger_reversal_principal_invalid' });
  });

  it('omits fee entries when clientFeeCents is not supplied (defaults to 0, principal-only batch)', async () => {
    const entries = new CapturingEntryRepository();
    const service = new LedgerService(entries, new StubAccountRepository());

    // No clientFeeCents → only the principal pair
    await service.postCashoutReturnReversal(stubSql, baseReversal());

    expect(entries.lastBatch).toHaveLength(2);
    const touchedAccounts = entries.lastBatch.map((e) => e.accountId);
    expect(touchedAccounts).not.toContain('account-system-system:cashyin_fee_revenue');
  });

  it('includes fee reversal entries when clientFeeCents > 0 (fee-refund policy)', async () => {
    const entries = new CapturingEntryRepository();
    const service = new LedgerService(entries, new StubAccountRepository());

    await service.postCashoutReturnReversal(
      stubSql,
      baseReversal({ clientFeeCents: 15 })
    );

    // 2 principal entries + 2 fee entries
    expect(entries.lastBatch).toHaveLength(4);

    const feeDebit = entries.lastBatch.find((e) => e.reason === 'cash_out.fee.reversal.debit');
    const feeCredit = entries.lastBatch.find((e) => e.reason === 'cash_out.fee.reversal.credit');
    expect(feeDebit?.accountId).toBe('account-system-system:cashyin_fee_revenue');
    expect(feeCredit?.accountId).toBe('account-client-client_liability');
    expect(feeDebit?.amountCents).toBe(15);
    expect(feeCredit?.amountCents).toBe(15);
  });

  it('keeps the batch balanced with clientFeeCents > 0', async () => {
    const entries = new CapturingEntryRepository();
    const service = new LedgerService(entries, new StubAccountRepository());

    await service.postCashoutReturnReversal(
      stubSql,
      baseReversal({ principalAmountCents: 2500, clientFeeCents: 15 })
    );

    const totals = sumByDirection(entries.lastBatch);
    expect(totals.debit).toBe(totals.credit);
    expect(totals.debit).toBe(2515);
  });
});

// -----------------------------------------------------------------------------
// Idempotency + null-assessment behaviour (fix/cash-in-paid-ledger-credit)
// -----------------------------------------------------------------------------

describe('LedgerService.postFeeAssessment — idempotency', () => {
  it('returns first_post and posts the batch when the idempotency key is fresh', async () => {
    const entries = new CapturingEntryRepository();
    const idempotency = new AlwaysAcceptIdempotencyRepository();
    const service = new LedgerService(entries, new StubAccountRepository(), idempotency);

    const result = await service.postFeeAssessment(stubSql, basePosting());

    expect(result.kind).toBe('first_post');
    if (result.kind === 'first_post') {
      expect(result.entries).toHaveLength(6);
    }
    expect(idempotency.attempts).toEqual(['cash_in_paid:charge-1']);
    expect(entries.lastBatch.every((e) => e.metadata.idempotencyKey === 'cash_in_paid:charge-1')).toBe(true);
  });

  it('returns duplicate_skipped and does NOT post when the idempotency key is already claimed', async () => {
    const entries = new CapturingEntryRepository();
    const idempotency = new AlwaysRejectIdempotencyRepository();
    const appendSpy = vi.spyOn(entries, 'appendBatch');
    const service = new LedgerService(entries, new StubAccountRepository(), idempotency);

    const result = await service.postFeeAssessment(stubSql, basePosting());

    expect(result.kind).toBe('duplicate_skipped');
    if (result.kind === 'duplicate_skipped') {
      expect(result.idempotencyKey).toBe('cash_in_paid:charge-1');
    }
    expect(appendSpy).not.toHaveBeenCalled();
  });

  it('derives the idempotency key from triggerEvent + transactionId', async () => {
    const entries = new CapturingEntryRepository();
    const idempotency = new AlwaysAcceptIdempotencyRepository();
    const service = new LedgerService(entries, new StubAccountRepository(), idempotency);

    await service.postFeeAssessment(
      stubSql,
      basePosting({
        triggerEvent: 'cash_out_completed',
        transactionId: 'cashout-99',
        operationType: 'cash_out'
      })
    );

    expect(idempotency.attempts).toEqual(['cash_out_completed:cashout-99']);
  });
});

describe('LedgerService.postFeeAssessment — null fee_assessment (no pricing rules)', () => {
  it('posts only the principal pair when feeAssessmentId is null and fees are zero', async () => {
    const entries = new CapturingEntryRepository();
    const service = new LedgerService(entries, new StubAccountRepository());

    const result = await service.postFeeAssessment(
      stubSql,
      basePosting({
        feeAssessmentId: null,
        clientFeeCents: 0,
        providerCostCents: 0,
        subsidyCents: 0
      })
    );

    expect(result.kind).toBe('first_post');
    if (result.kind === 'first_post') {
      expect(result.entries).toHaveLength(2);
    }
    const reasons = entries.lastBatch.map((e) => e.reason);
    expect(reasons).toEqual(
      expect.arrayContaining(['cash_in.principal.debit', 'cash_in.principal.credit'])
    );
  });

  it('omits feeAssessmentId from entry metadata when null (no DB FK to a non-existent row)', async () => {
    const entries = new CapturingEntryRepository();
    const service = new LedgerService(entries, new StubAccountRepository());

    await service.postFeeAssessment(
      stubSql,
      basePosting({
        feeAssessmentId: null,
        clientFeeCents: 0,
        providerCostCents: 0,
        subsidyCents: 0
      })
    );

    for (const entry of entries.lastBatch) {
      expect(entry.metadata).not.toHaveProperty('feeAssessmentId');
      expect(entry.metadata).toMatchObject({
        triggerEvent: 'cash_in_paid',
        operationType: 'cash_in'
      });
    }
  });

  it('rejects a null feeAssessmentId combined with non-zero fees (programming error guard)', async () => {
    const service = new LedgerService(
      new CapturingEntryRepository(),
      new StubAccountRepository()
    );

    await expect(
      service.postFeeAssessment(
        stubSql,
        basePosting({ feeAssessmentId: null, clientFeeCents: 15, providerCostCents: 0, subsidyCents: 0 })
      )
    ).rejects.toMatchObject({ code: 'ledger_null_assessment_with_fees' });
  });
});
