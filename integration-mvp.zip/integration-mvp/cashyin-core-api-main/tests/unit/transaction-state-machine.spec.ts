import { describe, expect, it } from 'vitest';
import {
  allowedNextCashInStatuses,
  allowedNextCashOutStatuses,
  canTransitionCashIn,
  canTransitionCashOut,
  transitionCashIn,
  transitionCashOut
} from '../../src/modules/transactions/state-machine.js';
import { CASH_IN_STATUSES, CASH_OUT_STATUSES } from '../../src/modules/transactions/status.js';

describe('Cash-In state machine', () => {
  it('allows `pending` to transition to each of paid/expired/cancelled/failed', () => {
    expect(canTransitionCashIn('pending', 'paid')).toBe(true);
    expect(canTransitionCashIn('pending', 'expired')).toBe(true);
    expect(canTransitionCashIn('pending', 'cancelled')).toBe(true);
    expect(canTransitionCashIn('pending', 'failed')).toBe(true);
  });

  it('exposes the documented allowed-next-set for `pending`', () => {
    expect([...allowedNextCashInStatuses('pending')].sort()).toEqual(
      ['cancelled', 'expired', 'failed', 'paid'].sort()
    );
  });

  it('rejects every same-status transition with reason `same_status`', () => {
    for (const status of CASH_IN_STATUSES) {
      const result = transitionCashIn(status, status);
      expect(result.ok).toBe(false);
      if (!result.ok) expect(result.reason).toBe('same_status');
    }
  });

  it('allows `paid` to transition to `refunded`', () => {
    expect(canTransitionCashIn('paid', 'refunded')).toBe(true);
  });

  it('rejects transitions out of `refunded` (terminal)', () => {
    expect(allowedNextCashInStatuses('refunded').size).toBe(0);
    for (const to of CASH_IN_STATUSES) {
      if (to === 'refunded') continue;
      expect(canTransitionCashIn('refunded', to)).toBe(false);
    }
  });

  it('rejects transitions out of non-refundable terminal statuses (expired/cancelled/failed)', () => {
    const terminals = ['expired', 'cancelled', 'failed'] as const;
    for (const from of terminals) {
      expect(allowedNextCashInStatuses(from).size).toBe(0);
      for (const to of CASH_IN_STATUSES) {
        if (from === to) continue;
        expect(canTransitionCashIn(from, to)).toBe(false);
      }
    }
  });

  it('returns a structured failure with reason `transition_not_allowed`', () => {
    expect(transitionCashIn('paid', 'pending')).toEqual({
      ok: false,
      from: 'paid',
      to: 'pending',
      reason: 'transition_not_allowed'
    });
  });

  it('returns a structured success on a valid transition', () => {
    expect(transitionCashIn('pending', 'paid')).toEqual({ ok: true, from: 'pending', to: 'paid' });
  });
});

describe('Cash-Out state machine', () => {
  it('allows `processing` to transition to completed/failed/returned', () => {
    expect(canTransitionCashOut('processing', 'completed')).toBe(true);
    expect(canTransitionCashOut('processing', 'failed')).toBe(true);
    expect(canTransitionCashOut('processing', 'returned')).toBe(true);
  });

  it('allows the documented post-success `completed → returned` transition', () => {
    expect(canTransitionCashOut('completed', 'returned')).toBe(true);
  });

  it('rejects `completed → failed` because initial failure and post-success return are different events', () => {
    expect(canTransitionCashOut('completed', 'failed')).toBe(false);
  });

  it('rejects every transition out of `failed`', () => {
    for (const to of CASH_OUT_STATUSES) {
      if (to === 'failed') continue;
      expect(canTransitionCashOut('failed', to)).toBe(false);
    }
    expect(allowedNextCashOutStatuses('failed').size).toBe(0);
  });

  it('rejects every transition out of `returned`', () => {
    for (const to of CASH_OUT_STATUSES) {
      if (to === 'returned') continue;
      expect(canTransitionCashOut('returned', to)).toBe(false);
    }
    expect(allowedNextCashOutStatuses('returned').size).toBe(0);
  });

  it('rejects same-status transitions with reason `same_status`', () => {
    for (const status of CASH_OUT_STATUSES) {
      const result = transitionCashOut(status, status);
      expect(result.ok).toBe(false);
      if (!result.ok) expect(result.reason).toBe('same_status');
    }
  });

  it('returns a structured failure for forbidden transitions', () => {
    expect(transitionCashOut('failed', 'completed')).toEqual({
      ok: false,
      from: 'failed',
      to: 'completed',
      reason: 'transition_not_allowed'
    });
  });

  it('returns a structured success for `completed → returned`', () => {
    expect(transitionCashOut('completed', 'returned')).toEqual({
      ok: true,
      from: 'completed',
      to: 'returned'
    });
  });
});
