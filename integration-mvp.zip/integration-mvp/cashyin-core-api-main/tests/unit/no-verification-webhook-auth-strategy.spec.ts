import { describe, expect, it } from 'vitest';
import { NoVerificationWebhookAuthStrategy } from '../../src/providers/security/no-verification.strategy.js';

describe('NoVerificationWebhookAuthStrategy', () => {
  it('exposes name = no_verification', () => {
    expect(new NoVerificationWebhookAuthStrategy().name).toBe('no_verification');
  });

  it('accepts any request unconditionally', async () => {
    const strategy = new NoVerificationWebhookAuthStrategy();
    const result = await strategy.verify({
      rawBody: Buffer.from('arbitrary content'),
      signature: null,
      headers: {},
      receivedAt: new Date()
    });
    expect(result).toEqual({ valid: true });
  });

  it('still accepts requests that DO carry signature headers (does not inspect them)', async () => {
    const strategy = new NoVerificationWebhookAuthStrategy();
    const result = await strategy.verify({
      rawBody: Buffer.from('{}'),
      signature: 'sha256=any-garbage',
      headers: { 'x-bents-signature': 'sha256=garbage' },
      receivedAt: new Date()
    });
    expect(result).toEqual({ valid: true });
  });

  it('accepts empty bodies', async () => {
    const strategy = new NoVerificationWebhookAuthStrategy();
    const result = await strategy.verify({
      rawBody: Buffer.alloc(0),
      signature: null,
      headers: {},
      receivedAt: new Date()
    });
    expect(result).toEqual({ valid: true });
  });
});
