import { createHmac } from 'node:crypto';
import { describe, expect, it, vi } from 'vitest';
import {
  ClientWebhookDispatcher,
  type ClientWebhookDispatcherDeps,
  type ClientWebhookRetryPolicy,
  type OutboxDispatchClaimFilter
} from '../../src/modules/webhooks/client-webhook.dispatcher.js';
import type {
  ClientWebhookDeliveryAttemptUpdate,
  ClientWebhookDeliveryInsertInput,
  ClientWebhookDeliveryRecord,
  ClientWebhookDeliveryRepository
} from '../../src/modules/webhooks/client-webhook-delivery.repository.js';
import type {
  ClientWebhookEndpointRecord,
  ClientWebhookEndpointRepository
} from '../../src/modules/webhooks/client-webhook-endpoint.repository.js';
import type {
  OutboxClaimInput,
  OutboxEventRecord,
  OutboxRepository,
  OutboxScheduleRetryInput
} from '../../src/modules/outbox/outbox.repository.js';
import type { HttpClient, HttpRequestInput, HttpResponse } from '../../src/shared/http/http-client.js';
import type { Database } from '../../src/shared/db/database.js';
import type { Sql } from '../../src/shared/db/sql.js';
import { metrics } from '../../src/shared/observability/metrics.js';

// ────────────────────────────────────────────────────────────────────
// Fixtures
// ────────────────────────────────────────────────────────────────────

const CLIENT_ID = '00000000-0000-0000-0000-000000000001';
const OUTBOX_ID = 'ob_0001';
const ENDPOINT_ID = 'ep_0001';
const SIGNING_SECRET = 'test-secret-please-replace';

function baseOutboxRecord(overrides: Partial<OutboxEventRecord> = {}): OutboxEventRecord {
  return {
    id: OUTBOX_ID,
    aggregateType: 'cash_in',
    aggregateId: 'ch_001',
    eventType: 'pix.cash_in.paid',
    payload: {
      charge_id: 'ch_001',
      external_ref: 'merchant-ref-001',
      client_id: CLIENT_ID,
      provider: 'bents',
      provider_charge_id: 'provider-ch-001',
      txid: 'tx_001',
      status: 'paid',
      amount: 12_345,
      emv: null,
      description: null,
      created_at: '2026-05-23T19:30:00.000Z',
      paid_at: '2026-05-23T19:45:00.000Z',
      e2e_id: 'E0000000020260523194500abcdef01'
    },
    status: 'processing',
    attempts: 1,
    priority: 10,
    availableAt: new Date('2026-05-23T19:30:00.000Z'),
    createdAt: new Date('2026-05-23T19:30:00.000Z'),
    updatedAt: new Date('2026-05-23T19:30:00.000Z'),
    publishedAt: null,
    ...overrides
  };
}

function baseEndpoint(overrides: Partial<ClientWebhookEndpointRecord> = {}): ClientWebhookEndpointRecord {
  return {
    id: ENDPOINT_ID,
    clientId: CLIENT_ID,
    eventPattern: '*',
    targetUrl: 'https://client.example/webhooks/cashyin',
    signingSecret: SIGNING_SECRET,
    status: 'active',
    description: null,
    lastDeliveredAt: null,
    lastFailureAt: null,
    createdAt: new Date('2026-05-01T00:00:00Z'),
    updatedAt: new Date('2026-05-01T00:00:00Z'),
    ...overrides
  };
}

function baseDelivery(overrides: Partial<ClientWebhookDeliveryRecord> = {}): ClientWebhookDeliveryRecord {
  return {
    id: 'cd_0001',
    outboxEventId: OUTBOX_ID,
    clientId: CLIENT_ID,
    eventId: `evt_${OUTBOX_ID}`,
    eventType: 'pix.cash_in.paid',
    targetUrl: 'https://client.example/webhooks/cashyin',
    payload: {},
    signature: null,
    status: 'pending',
    attemptCount: 0,
    lastHttpStatus: null,
    lastResponseSnippet: null,
    lastError: null,
    nextAttemptAt: new Date('2026-05-23T20:00:00Z'),
    deliveredAt: null,
    firstAttemptStartedAt: null,
    firstAttemptFinishedAt: null,
    createdAt: new Date('2026-05-23T20:00:00Z'),
    updatedAt: new Date('2026-05-23T20:00:00Z'),
    ...overrides
  };
}

type Calls = {
  outboxClaim: Array<OutboxClaimInput>;
  outboxPublished: string[];
  outboxRetry: OutboxScheduleRetryInput[];
  outboxFailed: string[];
  endpointDelivered: Array<{ id: string; at: Date }>;
  endpointFailure: Array<{ id: string; at: Date }>;
  deliveryUpserts: ClientWebhookDeliveryInsertInput[];
  deliveryAttempts: ClientWebhookDeliveryAttemptUpdate[];
  httpRequests: HttpRequestInput[];
  reaperRuns: number;
};

function buildHarness(opts: {
  claimed: OutboxEventRecord | null;
  endpoint?: ClientWebhookEndpointRecord | null;
  upsertedDelivery?: ClientWebhookDeliveryRecord;
  httpResponse?: HttpResponse;
  httpError?: Error;
  retryPolicy?: ClientWebhookRetryPolicy;
  now?: () => Date;
  reaperMinIntervalMs?: number;
  claimFilter?: OutboxDispatchClaimFilter;
  reclaimStaleProcessing?: () => Promise<number>;
} = { claimed: null }) {
  const calls: Calls = {
    outboxClaim: [],
    outboxPublished: [],
    outboxRetry: [],
    outboxFailed: [],
    endpointDelivered: [],
    endpointFailure: [],
    deliveryUpserts: [],
    deliveryAttempts: [],
    httpRequests: [],
    reaperRuns: 0
  };

  const outboxRepository: OutboxRepository = {
    insert: vi.fn(),
    claimNextPending: vi.fn(async (_sql: Sql, input: OutboxClaimInput) => {
      calls.outboxClaim.push(input);
      return opts.claimed;
    }),
    markPublished: vi.fn(async (_sql: Sql, id: string) => {
      calls.outboxPublished.push(id);
    }),
    scheduleRetry: vi.fn(async (_sql: Sql, input: OutboxScheduleRetryInput) => {
      calls.outboxRetry.push(input);
    }),
    markFailed: vi.fn(async (_sql: Sql, id: string) => {
      calls.outboxFailed.push(id);
    }),
    reclaimStaleProcessing: vi.fn(async () => {
      calls.reaperRuns += 1;
      return opts.reclaimStaleProcessing ? opts.reclaimStaleProcessing() : 0;
    })
  };

  const endpointRecord = opts.endpoint === undefined ? baseEndpoint() : opts.endpoint;
  const endpointRepository: ClientWebhookEndpointRepository = {
    findActiveForEvent: vi.fn(async () => endpointRecord),
    markDelivered: vi.fn(async (_sql: Sql, id: string, at: Date) => {
      calls.endpointDelivered.push({ id, at });
    }),
    markFailure: vi.fn(async (_sql: Sql, id: string, at: Date) => {
      calls.endpointFailure.push({ id, at });
    })
  };

  const upsertedDelivery = opts.upsertedDelivery ?? baseDelivery();
  const deliveryRepository: ClientWebhookDeliveryRepository = {
    upsertForOutbox: vi.fn(async (_sql: Sql, input: ClientWebhookDeliveryInsertInput) => {
      calls.deliveryUpserts.push(input);
      return upsertedDelivery;
    }),
    findByOutboxEvent: vi.fn(async () => null),
    applyAttempt: vi.fn(async (_sql: Sql, input: ClientWebhookDeliveryAttemptUpdate) => {
      calls.deliveryAttempts.push(input);
    })
  };

  const httpClient: HttpClient = {
    post: vi.fn(async (input: HttpRequestInput) => {
      calls.httpRequests.push(input);
      if (opts.httpError) throw opts.httpError;
      return opts.httpResponse ?? { statusCode: 200, bodyText: '{"ok":true}' };
    })
  };

  const db: Database = {
    withTransaction: async <T>(fn: (tx: unknown) => Promise<T>): Promise<T> => fn({}),
    pool: {} as unknown
  } as unknown as Database;

  const depsObj: ClientWebhookDispatcherDeps = {
    db,
    outboxRepository,
    endpointRepository,
    deliveryRepository,
    httpClient,
    ...(opts.retryPolicy !== undefined ? { retryPolicy: opts.retryPolicy } : {}),
    ...(opts.now !== undefined ? { now: opts.now } : {}),
    ...(opts.reaperMinIntervalMs !== undefined
      ? { reaperMinIntervalMs: opts.reaperMinIntervalMs }
      : {}),
    ...(opts.claimFilter !== undefined ? { claimFilter: opts.claimFilter } : {})
  };
  const dispatcher = new ClientWebhookDispatcher(depsObj);

  return {
    dispatcher,
    calls,
    outboxRepository,
    endpointRepository,
    deliveryRepository,
    httpClient,
    upsertedDelivery,
    endpointRecord
  };
}

function expectedSignature(envelopeJson: string, secret: string): string {
  return `sha256=${createHmac('sha256', secret).update(envelopeJson).digest('hex')}`;
}

// ────────────────────────────────────────────────────────────────────
// Empty queue
// ────────────────────────────────────────────────────────────────────

describe('ClientWebhookDispatcher.dispatchNext — empty queue', () => {
  it('returns {kind:"empty"} when no outbox row is due', async () => {
    const h = buildHarness({ claimed: null });
    const result = await h.dispatcher.dispatchNext();
    expect(result).toEqual({ kind: 'empty' });
    expect(h.calls.outboxClaim).toHaveLength(1);
    expect(h.calls.outboxClaim[0]).toMatchObject({
      aggregateTypes: ['cash_in', 'cashout']
    });
    expect(h.calls.deliveryUpserts).toHaveLength(0);
    expect(h.calls.httpRequests).toHaveLength(0);
  });
});

// ────────────────────────────────────────────────────────────────────
// Happy path
// ────────────────────────────────────────────────────────────────────

describe('ClientWebhookDispatcher.dispatchNext — delivered', () => {
  it('builds the cash_in.paid envelope, signs the body, persists delivery+endpoint+outbox', async () => {
    const fixedNow = new Date('2026-05-23T20:00:00Z');
    const h = buildHarness({
      claimed: baseOutboxRecord(),
      httpResponse: { statusCode: 200, bodyText: 'OK' },
      now: () => fixedNow
    });

    const result = await h.dispatcher.dispatchNext();

    // 1. Endpoint lookup uses the public event name derived from the
    //    canonical pix.cash_in.paid outbox event → pix.cash_in.paid public envelope.
    expect(h.endpointRepository.findActiveForEvent).toHaveBeenCalledWith(
      expect.anything(),
      CLIENT_ID,
      'pix.cash_in.paid'
    );

    // 2. The upserted delivery row carries the deterministic evt_<outbox>
    //    id, the public event name, target URL, and signed signature.
    expect(h.calls.deliveryUpserts).toHaveLength(1);
    const upsert = h.calls.deliveryUpserts[0]!;
    expect(upsert.outboxEventId).toBe(OUTBOX_ID);
    expect(upsert.clientId).toBe(CLIENT_ID);
    expect(upsert.eventId).toBe(`evt_${OUTBOX_ID}`);
    expect(upsert.eventType).toBe('pix.cash_in.paid');
    expect(upsert.targetUrl).toBe('https://client.example/webhooks/cashyin');
    expect(upsert.signature).toBeTruthy();

    // 3. The HTTP POST body is the JSON-serialised envelope, signed
    //    with the per-client secret using sha256= prefix.
    expect(h.calls.httpRequests).toHaveLength(1);
    const req = h.calls.httpRequests[0]!;
    expect(req.url).toBe('https://client.example/webhooks/cashyin');
    expect(req.headers['content-type']).toBe('application/json');
    expect(req.headers['x-cashyin-signature']).toBe(
      expectedSignature(req.bodyText, SIGNING_SECRET)
    );
    expect(req.headers['x-cashyin-signature']).toBe(upsert.signature);
    const decoded = JSON.parse(req.bodyText) as Record<string, unknown>;
    expect(decoded.event).toBe('pix.cash_in.paid');
    expect(decoded.id).toBe(`evt_${OUTBOX_ID}`);
    const data = decoded.data as Record<string, unknown>;
    expect(data.txid).toBe('tx_001');
    expect(data.external_ref).toBe('merchant-ref-001');
    expect(data.type).toBeUndefined();
    expect(data.status).toBe('paid');
    expect(data.amount).toBe(12_345);
    expect(data.created_at).toBe('2026-05-23T19:30:00.000Z');
    expect(data.paid_at).toBe('2026-05-23T19:45:00.000Z');
    expect((data.pix as Record<string, unknown>).e2e_id).toBe('E0000000020260523194500abcdef01');

    // 4. The single applyAttempt call flips the row to delivered with
    //    httpStatus=200, response snippet, and a deliveredAt = now.
    expect(h.calls.deliveryAttempts).toEqual([
      {
        id: h.upsertedDelivery.id,
        status: 'delivered',
        attemptCount: 1,
        httpStatus: 200,
        responseSnippet: 'OK',
        error: null,
        nextAttemptAt: fixedNow,
        deliveredAt: fixedNow,
        firstAttemptStartedAt: fixedNow,
        firstAttemptFinishedAt: fixedNow
      }
    ]);

    // 5. Endpoint + outbox bookkeeping are flushed in the same txn.
    expect(h.calls.endpointDelivered).toEqual([{ id: ENDPOINT_ID, at: fixedNow }]);
    expect(h.calls.endpointFailure).toHaveLength(0);
    expect(h.calls.outboxPublished).toEqual([OUTBOX_ID]);
    expect(h.calls.outboxRetry).toHaveLength(0);
    expect(h.calls.outboxFailed).toHaveLength(0);

    expect(result).toMatchObject({
      kind: 'delivered',
      outboxEventId: OUTBOX_ID,
      deliveryId: h.upsertedDelivery.id,
      eventId: `evt_${OUTBOX_ID}`,
      eventType: 'pix.cash_in.paid',
      httpStatus: 200
    });
  });

  it('treats any 2xx as a successful delivery', async () => {
    const h = buildHarness({
      claimed: baseOutboxRecord(),
      httpResponse: { statusCode: 204, bodyText: '' }
    });
    const result = await h.dispatcher.dispatchNext();
    expect(result.kind).toBe('delivered');
    expect(h.calls.outboxPublished).toEqual([OUTBOX_ID]);
  });

  it('skips pix.cash_in.created — pending state is NOT dispatched to clients', async () => {
    const h = buildHarness({
      claimed: baseOutboxRecord({
        eventType: 'pix.cash_in.created',
        payload: {
          charge_id: 'ch_001',
          external_ref: 'merchant-ref-001',
          client_id: CLIENT_ID,
          provider: 'bents',
          provider_charge_id: 'provider-ch-001',
          txid: 'tx_001',
          status: 'pending',
          amount: 5_000,
          qr_code: 'br-code',
          qr_code_image: null,
          description: null,
          created_at: '2026-05-23T19:30:00.000Z',
          expires_at: '2026-05-23T20:30:00.000Z'
        }
      })
    });

    const result = await h.dispatcher.dispatchNext();
    expect(result.kind).toBe('skipped');
    expect(h.calls.httpRequests).toHaveLength(0);
    expect(h.calls.outboxPublished).toEqual([OUTBOX_ID]);
  });

  it.each(['expired', 'cancelled', 'failed'] as const)(
    'maps pix.cash_in.%s to the matching public event with correct status and null paid_at',
    async (status) => {
      const h = buildHarness({
        claimed: baseOutboxRecord({
          eventType: `pix.cash_in.${status}`,
          payload: {
            charge_id: 'ch_001',
            external_ref: 'merchant-ref-001',
            client_id: CLIENT_ID,
            provider: 'bents',
            provider_charge_id: 'provider-ch-001',
            txid: 'tx_001',
            status,
            amount: 5_000,
            qr_code: null,
            qr_code_image: null,
            description: null,
            created_at: '2026-05-23T19:30:00.000Z',
            occurred_at: '2026-05-23T19:55:00.000Z'
          }
        })
      });
      await h.dispatcher.dispatchNext();
      const req = h.calls.httpRequests[0]!;
      const decoded = JSON.parse(req.bodyText) as { event: string; data: Record<string, unknown> };
      expect(decoded.event).toBe(`pix.cash_in.${status}`);
      // Terminal status is surfaced via `status` + `event` fields; no separate `*_at` slot.
      expect(decoded.data.status).toBe(status);
      // `paid_at` is omitted (not null) when the charge never settled.
      expect(decoded.data.paid_at).toBeUndefined();
    }
  );
});

// ────────────────────────────────────────────────────────────────────
// Skips
// ────────────────────────────────────────────────────────────────────

describe('ClientWebhookDispatcher.dispatchNext — skips', () => {
  it('skips with no_endpoint_configured when the client has no active endpoint', async () => {
    const h = buildHarness({
      claimed: baseOutboxRecord(),
      endpoint: null
    });
    const result = await h.dispatcher.dispatchNext();
    expect(result).toMatchObject({
      kind: 'skipped',
      outboxEventId: OUTBOX_ID,
      reason: 'no_endpoint_configured'
    });
    // Skipped rows still drain the queue.
    expect(h.calls.outboxPublished).toEqual([OUTBOX_ID]);
    expect(h.calls.outboxFailed).toHaveLength(0);
    expect(h.calls.httpRequests).toHaveLength(0);
    expect(h.calls.deliveryUpserts).toHaveLength(0);
  });

  it('skips with unsupported_event_type when the outbox row is not a pix.cash_in.*', async () => {
    const h = buildHarness({
      claimed: baseOutboxRecord({ eventType: 'pix.cash_in.archived' })
    });
    const result = await h.dispatcher.dispatchNext();
    expect(result).toMatchObject({ kind: 'skipped', reason: 'unsupported_event_type' });
    expect(h.calls.outboxPublished).toEqual([OUTBOX_ID]);
  });

  it('skips with malformed_payload when required fields are missing', async () => {
    const h = buildHarness({
      claimed: baseOutboxRecord({
        payload: {
          charge_id: 'ch_001',
          client_id: CLIENT_ID,
          provider: 'bents',
          status: 'paid',
          amount: 12_345
          // missing external_ref, txid & created_at
        }
      })
    });
    const result = await h.dispatcher.dispatchNext();
    expect(result).toMatchObject({ kind: 'skipped', reason: 'malformed_payload' });
    expect(h.calls.outboxPublished).toEqual([OUTBOX_ID]);
  });

  it('skips with malformed_payload when clientId is missing (no endpoint lookup possible)', async () => {
    const h = buildHarness({
      claimed: baseOutboxRecord({
        payload: {
          charge_id: 'ch_001',
          external_ref: 'merchant-ref-001',
          provider: 'bents',
          provider_charge_id: 'provider-ch-001',
          txid: 'tx_001',
          status: 'paid',
          amount: 12_345,
          created_at: '2026-05-23T19:30:00.000Z'
        }
      })
    });
    const result = await h.dispatcher.dispatchNext();
    expect(result).toMatchObject({ kind: 'skipped', reason: 'malformed_payload' });
    expect(h.endpointRepository.findActiveForEvent).not.toHaveBeenCalled();
  });
});

// ────────────────────────────────────────────────────────────────────
// Retry & DLQ
// ────────────────────────────────────────────────────────────────────

describe('ClientWebhookDispatcher.dispatchNext — failures', () => {
  const fixedNow = new Date('2026-05-23T20:00:00Z');
  const retryPolicy: ClientWebhookRetryPolicy = {
    baseDelayMs: 30_000,
    maxDelayMs: 3_600_000,
    maxAttempts: 3,
    responseSnippetLength: 256,
    requestTimeoutMs: 10_000
  };

  it('schedules a retry when the endpoint returns a 5xx', async () => {
    const h = buildHarness({
      claimed: baseOutboxRecord(),
      httpResponse: { statusCode: 503, bodyText: 'unavailable' },
      now: () => fixedNow,
      retryPolicy
    });

    const result = await h.dispatcher.dispatchNext();

    expect(h.calls.deliveryAttempts).toEqual([
      {
        id: h.upsertedDelivery.id,
        status: 'failed',
        attemptCount: 1,
        httpStatus: 503,
        responseSnippet: 'unavailable',
        error: 'non_2xx_response:503',
        nextAttemptAt: new Date(fixedNow.getTime() + 30_000),
        deliveredAt: null,
        firstAttemptStartedAt: fixedNow,
        firstAttemptFinishedAt: fixedNow
      }
    ]);
    expect(h.calls.outboxRetry).toEqual([
      { id: OUTBOX_ID, availableAt: new Date(fixedNow.getTime() + 30_000) }
    ]);
    expect(h.calls.outboxPublished).toHaveLength(0);
    expect(h.calls.outboxFailed).toHaveLength(0);
    expect(h.calls.endpointFailure).toEqual([{ id: ENDPOINT_ID, at: fixedNow }]);
    expect(h.calls.endpointDelivered).toHaveLength(0);

    expect(result).toMatchObject({
      kind: 'retry',
      outboxEventId: OUTBOX_ID,
      deliveryId: h.upsertedDelivery.id,
      attemptNumber: 1,
      error: 'non_2xx_response:503',
      httpStatus: 503,
      nextAttemptAt: new Date(fixedNow.getTime() + 30_000)
    });
  });

  it('schedules a retry when the HTTP client throws (transport error)', async () => {
    const h = buildHarness({
      claimed: baseOutboxRecord(),
      httpError: new Error('ETIMEDOUT'),
      now: () => fixedNow,
      retryPolicy
    });
    const result = await h.dispatcher.dispatchNext();
    expect(result).toMatchObject({
      kind: 'retry',
      error: 'ETIMEDOUT',
      httpStatus: null,
      nextAttemptAt: new Date(fixedNow.getTime() + 30_000)
    });
    expect(h.calls.deliveryAttempts[0]).toMatchObject({
      status: 'failed',
      httpStatus: null,
      responseSnippet: null,
      error: 'ETIMEDOUT'
    });
  });

  it('doubles the backoff with each subsequent attempt', async () => {
    const upserted = baseDelivery({ attemptCount: 1 });
    const h = buildHarness({
      claimed: baseOutboxRecord(),
      upsertedDelivery: upserted,
      httpResponse: { statusCode: 500, bodyText: 'down' },
      now: () => fixedNow,
      retryPolicy
    });
    const result = await h.dispatcher.dispatchNext();
    // attempt 2 → base * 2^(2-1) = 60_000
    expect(result).toMatchObject({
      kind: 'retry',
      attemptNumber: 2,
      nextAttemptAt: new Date(fixedNow.getTime() + 60_000)
    });
  });

  it('caps the backoff at maxDelayMs', async () => {
    const upserted = baseDelivery({ attemptCount: 10 });
    const h = buildHarness({
      claimed: baseOutboxRecord(),
      upsertedDelivery: upserted,
      httpResponse: { statusCode: 500, bodyText: 'down' },
      now: () => fixedNow,
      retryPolicy: {
        baseDelayMs: 30_000,
        maxDelayMs: 60_000,
        maxAttempts: 100,
        responseSnippetLength: 256,
        requestTimeoutMs: 10_000
      }
    });
    const result = await h.dispatcher.dispatchNext();
    expect(result).toMatchObject({
      kind: 'retry',
      nextAttemptAt: new Date(fixedNow.getTime() + 60_000)
    });
  });

  it('routes to DLQ once attempt count reaches maxAttempts', async () => {
    const upserted = baseDelivery({ attemptCount: 2 });
    const h = buildHarness({
      claimed: baseOutboxRecord(),
      upsertedDelivery: upserted,
      httpResponse: { statusCode: 500, bodyText: 'down' },
      now: () => fixedNow,
      retryPolicy
    });
    const result = await h.dispatcher.dispatchNext();
    expect(result).toMatchObject({
      kind: 'dlq',
      outboxEventId: OUTBOX_ID,
      deliveryId: upserted.id,
      attemptNumber: 3,
      error: 'non_2xx_response:500',
      httpStatus: 500
    });
    expect(h.calls.outboxFailed).toEqual([OUTBOX_ID]);
    expect(h.calls.outboxRetry).toHaveLength(0);
    expect(h.calls.deliveryAttempts[0]).toMatchObject({ status: 'dead_letter' });
  });

  it('truncates oversized response bodies into the persisted snippet', async () => {
    const longBody = 'x'.repeat(1024);
    const h = buildHarness({
      claimed: baseOutboxRecord(),
      httpResponse: { statusCode: 500, bodyText: longBody },
      now: () => fixedNow,
      retryPolicy: { ...retryPolicy, responseSnippetLength: 16 }
    });
    await h.dispatcher.dispatchNext();
    const attempt = h.calls.deliveryAttempts[0]!;
    expect(attempt.responseSnippet).toHaveLength(17); // 16 + ellipsis char
    expect(attempt.responseSnippet?.startsWith('xxxxxxxxxxxxxxxx')).toBe(true);
    expect(attempt.responseSnippet?.endsWith('…')).toBe(true);
  });
});

// ────────────────────────────────────────────────────────────────────
// Signing determinism
// ────────────────────────────────────────────────────────────────────

describe('ClientWebhookDispatcher — signing', () => {
  it('signs the exact bytes that get sent on the wire', async () => {
    const h = buildHarness({
      claimed: baseOutboxRecord(),
      httpResponse: { statusCode: 200, bodyText: '' }
    });
    await h.dispatcher.dispatchNext();
    const req = h.calls.httpRequests[0]!;
    const computed = createHmac('sha256', SIGNING_SECRET).update(req.bodyText).digest('hex');
    expect(req.headers['x-cashyin-signature']).toBe(`sha256=${computed}`);
  });

  it('uses the per-endpoint signing secret, not a global one', async () => {
    const h = buildHarness({
      claimed: baseOutboxRecord(),
      endpoint: baseEndpoint({ signingSecret: 'rotated-secret' }),
      httpResponse: { statusCode: 200, bodyText: '' }
    });
    await h.dispatcher.dispatchNext();
    const req = h.calls.httpRequests[0]!;
    const computed = createHmac('sha256', 'rotated-secret').update(req.bodyText).digest('hex');
    expect(req.headers['x-cashyin-signature']).toBe(`sha256=${computed}`);
  });
});

// ────────────────────────────────────────────────────────────────────
// dispatchBatch
// ────────────────────────────────────────────────────────────────────

describe('ClientWebhookDispatcher.dispatchBatch', () => {
  it('rejects non-positive limits', async () => {
    const h = buildHarness({ claimed: null });
    await expect(h.dispatcher.dispatchBatch(0)).rejects.toThrow(/positive integer/);
    await expect(h.dispatcher.dispatchBatch(-2)).rejects.toThrow(/positive integer/);
    await expect(h.dispatcher.dispatchBatch(2.5)).rejects.toThrow(/positive integer/);
  });

  it('stops on the first empty outcome', async () => {
    const h = buildHarness({ claimed: null });
    const results = await h.dispatcher.dispatchBatch(5);
    expect(results).toEqual([{ kind: 'empty' }]);
    expect(h.outboxRepository.claimNextPending).toHaveBeenCalledTimes(1);
  });

  it('processes up to `limit` events when the queue stays non-empty', async () => {
    const h = buildHarness({ claimed: baseOutboxRecord(), httpResponse: { statusCode: 200, bodyText: '' } });
    const results = await h.dispatcher.dispatchBatch(3);
    expect(results).toHaveLength(3);
    for (const r of results) {
      expect(r.kind).toBe('delivered');
    }
    expect(h.outboxRepository.claimNextPending).toHaveBeenCalledTimes(3);
  });
});

// ────────────────────────────────────────────────────────────────────
// Phase 7 — Cash-out envelopes
// ────────────────────────────────────────────────────────────────────

const CASHOUT_OUTBOX_ID = 'ob_co_0001';

function cashoutOutboxRecord(
  overrides: Partial<{ eventType: string; payload: Record<string, unknown> }> = {}
) {
  return baseOutboxRecord({
    id: CASHOUT_OUTBOX_ID,
    aggregateType: 'cashout',
    aggregateId: 'co_001',
    eventType: overrides.eventType ?? 'pix.cash_out.completed',
    payload: overrides.payload ?? {
      cashoutId: 'co_001',
      externalId: 'merchant-cashout-ref-001',
      clientId: CLIENT_ID,
      provider: 'bents',
      providerPaymentId: 'pay_001',
      status: 'completed',
      amountCents: 7_500,
      pixKey: 'alice@example.com',
      pixKeyType: 'EMAIL',
      receiverName: 'Alice Souza',
      receiverDocument: '12345678901',
      receiverBank: 'A55 SCD S.A.',
      receiverIspb: '48756121',
      createdAt: '2026-05-23T19:30:00.000Z',
      occurredAt: '2026-05-23T19:55:00.000Z',
      e2eId: 'E0000000020260523195500cashout01'
    }
  });
}

describe('ClientWebhookDispatcher.dispatchNext — cash_out happy path', () => {
  it('builds pix.cash_out.completed envelope, signs, persists delivery+outbox', async () => {
    const fixedNow = new Date('2026-05-23T20:00:00Z');
    const h = buildHarness({
      claimed: cashoutOutboxRecord(),
      httpResponse: { statusCode: 200, bodyText: 'OK' },
      now: () => fixedNow
    });

    const result = await h.dispatcher.dispatchNext();

    expect(h.endpointRepository.findActiveForEvent).toHaveBeenCalledWith(
      expect.anything(),
      CLIENT_ID,
      'pix.cash_out.completed'
    );

    const req = h.calls.httpRequests[0]!;
    const decoded = JSON.parse(req.bodyText) as { event: string; data: Record<string, unknown> };
    expect(decoded.event).toBe('pix.cash_out.completed');
    expect(decoded.data.id).toBe('co_001');
    expect(decoded.data.external_ref).toBe('merchant-cashout-ref-001');
    expect(decoded.data.type).toBeUndefined();
    expect(decoded.data.status).toBe('completed');
    expect(decoded.data.amount).toBe(7_500);
    expect(decoded.data.amount_cents).toBeUndefined();
    // Pix key/key_type/e2e_id are nested under `pix`.
    const pix = decoded.data.pix as Record<string, unknown>;
    expect(pix.key).toBe('alice@example.com');
    expect(pix.key_type).toBe('EMAIL');
    expect(pix.e2e_id).toBe('E0000000020260523195500cashout01');
    expect(decoded.data.pix_key).toBeUndefined();
    expect(decoded.data.pix_key_type).toBeUndefined();
    // Receiver identity is exposed only via the nested `receiver` object.
    expect(decoded.data.receiver_name).toBeUndefined();
    expect(decoded.data.receiver_document).toBeUndefined();
    // Canonical nested receiver block (always present, nullable children).
    expect(decoded.data.receiver).toEqual({
      name: 'Alice Souza',
      document_number: '12345678901',
      bank_name: 'A55 SCD S.A.',
      bank_ispb: '48756121',
      branch: null,
      account: null,
      account_type: null
    });
    expect(decoded.data.created_at).toBe('2026-05-23T19:30:00.000Z');
    expect(decoded.data.completed_at).toBe('2026-05-23T19:55:00.000Z');
    expect(decoded.data.e2e_id).toBeUndefined();
    // Cash-out envelopes never carry payer fields.
    expect(decoded.data.payer_name).toBeUndefined();
    expect(decoded.data.payer_document).toBeUndefined();

    expect(h.calls.outboxPublished).toEqual([CASHOUT_OUTBOX_ID]);
    expect(result.kind).toBe('delivered');
  });

  it.each(['completed', 'failed', 'returned'] as const)(
    'emits pix.cash_out.%s envelope with the matching timestamp slot',
    async (status) => {
      const h = buildHarness({
        claimed: cashoutOutboxRecord({
          eventType: `pix.cash_out.${status}`,
          payload: {
            cashoutId: 'co_001',
            externalId: 'merchant-cashout-ref-001',
            clientId: CLIENT_ID,
            provider: 'bents',
            providerPaymentId: 'pay_001',
          status,
          amountCents: 7_500,
          pixKey: 'alice@example.com',
          pixKeyType: 'EMAIL',
          createdAt: '2026-05-23T19:30:00.000Z',
          occurredAt: '2026-05-23T19:55:00.000Z'
        }
        })
      });
      await h.dispatcher.dispatchNext();
      const req = h.calls.httpRequests[0]!;
      const decoded = JSON.parse(req.bodyText) as {
        event: string;
        data: Record<string, unknown>;
      };
      expect(decoded.event).toBe(`pix.cash_out.${status}`);
      expect(decoded.data[`${status}_at`]).toBe('2026-05-23T19:55:00.000Z');
    }
  );

  it.each(['pix.cash_out.initiated', 'pix.cash_out.processing'] as const)(
    'never sends a public pix.cash_out.processing webhook for %s (skips and drains the queue)',
    async (eventType) => {
      const h = buildHarness({
        claimed: cashoutOutboxRecord({
          eventType,
          payload: {
            cashoutId: 'co_001',
            externalId: 'merchant-cashout-ref-001',
            clientId: CLIENT_ID,
            provider: 'bents',
            providerPaymentId: 'pay_001',
            status: 'processing',
            amountCents: 7_500,
            pixKey: 'alice@example.com',
            pixKeyType: 'EMAIL',
            createdAt: '2026-05-23T19:30:00.000Z'
          }
        })
      });
      const result = await h.dispatcher.dispatchNext();
      // Product decision: the `processing` stage is internal-only. The row is
      // skipped (treated as unsupported) and marked published so the queue
      // drains, but NO HTTP POST is ever made to the client.
      expect(result).toMatchObject({ kind: 'skipped', reason: 'unsupported_event_type' });
      expect(h.calls.httpRequests).toHaveLength(0);
      expect(h.calls.outboxPublished).toEqual([CASHOUT_OUTBOX_ID]);
    }
  );

  // Backward compatibility: rows enqueued before migration 0015 still carry the
  // legacy `cashout.*` token. The dispatcher must keep draining them with the
  // identical public envelope name.
  it.each(['completed', 'failed', 'returned'] as const)(
    'still delivers pix.cash_out.%s for a legacy cashout.%s row (pre-0015)',
    async (status) => {
      const h = buildHarness({
        claimed: cashoutOutboxRecord({
          eventType: `cashout.${status}`,
          payload: {
            cashoutId: 'co_001',
            externalId: 'merchant-cashout-ref-001',
            clientId: CLIENT_ID,
            provider: 'bents',
            providerPaymentId: 'pay_001',
            status,
            amountCents: 7_500,
            pixKey: 'alice@example.com',
            pixKeyType: 'EMAIL',
            createdAt: '2026-05-23T19:30:00.000Z',
            occurredAt: '2026-05-23T19:55:00.000Z'
          }
        })
      });
      const result = await h.dispatcher.dispatchNext();
      const req = h.calls.httpRequests[0]!;
      const decoded = JSON.parse(req.bodyText) as { event: string };
      expect(decoded.event).toBe(`pix.cash_out.${status}`);
      expect(result.kind).toBe('delivered');
    }
  );

  it('still skips a legacy cashout.initiated row without POSTing (pre-0015)', async () => {
    const h = buildHarness({
      claimed: cashoutOutboxRecord({
        eventType: 'cashout.initiated',
        payload: {
          cashoutId: 'co_001',
          externalId: 'merchant-cashout-ref-001',
          clientId: CLIENT_ID,
          provider: 'bents',
          providerPaymentId: 'pay_001',
          status: 'processing',
          amountCents: 7_500,
          pixKey: 'alice@example.com',
          pixKeyType: 'EMAIL',
          createdAt: '2026-05-23T19:30:00.000Z'
        }
      })
    });
    const result = await h.dispatcher.dispatchNext();
    expect(result).toMatchObject({ kind: 'skipped', reason: 'unsupported_event_type' });
    expect(h.calls.httpRequests).toHaveLength(0);
    expect(h.calls.outboxPublished).toEqual([CASHOUT_OUTBOX_ID]);
  });
});

describe('ClientWebhookDispatcher.dispatchNext — cash_out skips', () => {
  it('skips with unsupported_event_type when the cashout event is unknown', async () => {
    const h = buildHarness({
      claimed: cashoutOutboxRecord({ eventType: 'cashout.archived' })
    });
    const result = await h.dispatcher.dispatchNext();
    expect(result).toMatchObject({ kind: 'skipped', reason: 'unsupported_event_type' });
    expect(h.calls.outboxPublished).toEqual([CASHOUT_OUTBOX_ID]);
  });

  it('skips with malformed_payload when cashoutId is missing', async () => {
    const h = buildHarness({
      claimed: cashoutOutboxRecord({
        payload: {
          externalId: 'merchant-cashout-ref-001',
          clientId: CLIENT_ID,
          provider: 'bents',
          providerPaymentId: 'pay_001',
          status: 'completed',
          amountCents: 7_500,
          createdAt: '2026-05-23T19:30:00.000Z'
        }
      })
    });
    const result = await h.dispatcher.dispatchNext();
    expect(result).toMatchObject({ kind: 'skipped', reason: 'malformed_payload' });
  });
});

// ────────────────────────────────────────────────────────────────────
// Stale processing reaper
// ────────────────────────────────────────────────────────────────────

describe('ClientWebhookDispatcher — stale processing reaper', () => {
  it('calls reclaimStaleProcessing before claiming the next outbox row', async () => {
    const fixedNow = new Date('2026-05-28T10:00:00Z');
    const h = buildHarness({ claimed: null, now: () => fixedNow });

    await h.dispatcher.dispatchNext();

    expect(h.outboxRepository.reclaimStaleProcessing).toHaveBeenCalledOnce();
    // staleBefore = fixedNow - 5 min
    const [, staleBefore] = (
      h.outboxRepository.reclaimStaleProcessing as ReturnType<typeof vi.fn>
    ).mock.calls[0] as [unknown, Date];
    expect(staleBefore).toEqual(new Date('2026-05-28T09:55:00Z'));
  });

  it('does not throw if reclaimStaleProcessing rejects (non-fatal)', async () => {
    const h = buildHarness({ claimed: null });
    (h.outboxRepository.reclaimStaleProcessing as ReturnType<typeof vi.fn>).mockRejectedValueOnce(
      new Error('db connection lost')
    );
    await expect(h.dispatcher.dispatchNext()).resolves.toEqual({ kind: 'empty' });
  });
});

// ────────────────────────────────────────────────────────────────────
// markFailed → dlq (outbox terminal status)
// ────────────────────────────────────────────────────────────────────

describe('ClientWebhookDispatcher — dlq after max retries', () => {
  it('calls markFailed (dlq) and not scheduleRetry once retry budget is exhausted', async () => {
    const upserted = baseDelivery({ attemptCount: 3 });
    const h = buildHarness({
      claimed: baseOutboxRecord(),
      upsertedDelivery: upserted,
      // HTTP returns 500 to trigger failure path
      httpResponse: { statusCode: 500, bodyText: 'error' },
      retryPolicy: { baseDelayMs: 1_000, maxDelayMs: 60_000, maxAttempts: 3, responseSnippetLength: 256, requestTimeoutMs: 5_000 }
    });

    const result = await h.dispatcher.dispatchNext();

    expect(result).toMatchObject({ kind: 'dlq', outboxEventId: OUTBOX_ID });
    // markFailed must be called exactly once (sets status to 'dlq' in DB)
    expect(h.calls.outboxFailed).toEqual([OUTBOX_ID]);
    // No retry scheduled
    expect(h.calls.outboxRetry).toHaveLength(0);
  });
});

// ────────────────────────────────────────────────────────────────────
// claimLatencyMs
// ────────────────────────────────────────────────────────────────────

describe('ClientWebhookDispatcher — claimLatencyMs', () => {
  it('includes claimLatencyMs on delivered outcome', async () => {
    const createdAt = new Date('2026-05-28T10:00:00.000Z');
    const claimedAt = new Date('2026-05-28T10:00:00.450Z');
    const h = buildHarness({
      claimed: baseOutboxRecord({ createdAt }),
      httpResponse: { statusCode: 200, bodyText: 'ok' },
      now: () => claimedAt
    });
    const result = await h.dispatcher.dispatchNext();
    expect(result.kind).toBe('delivered');
    expect((result as { claimLatencyMs?: number }).claimLatencyMs).toBe(450);
  });

  it('does not include claimLatencyMs on empty outcome', async () => {
    const h = buildHarness({ claimed: null });
    const result = await h.dispatcher.dispatchNext();
    expect(result).toEqual({ kind: 'empty' });
  });
});

// ────────────────────────────────────────────────────────────────────
// Phase A — first-attempt latency timestamps + metrics
// ────────────────────────────────────────────────────────────────────

describe('ClientWebhookDispatcher — first-attempt latency instrumentation', () => {
  it('persists first_attempt_started_at/finished_at on the first attempt', async () => {
    const claimedAt = new Date('2026-05-28T10:00:00.150Z');
    const h = buildHarness({
      claimed: baseOutboxRecord({ createdAt: new Date('2026-05-28T10:00:00.000Z') }),
      upsertedDelivery: baseDelivery({ attemptCount: 0 }),
      httpResponse: { statusCode: 200, bodyText: 'ok' },
      now: () => claimedAt
    });

    const result = await h.dispatcher.dispatchNext();

    expect(result.kind).toBe('delivered');
    expect(h.calls.deliveryAttempts).toHaveLength(1);
    const attempt = h.calls.deliveryAttempts[0]!;
    expect(attempt.firstAttemptStartedAt).toEqual(claimedAt);
    expect(attempt.firstAttemptFinishedAt).toEqual(claimedAt);
  });

  it('does NOT overwrite first-attempt timestamps on a retry (attemptCount > 0)', async () => {
    const h = buildHarness({
      claimed: baseOutboxRecord(),
      // delivery already has one prior attempt → this is not the first.
      upsertedDelivery: baseDelivery({ attemptCount: 1 }),
      httpResponse: { statusCode: 200, bodyText: 'ok' }
    });

    const result = await h.dispatcher.dispatchNext();

    expect(result.kind).toBe('delivered');
    const attempt = h.calls.deliveryAttempts[0]!;
    expect(attempt.firstAttemptStartedAt).toBeNull();
    expect(attempt.firstAttemptFinishedAt).toBeNull();
  });

  it('emits the first-attempt-start and success latency histograms', async () => {
    const h = buildHarness({
      claimed: baseOutboxRecord(),
      httpResponse: { statusCode: 200, bodyText: 'ok' }
    });
    await h.dispatcher.dispatchNext();
    const rendered = metrics.renderPrometheus();
    expect(rendered).toContain('cashyin_client_webhook_first_attempt_start_latency_seconds');
    expect(rendered).toContain('cashyin_client_webhook_first_attempt_total_latency_seconds');
    expect(rendered).toContain('cashyin_client_webhook_success_latency_seconds');
  });
});

// ────────────────────────────────────────────────────────────────────
// Phase B2 — stale-reaper throttling
// ────────────────────────────────────────────────────────────────────

describe('ClientWebhookDispatcher — stale-reaper throttling', () => {
  it('runs the reaper at most once within the throttle interval', async () => {
    const fixedNow = new Date('2026-05-28T10:00:00.000Z');
    const h = buildHarness({
      claimed: null,
      reaperMinIntervalMs: 60_000,
      now: () => fixedNow
    });
    await h.dispatcher.dispatchNext();
    await h.dispatcher.dispatchNext();
    expect(h.calls.reaperRuns).toBe(1);
  });

  it('runs the reaper on every tick when the interval is 0 (legacy behaviour)', async () => {
    const h = buildHarness({ claimed: null, reaperMinIntervalMs: 0 });
    await h.dispatcher.dispatchNext();
    await h.dispatcher.dispatchNext();
    expect(h.calls.reaperRuns).toBe(2);
  });
});

// ────────────────────────────────────────────────────────────────────
// Phase B1 — outbox event-type partition filter
// ────────────────────────────────────────────────────────────────────

describe('ClientWebhookDispatcher — claim partition filter', () => {
  it('forwards an include event-type filter to the outbox claim', async () => {
    const h = buildHarness({
      claimed: null,
      claimFilter: { eventTypes: ['pix.cash_in.paid'] }
    });
    await h.dispatcher.dispatchNext();
    expect(h.calls.outboxClaim[0]).toMatchObject({
      aggregateTypes: ['cash_in', 'cashout'],
      eventTypes: ['pix.cash_in.paid']
    });
  });

  it('forwards an exclude event-type filter to the outbox claim', async () => {
    const h = buildHarness({
      claimed: null,
      claimFilter: { excludeEventTypes: ['pix.cash_in.paid'] }
    });
    await h.dispatcher.dispatchNext();
    expect(h.calls.outboxClaim[0]).toMatchObject({
      excludeEventTypes: ['pix.cash_in.paid']
    });
  });

  it('does not set any event-type filter when none is configured', async () => {
    const h = buildHarness({ claimed: null });
    await h.dispatcher.dispatchNext();
    expect(h.calls.outboxClaim[0]).not.toHaveProperty('eventTypes');
    expect(h.calls.outboxClaim[0]).not.toHaveProperty('excludeEventTypes');
  });
});
