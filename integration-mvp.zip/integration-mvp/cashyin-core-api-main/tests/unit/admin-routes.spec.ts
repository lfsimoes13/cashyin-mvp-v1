import type { FastifyRequest, preHandlerAsyncHookHandler } from 'fastify';
import Fastify from 'fastify';
import { describe, expect, it, vi } from 'vitest';
import { registerAdminRoutes } from '../../src/modules/admin/admin.routes.js';
import type { ClientApiKeyService } from '../../src/modules/auth/client-api-key.service.js';
import type { UserClientGrantService } from '../../src/modules/auth/user-client-grant.js';
import type { ClientWebhookEndpointAdminService } from '../../src/modules/webhooks/client-webhook-endpoint.admin.js';
import type { ClientConfigService } from '../../src/modules/admin/client-config.service.js';
import { AUTH_SCOPES } from '../../src/shared/auth/auth-scopes.js';
import { toHttpError } from '../../src/shared/errors/app-error.js';

const CLIENT_ID = 'tenant-1';

function fakeAuthenticate(scopes: string[]): preHandlerAsyncHookHandler {
  return async function authenticate(request: FastifyRequest): Promise<void> {
    request.authPrincipal = {
      channel: 'api_direct',
      principalType: 'api_client',
      principalId: CLIENT_ID,
      clientId: CLIENT_ID,
      credentialId: 'cred-1',
      scopes: scopes as never
    };
  };
}

function buildApp(scopes: string[]) {
  const app = Fastify();
  app.setErrorHandler((error, _request, reply) => {
    const httpError = toHttpError(error);
    void reply.status(httpError.statusCode).send({ error: { code: httpError.code } });
  });

  const keyMocks = {
    generate: vi.fn().mockResolvedValue({
      id: 'key-1',
      rawKey: 'ck_raw',
      keyPrefix: 'abcd1234',
      label: 'admin',
      scopes: [AUTH_SCOPES.PIX_CASH_IN_CREATE],
      expiresAt: null
    }),
    listByClient: vi.fn().mockResolvedValue([{ id: 'key-1', keyPrefix: 'abcd1234' }]),
    rotate: vi.fn().mockResolvedValue({
      id: 'key-2',
      rawKey: 'ck_raw2',
      keyPrefix: 'ef567890',
      label: 'admin',
      scopes: [],
      expiresAt: null
    }),
    revoke: vi.fn().mockResolvedValue(true)
  };

  const webhookMocks = {
    create: vi.fn().mockResolvedValue({
      endpoint: { id: 'wh-1', clientId: CLIENT_ID, eventPattern: '*', targetUrl: 'https://x.test/h', status: 'active' },
      signingSecret: 'whsec_abc'
    }),
    listByClient: vi.fn().mockResolvedValue([{ id: 'wh-1' }]),
    update: vi.fn().mockResolvedValue({ id: 'wh-1', status: 'disabled' }),
    disable: vi.fn().mockResolvedValue({ id: 'wh-1', status: 'disabled' })
  };

  const grantMocks = {
    listByClient: vi.fn().mockResolvedValue([{ actorUserId: 'user-9', clientId: CLIENT_ID, scopes: [] }]),
    grant: vi.fn().mockResolvedValue({
      actorUserId: 'user-9',
      clientId: CLIENT_ID,
      scopes: [AUTH_SCOPES.PIX_CASH_IN_READ],
      status: 'active'
    }),
    revoke: vi.fn().mockResolvedValue(true)
  };

  const configMocks = {
    listFees: vi.fn().mockResolvedValue([
      {
        operationType: 'cash_in',
        triggerEvent: 'cash_in_paid',
        fixedFeeCents: 15,
        variableFeeBps: 0,
        minFeeCents: null,
        maxFeeCents: null,
        billingMode: 'deduct_from_settlement',
        roundingMode: 'round_half_up'
      }
    ]),
    listRouting: vi.fn().mockResolvedValue([{ operationType: 'cash_in', providerName: 'bents' }])
  };

  void registerAdminRoutes(app, {
    authenticate: fakeAuthenticate(scopes),
    clientApiKeyService: keyMocks as unknown as ClientApiKeyService,
    userClientGrantService: grantMocks as unknown as UserClientGrantService,
    webhookEndpointAdminService: webhookMocks as unknown as ClientWebhookEndpointAdminService,
    clientConfigService: configMocks as unknown as ClientConfigService
  });

  return { app, keyMocks, grantMocks, webhookMocks, configMocks };
}

const API_KEYS = [AUTH_SCOPES.API_KEYS_MANAGE];
const WEBHOOKS = [AUTH_SCOPES.WEBHOOKS_MANAGE];
const CLIENTS_READ = [AUTH_SCOPES.CLIENTS_READ];
const CLIENTS_MANAGE = [AUTH_SCOPES.CLIENTS_MANAGE];

describe('admin api-key routes', () => {
  it('creates a key for the authenticated client (201, raw shown once)', async () => {
    const { app, keyMocks } = buildApp(API_KEYS);
    const res = await app.inject({
      method: 'POST',
      url: '/v1/admin/api-keys',
      payload: { label: 'admin' }
    });
    expect(res.statusCode).toBe(201);
    expect(res.json<{ rawKey: string }>().rawKey).toBe('ck_raw');
    expect(keyMocks.generate).toHaveBeenCalledWith(
      expect.objectContaining({ clientId: CLIENT_ID, label: 'admin' })
    );
    await app.close();
  });

  it('rejects creation without the api_keys:manage scope (403)', async () => {
    const { app } = buildApp([AUTH_SCOPES.PIX_CASH_IN_CREATE]);
    const res = await app.inject({ method: 'POST', url: '/v1/admin/api-keys', payload: {} });
    expect(res.statusCode).toBe(403);
    await app.close();
  });

  it('rejects an unknown scope in the body (422)', async () => {
    const { app } = buildApp(API_KEYS);
    const res = await app.inject({
      method: 'POST',
      url: '/v1/admin/api-keys',
      payload: { scopes: ['not:a:scope'] }
    });
    expect(res.statusCode).toBe(422);
    await app.close();
  });

  it('lists keys for the client', async () => {
    const { app, keyMocks } = buildApp(API_KEYS);
    const res = await app.inject({ method: 'GET', url: '/v1/admin/api-keys' });
    expect(res.statusCode).toBe(200);
    expect(res.json<{ data: unknown[] }>().data).toHaveLength(1);
    expect(keyMocks.listByClient).toHaveBeenCalledWith(CLIENT_ID);
    await app.close();
  });

  it('rotates a key, scoping the call to the client (201)', async () => {
    const { app, keyMocks } = buildApp(API_KEYS);
    const res = await app.inject({ method: 'POST', url: '/v1/admin/api-keys/key-1/rotate' });
    expect(res.statusCode).toBe(201);
    expect(keyMocks.rotate).toHaveBeenCalledWith('key-1', CLIENT_ID);
    await app.close();
  });

  it('returns 404 when rotate finds nothing for the client', async () => {
    const { app, keyMocks } = buildApp(API_KEYS);
    keyMocks.rotate.mockResolvedValueOnce(null);
    const res = await app.inject({ method: 'POST', url: '/v1/admin/api-keys/missing/rotate' });
    expect(res.statusCode).toBe(404);
    await app.close();
  });

  it('revokes a key (204)', async () => {
    const { app, keyMocks } = buildApp(API_KEYS);
    const res = await app.inject({ method: 'POST', url: '/v1/admin/api-keys/key-1/revoke' });
    expect(res.statusCode).toBe(204);
    expect(keyMocks.revoke).toHaveBeenCalledWith('key-1', CLIENT_ID);
    await app.close();
  });

  it('returns 404 when revoke does not match the client', async () => {
    const { app, keyMocks } = buildApp(API_KEYS);
    keyMocks.revoke.mockResolvedValueOnce(false);
    const res = await app.inject({ method: 'POST', url: '/v1/admin/api-keys/missing/revoke' });
    expect(res.statusCode).toBe(404);
    await app.close();
  });
});

describe('admin webhook-endpoint routes', () => {
  it('creates an endpoint and returns the signing secret once (201)', async () => {
    const { app, webhookMocks } = buildApp(WEBHOOKS);
    const res = await app.inject({
      method: 'POST',
      url: '/v1/admin/webhook-endpoints',
      payload: { eventPattern: '*', targetUrl: 'https://x.test/h' }
    });
    expect(res.statusCode).toBe(201);
    expect(res.json<{ signingSecret: string }>().signingSecret).toBe('whsec_abc');
    expect(webhookMocks.create).toHaveBeenCalledWith(
      expect.objectContaining({ clientId: CLIENT_ID, eventPattern: '*', targetUrl: 'https://x.test/h' })
    );
    await app.close();
  });

  it('rejects an invalid target URL (422)', async () => {
    const { app } = buildApp(WEBHOOKS);
    const res = await app.inject({
      method: 'POST',
      url: '/v1/admin/webhook-endpoints',
      payload: { eventPattern: '*', targetUrl: 'not-a-url' }
    });
    expect(res.statusCode).toBe(422);
    await app.close();
  });

  it('rejects management without the webhooks:manage scope (403)', async () => {
    const { app } = buildApp([AUTH_SCOPES.API_KEYS_MANAGE]);
    const res = await app.inject({ method: 'GET', url: '/v1/admin/webhook-endpoints' });
    expect(res.statusCode).toBe(403);
    await app.close();
  });

  it('lists endpoints for the client', async () => {
    const { app, webhookMocks } = buildApp(WEBHOOKS);
    const res = await app.inject({ method: 'GET', url: '/v1/admin/webhook-endpoints' });
    expect(res.statusCode).toBe(200);
    expect(webhookMocks.listByClient).toHaveBeenCalledWith(CLIENT_ID);
    await app.close();
  });

  it('patches an endpoint (200) and 404s when not owned', async () => {
    const { app, webhookMocks } = buildApp(WEBHOOKS);
    const ok = await app.inject({
      method: 'PATCH',
      url: '/v1/admin/webhook-endpoints/wh-1',
      payload: { status: 'disabled' }
    });
    expect(ok.statusCode).toBe(200);
    expect(webhookMocks.update).toHaveBeenCalledWith(CLIENT_ID, 'wh-1', { status: 'disabled' });

    webhookMocks.update.mockResolvedValueOnce(null);
    const missing = await app.inject({
      method: 'PATCH',
      url: '/v1/admin/webhook-endpoints/nope',
      payload: { status: 'disabled' }
    });
    expect(missing.statusCode).toBe(404);
    await app.close();
  });

  it('rejects an empty patch body (422)', async () => {
    const { app } = buildApp(WEBHOOKS);
    const res = await app.inject({ method: 'PATCH', url: '/v1/admin/webhook-endpoints/wh-1', payload: {} });
    expect(res.statusCode).toBe(422);
    await app.close();
  });
});

describe('admin bff-grant routes (D7)', () => {
  it('upserts a grant for an actor (200)', async () => {
    const { app, grantMocks } = buildApp(CLIENTS_MANAGE);
    const res = await app.inject({
      method: 'PUT',
      url: '/v1/admin/bff-grants/user-9',
      payload: { scopes: [AUTH_SCOPES.PIX_CASH_IN_READ] }
    });
    expect(res.statusCode).toBe(200);
    expect(grantMocks.grant).toHaveBeenCalledWith({
      clientId: CLIENT_ID,
      actorUserId: 'user-9',
      scopes: [AUTH_SCOPES.PIX_CASH_IN_READ]
    });
    await app.close();
  });

  it('rejects grant management without clients:manage (403)', async () => {
    const { app } = buildApp(CLIENTS_READ);
    const res = await app.inject({
      method: 'PUT',
      url: '/v1/admin/bff-grants/user-9',
      payload: { scopes: [AUTH_SCOPES.PIX_CASH_IN_READ] }
    });
    expect(res.statusCode).toBe(403);
    await app.close();
  });

  it('lists grants for the client', async () => {
    const { app, grantMocks } = buildApp(CLIENTS_MANAGE);
    const res = await app.inject({ method: 'GET', url: '/v1/admin/bff-grants' });
    expect(res.statusCode).toBe(200);
    expect(grantMocks.listByClient).toHaveBeenCalledWith(CLIENT_ID);
    await app.close();
  });

  it('revokes a grant (204) and 404s when none matched', async () => {
    const { app, grantMocks } = buildApp(CLIENTS_MANAGE);
    const ok = await app.inject({ method: 'DELETE', url: '/v1/admin/bff-grants/user-9' });
    expect(ok.statusCode).toBe(204);
    expect(grantMocks.revoke).toHaveBeenCalledWith(CLIENT_ID, 'user-9');

    grantMocks.revoke.mockResolvedValueOnce(false);
    const missing = await app.inject({ method: 'DELETE', url: '/v1/admin/bff-grants/nobody' });
    expect(missing.statusCode).toBe(404);
    await app.close();
  });

  it('rejects an empty scopes array (422)', async () => {
    const { app } = buildApp(CLIENTS_MANAGE);
    const res = await app.inject({
      method: 'PUT',
      url: '/v1/admin/bff-grants/user-9',
      payload: { scopes: [] }
    });
    expect(res.statusCode).toBe(422);
    await app.close();
  });
});

describe('admin client-config routes', () => {
  it('returns the fee config for the client (200)', async () => {
    const { app, configMocks } = buildApp(CLIENTS_READ);
    const res = await app.inject({ method: 'GET', url: '/v1/admin/config/fees' });
    expect(res.statusCode).toBe(200);
    const body = res.json<{ data: Array<Record<string, unknown>> }>();
    expect(body.data).toHaveLength(1);
    expect(configMocks.listFees).toHaveBeenCalledWith(CLIENT_ID);
    await app.close();
  });

  it('never leaks margin/subsidy/internal fields in the fee config', async () => {
    const { app } = buildApp(CLIENTS_READ);
    const res = await app.inject({ method: 'GET', url: '/v1/admin/config/fees' });
    const raw = res.body;
    for (const forbidden of [
      'margin',
      'subsidy',
      'provider_cost',
      'pricingPlanVersionId',
      'providerAccountId',
      'metadata',
      'signing'
    ]) {
      expect(raw).not.toContain(forbidden);
    }
    await app.close();
  });

  it('returns the routing config exposing only providerName (200)', async () => {
    const { app, configMocks } = buildApp(CLIENTS_READ);
    const res = await app.inject({ method: 'GET', url: '/v1/admin/config/routing' });
    expect(res.statusCode).toBe(200);
    const body = res.json<{ data: Array<{ operationType: string; providerName: string }> }>();
    expect(body.data[0]).toEqual({ operationType: 'cash_in', providerName: 'bents' });
    expect(Object.keys(body.data[0]!)).toEqual(['operationType', 'providerName']);
    expect(configMocks.listRouting).toHaveBeenCalledWith(CLIENT_ID);
    await app.close();
  });

  it('rejects config reads without clients:read (403)', async () => {
    const { app } = buildApp([AUTH_SCOPES.API_KEYS_MANAGE]);
    const fees = await app.inject({ method: 'GET', url: '/v1/admin/config/fees' });
    const routing = await app.inject({ method: 'GET', url: '/v1/admin/config/routing' });
    expect(fees.statusCode).toBe(403);
    expect(routing.statusCode).toBe(403);
    await app.close();
  });
});
