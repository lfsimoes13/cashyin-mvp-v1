import Fastify, { type FastifyInstance, type FastifyRequest } from 'fastify';
import { describe, expect, it, vi } from 'vitest';
import {
  ClientApiKeyService,
  type ClientApiKeyRepository
} from '../../src/modules/auth/client-api-key.service.js';
import {
  buildAuthPreHandlers,
  buildResolveAuthContext,
  type AuthPreHandlers
} from '../../src/modules/auth/auth-enforcement.js';
import { registerPaymentRoutes } from '../../src/modules/payments/payment.routes.js';
import {
  createCashInBodySchema,
  type CreateCashInInput
} from '../../src/modules/payments/payment.schemas.js';
import { registerCashoutRoutes } from '../../src/modules/cashouts/cashout.routes.js';
import {
  createCashoutBodySchema,
  toCreateCashoutInput,
  type CreateCashoutInput
} from '../../src/modules/cashouts/cashout.schemas.js';
import {
  CashoutStepUpService,
  type CashoutStepUpRepository
} from '../../src/modules/cashouts/cashout-step-up.js';
import type { PaymentService } from '../../src/modules/payments/payment.service.js';
import type { CashoutService } from '../../src/modules/cashouts/cashout.service.js';
import { toHttpError } from '../../src/shared/errors/app-error.js';

const CLIENT_A = '11111111-1111-4111-8111-111111111111';
const CLIENT_B = '22222222-2222-4222-8222-222222222222';

/**
 * Builds a Fastify app with the same error handler the real app uses, so
 * thrown `AppError`s map to their HTTP status (e.g. 401) exactly as in
 * production.
 */
function buildApp(): FastifyInstance {
  const app = Fastify();
  app.setErrorHandler((error, _request, reply) => {
    const httpError = toHttpError(error);
    void reply
      .status(httpError.statusCode)
      .send({ error: { code: httpError.code, message: httpError.message } });
  });
  return app;
}

/** Empty API-key repository — every lookup misses, so verify() returns null. */
function emptyApiKeyRepo(): ClientApiKeyRepository {
  return {
    findActiveByPrefix: async () => [],
    findById: async () => null,
    listByClient: async () => [],
    insert: async () => ({ id: 'unused' }),
    touchLastUsed: async () => undefined,
    revoke: async () => undefined
  };
}

/**
 * The REAL multi-channel authenticator over an empty key store (no DB needed)
 * and with the BFF channel off — so an unauthenticated request is rejected
 * with 401 exactly as in production. Scope enforcement is `off`, which is
 * irrelevant to these tests (they assert the *authentication* boundary).
 */
function realAuth(): AuthPreHandlers {
  return buildAuthPreHandlers({
    mode: 'off',
    clientApiKeyService: new ClientApiKeyService({ repository: emptyApiKeyRepo(), sql: {} as never }),
    bffMode: 'off'
  });
}

/**
 * A stub auth bundle that injects an authenticated principal for `clientId`,
 * mimicking a successful authentication without touching the DB. Used to drive
 * the smuggle tests: it proves the ROUTE derives the tenant from
 * `request.client`, regardless of the body.
 */
function stubAuthAs(clientId: string): AuthPreHandlers {
  return {
    authenticate: async (request: FastifyRequest) => {
      request.authPrincipal = {
        channel: 'api_direct',
        principalType: 'api_client',
        principalId: 'p',
        clientId,
        scopes: [],
        credentialId: 'cred'
      };
      request.client = { clientId, apiKeyId: 'api-key-1', keyPrefix: 'de1f7752', label: null, scopes: [] };
    },
    resolveAuthContext: buildResolveAuthContext(),
    requireScope: () => async () => undefined
  };
}

/** A step-up service backed by a stub repo; inert because cash-out uses `mode: 'off'`. */
function inertStepUp(): { mode: 'off'; service: CashoutStepUpService } {
  const repository: CashoutStepUpRepository = {
    insert: async () => ({ id: 'proof-1' }),
    consumeMatching: async () => null,
    findValid: async () => null
  };
  return { mode: 'off', service: new CashoutStepUpService({ repository, sql: {} as never, ttlMs: 60_000 }) };
}

describe('tenant clientId boundary — schemas strip body clientId', () => {
  it('createCashInBodySchema drops smuggled client_id / clientId', () => {
    const parsed = createCashInBodySchema.parse({
      external_ref: 'order-1',
      amount: 100,
      description: 'demo',
      client_id: CLIENT_B,
      clientId: CLIENT_B
    });
    expect(parsed).not.toHaveProperty('client_id');
    expect(parsed).not.toHaveProperty('clientId');
    expect(parsed).toEqual({ external_ref: 'order-1', amount: 100, description: 'demo' });
  });

  it('createCashoutBodySchema drops smuggled client_id / clientId', () => {
    const parsed = createCashoutBodySchema.parse({
      amount: 100,
      pix: { key_type: 'EMAIL', key: 'user@example.com' },
      client_id: CLIENT_B,
      clientId: CLIENT_B
    });
    expect(parsed).not.toHaveProperty('client_id');
    expect(parsed).not.toHaveProperty('clientId');
  });
});

describe('tenant clientId boundary — toCreateCashoutInput uses authenticated id', () => {
  it('always returns the authenticated clientId, ignoring smuggled body fields', () => {
    const body = {
      amount: 100,
      pix: { key_type: 'EMAIL' as const, key: 'user@example.com' },
      external_ref: 'order-1',
      // Smuggled fields are not part of CreateCashoutBody but structurally
      // tolerated on a variable — mirrors how a malicious raw body arrives.
      client_id: CLIENT_B,
      clientId: CLIENT_B
    };
    const input = toCreateCashoutInput(body, CLIENT_A);
    expect(input.clientId).toBe(CLIENT_A);
    expect(input).not.toHaveProperty('client_id');
  });
});

describe('tenant clientId boundary — cash-in route', () => {
  it('rejects with 401 when no auth/client context is present', async () => {
    const createCashIn = vi.fn();
    const app = buildApp();
    await registerPaymentRoutes(app, {
      paymentService: { createCashIn } as unknown as PaymentService,
      auth: realAuth()
    });

    const response = await app.inject({
      method: 'POST',
      url: '/v1/pix/cash-in/qrcode',
      payload: { external_ref: 'order-1', amount: 100 }
    });

    expect(response.statusCode).toBe(401);
    expect(createCashIn).not.toHaveBeenCalled();
    await app.close();
  });

  it('invokes the service with authenticated client A even when the body smuggles client B', async () => {
    const createCashIn = vi.fn(async (input: CreateCashInInput) => ({
      txid: 'tx-1',
      amount: input.amount,
      external_ref: input.external_ref,
      status: 'pending'
    }));
    const app = buildApp();
    await registerPaymentRoutes(app, {
      paymentService: { createCashIn } as unknown as PaymentService,
      auth: stubAuthAs(CLIENT_A)
    });

    const response = await app.inject({
      method: 'POST',
      url: '/v1/pix/cash-in/qrcode',
      payload: { external_ref: 'order-1', amount: 100, client_id: CLIENT_B, clientId: CLIENT_B }
    });

    expect(response.statusCode).toBe(201);
    expect(createCashIn).toHaveBeenCalledTimes(1);
    const arg = createCashIn.mock.calls[0]![0];
    expect(arg.client_id).toBe(CLIENT_A);
    expect(arg).not.toHaveProperty('clientId');
    await app.close();
  });
});

describe('tenant clientId boundary — cash-out route', () => {
  it('rejects with 401 when no auth/client context is present', async () => {
    const createCashoutWithDisposition = vi.fn();
    const app = buildApp();
    await registerCashoutRoutes(app, {
      cashoutService: { createCashoutWithDisposition } as unknown as CashoutService,
      auth: realAuth(),
      stepUp: inertStepUp()
    });

    const response = await app.inject({
      method: 'POST',
      url: '/v1/pix/cash-out',
      headers: { 'idempotency-key': 'idem-1' },
      payload: { amount: 100, pix: { key_type: 'EMAIL', key: 'user@example.com' } }
    });

    expect(response.statusCode).toBe(401);
    expect(createCashoutWithDisposition).not.toHaveBeenCalled();
    await app.close();
  });

  it('invokes the service with authenticated client A even when the body smuggles client B', async () => {
    const createCashoutWithDisposition = vi.fn(async (input: CreateCashoutInput) => ({
      cashout: {
        id: 'co-1',
        externalRef: input.externalRef,
        status: 'processing',
        amountCents: input.amountCents,
        currency: 'BRL',
        pixKey: input.pixKey,
        pixKeyType: input.pixKeyType,
        createdAt: new Date('2026-01-01T00:00:00.000Z')
      },
      replayed: false
    }));
    const app = buildApp();
    await registerCashoutRoutes(app, {
      cashoutService: { createCashoutWithDisposition } as unknown as CashoutService,
      auth: stubAuthAs(CLIENT_A),
      stepUp: inertStepUp()
    });

    const response = await app.inject({
      method: 'POST',
      url: '/v1/pix/cash-out',
      headers: { 'idempotency-key': 'idem-1' },
      payload: {
        amount: 100,
        pix: { key_type: 'EMAIL', key: 'user@example.com' },
        client_id: CLIENT_B,
        clientId: CLIENT_B
      }
    });

    expect(response.statusCode).toBe(201);
    expect(createCashoutWithDisposition).toHaveBeenCalledTimes(1);
    const input = createCashoutWithDisposition.mock.calls[0]![0];
    expect(input.clientId).toBe(CLIENT_A);
    expect(input).not.toHaveProperty('client_id');
    await app.close();
  });
});
