import { describe, expect, it } from 'vitest';
import {
  CASH_IN_EVENT_NAMES,
  CASH_OUT_EVENT_NAMES,
  eventNameForCashInStatus,
  eventNameForCashOutStatus,
  eventNameForStatus,
  isCashInEventName,
  isCashOutEventName,
  isPublicWebhookEventName,
  statusForCashInEvent,
  statusForCashOutEvent
} from '../../src/modules/transactions/public-events.js';
import { CASH_IN_STATUSES, CASH_OUT_STATUSES } from '../../src/modules/transactions/status.js';

describe('public event-name constants', () => {
  it('exposes the 5 canonical Cash-In event names in the documented order', () => {
    expect([...CASH_IN_EVENT_NAMES]).toEqual([
      'pix.cash_in.paid',
      'pix.cash_in.expired',
      'pix.cash_in.cancelled',
      'pix.cash_in.failed',
      'pix.cash_in.refunded'
    ]);
  });

  it('exposes the 4 canonical Cash-Out event names in the documented order', () => {
    expect([...CASH_OUT_EVENT_NAMES]).toEqual([
      'pix.cash_out.processing',
      'pix.cash_out.completed',
      'pix.cash_out.failed',
      'pix.cash_out.returned'
    ]);
  });

  it('uses only the `pix.cash_in.*` / `pix.cash_out.*` prefixes', () => {
    for (const name of CASH_IN_EVENT_NAMES) {
      expect(name.startsWith('pix.cash_in.')).toBe(true);
    }
    for (const name of CASH_OUT_EVENT_NAMES) {
      expect(name.startsWith('pix.cash_out.')).toBe(true);
    }
  });

  it('does not introduce legacy `pix.cash_in.confirmed` or `pix.cash_out.reversed`', () => {
    const all = new Set([...CASH_IN_EVENT_NAMES, ...CASH_OUT_EVENT_NAMES]);
    expect(all.has('pix.cash_in.confirmed' as never)).toBe(false);
    expect(all.has('pix.cash_out.reversed' as never)).toBe(false);
  });
});

describe('status ↔ event mapping', () => {
  it('maps every dispatched Cash-In status (non-pending) to a unique event name', () => {
    const dispatched = CASH_IN_STATUSES.filter((s) => s !== 'pending');
    const mapped = dispatched.map(eventNameForCashInStatus);
    expect(new Set(mapped).size).toBe(dispatched.length);
  });

  it('maps every Cash-Out status to a unique event name', () => {
    const mapped = CASH_OUT_STATUSES.map(eventNameForCashOutStatus);
    expect(new Set(mapped).size).toBe(CASH_OUT_STATUSES.length);
  });

  it('round-trips dispatched Cash-In status → event → status (pending excluded)', () => {
    const dispatched = CASH_IN_STATUSES.filter((s) => s !== 'pending');
    for (const status of dispatched) {
      expect(statusForCashInEvent(eventNameForCashInStatus(status))).toBe(status);
    }
  });

  it('round-trips Cash-Out status → event → status for every status', () => {
    for (const status of CASH_OUT_STATUSES) {
      expect(statusForCashOutEvent(eventNameForCashOutStatus(status))).toBe(status);
    }
  });

  it('uses `paid` (not `confirmed`) as the canonical paid Cash-In event', () => {
    expect(eventNameForCashInStatus('paid')).toBe('pix.cash_in.paid');
  });

  it('uses `completed` (not `confirmed`) as the canonical completed Cash-Out event', () => {
    expect(eventNameForCashOutStatus('completed')).toBe('pix.cash_out.completed');
  });

  it('uses `returned` (not `reversed`) as the canonical bank-return Cash-Out event', () => {
    expect(eventNameForCashOutStatus('returned')).toBe('pix.cash_out.returned');
  });

  it('`pix.cash_in.pending` is NOT a public event name — pending state is not dispatched', () => {
    expect(isCashInEventName('pix.cash_in.pending')).toBe(false);
  });

  it('emits `pix.cash_in.refunded` for a `refunded` charge', () => {
    expect(eventNameForCashInStatus('refunded')).toBe('pix.cash_in.refunded');
  });
});

describe('eventNameForStatus (typed overload)', () => {
  it('routes Cash-In through the Cash-In mapper', () => {
    expect(eventNameForStatus('cash_in', 'paid')).toBe('pix.cash_in.paid');
  });

  it('routes Cash-Out through the Cash-Out mapper', () => {
    expect(eventNameForStatus('cash_out', 'completed')).toBe('pix.cash_out.completed');
  });
});

describe('event-name guards', () => {
  it('only accepts Cash-In event names through `isCashInEventName`', () => {
    expect(isCashInEventName('pix.cash_in.paid')).toBe(true);
    expect(isCashInEventName('pix.cash_in.pending')).toBe(false); // pending is not dispatched
    expect(isCashInEventName('pix.cash_out.completed')).toBe(false);
    expect(isCashInEventName('pix.cash_in.confirmed')).toBe(false);
    expect(isCashInEventName(undefined)).toBe(false);
  });

  it('only accepts Cash-Out event names through `isCashOutEventName`', () => {
    expect(isCashOutEventName('pix.cash_out.returned')).toBe(true);
    expect(isCashOutEventName('pix.cash_in.paid')).toBe(false);
    expect(isCashOutEventName(123)).toBe(false);
  });

  it('accepts both flows through `isPublicWebhookEventName`', () => {
    expect(isPublicWebhookEventName('pix.cash_in.paid')).toBe(true);
    expect(isPublicWebhookEventName('pix.cash_out.failed')).toBe(true);
    expect(isPublicWebhookEventName('pix.cash_in.confirmed')).toBe(false);
    expect(isPublicWebhookEventName('charge.paid')).toBe(false);
  });
});
