import { describe, expect, it } from 'vitest';
import { generateTxid, isValidTxid } from '../../src/shared/types/txid.js';

describe('generateTxid', () => {
  it('generates alphanumeric transaction ids with the expected prefix and length', () => {
    const txid = generateTxid('TX');
    expect(txid.startsWith('TX')).toBe(true);
    expect(txid).toMatch(/^[A-Za-z0-9]+$/);
    expect(txid.length).toBeGreaterThanOrEqual(28);
    expect(txid.length).toBeLessThanOrEqual(37);
    expect(isValidTxid(txid)).toBe(true);
  });

  it('generates unique transaction ids', () => {
    const txids = new Set(Array.from({ length: 1000 }, () => generateTxid('TX')));
    expect(txids.size).toBe(1000);
  });
});

