import { describe, expect, it } from 'vitest';
import { isValidPixKeyForType } from '../../src/shared/validation/pix.js';
import { createCashoutBodySchema } from '../../src/modules/cashouts/cashout.schemas.js';

describe('isValidPixKeyForType', () => {
  it('accepts well-formed keys for every type', () => {
    expect(isValidPixKeyForType('CPF', '12345678901')).toBe(true);
    expect(isValidPixKeyForType('CNPJ', '12345678000199')).toBe(true);
    expect(isValidPixKeyForType('PHONE', '+5511999998888')).toBe(true);
    expect(isValidPixKeyForType('EMAIL', 'alice@example.com')).toBe(true);
    expect(isValidPixKeyForType('EVP', 'f17a24fa-d422-4d66-bfe0-1dd0e565cc1e')).toBe(true);
  });

  it('accepts upper-case EVP and EMAIL (case-insensitive)', () => {
    expect(isValidPixKeyForType('EVP', 'F17A24FA-D422-4D66-BFE0-1DD0E565CC1E')).toBe(true);
    expect(isValidPixKeyForType('EMAIL', 'Alice@Example.com')).toBe(true);
  });

  it('rejects malformed keys for each type', () => {
    expect(isValidPixKeyForType('CPF', '1234567890')).toBe(false); // 10 digits
    expect(isValidPixKeyForType('CPF', '123.456.789-01')).toBe(false); // punctuation
    expect(isValidPixKeyForType('CNPJ', '12345678901')).toBe(false); // 11 digits
    expect(isValidPixKeyForType('PHONE', '5511999998888')).toBe(false); // no leading +
    expect(isValidPixKeyForType('PHONE', '+0511999998888')).toBe(false); // leading 0
    expect(isValidPixKeyForType('EMAIL', 'not-an-email')).toBe(false);
    expect(isValidPixKeyForType('EVP', 'f17a24fa-d422-4d66-bfe0-1dd0e565cc1')).toBe(false); // short
  });

  it('treats an unknown key type as valid (the enum is validated separately)', () => {
    expect(isValidPixKeyForType('UNKNOWN', 'anything')).toBe(true);
  });
});

describe('createCashoutBodySchema — pix key format', () => {
  const base = { amount: 7500, pix: { key_type: 'CPF', key: '12345678901' } };

  it('parses a valid CPF key', () => {
    expect(createCashoutBodySchema.safeParse(base).success).toBe(true);
  });

  it('rejects a key that does not match its declared type', () => {
    const result = createCashoutBodySchema.safeParse({
      amount: 7500,
      pix: { key_type: 'CPF', key: 'alice@example.com' }
    });
    expect(result.success).toBe(false);
    if (!result.success) {
      const issue = result.error.issues.find((i) => i.path.join('.') === 'pix.key');
      expect(issue?.message).toContain('not a valid CPF key');
    }
  });

  it('accepts an EVP key for an EVP cash-out', () => {
    const result = createCashoutBodySchema.safeParse({
      amount: 200,
      pix: { key_type: 'EVP', key: 'f17a24fa-d422-4d66-bfe0-1dd0e565cc1e' }
    });
    expect(result.success).toBe(true);
  });
});
