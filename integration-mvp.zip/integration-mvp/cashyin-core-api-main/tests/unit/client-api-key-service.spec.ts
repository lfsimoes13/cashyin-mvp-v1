import { createHash } from 'node:crypto';
import { describe, expect, it, vi } from 'vitest';
import {
  API_KEY_PREFIX,
  ClientApiKeyService,
  parseRawApiKey,
  type ClientApiKeyRepository
} from '../../src/modules/auth/client-api-key.service.js';
import { DEFAULT_CLIENT_API_SCOPES } from '../../src/shared/auth/auth-scopes.js';

function buildRepo(overrides: Partial<ClientApiKeyRepository> = {}): ClientApiKeyRepository {
  return {
    findActiveByPrefix: async () => [],
    findById: async () => null,
    listByClient: async () => [],
    insert: async () => ({ id: 'stub-id' }),
    touchLastUsed: async () => undefined,
    revoke: async () => undefined,
    ...overrides
  };
}

const DETERMINISTIC_TAIL = '00112233445566778899aabbccddeeff00112233445566778899aabbccddeeff';
const DETERMINISTIC_RAW_KEY = `${API_KEY_PREFIX}${DETERMINISTIC_TAIL}`;
const DETERMINISTIC_HASH = createHash('sha256').update(DETERMINISTIC_RAW_KEY).digest('hex');

function fixedRandomBytes(size: number): Buffer {
  if (size !== 32) throw new Error(`unexpected rng size ${size}`);
  return Buffer.from(DETERMINISTIC_TAIL, 'hex');
}

describe('parseRawApiKey', () => {
  it('parses a well-formed key', () => {
    const result = parseRawApiKey(DETERMINISTIC_RAW_KEY);
    expect(result).not.toBeNull();
    expect(result?.prefix).toBe('00112233');
    expect(result?.hash).toBe(DETERMINISTIC_HASH);
  });

  it('rejects keys without the ck_ prefix', () => {
    const tail = '0'.repeat(64);
    expect(parseRawApiKey(tail)).toBeNull();
    expect(parseRawApiKey(`xk_${tail}`)).toBeNull();
  });

  it('rejects keys with wrong length', () => {
    expect(parseRawApiKey(`${API_KEY_PREFIX}abc`)).toBeNull();
    expect(parseRawApiKey(`${API_KEY_PREFIX}${'0'.repeat(63)}`)).toBeNull();
    expect(parseRawApiKey(`${API_KEY_PREFIX}${'0'.repeat(65)}`)).toBeNull();
  });

  it('rejects keys with non-hex characters', () => {
    expect(parseRawApiKey(`${API_KEY_PREFIX}${'g'.repeat(64)}`)).toBeNull();
    expect(parseRawApiKey(`${API_KEY_PREFIX}${'A'.repeat(64)}`)).toBeNull();
  });
});

describe('ClientApiKeyService.generate', () => {
  it('mints a key of the documented shape and persists prefix+hash', async () => {
    const insert = vi.fn().mockResolvedValue({ id: 'row-1' });
    const repo = buildRepo({ insert });
    const service = new ClientApiKeyService({
      repository: repo,
      sql: {} as never,
      randomBytes: fixedRandomBytes
    });

    const generated = await service.generate({ clientId: 'client-uuid', label: 'Postman' });

    expect(generated.rawKey).toBe(DETERMINISTIC_RAW_KEY);
    expect(generated.id).toBe('row-1');
    expect(generated.keyPrefix).toBe('00112233');
    expect(generated.clientId).toBe('client-uuid');
    expect(generated.label).toBe('Postman');

    expect(insert).toHaveBeenCalledTimes(1);
    expect(insert).toHaveBeenCalledWith(expect.anything(), {
      clientId: 'client-uuid',
      keyPrefix: '00112233',
      keyHash: DETERMINISTIC_HASH,
      label: 'Postman',
      scopes: DEFAULT_CLIENT_API_SCOPES,
      expiresAt: null,
      signingSecret: DETERMINISTIC_TAIL
    });
    expect(generated.signingSecret).toBe(DETERMINISTIC_TAIL);
  });

  it('defaults label to null, scopes to the standard set, and never-expires', async () => {
    const insert = vi.fn().mockResolvedValue({ id: 'row-2' });
    const service = new ClientApiKeyService({
      repository: buildRepo({ insert }),
      sql: {} as never,
      randomBytes: fixedRandomBytes
    });
    const generated = await service.generate({ clientId: 'client-uuid' });
    expect(generated.label).toBeNull();
    expect(generated.scopes).toEqual(DEFAULT_CLIENT_API_SCOPES);
    expect(generated.expiresAt).toBeNull();
    expect(insert.mock.calls[0]?.[1]).toMatchObject({
      label: null,
      scopes: DEFAULT_CLIENT_API_SCOPES,
      expiresAt: null
    });
  });

  it('persists the explicit scopes and expiry when supplied', async () => {
    const insert = vi.fn().mockResolvedValue({ id: 'row-3' });
    const service = new ClientApiKeyService({
      repository: buildRepo({ insert }),
      sql: {} as never,
      randomBytes: fixedRandomBytes
    });
    const expiresAt = new Date('2030-01-01T00:00:00.000Z');
    const generated = await service.generate({
      clientId: 'client-uuid',
      scopes: ['pix:cash_in:create'],
      expiresAt
    });
    expect(generated.scopes).toEqual(['pix:cash_in:create']);
    expect(generated.expiresAt).toBe(expiresAt);
    expect(insert.mock.calls[0]?.[1]).toMatchObject({
      scopes: ['pix:cash_in:create'],
      expiresAt
    });
  });
});

describe('ClientApiKeyService.verify', () => {
  it('returns the principal when the key matches', async () => {
    const findActiveByPrefix = vi.fn().mockResolvedValue([
      {
        id: 'row-1',
        client_id: 'client-uuid',
        key_prefix: '00112233',
        key_hash: DETERMINISTIC_HASH,
        label: 'Postman',
        scopes: ['pix:cash_in:create', 'pix:cash_in:read'],
        expires_at: null
      }
    ]);
    const touchLastUsed = vi.fn().mockResolvedValue(undefined);
    const service = new ClientApiKeyService({
      repository: buildRepo({ findActiveByPrefix, touchLastUsed }),
      sql: {} as never
    });

    const principal = await service.verify(DETERMINISTIC_RAW_KEY);
    expect(principal).toEqual({
      clientId: 'client-uuid',
      apiKeyId: 'row-1',
      keyPrefix: '00112233',
      label: 'Postman',
      scopes: ['pix:cash_in:create', 'pix:cash_in:read']
    });
    expect(findActiveByPrefix).toHaveBeenCalledTimes(1);
    expect(findActiveByPrefix).toHaveBeenCalledWith(expect.anything(), '00112233');
    expect(touchLastUsed).toHaveBeenCalledTimes(1);
    expect(touchLastUsed).toHaveBeenCalledWith(expect.anything(), 'row-1');
  });

  it('returns null for a malformed key', async () => {
    const findActiveByPrefix = vi.fn();
    const service = new ClientApiKeyService({
      repository: buildRepo({ findActiveByPrefix }),
      sql: {} as never
    });
    const result = await service.verify('garbage');
    expect(result).toBeNull();
    expect(findActiveByPrefix).not.toHaveBeenCalled();
  });

  it('returns null when no candidate row matches the prefix', async () => {
    const service = new ClientApiKeyService({
      repository: buildRepo({ findActiveByPrefix: async () => [] }),
      sql: {} as never
    });
    expect(await service.verify(DETERMINISTIC_RAW_KEY)).toBeNull();
  });

  it('returns null when the hash does not match (wrong key)', async () => {
    const service = new ClientApiKeyService({
      repository: buildRepo({
        findActiveByPrefix: async () => [
          {
            id: 'row-1',
            client_id: 'other-client',
            key_prefix: '00112233',
            key_hash: 'f'.repeat(64),
            label: null,
            scopes: [],
            expires_at: null
          }
        ]
      }),
      sql: {} as never
    });
    expect(await service.verify(DETERMINISTIC_RAW_KEY)).toBeNull();
  });

  it('iterates all candidates even after a match (timing-constant)', async () => {
    const findActiveByPrefix = vi.fn().mockResolvedValue([
      {
        id: 'row-1',
        client_id: 'other-1',
        key_prefix: '00112233',
        key_hash: 'a'.repeat(64),
        label: null,
        scopes: [],
        expires_at: null
      },
      {
        id: 'row-2',
        client_id: 'client-uuid',
        key_prefix: '00112233',
        key_hash: DETERMINISTIC_HASH,
        label: 'Postman',
        scopes: ['pix:cash_in:create'],
        expires_at: null
      },
      {
        id: 'row-3',
        client_id: 'other-2',
        key_prefix: '00112233',
        key_hash: 'b'.repeat(64),
        label: null,
        scopes: [],
        expires_at: null
      }
    ]);
    const service = new ClientApiKeyService({
      repository: buildRepo({ findActiveByPrefix }),
      sql: {} as never
    });
    const principal = await service.verify(DETERMINISTIC_RAW_KEY);
    expect(principal?.apiKeyId).toBe('row-2');
    expect(findActiveByPrefix).toHaveBeenCalledTimes(1);
  });

  it('still returns the principal when touchLastUsed fails (best-effort)', async () => {
    const service = new ClientApiKeyService({
      repository: buildRepo({
        findActiveByPrefix: async () => [
          {
            id: 'row-1',
            client_id: 'client-uuid',
            key_prefix: '00112233',
            key_hash: DETERMINISTIC_HASH,
            label: null,
            scopes: [],
            expires_at: null
          }
        ],
        touchLastUsed: async () => {
          throw new Error('db down');
        }
      }),
      sql: {} as never
    });
    const principal = await service.verify(DETERMINISTIC_RAW_KEY);
    expect(principal?.clientId).toBe('client-uuid');
  });

  it('rejects an expired key (returns null, treated as 401)', async () => {
    const touchLastUsed = vi.fn();
    const service = new ClientApiKeyService({
      repository: buildRepo({
        findActiveByPrefix: async () => [
          {
            id: 'row-1',
            client_id: 'client-uuid',
            key_prefix: '00112233',
            key_hash: DETERMINISTIC_HASH,
            label: null,
            scopes: ['pix:cash_in:create'],
            expires_at: new Date(Date.now() - 1_000)
          }
        ],
        touchLastUsed
      }),
      sql: {} as never
    });
    expect(await service.verify(DETERMINISTIC_RAW_KEY)).toBeNull();
    expect(touchLastUsed).not.toHaveBeenCalled();
  });

  it('accepts a key whose expiry is still in the future', async () => {
    const service = new ClientApiKeyService({
      repository: buildRepo({
        findActiveByPrefix: async () => [
          {
            id: 'row-1',
            client_id: 'client-uuid',
            key_prefix: '00112233',
            key_hash: DETERMINISTIC_HASH,
            label: null,
            scopes: ['pix:cash_in:create'],
            expires_at: new Date(Date.now() + 60_000)
          }
        ]
      }),
      sql: {} as never
    });
    const principal = await service.verify(DETERMINISTIC_RAW_KEY);
    expect(principal?.clientId).toBe('client-uuid');
  });

  it('drops unknown scope strings from the resolved principal', async () => {
    const service = new ClientApiKeyService({
      repository: buildRepo({
        findActiveByPrefix: async () => [
          {
            id: 'row-1',
            client_id: 'client-uuid',
            key_prefix: '00112233',
            key_hash: DETERMINISTIC_HASH,
            label: null,
            scopes: ['pix:cash_in:create', 'totally:made:up'],
            expires_at: null
          }
        ]
      }),
      sql: {} as never
    });
    const principal = await service.verify(DETERMINISTIC_RAW_KEY);
    expect(principal?.scopes).toEqual(['pix:cash_in:create']);
  });
});

describe('ClientApiKeyService.rotate', () => {
  it('mints a replacement carrying the same client/scopes/expiry and revokes the old key', async () => {
    const expiresAt = new Date('2030-06-01T00:00:00.000Z');
    const findById = vi.fn().mockResolvedValue({
      id: 'old-id',
      client_id: 'client-uuid',
      status: 'active',
      label: 'Production',
      scopes: ['pix:cash_in:create', 'totally:made:up'],
      expires_at: expiresAt
    });
    const insert = vi.fn().mockResolvedValue({ id: 'new-id' });
    const revoke = vi.fn().mockResolvedValue(undefined);
    const service = new ClientApiKeyService({
      repository: buildRepo({ findById, insert, revoke }),
      sql: {} as never,
      randomBytes: fixedRandomBytes
    });

    const rotated = await service.rotate('old-id');

    expect(rotated?.id).toBe('new-id');
    expect(rotated?.rawKey).toBe(DETERMINISTIC_RAW_KEY);
    // Unknown scopes are dropped; expiry and label are inherited.
    expect(insert).toHaveBeenCalledWith(expect.anything(), {
      clientId: 'client-uuid',
      keyPrefix: '00112233',
      keyHash: DETERMINISTIC_HASH,
      label: 'Production',
      scopes: ['pix:cash_in:create'],
      expiresAt,
      signingSecret: DETERMINISTIC_TAIL
    });
    expect(revoke).toHaveBeenCalledWith(expect.anything(), 'old-id');
  });

  it('returns null without minting when the key does not exist', async () => {
    const insert = vi.fn();
    const revoke = vi.fn();
    const service = new ClientApiKeyService({
      repository: buildRepo({ findById: async () => null, insert, revoke }),
      sql: {} as never,
      randomBytes: fixedRandomBytes
    });
    expect(await service.rotate('missing')).toBeNull();
    expect(insert).not.toHaveBeenCalled();
    expect(revoke).not.toHaveBeenCalled();
  });

  it('returns null without minting when the key is already revoked', async () => {
    const insert = vi.fn();
    const revoke = vi.fn();
    const service = new ClientApiKeyService({
      repository: buildRepo({
        findById: async () => ({
          id: 'old-id',
          client_id: 'client-uuid',
          status: 'revoked',
          label: null,
          scopes: [],
          expires_at: null,
          signing_secret: null
        }),
        insert,
        revoke
      }),
      sql: {} as never,
      randomBytes: fixedRandomBytes
    });
    expect(await service.rotate('old-id')).toBeNull();
    expect(insert).not.toHaveBeenCalled();
    expect(revoke).not.toHaveBeenCalled();
  });

  it('runs mint + revoke inside the injected transaction runner', async () => {
    const calls: string[] = [];
    const findById = vi.fn().mockResolvedValue({
      id: 'old-id',
      client_id: 'client-uuid',
      status: 'active',
      label: null,
      scopes: ['pix:cash_in:create'],
      expires_at: null
    });
    const insert = vi.fn(async () => {
      calls.push('insert');
      return { id: 'new-id' };
    });
    const revoke = vi.fn(async () => {
      calls.push('revoke');
    });
    const withTransaction = vi.fn(async <T>(fn: (tx: never) => Promise<T>) => {
      calls.push('begin');
      const result = await fn({} as never);
      calls.push('commit');
      return result;
    });
    const service = new ClientApiKeyService({
      repository: buildRepo({ findById, insert, revoke }),
      sql: {} as never,
      withTransaction,
      randomBytes: fixedRandomBytes
    });

    await service.rotate('old-id');
    expect(withTransaction).toHaveBeenCalledTimes(1);
    expect(calls).toEqual(['begin', 'insert', 'revoke', 'commit']);
  });
});

describe('ClientApiKeyService.rotate ownership', () => {
  it('returns null without minting when the key belongs to another client', async () => {
    const insert = vi.fn();
    const revoke = vi.fn();
    const service = new ClientApiKeyService({
      repository: buildRepo({
        findById: async () => ({
          id: 'old-id',
          client_id: 'other-client',
          status: 'active',
          label: null,
          scopes: ['pix:cash_in:create'],
          expires_at: null,
          signing_secret: null
        }),
        insert,
        revoke
      }),
      sql: {} as never,
      randomBytes: fixedRandomBytes
    });
    expect(await service.rotate('old-id', 'client-uuid')).toBeNull();
    expect(insert).not.toHaveBeenCalled();
    expect(revoke).not.toHaveBeenCalled();
  });
});

describe('ClientApiKeyService.revoke', () => {
  it('revokes an owned key and reports success', async () => {
    const findById = vi.fn().mockResolvedValue({
      id: 'some-id',
      client_id: 'client-uuid',
      status: 'active',
      label: null,
      scopes: [],
      expires_at: null
    });
    const revoke = vi.fn().mockResolvedValue(undefined);
    const service = new ClientApiKeyService({
      repository: buildRepo({ findById, revoke }),
      sql: {} as never
    });
    expect(await service.revoke('some-id', 'client-uuid')).toBe(true);
    expect(revoke).toHaveBeenCalledWith(expect.anything(), 'some-id');
  });

  it('returns false without revoking an unknown key', async () => {
    const revoke = vi.fn();
    const service = new ClientApiKeyService({
      repository: buildRepo({ findById: async () => null, revoke }),
      sql: {} as never
    });
    expect(await service.revoke('missing', 'client-uuid')).toBe(false);
    expect(revoke).not.toHaveBeenCalled();
  });

  it('returns false (no revoke) for a key owned by another client', async () => {
    const revoke = vi.fn();
    const service = new ClientApiKeyService({
      repository: buildRepo({
        findById: async () => ({
          id: 'some-id',
          client_id: 'other-client',
          status: 'active',
          label: null,
          scopes: [],
          expires_at: null,
          signing_secret: null
        }),
        revoke
      }),
      sql: {} as never
    });
    expect(await service.revoke('some-id', 'client-uuid')).toBe(false);
    expect(revoke).not.toHaveBeenCalled();
  });
});

describe('ClientApiKeyService.listByClient', () => {
  it('maps rows to non-secret summaries and drops unknown scopes', async () => {
    const createdAt = new Date('2026-01-01T00:00:00.000Z');
    const service = new ClientApiKeyService({
      repository: buildRepo({
        listByClient: async (_sql, clientId) => {
          expect(clientId).toBe('client-uuid');
          return [
            {
              id: 'row-1',
              key_prefix: '00112233',
              label: 'Production',
              scopes: ['pix:cash_in:create', 'totally:made:up'],
              status: 'active',
              created_at: createdAt,
              last_used_at: null,
              expires_at: null,
              revoked_at: null
            }
          ];
        }
      }),
      sql: {} as never
    });
    const summaries = await service.listByClient('client-uuid');
    expect(summaries).toEqual([
      {
        id: 'row-1',
        keyPrefix: '00112233',
        label: 'Production',
        scopes: ['pix:cash_in:create'],
        status: 'active',
        createdAt,
        lastUsedAt: null,
        expiresAt: null,
        revokedAt: null
      }
    ]);
  });
});
