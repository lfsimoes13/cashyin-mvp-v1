import Fastify from 'fastify';
import { describe, expect, it, vi } from 'vitest';
import {
  PgUserClientGrantRepository,
  UserClientGrantService,
  type UserClientGrantRepository
} from '../../src/modules/auth/user-client-grant.js';
import { buildAuthPreHandlers } from '../../src/modules/auth/auth-enforcement.js';
import {
  BFF_ACTOR_USER_HEADER,
  BFF_CLIENT_HEADER,
  BFF_TOKEN_HEADER,
  DEFAULT_BFF_SCOPES
} from '../../src/modules/auth/authenticate.js';
import {
  ClientApiKeyService,
  type ClientApiKeyRepository
} from '../../src/modules/auth/client-api-key.service.js';
import { AUTH_SCOPES } from '../../src/shared/auth/auth-scopes.js';
import { toHttpError } from '../../src/shared/errors/app-error.js';
import type { Sql } from '../../src/shared/db/sql.js';

const SQL = {} as Sql;

function fakeRepo(overrides: Partial<UserClientGrantRepository> = {}): UserClientGrantRepository {
  return {
    findActiveScopes: async () => null,
    upsert: async (_sql, input) => ({
      actor_user_id: input.actorUserId,
      client_id: input.clientId,
      scopes: input.scopes as string[],
      status: 'active',
      created_at: new Date('2026-01-01T00:00:00.000Z'),
      updated_at: new Date('2026-01-01T00:00:00.000Z')
    }),
    listByClient: async () => [],
    revoke: async () => true,
    ...overrides
  };
}

describe('UserClientGrantService.resolveBffScopes', () => {
  it('returns null when the actor has no active grant', async () => {
    const service = new UserClientGrantService({ repository: fakeRepo(), sql: SQL });
    expect(await service.resolveBffScopes('user-1', 'tenant-1')).toBeNull();
  });

  it('returns only known scopes, dropping unrecognised strings', async () => {
    const service = new UserClientGrantService({
      repository: fakeRepo({ findActiveScopes: async () => ['pix:cash_in:read', 'bogus:scope'] }),
      sql: SQL
    });
    expect(await service.resolveBffScopes('user-1', 'tenant-1')).toEqual([AUTH_SCOPES.PIX_CASH_IN_READ]);
  });
});

describe('UserClientGrantService.grant', () => {
  it('rejects an unknown scope (422)', async () => {
    const service = new UserClientGrantService({ repository: fakeRepo(), sql: SQL });
    await expect(
      service.grant({ clientId: 't', actorUserId: 'u', scopes: ['not:a:scope'] })
    ).rejects.toMatchObject({ statusCode: 422 });
  });

  it('rejects a scope above the BFF ceiling (422)', async () => {
    const service = new UserClientGrantService({ repository: fakeRepo(), sql: SQL });
    await expect(
      service.grant({ clientId: 't', actorUserId: 'u', scopes: [AUTH_SCOPES.API_KEYS_MANAGE] })
    ).rejects.toMatchObject({ statusCode: 422 });
  });

  it('accepts a subset of DEFAULT_BFF_SCOPES', async () => {
    const upsert = vi.fn(fakeRepo().upsert);
    const service = new UserClientGrantService({ repository: fakeRepo({ upsert }), sql: SQL });
    const grant = await service.grant({
      clientId: 't',
      actorUserId: 'u',
      scopes: [AUTH_SCOPES.PIX_CASH_IN_READ, AUTH_SCOPES.BALANCE_READ]
    });
    expect(grant.scopes).toEqual([AUTH_SCOPES.PIX_CASH_IN_READ, AUTH_SCOPES.BALANCE_READ]);
    expect(upsert).toHaveBeenCalledOnce();
  });
});

// ── Authenticator RBAC integration (e2e via inject) ─────────────────────────

const BFF_SECRET = 'bff-shared-secret-value-0123456789abcd';

function bearerRepo(): ClientApiKeyRepository {
  return {
    findActiveByPrefix: async () => [],
    findById: async () => null,
    listByClient: async () => [],
    insert: async () => ({ id: 'x' }),
    touchLastUsed: async () => undefined,
    revoke: async () => undefined
  };
}

function buildApp(rbacMode: 'off' | 'enforce', grantedScopes: readonly string[] | null) {
  const app = Fastify();
  app.setErrorHandler((error, _request, reply) => {
    const httpError = toHttpError(error);
    void reply.status(httpError.statusCode).send({ error: { code: httpError.code } });
  });
  const service = new ClientApiKeyService({ repository: bearerRepo(), sql: {} as never });
  const auth = buildAuthPreHandlers({
    mode: 'enforce',
    clientApiKeyService: service,
    bffMode: 'enforce',
    bffSecret: BFF_SECRET,
    bffRbac: {
      mode: rbacMode,
      resolveScopes: async () => (grantedScopes === null ? null : (grantedScopes as never))
    }
  });
  app.get('/v1/balance', { preHandler: [auth.authenticate, auth.resolveAuthContext] }, async (request) => ({
    scopes: request.authContext?.scopes ?? null
  }));
  return app;
}

function callBff(app: ReturnType<typeof buildApp>) {
  return app.inject({
    method: 'GET',
    url: '/v1/balance',
    headers: {
      [BFF_TOKEN_HEADER]: BFF_SECRET,
      [BFF_ACTOR_USER_HEADER]: 'user-1',
      [BFF_CLIENT_HEADER]: 'tenant-1'
    }
  });
}

describe('BFF per-user RBAC in the authenticator (D7)', () => {
  it('off: actor gets the full DEFAULT_BFF_SCOPES', async () => {
    const app = buildApp('off', null);
    const res = await callBff(app);
    expect(res.statusCode).toBe(200);
    expect(res.json<{ scopes: string[] }>().scopes).toEqual(DEFAULT_BFF_SCOPES);
    await app.close();
  });

  it('enforce: actor scopes are the grant intersected with the ceiling', async () => {
    const app = buildApp('enforce', [AUTH_SCOPES.PIX_CASH_IN_READ, AUTH_SCOPES.BALANCE_READ]);
    const res = await callBff(app);
    expect(res.statusCode).toBe(200);
    expect(res.json<{ scopes: string[] }>().scopes).toEqual([
      AUTH_SCOPES.PIX_CASH_IN_READ,
      AUTH_SCOPES.BALANCE_READ
    ]);
    await app.close();
  });

  it('enforce: a granted scope above the ceiling is dropped by the intersection', async () => {
    const app = buildApp('enforce', [AUTH_SCOPES.PIX_CASH_IN_READ, AUTH_SCOPES.API_KEYS_MANAGE]);
    const res = await callBff(app);
    expect(res.statusCode).toBe(200);
    expect(res.json<{ scopes: string[] }>().scopes).toEqual([AUTH_SCOPES.PIX_CASH_IN_READ]);
    await app.close();
  });

  it('enforce: an actor with no active grant is rejected (403)', async () => {
    const app = buildApp('enforce', null);
    const res = await callBff(app);
    expect(res.statusCode).toBe(403);
    expect(res.json()).toEqual({ error: { code: 'auth_client_mismatch' } });
    await app.close();
  });
});

describe('PgUserClientGrantRepository', () => {
  it('findActiveScopes returns the row scopes or null', async () => {
    const repo = new PgUserClientGrantRepository();
    const sql = { query: vi.fn().mockResolvedValue({ rows: [{ scopes: ['pix:cash_in:read'] }] }) } as unknown as Sql;
    expect(await repo.findActiveScopes(sql, 'u', 't')).toEqual(['pix:cash_in:read']);

    const emptySql = { query: vi.fn().mockResolvedValue({ rows: [] }) } as unknown as Sql;
    expect(await repo.findActiveScopes(emptySql, 'u', 't')).toBeNull();
  });
});
