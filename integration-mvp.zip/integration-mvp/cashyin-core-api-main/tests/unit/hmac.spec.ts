import { describe, expect, it } from 'vitest';
import { signSha256, verifySha256Signature } from '../../src/shared/security/hmac.js';

describe('HMAC helpers', () => {
  it('validates sha256 signatures using timing-safe comparison', () => {
    const payload = JSON.stringify({ event: 'pix.charge.paid' });
    const secret = 'secret';
    const signature = signSha256(payload, secret);

    expect(verifySha256Signature(payload, signature, secret)).toBe(true);
    expect(verifySha256Signature(payload, 'sha256=invalid', secret)).toBe(false);
  });
});

