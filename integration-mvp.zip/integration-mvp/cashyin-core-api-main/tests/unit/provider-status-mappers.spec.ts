import { describe, expect, it } from 'vitest';
import {
  mapProviderCashInStatus,
  mapProviderCashOutStatus
} from '../../src/modules/transactions/provider-status-mappers.js';

describe('mapProviderCashInStatus', () => {
  it.each([
    ['PENDING', 'pending'],
    ['CREATED', 'pending'],
    ['RECEIVED', 'pending']
  ])('maps %s to `pending`', (raw, expected) => {
    const result = mapProviderCashInStatus(raw);
    expect(result.kind).toBe('mapped');
    if (result.kind === 'mapped') expect(result.status).toBe(expected);
  });

  it.each([
    ['PAID', 'paid'],
    ['CONFIRMED', 'paid'],
    ['SUCCESS', 'paid']
  ])('maps %s to `paid`', (raw, expected) => {
    const result = mapProviderCashInStatus(raw);
    expect(result.kind).toBe('mapped');
    if (result.kind === 'mapped') expect(result.status).toBe(expected);
  });

  it('maps EXPIRED to `expired`', () => {
    const result = mapProviderCashInStatus('EXPIRED');
    expect(result.kind).toBe('mapped');
    if (result.kind === 'mapped') expect(result.status).toBe('expired');
  });

  it.each([
    ['CANCELLED', 'cancelled'],
    ['CANCELED', 'cancelled']
  ])('maps %s to `cancelled` (both British/US spellings)', (raw, expected) => {
    const result = mapProviderCashInStatus(raw);
    expect(result.kind).toBe('mapped');
    if (result.kind === 'mapped') expect(result.status).toBe(expected);
  });

  it.each([
    ['FAILED', 'failed'],
    ['ERROR', 'failed'],
    ['REJECTED', 'failed']
  ])('maps %s to `failed`', (raw, expected) => {
    const result = mapProviderCashInStatus(raw);
    expect(result.kind).toBe('mapped');
    if (result.kind === 'mapped') expect(result.status).toBe(expected);
  });

  it('is case-insensitive and trims surrounding whitespace', () => {
    const result = mapProviderCashInStatus(' paid ');
    expect(result.kind).toBe('mapped');
    if (result.kind === 'mapped') {
      expect(result.status).toBe('paid');
      expect(result.normalisedKey).toBe('PAID');
    }
  });

  it('returns `unknown` (not silently `failed`) for unrecognised statuses', () => {
    const result = mapProviderCashInStatus('UNDER_REVIEW');
    expect(result).toEqual({
      kind: 'unknown',
      rawStatus: 'UNDER_REVIEW',
      normalisedKey: 'UNDER_REVIEW'
    });
  });

  it('preserves the original raw status verbatim for auditing', () => {
    const result = mapProviderCashInStatus('Paid');
    expect(result.rawStatus).toBe('Paid');
    expect(result.normalisedKey).toBe('PAID');
  });

  it('maps REFUNDED / REVERSED / DEVOLVED to `refunded` for cash-in', () => {
    const r = mapProviderCashInStatus('REFUNDED');
    expect(r.kind).toBe('mapped');
    if (r.kind === 'mapped') expect(r.status).toBe('refunded');
    const rev = mapProviderCashInStatus('REVERSED');
    expect(rev.kind).toBe('mapped');
    if (rev.kind === 'mapped') expect(rev.status).toBe('refunded');
  });

  it('does not map Cash-Out-only tokens like PROCESSING to a Cash-In status', () => {
    expect(mapProviderCashInStatus('PROCESSING').kind).toBe('unknown');
  });
});

describe('mapProviderCashOutStatus', () => {
  it.each([
    ['PROCESSING', 'processing'],
    ['PENDING', 'processing'],
    ['SENT', 'processing']
  ])('maps %s to `processing`', (raw, expected) => {
    const result = mapProviderCashOutStatus(raw);
    expect(result.kind).toBe('mapped');
    if (result.kind === 'mapped') expect(result.status).toBe(expected);
  });

  it.each([
    ['CONFIRMED', 'completed'],
    ['PAID', 'completed'],
    ['SUCCESS', 'completed'],
    ['COMPLETED', 'completed']
  ])('maps %s to `completed`', (raw, expected) => {
    const result = mapProviderCashOutStatus(raw);
    expect(result.kind).toBe('mapped');
    if (result.kind === 'mapped') expect(result.status).toBe(expected);
  });

  it.each([
    ['FAILED', 'failed'],
    ['ERROR', 'failed'],
    ['REJECTED', 'failed'],
    ['CANCELLED', 'failed'],
    ['CANCELED', 'failed']
  ])('maps %s to `failed`', (raw, expected) => {
    const result = mapProviderCashOutStatus(raw);
    expect(result.kind).toBe('mapped');
    if (result.kind === 'mapped') expect(result.status).toBe(expected);
  });

  it.each([
    ['REFUNDED', 'returned'],
    ['RETURNED', 'returned'],
    ['DEVOLVED', 'returned']
  ])('maps %s to `returned` (post-success bank return, distinct from initial failure)', (raw, expected) => {
    const result = mapProviderCashOutStatus(raw);
    expect(result.kind).toBe('mapped');
    if (result.kind === 'mapped') expect(result.status).toBe(expected);
  });

  it('returns `unknown` for unrecognised statuses', () => {
    const result = mapProviderCashOutStatus('FROZEN');
    expect(result).toEqual({
      kind: 'unknown',
      rawStatus: 'FROZEN',
      normalisedKey: 'FROZEN'
    });
  });

  it('is case-insensitive and trims surrounding whitespace', () => {
    const result = mapProviderCashOutStatus('  completed  ');
    expect(result.kind).toBe('mapped');
    if (result.kind === 'mapped') {
      expect(result.status).toBe('completed');
      expect(result.normalisedKey).toBe('COMPLETED');
    }
  });

  it('does not map Cash-In-only tokens like EXPIRED to a Cash-Out status', () => {
    expect(mapProviderCashOutStatus('EXPIRED').kind).toBe('unknown');
    expect(mapProviderCashOutStatus('CREATED').kind).toBe('unknown');
    expect(mapProviderCashOutStatus('RECEIVED').kind).toBe('unknown');
  });
});
