import { describe, expect, it } from 'vitest';
import {
  buildClaimFilterClauses,
  type WebhookEventClaimFilter
} from '../../src/modules/webhooks/webhook-event.repository.js';

/**
 * Locks the SQL fragments + bound parameters produced for the optional
 * `webhook_events` partition filter (Fase 1). The clauses are appended
 * after `$1` (the claim's `now`), so the first filter parameter is `$2`.
 */
describe('buildClaimFilterClauses', () => {
  it('returns no clauses and pushes nothing when the filter is undefined', () => {
    const params: unknown[] = [new Date()];
    expect(buildClaimFilterClauses(undefined, params)).toEqual([]);
    expect(params).toHaveLength(1);
  });

  it('returns no clauses for an empty filter object', () => {
    const params: unknown[] = [new Date()];
    expect(buildClaimFilterClauses({}, params)).toEqual([]);
    expect(params).toHaveLength(1);
  });

  it('builds the cashin-paid filter (operation_type + normalized_status)', () => {
    const params: unknown[] = [new Date()];
    const filter: WebhookEventClaimFilter = { operationType: 'cash_in', normalizedStatus: 'paid' };
    const clauses = buildClaimFilterClauses(filter, params);
    expect(clauses).toEqual(['operation_type = $2', 'normalized_status = $3']);
    expect(params.slice(1)).toEqual(['cash_in', 'paid']);
  });

  it('builds the cashin-default exclusion filter (NULL-safe <> ALL)', () => {
    const params: unknown[] = [new Date()];
    const filter: WebhookEventClaimFilter = {
      operationType: 'cash_in',
      excludeNormalizedStatus: ['paid']
    };
    const clauses = buildClaimFilterClauses(filter, params);
    expect(clauses).toEqual([
      'operation_type = $2',
      '(normalized_status IS NULL OR normalized_status <> ALL($3::text[]))'
    ]);
    expect(params.slice(1)).toEqual(['cash_in', ['paid']]);
  });

  it('builds the cashout filter (operation_type only)', () => {
    const params: unknown[] = [new Date()];
    const clauses = buildClaimFilterClauses({ operationType: 'cash_out' }, params);
    expect(clauses).toEqual(['operation_type = $2']);
    expect(params.slice(1)).toEqual(['cash_out']);
  });

  it('supports normalized_status_kind and event_types lists', () => {
    const params: unknown[] = [new Date()];
    const filter: WebhookEventClaimFilter = {
      normalizedStatusKind: 'cash_in',
      eventTypes: ['pix.charge.paid', 'charge.paid']
    };
    const clauses = buildClaimFilterClauses(filter, params);
    expect(clauses).toEqual([
      'normalized_status_kind = $2',
      'event_type = ANY($3::text[])'
    ]);
    expect(params.slice(1)).toEqual(['cash_in', ['pix.charge.paid', 'charge.paid']]);
  });

  it('ignores empty array filters', () => {
    const params: unknown[] = [new Date()];
    const clauses = buildClaimFilterClauses(
      { excludeNormalizedStatus: [], eventTypes: [] },
      params
    );
    expect(clauses).toEqual([]);
    expect(params).toHaveLength(1);
  });
});
