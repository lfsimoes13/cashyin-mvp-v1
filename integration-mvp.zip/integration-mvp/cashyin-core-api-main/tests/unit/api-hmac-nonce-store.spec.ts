import { describe, expect, it, vi } from 'vitest';
import {
  InMemoryApiHmacNonceStore,
  PgApiHmacNonceStore
} from '../../src/modules/auth/api-hmac-nonce-store.js';
import type { Sql } from '../../src/shared/db/sql.js';

describe('InMemoryApiHmacNonceStore', () => {
  it('records a fresh nonce and rejects its replay within the window', async () => {
    const store = new InMemoryApiHmacNonceStore();
    expect(await store.checkAndRecord('k1', 'n1', 2_000, 1_000)).toBe(true);
    expect(await store.checkAndRecord('k1', 'n1', 2_000, 1_000)).toBe(false);
  });

  it('treats an expired nonce as fresh again', async () => {
    const store = new InMemoryApiHmacNonceStore();
    expect(await store.checkAndRecord('k1', 'n1', 2_000, 1_000)).toBe(true);
    // now (3_000) is past the recorded expiry (2_000) → fresh again
    expect(await store.checkAndRecord('k1', 'n1', 4_000, 3_000)).toBe(true);
  });

  it('scopes nonces per api key', async () => {
    const store = new InMemoryApiHmacNonceStore();
    expect(await store.checkAndRecord('k1', 'n1', 2_000, 1_000)).toBe(true);
    expect(await store.checkAndRecord('k2', 'n1', 2_000, 1_000)).toBe(true);
  });
});

/**
 * Fake `Sql` that mimics the atomic upsert semantics of the real statement:
 * insert when absent, "revive" (fresh) when the prior row has expired,
 * otherwise report a replay.
 */
function fakeSql(now = () => 1_000) {
  const table = new Map<string, number>();
  const deletes = { count: 0 };
  const query = vi.fn(async (text: string, params?: unknown[]) => {
    if (text.includes('DELETE FROM api_hmac_nonces')) {
      deletes.count += 1;
      for (const [k, exp] of table) if (exp <= now()) table.delete(k);
      return { rows: [], rowCount: 0 };
    }
    const [apiKeyId, nonce, expiresAtMs] = params as [string, string, number];
    const key = `${apiKeyId}:${nonce}`;
    const existing = table.get(key);
    const fresh = existing === undefined || existing <= now();
    if (fresh) table.set(key, expiresAtMs);
    return { rows: [{ fresh }], rowCount: 1 };
  });
  return { sql: { query } as unknown as Sql, table, deletes, query };
}

describe('PgApiHmacNonceStore', () => {
  it('reports fresh on first sight and replay on the second', async () => {
    const { sql } = fakeSql();
    const store = new PgApiHmacNonceStore(sql);
    expect(await store.checkAndRecord('k1', 'n1', 9_999, 1_000)).toBe(true);
    expect(await store.checkAndRecord('k1', 'n1', 9_999, 1_000)).toBe(false);
  });

  it('revives an expired nonce as fresh', async () => {
    let clock = 1_000;
    const { sql } = fakeSql(() => clock);
    const store = new PgApiHmacNonceStore(sql);
    expect(await store.checkAndRecord('k1', 'n1', 2_000, clock)).toBe(true);
    clock = 3_000; // past the stored expiry
    expect(await store.checkAndRecord('k1', 'n1', 4_000, clock)).toBe(true);
  });

  it('passes the nonce/key/expiry to the upsert statement', async () => {
    const { sql, query } = fakeSql();
    const store = new PgApiHmacNonceStore(sql);
    await store.checkAndRecord('key-abc', 'nonce-xyz', 12_345, 1_000);
    expect(query).toHaveBeenCalledWith(expect.stringContaining('INSERT INTO api_hmac_nonces'), [
      'key-abc',
      'nonce-xyz',
      12_345
    ]);
  });

  it('opportunistically prunes expired rows on the configured cadence', async () => {
    const { sql, deletes } = fakeSql();
    const store = new PgApiHmacNonceStore(sql, 2);
    await store.checkAndRecord('k', 'a', 9_999, 1_000);
    expect(deletes.count).toBe(0);
    await store.checkAndRecord('k', 'b', 9_999, 1_000); // 2nd call → prune
    expect(deletes.count).toBe(1);
  });

  it('returns false (replay-safe) when the query yields no row', async () => {
    const sql = { query: vi.fn(async () => ({ rows: [], rowCount: 0 })) } as unknown as Sql;
    const store = new PgApiHmacNonceStore(sql);
    expect(await store.checkAndRecord('k', 'n', 9_999, 1_000)).toBe(false);
  });
});
