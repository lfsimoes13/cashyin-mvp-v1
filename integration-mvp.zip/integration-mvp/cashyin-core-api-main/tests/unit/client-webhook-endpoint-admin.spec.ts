import { describe, expect, it, vi } from 'vitest';
import {
  ClientWebhookEndpointAdminService,
  type ClientWebhookEndpointAdminRepository
} from '../../src/modules/webhooks/client-webhook-endpoint.admin.js';

const NOW = new Date('2026-01-01T00:00:00.000Z');

function row(overrides: Record<string, unknown> = {}) {
  return {
    id: 'wh-1',
    client_id: 'tenant-1',
    event_pattern: '*',
    target_url: 'https://x.test/hook',
    status: 'active' as const,
    description: null,
    last_delivered_at: null,
    last_failure_at: null,
    created_at: NOW,
    updated_at: NOW,
    ...overrides
  };
}

function buildRepo(overrides: Partial<ClientWebhookEndpointAdminRepository> = {}): ClientWebhookEndpointAdminRepository {
  return {
    create: async (_sql, input) => row({ target_url: input.targetUrl, event_pattern: input.eventPattern }),
    listByClient: async () => [row()],
    findByIdForClient: async () => row(),
    update: async () => row({ status: 'disabled' }),
    ...overrides
  };
}

describe('ClientWebhookEndpointAdminService.create', () => {
  it('generates a signing secret server-side and never persists it in the projection', async () => {
    const create = vi.fn(async (_sql: unknown, input: { targetUrl: string }) => row({ target_url: input.targetUrl }));
    const service = new ClientWebhookEndpointAdminService({
      repository: buildRepo({ create }),
      sql: {} as never,
      randomBytes: (size) => Buffer.alloc(size, 7)
    });
    const result = await service.create({
      clientId: 'tenant-1',
      eventPattern: '*',
      targetUrl: 'https://x.test/hook'
    });
    expect(result.signingSecret).toBe('07'.repeat(32));
    expect(create).toHaveBeenCalledWith(
      expect.anything(),
      expect.objectContaining({ clientId: 'tenant-1', signingSecret: '07'.repeat(32) })
    );
    // The returned endpoint projection carries no secret field.
    expect(result.endpoint).not.toHaveProperty('signingSecret');
  });

  it('maps a unique-violation into a 409 conflict', async () => {
    const service = new ClientWebhookEndpointAdminService({
      repository: buildRepo({
        create: async () => {
          throw Object.assign(new Error('dup'), { code: '23505' });
        }
      }),
      sql: {} as never
    });
    await expect(
      service.create({ clientId: 'tenant-1', eventPattern: '*', targetUrl: 'https://x.test/hook' })
    ).rejects.toMatchObject({ statusCode: 409, code: 'webhook_endpoint_conflict' });
  });
});

describe('ClientWebhookEndpointAdminService.update/disable', () => {
  it('returns null when the endpoint does not belong to the client', async () => {
    const service = new ClientWebhookEndpointAdminService({
      repository: buildRepo({ update: async () => null }),
      sql: {} as never
    });
    expect(await service.update('tenant-1', 'missing', { status: 'disabled' })).toBeNull();
  });

  it('disable patches the status to disabled', async () => {
    const update = vi.fn(async () => row({ status: 'disabled' }));
    const service = new ClientWebhookEndpointAdminService({
      repository: buildRepo({ update }),
      sql: {} as never
    });
    const result = await service.disable('tenant-1', 'wh-1');
    expect(result?.status).toBe('disabled');
    expect(update).toHaveBeenCalledWith(expect.anything(), 'tenant-1', 'wh-1', { status: 'disabled' });
  });
});
