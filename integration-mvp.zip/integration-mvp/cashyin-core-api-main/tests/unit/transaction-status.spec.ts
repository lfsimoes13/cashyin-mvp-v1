import { describe, expect, it } from 'vitest';
import {
  CASH_IN_STATUSES,
  CASH_OUT_STATUSES,
  TERMINAL_CASH_IN_STATUSES,
  TERMINAL_CASH_OUT_STATUSES,
  TRANSACTION_TYPES,
  isCashInStatus,
  isCashOutStatus,
  isTerminalCashInStatus,
  isTerminalCashOutStatus,
  isTransactionType
} from '../../src/modules/transactions/status.js';

describe('canonical status arrays', () => {
  it('contains exactly the 6 documented Cash-In statuses, in the documented order', () => {
    expect([...CASH_IN_STATUSES]).toEqual(['pending', 'paid', 'expired', 'cancelled', 'failed', 'refunded']);
  });

  it('contains exactly the 4 documented Cash-Out statuses, in the documented order', () => {
    expect([...CASH_OUT_STATUSES]).toEqual(['processing', 'completed', 'failed', 'returned']);
  });

  it('exposes only `cash_in` and `cash_out` as transaction types', () => {
    expect([...TRANSACTION_TYPES]).toEqual(['cash_in', 'cash_out']);
  });

  it('keeps Cash-In and Cash-Out vocabularies disjoint except for the shared `failed` token', () => {
    const overlap = (CASH_IN_STATUSES as readonly string[]).filter((s) =>
      (CASH_OUT_STATUSES as readonly string[]).includes(s)
    );
    expect(overlap).toEqual(['failed']);
  });

  it('does not reintroduce legacy `confirmed` / `reversed` / `created` tokens', () => {
    const all = new Set([...CASH_IN_STATUSES, ...CASH_OUT_STATUSES]);
    expect(all.has('confirmed' as never)).toBe(false);
    expect(all.has('reversed' as never)).toBe(false);
    expect(all.has('created' as never)).toBe(false);
  });
});

describe('terminal status sets', () => {
  it('marks every Cash-In status terminal except `pending`', () => {
    expect(isTerminalCashInStatus('pending')).toBe(false);
    expect(isTerminalCashInStatus('paid')).toBe(true);
    expect(isTerminalCashInStatus('expired')).toBe(true);
    expect(isTerminalCashInStatus('cancelled')).toBe(true);
    expect(isTerminalCashInStatus('failed')).toBe(true);
    expect(isTerminalCashInStatus('refunded')).toBe(true);
  });

  it('marks every Cash-Out status terminal except `processing`', () => {
    expect(isTerminalCashOutStatus('processing')).toBe(false);
    expect(isTerminalCashOutStatus('completed')).toBe(true);
    expect(isTerminalCashOutStatus('failed')).toBe(true);
    expect(isTerminalCashOutStatus('returned')).toBe(true);
  });

  it('exposes terminal sets with the documented cardinality', () => {
    expect(TERMINAL_CASH_IN_STATUSES.size).toBe(5);
    expect(TERMINAL_CASH_OUT_STATUSES.size).toBe(3);
  });
});

describe('type guards', () => {
  it('accepts canonical Cash-In values and rejects everything else', () => {
    expect(isCashInStatus('paid')).toBe(true);
    expect(isCashInStatus('refunded')).toBe(true);
    expect(isCashInStatus('processing')).toBe(false);
    expect(isCashInStatus('confirmed')).toBe(false);
    expect(isCashInStatus('completed')).toBe(false);
    expect(isCashInStatus(undefined)).toBe(false);
    expect(isCashInStatus(42)).toBe(false);
  });

  it('accepts canonical Cash-Out values and rejects everything else', () => {
    expect(isCashOutStatus('completed')).toBe(true);
    expect(isCashOutStatus('returned')).toBe(true);
    expect(isCashOutStatus('paid')).toBe(false);
    expect(isCashOutStatus('reversed')).toBe(false);
    expect(isCashOutStatus(null)).toBe(false);
  });

  it('accepts only `cash_in` / `cash_out` as TransactionType', () => {
    expect(isTransactionType('cash_in')).toBe(true);
    expect(isTransactionType('cash_out')).toBe(true);
    expect(isTransactionType('pix_charge')).toBe(false);
    expect(isTransactionType('')).toBe(false);
    expect(isTransactionType(0)).toBe(false);
  });
});
