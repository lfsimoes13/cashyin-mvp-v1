/**
 * Unit tests for the E2E redaction utilities.
 * No network calls, no real credentials.
 */

import { describe, it, expect } from 'vitest';
import { redactObject, redactAuthHeader, redactHeaders, safeStringify } from '../../scripts/e2e/fyhub/redact.js';

describe('redactObject', () => {
  it('leaves non-sensitive fields intact', () => {
    const result = redactObject({ txid: 'abc123', status: 'paid', amount: 100 });
    expect(result).toEqual({ txid: 'abc123', status: 'paid', amount: 100 });
  });

  it('redacts fields with "secret" in the key', () => {
    const result = redactObject({ clientSecret: 'super-secret-value' }) as Record<string, string>;
    expect(result.clientSecret).not.toBe('super-secret-value');
    expect(result.clientSecret).toContain('[REDACTED]');
  });

  it('redacts fields with "password" in the key', () => {
    const result = redactObject({ certPassword: 'p4ssw0rd' }) as Record<string, string>;
    expect(result.certPassword).toContain('[REDACTED]');
  });

  it('redacts fields with "token" in the key', () => {
    const result = redactObject({ accessToken: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.abc.def' }) as Record<string, string>;
    expect(result.accessToken).toContain('[REDACTED]');
  });

  it('truncates rather than fully replaces long token values', () => {
    const longToken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiYWRtaW4ifQ.sig';
    const result = redactObject({ accessToken: longToken }) as Record<string, string>;
    // TOKEN_TRUNCATE = 12 chars from the token then "…[REDACTED]"
    expect(result.accessToken).toMatch(/^eyJhbGciOiJI/);
    expect(result.accessToken).toContain('[REDACTED]');
    expect(result.accessToken).not.toBe(longToken);
  });

  it('redacts cert/pfx fields', () => {
    const result = redactObject({ pfx: Buffer.from('binary-cert-data') }) as Record<string, string>;
    expect(result.pfx).toContain('[REDACTED]');
  });

  it('handles nested objects', () => {
    const result = redactObject({
      outer: { inner: { clientSecret: 'secret123', name: 'test' } },
    }) as { outer: { inner: Record<string, string> } };
    expect(result.outer.inner.clientSecret).toContain('[REDACTED]');
    expect(result.outer.inner.name).toBe('test');
  });

  it('handles arrays', () => {
    const result = redactObject([{ token: 'abc' }, { value: 'safe' }]) as Array<Record<string, string>>;
    expect(result[0]?.token).toContain('[REDACTED]');
    expect(result[1]?.value).toBe('safe');
  });

  it('handles null and primitives', () => {
    expect(redactObject(null)).toBeNull();
    expect(redactObject(42)).toBe(42);
    expect(redactObject('hello')).toBe('hello');
  });

  it('case-insensitive key matching', () => {
    const result = redactObject({ CLIENT_SECRET: 'secret' }) as Record<string, string>;
    expect(result.CLIENT_SECRET).toContain('[REDACTED]');
  });
});

describe('redactAuthHeader', () => {
  it('truncates a bearer token', () => {
    const result = redactAuthHeader('Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.abc.def');
    expect(result).toMatch(/^Bearer eyJhbGciOiJI/);
    expect(result).toContain('[REDACTED]');
    expect(result).not.toContain('eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9');
  });

  it('returns REDACTED for undefined', () => {
    expect(redactAuthHeader(undefined)).toBe('[REDACTED]');
  });

  it('returns REDACTED for header without scheme', () => {
    expect(redactAuthHeader('justtoken')).toBe('[REDACTED]');
  });
});

describe('redactHeaders', () => {
  it('redacts Authorization header', () => {
    const result = redactHeaders({ Authorization: 'Bearer secret-token-abc123' });
    expect(result.Authorization).toContain('[REDACTED]');
    expect(result.Authorization).not.toBe('Bearer secret-token-abc123');
  });

  it('preserves safe headers', () => {
    const result = redactHeaders({
      'Content-Type': 'application/json',
      'x-idempotency-key': 'abc123',
    });
    expect(result['Content-Type']).toBe('application/json');
    expect(result['x-idempotency-key']).toBe('abc123');
  });

  it('redacts x-api-key', () => {
    const result = redactHeaders({ 'x-api-key': 'ck_deadbeef1234' });
    expect(result['x-api-key']).toContain('[REDACTED]');
  });
});

describe('safeStringify', () => {
  it('produces valid JSON with redacted secrets', () => {
    const obj = {
      clientId: 'abc',
      clientSecret: 'mysecret',
      amount: 100,
    };
    const json = safeStringify(obj);
    const parsed = JSON.parse(json) as { clientId: string; clientSecret: string; amount: number };
    expect(parsed.clientId).toBe('abc');
    expect(parsed.clientSecret).not.toBe('mysecret');
    expect(parsed.amount).toBe(100);
  });
});
