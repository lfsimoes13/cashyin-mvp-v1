import { describe, expect, it } from 'vitest';
import { PgOutboxRepository } from '../../src/modules/outbox/outbox.repository.js';
import type { Sql } from '../../src/shared/db/sql.js';

type Captured = { text: string; params: unknown[] };

/**
 * Minimal query-capturing stub. Records the SQL text + bound params so we
 * can assert the priority column / ordering without a live database, then
 * returns a single fully-shaped row so `mapRow` succeeds.
 */
function stubSql(): { sql: Sql; calls: Captured[] } {
  const calls: Captured[] = [];
  const row = {
    id: 'evt-1',
    aggregate_type: 'cash_in',
    aggregate_id: 'ch-1',
    event_type: 'pix.cash_in.paid',
    payload: {},
    status: 'pending',
    attempts: 0,
    priority: 10,
    available_at: new Date(),
    created_at: new Date(),
    updated_at: new Date(),
    published_at: null
  };
  const sql = {
    query: (text: string, params: unknown[] = []) => {
      calls.push({ text, params });
      return Promise.resolve({ rows: [row], rowCount: 1 });
    }
  } as unknown as Sql;
  return { sql, calls };
}

describe('PgOutboxRepository priority (Fase 2)', () => {
  it('derives priority from event_type on insert when not supplied', async () => {
    const { sql, calls } = stubSql();
    const repo = new PgOutboxRepository();
    await repo.insert(sql, {
      aggregateType: 'cash_in',
      aggregateId: 'ch-1',
      eventType: 'pix.cash_in.paid',
      payload: {}
    });
    expect(calls[0]!.text).toContain('priority');
    // params: [aggregateType, aggregateId, eventType, payload, availableAt, priority]
    expect(calls[0]!.params[5]).toBe(10);
  });

  it('derives lower priority for cash-out events', async () => {
    const { sql, calls } = stubSql();
    const repo = new PgOutboxRepository();
    await repo.insert(sql, {
      aggregateType: 'cashout',
      aggregateId: 'co-1',
      eventType: 'pix.cash_out.completed',
      payload: {}
    });
    expect(calls[0]!.params[5]).toBe(60);
  });

  it('honours an explicit priority override', async () => {
    const { sql, calls } = stubSql();
    const repo = new PgOutboxRepository();
    await repo.insert(sql, {
      aggregateType: 'cash_in',
      aggregateId: 'ch-1',
      eventType: 'pix.cash_in.paid',
      payload: {},
      priority: 5
    });
    expect(calls[0]!.params[5]).toBe(5);
  });

  it('orders the claim by priority before availability and creation', async () => {
    const { sql, calls } = stubSql();
    const repo = new PgOutboxRepository();
    await repo.claimNextPending(sql, { now: new Date() });
    const text = calls[0]!.text;
    expect(text).toContain('ORDER BY priority ASC, available_at ASC, created_at ASC');
    // Concurrency safety must be preserved.
    expect(text).toContain('FOR UPDATE SKIP LOCKED');
  });
});

describe('PgOutboxRepository claim partitioning (Fase B1)', () => {
  it('adds no event-type clause when no filter is supplied', async () => {
    const { sql, calls } = stubSql();
    const repo = new PgOutboxRepository();
    await repo.claimNextPending(sql, { now: new Date(), aggregateTypes: ['cash_in', 'cashout'] });
    const text = calls[0]!.text;
    expect(text).not.toContain('event_type = ANY');
    expect(text).not.toContain('NOT (event_type = ANY');
  });

  it('adds an include clause and binds the event-type whitelist', async () => {
    const { sql, calls } = stubSql();
    const repo = new PgOutboxRepository();
    const now = new Date();
    await repo.claimNextPending(sql, {
      now,
      aggregateTypes: ['cash_in', 'cashout'],
      eventTypes: ['pix.cash_in.paid']
    });
    const { text, params } = calls[0]!;
    expect(text).toContain('AND event_type = ANY($3::text[])');
    expect(params).toEqual([now, ['cash_in', 'cashout'], ['pix.cash_in.paid']]);
  });

  it('adds an exclude clause and binds the event-type blacklist', async () => {
    const { sql, calls } = stubSql();
    const repo = new PgOutboxRepository();
    const now = new Date();
    await repo.claimNextPending(sql, {
      now,
      aggregateTypes: ['cash_in', 'cashout'],
      excludeEventTypes: ['pix.cash_in.paid']
    });
    const { text, params } = calls[0]!;
    expect(text).toContain('AND NOT (event_type = ANY($3::text[]))');
    expect(params).toEqual([now, ['cash_in', 'cashout'], ['pix.cash_in.paid']]);
  });
});
