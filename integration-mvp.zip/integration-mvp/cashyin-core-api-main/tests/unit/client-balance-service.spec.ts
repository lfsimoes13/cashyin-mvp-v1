import { describe, expect, it, vi } from 'vitest';
import {
  ClientBalanceService,
  PgClientBalanceRepository,
  type BalanceSnapshot,
  type ClientBalanceRepository
} from '../../src/modules/balances/client-balance.service.js';
import type { Sql } from '../../src/shared/db/sql.js';

const CLIENT_ID = '11111111-1111-4111-8111-111111111111';
const POOL = { __pool: true } as unknown as Sql;

function buildService(getSnapshot: ClientBalanceRepository['getSnapshot']) {
  const repository: ClientBalanceRepository = { getSnapshot };
  return new ClientBalanceService({ repository, sql: POOL });
}

function snapshot(overrides: Partial<BalanceSnapshot> = {}): BalanceSnapshot {
  return {
    availableCents: 0,
    blockedCents: 0,
    updatedAt: new Date('2026-05-28T04:00:00.000Z'),
    ...overrides
  };
}

describe('ClientBalanceService.getPublicBalance', () => {
  it('returns the snake_case public payload with all five fields populated', async () => {
    const getSnapshot = vi.fn(async () =>
      snapshot({
        availableCents: 250_000,
        blockedCents: 15_000,
        updatedAt: new Date('2026-05-28T03:30:00.000Z')
      })
    );
    const service = buildService(getSnapshot);

    const balance = await service.getPublicBalance(CLIENT_ID);

    expect(balance).toEqual({
      available_balance: 250_000,
      blocked_balance: 15_000,
      total_balance: 265_000,
      currency: 'BRL',
      updated_at: '2026-05-28T03:30:00.000Z'
    });
    expect(getSnapshot).toHaveBeenCalledTimes(1);
    expect(getSnapshot).toHaveBeenCalledWith(POOL, CLIENT_ID);
  });

  it('returns zeros and BRL currency when the client has no ledger or liquidity activity', async () => {
    const service = buildService(async () => snapshot());

    const balance = await service.getPublicBalance(CLIENT_ID);

    expect(balance.available_balance).toBe(0);
    expect(balance.blocked_balance).toBe(0);
    expect(balance.total_balance).toBe(0);
    expect(balance.currency).toBe('BRL');
  });

  it('total_balance = available_balance + blocked_balance', async () => {
    const service = buildService(async () =>
      snapshot({ availableCents: 7_000, blockedCents: 3_000 })
    );

    const balance = await service.getPublicBalance(CLIENT_ID);

    expect(balance.total_balance).toBe(balance.available_balance + balance.blocked_balance);
  });

  it('propagates a negative available_balance as an audit signal (does not clamp)', async () => {
    // Pathological scenario: cash-out webhook posted before the cash-in.
    // Service does not "clamp" the value; the caller (e.g. cash-out
    // balance check) is responsible for refusing the operation.
    const service = buildService(async () => snapshot({ availableCents: -1_500 }));

    const balance = await service.getPublicBalance(CLIENT_ID);

    expect(balance.available_balance).toBe(-1_500);
    expect(balance.total_balance).toBe(-1_500);
  });

  it('serialises updated_at as an ISO-8601 string in UTC', async () => {
    const service = buildService(async () =>
      snapshot({ updatedAt: new Date('2026-05-28T04:00:00Z') })
    );

    const balance = await service.getPublicBalance(CLIENT_ID);

    expect(balance.updated_at).toBe('2026-05-28T04:00:00.000Z');
    expect(() => new Date(balance.updated_at)).not.toThrow();
  });

  it('returns all-zeros with epoch updated_at when the client row does not exist', async () => {
    // The repository signals "client not found" by returning null.
    // The service must still produce a stable response (no throw)
    // because the auth layer already validated the client; this branch
    // is mostly defensive against deleted/inactive clients.
    const service = buildService(async () => null);

    const balance = await service.getPublicBalance(CLIENT_ID);

    expect(balance).toEqual({
      available_balance: 0,
      blocked_balance: 0,
      total_balance: 0,
      currency: 'BRL',
      updated_at: '1970-01-01T00:00:00.000Z'
    });
  });
});

describe('ClientBalanceService.getAvailableCents (internal cash-out balance check)', () => {
  it('returns just the availableCents value as a number', async () => {
    const service = buildService(async () =>
      snapshot({ availableCents: 12_345, blockedCents: 99_999 })
    );

    const cents = await service.getAvailableCents(CLIENT_ID);

    expect(cents).toBe(12_345);
  });

  it('returns 0 when no snapshot is available (missing client)', async () => {
    const service = buildService(async () => null);

    const cents = await service.getAvailableCents(CLIENT_ID);

    expect(cents).toBe(0);
  });
});

describe('PgClientBalanceRepository.getSnapshot', () => {
  function buildSql(row: { available_cents: string; blocked_cents: string; updated_at: Date } | undefined) {
    const query = vi.fn(async () => ({
      rows: row ? [row] : [],
      rowCount: row ? 1 : 0
    }));
    const sql = { query } as unknown as Sql;
    return { sql, query };
  }

  it('issues a single CTE query joining ledger_entries, liquidity_reservations and clients', async () => {
    const { sql, query } = buildSql({
      available_cents: '12345',
      blocked_cents: '0',
      updated_at: new Date('2026-05-28T03:00:00.000Z')
    });
    const repository = new PgClientBalanceRepository();

    const result = await repository.getSnapshot(sql, CLIENT_ID);

    expect(result).toEqual({
      availableCents: 12_345,
      blockedCents: 0,
      updatedAt: new Date('2026-05-28T03:00:00.000Z')
    });
    expect(query).toHaveBeenCalledTimes(1);
    const [statement, params] = query.mock.calls[0]!;
    expect(statement).toContain('FROM ledger_entries le');
    expect(statement).toContain('JOIN ledger_accounts la');
    expect(statement).toContain("account_type = 'client_liability'");
    expect(statement).toContain('FROM liquidity_reservations');
    expect(statement).toContain("status    = 'reserved'");
    expect(statement).toContain('FROM clients c');
    expect(params).toEqual([CLIENT_ID]);
  });

  it('returns null when the client row is missing', async () => {
    const { sql } = buildSql(undefined);
    const repository = new PgClientBalanceRepository();

    const result = await repository.getSnapshot(sql, CLIENT_ID);

    expect(result).toBeNull();
  });

  it('coerces bigint strings to numbers (preserves negative sums)', async () => {
    const { sql } = buildSql({
      available_cents: '-7500',
      blocked_cents: '500',
      updated_at: new Date('2026-05-28T03:00:00.000Z')
    });
    const repository = new PgClientBalanceRepository();

    const result = await repository.getSnapshot(sql, CLIENT_ID);

    expect(result?.availableCents).toBe(-7_500);
    expect(result?.blockedCents).toBe(500);
  });
});
