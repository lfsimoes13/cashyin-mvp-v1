/**
 * Unit tests for the certificate loader.
 * Uses temp files — no real certificate content, no real passphrase.
 */

import { describe, it, expect } from 'vitest';
import { writeFileSync, mkdirSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { randomBytes } from 'node:crypto';

function makeTempDir(): string {
  const dir = join(tmpdir(), `cert-loader-test-${randomBytes(6).toString('hex')}`);
  mkdirSync(dir, { recursive: true });
  return dir;
}

describe('loadCertFromPath', () => {
  it('loads PFX buffer from a valid file', async () => {
    const { loadCertFromPath } = await import('../../scripts/e2e/fyhub/certificate-loader.js');
    const dir = makeTempDir();
    const pfxPath = join(dir, 'test.pfx');
    const fakeContent = Buffer.from('fake-pfx-content');
    writeFileSync(pfxPath, fakeContent);

    const bundle = loadCertFromPath(pfxPath, 'test-pass');
    expect(bundle.pfx.equals(fakeContent)).toBe(true);
    expect(bundle.passphrase).toBe('test-pass');

    rmSync(dir, { recursive: true });
  });

  it('throws when file does not exist', async () => {
    const { loadCertFromPath } = await import('../../scripts/e2e/fyhub/certificate-loader.js');
    expect(() => loadCertFromPath('/nonexistent/cert.pfx', 'pass')).toThrow(
      /Certificate not found/,
    );
  });
});

describe('loadCert', () => {
  it('uses certPath when certZipPath is empty', async () => {
    const { loadCert } = await import('../../scripts/e2e/fyhub/certificate-loader.js');
    const dir = makeTempDir();
    const pfxPath = join(dir, 'test.pfx');
    const fakeContent = Buffer.from('direct-pfx');
    writeFileSync(pfxPath, fakeContent);

    const bundle = loadCert(pfxPath, '', 'my-pass');
    expect(bundle.pfx.equals(fakeContent)).toBe(true);
    expect(bundle.passphrase).toBe('my-pass');

    rmSync(dir, { recursive: true });
  });

  it('throws when neither certPath exists nor certZipPath is set', async () => {
    const { loadCert } = await import('../../scripts/e2e/fyhub/certificate-loader.js');
    expect(() => loadCert('/nonexistent/cert.pfx', '', 'pass')).toThrow(
      /Certificate not found/,
    );
  });
});
