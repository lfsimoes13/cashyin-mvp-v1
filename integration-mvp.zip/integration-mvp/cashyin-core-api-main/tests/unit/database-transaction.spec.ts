import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { Database } from '../../src/shared/db/database.js';

type FakeClient = {
  query: ReturnType<typeof vi.fn>;
  release: ReturnType<typeof vi.fn>;
};

type FakePool = {
  on: () => void;
  connect: () => Promise<FakeClient>;
};

function buildClient(handlers: Partial<{ begin: () => unknown; commit: () => unknown; rollback: () => unknown; other: (sql: string) => unknown }>): FakeClient {
  return {
    query: vi.fn(async (sql: string) => {
      if (sql === 'BEGIN') return handlers.begin?.();
      if (sql === 'COMMIT') return handlers.commit?.();
      if (sql === 'ROLLBACK') return handlers.rollback?.();
      return handlers.other?.(sql);
    }),
    release: vi.fn()
  };
}

function attachFakePool(db: Database, client: FakeClient): void {
  const fakePool: FakePool = {
    on: () => undefined,
    connect: async () => client
  };
  // Replace the real Pool with our fake so withTransaction operates against it.
  (db as unknown as { pool: FakePool }).pool = fakePool;
}

const ORIGINAL_DATABASE_URL = process.env.DATABASE_URL;

beforeEach(() => {
  process.env.DATABASE_URL = 'postgres://user:pass@localhost:5432/test';
});

afterEach(() => {
  if (ORIGINAL_DATABASE_URL === undefined) {
    delete process.env.DATABASE_URL;
  } else {
    process.env.DATABASE_URL = ORIGINAL_DATABASE_URL;
  }
});

describe('Database.withTransaction', () => {
  it('runs BEGIN/COMMIT and releases the client cleanly on success', async () => {
    const db = new Database({ connectionString: 'postgres://localhost/fake' });
    const client = buildClient({});
    attachFakePool(db, client);

    const result = await db.withTransaction(async () => 42);

    expect(result).toBe(42);
    expect(client.query).toHaveBeenNthCalledWith(1, 'BEGIN');
    expect(client.query).toHaveBeenNthCalledWith(2, 'COMMIT');
    expect(client.release).toHaveBeenCalledTimes(1);
    expect(client.release).toHaveBeenCalledWith(undefined);
  });

  it('rolls back and releases cleanly when the work throws but ROLLBACK succeeds', async () => {
    const db = new Database({ connectionString: 'postgres://localhost/fake' });
    const client = buildClient({});
    attachFakePool(db, client);

    const workError = new Error('work failed');
    await expect(
      db.withTransaction(async () => {
        throw workError;
      })
    ).rejects.toBe(workError);

    expect(client.query).toHaveBeenNthCalledWith(1, 'BEGIN');
    expect(client.query).toHaveBeenNthCalledWith(2, 'ROLLBACK');
    expect(client.release).toHaveBeenCalledWith(undefined);
  });

  it('destroys the client when ROLLBACK itself fails', async () => {
    const db = new Database({ connectionString: 'postgres://localhost/fake' });
    const rollbackError = new Error('rollback exploded');
    const client = buildClient({
      rollback: () => {
        throw rollbackError;
      }
    });
    attachFakePool(db, client);

    const workError = new Error('work failed');
    await expect(
      db.withTransaction(async () => {
        throw workError;
      })
    ).rejects.toBe(workError);

    expect(client.release).toHaveBeenCalledTimes(1);
    expect(client.release).toHaveBeenCalledWith(rollbackError);
  });

  it('still releases the client when COMMIT fails', async () => {
    const db = new Database({ connectionString: 'postgres://localhost/fake' });
    const commitError = new Error('commit broke');
    const client = buildClient({
      commit: () => {
        throw commitError;
      }
    });
    attachFakePool(db, client);

    await expect(db.withTransaction(async () => 1)).rejects.toBe(commitError);
    // After COMMIT throws, the implementation runs ROLLBACK; if that succeeds,
    // the client is released cleanly with undefined.
    expect(client.release).toHaveBeenCalledTimes(1);
    expect(client.release).toHaveBeenCalledWith(undefined);
  });
});
