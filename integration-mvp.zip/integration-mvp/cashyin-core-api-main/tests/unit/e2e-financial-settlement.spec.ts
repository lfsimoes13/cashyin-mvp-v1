/**
 * Unit tests for the E2E financial settlement utilities.
 * No network calls, no real credentials.
 */

import { describe, it, expect } from 'vitest';
import {
  calculateDelta,
  checkTotalBalanceInvariant,
  checkUpdatedAtAdvanced,
  expectedNetCreditCents,
  buildSettlement,
} from '../../scripts/e2e/fyhub/financial-settlement.js';
import { parsePublicBalance } from '../../scripts/e2e/fyhub/cashyin.client.js';
import type { PublicBalance } from '../../scripts/e2e/fyhub/types.js';

// ─── Fixtures ─────────────────────────────────────────────────────────────────

function makeBalance(overrides: Partial<PublicBalance> = {}): PublicBalance {
  return {
    available_balance: 0,
    blocked_balance: 0,
    total_balance: 0,
    currency: 'BRL',
    updated_at: '2026-05-28T05:00:00.000Z',
    ...overrides,
  };
}

// ─── parsePublicBalance ───────────────────────────────────────────────────────

describe('parsePublicBalance', () => {
  it('detects the new snake_case contract', () => {
    const raw = {
      available_balance: 10000,
      blocked_balance: 0,
      total_balance: 10000,
      currency: 'BRL' as const,
      updated_at: '2026-05-28T10:00:00.000Z',
    };
    const { parsed, contractVersion } = parsePublicBalance(raw);
    expect(contractVersion).toBe('new');
    expect(parsed?.available_balance).toBe(10000);
    expect(parsed?.blocked_balance).toBe(0);
    expect(parsed?.total_balance).toBe(10000);
  });

  it('detects the legacy camelCase contract and converts it', () => {
    const raw = { clientId: 'abc', availableCents: 5000, currency: 'BRL' };
    const { parsed, contractVersion } = parsePublicBalance(raw as never);
    expect(contractVersion).toBe('legacy');
    expect(parsed?.available_balance).toBe(5000);
    expect(parsed?.blocked_balance).toBe(0);
    expect(parsed?.total_balance).toBe(5000);
  });

  it('returns contractVersion=legacy even without clientId when availableCents is present', () => {
    const raw = { availableCents: 100, currency: 'BRL' };
    const { contractVersion } = parsePublicBalance(raw as never);
    expect(contractVersion).toBe('legacy');
  });

  it('returns unknown for unrecognised contract', () => {
    const { parsed, contractVersion } = parsePublicBalance({ foo: 'bar' } as never);
    expect(contractVersion).toBe('unknown');
    expect(parsed).toBeNull();
  });

  it('handles zero available balance with new contract', () => {
    const raw = makeBalance({ available_balance: 0, total_balance: 0 });
    const { parsed, contractVersion } = parsePublicBalance(raw);
    expect(contractVersion).toBe('new');
    expect(parsed?.available_balance).toBe(0);
  });
});

// ─── calculateDelta ───────────────────────────────────────────────────────────

describe('calculateDelta', () => {
  it('calculates positive available delta correctly', () => {
    const before = makeBalance({ available_balance: 0, blocked_balance: 0, total_balance: 0 });
    const after = makeBalance({ available_balance: 100, blocked_balance: 0, total_balance: 100 });
    const delta = calculateDelta(before, after);
    expect(delta?.available_balance_delta).toBe(100);
    expect(delta?.blocked_balance_delta).toBe(0);
    expect(delta?.total_balance_delta).toBe(100);
  });

  it('calculates negative delta when balance decreased', () => {
    const before = makeBalance({ available_balance: 500, total_balance: 500 });
    const after = makeBalance({ available_balance: 400, total_balance: 400 });
    const delta = calculateDelta(before, after);
    expect(delta?.available_balance_delta).toBe(-100);
  });

  it('returns null when before is null', () => {
    const after = makeBalance({ available_balance: 100 });
    expect(calculateDelta(null, after)).toBeNull();
  });

  it('returns null when after is null', () => {
    const before = makeBalance({ available_balance: 0 });
    expect(calculateDelta(before, null)).toBeNull();
  });

  it('returns null when both are null', () => {
    expect(calculateDelta(null, null)).toBeNull();
  });
});

// ─── checkTotalBalanceInvariant ───────────────────────────────────────────────

describe('checkTotalBalanceInvariant', () => {
  it('passes when total = available + blocked', () => {
    const b = makeBalance({ available_balance: 1000, blocked_balance: 200, total_balance: 1200 });
    expect(checkTotalBalanceInvariant(b)).toBe(true);
  });

  it('passes with 1¢ tolerance', () => {
    const b = makeBalance({ available_balance: 1000, blocked_balance: 200, total_balance: 1201 });
    expect(checkTotalBalanceInvariant(b)).toBe(true);
  });

  it('fails when total is wrong by more than 1¢', () => {
    const b = makeBalance({ available_balance: 1000, blocked_balance: 200, total_balance: 1205 });
    expect(checkTotalBalanceInvariant(b)).toBe(false);
  });

  it('passes with all zeros', () => {
    const b = makeBalance({ available_balance: 0, blocked_balance: 0, total_balance: 0 });
    expect(checkTotalBalanceInvariant(b)).toBe(true);
  });
});

// ─── checkUpdatedAtAdvanced ───────────────────────────────────────────────────

describe('checkUpdatedAtAdvanced', () => {
  it('returns true when after.updated_at is later', () => {
    const before = makeBalance({ updated_at: '2026-05-28T05:00:00.000Z' });
    const after  = makeBalance({ updated_at: '2026-05-28T05:00:30.000Z' });
    expect(checkUpdatedAtAdvanced(before, after)).toBe(true);
  });

  it('returns false when after.updated_at is equal', () => {
    const before = makeBalance({ updated_at: '2026-05-28T05:00:00.000Z' });
    const after  = makeBalance({ updated_at: '2026-05-28T05:00:00.000Z' });
    expect(checkUpdatedAtAdvanced(before, after)).toBe(false);
  });

  it('returns false when after.updated_at is earlier', () => {
    const before = makeBalance({ updated_at: '2026-05-28T05:00:30.000Z' });
    const after  = makeBalance({ updated_at: '2026-05-28T05:00:00.000Z' });
    expect(checkUpdatedAtAdvanced(before, after)).toBe(false);
  });

  it('returns null when before is null', () => {
    expect(checkUpdatedAtAdvanced(null, makeBalance())).toBeNull();
  });

  it('returns null when after is null', () => {
    expect(checkUpdatedAtAdvanced(makeBalance(), null)).toBeNull();
  });
});

// ─── expectedNetCreditCents ───────────────────────────────────────────────────

describe('expectedNetCreditCents', () => {
  it('returns gross - fee when fee is known', () => {
    expect(expectedNetCreditCents(100, 5)).toBe(95);
  });

  it('returns gross when fee is 0', () => {
    expect(expectedNetCreditCents(100, 0)).toBe(100);
  });

  it('applies the current cash-in rule (gross 100 − fee 15 = 85)', () => {
    expect(expectedNetCreditCents(100, 15)).toBe(85);
  });
});

// ─── buildSettlement ─────────────────────────────────────────────────────────

describe('buildSettlement', () => {
  // defaultExpectedFeeCents: 0 keeps the legacy "net = gross" expectation for
  // the generic structural tests below; fee-specific behaviour is covered in
  // its own describe block.
  const baseInput = {
    grossAmountCents: 100,
    feeAmountCents: null,
    defaultExpectedFeeCents: 0,
    contractVersionBefore: 'new' as const,
    contractVersionAfter: 'new' as const,
  };

  it('passes when delta matches expected and invariant holds', () => {
    const before = makeBalance({ available_balance: 0, blocked_balance: 0, total_balance: 0 });
    const after  = makeBalance({ available_balance: 100, blocked_balance: 0, total_balance: 100, updated_at: '2026-05-28T05:01:00.000Z' });
    const s = buildSettlement({ ...baseInput, balanceBefore: before, balanceAfter: after });
    expect(s.validation_result).toBe('passed');
    expect(s.available_balance_delta).toBe(100);
    expect(s.delta_matches_expected).toBe(true);
    expect(s.total_balance_invariant).toBe(true);
    expect(s.contract_is_new).toBe(true);
  });

  it('fails when balance did not change (ledger credit bug)', () => {
    const before = makeBalance({ available_balance: 0, blocked_balance: 0, total_balance: 0 });
    const after  = makeBalance({ available_balance: 0, blocked_balance: 0, total_balance: 0, updated_at: '2026-05-28T05:01:00.000Z' });
    const s = buildSettlement({ ...baseInput, balanceBefore: before, balanceAfter: after });
    expect(s.validation_result).toBe('failed');
    expect(s.delta_matches_expected).toBe(false);
    expect(s.validation_reason).toContain('ledger credit bug');
  });

  it('fails when delta is wrong amount (unexpected fee)', () => {
    const before = makeBalance({ available_balance: 0, total_balance: 0 });
    const after  = makeBalance({ available_balance: 50, total_balance: 50, updated_at: '2026-05-28T05:01:00.000Z' });
    const s = buildSettlement({ ...baseInput, balanceBefore: before, balanceAfter: after });
    expect(s.validation_result).toBe('failed');
    expect(s.available_balance_delta).toBe(50);
    expect(s.delta_matches_expected).toBe(false);
  });

  it('fails when total_balance invariant is violated', () => {
    const before = makeBalance({ available_balance: 0, blocked_balance: 0, total_balance: 0 });
    const after  = makeBalance({
      available_balance: 100,
      blocked_balance: 0,
      total_balance: 999, // wrong!
      updated_at: '2026-05-28T05:01:00.000Z',
    });
    const s = buildSettlement({ ...baseInput, balanceBefore: before, balanceAfter: after });
    expect(s.total_balance_invariant).toBe(false);
    expect(s.validation_result).toBe('failed');
  });

  it('skips when balance snapshots are missing', () => {
    const s = buildSettlement({ ...baseInput, balanceBefore: null, balanceAfter: null });
    expect(s.validation_result).toBe('skipped_with_reason');
    expect(s.available_balance_delta).toBeNull();
  });

  it('skips when contract is unknown', () => {
    const before = makeBalance();
    const after  = makeBalance({ updated_at: '2026-05-28T05:01:00.000Z' });
    const s = buildSettlement({
      ...baseInput,
      balanceBefore: before,
      balanceAfter: after,
      contractVersionBefore: 'unknown' as const,
    });
    expect(s.validation_result).toBe('skipped_with_reason');
    expect(s.validation_reason).toContain('Unrecognised balance contract');
  });

  it('reports legacy contract in gaps', () => {
    const before = makeBalance();
    const after  = makeBalance({ updated_at: '2026-05-28T05:01:00.000Z' });
    const s = buildSettlement({
      ...baseInput,
      balanceBefore: before,
      balanceAfter: after,
      contractVersionBefore: 'legacy' as const,
    });
    expect(s.gaps.some((g) => g.includes('legacy'))).toBe(true);
  });

  it('includes fee gaps in all cases', () => {
    const s = buildSettlement({ ...baseInput, balanceBefore: null, balanceAfter: null });
    expect(s.gaps.some((g) => g.includes('fee_amount_cents'))).toBe(true);
    expect(s.gaps.some((g) => g.includes('ledger_entries'))).toBe(true);
  });

  it('uses the exact fee when provided (ledger inspection)', () => {
    const before = makeBalance({ available_balance: 0, total_balance: 0 });
    const after  = makeBalance({ available_balance: 95, total_balance: 95, updated_at: '2026-05-28T05:01:00.000Z' });
    const s = buildSettlement({ ...baseInput, balanceBefore: before, balanceAfter: after, feeAmountCents: 5 });
    expect(s.expected_net_amount_cents).toBe(95);
    expect(s.expected_fee_amount_cents).toBe(5);
    expect(s.expected_fee_source).toBe('ledger_inspection');
    expect(s.delta_matches_expected).toBe(true);
    expect(s.validation_result).toBe('passed');
  });

  it('does not push the fee gap when the exact fee is known', () => {
    const before = makeBalance({ available_balance: 0, total_balance: 0 });
    const after  = makeBalance({ available_balance: 85, total_balance: 85, updated_at: '2026-05-28T05:01:00.000Z' });
    const s = buildSettlement({ ...baseInput, balanceBefore: before, balanceAfter: after, feeAmountCents: 15 });
    expect(s.gaps.some((g) => g.includes('not returned in public API response'))).toBe(false);
  });
});

// ─── buildSettlement — current cash-in fee rule (gross 100 − fee 15 = 85) ──────

describe('buildSettlement — default cash-in fee (15¢)', () => {
  const feeRuleInput = {
    grossAmountCents: 100,
    feeAmountCents: null, // no ledger inspection → fall back to default
    defaultExpectedFeeCents: 15,
    contractVersionBefore: 'new' as const,
    contractVersionAfter: 'new' as const,
  };

  it('passes when net credit is 85 (gross 100 − fee 15)', () => {
    const before = makeBalance({ available_balance: 485, blocked_balance: 0, total_balance: 485 });
    const after  = makeBalance({ available_balance: 570, blocked_balance: 0, total_balance: 570, updated_at: '2026-05-29T18:17:38.295Z' });
    const s = buildSettlement({ ...feeRuleInput, balanceBefore: before, balanceAfter: after });
    expect(s.available_balance_delta).toBe(85);
    expect(s.expected_fee_amount_cents).toBe(15);
    expect(s.expected_fee_source).toBe('configured_default');
    expect(s.expected_net_amount_cents).toBe(85);
    expect(s.delta_matches_expected).toBe(true);
    expect(s.validation_result).toBe('passed');
  });

  it('fails (no longer wrongly expects zero fee) when delta is the full gross', () => {
    const before = makeBalance({ available_balance: 0, total_balance: 0 });
    const after  = makeBalance({ available_balance: 100, total_balance: 100, updated_at: '2026-05-29T18:17:38.295Z' });
    const s = buildSettlement({ ...feeRuleInput, balanceBefore: before, balanceAfter: after });
    expect(s.available_balance_delta).toBe(100);
    expect(s.expected_net_amount_cents).toBe(85);
    expect(s.delta_matches_expected).toBe(false);
    expect(s.validation_result).toBe('failed');
  });

  it('records the configured default fee in the gaps', () => {
    const before = makeBalance({ available_balance: 0, total_balance: 0 });
    const after  = makeBalance({ available_balance: 85, total_balance: 85, updated_at: '2026-05-29T18:17:38.295Z' });
    const s = buildSettlement({ ...feeRuleInput, balanceBefore: before, balanceAfter: after });
    expect(s.gaps.some((g) => g.includes('configured default cash-in client fee (15¢)'))).toBe(true);
  });
});
