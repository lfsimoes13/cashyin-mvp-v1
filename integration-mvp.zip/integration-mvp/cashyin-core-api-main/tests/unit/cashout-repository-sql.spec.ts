/**
 * Regression guard for the PostgreSQL "inconsistent types deduced for
 * parameter" error in the cash-out repository.
 *
 * The `status` parameter is used both as a `cashout_status` column value and
 * inside text CASE comparisons. Without an explicit cast Postgres deduces two
 * conflicting types for the same bind and aborts the statement. These tests
 * pin the SQL so the `::text::cashout_status` cast can never be dropped again.
 *
 * No database is required: a fake `Sql` executor captures the query text and
 * params the repository emits.
 */

import { describe, it, expect } from 'vitest';
import { PgCashoutRepository } from '../../src/modules/cashouts/cashout.repository.js';
import type { CashoutInsertInput } from '../../src/modules/cashouts/cashout.repository.js';
import type { Sql } from '../../src/shared/db/sql.js';

type CapturedQuery = { text: string; params: unknown[] };

function makeRow() {
  const now = new Date('2026-05-30T12:00:00.000Z');
  return {
    id: '11111111-1111-1111-1111-111111111111',
    client_id: '22222222-2222-2222-2222-222222222222',
    provider_name: 'bents',
    provider_account_id: 'acct-1',
    external_id: null,
    provider_payment_id: null,
    amount_cents: '200',
    currency: 'BRL',
    pix_key: 'f17a24fa-d422-4d66-bfe0-1dd0e565cc1e',
    pix_key_type: 'EVP',
    receiver_name: null,
    receiver_document: null,
    receiver_bank: null,
    receiver_ispb: null,
    receiver_branch: null,
    receiver_account: null,
    receiver_account_type: null,
    status: 'processing',
    e2e_id: null,
    fee_amount_cents: '0',
    failure_reason: null,
    completed_at: null,
    failed_at: null,
    returned_at: null,
    created_at: now,
    updated_at: now,
  };
}

function makeFakeSql(captured: CapturedQuery[]): Sql {
  return {
    query: (text: string, params: unknown[]) => {
      captured.push({ text, params });
      return Promise.resolve({ rows: [makeRow()] });
    },
  } as unknown as Sql;
}

const baseInsert: CashoutInsertInput = {
  clientId: '22222222-2222-2222-2222-222222222222',
  providerName: 'bents',
  providerAccountId: 'acct-1',
  externalId: null,
  providerPaymentId: null,
  amountCents: 200,
  pixKey: 'f17a24fa-d422-4d66-bfe0-1dd0e565cc1e',
  pixKeyType: 'EVP',
  receiverName: null,
  receiverDocument: null,
  receiverBank: null,
  receiverIspb: null,
  receiverBranch: null,
  receiverAccount: null,
  receiverAccountType: null,
  status: 'processing',
  e2eId: null,
  feeAmountCents: 0,
  metadata: {},
};

describe('PgCashoutRepository SQL parameter typing', () => {
  it('insert casts the status parameter so $16 has a single deduced type', async () => {
    const captured: CapturedQuery[] = [];
    const repo = new PgCashoutRepository();

    await repo.insert(makeFakeSql(captured), baseInsert);

    expect(captured).toHaveLength(1);
    const { text, params } = captured[0]!;

    // The status column value must be cast, not a bare `$16`.
    expect(text).toContain('$16::text::cashout_status');
    expect(text).not.toMatch(/\$16,/);

    // The timestamp CASE branches still compare $16 as text — unchanged.
    expect(text).toContain("CASE WHEN $16 = 'completed' THEN now() END");
    expect(text).toContain("CASE WHEN $16 = 'failed'    THEN now() END");
    expect(text).toContain("CASE WHEN $16 = 'returned'  THEN now() END");

    // $16 is the 16th bind and carries the status string.
    expect(params).toHaveLength(19);
    expect(params[15]).toBe('processing');
  });

  it('markStatus casts the status parameter so $2 has a single deduced type', async () => {
    const captured: CapturedQuery[] = [];
    const repo = new PgCashoutRepository();

    await repo.markStatus(makeFakeSql(captured), '11111111-1111-1111-1111-111111111111', 'completed');

    expect(captured).toHaveLength(1);
    const { text, params } = captured[0]!;

    expect(text).toContain('$2::text::cashout_status');
    // CASE branches still compare $2 as text, predecessor guard unchanged.
    expect(text).toContain("CASE WHEN $2 = 'completed'");
    expect(text).toContain('status = ANY($3::cashout_status[])');

    expect(params[1]).toBe('completed');
  });
});
