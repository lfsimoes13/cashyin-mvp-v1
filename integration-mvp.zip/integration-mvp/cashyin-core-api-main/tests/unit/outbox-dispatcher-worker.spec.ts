import { describe, expect, it, vi } from 'vitest';
import type { Logger } from 'pino';
import type {
  ClientWebhookDispatcher,
  DispatchOutcome
} from '../../src/modules/webhooks/client-webhook.dispatcher.js';
import { createOutboxDispatcherWorker } from '../../src/workers/outbox-dispatcher/index.js';
import type { WorkerLoopIntervals } from '../../src/workers/runtime/worker-loop.js';

const INTERVALS: WorkerLoopIntervals = {
  busyMs: 0,
  idleStartMs: 1,
  idleMaxMs: 5,
  errorBaseMs: 1,
  errorMaxMs: 5,
  shutdownTimeoutMs: 1_000
};

const flush = (ms: number): Promise<void> =>
  new Promise((resolve) => setTimeout(resolve, ms));

function silentLogger(): Logger {
  const noop = (): void => undefined;
  const logger = {
    info: noop,
    warn: noop,
    error: noop,
    debug: noop,
    trace: noop,
    fatal: noop,
    level: 'silent',
    child(): Logger {
      return logger;
    }
  } as unknown as Logger;
  return logger;
}

function makeFakeDispatcher(outcomes: DispatchOutcome[]): ClientWebhookDispatcher {
  const queue = [...outcomes];
  return {
    dispatchNext: vi.fn(async (): Promise<DispatchOutcome> => {
      const next = queue.shift();
      if (!next) return { kind: 'empty' };
      return next;
    })
  } as unknown as ClientWebhookDispatcher;
}

describe('createOutboxDispatcherWorker — wiring', () => {
  it('drains delivered + skipped + retry + dlq outcomes without crashing', async () => {
    const dispatcher = makeFakeDispatcher([
      {
        kind: 'delivered',
        outboxEventId: 'ob-1',
        deliveryId: 'd-1',
        eventId: 'evt-1',
        eventType: 'pix.cash_in.paid',
        httpStatus: 200
      },
      { kind: 'skipped', outboxEventId: 'ob-2', reason: 'no_endpoint_configured' },
      {
        kind: 'retry',
        outboxEventId: 'ob-3',
        deliveryId: 'd-3',
        attemptNumber: 2,
        error: 'timeout',
        httpStatus: null,
        nextAttemptAt: new Date('2026-05-23T12:00:00Z')
      },
      {
        kind: 'dlq',
        outboxEventId: 'ob-4',
        deliveryId: 'd-4',
        attemptNumber: 8,
        error: 'permanent_4xx',
        httpStatus: 422
      }
    ]);

    const worker = createOutboxDispatcherWorker({
      dispatcher,
      logger: silentLogger(),
      intervals: INTERVALS
    });

    const running = worker.run();
    await flush(50);
    await worker.stop();
    const stats = await running;

    expect(stats.processed).toBeGreaterThanOrEqual(4);
    expect(stats.errors).toBe(0);
  });

  it('idle outcomes do NOT advance the processed counter', async () => {
    const dispatcher = makeFakeDispatcher([]);
    const worker = createOutboxDispatcherWorker({
      dispatcher,
      logger: silentLogger(),
      intervals: INTERVALS
    });
    const running = worker.run();
    await flush(20);
    await worker.stop();
    const stats = await running;
    expect(stats.processed).toBe(0);
    expect(stats.idle).toBeGreaterThanOrEqual(1);
  });
});
