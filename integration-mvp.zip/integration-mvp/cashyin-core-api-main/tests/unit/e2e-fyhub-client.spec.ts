/**
 * Unit tests for FyhubClient — all network calls are mocked.
 * No real credentials, no real HTTP requests.
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';

// ─── Mock undici fetch ────────────────────────────────────────────────────────

vi.mock('undici', () => {
  return {
    Agent: vi.fn().mockImplementation(() => ({
      destroy: vi.fn().mockResolvedValue(undefined),
    })),
    fetch: vi.fn(),
  };
});

import { fetch } from 'undici';
const mockFetch = vi.mocked(fetch);

// ─── Helpers ──────────────────────────────────────────────────────────────────

function makeFakeTokenResponse(overrides?: Partial<{ accessToken: string; expiresAt: number }>) {
  return {
    accessToken: overrides?.accessToken ?? 'eyJhbGciOiJIUzI1NiJ9.payload.sig',
    expiresAt: overrides?.expiresAt ?? Math.floor(Date.now() / 1000) + 1800,
    tokenType: 'Bearer',
    scope: 'pix.write pix.read account.read',
  };
}

function makeJsonResponse(body: unknown, status = 200) {
  return {
    status,
    ok: status >= 200 && status < 300,
    json: () => Promise.resolve(body),
    text: () => Promise.resolve(JSON.stringify(body)),
  } as unknown as Response;
}

// ─── Auth tests ───────────────────────────────────────────────────────────────

describe('FyhubClient.getToken', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('fetches and caches a token', async () => {
    const { FyhubClient } = await import('../../scripts/e2e/fyhub/fyhub.client.js');
    const client = new FyhubClient({
      baseUrl: 'https://pagamentos.fyhub.com.br/api/v2',
      clientId: 'test-client-id',
      clientSecret: 'test-secret',
      cert: { pfx: Buffer.from('fake-pfx'), passphrase: 'pass' },
    });

    const tokenResponse = makeFakeTokenResponse();
    mockFetch.mockResolvedValueOnce(makeJsonResponse(tokenResponse, 202) as never);

    const token = await client.getToken();
    expect(token).toBe(tokenResponse.accessToken);

    // Second call should use cache (fetch not called again)
    const token2 = await client.getToken();
    expect(token2).toBe(token);
    expect(mockFetch).toHaveBeenCalledTimes(1);
  });

  it('throws FyhubApiError on non-202/200 status', async () => {
    const { FyhubClient, FyhubApiError } = await import('../../scripts/e2e/fyhub/fyhub.client.js');
    const client = new FyhubClient({
      baseUrl: 'https://pagamentos.fyhub.com.br/api/v2',
      clientId: 'test',
      clientSecret: 'secret',
      cert: { pfx: Buffer.from('pfx'), passphrase: 'pass' },
    });

    mockFetch.mockResolvedValueOnce(
      makeJsonResponse({ message: 'Unauthorized' }, 401) as never,
    );

    await expect(client.getToken()).rejects.toThrow(FyhubApiError);
  });

  it('does NOT include clientSecret in logged request body', async () => {
    const { FyhubClient } = await import('../../scripts/e2e/fyhub/fyhub.client.js');
    const loggedRequests: unknown[] = [];
    const client = new FyhubClient({
      baseUrl: 'https://pagamentos.fyhub.com.br/api/v2',
      clientId: 'test',
      clientSecret: 'super-secret-value',
      cert: { pfx: Buffer.from('pfx'), passphrase: 'pass' },
      onRequest: (r) => loggedRequests.push(r),
    });

    mockFetch.mockResolvedValueOnce(makeJsonResponse(makeFakeTokenResponse(), 202) as never);
    await client.getToken();

    const logged = JSON.stringify(loggedRequests);
    expect(logged).not.toContain('super-secret-value');
  });
});

// ─── CashYin cash-out client (public contract mapping) ─────────────────────────

type SentRequest = { method?: string; headers?: Record<string, string>; body?: string };

function makePublicCashOut(overrides?: Record<string, unknown>) {
  return {
    id: 'co_123',
    external_ref: 'ext-abc',
    status: 'completed',
    amount: 200,
    currency: 'BRL',
    pix: {
      key: 'pix-key-uuid',
      key_type: 'EVP',
      e2e_id: 'E12345678202605301200abcdef0001',
    },
    receiver: {
      name: 'ACME LTDA',
      document_number: '***456789**',
      bank_name: 'Banco Exemplo',
      bank_ispb: '12345678',
      branch: '0001',
      account: '99999-9',
      account_type: 'CACC',
    },
    created_at: '2026-05-30T12:00:00.000Z',
    completed_at: '2026-05-30T12:00:01.000Z',
    ...overrides,
  };
}

describe('CashyinClient.createCashOut', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('sends the PUBLIC nested body with pix.key_type + Idempotency-Key header', async () => {
    const { CashyinClient } = await import('../../scripts/e2e/fyhub/cashyin.client.js');
    const client = new CashyinClient({ baseUrl: 'https://api.example', apiKey: 'ck_test' });

    mockFetch.mockResolvedValueOnce(makeJsonResponse(makePublicCashOut(), 201) as never);

    const { status } = await client.createCashOut(200, 'pix-key-uuid', 'EVP', 'ext-abc', 'idem-key-1', 'a description');

    expect(status).toBe(201);

    const call = mockFetch.mock.calls[0];
    expect(call).toBeDefined();
    const url = call?.[0];
    const init = call?.[1] as SentRequest | undefined;

    expect(url).toBe('https://api.example/v1/pix/cash-out');
    expect(init?.method).toBe('POST');
    expect(init?.headers?.['Idempotency-Key']).toBe('idem-key-1');

    const sent = JSON.parse(init?.body ?? '{}') as Record<string, unknown>;
    expect(sent).toEqual({
      amount: 200,
      pix: { key_type: 'EVP', key: 'pix-key-uuid' },
      external_ref: 'ext-abc',
      description: 'a description',
    });
    // Must NOT use the old flat / internal camelCase request fields.
    expect(sent).not.toHaveProperty('amountCents');
    expect(sent).not.toHaveProperty('pix_key');
    expect(sent).not.toHaveProperty('pix_key_type');
    expect(sent).not.toHaveProperty('pixKey');
    expect(sent).not.toHaveProperty('externalId');
  });

  it('omits description from the body when not supplied', async () => {
    const { CashyinClient } = await import('../../scripts/e2e/fyhub/cashyin.client.js');
    const client = new CashyinClient({ baseUrl: 'https://api.example', apiKey: 'ck_test' });

    mockFetch.mockResolvedValueOnce(makeJsonResponse(makePublicCashOut(), 201) as never);

    await client.createCashOut(150, 'key', 'CPF', 'ext-1', 'idem-2');

    const init = mockFetch.mock.calls[0]?.[1] as SentRequest | undefined;
    const sent = JSON.parse(init?.body ?? '{}') as Record<string, unknown>;
    expect(sent).toEqual({ amount: 150, pix: { key_type: 'CPF', key: 'key' }, external_ref: 'ext-1' });
    expect(sent).not.toHaveProperty('description');
  });

  it('parses the public response shape (nested receiver, lifecycle timestamps, no fee fields)', async () => {
    const { CashyinClient } = await import('../../scripts/e2e/fyhub/cashyin.client.js');
    const client = new CashyinClient({ baseUrl: 'https://api.example', apiKey: 'ck_test' });

    mockFetch.mockResolvedValueOnce(makeJsonResponse(makePublicCashOut(), 200) as never);

    const { data } = await client.getCashOut('co_123');

    expect(data.amount).toBe(200);
    expect(data.pix.key).toBe('pix-key-uuid');
    expect(data.pix.key_type).toBe('EVP');
    expect(data.external_ref).toBe('ext-abc');
    expect(data.pix.e2e_id).toBe('E12345678202605301200abcdef0001');
    expect(data.completed_at).toBe('2026-05-30T12:00:01.000Z');
    expect(data).not.toHaveProperty('type');
    expect(data).not.toHaveProperty('failed_at');
    expect(data).not.toHaveProperty('returned_at');

    // Canonical nested receiver with all keys present.
    expect(data.receiver).toMatchObject({
      name: 'ACME LTDA',
      document_number: '***456789**',
      bank_name: 'Banco Exemplo',
      bank_ispb: '12345678',
      branch: '0001',
      account: '99999-9',
      account_type: 'CACC',
    });

    // The public response exposes receiver identity only via the nested
    // `receiver` object and must not carry flat mirrors or internal fields.
    for (const k of [
      'receiver_name',
      'receiver_document',
      'clientFeeCents',
      'providerCostCents',
      'marginCents',
      'totalDebitAmountCents',
      'feeAmountCents',
      'feeAssessmentId',
      'reservationId',
      'providerPaymentId',
      'provider',
      'clientId',
    ]) {
      expect(data).not.toHaveProperty(k);
    }
  });
});

// ─── centsToBrl ───────────────────────────────────────────────────────────────

describe('centsToBrl', () => {
  it('converts 100 cents to 1.00', async () => {
    const { centsToBrl } = await import('../../scripts/e2e/fyhub/fyhub.client.js');
    expect(centsToBrl(100)).toBe(1.0);
  });

  it('converts 150 cents to 1.50', async () => {
    const { centsToBrl } = await import('../../scripts/e2e/fyhub/fyhub.client.js');
    expect(centsToBrl(150)).toBe(1.5);
  });

  it('keeps precision for 1 cent', async () => {
    const { centsToBrl } = await import('../../scripts/e2e/fyhub/fyhub.client.js');
    expect(centsToBrl(1)).toBeCloseTo(0.01, 5);
  });
});
