import { describe, expect, it } from 'vitest';

import {
  calculateFee,
  calculateMargin,
  calculateMarginAndSubsidy,
  calculateProviderCost,
  calculateProviderLiquidityRequired,
  calculateSubsidy,
  evaluateNegativeMarginPolicy,
  PRICING_ERROR_CODES
} from '../../src/modules/pricing/index.js';
import type {
  FeeFormula,
  NegativeMarginPolicy,
  ProviderCostFormula
} from '../../src/modules/pricing/index.js';
import { AppError } from '../../src/shared/errors/app-error.js';

/**
 * Helper to assert that a synchronous call throws an {@link AppError} with
 * a specific code. Avoids `expect.objectContaining` (which returns `any` and
 * triggers `@typescript-eslint/no-unsafe-argument` when fed to `toThrow`).
 */
function expectAppErrorCode(fn: () => unknown, code: string): void {
  let caught: unknown;
  try {
    fn();
  } catch (error) {
    caught = error;
  }
  expect(caught).toBeInstanceOf(AppError);
  expect((caught as AppError).code).toBe(code);
}

function feeFormula(overrides: Partial<FeeFormula> = {}): FeeFormula {
  return {
    fixedFeeCents: 0,
    variableFeeBps: 0,
    minFeeCents: null,
    maxFeeCents: null,
    roundingMode: 'round_half_up',
    billingMode: 'deduct_from_settlement',
    ...overrides
  };
}

function costFormula(overrides: Partial<ProviderCostFormula> = {}): ProviderCostFormula {
  return {
    fixedCostCents: 0,
    variableCostBps: 0,
    minCostCents: null,
    maxCostCents: null,
    roundingMode: 'round_half_up',
    chargedFromProviderBalance: true,
    ...overrides
  };
}

function policy(overrides: Partial<NegativeMarginPolicy> = {}): NegativeMarginPolicy {
  return {
    allowNegativeMargin: false,
    maxNegativeMarginCentsPerTxn: null,
    dailySubsidyLimitCents: null,
    monthlySubsidyLimitCents: null,
    ...overrides
  };
}

describe('calculateFee — formulas', () => {
  it('applies fixed-only fee', () => {
    const result = calculateFee({
      amountCents: 10_000,
      formula: feeFormula({ fixedFeeCents: 10 })
    });
    expect(result).toEqual({ clientFeeCents: 10, appliedRule: 'fixed_only' });
  });

  it('applies variable-only fee', () => {
    const result = calculateFee({
      amountCents: 10_000,
      formula: feeFormula({ variableFeeBps: 50 })
    });
    expect(result).toEqual({ clientFeeCents: 50, appliedRule: 'variable_only' });
  });

  it('applies fixed plus variable fee', () => {
    const result = calculateFee({
      amountCents: 10_000,
      formula: feeFormula({ fixedFeeCents: 20, variableFeeBps: 50 })
    });
    expect(result).toEqual({ clientFeeCents: 70, appliedRule: 'fixed_plus_variable' });
  });

  it('returns zero when no fee is configured', () => {
    const result = calculateFee({
      amountCents: 10_000,
      formula: feeFormula()
    });
    expect(result).toEqual({ clientFeeCents: 0, appliedRule: 'zero' });
  });

  it('applies the minimum floor when the variable component is below it', () => {
    const result = calculateFee({
      amountCents: 100,
      formula: feeFormula({ variableFeeBps: 10, minFeeCents: 5 })
    });
    expect(result).toEqual({ clientFeeCents: 5, appliedRule: 'min_floor' });
  });

  it('applies the minimum floor when nothing is configured but a floor is set', () => {
    const result = calculateFee({
      amountCents: 0,
      formula: feeFormula({ minFeeCents: 5 })
    });
    expect(result).toEqual({ clientFeeCents: 5, appliedRule: 'min_floor' });
  });

  it('applies the maximum ceiling when the computed value exceeds it', () => {
    const result = calculateFee({
      amountCents: 10_000,
      formula: feeFormula({ variableFeeBps: 200, maxFeeCents: 100 })
    });
    expect(result).toEqual({ clientFeeCents: 100, appliedRule: 'max_ceiling' });
  });

  it('does not clamp when the computed value sits within [min, max]', () => {
    const result = calculateFee({
      amountCents: 10_000,
      formula: feeFormula({
        fixedFeeCents: 5,
        variableFeeBps: 50,
        minFeeCents: 10,
        maxFeeCents: 200
      })
    });
    expect(result).toEqual({ clientFeeCents: 55, appliedRule: 'fixed_plus_variable' });
  });
});

describe('calculateFee — rounding modes', () => {
  it('floor rounds toward zero', () => {
    const result = calculateFee({
      amountCents: 99,
      formula: feeFormula({ variableFeeBps: 50, roundingMode: 'floor' })
    });
    // raw 99 * 50 / 10000 = 0.495 → floor → 0
    expect(result.clientFeeCents).toBe(0);
  });

  it('ceil rounds away from zero', () => {
    const result = calculateFee({
      amountCents: 99,
      formula: feeFormula({ variableFeeBps: 50, roundingMode: 'ceil' })
    });
    // 0.495 → ceil → 1
    expect(result.clientFeeCents).toBe(1);
  });

  it('round_half_up rounds 0.5 ties up', () => {
    const result = calculateFee({
      amountCents: 100,
      formula: feeFormula({ variableFeeBps: 50, roundingMode: 'round_half_up' })
    });
    // raw 100 * 50 / 10000 = 0.5 exactly → 1
    expect(result.clientFeeCents).toBe(1);
  });

  it('round_half_up rounds below 0.5 down', () => {
    const result = calculateFee({
      amountCents: 98,
      formula: feeFormula({ variableFeeBps: 50, roundingMode: 'round_half_up' })
    });
    // 98 * 50 / 10000 = 0.49 → 0
    expect(result.clientFeeCents).toBe(0);
  });

  it('round_half_up rounds above 0.5 up', () => {
    const result = calculateFee({
      amountCents: 100,
      formula: feeFormula({ variableFeeBps: 51, roundingMode: 'round_half_up' })
    });
    // 100 * 51 / 10000 = 0.51 → 1
    expect(result.clientFeeCents).toBe(1);
  });
});

describe('calculateFee — validation', () => {
  it('rejects non-integer amountCents', () => {
    expectAppErrorCode(
      () => calculateFee({ amountCents: 10.5, formula: feeFormula({ fixedFeeCents: 1 }) }),
      PRICING_ERROR_CODES.invalidInput
    );
  });

  it('rejects negative amountCents', () => {
    expectAppErrorCode(
      () => calculateFee({ amountCents: -1, formula: feeFormula({ fixedFeeCents: 1 }) }),
      PRICING_ERROR_CODES.invalidInput
    );
  });

  it('rejects non-integer bps', () => {
    expectAppErrorCode(
      () =>
        calculateFee({
          amountCents: 10_000,
          formula: feeFormula({ variableFeeBps: 50.5 })
        }),
      PRICING_ERROR_CODES.invalidInput
    );
  });

  it('rejects negative fixed fee', () => {
    expectAppErrorCode(
      () =>
        calculateFee({
          amountCents: 10_000,
          formula: feeFormula({ fixedFeeCents: -1 })
        }),
      PRICING_ERROR_CODES.invalidInput
    );
  });

  it('rejects maxFeeCents < minFeeCents', () => {
    expectAppErrorCode(
      () =>
        calculateFee({
          amountCents: 10_000,
          formula: feeFormula({ minFeeCents: 100, maxFeeCents: 50 })
        }),
      PRICING_ERROR_CODES.invalidInput
    );
  });

  it('rejects non-finite values', () => {
    expectAppErrorCode(
      () =>
        calculateFee({ amountCents: Number.POSITIVE_INFINITY, formula: feeFormula() }),
      PRICING_ERROR_CODES.invalidInput
    );
  });
});

describe('calculateFee — integer-safety', () => {
  it('returns the exact fee for a 1e11-cent principal at 100% (10000 bps)', () => {
    const result = calculateFee({
      amountCents: 100_000_000_000,
      formula: feeFormula({ variableFeeBps: 10_000 })
    });
    // 1e11 * 10000 / 10000 = 1e11; well within MAX_SAFE_INTEGER (9.007e15)
    expect(result.clientFeeCents).toBe(100_000_000_000);
    expect(result.appliedRule).toBe('variable_only');
  });

  it('throws when the computed variable would exceed MAX_SAFE_INTEGER', () => {
    // amount close to MAX_SAFE_INTEGER, bps = 20000 → result ~2 * MAX_SAFE_INTEGER
    expectAppErrorCode(
      () =>
        calculateFee({
          amountCents: Number.MAX_SAFE_INTEGER,
          formula: feeFormula({ variableFeeBps: 20_000 })
        }),
      PRICING_ERROR_CODES.invalidInput
    );
  });
});

describe('calculateProviderCost', () => {
  it('applies a fixed provider cost (e.g. R$ 0.10 = 10 cents)', () => {
    const result = calculateProviderCost({
      amountCents: 10_000,
      formula: costFormula({ fixedCostCents: 10 })
    });
    expect(result).toEqual({ providerCostCents: 10, appliedRule: 'fixed_only' });
  });

  it('applies a variable provider cost in bps', () => {
    const result = calculateProviderCost({
      amountCents: 10_000,
      formula: costFormula({ variableCostBps: 30 })
    });
    expect(result).toEqual({ providerCostCents: 30, appliedRule: 'variable_only' });
  });

  it('clamps with the minimum cost floor', () => {
    const result = calculateProviderCost({
      amountCents: 100,
      formula: costFormula({ variableCostBps: 10, minCostCents: 5 })
    });
    expect(result.providerCostCents).toBe(5);
    expect(result.appliedRule).toBe('min_floor');
  });

  it('clamps with the maximum cost ceiling', () => {
    const result = calculateProviderCost({
      amountCents: 10_000,
      formula: costFormula({ variableCostBps: 200, maxCostCents: 100 })
    });
    expect(result.providerCostCents).toBe(100);
    expect(result.appliedRule).toBe('max_ceiling');
  });

  it('returns zero when no cost is configured', () => {
    const result = calculateProviderCost({
      amountCents: 10_000,
      formula: costFormula()
    });
    expect(result).toEqual({ providerCostCents: 0, appliedRule: 'zero' });
  });

  it('rejects maxCostCents < minCostCents', () => {
    expectAppErrorCode(
      () =>
        calculateProviderCost({
          amountCents: 10_000,
          formula: costFormula({ minCostCents: 100, maxCostCents: 50 })
        }),
      PRICING_ERROR_CODES.invalidInput
    );
  });
});

describe('calculateMargin / calculateSubsidy', () => {
  it('computes positive margin and zero subsidy when fee > cost', () => {
    expect(calculateMargin(20, 10)).toBe(10);
    expect(calculateSubsidy(20, 10)).toBe(0);
  });

  it('computes zero margin and zero subsidy when fee == cost', () => {
    expect(calculateMargin(10, 10)).toBe(0);
    expect(calculateSubsidy(10, 10)).toBe(0);
  });

  it('computes negative margin and matching positive subsidy when fee < cost', () => {
    expect(calculateMargin(5, 10)).toBe(-5);
    expect(calculateSubsidy(5, 10)).toBe(5);
  });

  it('combined helper returns both values', () => {
    expect(calculateMarginAndSubsidy(5, 10)).toEqual({ marginCents: -5, subsidyCents: 5 });
    expect(calculateMarginAndSubsidy(20, 10)).toEqual({ marginCents: 10, subsidyCents: 0 });
  });

  it('rejects negative inputs', () => {
    expectAppErrorCode(() => calculateMargin(-1, 10), PRICING_ERROR_CODES.invalidInput);
    expectAppErrorCode(() => calculateSubsidy(10, -1), PRICING_ERROR_CODES.invalidInput);
  });
});

describe('evaluateNegativeMarginPolicy', () => {
  it('approves any non-subsidized operation regardless of policy', () => {
    const result = evaluateNegativeMarginPolicy({
      clientFeeCents: 20,
      providerCostCents: 10,
      policy: policy({ allowNegativeMargin: false })
    });
    expect(result).toEqual({ kind: 'approved', subsidyCents: 0 });
  });

  it('approves zero-margin operations', () => {
    const result = evaluateNegativeMarginPolicy({
      clientFeeCents: 10,
      providerCostCents: 10,
      policy: policy({ allowNegativeMargin: false })
    });
    expect(result).toEqual({ kind: 'approved', subsidyCents: 0 });
  });

  it('rejects negative margin when not allowed', () => {
    const result = evaluateNegativeMarginPolicy({
      clientFeeCents: 5,
      providerCostCents: 10,
      policy: policy({ allowNegativeMargin: false })
    });
    expect(result.kind).toBe('rejected');
    if (result.kind === 'rejected') {
      expect(result.code).toBe(PRICING_ERROR_CODES.negativeMarginNotAllowed);
      expect(result.subsidyCents).toBe(5);
    }
  });

  it('approves negative margin within the per-txn limit', () => {
    const result = evaluateNegativeMarginPolicy({
      clientFeeCents: 5,
      providerCostCents: 10,
      policy: policy({ allowNegativeMargin: true, maxNegativeMarginCentsPerTxn: 10 })
    });
    expect(result).toEqual({ kind: 'approved', subsidyCents: 5 });
  });

  it('approves negative margin when allow=true and no per-txn limit is set', () => {
    const result = evaluateNegativeMarginPolicy({
      clientFeeCents: 0,
      providerCostCents: 1000,
      policy: policy({ allowNegativeMargin: true, maxNegativeMarginCentsPerTxn: null })
    });
    expect(result).toEqual({ kind: 'approved', subsidyCents: 1000 });
  });

  it('rejects negative margin that exceeds the per-txn limit', () => {
    const result = evaluateNegativeMarginPolicy({
      clientFeeCents: 5,
      providerCostCents: 20,
      policy: policy({ allowNegativeMargin: true, maxNegativeMarginCentsPerTxn: 10 })
    });
    expect(result.kind).toBe('rejected');
    if (result.kind === 'rejected') {
      expect(result.code).toBe(PRICING_ERROR_CODES.negativeMarginExceedsPerTxnLimit);
      expect(result.subsidyCents).toBe(15);
    }
  });

  it('approves exact-limit subsidies (boundary inclusive)', () => {
    const result = evaluateNegativeMarginPolicy({
      clientFeeCents: 0,
      providerCostCents: 10,
      policy: policy({ allowNegativeMargin: true, maxNegativeMarginCentsPerTxn: 10 })
    });
    expect(result).toEqual({ kind: 'approved', subsidyCents: 10 });
  });

  it('accepts but does not enforce daily/monthly limits in Phase 2', () => {
    // dailySubsidyLimitCents and monthlySubsidyLimitCents are placeholders.
    // The calculator does not aggregate historical subsidies, so a single
    // transaction within the per-txn limit must be approved even if the
    // configured daily/monthly caps look low.
    const result = evaluateNegativeMarginPolicy({
      clientFeeCents: 0,
      providerCostCents: 5,
      policy: policy({
        allowNegativeMargin: true,
        maxNegativeMarginCentsPerTxn: 10,
        dailySubsidyLimitCents: 1,
        monthlySubsidyLimitCents: 1
      })
    });
    expect(result).toEqual({ kind: 'approved', subsidyCents: 5 });
  });

  it('rejects negative policy limits via the invalid-input guard', () => {
    expectAppErrorCode(
      () =>
        evaluateNegativeMarginPolicy({
          clientFeeCents: 0,
          providerCostCents: 5,
          policy: policy({ allowNegativeMargin: true, maxNegativeMarginCentsPerTxn: -1 })
        }),
      PRICING_ERROR_CODES.invalidInput
    );
  });
});

describe('calculateProviderLiquidityRequired', () => {
  it('adds the expected provider cost when charged_from_provider_balance is true', () => {
    const result = calculateProviderLiquidityRequired({
      amountCents: 10_000,
      expectedProviderCostCents: 10,
      chargedFromProviderBalance: true
    });
    expect(result.providerLiquidityRequiredCents).toBe(10_010);
    expect(result.components).toEqual({ principal: 10_000, providerCost: 10 });
  });

  it('returns only the principal when charged_from_provider_balance is false', () => {
    const result = calculateProviderLiquidityRequired({
      amountCents: 10_000,
      expectedProviderCostCents: 10,
      chargedFromProviderBalance: false
    });
    expect(result.providerLiquidityRequiredCents).toBe(10_000);
    expect(result.components).toEqual({ principal: 10_000, providerCost: 0 });
  });

  it('does not let the client fee influence the required liquidity', () => {
    // Scenario from docs/tariff-system-plan.md §8: a R$ 0.05 client fee with
    // R$ 0.10 provider cost still requires R$ 100.10 at the provider.
    const result = calculateProviderLiquidityRequired({
      amountCents: 10_000,
      expectedProviderCostCents: 10,
      chargedFromProviderBalance: true
    });
    expect(result.providerLiquidityRequiredCents).toBe(10_010);
  });

  it('handles zero provider cost gracefully', () => {
    const result = calculateProviderLiquidityRequired({
      amountCents: 10_000,
      expectedProviderCostCents: 0,
      chargedFromProviderBalance: true
    });
    expect(result.providerLiquidityRequiredCents).toBe(10_000);
    expect(result.components).toEqual({ principal: 10_000, providerCost: 0 });
  });

  it('rejects non-integer or negative inputs', () => {
    expectAppErrorCode(
      () =>
        calculateProviderLiquidityRequired({
          amountCents: 10.5,
          expectedProviderCostCents: 10,
          chargedFromProviderBalance: true
        }),
      PRICING_ERROR_CODES.invalidInput
    );
    expectAppErrorCode(
      () =>
        calculateProviderLiquidityRequired({
          amountCents: 10_000,
          expectedProviderCostCents: -1,
          chargedFromProviderBalance: true
        }),
      PRICING_ERROR_CODES.invalidInput
    );
  });
});

describe('end-to-end pricing scenarios from docs/tariff-system-plan.md', () => {
  // The plan ships the following table in §8 (cash-out, R$ 100 principal,
  // R$ 0.10 provider cost charged from provider balance). Each scenario is
  // a small composition of the pure functions to prove they line up with
  // the documented business expectations.

  it('scenario: client fee equals provider cost → zero margin, no subsidy, R$ 100.10 reserve', () => {
    const fee = calculateFee({
      amountCents: 10_000,
      formula: feeFormula({ fixedFeeCents: 10 })
    });
    const cost = calculateProviderCost({
      amountCents: 10_000,
      formula: costFormula({ fixedCostCents: 10 })
    });
    expect(calculateMargin(fee.clientFeeCents, cost.providerCostCents)).toBe(0);
    expect(calculateSubsidy(fee.clientFeeCents, cost.providerCostCents)).toBe(0);
    expect(
      calculateProviderLiquidityRequired({
        amountCents: 10_000,
        expectedProviderCostCents: cost.providerCostCents,
        chargedFromProviderBalance: true
      }).providerLiquidityRequiredCents
    ).toBe(10_010);
  });

  it('scenario: client fee greater than provider cost → positive margin, R$ 100.10 reserve', () => {
    const fee = calculateFee({
      amountCents: 10_000,
      formula: feeFormula({ fixedFeeCents: 30 })
    });
    const cost = calculateProviderCost({
      amountCents: 10_000,
      formula: costFormula({ fixedCostCents: 10 })
    });
    expect(calculateMargin(fee.clientFeeCents, cost.providerCostCents)).toBe(20);
    expect(calculateSubsidy(fee.clientFeeCents, cost.providerCostCents)).toBe(0);
    expect(
      calculateProviderLiquidityRequired({
        amountCents: 10_000,
        expectedProviderCostCents: cost.providerCostCents,
        chargedFromProviderBalance: true
      }).providerLiquidityRequiredCents
    ).toBe(10_010);
  });

  it('scenario: subsidised client (fee < cost) is approved within policy and still requires R$ 100.10', () => {
    const fee = calculateFee({
      amountCents: 10_000,
      formula: feeFormula({ fixedFeeCents: 5 })
    });
    const cost = calculateProviderCost({
      amountCents: 10_000,
      formula: costFormula({ fixedCostCents: 10 })
    });
    const decision = evaluateNegativeMarginPolicy({
      clientFeeCents: fee.clientFeeCents,
      providerCostCents: cost.providerCostCents,
      policy: policy({ allowNegativeMargin: true, maxNegativeMarginCentsPerTxn: 10 })
    });
    expect(decision).toEqual({ kind: 'approved', subsidyCents: 5 });
    expect(
      calculateProviderLiquidityRequired({
        amountCents: 10_000,
        expectedProviderCostCents: cost.providerCostCents,
        chargedFromProviderBalance: true
      }).providerLiquidityRequiredCents
    ).toBe(10_010);
  });

  it('scenario: zero client fee is rejected without policy approval', () => {
    const fee = calculateFee({ amountCents: 10_000, formula: feeFormula() });
    const cost = calculateProviderCost({
      amountCents: 10_000,
      formula: costFormula({ fixedCostCents: 10 })
    });
    const decision = evaluateNegativeMarginPolicy({
      clientFeeCents: fee.clientFeeCents,
      providerCostCents: cost.providerCostCents,
      policy: policy({ allowNegativeMargin: false })
    });
    expect(decision.kind).toBe('rejected');
    if (decision.kind === 'rejected') {
      expect(decision.code).toBe(PRICING_ERROR_CODES.negativeMarginNotAllowed);
      expect(decision.subsidyCents).toBe(10);
    }
  });
});
