import { describe, expect, it, vi } from 'vitest';
import { IdempotencyService } from '../../src/modules/idempotency/idempotency.service.js';
import type { IdempotencyRepository } from '../../src/modules/idempotency/idempotency.repository.js';
import type { IdempotencyRecord } from '../../src/modules/idempotency/idempotency.types.js';
import type { Database } from '../../src/shared/db/database.js';
import type { Sql } from '../../src/shared/db/sql.js';

/**
 * Unit tests for the shared idempotency engine used by cash-out (and any other
 * Idempotency-Key endpoint). Cash-in does NOT use this — it dedups by
 * (client_id, external_ref). These tests pin the cash-out contract:
 *   - same key + same body (completed) → replay
 *   - same key + DIFFERENT body → 409 idempotency_key_conflict
 *   - same key while in-flight → 409 idempotency_in_progress
 *   - stale lock → fresh takeover (caller must re-probe durable state)
 *   - scope is (client_id, key, operation_type) — per client, not global
 */

const BASE_INPUT = {
  clientId: 'client-1',
  key: 'idem-key-1',
  operationType: 'cash_out' as const,
  requestHash: 'hash-of-body-A',
  lockTtlMs: 30_000
};

function record(over: Partial<IdempotencyRecord> = {}): IdempotencyRecord {
  return {
    id: 'rec-1',
    clientId: BASE_INPUT.clientId,
    key: BASE_INPUT.key,
    operationType: BASE_INPUT.operationType,
    requestHash: BASE_INPUT.requestHash,
    responseBody: null,
    lockedUntil: null,
    completedAt: null,
    ...over
  };
}

function buildService(repoOver: Partial<IdempotencyRepository> = {}) {
  const tx = { __tx: true } as unknown as Sql;
  const repository: IdempotencyRepository = {
    insertIfAbsent: vi.fn(async () => null),
    loadForUpdate: vi.fn(async () => null),
    refreshLock: vi.fn(async () => undefined),
    finalize: vi.fn(async () => undefined),
    release: vi.fn(async () => undefined),
    ...repoOver
  };
  const db: Database = {
    withTransaction: vi.fn(async (cb: (sql: Sql) => unknown) => cb(tx)),
    pool: { __pool: true }
  } as unknown as Database;

  return { service: new IdempotencyService(db, repository), repository, tx };
}

describe('IdempotencyService.acquire', () => {
  it('fresh key → inserts within the (client, key, operation) scope and returns fresh', async () => {
    const insertIfAbsent = vi.fn(async () => record({ id: 'rec-new' }));
    const { service, repository } = buildService({ insertIfAbsent });

    const result = await service.acquire(BASE_INPUT);

    expect(result).toEqual({ kind: 'fresh', recordId: 'rec-new', wasStale: false });
    expect(insertIfAbsent).toHaveBeenCalledWith(
      expect.anything(),
      expect.objectContaining({
        clientId: 'client-1',
        key: 'idem-key-1',
        operationType: 'cash_out',
        requestHash: 'hash-of-body-A'
      })
    );
    expect(repository.loadForUpdate).not.toHaveBeenCalled();
  });

  it('same key + same body (completed) → replay returns the cached response', async () => {
    const cached = { id: 'cashout-1', status: 'processing' };
    const { service } = buildService({
      insertIfAbsent: vi.fn(async () => null),
      loadForUpdate: vi.fn(async () =>
        record({ requestHash: 'hash-of-body-A', completedAt: new Date(), responseBody: cached })
      )
    });

    const result = await service.acquire(BASE_INPUT);

    expect(result).toEqual({ kind: 'replay', response: cached });
  });

  it('same key + DIFFERENT body → 409 idempotency_key_conflict', async () => {
    const { service } = buildService({
      insertIfAbsent: vi.fn(async () => null),
      loadForUpdate: vi.fn(async () =>
        record({ requestHash: 'hash-of-body-B', completedAt: new Date() })
      )
    });

    await expect(service.acquire(BASE_INPUT)).rejects.toMatchObject({
      code: 'idempotency_key_conflict',
      statusCode: 409
    });
  });

  it('same key while still in-flight (lock not expired) → 409 idempotency_in_progress', async () => {
    const { service, repository } = buildService({
      insertIfAbsent: vi.fn(async () => null),
      loadForUpdate: vi.fn(async () =>
        record({ requestHash: 'hash-of-body-A', completedAt: null, lockedUntil: new Date(Date.now() + 60_000) })
      )
    });

    await expect(service.acquire(BASE_INPUT)).rejects.toMatchObject({
      code: 'idempotency_in_progress',
      statusCode: 409
    });
    expect(repository.refreshLock).not.toHaveBeenCalled();
  });

  it('same key with an expired lock → fresh takeover (wasStale=true) and refreshes the lock', async () => {
    const refreshLock = vi.fn(async () => undefined);
    const { service } = buildService({
      insertIfAbsent: vi.fn(async () => null),
      loadForUpdate: vi.fn(async () =>
        record({ id: 'rec-stale', requestHash: 'hash-of-body-A', completedAt: null, lockedUntil: new Date(Date.now() - 1_000) })
      ),
      refreshLock
    });

    const result = await service.acquire(BASE_INPUT);

    expect(result).toEqual({ kind: 'fresh', recordId: 'rec-stale', wasStale: true });
    expect(refreshLock).toHaveBeenCalledWith(expect.anything(), 'rec-stale', 30_000);
  });

  it('throws 500 if the row vanishes between insert and lookup (impossible-but-guarded)', async () => {
    const { service } = buildService({
      insertIfAbsent: vi.fn(async () => null),
      loadForUpdate: vi.fn(async () => null)
    });

    await expect(service.acquire(BASE_INPUT)).rejects.toMatchObject({
      code: 'idempotency_lookup_failed',
      statusCode: 500
    });
  });
});
