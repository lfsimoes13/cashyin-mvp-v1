import { createHash } from 'node:crypto';
import type { FastifyReply, FastifyRequest } from 'fastify';
import Fastify from 'fastify';
import { describe, expect, it, vi } from 'vitest';
import {
  buildAuthPreHandlers,
  buildRequireScope,
  buildResolveAuthContext,
  mapPrincipalToAuthContext,
  type AuthEnforcementMode
} from '../../src/modules/auth/auth-enforcement.js';
import type { ResolvedPrincipal } from '../../src/modules/auth/authenticate.js';
import {
  API_KEY_PREFIX,
  ClientApiKeyService,
  type ClientApiKeyRepository
} from '../../src/modules/auth/client-api-key.service.js';
import { AUTH_SCOPES } from '../../src/shared/auth/auth-scopes.js';
import { toHttpError } from '../../src/shared/errors/app-error.js';

const VALID_TAIL = '00112233445566778899aabbccddeeff00112233445566778899aabbccddeeff';
const VALID_RAW_KEY = `${API_KEY_PREFIX}${VALID_TAIL}`;
const VALID_HASH = createHash('sha256').update(VALID_RAW_KEY).digest('hex');

function resolved(overrides: Partial<ResolvedPrincipal> = {}): ResolvedPrincipal {
  return {
    channel: 'api_direct',
    principalType: 'api_client',
    principalId: 'client-uuid',
    clientId: 'client-uuid',
    credentialId: 'key-row-1',
    scopes: [AUTH_SCOPES.PIX_CASH_IN_CREATE],
    ...overrides
  };
}

function fakeRequest(overrides: Partial<FastifyRequest> = {}): FastifyRequest {
  return {
    url: '/v1/pix/cash-in/qrcode',
    routeOptions: { url: '/v1/pix/cash-in/qrcode' },
    log: { warn: vi.fn(), info: vi.fn(), error: vi.fn() },
    ...overrides
  } as unknown as FastifyRequest;
}

const NOOP_REPLY = {} as FastifyReply;

describe('mapPrincipalToAuthContext', () => {
  it('projects an api_direct principal onto the normalised context', () => {
    const ctx = mapPrincipalToAuthContext(
      resolved({ scopes: [AUTH_SCOPES.PIX_CASH_IN_CREATE, AUTH_SCOPES.PIX_CASH_IN_READ] })
    );
    expect(ctx).toEqual({
      channel: 'api_direct',
      principalType: 'api_client',
      principalId: 'client-uuid',
      clientId: 'client-uuid',
      credentialId: 'key-row-1',
      scopes: [AUTH_SCOPES.PIX_CASH_IN_CREATE, AUTH_SCOPES.PIX_CASH_IN_READ],
      amr: []
    });
  });

  it('carries the audit actor for the frontend_bff channel', () => {
    const ctx = mapPrincipalToAuthContext(
      resolved({ channel: 'frontend_bff', principalType: 'user', actorUserId: 'user-9', credentialId: 'bff' })
    );
    expect(ctx.channel).toBe('frontend_bff');
    expect(ctx.actorUserId).toBe('user-9');
  });
});

describe('buildResolveAuthContext', () => {
  it('resolves the context unconditionally when a principal is present', async () => {
    const request = fakeRequest({ authPrincipal: resolved() });
    await buildResolveAuthContext()(request, NOOP_REPLY);
    expect(request.authContext?.clientId).toBe('client-uuid');
    expect(request.authContext?.channel).toBe('api_direct');
  });

  it('stays a no-op when no principal was resolved', async () => {
    const request = fakeRequest();
    await buildResolveAuthContext()(request, NOOP_REPLY);
    expect(request.authContext).toBeUndefined();
  });
});

describe('buildRequireScope', () => {
  function withContext(mode: AuthEnforcementMode, scopes: readonly string[]) {
    return fakeRequest({
      authContext: mode === 'off' ? undefined : mapPrincipalToAuthContext(resolved({ scopes: scopes as never }))
    });
  }

  it('never denies in off mode, even without a context', async () => {
    const request = fakeRequest();
    await expect(
      buildRequireScope('off', AUTH_SCOPES.PIX_CASH_OUT_CREATE)(request, NOOP_REPLY)
    ).resolves.toBeUndefined();
  });

  it('allows in enforce mode when the scope is present', async () => {
    const request = withContext('enforce', [AUTH_SCOPES.PIX_CASH_IN_CREATE]);
    await expect(
      buildRequireScope('enforce', AUTH_SCOPES.PIX_CASH_IN_CREATE)(request, NOOP_REPLY)
    ).resolves.toBeUndefined();
  });

  it('denies (403) in enforce mode when the scope is missing', async () => {
    const request = withContext('enforce', [AUTH_SCOPES.PIX_CASH_IN_READ]);
    await expect(
      buildRequireScope('enforce', AUTH_SCOPES.PIX_CASH_OUT_CREATE)(request, NOOP_REPLY)
    ).rejects.toMatchObject({ statusCode: 403, code: 'auth_insufficient_scope' });
  });

  it('denies (401) in enforce mode when no context was resolved', async () => {
    const request = fakeRequest();
    await expect(
      buildRequireScope('enforce', AUTH_SCOPES.PIX_CASH_IN_CREATE)(request, NOOP_REPLY)
    ).rejects.toMatchObject({ statusCode: 401, code: 'auth_required' });
  });

  it('does not deny in shadow mode but logs the would-be denial', async () => {
    const request = withContext('shadow', [AUTH_SCOPES.PIX_CASH_IN_READ]);
    await expect(
      buildRequireScope('shadow', AUTH_SCOPES.PIX_CASH_OUT_CREATE)(request, NOOP_REPLY)
    ).resolves.toBeUndefined();
    expect(request.log.warn).toHaveBeenCalledTimes(1);
    expect(request.log.warn).toHaveBeenCalledWith(
      expect.objectContaining({ authShadow: true, requiredScope: 'pix:cash_out:create' }),
      expect.any(String)
    );
  });
});

// ── End-to-end through the full preHandler chain (authenticate → resolve → scope) ──

function buildRepoForKey(scopes: readonly string[]): ClientApiKeyRepository {
  return {
    findActiveByPrefix: async (_sql, prefix) =>
      prefix === VALID_TAIL.slice(0, 8)
        ? [
            {
              id: 'key-row-1',
              client_id: 'client-uuid',
              key_prefix: VALID_TAIL.slice(0, 8),
              key_hash: VALID_HASH,
              label: null,
              scopes: scopes as string[],
              expires_at: null
            }
          ]
        : [],
    findById: async () => null,
    listByClient: async () => [],
    insert: async () => ({ id: 'unused' }),
    touchLastUsed: async () => undefined,
    revoke: async () => undefined
  };
}

function buildApp(mode: AuthEnforcementMode, scopes: readonly string[]) {
  const app = Fastify();
  app.setErrorHandler((error, _request, reply) => {
    const httpError = toHttpError(error);
    void reply.status(httpError.statusCode).send({ error: { code: httpError.code } });
  });
  const service = new ClientApiKeyService({ repository: buildRepoForKey(scopes), sql: {} as never });
  const auth = buildAuthPreHandlers({ mode, clientApiKeyService: service, bffMode: 'off' });
  app.post(
    '/v1/pix/cash-out',
    {
      preHandler: [auth.authenticate, auth.resolveAuthContext, auth.requireScope(AUTH_SCOPES.PIX_CASH_OUT_CREATE)]
    },
    async (request) => ({ clientId: request.client?.clientId, scopes: request.authContext?.scopes ?? null })
  );
  return app;
}

type ProbeBody = { clientId?: string; scopes: string[] | null };

async function call(app: ReturnType<typeof buildApp>) {
  return app.inject({
    method: 'POST',
    url: '/v1/pix/cash-out',
    headers: { authorization: `Bearer ${VALID_RAW_KEY}` }
  });
}

describe('auth enforcement chain (e2e via inject)', () => {
  it('off: allows even without the scope, but still resolves the context (D8)', async () => {
    const app = buildApp('off', [AUTH_SCOPES.PIX_CASH_IN_READ]);
    const res = await call(app);
    expect(res.statusCode).toBe(200);
    // Context is now resolved unconditionally; only the scope *guard* is inert.
    expect(res.json<ProbeBody>().scopes).toEqual([AUTH_SCOPES.PIX_CASH_IN_READ]);
    await app.close();
  });

  it('shadow: allows without the scope (but resolves the context)', async () => {
    const app = buildApp('shadow', [AUTH_SCOPES.PIX_CASH_IN_READ]);
    const res = await call(app);
    expect(res.statusCode).toBe(200);
    expect(res.json<ProbeBody>().scopes).toEqual([AUTH_SCOPES.PIX_CASH_IN_READ]);
    await app.close();
  });

  it('enforce: denies with 403 when the scope is missing', async () => {
    const app = buildApp('enforce', [AUTH_SCOPES.PIX_CASH_IN_READ]);
    const res = await call(app);
    expect(res.statusCode).toBe(403);
    expect(res.json()).toEqual({ error: { code: 'auth_insufficient_scope' } });
    await app.close();
  });

  it('enforce: allows with 200 when the scope is present', async () => {
    const app = buildApp('enforce', [AUTH_SCOPES.PIX_CASH_OUT_CREATE]);
    const res = await call(app);
    expect(res.statusCode).toBe(200);
    expect(res.json<ProbeBody>().clientId).toBe('client-uuid');
    await app.close();
  });

  it('enforce: still rejects an unauthenticated request with 401', async () => {
    const app = buildApp('enforce', [AUTH_SCOPES.PIX_CASH_OUT_CREATE]);
    const res = await app.inject({ method: 'POST', url: '/v1/pix/cash-out' });
    expect(res.statusCode).toBe(401);
    await app.close();
  });
});
