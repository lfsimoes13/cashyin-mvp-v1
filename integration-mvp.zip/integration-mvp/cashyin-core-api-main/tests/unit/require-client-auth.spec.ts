import { createHash } from 'node:crypto';
import Fastify from 'fastify';
import { describe, expect, it } from 'vitest';
import {
  API_KEY_PREFIX,
  ClientApiKeyService,
  type ClientApiKeyRepository
} from '../../src/modules/auth/client-api-key.service.js';
import { buildRequireClientAuth } from '../../src/modules/auth/require-client-auth.js';
import { toHttpError } from '../../src/shared/errors/app-error.js';

const VALID_TAIL = '00112233445566778899aabbccddeeff00112233445566778899aabbccddeeff';
const VALID_RAW_KEY = `${API_KEY_PREFIX}${VALID_TAIL}`;
const VALID_HASH = createHash('sha256').update(VALID_RAW_KEY).digest('hex');

function buildRepo(rows: ReadonlyArray<{
  id: string;
  client_id: string;
  key_prefix: string;
  key_hash: string;
  label: string | null;
  scopes?: string[];
  expires_at?: Date | null;
}> = []): ClientApiKeyRepository {
  return {
    findActiveByPrefix: async (_sql, prefix) =>
      rows
        .filter((r) => r.key_prefix === prefix)
        .map((r) => ({ scopes: [], expires_at: null, ...r })),
    findById: async () => null,
    listByClient: async () => [],
    insert: async () => ({ id: 'unused' }),
    touchLastUsed: async () => undefined,
    revoke: async () => undefined
  };
}

function buildAppWithAuth(service: ClientApiKeyService) {
  const app = Fastify();
  app.setErrorHandler((error, request, reply) => {
    const httpError = toHttpError(error);
    void reply
      .status(httpError.statusCode)
      .send({ error: { code: httpError.code, message: httpError.message } });
  });
  const preHandler = buildRequireClientAuth(service);
  app.get('/probe', { preHandler }, async (request) => ({
    clientId: request.client?.clientId,
    apiKeyId: request.client?.apiKeyId
  }));
  return app;
}

describe('requireClientAuth preHandler', () => {
  it('rejects when Authorization header is missing (401)', async () => {
    const app = buildAppWithAuth(
      new ClientApiKeyService({ repository: buildRepo(), sql: {} as never })
    );
    const response = await app.inject({ method: 'GET', url: '/probe' });
    expect(response.statusCode).toBe(401);
    expect(response.json()).toEqual({
      error: { code: 'unauthorized', message: 'Missing Authorization header' }
    });
    await app.close();
  });

  it('rejects when scheme is not Bearer (401)', async () => {
    const app = buildAppWithAuth(
      new ClientApiKeyService({ repository: buildRepo(), sql: {} as never })
    );
    const response = await app.inject({
      method: 'GET',
      url: '/probe',
      headers: { authorization: `Basic ${Buffer.from('user:pass').toString('base64')}` }
    });
    expect(response.statusCode).toBe(401);
    expect(response.json()).toEqual({
      error: { code: 'unauthorized', message: 'Authorization must use Bearer scheme' }
    });
    await app.close();
  });

  it('rejects an unknown key (401)', async () => {
    const app = buildAppWithAuth(
      new ClientApiKeyService({ repository: buildRepo(), sql: {} as never })
    );
    const response = await app.inject({
      method: 'GET',
      url: '/probe',
      headers: { authorization: `Bearer ${VALID_RAW_KEY}` }
    });
    expect(response.statusCode).toBe(401);
    expect(response.json()).toEqual({
      error: { code: 'unauthorized', message: 'Invalid API key' }
    });
    await app.close();
  });

  it('populates request.client and returns 200 when the key matches', async () => {
    const repo = buildRepo([
      {
        id: 'key-row-1',
        client_id: 'client-uuid',
        key_prefix: VALID_TAIL.slice(0, 8),
        key_hash: VALID_HASH,
        label: 'Postman'
      }
    ]);
    const app = buildAppWithAuth(
      new ClientApiKeyService({ repository: repo, sql: {} as never })
    );
    const response = await app.inject({
      method: 'GET',
      url: '/probe',
      headers: { authorization: `Bearer ${VALID_RAW_KEY}` }
    });
    expect(response.statusCode).toBe(200);
    expect(response.json()).toEqual({
      clientId: 'client-uuid',
      apiKeyId: 'key-row-1'
    });
    await app.close();
  });

  it('accepts case-insensitive Bearer scheme', async () => {
    const repo = buildRepo([
      {
        id: 'key-row-1',
        client_id: 'client-uuid',
        key_prefix: VALID_TAIL.slice(0, 8),
        key_hash: VALID_HASH,
        label: null
      }
    ]);
    const app = buildAppWithAuth(
      new ClientApiKeyService({ repository: repo, sql: {} as never })
    );
    const response = await app.inject({
      method: 'GET',
      url: '/probe',
      headers: { authorization: `bearer ${VALID_RAW_KEY}` }
    });
    expect(response.statusCode).toBe(200);
    await app.close();
  });
});
