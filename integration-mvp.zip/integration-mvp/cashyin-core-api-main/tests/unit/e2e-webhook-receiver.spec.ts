/**
 * Unit tests for the E2E outbound-webhook receiver resolution + payload
 * assertions. No network, no DB — pure functions only.
 */

import { describe, it, expect } from 'vitest';
import {
  resolveWebhookReceiver,
  isRemoteApi,
  isLocalOnlyTarget,
  redactUrl,
  assertCashInWebhookPayload,
  findForbiddenKeys,
  initialOutboundValidation,
  REMOTE_LOCAL_RECEIVER_ERROR,
  type WebhookReceiverConfig,
} from '../../scripts/e2e/fyhub/webhook-receiver.js';

const LOCAL_API = 'http://127.0.0.1:3000';
const REMOTE_API = 'https://api.cashyin.example';

function cfg(over: Partial<WebhookReceiverConfig>): WebhookReceiverConfig {
  return {
    mode: 'local',
    publicUrl: '',
    localReceiverUrl: 'http://127.0.0.1:19876',
    webhookSiteToken: '',
    ...over,
  };
}

describe('isRemoteApi', () => {
  it('treats loopback/private hosts as local', () => {
    expect(isRemoteApi('http://127.0.0.1:3000')).toBe(false);
    expect(isRemoteApi('http://localhost:3000')).toBe(false);
    expect(isRemoteApi('http://10.0.0.5:8080')).toBe(false);
    expect(isRemoteApi('http://192.168.1.10')).toBe(false);
    expect(isRemoteApi('http://172.16.4.4')).toBe(false);
  });

  it('treats public hosts as remote', () => {
    expect(isRemoteApi('https://api.cashyin.example')).toBe(true);
    expect(isRemoteApi('https://1.2.3.4')).toBe(true);
  });
});

describe('isLocalOnlyTarget', () => {
  it('detects loopback, 0.0.0.0 and private IPs', () => {
    expect(isLocalOnlyTarget('http://127.0.0.1:19876')).toBe(true);
    expect(isLocalOnlyTarget('http://0.0.0.0:19876')).toBe(true);
    expect(isLocalOnlyTarget('http://localhost')).toBe(true);
    expect(isLocalOnlyTarget('http://10.1.2.3')).toBe(true);
    expect(isLocalOnlyTarget('https://sub.ngrok-free.app')).toBe(false);
  });
});

describe('redactUrl', () => {
  it('keeps host but masks the secret path', () => {
    const r = redactUrl('https://webhook.site/2bfe903b-1234-abcd');
    expect(r).toContain('webhook.site');
    expect(r).not.toContain('2bfe903b-1234');
    expect(r).toMatch(/\*\*\*\*/);
  });

  it('handles path-less URLs', () => {
    expect(redactUrl('https://sub.ngrok-free.app')).toBe('https://sub.ngrok-free.app');
  });
});

describe('resolveWebhookReceiver', () => {
  it('local mode + local API → starts mock and expects delivery', () => {
    const plan = resolveWebhookReceiver(cfg({ mode: 'local' }), LOCAL_API);
    expect(plan.shouldStartLocalServer).toBe(true);
    expect(plan.expectDelivery).toBe(true);
    expect(plan.manualVerificationRequired).toBe(false);
  });

  it('local mode + remote API → throws the clear error', () => {
    expect(() => resolveWebhookReceiver(cfg({ mode: 'local' }), REMOTE_API)).toThrow(
      REMOTE_LOCAL_RECEIVER_ERROR,
    );
  });

  it('public mode + remote API + empty URL → skipped with reason (not failure)', () => {
    const plan = resolveWebhookReceiver(cfg({ mode: 'public', publicUrl: '' }), REMOTE_API);
    expect(plan.expectDelivery).toBe(false);
    expect(plan.skippedReason).toMatch(/E2E_WEBHOOK_PUBLIC_URL is empty/);
  });

  it('public mode + remote API + local-only URL → throws clear error', () => {
    expect(() =>
      resolveWebhookReceiver(
        cfg({ mode: 'public', publicUrl: 'http://127.0.0.1:19876' }),
        REMOTE_API,
      ),
    ).toThrow(REMOTE_LOCAL_RECEIVER_ERROR);
  });

  it('public mode + remote API + tunnel URL → starts mock, auto-asserts, redacts URL', () => {
    const plan = resolveWebhookReceiver(
      cfg({ mode: 'public', publicUrl: 'https://sub.ngrok-free.app/hook' }),
      REMOTE_API,
    );
    expect(plan.shouldStartLocalServer).toBe(true);
    expect(plan.expectDelivery).toBe(true);
    expect(plan.configuredPublicUrlRedacted).toContain('ngrok-free.app');
  });

  it('webhook_site without token → manual verification', () => {
    const plan = resolveWebhookReceiver(
      cfg({ mode: 'webhook_site', publicUrl: 'https://webhook.site/uuid' }),
      REMOTE_API,
    );
    expect(plan.manualVerificationRequired).toBe(true);
    expect(plan.expectDelivery).toBe(false);
  });

  it('webhook_site with token → auto-observable', () => {
    const plan = resolveWebhookReceiver(
      cfg({ mode: 'webhook_site', publicUrl: 'https://webhook.site/uuid', webhookSiteToken: 't' }),
      REMOTE_API,
    );
    expect(plan.manualVerificationRequired).toBe(false);
    expect(plan.expectDelivery).toBe(true);
  });

  it('disabled → skips entirely', () => {
    const plan = resolveWebhookReceiver(cfg({ mode: 'disabled' }), REMOTE_API);
    expect(plan.shouldStartLocalServer).toBe(false);
    expect(plan.expectDelivery).toBe(false);
    expect(plan.skippedReason).toMatch(/disabled/);
  });
});

describe('assertCashInWebhookPayload', () => {
  const expected = { txid: '2bfe903bb8c94121ac9be074c92062f4', amountCents: 100, externalRef: 'e2e-ref-1' };

  function validEnvelope() {
    return {
      id: 'evt_abc',
      event: 'pix.cash_in.paid',
      schema_version: '2026-05-23',
      timestamp: '2026-05-29T01:41:39Z',
      data: {
        txid: expected.txid,
        amount: 100,
        external_ref: 'e2e-ref-1',
        status: 'paid',
        pix: {
          emv: '00020126...6304CD5D',
          e2e_id: 'E4397869720260529014139827217069',
        },
        payer: { name: 'Alice' },
      },
    };
  }

  it('passes all checks for a correct envelope', () => {
    const results = assertCashInWebhookPayload(validEnvelope(), expected);
    expect(results.every((r) => r.passed)).toBe(true);
  });

  it('reads business fields from data.* (not top level)', () => {
    // txid at top level only must NOT satisfy the data.txid check.
    const bad = { event: 'pix.cash_in.paid', txid: expected.txid, data: {} };
    const results = assertCashInWebhookPayload(bad, expected);
    const txidCheck = results.find((r) => r.name === 'data.txid matches CashYin txid');
    expect(txidCheck?.passed).toBe(false);
  });

  it('fails when a provider field leaks anywhere', () => {
    const env = validEnvelope() as Record<string, unknown>;
    (env.data as Record<string, unknown>).provider_tx_id = 'bents-internal-123';
    const results = assertCashInWebhookPayload(env, expected);
    const leak = results.find((r) => r.name === 'No internal/provider fields leaked');
    expect(leak?.passed).toBe(false);
    expect(leak?.detail).toContain('provider_tx_id');
  });

  it('fails on client_id leak', () => {
    const env = validEnvelope() as Record<string, unknown>;
    env.client_id = 'uuid';
    const results = assertCashInWebhookPayload(env, expected);
    expect(results.find((r) => r.name === 'No internal/provider fields leaked')?.passed).toBe(false);
  });
});

describe('findForbiddenKeys', () => {
  it('finds nested forbidden keys', () => {
    const hits = findForbiddenKeys({ a: { b: { provider_charge_id: 'x' } }, ok: 1 });
    expect(hits).toContain('provider_charge_id');
  });

  it('returns empty for clean payloads', () => {
    expect(findForbiddenKeys({ txid: 'x', amount: 100, data: { status: 'paid' } })).toEqual([]);
  });
});

describe('initialOutboundValidation', () => {
  it('seeds report fields from the plan', () => {
    const plan = resolveWebhookReceiver(cfg({ mode: 'disabled' }), REMOTE_API);
    const v = initialOutboundValidation(plan);
    expect(v.mode).toBe('disabled');
    expect(v.received).toBe(false);
    expect(v.skipped_reason).toMatch(/disabled/);
    expect(v.payload_assertions).toEqual([]);
  });
});
