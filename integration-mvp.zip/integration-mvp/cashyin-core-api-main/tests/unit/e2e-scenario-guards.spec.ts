/**
 * Unit tests for scenario runner guards.
 * No network calls, no real credentials.
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';

// We test the guards by importing them directly.
// The guards read from process.argv and process.env.

// ─── Helpers ──────────────────────────────────────────────────────────────────

function buildCfg(overrides: {
  realPaymentEnabled?: boolean;
  maxAmountCents?: number;
  defaultAmountCents?: number;
}) {
  return {
    fyhub: {
      baseUrl: 'https://pagamentos.fyhub.com.br/api/v2',
      clientId: 'test-client-id',
      clientSecret: 'test-client-secret',
      certPath: './certs/test.pfx',
      certZipPath: '',
      certPassword: 'test-password',
      receiverPixKey: 'e22431d9-222a-4cf2-b888-42fb8ada6452',
      receiverName: 'Test',
      receiverTaxId: '00.000.000/0001-00',
      timeoutMs: 5000,
    },
    cashyin: {
      baseUrl: 'http://localhost:3000',
      apiKey: 'ck_test',
      timeoutMs: 5000,
    },
    test: {
      defaultAmountCents: overrides.defaultAmountCents ?? 100,
      maxAmountCents: overrides.maxAmountCents ?? 100,
      pollTimeoutSecs: 30,
      pollIntervalSecs: 3,
      webhookServerPort: 19876,
      outputDir: './test-results/fyhub',
    },
    realPaymentEnabled: overrides.realPaymentEnabled ?? false,
  };
}

// ─── Tests ────────────────────────────────────────────────────────────────────

describe('assertAmountWithinLimit', () => {
  let assertAmountWithinLimit: (cfg: ReturnType<typeof buildCfg>, amountCents: number) => void;
  let PaymentGuardError: new (message: string) => Error;

  beforeEach(async () => {
    const module = await import('../../scripts/e2e/fyhub/scenario-runner.js');
    assertAmountWithinLimit = module.assertAmountWithinLimit;
    PaymentGuardError = module.PaymentGuardError;
  });

  it('passes when amount equals max', () => {
    const cfg = buildCfg({ maxAmountCents: 100 });
    expect(() => assertAmountWithinLimit(cfg, 100)).not.toThrow();
  });

  it('passes when amount is below max', () => {
    const cfg = buildCfg({ maxAmountCents: 200 });
    expect(() => assertAmountWithinLimit(cfg, 100)).not.toThrow();
  });

  it('throws when amount exceeds max', () => {
    const cfg = buildCfg({ maxAmountCents: 100 });
    expect(() => assertAmountWithinLimit(cfg, 200)).toThrow(PaymentGuardError);
    expect(() => assertAmountWithinLimit(cfg, 200)).toThrow(/TEST_MAX_AMOUNT_CENTS/);
  });

  it('throws for zero amount', () => {
    const cfg = buildCfg({ maxAmountCents: 100 });
    expect(() => assertAmountWithinLimit(cfg, 0)).toThrow(PaymentGuardError);
  });

  it('throws for negative amount', () => {
    const cfg = buildCfg({ maxAmountCents: 100 });
    expect(() => assertAmountWithinLimit(cfg, -1)).toThrow(PaymentGuardError);
  });

  it('throws for non-integer amount', () => {
    const cfg = buildCfg({ maxAmountCents: 100 });
    expect(() => assertAmountWithinLimit(cfg, 1.5)).toThrow(PaymentGuardError);
  });
});

describe('assertRealPaymentAllowed', () => {
  let assertRealPaymentAllowed: (cfg: ReturnType<typeof buildCfg>, amountCents: number) => void;
  let PaymentGuardError: new (message: string) => Error;

  const originalArgv = process.argv;

  beforeEach(async () => {
    const module = await import('../../scripts/e2e/fyhub/scenario-runner.js');
    assertRealPaymentAllowed = module.assertRealPaymentAllowed;
    PaymentGuardError = module.PaymentGuardError;
  });

  afterEach(() => {
    process.argv = originalArgv;
  });

  it('throws when REAL_PAYMENT_TESTS_ENABLED=false', () => {
    const cfg = buildCfg({ realPaymentEnabled: false });
    expect(() => assertRealPaymentAllowed(cfg, 100)).toThrow(PaymentGuardError);
    expect(() => assertRealPaymentAllowed(cfg, 100)).toThrow(/REAL_PAYMENT_TESTS_ENABLED/);
  });

  it('throws when env enabled but flag missing from argv', () => {
    const cfg = buildCfg({ realPaymentEnabled: true });
    // argv does NOT include --execute-real-payment
    process.argv = ['node', 'run.ts', '--scenario=cashin'];
    expect(() => assertRealPaymentAllowed(cfg, 100)).toThrow(PaymentGuardError);
    expect(() => assertRealPaymentAllowed(cfg, 100)).toThrow(/--execute-real-payment/);
  });

  it('passes when env enabled AND flag present', () => {
    const cfg = buildCfg({ realPaymentEnabled: true, maxAmountCents: 100 });
    process.argv = ['node', 'run.ts', '--execute-real-payment'];
    expect(() => assertRealPaymentAllowed(cfg, 100)).not.toThrow();
  });

  it('throws when amount exceeds max even if env + flag set', () => {
    const cfg = buildCfg({ realPaymentEnabled: true, maxAmountCents: 100 });
    process.argv = ['node', 'run.ts', '--execute-real-payment'];
    expect(() => assertRealPaymentAllowed(cfg, 200)).toThrow(PaymentGuardError);
    expect(() => assertRealPaymentAllowed(cfg, 200)).toThrow(/TEST_MAX_AMOUNT_CENTS/);
  });
});

describe('hasFlag', () => {
  const originalArgv = process.argv;

  afterEach(() => {
    process.argv = originalArgv;
  });

  it('returns true when flag is present', async () => {
    process.argv = ['node', 'run.ts', '--execute-real-payment'];
    const { hasFlag } = await import('../../scripts/e2e/fyhub/scenario-runner.js');
    expect(hasFlag('--execute-real-payment')).toBe(true);
  });

  it('returns false when flag is absent', async () => {
    process.argv = ['node', 'run.ts'];
    const { hasFlag } = await import('../../scripts/e2e/fyhub/scenario-runner.js');
    expect(hasFlag('--execute-real-payment')).toBe(false);
  });
});
