import { describe, expect, it } from 'vitest';
import type { AuthContext, StepUpProof } from '../../src/shared/auth/auth-context.js';
import { AUTH_SCOPES } from '../../src/shared/auth/auth-scopes.js';
import { AppError } from '../../src/shared/errors/app-error.js';
import {
  requireAnyAmr,
  requireAuth,
  requireCashoutStepUp,
  requireClientAccess,
  requireScope
} from '../../src/shared/auth/guards.js';

const TX_HASH = 'a'.repeat(64);

function baseContext(overrides: Partial<AuthContext> = {}): AuthContext {
  return {
    channel: 'api_direct',
    principalType: 'api_client',
    principalId: 'client-123',
    clientId: 'client-123',
    scopes: [AUTH_SCOPES.PIX_CASH_IN_CREATE],
    ...overrides
  };
}

function freshStepUp(overrides: Partial<StepUpProof> = {}): StepUpProof {
  return {
    amr: ['otp'],
    transactionHash: TX_HASH,
    issuedAt: Date.now() - 1_000,
    expiresAt: Date.now() + 60_000,
    ...overrides
  };
}

/** Asserts the thrown value is an AppError with the expected status/code. */
function expectAppError(fn: () => unknown, statusCode: number, code?: string): void {
  try {
    fn();
  } catch (error) {
    expect(error).toBeInstanceOf(AppError);
    const appError = error as AppError;
    expect(appError.statusCode).toBe(statusCode);
    if (code) expect(appError.code).toBe(code);
    return;
  }
  throw new Error('Expected guard to throw, but it did not');
}

describe('requireAuth', () => {
  it('passes with a valid context (accepts a raw context)', () => {
    const ctx = baseContext();
    expect(requireAuth(ctx)).toBe(ctx);
  });

  it('passes when given a Fastify-like carrier with an authContext', () => {
    const ctx = baseContext();
    expect(requireAuth({ authContext: ctx })).toBe(ctx);
  });

  it('fails with 401 when context is absent', () => {
    expectAppError(() => requireAuth(undefined), 401, 'auth_required');
    expectAppError(() => requireAuth({ authContext: undefined }), 401, 'auth_required');
  });

  it('fails with 401 when context is expired', () => {
    const ctx = baseContext({ expiresAt: Date.now() - 1 });
    expectAppError(() => requireAuth(ctx), 401, 'auth_invalid');
  });
});

describe('requireScope', () => {
  it('passes when the required scope is present', () => {
    const ctx = baseContext({ scopes: [AUTH_SCOPES.PIX_CASH_IN_CREATE, AUTH_SCOPES.PIX_CASH_IN_READ] });
    expect(requireScope(ctx, AUTH_SCOPES.PIX_CASH_IN_READ)).toBe(ctx);
  });

  it('fails with 403 when the scope is missing', () => {
    const ctx = baseContext({ scopes: [AUTH_SCOPES.PIX_CASH_IN_READ] });
    expectAppError(
      () => requireScope(ctx, AUTH_SCOPES.PIX_CASH_OUT_CREATE),
      403,
      'auth_insufficient_scope'
    );
  });

  it('surfaces the required scope without leaking other context', () => {
    const ctx = baseContext({ scopes: [] });
    try {
      requireScope(ctx, AUTH_SCOPES.PIX_CASH_OUT_APPROVE);
    } catch (error) {
      expect((error as AppError).details).toEqual({ requiredScope: 'pix:cash_out:approve' });
    }
  });
});

describe('requireClientAccess', () => {
  it('passes for a matching clientId', () => {
    const ctx = baseContext({ clientId: 'client-abc' });
    expect(requireClientAccess(ctx, 'client-abc')).toBe(ctx);
  });

  it('fails with 403 for a mismatched clientId', () => {
    const ctx = baseContext({ clientId: 'client-abc' });
    expectAppError(() => requireClientAccess(ctx, 'client-xyz'), 403, 'auth_client_mismatch');
  });

  it('fails with 403 when the context has no clientId', () => {
    const ctx = baseContext({ clientId: undefined });
    expectAppError(() => requireClientAccess(ctx, 'client-abc'), 403, 'auth_client_mismatch');
  });
});

describe('requireAnyAmr', () => {
  it('passes when at least one required method is present', () => {
    const ctx = baseContext({ amr: ['pwd', 'otp'] });
    expect(requireAnyAmr(ctx, ['otp', 'webauthn'])).toBe(ctx);
  });

  it('fails with 403 when none of the required methods are present', () => {
    const ctx = baseContext({ amr: ['pwd'] });
    expectAppError(() => requireAnyAmr(ctx, ['otp', 'webauthn']), 403, 'auth_step_up_required');
  });

  it('fails with 403 when amr is absent entirely', () => {
    const ctx = baseContext();
    expectAppError(() => requireAnyAmr(ctx, ['otp']), 403, 'auth_step_up_required');
  });
});

describe('requireCashoutStepUp', () => {
  it('passes with a matching transaction hash and non-expired proof', () => {
    const ctx = baseContext({ stepUp: freshStepUp() });
    expect(requireCashoutStepUp(ctx, TX_HASH)).toBe(ctx);
  });

  it('fails (missing) when no step-up proof is present', () => {
    const ctx = baseContext();
    expectAppError(() => requireCashoutStepUp(ctx, TX_HASH), 403, 'auth_step_up_required');
    try {
      requireCashoutStepUp(baseContext(), TX_HASH);
    } catch (error) {
      expect((error as AppError).details).toEqual({ reason: 'missing' });
    }
  });

  it('fails (expired) when the step-up proof has expired', () => {
    const ctx = baseContext({ stepUp: freshStepUp({ expiresAt: Date.now() - 1 }) });
    expectAppError(() => requireCashoutStepUp(ctx, TX_HASH), 403, 'auth_step_up_required');
    try {
      requireCashoutStepUp(
        baseContext({ stepUp: freshStepUp({ expiresAt: Date.now() - 1 }) }),
        TX_HASH
      );
    } catch (error) {
      expect((error as AppError).details).toEqual({ reason: 'expired' });
    }
  });

  it('fails (mismatch) when the proof is bound to a different operation', () => {
    const ctx = baseContext({ stepUp: freshStepUp({ transactionHash: 'b'.repeat(64) }) });
    expectAppError(() => requireCashoutStepUp(ctx, TX_HASH), 403, 'auth_step_up_required');
    try {
      requireCashoutStepUp(
        baseContext({ stepUp: freshStepUp({ transactionHash: 'b'.repeat(64) }) }),
        TX_HASH
      );
    } catch (error) {
      expect((error as AppError).details).toEqual({ reason: 'mismatch' });
    }
  });

  it('fails with 401 before checking step-up when unauthenticated', () => {
    expectAppError(() => requireCashoutStepUp(undefined, TX_HASH), 401, 'auth_required');
  });
});
