import { createHash } from 'node:crypto';
import { describe, expect, it, vi } from 'vitest';
import { BentsWebhookAdapter } from '../../src/providers/bents/bents-webhook.adapter.js';
import { NoVerificationWebhookAuthStrategy } from '../../src/providers/security/no-verification.strategy.js';
import type {
  ProviderWebhookVerificationInput,
  ProviderWebhookVerificationResult,
  RawHeaders
} from '../../src/providers/contracts/provider-webhook-adapter.js';
import type { WebhookAuthStrategy } from '../../src/providers/contracts/webhook-auth-strategy.js';

function sha256Hex(body: Buffer): string {
  return createHash('sha256').update(body).digest('hex');
}

/**
 * Build a fresh adapter instance for each test so state is isolated
 * from other specs running concurrently. Defaults to a
 * `NoVerificationWebhookAuthStrategy` so `parse`/`normalize` tests
 * don't have to construct credentials they don't care about. Pass a
 * custom strategy to exercise the delegation behaviour itself.
 */
function buildAdapter(strategy?: WebhookAuthStrategy): BentsWebhookAdapter {
  return new BentsWebhookAdapter(
    strategy ? { authStrategy: strategy } : { authStrategy: new NoVerificationWebhookAuthStrategy() }
  );
}

/**
 * Sanitized Bents-style cash-in `charge.paid` envelope. UUIDs and PII
 * are placeholders only.
 */
const CHARGE_PAID_FIXTURE = {
  event: 'charge.paid',
  event_id: 'evt_paid_001',
  timestamp: '2026-05-22T12:00:00Z',
  data: {
    charge_uuid: 'ch_aaaa1111',
    status: 'PAID',
    amount_cents: 12500,
    paid_at: '2026-05-22T11:59:58Z',
    end_to_end_id: 'E26358200202605221159s00000001',
    payer_name: 'Sanitized Payer',
    payer_document: '00000000000'
  }
};

const CHARGE_EXPIRED_FIXTURE = {
  event: 'charge.expired',
  event_id: 'evt_expired_002',
  timestamp: '2026-05-22T13:00:00Z',
  data: {
    charge_uuid: 'ch_aaaa2222',
    status: 'EXPIRED'
  }
};

const CHARGE_CANCELLED_FIXTURE = {
  event: 'charge.cancelled',
  event_id: 'evt_cancelled_003',
  timestamp: '2026-05-22T14:00:00Z',
  data: {
    charge_uuid: 'ch_aaaa3333'
  }
};

const PAYMENT_COMPLETED_FIXTURE = {
  event: 'payment.completed',
  event_id: 'evt_payment_001',
  timestamp: '2026-05-22T15:00:00Z',
  data: {
    transaction_id: 'pay_bbbb1111',
    status: 'CONFIRMED',
    amount_cents: 5000,
    completed_at: '2026-05-22T14:59:55Z',
    end_to_end_id: 'E26358200202605221459s00000001'
  }
};

const PAYMENT_RETURNED_FIXTURE = {
  event: 'payment.returned',
  event_id: 'evt_payment_002',
  timestamp: '2026-05-22T16:00:00Z',
  data: {
    transaction_id: 'pay_bbbb2222',
    status: 'DEVOLVED',
    returned_at: '2026-05-22T15:59:30Z'
  }
};

const PAYMENT_FAILED_FIXTURE = {
  event: 'payment.failed',
  event_id: 'evt_payment_003',
  timestamp: '2026-05-22T17:00:00Z',
  data: {
    transaction_id: 'pay_bbbb3333',
    status: 'REJECTED',
    failed_at: '2026-05-22T16:59:00Z'
  }
};

const PUBLIC_CASH_IN_ALIAS_FIXTURE = {
  event: 'pix.cash_in.paid',
  event_id: 'evt_alias_001',
  data: {
    charge_uuid: 'ch_alias_001',
    status: 'PAID',
    paid_at: '2026-05-22T12:00:00Z'
  }
};

const UNKNOWN_EVENT_FIXTURE = {
  event: 'fraud.alert',
  event_id: 'evt_unknown_001',
  data: { id: 'x' }
};

describe('BentsWebhookAdapter.verify — delegates to the injected WebhookAuthStrategy', () => {
  it('returns valid when the strategy returns valid', async () => {
    const adapter = buildAdapter(new NoVerificationWebhookAuthStrategy());
    const result = await adapter.verify({
      rawBody: Buffer.from('{}'),
      headers: {},
      signature: null,
      receivedAt: new Date()
    });
    expect(result).toEqual({ valid: true });
  });

  it('forwards the strategy failure verbatim (no rewriting / no swallowing)', async () => {
    const strategy: WebhookAuthStrategy = {
      name: 'always_fail',
      verify: async () => ({ valid: false, reason: 'invalid_signature' as const, detail: 'forced' })
    };
    const result = await buildAdapter(strategy).verify({
      rawBody: Buffer.from('{}'),
      headers: {},
      signature: null,
      receivedAt: new Date()
    });
    expect(result).toEqual({ valid: false, reason: 'invalid_signature', detail: 'forced' });
  });

  it('passes the verification input through unchanged', async () => {
    const verifySpy = vi.fn<
      [ProviderWebhookVerificationInput],
      Promise<ProviderWebhookVerificationResult>
    >().mockResolvedValue({ valid: true });
    const strategy: WebhookAuthStrategy = { name: 'spy', verify: verifySpy };

    const input: ProviderWebhookVerificationInput = {
      rawBody: Buffer.from('payload'),
      headers: { 'x-bents-signature': 'sha256=deadbeef' },
      signature: 'sha256=deadbeef',
      receivedAt: new Date('2026-05-22T12:00:00Z')
    };
    await buildAdapter(strategy).verify(input);
    expect(verifySpy).toHaveBeenCalledTimes(1);
    expect(verifySpy.mock.calls[0]?.[0]).toBe(input);
  });

  it('exposes the strategy name for audit logs', () => {
    const adapter = buildAdapter(new NoVerificationWebhookAuthStrategy());
    expect(adapter.authStrategyName).toBe('no_verification');
  });

  it('defaults to NoVerificationWebhookAuthStrategy when no strategy is injected', () => {
    const adapter = new BentsWebhookAdapter();
    expect(adapter.authStrategyName).toBe('no_verification');
  });
});

describe('BentsWebhookAdapter.parse', () => {
  it('extracts the canonical audit fields from a charge.paid envelope', async () => {
    const adapter = buildAdapter();
    const rawBody = Buffer.from(JSON.stringify(CHARGE_PAID_FIXTURE));
    const parsed = await adapter.parse({
      rawBody,
      payload: CHARGE_PAID_FIXTURE,
      headers: {
        'content-type': 'application/json',
        'x-bents-signature': 'sha256=test-signature-placeholder'
      }
    });

    expect(parsed.providerName).toBe('bents');
    expect(parsed.providerEventId).toBe('evt_paid_001');
    expect(parsed.providerEventType).toBe('charge.paid');
    expect(parsed.providerTransactionId).toBe('ch_aaaa1111');
    expect(parsed.providerStatus).toBe('PAID');
    expect(parsed.operationType).toBe('cash_in');
    expect(parsed.occurredAt?.toISOString()).toBe('2026-05-22T11:59:58.000Z');
    expect(parsed.rawPayloadHash).toBe(sha256Hex(rawBody));
    expect(parsed.fields).toEqual({
      e2e_id: 'E26358200202605221159s00000001',
      realised_amount: 12500,
      payer_name: 'Sanitized Payer',
      payer_document: '00000000000',
      payer_document_type: null,
      payer_bank_name: null,
      payer_bank_ispb: null,
      payer_bank_branch: null,
      payer_bank_account: null
    });
  });

  it('redacts the signature header for audit persistence', async () => {
    const adapter = buildAdapter();
    const rawBody = Buffer.from(JSON.stringify(CHARGE_PAID_FIXTURE));
    const signature = 'sha256=test-signature-placeholder';
    const headers: RawHeaders = {
      'content-type': 'application/json',
      'x-bents-signature': signature,
      Authorization: 'Bearer secret-token',
      'X-Trace-Id': 'trace-123'
    };
    const parsed = await adapter.parse({ rawBody, payload: CHARGE_PAID_FIXTURE, headers });
    expect(parsed.redactedHeaders['x-bents-signature']).toBe('[redacted]');
    expect(parsed.redactedHeaders['authorization']).toBe('[redacted]');
    expect(parsed.redactedHeaders['x-trace-id']).toBe('trace-123');
    expect(parsed.redactedHeaders['content-type']).toBe('application/json');
  });

  it('joins multi-valued headers with ", " when persisting them', async () => {
    const adapter = buildAdapter();
    const rawBody = Buffer.from('{}');
    const parsed = await adapter.parse({
      rawBody,
      payload: {},
      headers: { 'x-multi': ['a', 'b'] }
    });
    expect(parsed.redactedHeaders['x-multi']).toBe('a, b');
  });

  it('infers operationType=cash_out from a payment.completed envelope', async () => {
    const adapter = buildAdapter();
    const rawBody = Buffer.from(JSON.stringify(PAYMENT_COMPLETED_FIXTURE));
    const parsed = await adapter.parse({
      rawBody,
      payload: PAYMENT_COMPLETED_FIXTURE,
      headers: {}
    });
    expect(parsed.operationType).toBe('cash_out');
    expect(parsed.providerTransactionId).toBe('pay_bbbb1111');
    expect(parsed.providerStatus).toBe('CONFIRMED');
    expect(parsed.occurredAt?.toISOString()).toBe('2026-05-22T14:59:55.000Z');
    expect(parsed.fields.e2e_id).toBe('E26358200202605221459s00000001');
  });

  it('returns operationType=null and empty providerEventType for shapeless payloads', async () => {
    const adapter = buildAdapter();
    const parsed = await adapter.parse({
      rawBody: Buffer.from('{}'),
      payload: {},
      headers: {}
    });
    expect(parsed.operationType).toBeNull();
    expect(parsed.providerEventType).toBe('');
    expect(parsed.providerEventId).toBeNull();
    expect(parsed.providerTransactionId).toBeNull();
    expect(parsed.providerStatus).toBeNull();
    expect(parsed.occurredAt).toBeNull();
  });

  it('treats `event_type` and `type` as aliases for the event name', async () => {
    const adapter = buildAdapter();
    const variantA = await adapter.parse({
      rawBody: Buffer.from('{}'),
      payload: { event_type: 'charge.paid', data: { charge_uuid: 'a' } },
      headers: {}
    });
    const variantB = await adapter.parse({
      rawBody: Buffer.from('{}'),
      payload: { type: 'charge.paid', data: { charge_uuid: 'b' } },
      headers: {}
    });
    expect(variantA.providerEventType).toBe('charge.paid');
    expect(variantB.providerEventType).toBe('charge.paid');
  });

  it('falls back to the top-level `timestamp` when no flow-specific timestamp is present', async () => {
    const adapter = buildAdapter();
    const parsed = await adapter.parse({
      rawBody: Buffer.from('{}'),
      payload: { event: 'charge.paid', timestamp: '2026-05-22T12:00:00Z', data: { charge_uuid: 'x' } },
      headers: {}
    });
    expect(parsed.occurredAt?.toISOString()).toBe('2026-05-22T12:00:00.000Z');
  });

  it('ignores malformed timestamps rather than throwing', async () => {
    const adapter = buildAdapter();
    const parsed = await adapter.parse({
      rawBody: Buffer.from('{}'),
      payload: { event: 'charge.paid', timestamp: 'not-a-date', data: { charge_uuid: 'x' } },
      headers: {}
    });
    expect(parsed.occurredAt).toBeNull();
  });

  it('does not throw when payload is a primitive', async () => {
    const adapter = buildAdapter();
    const parsed = await adapter.parse({
      rawBody: Buffer.from('"hello"'),
      payload: 'hello',
      headers: {}
    });
    expect(parsed.providerEventType).toBe('');
    expect(parsed.operationType).toBeNull();
  });

  it('hashes the raw body, not the parsed payload, so signature audits replay correctly', async () => {
    const adapter = buildAdapter();
    const rawBody = Buffer.from('{"event":"charge.paid","data":{"charge_uuid":"x"}}');
    const parsed = await adapter.parse({
      rawBody,
      payload: { event: 'charge.paid', data: { charge_uuid: 'x' } },
      headers: {}
    });
    expect(parsed.rawPayloadHash).toBe(sha256Hex(rawBody));
  });
});

describe('BentsWebhookAdapter.normalize — cash_in', () => {
  it('maps charge.paid + status PAID → cash_in/paid', async () => {
    const adapter = buildAdapter();
    const parsed = await adapter.parse({
      rawBody: Buffer.from(JSON.stringify(CHARGE_PAID_FIXTURE)),
      payload: CHARGE_PAID_FIXTURE,
      headers: {}
    });
    const normalized = await adapter.normalize(parsed);
    expect(normalized.normalizedStatus).toEqual({ kind: 'cash_in', status: 'paid' });
  });

  it('maps charge.expired → cash_in/expired', async () => {
    const adapter = buildAdapter();
    const parsed = await adapter.parse({
      rawBody: Buffer.from(JSON.stringify(CHARGE_EXPIRED_FIXTURE)),
      payload: CHARGE_EXPIRED_FIXTURE,
      headers: {}
    });
    const normalized = await adapter.normalize(parsed);
    expect(normalized.normalizedStatus).toEqual({ kind: 'cash_in', status: 'expired' });
  });

  it('maps charge.cancelled (no explicit status field) by inferring from event type', async () => {
    const adapter = buildAdapter();
    const parsed = await adapter.parse({
      rawBody: Buffer.from(JSON.stringify(CHARGE_CANCELLED_FIXTURE)),
      payload: CHARGE_CANCELLED_FIXTURE,
      headers: {}
    });
    expect(parsed.providerStatus).toBeNull();
    const normalized = await adapter.normalize(parsed);
    expect(normalized.normalizedStatus).toEqual({ kind: 'cash_in', status: 'cancelled' });
  });

  it('accepts the BRZip alias pix.cash_in.paid', async () => {
    const adapter = buildAdapter();
    const parsed = await adapter.parse({
      rawBody: Buffer.from(JSON.stringify(PUBLIC_CASH_IN_ALIAS_FIXTURE)),
      payload: PUBLIC_CASH_IN_ALIAS_FIXTURE,
      headers: {}
    });
    expect(parsed.operationType).toBe('cash_in');
    const normalized = await adapter.normalize(parsed);
    expect(normalized.normalizedStatus).toEqual({ kind: 'cash_in', status: 'paid' });
  });

  it('treats CONFIRMED on a cash-in event as paid', async () => {
    const adapter = buildAdapter();
    const parsed = await adapter.parse({
      rawBody: Buffer.from('{}'),
      payload: { event: 'charge.paid', data: { charge_uuid: 'x', status: 'CONFIRMED' } },
      headers: {}
    });
    const normalized = await adapter.normalize(parsed);
    expect(normalized.normalizedStatus).toEqual({ kind: 'cash_in', status: 'paid' });
  });

  it('reports unknown_status for an unrecognised provider status on a cash_in event', async () => {
    const adapter = buildAdapter();
    const parsed = await adapter.parse({
      rawBody: Buffer.from('{}'),
      payload: { event: 'charge.paid', data: { charge_uuid: 'x', status: 'QUANTUM_FLUX' } },
      headers: {}
    });
    const normalized = await adapter.normalize(parsed);
    // `charge.paid` verb still resolves the canonical status from the event
    // type, so this surface area is deterministic; the test asserts that
    // fallback so future regressions in the verb table fire here.
    expect(normalized.normalizedStatus).toEqual({ kind: 'cash_in', status: 'paid' });
  });

  it('reports unknown_status when neither status nor verb resolves on a known cash_in shape', async () => {
    const adapter = buildAdapter();
    const parsed = await adapter.parse({
      rawBody: Buffer.from('{}'),
      payload: { event: 'charge.quantum', data: { charge_uuid: 'x', status: 'QUANTUM_FLUX' } },
      headers: {}
    });
    const normalized = await adapter.normalize(parsed);
    expect(normalized.normalizedStatus).toEqual({ kind: 'unknown', reason: 'unknown_status' });
  });

  it('reports missing_status when neither status nor a known verb is present', async () => {
    const adapter = buildAdapter();
    const parsed = await adapter.parse({
      rawBody: Buffer.from('{}'),
      payload: { event: 'charge.quantum', data: { charge_uuid: 'x' } },
      headers: {}
    });
    const normalized = await adapter.normalize(parsed);
    expect(normalized.normalizedStatus).toEqual({ kind: 'unknown', reason: 'missing_status' });
  });
});

describe('BentsWebhookAdapter.normalize — cash_out', () => {
  it('maps payment.completed + CONFIRMED → cash_out/completed', async () => {
    const adapter = buildAdapter();
    const parsed = await adapter.parse({
      rawBody: Buffer.from(JSON.stringify(PAYMENT_COMPLETED_FIXTURE)),
      payload: PAYMENT_COMPLETED_FIXTURE,
      headers: {}
    });
    const normalized = await adapter.normalize(parsed);
    expect(normalized.normalizedStatus).toEqual({ kind: 'cash_out', status: 'completed' });
  });

  it('maps payment.returned + DEVOLVED → cash_out/returned', async () => {
    const adapter = buildAdapter();
    const parsed = await adapter.parse({
      rawBody: Buffer.from(JSON.stringify(PAYMENT_RETURNED_FIXTURE)),
      payload: PAYMENT_RETURNED_FIXTURE,
      headers: {}
    });
    const normalized = await adapter.normalize(parsed);
    expect(normalized.normalizedStatus).toEqual({ kind: 'cash_out', status: 'returned' });
  });

  it('maps payment.failed + REJECTED → cash_out/failed', async () => {
    const adapter = buildAdapter();
    const parsed = await adapter.parse({
      rawBody: Buffer.from(JSON.stringify(PAYMENT_FAILED_FIXTURE)),
      payload: PAYMENT_FAILED_FIXTURE,
      headers: {}
    });
    const normalized = await adapter.normalize(parsed);
    expect(normalized.normalizedStatus).toEqual({ kind: 'cash_out', status: 'failed' });
  });

  it('accepts the BRZip alias pix.cash_out.completed', async () => {
    const adapter = buildAdapter();
    const parsed = await adapter.parse({
      rawBody: Buffer.from('{}'),
      payload: {
        event: 'pix.cash_out.completed',
        data: { transaction_id: 'pay_alias', status: 'SUCCESS' }
      },
      headers: {}
    });
    expect(parsed.operationType).toBe('cash_out');
    const normalized = await adapter.normalize(parsed);
    expect(normalized.normalizedStatus).toEqual({ kind: 'cash_out', status: 'completed' });
  });

  it('infers cash_out/processing from a status-less payment.processing event', async () => {
    const adapter = buildAdapter();
    const parsed = await adapter.parse({
      rawBody: Buffer.from('{}'),
      payload: { event: 'payment.processing', data: { transaction_id: 'pay_x' } },
      headers: {}
    });
    const normalized = await adapter.normalize(parsed);
    expect(normalized.normalizedStatus).toEqual({ kind: 'cash_out', status: 'processing' });
  });
});

describe('BentsWebhookAdapter.normalize — unknowns', () => {
  it('surfaces missing_operation_type for an unrecognised event prefix', async () => {
    const adapter = buildAdapter();
    const parsed = await adapter.parse({
      rawBody: Buffer.from(JSON.stringify(UNKNOWN_EVENT_FIXTURE)),
      payload: UNKNOWN_EVENT_FIXTURE,
      headers: {}
    });
    expect(parsed.operationType).toBeNull();
    const normalized = await adapter.normalize(parsed);
    expect(normalized.normalizedStatus).toEqual({
      kind: 'unknown',
      reason: 'missing_operation_type'
    });
  });

  it('preserves audit fields when surfacing unknowns', async () => {
    const adapter = buildAdapter();
    const rawBody = Buffer.from(JSON.stringify(UNKNOWN_EVENT_FIXTURE));
    const parsed = await adapter.parse({
      rawBody,
      payload: UNKNOWN_EVENT_FIXTURE,
      headers: { 'x-bents-signature': 'sha256=anything' }
    });
    const normalized = await adapter.normalize(parsed);
    expect(normalized.providerEventId).toBe('evt_unknown_001');
    expect(normalized.rawPayloadHash).toBe(sha256Hex(rawBody));
    expect(normalized.redactedHeaders['x-bents-signature']).toBe('[redacted]');
    expect(normalized.rawPayload).toEqual(UNKNOWN_EVENT_FIXTURE);
  });

  it('is case-insensitive on the event name when resolving the operation type', async () => {
    const adapter = buildAdapter();
    const parsed = await adapter.parse({
      rawBody: Buffer.from('{}'),
      payload: { event: 'CHARGE.PAID', data: { charge_uuid: 'x', status: 'paid' } },
      headers: {}
    });
    expect(parsed.operationType).toBe('cash_in');
    const normalized = await adapter.normalize(parsed);
    expect(normalized.normalizedStatus).toEqual({ kind: 'cash_in', status: 'paid' });
  });
});

describe('BentsWebhookAdapter.providerName', () => {
  it('exposes the bents provider name as a readonly field', () => {
    const adapter = buildAdapter();
    expect(adapter.providerName).toBe('bents');
  });
});

// ─── PR A — alignment with Bents docs ────────────────────────────────────────
//
// The fixtures below mirror the *exact* payload shapes from the Bents API
// docs (https://finance.bents.com.br/docs § "Webhooks"). They guard the
// regression where our adapter recognised internal vocabulary
// (`charge.paid`, `payment.completed`) but not the canonical Bents
// vocabulary (`pix.charge.paid`, `pix.payment.sent`) — which is what
// actually arrives over the wire in production.

const DOC_PIX_CHARGE_PAID = {
  event: 'pix.charge.paid',
  timestamp: '2026-05-01T15:30:00Z',
  data: {
    charge_uuid: '550e8400-e29b-41d4-a716-446655440000',
    status: 'PAID',
    amount_cents: 1500,
    txid: 'abc123XYZ789',
    e2e_id: 'E18236120202505011530001abcd',
    paid_at: '2026-05-01T15:30:00Z',
    payer: {
      name: 'João da Silva',
      document: '***.456.789-**',
      bank_ispb: '60746948'
    }
  }
};

const DOC_PIX_PAYMENT_SENT = {
  event: 'pix.payment.sent',
  timestamp: '2026-05-01T15:45:00Z',
  data: {
    transaction_id: '660e9511-f3ac-52e5-b827-557766551111',
    status: 'SUCCESS',
    e2e_id: 'E18236120202505011545002efgh',
    e2e_id_dict: 'E18236120202505011544991abcd',
    fee_amount_cents: 50,
    receiver: { name: 'Fornecedor LTDA', document: '***.456.789-**', bank: 'Nubank' }
  }
};

const DOC_PIX_CHARGE_CANCELLED = {
  event: 'pix.charge.cancelled',
  timestamp: '2026-05-13T20:30:00Z',
  data: {
    charge_uuid: '550e8400-e29b-41d4-a716-446655440000',
    status: 'CANCELLED',
    amount_cents: 1500,
    description: 'Pedido #1234',
    cancelled_at: '2026-05-13T20:30:00Z'
  }
};

describe('BentsWebhookAdapter — Bents docs alignment (PR A)', () => {
  it('recognises pix.charge.paid as cash_in and extracts the nested payer block', async () => {
    const adapter = buildAdapter();
    const rawBody = Buffer.from(JSON.stringify(DOC_PIX_CHARGE_PAID));
    const parsed = await adapter.parse({ rawBody, payload: DOC_PIX_CHARGE_PAID, headers: {} });

    expect(parsed.operationType).toBe('cash_in');
    expect(parsed.providerEventType).toBe('pix.charge.paid');
    expect(parsed.providerTransactionId).toBe('550e8400-e29b-41d4-a716-446655440000');
    expect(parsed.providerStatus).toBe('PAID');
    expect(parsed.fields.e2e_id).toBe('E18236120202505011530001abcd');
    expect(parsed.fields.realised_amount).toBe(1500);
    // Nested payer.{name,document} take precedence over the legacy
    // flat payer_name/payer_document shape.
    expect(parsed.fields.payer_name).toBe('João da Silva');
    expect(parsed.fields.payer_document).toBe('***.456.789-**');
    expect(parsed.occurredAt?.toISOString()).toBe('2026-05-01T15:30:00.000Z');

    const normalised = await adapter.normalize(parsed);
    expect(normalised.normalizedStatus).toEqual({ kind: 'cash_in', status: 'paid' });
  });

  it('still honours the legacy flat payer_name/payer_document fallback', async () => {
    const adapter = buildAdapter();
    const parsed = await adapter.parse({
      rawBody: Buffer.from('{}'),
      payload: {
        event: 'pix.charge.paid',
        data: {
          charge_uuid: 'x',
          status: 'PAID',
          payer_name: 'Legacy Payer',
          payer_document: '999.999.999-99'
        }
      },
      headers: {}
    });
    expect(parsed.fields.payer_name).toBe('Legacy Payer');
    expect(parsed.fields.payer_document).toBe('999.999.999-99');
  });

  it('recognises pix.payment.sent as cash_out and extracts e2e_id from data', async () => {
    const adapter = buildAdapter();
    const rawBody = Buffer.from(JSON.stringify(DOC_PIX_PAYMENT_SENT));
    const parsed = await adapter.parse({ rawBody, payload: DOC_PIX_PAYMENT_SENT, headers: {} });

    expect(parsed.operationType).toBe('cash_out');
    expect(parsed.providerEventType).toBe('pix.payment.sent');
    expect(parsed.providerTransactionId).toBe('660e9511-f3ac-52e5-b827-557766551111');
    expect(parsed.providerStatus).toBe('SUCCESS');
    expect(parsed.fields.e2e_id).toBe('E18236120202505011545002efgh');

    const normalised = await adapter.normalize(parsed);
    expect(normalised.normalizedStatus).toEqual({ kind: 'cash_out', status: 'completed' });
  });

  it('recognises pix.charge.cancelled with the cancelled_at timestamp', async () => {
    const adapter = buildAdapter();
    const parsed = await adapter.parse({
      rawBody: Buffer.from('{}'),
      payload: DOC_PIX_CHARGE_CANCELLED,
      headers: {}
    });
    expect(parsed.operationType).toBe('cash_in');
    const normalised = await adapter.normalize(parsed);
    expect(normalised.normalizedStatus).toEqual({ kind: 'cash_in', status: 'cancelled' });
  });

  it('still leaves transfer.refunded / med.* as missing_operation_type (follow-up PR scope)', async () => {
    const adapter = buildAdapter();
    for (const event of ['transfer.refunded', 'med.opened', 'med.resolved']) {
      const parsed = await adapter.parse({
        rawBody: Buffer.from('{}'),
        payload: { event, data: {} },
        headers: {}
      });
      expect(parsed.operationType).toBeNull();
      const normalised = await adapter.normalize(parsed);
      expect(normalised.normalizedStatus).toEqual({
        kind: 'unknown',
        reason: 'missing_operation_type'
      });
    }
  });
});

// The HMAC strict/permissive mode and the bridge-mode behaviour now live
// on `Sha256HmacWebhookAuthStrategy`; their dedicated spec is in
// `tests/unit/sha256-hmac-webhook-auth-strategy.spec.ts`. The adapter
// is now agnostic — see "BentsWebhookAdapter.verify — delegates to the
// injected WebhookAuthStrategy" above.
