import { describe, expect, it } from 'vitest';
import {
  OUTBOX_PRIORITY,
  resolveOutboxPriority
} from '../../src/modules/outbox/outbox-priority.js';

describe('resolveOutboxPriority', () => {
  it('gives pix.cash_in.paid the highest urgency', () => {
    expect(resolveOutboxPriority('pix.cash_in.paid')).toBe(OUTBOX_PRIORITY.CASH_IN_PAID);
    expect(OUTBOX_PRIORITY.CASH_IN_PAID).toBe(10);
  });

  it('ranks other terminal cash-in events below paid', () => {
    for (const t of ['pix.cash_in.expired', 'pix.cash_in.cancelled', 'pix.cash_in.failed', 'pix.cash_in.refunded']) {
      expect(resolveOutboxPriority(t)).toBe(OUTBOX_PRIORITY.CASH_IN_TERMINAL);
    }
    expect(OUTBOX_PRIORITY.CASH_IN_TERMINAL).toBe(30);
  });

  it('ranks cash-out below cash-in', () => {
    for (const t of [
      'pix.cash_out.initiated',
      'pix.cash_out.processing',
      'pix.cash_out.completed',
      'pix.cash_out.failed',
      'pix.cash_out.returned'
    ]) {
      expect(resolveOutboxPriority(t)).toBe(OUTBOX_PRIORITY.CASH_OUT);
    }
    expect(OUTBOX_PRIORITY.CASH_OUT).toBe(60);
  });

  it('still ranks legacy cashout.* tokens in the cash-out lane (pre-0015 rows)', () => {
    for (const t of ['cashout.initiated', 'cashout.processing', 'cashout.completed', 'cashout.failed', 'cashout.returned']) {
      expect(resolveOutboxPriority(t)).toBe(OUTBOX_PRIORITY.CASH_OUT);
    }
  });

  it('falls back to DEFAULT for unknown event types', () => {
    expect(resolveOutboxPriority('something.informational')).toBe(OUTBOX_PRIORITY.DEFAULT);
    expect(resolveOutboxPriority('')).toBe(OUTBOX_PRIORITY.DEFAULT);
    expect(OUTBOX_PRIORITY.DEFAULT).toBe(100);
  });

  it('orders the tiers strictly: paid < terminal < cash-out < default', () => {
    expect(OUTBOX_PRIORITY.CASH_IN_PAID).toBeLessThan(OUTBOX_PRIORITY.CASH_IN_TERMINAL);
    expect(OUTBOX_PRIORITY.CASH_IN_TERMINAL).toBeLessThan(OUTBOX_PRIORITY.CASH_OUT);
    expect(OUTBOX_PRIORITY.CASH_OUT).toBeLessThan(OUTBOX_PRIORITY.DEFAULT);
  });
});
