import { describe, expect, it } from 'vitest';
import {
  toPublicCashIn,
  toPublicCashOut,
  toPublicPixCounterparty,
  type CashInPublicSource,
  type CashOutPublicSource,
  type PublicCounterpartySource
} from '../../src/modules/transactions/public-serialization.js';

const EMPTY_COUNTERPARTY: PublicCounterpartySource = {
  name: null,
  documentNumber: null,
  bank: null,
  ispb: null,
  branch: null,
  account: null,
  accountType: null
};

describe('toPublicPixCounterparty', () => {
  it('renames document_number and keeps every field (nullable children)', () => {
    expect(
      toPublicPixCounterparty({
        name: 'Alice',
        documentNumber: '12345678901',
        bank: 'A55 SCD S.A.',
        ispb: '48756121',
        branch: '0001',
        account: '12345-6',
        accountType: 'checking'
      })
    ).toEqual({
      name: 'Alice',
      document_number: '12345678901',
      bank_name: 'A55 SCD S.A.',
      bank_ispb: '48756121',
      branch: '0001',
      account: '12345-6',
      account_type: 'checking'
    });
  });
});

describe('toPublicCashOut', () => {
  const base: CashOutPublicSource = {
    id: 'co-1',
    externalRef: 'payout-1',
    status: 'processing',
    amountCents: 7_500,
    pixKey: 'alice@example.com',
    pixKeyType: 'EMAIL',
    e2eId: null,
    receiver: { ...EMPTY_COUNTERPARTY, name: 'Alice', documentNumber: '12345678901' },
    createdAt: '2026-05-31T03:53:35.643Z'
  };

  it('nests pix without e2e_id and omits null terminal timestamps', () => {
    const out = toPublicCashOut(base);
    expect(out).toEqual({
      id: 'co-1',
      external_ref: 'payout-1',
      status: 'processing',
      amount: 7_500,
      currency: 'BRL',
      pix: { key: 'alice@example.com', key_type: 'EMAIL' },
      receiver: {
        name: 'Alice',
        document_number: '12345678901',
        bank_name: null,
        bank_ispb: null,
        branch: null,
        account: null,
        account_type: null
      },
      created_at: '2026-05-31T03:53:35.643Z'
    });
    expect(out).not.toHaveProperty('type');
    expect(out).not.toHaveProperty('completed_at');
    expect(out).not.toHaveProperty('e2e_id');
  });

  it('includes pix.e2e_id and completed_at once settled', () => {
    const out = toPublicCashOut({
      ...base,
      status: 'completed',
      e2eId: 'E2E_OUT_1',
      completedAt: new Date('2026-05-31T03:55:00.000Z')
    });
    expect(out.pix.e2e_id).toBe('E2E_OUT_1');
    expect(out.completed_at).toBe('2026-05-31T03:55:00.000Z');
  });

  it('emits failure_reason only on non-success terminal states', () => {
    const failed = toPublicCashOut({ ...base, status: 'failed', failureReason: 'provider_rejected' });
    expect(failed.failure_reason).toBe('provider_rejected');
    const processing = toPublicCashOut({ ...base, failureReason: 'ignored-while-processing' });
    expect(processing).not.toHaveProperty('failure_reason');
  });
});

describe('toPublicCashIn', () => {
  const base: CashInPublicSource = {
    txid: 'tx-1',
    externalRef: 'cashin-1',
    status: 'pending',
    amountCents: 100,
    emv: 'br-code',
    expiresAt: '2026-06-01T02:07:01.231Z',
    e2eId: null,
    payer: null,
    description: 'desc',
    createdAt: '2026-06-01T01:07:01.973Z'
  };

  it('nests pix.emv/expires_at and omits payer/paid_at/e2e_id while pending', () => {
    const out = toPublicCashIn(base);
    expect(out).toEqual({
      txid: 'tx-1',
      external_ref: 'cashin-1',
      amount: 100,
      pix: { emv: 'br-code', expires_at: '2026-06-01T02:07:01.231Z' },
      status: 'pending',
      description: 'desc',
      created_at: '2026-06-01T01:07:01.973Z'
    });
    expect(out).not.toHaveProperty('type');
    expect(out).not.toHaveProperty('payer');
    expect(out).not.toHaveProperty('paid_at');
    expect(out.pix).not.toHaveProperty('e2e_id');
  });

  it('includes payer, paid_at and pix.e2e_id once paid', () => {
    const out = toPublicCashIn({
      ...base,
      status: 'paid',
      e2eId: 'E2E_IN_1',
      paidAt: '2026-06-01T01:09:00.000Z',
      payer: { ...EMPTY_COUNTERPARTY, name: 'Payer', documentNumber: '99999999999' }
    });
    expect(out.pix.e2e_id).toBe('E2E_IN_1');
    expect(out.paid_at).toBe('2026-06-01T01:09:00.000Z');
    expect(out.payer).toEqual({
      name: 'Payer',
      document_number: '99999999999',
      bank_name: null,
      bank_ispb: null,
      branch: null,
      account: null,
      account_type: null
    });
  });

  it('omits the payer block entirely when every field is null', () => {
    const out = toPublicCashIn({ ...base, status: 'paid', payer: { ...EMPTY_COUNTERPARTY } });
    expect(out).not.toHaveProperty('payer');
  });
});
