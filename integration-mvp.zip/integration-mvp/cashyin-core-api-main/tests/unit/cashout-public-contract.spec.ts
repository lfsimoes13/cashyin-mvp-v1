import { describe, expect, it } from 'vitest';
import {
  type CreateCashoutResponse,
  toPublicCashout
} from '../../src/modules/cashouts/cashout.service.js';

/**
 * Locks the public cash-out HTTP contract: snake_case, integer-cents
 * `amount`, and zero leakage of internal pricing/provider/ledger state.
 */
const internal: CreateCashoutResponse = {
  id: '550e8400-e29b-41d4-a716-446655440000',
  clientId: '22222222-2222-4222-8222-222222222222',
  externalRef: 'payout-9876',
  amountCents: 7_500,
  currency: 'BRL',
  pixKey: 'alice@example.com',
  pixKeyType: 'EMAIL',
  receiverName: 'Alice Souza',
  receiverDocument: '12345678901',
  receiverBank: 'A55 SCD S.A.',
  receiverIspb: '48756121',
  receiverBranch: null,
  receiverAccount: null,
  receiverAccountType: null,
  status: 'processing',
  provider: 'bents',
  providerPaymentId: 'pay_001',
  e2eId: null,
  feeAmountCents: 15,
  clientFeeCents: 15,
  providerCostCents: 10,
  marginCents: 5,
  totalDebitAmountCents: 7_515,
  feeAssessmentId: 'fee-assessment-1',
  reservationId: 'reservation-1',
  createdAt: '2026-05-29T19:30:00.000Z',
  completedAt: null,
  failedAt: null,
  returnedAt: null
};

describe('toPublicCashout', () => {
  it('maps to the snake_case public contract with nested pix/receiver and integer-cents amount', () => {
    expect(toPublicCashout(internal)).toEqual({
      id: '550e8400-e29b-41d4-a716-446655440000',
      external_ref: 'payout-9876',
      status: 'processing',
      amount: 7_500,
      currency: 'BRL',
      pix: {
        key: 'alice@example.com',
        key_type: 'EMAIL'
      },
      receiver: {
        name: 'Alice Souza',
        document_number: '12345678901',
        bank_name: 'A55 SCD S.A.',
        bank_ispb: '48756121',
        branch: null,
        account: null,
        account_type: null
      },
      created_at: '2026-05-29T19:30:00.000Z'
    });
  });

  it('never leaks internal pricing, provider or ledger fields', () => {
    const publicBody = toPublicCashout(internal) as Record<string, unknown>;
    for (const leaked of [
      'amount_cents',
      'amountCents',
      'fee_amount_cents',
      'feeAmountCents',
      'client_fee_cents',
      'clientFeeCents',
      'provider_cost_cents',
      'providerCostCents',
      'margin_cents',
      'marginCents',
      'total_debit_amount_cents',
      'totalDebitAmountCents',
      'fee_assessment_id',
      'feeAssessmentId',
      'reservation_id',
      'reservationId',
      'client_id',
      'clientId',
      'provider',
      'provider_payment_id',
      'providerPaymentId',
      'receiver_name',
      'receiver_document',
      'type',
      'pix_key',
      'pix_key_type',
      'e2e_id'
    ]) {
      expect(publicBody).not.toHaveProperty(leaked);
    }
  });

  it('propagates e2e_id under pix once the transfer settles', () => {
    const settled = toPublicCashout({ ...internal, status: 'completed', e2eId: 'E2E_OUT_1' });
    expect(settled.status).toBe('completed');
    expect(settled.pix.e2e_id).toBe('E2E_OUT_1');
  });
});
