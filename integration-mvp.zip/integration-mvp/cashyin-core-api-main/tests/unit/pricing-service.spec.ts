import { describe, expect, it, vi } from 'vitest';

import {
  PricingService,
  type CashoutPricingAssessment
} from '../../src/modules/pricing/index.js';
import type {
  PricingRuleRecord,
  PricingRuleRepository
} from '../../src/modules/pricing/pricing-rule.repository.js';
import type {
  ProviderCostRuleRecord,
  ProviderCostRuleRepository
} from '../../src/modules/pricing/provider-cost-rule.repository.js';
import type {
  FeeAssessmentInsertInput,
  FeeAssessmentRecord,
  FeeAssessmentRepository
} from '../../src/modules/pricing/fee-assessment.repository.js';
import type {
  SubsidyEventInsertInput,
  SubsidyEventRecord,
  SubsidyEventRepository
} from '../../src/modules/pricing/subsidy-event.repository.js';
import type { Sql } from '../../src/shared/db/sql.js';

const stubSql = {} as Sql;
const CLIENT_ID = '11111111-1111-4111-8111-111111111111';
const PROVIDER_ACCOUNT_ID = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
const CASHOUT_AMOUNT_CENTS = 10_000;

function pricingRule(overrides: Partial<PricingRuleRecord> = {}): PricingRuleRecord {
  return {
    id: 'rule-pricing-1',
    pricingPlanVersionId: 'ppv-1',
    operationType: 'cash_out',
    triggerEvent: 'cash_out_created',
    fixedFeeCents: 20,
    variableFeeBps: 0,
    minFeeCents: null,
    maxFeeCents: null,
    billingMode: 'add_to_debit',
    roundingMode: 'round_half_up',
    allowNegativeMargin: false,
    maxNegativeMarginCentsPerTxn: null,
    dailySubsidyLimitCents: null,
    monthlySubsidyLimitCents: null,
    ...overrides
  };
}

function costRule(overrides: Partial<ProviderCostRuleRecord> = {}): ProviderCostRuleRecord {
  return {
    id: 'rule-cost-1',
    providerAccountId: PROVIDER_ACCOUNT_ID,
    operationType: 'cash_out',
    triggerEvent: 'cash_out_created',
    fixedCostCents: 10,
    variableCostBps: 0,
    minCostCents: null,
    maxCostCents: null,
    chargedFromProviderBalance: true,
    roundingMode: 'round_half_up',
    ...overrides
  };
}

class StubPricingRuleRepo implements PricingRuleRepository {
  constructor(private readonly value: PricingRuleRecord | null) {}
  findActiveForClient = vi.fn(async () => this.value);
}

class StubProviderCostRuleRepo implements ProviderCostRuleRepository {
  constructor(private readonly value: ProviderCostRuleRecord | null) {}
  findActiveForProviderAccount = vi.fn(async () => this.value);
}

class StubFeeAssessmentRepo implements FeeAssessmentRepository {
  public lastInsert: FeeAssessmentInsertInput | null = null;
  insert = vi.fn(async (_sql: Sql, input: FeeAssessmentInsertInput): Promise<FeeAssessmentRecord> => {
    this.lastInsert = input;
    return {
      id: 'fee-assessment-1',
      transactionType: input.transactionType,
      transactionId: input.transactionId,
      clientId: input.clientId,
      providerAccountId: input.providerAccountId,
      operationType: input.operationType,
      triggerEvent: input.triggerEvent,
      principalAmountCents: input.principalAmountCents,
      clientFeeCents: input.clientFeeCents,
      providerCostCents: input.providerCostCents,
      marginCents: input.marginCents,
      subsidyCents: input.subsidyCents,
      pricingRuleId: input.pricingRuleId,
      providerCostRuleId: input.providerCostRuleId,
      billingMode: input.billingMode,
      roundingMode: input.roundingMode,
      status: input.status,
      createdAt: new Date('2026-05-22T00:00:00Z'),
      updatedAt: new Date('2026-05-22T00:00:00Z')
    };
  });
  findById = vi.fn(async () => null);
  findByTransaction = vi.fn(async () => null);
  updateStatus = vi.fn(async () => null);
}

class StubSubsidyEventRepo implements SubsidyEventRepository {
  public lastInsert: SubsidyEventInsertInput | null = null;
  public sumValue: number = 0;
  insert = vi.fn(async (_sql: Sql, input: SubsidyEventInsertInput): Promise<SubsidyEventRecord> => {
    this.lastInsert = input;
    return {
      id: 'subsidy-event-1',
      feeAssessmentId: input.feeAssessmentId,
      clientId: input.clientId,
      transactionType: input.transactionType,
      transactionId: input.transactionId,
      subsidyCents: input.subsidyCents,
      status: input.status,
      reason: input.reason,
      createdAt: new Date('2026-05-22T00:00:00Z')
    };
  });
  sumApprovedBetween = vi.fn(async () => this.sumValue);
}

function service(opts: {
  pricingRule?: PricingRuleRecord | null;
  costRule?: ProviderCostRuleRecord | null;
  subsidySumValue?: number;
} = {}) {
  const pricingRuleRepo = new StubPricingRuleRepo(
    opts.pricingRule === undefined ? pricingRule() : opts.pricingRule
  );
  const costRuleRepo = new StubProviderCostRuleRepo(
    opts.costRule === undefined ? costRule() : opts.costRule
  );
  const feeAssessmentRepo = new StubFeeAssessmentRepo();
  const subsidyEventRepo = new StubSubsidyEventRepo();
  if (opts.subsidySumValue !== undefined) {
    subsidyEventRepo.sumValue = opts.subsidySumValue;
  }
  return {
    service: new PricingService(pricingRuleRepo, costRuleRepo, feeAssessmentRepo, subsidyEventRepo),
    pricingRuleRepo,
    costRuleRepo,
    feeAssessmentRepo,
    subsidyEventRepo
  };
}

describe('PricingService.assessForCashout — configuration fallback', () => {
  it('returns null when no pricing rule is configured', async () => {
    const { service: svc } = service({ pricingRule: null });
    const result = await svc.assessForCashout(stubSql, {
      clientId: CLIENT_ID,
      providerAccountId: PROVIDER_ACCOUNT_ID,
      amountCents: CASHOUT_AMOUNT_CENTS
    });
    expect(result).toBeNull();
  });

  it('returns null when no provider cost rule is configured', async () => {
    const { service: svc } = service({ costRule: null });
    const result = await svc.assessForCashout(stubSql, {
      clientId: CLIENT_ID,
      providerAccountId: PROVIDER_ACCOUNT_ID,
      amountCents: CASHOUT_AMOUNT_CENTS
    });
    expect(result).toBeNull();
  });

  it('returns null when both sides are missing', async () => {
    const { service: svc } = service({ pricingRule: null, costRule: null });
    const result = await svc.assessForCashout(stubSql, {
      clientId: CLIENT_ID,
      providerAccountId: PROVIDER_ACCOUNT_ID,
      amountCents: CASHOUT_AMOUNT_CENTS
    });
    expect(result).toBeNull();
  });
});

describe('PricingService.assessForCashout — happy path', () => {
  it('computes fee, cost, margin and approves when policy allows', async () => {
    const { service: svc } = service({
      pricingRule: pricingRule({ fixedFeeCents: 20 }),
      costRule: costRule({ fixedCostCents: 10 })
    });
    const result = await svc.assessForCashout(stubSql, {
      clientId: CLIENT_ID,
      providerAccountId: PROVIDER_ACCOUNT_ID,
      amountCents: CASHOUT_AMOUNT_CENTS
    });
    expect(result).not.toBeNull();
    const assessment = result as CashoutPricingAssessment;
    expect(assessment.clientFeeCents).toBe(20);
    expect(assessment.providerCostCents).toBe(10);
    expect(assessment.marginCents).toBe(10);
    expect(assessment.subsidyCents).toBe(0);
    expect(assessment.billingMode).toBe('add_to_debit');
    expect(assessment.policyDecision.kind).toBe('approved');
    expect(assessment.pricingRuleId).toBe('rule-pricing-1');
    expect(assessment.providerCostRuleId).toBe('rule-cost-1');
  });

  it('returns the rule snapshots so callers can persist them', async () => {
    const { service: svc } = service();
    const result = await svc.assessForCashout(stubSql, {
      clientId: CLIENT_ID,
      providerAccountId: PROVIDER_ACCOUNT_ID,
      amountCents: CASHOUT_AMOUNT_CENTS
    });
    expect(result?.pricingRuleSnapshot.id).toBe('rule-pricing-1');
    expect(result?.providerCostRuleSnapshot.chargedFromProviderBalance).toBe(true);
  });
});

describe('PricingService.assessForCashout — negative margin policy', () => {
  it('rejects when client fee < provider cost and policy disallows', async () => {
    const { service: svc } = service({
      pricingRule: pricingRule({ fixedFeeCents: 5, allowNegativeMargin: false }),
      costRule: costRule({ fixedCostCents: 10 })
    });
    const result = await svc.assessForCashout(stubSql, {
      clientId: CLIENT_ID,
      providerAccountId: PROVIDER_ACCOUNT_ID,
      amountCents: CASHOUT_AMOUNT_CENTS
    });
    expect(result?.policyDecision.kind).toBe('rejected');
    if (result && result.policyDecision.kind === 'rejected') {
      expect(result.policyDecision.code).toBe('pricing_negative_margin_not_allowed');
      expect(result.policyDecision.subsidyCents).toBe(5);
    }
    expect(result?.marginCents).toBe(-5);
    expect(result?.subsidyCents).toBe(5);
  });

  it('approves subsidy within per-txn limit', async () => {
    const { service: svc } = service({
      pricingRule: pricingRule({
        fixedFeeCents: 5,
        allowNegativeMargin: true,
        maxNegativeMarginCentsPerTxn: 10
      }),
      costRule: costRule({ fixedCostCents: 10 })
    });
    const result = await svc.assessForCashout(stubSql, {
      clientId: CLIENT_ID,
      providerAccountId: PROVIDER_ACCOUNT_ID,
      amountCents: CASHOUT_AMOUNT_CENTS
    });
    expect(result?.policyDecision.kind).toBe('approved');
    if (result && result.policyDecision.kind === 'approved') {
      expect(result.policyDecision.subsidyCents).toBe(5);
    }
  });

  it('rejects subsidy that exceeds per-txn limit', async () => {
    const { service: svc } = service({
      pricingRule: pricingRule({
        fixedFeeCents: 5,
        allowNegativeMargin: true,
        maxNegativeMarginCentsPerTxn: 3
      }),
      costRule: costRule({ fixedCostCents: 10 })
    });
    const result = await svc.assessForCashout(stubSql, {
      clientId: CLIENT_ID,
      providerAccountId: PROVIDER_ACCOUNT_ID,
      amountCents: CASHOUT_AMOUNT_CENTS
    });
    expect(result?.policyDecision.kind).toBe('rejected');
    if (result && result.policyDecision.kind === 'rejected') {
      expect(result.policyDecision.code).toBe(
        'pricing_negative_margin_exceeds_per_txn_limit'
      );
    }
  });
});

describe('PricingService.assessForCashout — daily/monthly aggregates', () => {
  it('rejects when adding the prospective subsidy would exceed the daily cap', async () => {
    const { service: svc, subsidyEventRepo } = service({
      pricingRule: pricingRule({
        fixedFeeCents: 0,
        allowNegativeMargin: true,
        maxNegativeMarginCentsPerTxn: 1000,
        dailySubsidyLimitCents: 12
      }),
      costRule: costRule({ fixedCostCents: 10 }),
      subsidySumValue: 5
    });
    const result = await svc.assessForCashout(stubSql, {
      clientId: CLIENT_ID,
      providerAccountId: PROVIDER_ACCOUNT_ID,
      amountCents: CASHOUT_AMOUNT_CENTS
    });
    expect(result?.policyDecision.kind).toBe('rejected');
    if (result && result.policyDecision.kind === 'rejected') {
      expect(result.policyDecision.code).toBe(
        'pricing_negative_margin_exceeds_daily_limit'
      );
      expect(result.policyDecision.dailySubsidyTotalBeforeCents).toBe(5);
    }
    expect(subsidyEventRepo.sumApprovedBetween).toHaveBeenCalled();
  });

  it('approves when daily cap leaves room for the prospective subsidy', async () => {
    const { service: svc } = service({
      pricingRule: pricingRule({
        fixedFeeCents: 0,
        allowNegativeMargin: true,
        maxNegativeMarginCentsPerTxn: 1000,
        dailySubsidyLimitCents: 100
      }),
      costRule: costRule({ fixedCostCents: 10 }),
      subsidySumValue: 50
    });
    const result = await svc.assessForCashout(stubSql, {
      clientId: CLIENT_ID,
      providerAccountId: PROVIDER_ACCOUNT_ID,
      amountCents: CASHOUT_AMOUNT_CENTS
    });
    expect(result?.policyDecision.kind).toBe('approved');
  });

  it('rejects when monthly cap is exceeded even if daily would allow', async () => {
    const { service: svc } = service({
      pricingRule: pricingRule({
        fixedFeeCents: 0,
        allowNegativeMargin: true,
        maxNegativeMarginCentsPerTxn: 1000,
        dailySubsidyLimitCents: 100,
        monthlySubsidyLimitCents: 60
      }),
      costRule: costRule({ fixedCostCents: 10 }),
      subsidySumValue: 55
    });
    const result = await svc.assessForCashout(stubSql, {
      clientId: CLIENT_ID,
      providerAccountId: PROVIDER_ACCOUNT_ID,
      amountCents: CASHOUT_AMOUNT_CENTS
    });
    expect(result?.policyDecision.kind).toBe('rejected');
    if (result && result.policyDecision.kind === 'rejected') {
      expect(result.policyDecision.code).toBe(
        'pricing_negative_margin_exceeds_monthly_limit'
      );
    }
  });

  it('does not call sumApprovedBetween when subsidy is zero', async () => {
    const { service: svc, subsidyEventRepo } = service({
      pricingRule: pricingRule({
        fixedFeeCents: 20,
        allowNegativeMargin: true,
        maxNegativeMarginCentsPerTxn: 1000,
        dailySubsidyLimitCents: 100,
        monthlySubsidyLimitCents: 1000
      }),
      costRule: costRule({ fixedCostCents: 10 })
    });
    const result = await svc.assessForCashout(stubSql, {
      clientId: CLIENT_ID,
      providerAccountId: PROVIDER_ACCOUNT_ID,
      amountCents: CASHOUT_AMOUNT_CENTS
    });
    expect(result?.policyDecision.kind).toBe('approved');
    expect(subsidyEventRepo.sumApprovedBetween).not.toHaveBeenCalled();
  });

  it('does not call sumApprovedBetween when no aggregate limit is configured', async () => {
    const { service: svc, subsidyEventRepo } = service({
      pricingRule: pricingRule({
        fixedFeeCents: 5,
        allowNegativeMargin: true,
        maxNegativeMarginCentsPerTxn: 1000
      }),
      costRule: costRule({ fixedCostCents: 10 })
    });
    const result = await svc.assessForCashout(stubSql, {
      clientId: CLIENT_ID,
      providerAccountId: PROVIDER_ACCOUNT_ID,
      amountCents: CASHOUT_AMOUNT_CENTS
    });
    expect(result?.policyDecision.kind).toBe('approved');
    expect(subsidyEventRepo.sumApprovedBetween).not.toHaveBeenCalled();
  });
});

describe('PricingService.persistAssessment / persistSubsidyEvent', () => {
  it('persists the assessment with the requested status and trigger event', async () => {
    const { service: svc, feeAssessmentRepo } = service();
    const assessment = (await svc.assessForCashout(stubSql, {
      clientId: CLIENT_ID,
      providerAccountId: PROVIDER_ACCOUNT_ID,
      amountCents: CASHOUT_AMOUNT_CENTS
    })) as CashoutPricingAssessment;

    const record = await svc.persistAssessment(stubSql, {
      assessment,
      transactionType: 'cashout',
      transactionId: 'cashout-abc',
      clientId: CLIENT_ID,
      providerAccountId: PROVIDER_ACCOUNT_ID,
      operationType: 'cash_out',
      triggerEvent: 'cash_out_created',
      principalAmountCents: CASHOUT_AMOUNT_CENTS,
      status: 'estimated',
      metadata: { externalId: 'ext-1' }
    });

    expect(record.id).toBe('fee-assessment-1');
    expect(feeAssessmentRepo.lastInsert).toMatchObject({
      transactionType: 'cashout',
      transactionId: 'cashout-abc',
      principalAmountCents: CASHOUT_AMOUNT_CENTS,
      clientFeeCents: 20,
      providerCostCents: 10,
      marginCents: 10,
      subsidyCents: 0,
      pricingRuleId: 'rule-pricing-1',
      providerCostRuleId: 'rule-cost-1',
      billingMode: 'add_to_debit',
      status: 'estimated',
      metadata: { externalId: 'ext-1' }
    });
  });

  it('persists a subsidy event with a policy snapshot that includes aggregates', async () => {
    const { service: svc, subsidyEventRepo } = service({
      pricingRule: pricingRule({
        fixedFeeCents: 5,
        allowNegativeMargin: true,
        maxNegativeMarginCentsPerTxn: 1000,
        dailySubsidyLimitCents: 100,
        monthlySubsidyLimitCents: 1000
      }),
      costRule: costRule({ fixedCostCents: 10 }),
      subsidySumValue: 30
    });
    const assessment = (await svc.assessForCashout(stubSql, {
      clientId: CLIENT_ID,
      providerAccountId: PROVIDER_ACCOUNT_ID,
      amountCents: CASHOUT_AMOUNT_CENTS
    })) as CashoutPricingAssessment;
    expect(assessment.policyDecision.kind).toBe('approved');
    if (assessment.policyDecision.kind !== 'approved') return;

    await svc.persistSubsidyEvent(stubSql, {
      feeAssessmentId: 'fee-assessment-1',
      clientId: CLIENT_ID,
      transactionType: 'cashout',
      transactionId: 'cashout-abc',
      subsidyCents: assessment.policyDecision.subsidyCents,
      status: 'approved',
      reason: 'cashout subsidy approved',
      policy: assessment.policy,
      dailySubsidyTotalBeforeCents:
        assessment.policyDecision.dailySubsidyTotalBeforeCents,
      monthlySubsidyTotalBeforeCents:
        assessment.policyDecision.monthlySubsidyTotalBeforeCents
    });

    expect(subsidyEventRepo.lastInsert).not.toBeNull();
    expect(subsidyEventRepo.lastInsert?.subsidyCents).toBe(5);
    expect(subsidyEventRepo.lastInsert?.status).toBe('approved');
    expect(subsidyEventRepo.lastInsert?.policySnapshot).toMatchObject({
      allowNegativeMargin: true,
      maxNegativeMarginCentsPerTxn: 1000,
      dailySubsidyLimitCents: 100,
      monthlySubsidyLimitCents: 1000,
      dailySubsidyTotalBeforeCents: 30,
      monthlySubsidyTotalBeforeCents: 30
    });
  });
});

describe('PricingService.assessForCashIn — Phase 4 surface', () => {
  it('looks up the cash_in_paid rule by default and returns the assessment', async () => {
    const cashInPricingRule = pricingRule({
      operationType: 'cash_in',
      triggerEvent: 'cash_in_paid',
      fixedFeeCents: 12,
      billingMode: 'deduct_from_settlement'
    });
    const cashInCostRule = costRule({
      operationType: 'cash_in',
      triggerEvent: 'cash_in_paid',
      fixedCostCents: 3,
      chargedFromProviderBalance: false
    });
    const { service: svc, pricingRuleRepo, costRuleRepo } = service({
      pricingRule: cashInPricingRule,
      costRule: cashInCostRule
    });

    const result = await svc.assessForCashIn(stubSql, {
      clientId: CLIENT_ID,
      providerAccountId: PROVIDER_ACCOUNT_ID,
      amountCents: 10_000
    });

    expect(pricingRuleRepo.findActiveForClient).toHaveBeenCalledWith(
      expect.anything(),
      expect.objectContaining({ operationType: 'cash_in', triggerEvent: 'cash_in_paid' })
    );
    expect(costRuleRepo.findActiveForProviderAccount).toHaveBeenCalledWith(
      expect.anything(),
      expect.objectContaining({ operationType: 'cash_in', triggerEvent: 'cash_in_paid' })
    );
    expect(result?.clientFeeCents).toBe(12);
    expect(result?.providerCostCents).toBe(3);
    expect(result?.billingMode).toBe('deduct_from_settlement');
  });

  it('returns null when no cash-in pricing rule is configured', async () => {
    const { service: svc } = service({ pricingRule: null });
    const result = await svc.assessForCashIn(stubSql, {
      clientId: CLIENT_ID,
      providerAccountId: PROVIDER_ACCOUNT_ID,
      amountCents: 10_000
    });
    expect(result).toBeNull();
  });
});

describe('PricingService.findAssessmentByTransaction / promoteAssessmentStatus', () => {
  it('forwards the lookup to the repository', async () => {
    const { service: svc, feeAssessmentRepo } = service();
    feeAssessmentRepo.findByTransaction = vi.fn(async () => null);
    await svc.findAssessmentByTransaction(stubSql, 'cash_in', 'charge-1', 'cash_in_paid');
    expect(feeAssessmentRepo.findByTransaction).toHaveBeenCalledWith(
      expect.anything(),
      'cash_in',
      'charge-1',
      'cash_in_paid'
    );
  });

  it('forwards the promotion to the repository', async () => {
    const { service: svc, feeAssessmentRepo } = service();
    feeAssessmentRepo.updateStatus = vi.fn(async () => null);
    await svc.promoteAssessmentStatus(stubSql, 'fee-1', 'posted');
    expect(feeAssessmentRepo.updateStatus).toHaveBeenCalledWith(
      expect.anything(),
      'fee-1',
      'posted'
    );
  });
});

describe('PricingService.evaluatePolicyWithAggregates — deterministic per-txn pass-through', () => {
  it('returns approved with zero subsidy when prospective subsidy is zero', async () => {
    const { service: svc } = service();
    const decision = await svc.evaluatePolicyWithAggregates(stubSql, {
      clientId: CLIENT_ID,
      policy: {
        allowNegativeMargin: true,
        maxNegativeMarginCentsPerTxn: 100,
        dailySubsidyLimitCents: 100,
        monthlySubsidyLimitCents: 1000
      },
      prospectiveSubsidyCents: 0
    });
    expect(decision.kind).toBe('approved');
    if (decision.kind === 'approved') {
      expect(decision.subsidyCents).toBe(0);
    }
  });

  it('rejects when allowNegativeMargin is false even with low subsidy', async () => {
    const { service: svc } = service();
    const decision = await svc.evaluatePolicyWithAggregates(stubSql, {
      clientId: CLIENT_ID,
      policy: {
        allowNegativeMargin: false,
        maxNegativeMarginCentsPerTxn: null,
        dailySubsidyLimitCents: null,
        monthlySubsidyLimitCents: null
      },
      prospectiveSubsidyCents: 1
    });
    expect(decision.kind).toBe('rejected');
    if (decision.kind === 'rejected') {
      expect(decision.code).toBe('pricing_negative_margin_not_allowed');
    }
  });
});
