import { createHmac } from 'node:crypto';
import { describe, expect, it } from 'vitest';
import { Sha256HmacWebhookAuthStrategy } from '../../src/providers/security/sha256-hmac.strategy.js';

const SECRET = 'test-strategy-secret';

function signSha256(body: Buffer, secret: string = SECRET): string {
  return `sha256=${createHmac('sha256', secret).update(body).digest('hex')}`;
}

function buildStrategy(
  overrides: Partial<{
    signatureHeader: string;
    signaturePrefix: string;
    secret: string | undefined;
    requireSignature: boolean;
  }> = {}
): Sha256HmacWebhookAuthStrategy {
  return new Sha256HmacWebhookAuthStrategy({
    signatureHeader: overrides.signatureHeader ?? 'x-test-signature',
    signaturePrefix: overrides.signaturePrefix ?? 'sha256=',
    secret: 'secret' in overrides ? overrides.secret : SECRET,
    ...(overrides.requireSignature !== undefined
      ? { requireSignature: overrides.requireSignature }
      : {})
  });
}

describe('Sha256HmacWebhookAuthStrategy', () => {
  describe('strict mode (default)', () => {
    it('exposes name = sha256_hmac', () => {
      expect(buildStrategy().name).toBe('sha256_hmac');
    });

    it('rejects when signature header is missing', async () => {
      const strategy = buildStrategy({ requireSignature: true });
      const result = await strategy.verify({
        rawBody: Buffer.from('{}'),
        signature: null,
        headers: {},
        receivedAt: new Date()
      });
      expect(result).toEqual({ valid: false, reason: 'missing_signature' });
    });

    it('rejects when secret is not configured', async () => {
      const strategy = buildStrategy({ secret: undefined, requireSignature: true });
      const result = await strategy.verify({
        rawBody: Buffer.from('{}'),
        signature: 'sha256=anything',
        headers: {},
        receivedAt: new Date()
      });
      expect(result).toEqual({ valid: false, reason: 'missing_secret' });
    });

    it('rejects when signature lacks the configured prefix', async () => {
      const strategy = buildStrategy({ signaturePrefix: 'sha256=', requireSignature: true });
      const result = await strategy.verify({
        rawBody: Buffer.from('{}'),
        signature: 'md5=deadbeef',
        headers: {},
        receivedAt: new Date()
      });
      expect(result).toEqual({
        valid: false,
        reason: 'malformed_signature',
        detail: 'expected sha256= prefix'
      });
    });

    it('rejects a tampered signature', async () => {
      const strategy = buildStrategy({ requireSignature: true });
      const body = Buffer.from('{"hello":"world"}');
      const result = await strategy.verify({
        rawBody: body,
        signature: signSha256(body, 'wrong-secret'),
        headers: {},
        receivedAt: new Date()
      });
      expect(result).toEqual({ valid: false, reason: 'invalid_signature' });
    });

    it('accepts a valid signature', async () => {
      const strategy = buildStrategy({ requireSignature: true });
      const body = Buffer.from('{"hello":"world"}');
      const result = await strategy.verify({
        rawBody: body,
        signature: signSha256(body),
        headers: {},
        receivedAt: new Date()
      });
      expect(result).toEqual({ valid: true });
    });

    it('falls back to scanning headers when signature input is null (case-insensitive)', async () => {
      const strategy = buildStrategy({
        signatureHeader: 'x-test-signature',
        requireSignature: true
      });
      const body = Buffer.from('{}');
      const result = await strategy.verify({
        rawBody: body,
        signature: null,
        headers: { 'X-Test-Signature': signSha256(body) },
        receivedAt: new Date()
      });
      expect(result).toEqual({ valid: true });
    });
  });

  describe('permissive mode (requireSignature=false)', () => {
    it('accepts when signature is missing', async () => {
      const strategy = buildStrategy({ requireSignature: false });
      const result = await strategy.verify({
        rawBody: Buffer.from('{}'),
        signature: null,
        headers: {},
        receivedAt: new Date()
      });
      expect(result).toEqual({ valid: true });
    });

    it('accepts when secret is missing', async () => {
      const strategy = buildStrategy({ secret: undefined, requireSignature: false });
      const result = await strategy.verify({
        rawBody: Buffer.from('{}'),
        signature: 'sha256=any',
        headers: {},
        receivedAt: new Date()
      });
      expect(result).toEqual({ valid: true });
    });

    it('accepts when signature has the wrong prefix', async () => {
      const strategy = buildStrategy({ requireSignature: false });
      const result = await strategy.verify({
        rawBody: Buffer.from('{}'),
        signature: 'md5=anything',
        headers: {},
        receivedAt: new Date()
      });
      expect(result).toEqual({ valid: true });
    });

    it('still rejects when both sides are present but the signature is tampered', async () => {
      const strategy = buildStrategy({ requireSignature: false });
      const body = Buffer.from('payload');
      const result = await strategy.verify({
        rawBody: body,
        signature: signSha256(body, 'wrong-secret'),
        headers: {},
        receivedAt: new Date()
      });
      expect(result).toEqual({ valid: false, reason: 'invalid_signature' });
    });

    it('accepts a valid signature even in permissive mode', async () => {
      const strategy = buildStrategy({ requireSignature: false });
      const body = Buffer.from('payload');
      const result = await strategy.verify({
        rawBody: body,
        signature: signSha256(body),
        headers: {},
        receivedAt: new Date()
      });
      expect(result).toEqual({ valid: true });
    });
  });
});
