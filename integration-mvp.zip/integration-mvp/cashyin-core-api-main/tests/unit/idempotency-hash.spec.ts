import { describe, expect, it } from 'vitest';
import { hashRequest, stableStringify } from '../../src/modules/idempotency/idempotency.hash.js';

describe('stableStringify', () => {
  it('produces identical output regardless of key ordering', () => {
    const a = stableStringify({ b: 1, a: 2, nested: { y: 'y', x: 'x' } });
    const b = stableStringify({ nested: { x: 'x', y: 'y' }, a: 2, b: 1 });
    expect(a).toBe(b);
  });

  it('drops undefined values while keeping nulls', () => {
    expect(stableStringify({ a: undefined, b: null })).toBe('{"b":null}');
  });

  it('rejects non-finite numbers to avoid silent hash drift', () => {
    expect(() => stableStringify({ a: Number.POSITIVE_INFINITY })).toThrow(TypeError);
    expect(() => stableStringify({ a: Number.NaN })).toThrow(TypeError);
  });
});

describe('hashRequest', () => {
  it('returns the same hash for semantically equal payloads', () => {
    const left = hashRequest({ amountCents: 1500, externalId: 'order-1', metadata: { a: 1, b: 2 } });
    const right = hashRequest({ metadata: { b: 2, a: 1 }, externalId: 'order-1', amountCents: 1500 });
    expect(left).toBe(right);
  });

  it('changes the hash when any field changes', () => {
    const original = hashRequest({ amountCents: 1500, externalId: 'order-1' });
    const mutated = hashRequest({ amountCents: 1501, externalId: 'order-1' });
    expect(original).not.toBe(mutated);
  });

  it('produces hex-encoded sha256 output', () => {
    const value = hashRequest({ foo: 'bar' });
    expect(value).toMatch(/^[0-9a-f]{64}$/);
  });
});
