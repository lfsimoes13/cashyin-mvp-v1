# CashYin Core API

**CashYin** is a new, independent financial processing API focused on PIX cash-in, PIX cash-out, provider routing, auditability, and safe high-volume operation. This repository is intentionally separated from JadeLink v1 and must not modify v1 contracts, infrastructure, users, or production traffic.

The project starts with a native **Bents** provider adapter and a multi-provider core that makes future provider additions incremental instead of invasive. The first implementation milestone is the processing core: public API contracts, provider abstraction, ledger model, idempotency model, outbox pattern, webhook ingestion, and PostgreSQL migration baseline.

| Area | Initial Decision |
|---|---|
| Runtime | Node.js 22 with TypeScript and Fastify |
| Financial source of truth | PostgreSQL or Aurora PostgreSQL |
| Cache, locks, rate control | Redis |
| Async processing | Queue/outbox workers, with AWS SQS planned for cloud deployment |
| Observability | Structured logs now; OpenTelemetry-ready instrumentation points |
| Initial provider | Bents |
| Provider strategy | Versioned provider assignments per client and operation type |

## Repository Naming

The repository is named `cashyin-core-api` using lowercase kebab-case. The suffix `core-api` communicates that this repository owns the transactional processing API and not future dashboards, BI, backoffice, or reconciliation products.

## Local Development

```bash
pnpm install
cp .env.example .env
pnpm db:migrate
psql "$DATABASE_URL" -f scripts/seed-dev.sql   # optional dev fixtures
pnpm dev:api                                   # HTTP API
pnpm dev:provider-webhook-worker               # inbound provider webhook processor
pnpm dev:webhook-dispatcher-worker             # outbound public webhook dispatcher
```

The API and the two background workers are **independent processes**. Each owns its own poll loop, but they share the same dependency container (`src/app/container.ts`) so wiring stays in sync. Production scripts (`start:api`, `start:provider-webhook-worker`, `start:webhook-dispatcher-worker`) map 1:1 to the dev ones above and point at the compiled `dist/main*-worker.js` entrypoints. See [`infra/README.md` → Background workers](infra/README.md#background-workers) for the deferred ECS task definitions and the temporary single-task fallback.

PostgreSQL is now the financial source of truth: cash-in, cash-out, idempotency, liquidity reservations, outbox events, and webhook audit rows all persist through repositories defined in `src/modules/**` and assembled in `src/app/container.ts`. `DATABASE_URL` must be set whenever the API or workers are started; the `/ready` endpoint runs `SELECT 1` so health checks fail loudly if the connection drops. The optional `scripts/seed-dev.sql` script seeds a demo client, a default Bents provider account, and active assignments so the routes can be exercised end-to-end.

`pnpm db:migrate` runs `scripts/migrate.mjs`, which applies every `migrations/*.sql` file in lexicographic order exactly once and tracks applied files in `schema_migrations`. The current set includes the initial schema (`0001`), monthly ledger partitions (`0002`–`0005` for pricing, liquidity and system accounts) and the transaction-status split + provider webhook audit tables (`0006`). Ledger writes fall through to `ledger_entries_default` whenever `created_at` lands outside an explicit monthly window, so monitoring must alert on any non-zero row count in that partition.

## Manual testing (Postman)

A ready-to-run Postman v2.1 collection lives in `postman/`:

- `postman/cashyin-core-api.postman_collection.json`
- `postman/cashyin-local.postman_environment.json`

Setup steps:

1. Ensure the API is running locally (`pnpm dev` or `pnpm build && node dist/src/main.js`) and that `DATABASE_URL` points to the migrated database.
2. Run the dev seed so the routes have a valid client and provider assignment:
   ```bash
   psql "$DATABASE_URL" -f scripts/seed-dev.sql
   ```
3. Open Postman → **Import** → drop both files. Pick the `CashYin Local` environment in the top-right environment selector.
4. In the environment, set `bentsWebhookSecret` to the exact value of `BENTS_WEBHOOK_SECRET` in your `.env`. The webhook request signs the body with this secret at send-time, so any mismatch returns 401.

What the collection covers:

- `Health` — liveness (`/health`) and PostgreSQL readiness (`/ready`).
- `Cash-in` — `POST /v1/pix/cash-in/qrcode` (no `Idempotency-Key`); a repeat with the same `external_ref` returns the original charge (dedup business rule); invalid payload (422). The fresh request stores `txid` in a collection variable so `GET /v1/pix/cash-in/{txid}` can chain off it.
- `Cash-out` — fresh `POST /v1/pix/cash-out` (**requires `Idempotency-Key`**), replay with the same key, idempotency-key conflict (same key + different body → 409), missing `Idempotency-Key` (400), and a 422 validation case.
- `Webhook` — `POST /internal/webhooks/bents` with a pre-request script that computes `x-bents-signature: sha256=<HMAC>` over the exact body bytes via CryptoJS; also a bogus-signature case (401) and a missing-header case (401).

### Bents prod-safety guardrails

Today the API calls `BENTS_API_BASE_URL` directly, which by default points at Bents production. While Bents is not serving real customer traffic, every `POST /v1/pix/cash-in/qrcode` and `POST /v1/pix/cash-out` still creates a real resource in your Bents account. Treat the manual-testing workflow accordingly:

- Keep `cashinAmountCents` and `cashoutAmountCents` small (the collection defaults to `100` cents) so noise in your Bents account is bounded.
- Never paste a real customer PIX key in `cashoutPixKey`. The default `00000000000` will be rejected by Bents and is safe to leave as-is until you have a controlled test key.
- To abort and retry safely: cash-in is deduped by `external_ref` (replay the same `external_ref` to get the original charge, no new Bents resource); cash-out is deduped by its `Idempotency-Key` (replay the same key + payload).
- For signed webhook curl flows outside Postman, use `scripts/sign-webhook.mjs`:
   ```bash
   echo '{"event":"charge.paid","charge_uuid":"<id>","status":"PAID"}' \
     | BENTS_WEBHOOK_SECRET=<your-secret> node scripts/sign-webhook.mjs --curl
   ```

### Provider correctness notes (Bents)

The Bents API (https://finance.bents.com.br/docs) does **not** support a client-supplied idempotency key on `POST /pix/charge` or `POST /pix/payment`, and `POST /pix/charge` generates its own Pix `txid` server-side. CashYin therefore:

- **Generates its own public `txid` for cash-in** (`generatePixTxid()` — UUID v4 without hyphens, 32 lowercase chars) before calling Bents. The provider's own txid is stored separately as the internal `provider_tx_id` and is **never** exposed publicly.
- Does not send `x-idempotency-key`, `external_id`, or `metadata` to Bents.
- **Cash-in retry-safety**: no `Idempotency-Key` header; dedup by the `(client_id, external_ref)` business rule (`UNIQUE` constraint). A repeated `external_ref` returns the existing charge without a second Bents call.
- **Cash-out retry-safety**: requires `Idempotency-Key` (scoped per client).
- Treats provider timeouts, 5xx, 408, 425, 429 and any unclassified error as **ambiguous**: for cash-out the idempotency lock and liquidity reservation are retained; for cash-in a `reconciliation_required` structured log line is emitted (keyed on `client_id`/`external_ref`) so an operator/cron can determine the true provider state before retrying.
- Treats other 4xx as **definite_client_error** (cash-out releases its idempotency lock and reservation; cash-in simply surfaces the error with no orphan).
- **Cash-out** stale-lock takeover (previous owner crashed before finalising) probes the local `cashouts` row by `(client_id, external_id)`; if a row exists the cached response is replayed, otherwise the request is refused with `409 cashout_stale_lock_requires_reconciliation`. Cash-in has no lock to recover — a concurrent duplicate `external_ref` simply returns the winning charge and flags any orphaned provider charge for reconciliation.

Webhook deduplication via `(provider_name, provider_event_id)` is documented as a known gap: Bents webhooks do not carry a generic `event_id`. M5/M6 will introduce a composite dedupe key based on domain identifiers (`charge_uuid` for `pix/charge` webhooks, `transaction_id` for `pix/payment` webhooks) before any webhook-driven state transition runs in production.

## Documentation

The `docs/` directory is part of the product deliverable and should be treated as source-controlled architecture. Start with:

| Document | Purpose |
|---|---|
| `docs/architecture.md` | System architecture and critical invariants |
| `docs/multi-provider.md` | Provider interface and implementation guide |
| `docs/provider-migration.md` | Safe migration flow between providers |
| `docs/database-schema.md` | PostgreSQL model and partitioning guidance |
| `docs/api-contracts.md` | External public API contract draft |
| `docs/cursor/README.md` | Instructions for Cursor and AI coding agents |
| `docs/adr/0001-core-architecture.md` | First architecture decision record |

## Critical Financial Invariants

CashYin must remain **ledger-first, idempotent, auditable, and provider-agnostic**. Every cash-out requires both accounting balance availability and operational liquidity availability. Ledger entries are append-only; corrections are compensating entries, never updates in place.

