const required = ['BENTS_API_KEY', 'BENTS_WEBHOOK_SECRET'];
const missing = required.filter((name) => !process.env[name]);

if (missing.length > 0) {
  console.error(`Missing required environment variables: ${missing.join(', ')}`);
  process.exit(1);
}

console.log('Required environment variables are present.');

