#!/usr/bin/env node
/* eslint-disable no-console */
//
// scripts/migrate.mjs
//
// Idempotent migration runner. Each *.sql file under `migrations/` is run
// exactly once and recorded in a `schema_migrations` tracker table so
// subsequent runs skip already-applied files.
//
// The script lives next to the Dockerfile so the same image that ships
// the API server can also run migrations: in ECS we register a separate
// task definition whose container `command` overrides the default and
// becomes ["node", "scripts/migrate.mjs"]. The container then exits with
// code 0 on success, non-zero on failure (and ECS RunTask propagates the
// exit code to the caller).
//
// Usage:
//   DATABASE_URL=postgres://... node scripts/migrate.mjs [migrations-dir]
//
// Defaults:
//   migrations-dir = ./migrations
//
// Behaviour:
//   * Creates `schema_migrations(filename, checksum, applied_at)` if missing.
//   * For each *.sql file in lexicographic order:
//       - Skip if `filename` already present in `schema_migrations`.
//       - Otherwise run the SQL inside a single transaction and insert
//         a row into `schema_migrations` in the same transaction.
//   * On any error: ROLLBACK the current file and abort. Already-applied
//     files stay applied; the failing file is left unapplied so the
//     operator can fix and re-run.

import { createHash } from 'node:crypto';
import { readFile, readdir } from 'node:fs/promises';
import path from 'node:path';
import { Client } from 'pg';

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) {
  console.error('FATAL: DATABASE_URL is required');
  process.exit(2);
}

const migrationsDir = process.argv[2] ?? 'migrations';

/**
 * @param {string} sql
 * @returns {string} short hex checksum used only for drift detection logs.
 */
function checksum(sql) {
  return createHash('sha256').update(sql, 'utf8').digest('hex').slice(0, 12);
}

async function listSqlFiles(dir) {
  const entries = await readdir(dir, { withFileTypes: true });
  return entries
    .filter((e) => e.isFile() && e.name.endsWith('.sql'))
    .map((e) => e.name)
    .sort();
}

async function ensureTracker(client) {
  await client.query(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      filename   TEXT PRIMARY KEY,
      checksum   TEXT NOT NULL,
      applied_at TIMESTAMPTZ NOT NULL DEFAULT now()
    )
  `);
}

async function listApplied(client) {
  const { rows } = await client.query(
    'SELECT filename, checksum FROM schema_migrations'
  );
  return new Map(rows.map((r) => [r.filename, r.checksum]));
}

async function applyOne(client, dir, file) {
  const fullPath = path.join(dir, file);
  const sql = await readFile(fullPath, 'utf8');
  const sum = checksum(sql);
  const t0 = Date.now();

  console.log(`→ ${file} (${sql.length} bytes, checksum=${sum})`);

  await client.query('BEGIN');
  try {
    await client.query(sql);
    await client.query(
      'INSERT INTO schema_migrations (filename, checksum) VALUES ($1, $2)',
      [file, sum]
    );
    await client.query('COMMIT');
    console.log(`  ✓ applied in ${Date.now() - t0}ms`);
  } catch (err) {
    await client.query('ROLLBACK');
    const message = err instanceof Error ? err.message : String(err);
    console.error(`  ✗ failed: ${message}`);
    throw err;
  }
}

async function main() {
  const client = new Client({
    connectionString: databaseUrl,
    // Wait up to 30 s for the connection so we don't fail the ECS run-task
    // call on transient DNS hiccups when the API service is also booting.
    connectionTimeoutMillis: 30_000,
    // Statement timeout 5 min is generous for DDL such as creating monthly
    // partitions. Bump if a future migration legitimately needs longer.
    statement_timeout: 300_000
  });

  await client.connect();

  try {
    await ensureTracker(client);

    const files = await listSqlFiles(migrationsDir);
    const applied = await listApplied(client);
    const pending = files.filter((f) => !applied.has(f));

    console.log(`migrations dir : ${path.resolve(migrationsDir)}`);
    console.log(`files on disk  : ${files.length}`);
    console.log(`already applied: ${applied.size}`);
    console.log(`pending        : ${pending.length}`);
    if (pending.length === 0) {
      console.log('Schema is up to date.');
      return;
    }

    for (const file of pending) {
      await applyOne(client, migrationsDir, file);
    }

    console.log('All pending migrations applied.');
  } finally {
    await client.end();
  }
}

main().catch((err) => {
  const message = err instanceof Error ? err.message : String(err);
  console.error(`FATAL: ${message}`);
  process.exit(1);
});
