#!/usr/bin/env node
/* eslint-disable no-console */
//
// scripts/provision-provider.mjs
//
// Full provider provisioning: registers a provider account, wires it to a
// client, sets cost rules for cash-in and cash-out, and optionally assigns
// the standard client pricing plan.
//
// The script is intentionally idempotent — safe to re-run at any time:
//   * provider_accounts           → reused if (provider_name, alias) already exists
//   * client_provider_assignments → reused if an active assignment exists
//   * provider_cost_rules         → no-op if unchanged; rotates if costs changed
//   * pricing plan assignment     → no-op if an active assignment already exists
//
// Usage — minimal (cost rules only, no client assignment):
//   DATABASE_URL=postgres://... \
//   PROVIDER_NAME=bents \
//   PROVIDER_ALIAS=default \
//   CASH_IN_COST_CENTS=10 \
//   CASH_OUT_COST_CENTS=10 \
//   node scripts/provision-provider.mjs
//
// Usage — full (provider routing + client pricing plan):
//   DATABASE_URL=postgres://... \
//   PROVIDER_NAME=bents \
//   PROVIDER_ALIAS=default \
//   CLIENT_ID=<uuid> \
//   CASH_IN_COST_CENTS=10 \
//   CASH_OUT_COST_CENTS=10 \
//   ASSIGN_PRICING_PLAN=true \
//   node scripts/provision-provider.mjs
//
// Advanced overrides:
//   CASH_IN_VARIABLE_BPS=0        default: 0
//   CASH_OUT_VARIABLE_BPS=0       default: 0
//   CASH_IN_TRIGGER_EVENT=cash_in_paid          default: cash_in_paid
//   CASH_OUT_TRIGGER_EVENT=cash_out_created     default: cash_out_created
//   CHARGED_FROM_PROVIDER_BALANCE=true          default: true
//   PRICING_PLAN_NAME=standard    default: standard  (used with ASSIGN_PRICING_PLAN)
//   DRY_RUN=true                  print SQL without executing
//
// Note: the standard pricing plan is seeded by migration 0009. Run migrations
// before using ASSIGN_PRICING_PLAN=true in a fresh environment.
//
// Note: adding a brand-new provider name requires a migration first:
//   ALTER TYPE provider_name ADD VALUE 'new_provider';
// This script only handles provider_accounts rows (not the enum).

import { Client } from 'pg';

// ─── env ─────────────────────────────────────────────────────────────────────

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) {
  console.error('FATAL: DATABASE_URL is required');
  process.exit(2);
}

const providerName = process.env.PROVIDER_NAME ?? 'bents';
const providerAlias = process.env.PROVIDER_ALIAS ?? 'default';
const clientId = process.env.CLIENT_ID ?? null;

const cashInCostCents = parseInt(process.env.CASH_IN_COST_CENTS ?? '0', 10);
const cashOutCostCents = parseInt(process.env.CASH_OUT_COST_CENTS ?? '0', 10);
const cashInVariableBps = parseInt(process.env.CASH_IN_VARIABLE_BPS ?? '0', 10);
const cashOutVariableBps = parseInt(process.env.CASH_OUT_VARIABLE_BPS ?? '0', 10);
const cashInTriggerEvent = process.env.CASH_IN_TRIGGER_EVENT ?? 'cash_in_paid';
const cashOutTriggerEvent = process.env.CASH_OUT_TRIGGER_EVENT ?? 'cash_out_created';
const chargedFromProviderBalance =
  (process.env.CHARGED_FROM_PROVIDER_BALANCE ?? 'true').toLowerCase() !== 'false';
const assignPricingPlan =
  (process.env.ASSIGN_PRICING_PLAN ?? 'false').toLowerCase() === 'true';
const pricingPlanName = process.env.PRICING_PLAN_NAME ?? 'standard';
const dryRun = (process.env.DRY_RUN ?? 'false').toLowerCase() === 'true';

if (isNaN(cashInCostCents) || cashInCostCents < 0) {
  console.error('FATAL: CASH_IN_COST_CENTS must be a non-negative integer');
  process.exit(2);
}
if (isNaN(cashOutCostCents) || cashOutCostCents < 0) {
  console.error('FATAL: CASH_OUT_COST_CENTS must be a non-negative integer');
  process.exit(2);
}

// ─── helpers ─────────────────────────────────────────────────────────────────

function fmt(cents) {
  return `R$ ${(cents / 100).toFixed(2)} (${cents} cents)`;
}

function fmtBps(bps) {
  return bps === 0 ? 'none' : `${bps} bps (${(bps / 100).toFixed(2)}%)`;
}

async function exec(client, sql, params = []) {
  if (dryRun) {
    const preview = sql.replace(/\s+/g, ' ').trim().slice(0, 120);
    console.log(`  [dry-run] ${preview}  params=${JSON.stringify(params)}`);
    return { rowCount: 0, rows: [] };
  }
  return client.query(sql, params);
}

// ─── steps ───────────────────────────────────────────────────────────────────

async function findOrCreateProviderAccount(client) {
  const found = await client.query(
    `SELECT id, status FROM provider_accounts
      WHERE provider_name = $1 AND alias = $2
      LIMIT 1`,
    [providerName, providerAlias]
  );

  if (found.rowCount && found.rows[0]) {
    const row = found.rows[0];
    console.log(
      `✓ provider_account   : reused  id=${row.id}  status=${row.status}  (${providerName}/${providerAlias})`
    );
    return row.id;
  }

  const result = await exec(
    client,
    `INSERT INTO provider_accounts (provider_name, alias, currency, status)
     VALUES ($1, $2, 'BRL', 'active')
     RETURNING id`,
    [providerName, providerAlias]
  );

  const id = dryRun ? '<dry-run-id>' : result.rows[0].id;
  console.log(
    `✓ provider_account   : created id=${id}  (${providerName}/${providerAlias})`
  );
  return id;
}

async function ensureAssignment(client, providerAccountId, operationType) {
  if (!clientId) return;

  const existing = await client.query(
    `SELECT id FROM client_provider_assignments
      WHERE client_id = $1
        AND operation_type = $2
        AND status = 'active'
        AND valid_from <= now()
        AND (valid_to IS NULL OR valid_to > now())
      LIMIT 1`,
    [clientId, operationType]
  );

  if (existing.rowCount) {
    console.log(`✓ assignment(${operationType.padEnd(8)}) : reused  id=${existing.rows[0].id}`);
    return;
  }

  const result = await exec(
    client,
    `INSERT INTO client_provider_assignments
      (client_id, operation_type, provider_name, provider_account_id, status, weight)
     VALUES ($1, $2, $3, $4, 'active', 100)
     RETURNING id`,
    [clientId, operationType, providerName, providerAccountId]
  );

  const id = dryRun ? '<dry-run-id>' : result.rows[0].id;
  console.log(`✓ assignment(${operationType.padEnd(8)}) : created id=${id}`);
}

async function ensureClientPricingAssignment(client, operationType) {
  if (!clientId) return;

  // Look up the active version of the named pricing plan
  const planVersion = await client.query(
    `SELECT ppv.id
       FROM pricing_plan_versions ppv
       JOIN pricing_plans p ON p.id = ppv.plan_id
      WHERE p.name = $1
        AND ppv.status = 'active'
        AND (ppv.valid_to IS NULL OR ppv.valid_to > now())
      ORDER BY ppv.valid_from DESC
      LIMIT 1`,
    [pricingPlanName]
  );

  if (!planVersion.rowCount || !planVersion.rows[0]) {
    console.warn(
      `  ⚠  pricing_plan(${operationType.padEnd(8)}) : plan "${pricingPlanName}" not found — run migrations first`
    );
    return;
  }

  const planVersionId = planVersion.rows[0].id;

  const existing = await client.query(
    `SELECT id FROM client_pricing_assignments
      WHERE client_id = $1
        AND operation_type = $2::operation_type
        AND status = 'active'
        AND valid_to IS NULL
      LIMIT 1`,
    [clientId, operationType]
  );

  if (existing.rowCount && existing.rows[0]) {
    console.log(
      `✓ pricing_assign(${operationType.padEnd(8)}) : reused  id=${existing.rows[0].id}  plan_version=${planVersionId}`
    );
    return;
  }

  const result = await exec(
    client,
    `INSERT INTO client_pricing_assignments
      (client_id, operation_type, pricing_plan_version_id, status)
     VALUES ($1, $2::operation_type, $3, 'active')
     RETURNING id`,
    [clientId, operationType, planVersionId]
  );

  const id = dryRun ? '<dry-run-id>' : result.rows[0]?.id;
  console.log(
    `✓ pricing_assign(${operationType.padEnd(8)}) : created id=${id}  plan="${pricingPlanName}"  version=${planVersionId}`
  );
}

async function upsertCostRule(client, providerAccountId, operationType, triggerEvent, fixedCostCents, variableBps) {
  const existing = await client.query(
    `SELECT id, fixed_cost_cents, variable_cost_bps
       FROM provider_cost_rules
      WHERE provider_account_id = $1
        AND operation_type = $2::operation_type
        AND trigger_event = $3
        AND status = 'active'
        AND valid_to IS NULL
      ORDER BY valid_from DESC
      LIMIT 1`,
    [providerAccountId, operationType, triggerEvent]
  );

  if (existing.rowCount && existing.rows[0]) {
    const row = existing.rows[0];
    const costsMatch =
      Number(row.fixed_cost_cents) === fixedCostCents &&
      Number(row.variable_cost_bps) === variableBps;

    if (costsMatch) {
      console.log(
        `✓ cost_rule(${operationType.padEnd(8)}) : unchanged  id=${row.id}  fixed=${fmt(fixedCostCents)}  variable=${fmtBps(variableBps)}`
      );
      return row.id;
    }

    // Expire the current rule and create a new version
    await exec(
      client,
      `UPDATE provider_cost_rules SET valid_to = now(), status = 'disabled' WHERE id = $1`,
      [row.id]
    );
    console.log(
      `  cost_rule(${operationType.padEnd(8)}) : expired   id=${row.id}  (costs changed)`
    );
  }

  const result = await exec(
    client,
    `INSERT INTO provider_cost_rules
      (provider_account_id, operation_type, trigger_event,
       fixed_cost_cents, variable_cost_bps,
       charged_from_provider_balance, rounding_mode, status)
     VALUES ($1, $2::operation_type, $3, $4, $5, $6, 'round_half_up', 'active')
     RETURNING id`,
    [providerAccountId, operationType, triggerEvent, fixedCostCents, variableBps, chargedFromProviderBalance]
  );

  const id = dryRun ? '<dry-run-id>' : result.rows[0].id;
  const action = existing.rowCount ? 'rotated ' : 'created ';
  console.log(
    `✓ cost_rule(${operationType.padEnd(8)}) : ${action} id=${id}  fixed=${fmt(fixedCostCents)}  variable=${fmtBps(variableBps)}`
  );
  return id;
}

// ─── main ────────────────────────────────────────────────────────────────────

async function main() {
  console.log('');
  console.log('CashYin — provision-provider');
  console.log('════════════════════════════════════════════════');
  console.log(`  provider         : ${providerName}`);
  console.log(`  alias            : ${providerAlias}`);
  console.log(`  client_id        : ${clientId ?? '(not set — skipping assignments)'}`);
  console.log(`  cash_in  cost    : ${fmt(cashInCostCents)}  + ${fmtBps(cashInVariableBps)}`);
  console.log(`  cash_out cost    : ${fmt(cashOutCostCents)}  + ${fmtBps(cashOutVariableBps)}`);
  console.log(`  charged_from_bal : ${chargedFromProviderBalance}`);
  console.log(`  pricing plan     : ${assignPricingPlan ? `"${pricingPlanName}" (will assign to client)` : '(skipped — set ASSIGN_PRICING_PLAN=true to enable)'}`);
  if (dryRun) console.log('  ⚠  DRY RUN — no writes will be made');
  console.log('────────────────────────────────────────────────');
  console.log('');

  const pg = new Client({ connectionString: databaseUrl, connectionTimeoutMillis: 30_000 });
  await pg.connect();

  try {
    await pg.query('BEGIN');

    const providerAccountId = await findOrCreateProviderAccount(pg);

    if (clientId) {
      await ensureAssignment(pg, providerAccountId, 'cash_in');
      await ensureAssignment(pg, providerAccountId, 'cash_out');
    }

    await upsertCostRule(pg, providerAccountId, 'cash_in',  cashInTriggerEvent,  cashInCostCents,  cashInVariableBps);
    await upsertCostRule(pg, providerAccountId, 'cash_out', cashOutTriggerEvent, cashOutCostCents, cashOutVariableBps);

    if (assignPricingPlan && clientId) {
      await ensureClientPricingAssignment(pg, 'cash_in');
      await ensureClientPricingAssignment(pg, 'cash_out');
    }

    if (!dryRun) {
      await pg.query('COMMIT');
    } else {
      await pg.query('ROLLBACK');
    }

    console.log('');
    console.log('════════════════════════════════════════════════');
    console.log(dryRun ? '  DRY RUN complete — no changes committed.' : '  Done.');
    console.log('════════════════════════════════════════════════');
    console.log('');
  } catch (err) {
    await pg.query('ROLLBACK').catch(() => undefined);
    throw err;
  } finally {
    await pg.end();
  }
}

main().catch((err) => {
  const message = err instanceof Error ? err.message : String(err);
  console.error(`\nFATAL: ${message}`);
  process.exit(1);
});
