#!/usr/bin/env node
/* eslint-disable no-console */
//
// scripts/provision-test-client.mjs
//
// Provisions the smallest set of rows needed for an end-to-end PIX
// test from Postman (or any HTTP client) against a deployed CashYin
// Core API:
//
//   1. clients               — the tenant row that owns the resources
//   2. provider_accounts     — Bents account the charges will route to
//   3. client_provider_assignments(cash_in, cash_out)  — active routing
//   4. client_webhook_endpoints — where the dispatcher delivers events
//   5. client_api_keys       — Bearer credential the API will require
//
// The script runs through `DATABASE_URL`. In ECS Fargate you'd run it
// via `aws ecs execute-command` from inside the API task (which already
// has the credentials, network, and image) or via a one-off ECS RunTask
// that overrides the container `command`.
//
// Behaviour: every step is idempotent. The script will:
//   * reuse an existing client/provider_account/assignment/endpoint
//   * mint a NEW api key every time (you can revoke old ones manually)
//
// The raw key is printed exactly once at the end. Re-running the
// script does NOT print the previous key — there is no way to recover
// it. Generate a new key + revoke the old one if you lose it.
//
// Usage:
//   DATABASE_URL=postgres://...                  \
//   TEST_CLIENT_LEGAL_NAME='CashYin Postman Test' \
//   TEST_WEBHOOK_TARGET_URL='https://webhook.site/<uuid>' \
//   node scripts/provision-test-client.mjs
//
// All `TEST_*` env vars are optional; sensible defaults are documented
// below.

import { createHash, randomBytes, randomUUID } from 'node:crypto';
import { Client } from 'pg';

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) {
  console.error('FATAL: DATABASE_URL is required');
  process.exit(2);
}

const legalName = process.env.TEST_CLIENT_LEGAL_NAME ?? 'CashYin Postman Test';
const tradeName = process.env.TEST_CLIENT_TRADE_NAME ?? 'postman-test';
const webhookTargetUrl =
  process.env.TEST_WEBHOOK_TARGET_URL ?? 'https://webhook.site/replace-me';
const apiKeyLabel = process.env.TEST_API_KEY_LABEL ?? 'Postman provisioning';
const providerName = process.env.TEST_PROVIDER_NAME ?? 'bents';
const providerAlias = process.env.TEST_PROVIDER_ALIAS ?? 'default';

const API_KEY_PREFIX = 'ck_';
const RAW_KEY_BYTES = 32;

// Default standard client capability set. Mirrors DEFAULT_CLIENT_API_SCOPES
// in src/shared/auth/auth-scopes.ts — keep in sync.
const DEFAULT_CLIENT_API_SCOPES = [
  'pix:cash_in:create',
  'pix:cash_in:read',
  'pix:cash_out:create',
  'pix:cash_out:read',
  'balance:read'
];

function mintRawApiKey() {
  const tail = randomBytes(RAW_KEY_BYTES).toString('hex');
  const raw = `${API_KEY_PREFIX}${tail}`;
  const prefix = tail.slice(0, 8);
  const hash = createHash('sha256').update(raw).digest('hex');
  return { raw, prefix, hash };
}

function mintWebhookSigningSecret() {
  return `whk_${randomBytes(32).toString('hex')}`;
}

async function findOrCreateClient(client) {
  const found = await client.query(
    `SELECT id FROM clients WHERE legal_name = $1 LIMIT 1`,
    [legalName]
  );
  if (found.rowCount && found.rows[0]) {
    console.log(`✓ client       : reused id=${found.rows[0].id}`);
    return found.rows[0].id;
  }
  const id = randomUUID();
  await client.query(
    `INSERT INTO clients (id, legal_name, trade_name, status)
     VALUES ($1, $2, $3, 'active')`,
    [id, legalName, tradeName]
  );
  console.log(`✓ client       : created id=${id}`);
  return id;
}

async function findOrCreateProviderAccount(client) {
  const found = await client.query(
    `SELECT id FROM provider_accounts
      WHERE provider_name = $1 AND alias = $2
      LIMIT 1`,
    [providerName, providerAlias]
  );
  if (found.rowCount && found.rows[0]) {
    console.log(
      `✓ providerAcct : reused id=${found.rows[0].id} (${providerName}/${providerAlias})`
    );
    return found.rows[0].id;
  }
  const result = await client.query(
    `INSERT INTO provider_accounts (provider_name, alias, currency, status)
     VALUES ($1, $2, 'BRL', 'active')
     RETURNING id`,
    [providerName, providerAlias]
  );
  console.log(
    `✓ providerAcct : created id=${result.rows[0].id} (${providerName}/${providerAlias})`
  );
  return result.rows[0].id;
}

async function ensureAssignment(client, clientId, operationType, providerAccountId) {
  const existing = await client.query(
    `SELECT id FROM client_provider_assignments
      WHERE client_id = $1
        AND operation_type = $2
        AND status = 'active'
        AND valid_from <= now()
        AND (valid_to IS NULL OR valid_to > now())
      LIMIT 1`,
    [clientId, operationType]
  );
  if (existing.rowCount) {
    console.log(`✓ assignment   : reused (${operationType})`);
    return;
  }
  await client.query(
    `INSERT INTO client_provider_assignments
      (client_id, operation_type, provider_name, provider_account_id, status, weight)
     VALUES ($1, $2, $3, $4, 'active', 100)`,
    [clientId, operationType, providerName, providerAccountId]
  );
  console.log(`✓ assignment   : created (${operationType})`);
}

async function ensureWebhookEndpoint(client, clientId) {
  const existing = await client.query(
    `SELECT id, target_url, signing_secret FROM client_webhook_endpoints
      WHERE client_id = $1 AND event_pattern = '*' LIMIT 1`,
    [clientId]
  );
  if (existing.rowCount && existing.rows[0]) {
    const row = existing.rows[0];
    if (row.target_url !== webhookTargetUrl) {
      await client.query(
        `UPDATE client_webhook_endpoints
            SET target_url = $1, updated_at = now()
          WHERE id = $2`,
        [webhookTargetUrl, row.id]
      );
      console.log(
        `✓ webhookEndpt : updated target_url (id=${row.id}) → ${webhookTargetUrl}`
      );
    } else {
      console.log(`✓ webhookEndpt : reused id=${row.id}`);
    }
    return { id: row.id, signingSecret: row.signing_secret };
  }
  const signingSecret = mintWebhookSigningSecret();
  const result = await client.query(
    `INSERT INTO client_webhook_endpoints
      (client_id, event_pattern, target_url, signing_secret, status, description)
     VALUES ($1, '*', $2, $3, 'active', 'Provisioned by provision-test-client.mjs')
     RETURNING id`,
    [clientId, webhookTargetUrl, signingSecret]
  );
  console.log(`✓ webhookEndpt : created id=${result.rows[0].id}`);
  return { id: result.rows[0].id, signingSecret };
}

async function mintApiKey(client, clientId) {
  const { raw, prefix, hash } = mintRawApiKey();
  // Per-key HMAC signing secret (API_HMAC_MODE). Returned once below.
  const signingSecret = randomBytes(RAW_KEY_BYTES).toString('hex');
  const result = await client.query(
    `INSERT INTO client_api_keys (client_id, key_prefix, key_hash, label, scopes, signing_secret)
     VALUES ($1, $2, $3, $4, $5::text[], $6)
     RETURNING id`,
    [clientId, prefix, hash, apiKeyLabel, DEFAULT_CLIENT_API_SCOPES, signingSecret]
  );
  console.log(`✓ apiKey       : created id=${result.rows[0].id} prefix=${prefix}`);
  return { id: result.rows[0].id, raw, prefix, signingSecret };
}

async function main() {
  const client = new Client({
    connectionString: databaseUrl,
    connectionTimeoutMillis: 30_000
  });
  await client.connect();

  try {
    await client.query('BEGIN');
    const clientId = await findOrCreateClient(client);
    const providerAccountId = await findOrCreateProviderAccount(client);
    await ensureAssignment(client, clientId, 'cash_in', providerAccountId);
    await ensureAssignment(client, clientId, 'cash_out', providerAccountId);
    const webhookEndpoint = await ensureWebhookEndpoint(client, clientId);
    const apiKey = await mintApiKey(client, clientId);
    await client.query('COMMIT');

    console.log('');
    console.log('================================================================');
    console.log('  CASHYIN TEST CLIENT — CREDENTIALS (SAVE NOW, SHOWN ONCE)');
    console.log('================================================================');
    console.log('');
    console.log(`  clientId            ${clientId}`);
    console.log(`  apiKey              ${apiKey.raw}`);
    console.log(`  apiKeyId            ${apiKey.id}`);
    console.log(`  apiKeyPrefix        ${apiKey.prefix}`);
    console.log(`  providerAccountId   ${providerAccountId}`);
    console.log(`  webhookEndpointId   ${webhookEndpoint.id}`);
    console.log(`  webhookTargetUrl    ${webhookTargetUrl}`);
    console.log(`  webhookSigningSec   ${webhookEndpoint.signingSecret}`);
    console.log('');
    console.log('  Bearer header for Postman:');
    console.log(`    Authorization: Bearer ${apiKey.raw}`);
    console.log('');
    console.log('================================================================');
  } catch (err) {
    await client.query('ROLLBACK').catch(() => undefined);
    throw err;
  } finally {
    await client.end();
  }
}

main().catch((err) => {
  const message = err instanceof Error ? err.message : String(err);
  console.error(`FATAL: ${message}`);
  process.exit(1);
});
