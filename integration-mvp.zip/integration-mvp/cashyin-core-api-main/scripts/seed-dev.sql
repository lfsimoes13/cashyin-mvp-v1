-- Optional development seed for the CashYin Core API.
--
-- The repository code requires:
--   * a `clients` row that owns the request (FK target for idempotency_keys,
--     pix_charges, cashouts, liquidity_reservations, and ledger entries)
--   * a `provider_accounts` row that backs the active assignment
--   * an active `client_provider_assignments` row for each supported
--     operation type (cash_in, cash_out)
--
-- This script seeds the smallest set that lets a developer exercise the
-- POST /v1/pix/charges and POST /v1/pix/payments routes against the local
-- Bents adapter. It is safe to run repeatedly: every statement is idempotent.
--
-- Usage:
--   psql "$DATABASE_URL" -f scripts/seed-dev.sql

INSERT INTO clients (id, legal_name, trade_name)
VALUES ('00000000-0000-0000-0000-000000000001', 'CashYin Demo Client', 'demo')
ON CONFLICT (id) DO NOTHING;

INSERT INTO provider_accounts (id, provider_name, alias, currency)
VALUES ('00000000-0000-0000-0000-0000000000a0', 'bents', 'default', 'BRL')
ON CONFLICT (provider_name, alias) DO NOTHING;

INSERT INTO client_provider_assignments
  (client_id, operation_type, provider_name, provider_account_id, status, weight)
SELECT
  '00000000-0000-0000-0000-000000000001',
  'cash_in',
  'bents',
  pa.id,
  'active',
  100
FROM provider_accounts pa
WHERE pa.provider_name = 'bents' AND pa.alias = 'default'
  AND NOT EXISTS (
    SELECT 1 FROM client_provider_assignments a
     WHERE a.client_id = '00000000-0000-0000-0000-000000000001'
       AND a.operation_type = 'cash_in'
       AND a.status = 'active'
  );

INSERT INTO client_provider_assignments
  (client_id, operation_type, provider_name, provider_account_id, status, weight)
SELECT
  '00000000-0000-0000-0000-000000000001',
  'cash_out',
  'bents',
  pa.id,
  'active',
  100
FROM provider_accounts pa
WHERE pa.provider_name = 'bents' AND pa.alias = 'default'
  AND NOT EXISTS (
    SELECT 1 FROM client_provider_assignments a
     WHERE a.client_id = '00000000-0000-0000-0000-000000000001'
       AND a.operation_type = 'cash_out'
       AND a.status = 'active'
  );

-- ──────────────────────────────────────────────────────────────────────────────
-- Provider cost rules — Bents
--
-- CashYin incurs R$ 0,10 (10 cents) per Pix transaction on both sides:
--   cash_in  → assessed when payment is confirmed (trigger: cash_in_paid)
--   cash_out → assessed when the cashout is created (trigger: cash_out_created)
--
-- charged_from_provider_balance = true  ⇒ Bents deducts their fee from
-- CashYin's Bents balance (settlement net). The PricingService uses this flag
-- to decide whether to pre-reserve liquidity or simply record the cost.
-- ──────────────────────────────────────────────────────────────────────────────

INSERT INTO provider_cost_rules
  (provider_account_id, operation_type, trigger_event,
   fixed_cost_cents, variable_cost_bps,
   charged_from_provider_balance, rounding_mode, status)
SELECT
  pa.id,
  'cash_in',
  'cash_in_paid',
  10,
  0,
  true,
  'round_half_up',
  'active'
FROM provider_accounts pa
WHERE pa.provider_name = 'bents' AND pa.alias = 'default'
  AND NOT EXISTS (
    SELECT 1 FROM provider_cost_rules pcr
     WHERE pcr.provider_account_id = pa.id
       AND pcr.operation_type = 'cash_in'
       AND pcr.trigger_event = 'cash_in_paid'
       AND pcr.status = 'active'
       AND pcr.valid_to IS NULL
  );

INSERT INTO provider_cost_rules
  (provider_account_id, operation_type, trigger_event,
   fixed_cost_cents, variable_cost_bps,
   charged_from_provider_balance, rounding_mode, status)
SELECT
  pa.id,
  'cash_out',
  'cash_out_created',
  10,
  0,
  true,
  'round_half_up',
  'active'
FROM provider_accounts pa
WHERE pa.provider_name = 'bents' AND pa.alias = 'default'
  AND NOT EXISTS (
    SELECT 1 FROM provider_cost_rules pcr
     WHERE pcr.provider_account_id = pa.id
       AND pcr.operation_type = 'cash_out'
       AND pcr.trigger_event = 'cash_out_created'
       AND pcr.status = 'active'
       AND pcr.valid_to IS NULL
  );

-- ──────────────────────────────────────────────────────────────────────────────
-- Standard client pricing plan
--
-- Seeds the pricing plan structure and assigns the demo client to it so that
-- PricingService.assess() returns a non-null assessment (fee_assessments are
-- written) on every transaction from day one.
--
-- Values match src/config/pricing.config.ts:
--   cash_in:  customer_fee_amount_cents = 15  billing_mode = deduct_from_settlement
--   cash_out: customer_fee_amount_cents = 15  billing_mode = add_to_debit
--
-- Fixed UUIDs (same as migration/0009_standard_pricing_plan.sql):
--   plan:         00000000-0000-0000-0010-000000000001
--   plan_version: 00000000-0000-0000-0011-000000000001
-- ──────────────────────────────────────────────────────────────────────────────

INSERT INTO pricing_plans (id, name, description, status)
VALUES (
  '00000000-0000-0000-0010-000000000001',
  'standard',
  'Standard CashYin Pix pricing — R$ 0,15 per transaction (cash-in and cash-out).',
  'active'
)
ON CONFLICT (name) DO NOTHING;

INSERT INTO pricing_plan_versions (id, plan_id, version, status, valid_from)
SELECT
  '00000000-0000-0000-0011-000000000001',
  p.id,
  1,
  'active',
  now()
FROM pricing_plans p
WHERE p.id = '00000000-0000-0000-0010-000000000001'
ON CONFLICT (plan_id, version) DO NOTHING;

-- Cash-in rule: 15 ¢ flat, fee deducted from the incoming Pix amount
-- net_amount_cents = gross_amount_cents - 15
INSERT INTO pricing_rules
  (pricing_plan_version_id, operation_type, trigger_event,
   fixed_fee_cents, variable_fee_bps,
   billing_mode, rounding_mode,
   allow_negative_margin)
SELECT
  '00000000-0000-0000-0011-000000000001',
  'cash_in',
  'cash_in_paid',
  15,
  0,
  'deduct_from_settlement',
  'round_half_up',
  false
WHERE NOT EXISTS (
  SELECT 1 FROM pricing_rules
   WHERE pricing_plan_version_id = '00000000-0000-0000-0011-000000000001'
     AND operation_type = 'cash_in'
     AND trigger_event = 'cash_in_paid'
);

-- Cash-out rule: 15 ¢ flat, fee added on top of the debit
-- totalDebitAmountCents = gross_amount_cents + 15
INSERT INTO pricing_rules
  (pricing_plan_version_id, operation_type, trigger_event,
   fixed_fee_cents, variable_fee_bps,
   billing_mode, rounding_mode,
   allow_negative_margin)
SELECT
  '00000000-0000-0000-0011-000000000001',
  'cash_out',
  'cash_out_created',
  15,
  0,
  'add_to_debit',
  'round_half_up',
  false
WHERE NOT EXISTS (
  SELECT 1 FROM pricing_rules
   WHERE pricing_plan_version_id = '00000000-0000-0000-0011-000000000001'
     AND operation_type = 'cash_out'
     AND trigger_event = 'cash_out_created'
);

-- Assign standard plan to the demo client for cash_in
INSERT INTO client_pricing_assignments
  (client_id, operation_type, pricing_plan_version_id, status)
SELECT
  '00000000-0000-0000-0000-000000000001',
  'cash_in',
  '00000000-0000-0000-0011-000000000001',
  'active'
WHERE NOT EXISTS (
  SELECT 1 FROM client_pricing_assignments
   WHERE client_id = '00000000-0000-0000-0000-000000000001'
     AND operation_type = 'cash_in'
     AND status = 'active'
     AND valid_to IS NULL
);

-- Assign standard plan to the demo client for cash_out
INSERT INTO client_pricing_assignments
  (client_id, operation_type, pricing_plan_version_id, status)
SELECT
  '00000000-0000-0000-0000-000000000001',
  'cash_out',
  '00000000-0000-0000-0011-000000000001',
  'active'
WHERE NOT EXISTS (
  SELECT 1 FROM client_pricing_assignments
   WHERE client_id = '00000000-0000-0000-0000-000000000001'
     AND operation_type = 'cash_out'
     AND status = 'active'
     AND valid_to IS NULL
);
