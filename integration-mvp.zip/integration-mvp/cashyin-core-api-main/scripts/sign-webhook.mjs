#!/usr/bin/env node
// scripts/sign-webhook.mjs
//
// Computes the `x-bents-signature` header value for a webhook payload so you
// can hit POST /internal/webhooks/bents from curl/HTTPie/Postman without
// having to drive HMAC by hand.
//
// Usage:
//   echo '{"event":"charge.paid"}' | node scripts/sign-webhook.mjs
//   node scripts/sign-webhook.mjs --file payload.json
//   node scripts/sign-webhook.mjs --file payload.json --curl
//   node scripts/sign-webhook.mjs --file payload.json --url http://localhost:3000/internal/webhooks/bents --curl
//
// Flags:
//   --file <path>     read the JSON body from a file instead of stdin
//   --secret <value>  override the secret (defaults to $BENTS_WEBHOOK_SECRET)
//   --url <value>     full webhook URL for --curl output (defaults to $WEBHOOK_URL or http://localhost:3000/internal/webhooks/bents)
//   --curl            print a ready-to-run curl command instead of just the header
//
// The signature is computed against the *exact bytes* you pass in. Do not
// re-serialise the payload between signing it and sending it: a single
// whitespace change will invalidate the HMAC.

import { createHmac } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { argv, stdin, stderr, stdout, env, exit } from 'node:process';

function parseArgs(args) {
  const out = { file: null, secret: null, url: null, curl: false };
  for (let i = 2; i < args.length; i += 1) {
    const flag = args[i];
    switch (flag) {
      case '--file':
        out.file = args[++i] ?? null;
        break;
      case '--secret':
        out.secret = args[++i] ?? null;
        break;
      case '--url':
        out.url = args[++i] ?? null;
        break;
      case '--curl':
        out.curl = true;
        break;
      case '-h':
      case '--help':
        stdout.write(
          'Usage: sign-webhook.mjs [--file payload.json] [--secret SECRET] [--url URL] [--curl]\n'
        );
        exit(0);
        break;
      default:
        stderr.write(`unknown flag: ${flag}\n`);
        exit(2);
    }
  }
  return out;
}

async function readStdin() {
  const chunks = [];
  for await (const chunk of stdin) chunks.push(chunk);
  return Buffer.concat(chunks);
}

async function loadBody(flags) {
  if (flags.file) {
    return readFile(flags.file);
  }
  if (stdin.isTTY) {
    stderr.write(
      'No --file given and stdin is a TTY. Pipe a payload in or pass --file <path>.\n'
    );
    exit(2);
  }
  return readStdin();
}

async function main() {
  const flags = parseArgs(argv);
  const secret = flags.secret ?? env.BENTS_WEBHOOK_SECRET;
  if (!secret) {
    stderr.write(
      'Missing webhook secret. Set $BENTS_WEBHOOK_SECRET or pass --secret <value>.\n'
    );
    exit(2);
  }

  const body = await loadBody(flags);
  if (body.length === 0) {
    stderr.write('Refusing to sign an empty body.\n');
    exit(2);
  }

  const signature = `sha256=${createHmac('sha256', secret).update(body).digest('hex')}`;

  if (!flags.curl) {
    stdout.write(`${signature}\n`);
    return;
  }

  const url =
    flags.url ?? env.WEBHOOK_URL ?? 'http://localhost:3000/internal/webhooks/bents';

  // Inline the body via --data-binary @- so the exact bytes match the signed payload.
  const inlineBody = body.toString('utf8').replace(/'/g, `'\\''`);
  stdout.write(
    `curl -sS -X POST '${url}' \\\n` +
      `  -H 'content-type: application/json' \\\n` +
      `  -H 'x-bents-signature: ${signature}' \\\n` +
      `  --data-binary '${inlineBody}'\n`
  );
}

main().catch((err) => {
  stderr.write(`sign-webhook failed: ${err instanceof Error ? err.message : String(err)}\n`);
  exit(1);
});
