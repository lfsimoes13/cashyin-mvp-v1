#!/usr/bin/env tsx
/**
 * CashYin × Fyhub E2E test suite entry point.
 *
 * Usage:
 *   node --env-file=.env.test.local scripts/e2e/fyhub/run.ts --scenario=<name>
 *   pnpm e2e:fyhub:<name>
 *   pnpm e2e:fyhub:all
 *
 * Scenarios:
 *   cashin           Create QR code (Bents) → pay via Fyhub → confirm paid
 *   cashout          Send CashYin cash-out → Fyhub PIX key
 *   webhook-latency  Full pipeline with local webhook receiver
 *   idempotency      Idempotency key contract validation
 *   failure-retry    Dispatcher retry after webhook 500 failures
 *   fees-balance     Balance snapshot + cash-out fee inspection
 *   all              Run all scenarios in sequence
 *
 * Real payments (default: DRY RUN):
 *   REAL_PAYMENT_TESTS_ENABLED=true \
 *   pnpm e2e:fyhub:cashin -- --execute-real-payment --amount-cents=100
 *
 * See scripts/e2e/fyhub/README.md for full documentation.
 */

import { loadConfig } from './config.js';
import { resolveAmountCents, hasFlag } from './scenario-runner.js';
import { runCashInScenario } from './scenarios/cashin-qrcode-paid-by-fyhub.js';
import { runCashOutScenario } from './scenarios/cashout-to-fyhub-pix-key.js';
import { runWebhookLatencyScenario } from './scenarios/webhook-latency.js';
import { runIdempotencyScenario } from './scenarios/idempotency.js';
import { runFailureRetryScenario } from './scenarios/failure-retry.js';
import { runFeesAndBalanceScenario } from './scenarios/fees-and-balance.js';
import type { ScenarioReport } from './types.js';

// ─── Parse CLI ────────────────────────────────────────────────────────────────

const args = process.argv.slice(2);
const scenarioArg = args.find((a) => a.startsWith('--scenario='))?.replace('--scenario=', '');
const scenario = scenarioArg ?? 'cashin';

const VALID_SCENARIOS = [
  'cashin',
  'cashout',
  'webhook-latency',
  'idempotency',
  'failure-retry',
  'fees-balance',
  'all',
] as const;

type ScenarioName = (typeof VALID_SCENARIOS)[number];

if (!VALID_SCENARIOS.includes(scenario as ScenarioName)) {
  console.error(`\nUnknown scenario: "${scenario}"`);
  console.error(`Valid: ${VALID_SCENARIOS.join(', ')}\n`);
  process.exit(2);
}

// ─── Load config ──────────────────────────────────────────────────────────────

let cfg;
try {
  // For idempotency and dry-run scenarios, the cert is optional
  const needsCert = !['idempotency'].includes(scenario);
  cfg = loadConfig(needsCert);
} catch (err) {
  console.error(`\nConfiguration error: ${err instanceof Error ? err.message : String(err)}`);
  console.error('See .env.test.example for required variables.\n');
  process.exit(2);
}

const amountCents = resolveAmountCents(cfg);

// ─── Dispatch ─────────────────────────────────────────────────────────────────

async function run(): Promise<void> {
  const reports: ScenarioReport[] = [];

  const scenarios: Array<{ name: ScenarioName; fn: () => Promise<ScenarioReport> }> = [
    { name: 'cashin',          fn: () => runCashInScenario(cfg, amountCents) },
    { name: 'cashout',         fn: () => runCashOutScenario(cfg, amountCents) },
    { name: 'webhook-latency', fn: () => runWebhookLatencyScenario(cfg, amountCents) },
    { name: 'idempotency',     fn: () => runIdempotencyScenario(cfg, amountCents) },
    { name: 'failure-retry',   fn: () => runFailureRetryScenario(cfg, amountCents) },
    { name: 'fees-balance',    fn: () => runFeesAndBalanceScenario(cfg, amountCents) },
  ];

  const toRun = scenario === 'all' ? scenarios : scenarios.filter((s) => s.name === scenario);

  for (const { name, fn } of toRun) {
    console.log(`\n${'─'.repeat(60)}`);
    console.log(`  Running scenario: ${name}`);
    console.log(`${'─'.repeat(60)}`);

    try {
      const report = await fn();
      reports.push(report);
    } catch (err) {
      console.error(`\n  FATAL in scenario ${name}: ${err instanceof Error ? err.message : String(err)}`);
      if (err instanceof Error) console.error(err.stack);
      process.exitCode = 1;
    }
  }

  // ── Summary for `all` ────────────────────────────────────────────────────

  if (scenario === 'all' && reports.length > 1) {
    const line = '═'.repeat(60);
    console.log(`\n${line}`);
    console.log('  SUITE SUMMARY');
    console.log(line);

    let failed = 0;
    for (const r of reports) {
      const icon = r.result === 'passed' ? '✓' : r.result === 'dry_run' ? '○' : '✗';
      console.log(`  ${icon} ${r.scenario.padEnd(25)} ${r.result}  (${r.durationMs}ms)`);
      if (r.result === 'failed') failed++;
    }

    console.log(`${line}\n`);
    if (failed > 0) process.exitCode = 1;
  }
}

run().catch((err) => {
  console.error(`\nFATAL: ${err instanceof Error ? err.message : String(err)}`);
  if (err instanceof Error) console.error(err.stack);
  process.exit(1);
});
