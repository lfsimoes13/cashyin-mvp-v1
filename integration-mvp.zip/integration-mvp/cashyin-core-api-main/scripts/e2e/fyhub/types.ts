/**
 * Shared types for the CashYin × Fyhub E2E test suite.
 * All monetary values are in BRL **cents** unless explicitly noted.
 */

// ─── Timing ──────────────────────────────────────────────────────────────────

/** ISO-8601 timestamp string */
export type ISOTimestamp = string;

export interface Timings {
  t0_charge_create_requested?: ISOTimestamp;
  t1_charge_create_response?: ISOTimestamp;
  t2_fyhub_payment_requested?: ISOTimestamp;
  t3_fyhub_payment_response?: ISOTimestamp;
  /** Timestamp from Bents/provider `paid_at` field in the charge response. */
  t4_bents_paid_at?: ISOTimestamp;
  /** Set when the CashYin status poll returns `paid` */
  t5_charge_marked_paid?: ISOTimestamp;
  /** Set when the local webhook receiver catches the outbound event */
  t7_client_webhook_received?: ISOTimestamp;

  createChargeMs?: number;
  fyhubPayMs?: number;
  pollToConfirmedMs?: number;
  webhookDeliveryMs?: number;
  totalMs?: number;

  /** Derived: ms from Fyhub payment accepted until CashYin status = paid */
  fyhubAcceptedToCashyinPaidMs?: number;
  /** Derived: ms from Bents paid_at until CashYin status = paid (provider propagation) */
  bentsPaidToCashyinPaidMs?: number;
  /** Derived: ms from CashYin paid until outbound webhook received */
  cashyinPaidToWebhookMs?: number;
  /** Derived: ms from the CashYin webhook `timestamp` field until the receiver recorded it */
  webhookTimestampToReceivedMs?: number;
  /** Total E2E including waiting for the outbound webhook. */
  totalWithWebhookMs?: number;
  /** Total E2E excluding the outbound-webhook wait. */
  totalWithoutWebhookWaitMs?: number;
}

// ─── CashYin API shapes ───────────────────────────────────────────────────────

/**
 * Shared Pix counterparty block (`receiver` on cash-out, `payer` on cash-in).
 * Always present with nullable children when the block is emitted; mirrors
 * `PublicPixCounterparty` in `src/modules/transactions/public-serialization.ts`.
 */
export interface PixCounterparty {
  name: string | null;
  document_number: string | null;
  bank_name: string | null;
  bank_ispb: string | null;
  branch: string | null;
  account: string | null;
  account_type: string | null;
}

/** Nested `pix` block on the cash-in response. */
export interface CashInPixBlock {
  /** EMV "copia e cola" payment string. */
  emv: string | null;
  /** Omitted when null. */
  expires_at?: string;
  /** Present once the charge settles. */
  e2e_id?: string;
}

export interface CashInCharge {
  txid: string;
  amount: number;           // BRL cents
  external_ref: string;
  pix: CashInPixBlock;
  status: 'pending' | 'paid' | 'expired' | 'cancelled' | 'failed' | 'refunded';
  /** Present (with nullable children) once a payer is observed. */
  payer?: PixCounterparty;
  description: string | null;
  /** Present once the charge settles. */
  paid_at?: string;
  created_at: string;
}

/** @deprecated Use {@link PixCounterparty}. Kept as an alias for older imports. */
export type CashInPayer = PixCounterparty;

/** Public Pix key types accepted/echoed by the cash-out contract. */
export type CashOutPixKeyType = 'CPF' | 'CNPJ' | 'EMAIL' | 'PHONE' | 'EVP';

/** @deprecated Use {@link PixCounterparty}. */
export type PublicCashOutReceiver = PixCounterparty;

/** Nested `pix` block on the cash-out response. */
export interface CashOutPixBlock {
  key: string;
  key_type: CashOutPixKeyType;
  /** Present once the transfer settles. */
  e2e_id?: string;
}

/**
 * Public, client-facing cash-out representation returned by
 * `POST /v1/pix/cash-out` and `GET /v1/pix/cash-out/:id` (snake_case, money
 * in integer cents). Mirrors `PublicCashOut` in
 * `src/modules/transactions/public-serialization.ts`: `pix`/`receiver` are
 * nested, `type` is gone, and null terminal timestamps are omitted.
 */
export interface PublicCashOutResponse {
  id: string;
  external_ref: string | null;
  status: 'processing' | 'completed' | 'failed' | 'returned';
  /** Pix amount in BRL cents. */
  amount: number;
  currency: 'BRL';
  pix: CashOutPixBlock;
  /** Canonical nested receiver block, always present (nullable children). */
  receiver: PixCounterparty;
  created_at: string;
  completed_at?: string;
  failed_at?: string;
  returned_at?: string;
  failure_reason?: string;
}

/**
 * New balance contract (May 2026 — branch fix/cash-in-paid-ledger-credit).
 * Breaking change from `{ clientId, availableCents, currency }`.
 *
 * Source of truth: `ledger_entries` aggregated on `client_liability` ledger account.
 * All monetary values are BRL **cents**.
 */
export interface PublicBalance {
  /** Net credit − debit on client_liability, in BRL cents. */
  available_balance: number;
  /** Sum of in-flight cash-out reservations (liquidity_reservations.status=reserved), cents. */
  blocked_balance: number;
  /** available_balance + blocked_balance, cents. */
  total_balance: number;
  currency: 'BRL';
  /** ISO-8601 of the latest balance-affecting event. */
  updated_at: string;
}

/**
 * Old balance contract (pre May 2026). Kept for contract-detection only.
 * @deprecated Use PublicBalance instead.
 */
export interface LegacyBalance {
  clientId: string;
  availableCents: number;
  currency: 'BRL';
}

/** Union returned by the raw balance endpoint — may be old or new. */
export type RawBalanceResponse = PublicBalance | LegacyBalance;

/** @deprecated kept only for existing non-financial code paths */
export interface ClientBalance {
  clientId: string;
  availableCents: number;
  currency: 'BRL';
}

// ─── Fyhub API shapes ─────────────────────────────────────────────────────────

export interface FyhubTokenResponse {
  accessToken: string;
  expiresAt: number;       // Unix timestamp (seconds)
  tokenType: string;
  scope: string;
  refreshExpiresIn?: number;
}

export interface FyhubQrcPaymentRequest {
  qrCode: string;          // PIX EMV string
  payment: { currency: 'BRL'; amount: number }; // BRL float, NOT cents
  description?: string;
  paymentFlow?: 'INSTANT' | 'APPROVAL_REQUIRED';
  expiration?: number;     // seconds, 1-10800
  creditorDocument?: string;
  priority?: 'HIGH' | 'NORM';
}

export interface FyhubDictPaymentRequest {
  pixKey: string;
  payment: { currency: 'BRL'; amount: number };
  description?: string;
  paymentFlow?: 'INSTANT' | 'APPROVAL_REQUIRED';
}

export interface FyhubPaymentResponse {
  endToEndId?: string;
  eventDate?: string;
  id?: number;
  payment?: { currency: string; amount: number };
  type?: string;
}

export interface FyhubBalance {
  eventDate: string;
  balanceAmount: {
    currency: string;
    available: number;
    blocked: number;
    overdraft: number;
  };
}

// ─── Financial settlement ──────────────────────────────────────────────────────

export type SettlementStatus = 'passed' | 'failed' | 'skipped_with_reason';

/**
 * Where the expected client fee used in settlement validation came from.
 *   - `ledger_inspection`  : exact fee read from fee_assessments via DATABASE_URL.
 *   - `configured_default` : the documented default cash-in client fee
 *                            (E2E_CASH_IN_CUSTOMER_FEE_AMOUNT), used when
 *                            the public API does not expose cash-in fees and no
 *                            DATABASE_URL was provided.
 */
export type ExpectedFeeSource = 'ledger_inspection' | 'configured_default';

export interface FinancialSettlement {
  /** Balance snapshot before charge was created (cents). */
  balance_before: PublicBalance | null;
  /** Balance snapshot after charge reached `paid` status (cents). */
  balance_after: PublicBalance | null;

  /** Charge gross amount in cents (= amountCents). */
  expected_gross_amount_cents: number;
  /**
   * Expected client fee in cents used to compute the net credit.
   * Always populated: either the exact fee (ledger inspection) or the
   * configured default cash-in client fee. See `expected_fee_source`.
   */
  expected_fee_amount_cents: number | null;
  /** Where `expected_fee_amount_cents` came from. */
  expected_fee_source: ExpectedFeeSource;
  /**
   * Expected net credit to client's available balance.
   * `= gross - expected_fee_amount_cents`.
   */
  expected_net_amount_cents: number;

  /** Actual available_balance delta (after − before). */
  available_balance_delta: number | null;
  /** Actual blocked_balance delta. */
  blocked_balance_delta: number | null;
  /** Actual total_balance delta. */
  total_balance_delta: number | null;

  /** Whether `available_balance_delta === expected_net_amount_cents`. */
  delta_matches_expected: boolean | null;

  /** Whether `balance_after.total = available + blocked`. */
  total_balance_invariant: boolean | null;

  /** Whether `updated_at` advanced after the payment. */
  updated_at_advanced: boolean | null;

  /** Whether the balance endpoint returned the new contract (snake_case). */
  contract_is_new: boolean | null;

  /** Overall validation result. */
  validation_result: SettlementStatus;
  /** Why the validation was skipped or failed. */
  validation_reason?: string;

  /** Notes on API gaps (fees, ledger) that could not be validated via REST. */
  gaps: string[];
}

// ─── Outbound webhook ─────────────────────────────────────────────────────────

export type WebhookReceiverMode = 'public' | 'local' | 'webhook_site' | 'disabled';

export interface WebhookPayloadAssertion {
  name: string;
  passed: boolean;
  detail?: string;
}

export interface OutboundWebhookValidation {
  /** Which receiver strategy was used. */
  mode: WebhookReceiverMode;
  /** Whether a delivery was actually observed. */
  received: boolean;
  /** Redacted public URL configured as the test client endpoint, if any. */
  configured_public_url: string | null;
  /** Local mock receiver URL, if used. */
  local_receiver_url: string | null;
  /** ISO timestamp recorded by the receiver. */
  received_at: string | null;
  /** Delivery latency (wait → first delivery), ms. */
  latency_ms: number | null;
  /** HTTP method of the delivery. */
  http_method: string | null;
  /** Redacted delivery headers (secrets/signatures masked). */
  headers_redacted: Record<string, string> | null;
  /** Assertions on the webhook payload (Part 6 contract). */
  payload_assertions: WebhookPayloadAssertion[];
  /** Reason the check was skipped, when applicable. */
  skipped_reason: string | null;
  /** True when delivery must be confirmed manually (e.g. webhook.site, no token). */
  manual_verification_required: boolean;
  /** Delivery attempt count, when queryable. */
  attempt_count: number | null;
  /** Last delivery error, when queryable. */
  last_error: string | null;
  /** Outbox event status, when queryable. */
  outbox_event_status: string | null;
}

// ─── Ledger inspection (test-only, DATABASE_URL gated) ─────────────────────────

/**
 * Internal financial truth for a paid cash-in, read directly from the DB when
 * the test runner is given a `DATABASE_URL`. This is a TEST-ONLY back-channel —
 * never a public API. Only redacted financial aggregates + counts are surfaced;
 * no provider ids, client_id, or raw ledger rows leak into the report.
 */
export interface LedgerInspection {
  /** Whether a DATABASE_URL was provided and the query ran. */
  available: boolean;
  /** Reason the inspection was skipped (no DATABASE_URL, query error, etc.). */
  skipped_reason: string | null;
  gross_amount_cents: number | null;
  fee_amount_cents: number | null;
  net_amount_cents: number | null;
  /** Net delta on the client_liability account for this charge. */
  client_liability_delta_cents: number | null;
  /** Number of ledger entries posted for this charge. */
  ledger_entry_count: number | null;
  /** Whether the cash_in_paid ledger idempotency key exists (single posting). */
  ledger_idempotency_key_present: boolean | null;
  fee_assessment_status: string | null;
}

// ─── Paid-pipeline timing (test-only, DATABASE_URL gated) ──────────────────────

/**
 * Server-side latency breakdown of the `cash_in.paid` pipeline, read directly
 * from the DB timestamps when the runner is given a `DATABASE_URL`. TEST-ONLY —
 * never a public API. Surfaces only durations and timestamps for the charge
 * under test; no provider ids, client_id, urls, or payloads are exposed.
 *
 * Stages (each derived from a pair of TIMESTAMPTZ columns):
 *   - webhook_processing_ms: webhook_events.received_at  → processed_at
 *   - outbox_dispatch_ms:    outbox_events.created_at     → published_at
 *   - delivery_ms:           client_webhook_deliveries.created_at → delivered_at
 *   - end_to_end_ms:         webhook_events.received_at   → delivery.delivered_at
 *
 * Part-1 latencies (all relative to outbox_events.created_at = outbox_created_at):
 *   - first_attempt_start_latency_ms: outbox_created_at → first_attempt_started_at
 *   - first_attempt_total_latency_ms: outbox_created_at → first_attempt_finished_at
 *   - success_latency_ms:             outbox_created_at → delivered_at
 *   - outbox_creation_latency_ms:     charge_paid_at    → outbox_created_at
 *       (DB-approximate; charge.paid_at is the provider business timestamp,
 *        not the persistence instant — the precise figure is the Prometheus
 *        cashyin_cash_in_paid_outbox_creation_latency_seconds histogram.)
 */
export interface PaidPipelineTiming {
  available: boolean;
  skipped_reason: string | null;
  webhook_received_at: ISOTimestamp | null;
  webhook_processed_at: ISOTimestamp | null;
  charge_paid_at: ISOTimestamp | null;
  outbox_created_at: ISOTimestamp | null;
  outbox_published_at: ISOTimestamp | null;
  delivery_created_at: ISOTimestamp | null;
  delivery_delivered_at: ISOTimestamp | null;
  delivery_first_attempt_started_at: ISOTimestamp | null;
  delivery_first_attempt_finished_at: ISOTimestamp | null;
  delivery_attempt_count: number | null;
  delivery_status: string | null;
  webhook_processing_ms: number | null;
  outbox_dispatch_ms: number | null;
  delivery_ms: number | null;
  end_to_end_ms: number | null;
  outbox_creation_latency_ms: number | null;
  first_attempt_start_latency_ms: number | null;
  first_attempt_total_latency_ms: number | null;
  success_latency_ms: number | null;
}

// ─── Metrics snapshot (optional, scraped from /internal/metrics) ───────────────

/** Summary of a single Prometheus histogram for the cash_in.paid path. */
export interface MetricHistogramSummary {
  metric: string;
  count: number;
  /** Average = sum / count, in seconds. */
  avg_seconds: number | null;
  /** Bucket-interpolated approximate percentiles, in seconds. */
  p50_seconds: number | null;
  p95_seconds: number | null;
  p99_seconds: number | null;
}

/**
 * Snapshot of the server-side Prometheus histograms covering the cash_in.paid
 * critical path, scraped from the deployed `/internal/metrics` endpoint at the
 * end of a run. Optional and best-effort — never fails the scenario.
 */
export interface MetricsSnapshot {
  available: boolean;
  skipped_reason: string | null;
  source_url: string | null;
  scraped_at: ISOTimestamp | null;
  histograms: MetricHistogramSummary[];
}

// ─── Scenario types ───────────────────────────────────────────────────────────

export type ScenarioResult = 'passed' | 'failed' | 'partial' | 'skipped' | 'dry_run';

export interface ScenarioReport {
  correlationId: string;
  scenario: string;
  result: ScenarioResult;
  startedAt: ISOTimestamp;
  finishedAt: ISOTimestamp;
  durationMs: number;
  dryRun: boolean;
  amountCents: number;
  timings: Timings;

  /** Public identifiers safe to surface */
  ids: {
    txid?: string;
    external_ref?: string;
    e2e_id?: string;
    cashout_id?: string;
    fyhub_payment_id?: number | string;
    fyhub_end_to_end_id?: string;
  };

  /** High-level assertions and their outcomes */
  assertions: Assertion[];

  /** Redacted request/response log */
  requests: RedactedRequest[];

  /** Human-readable messages */
  messages: string[];

  /** Latency measurements */
  latency?: LatencyReport;

  /** Financial settlement validation (cash-in scenario). */
  financial_settlement?: FinancialSettlement;

  /** Outbound webhook validation result. */
  outbound_webhook?: OutboundWebhookValidation;

  /** Internal ledger/fee truth (test-only, DATABASE_URL gated). */
  ledger_inspection?: LedgerInspection;

  /** Server-side cash_in.paid latency breakdown (test-only, DATABASE_URL gated). */
  paid_pipeline_timing?: PaidPipelineTiming;

  /** Prometheus metrics snapshot scraped at end of run (optional). */
  metrics_snapshot?: MetricsSnapshot;

  /** Failure info if result !== passed */
  error?: string;

  /** API gaps or missing features discovered */
  gaps?: string[];
}

export interface Assertion {
  name: string;
  passed: boolean;
  detail?: string;
}

export interface RedactedRequest {
  label: string;
  method: string;
  url: string;
  requestBodyRedacted?: unknown;
  responseStatus?: number;
  responseBodyRedacted?: unknown;
  latencyMs?: number;
  errorMessage?: string;
}

export interface LatencyReport {
  createChargeMs?: number;
  fyhubPayMs?: number;
  pollToConfirmedMs?: number;
  webhookDeliveryMs?: number;
  /** Fyhub accepted (202) → CashYin status=paid */
  fyhubAcceptedToCashyinPaidMs?: number;
  /** Bents provider paid_at → CashYin status=paid */
  bentsPaidToCashyinPaidMs?: number;
  /** CashYin paid → outbound client webhook received */
  cashyinPaidToWebhookMs?: number;
  /** CashYin webhook `timestamp` → receiver recorded the delivery */
  webhookTimestampToReceivedMs?: number;
  totalMs?: number;
  /** Total E2E including the outbound-webhook wait */
  totalWithWebhookMs?: number;
  /** Total E2E excluding the outbound-webhook wait */
  totalWithoutWebhookWaitMs?: number;
  pollAttempts?: number;
}
