/**
 * Log redaction utilities.
 *
 * Rules:
 * - Never print: client_secret, cert password, access/refresh tokens, cert content.
 * - Truncate auth headers to first 12 chars + "…".
 * - Redact known sensitive keys in arbitrary objects.
 * - Safe to call on any shape — returns a deep-cloned redacted copy.
 */

const REDACTED = '[REDACTED]';
const TOKEN_TRUNCATE = 12;

/** Sensitive key patterns — case-insensitive substring match. */
const SENSITIVE_KEYS = [
  'secret',
  'password',
  'passphrase',
  'token',
  'access_token',
  'accesstoken',
  'refresh_token',
  'refreshtoken',
  'authorization',
  'pfx',
  'cert',
  'certificate',
  'private_key',
  'privatekey',
  'pfxcontent',
  'client_secret',
  'clientsecret',
];

function isSensitiveKey(key: string): boolean {
  const lower = key.toLowerCase();
  return SENSITIVE_KEYS.some((s) => lower.includes(s));
}

function truncateToken(value: string): string {
  if (value.length <= TOKEN_TRUNCATE) return REDACTED;
  return `${value.slice(0, TOKEN_TRUNCATE)}…${REDACTED}`;
}

/**
 * Deep-clone an object, replacing sensitive fields with [REDACTED].
 * Handles circular references by stopping at depth 10.
 */
export function redactObject(obj: unknown, depth = 0): unknown {
  if (depth > 10) return REDACTED;
  if (obj === null || obj === undefined) return obj;
  if (typeof obj === 'string') return obj;
  if (typeof obj === 'number' || typeof obj === 'boolean') return obj;
  if (Buffer.isBuffer(obj)) return `[Buffer ${obj.length} bytes ${REDACTED}]`;
  if (Array.isArray(obj)) return obj.map((item) => redactObject(item, depth + 1));
  if (typeof obj === 'object') {
    const result: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(obj as Record<string, unknown>)) {
      if (isSensitiveKey(key)) {
        if (typeof value === 'string' && value.length > 0) {
          result[key] = truncateToken(value);
        } else {
          result[key] = REDACTED;
        }
      } else {
        result[key] = redactObject(value, depth + 1);
      }
    }
    return result;
  }
  return obj;
}

/** Redact an Authorization header value. */
export function redactAuthHeader(value: string | undefined): string {
  if (!value) return REDACTED;
  const [scheme, token] = value.split(' ', 2);
  if (!token) return REDACTED;
  return `${scheme} ${truncateToken(token)}`;
}

/** Redact request headers object, preserving non-sensitive ones. */
export function redactHeaders(headers: Record<string, string | undefined>): Record<string, string> {
  const result: Record<string, string> = {};
  for (const [key, value] of Object.entries(headers)) {
    const lower = key.toLowerCase();
    if (lower === 'authorization' || lower === 'x-api-key') {
      result[key] = redactAuthHeader(value);
    } else if (isSensitiveKey(key)) {
      result[key] = REDACTED;
    } else {
      result[key] = value ?? '';
    }
  }
  return result;
}

/** Stringify with redaction applied — safe to log. */
export function safeStringify(obj: unknown, indent = 2): string {
  return JSON.stringify(redactObject(obj), null, indent);
}
