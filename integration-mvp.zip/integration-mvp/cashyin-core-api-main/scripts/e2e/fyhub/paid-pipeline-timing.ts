/**
 * TEST-ONLY server-side latency inspector for the `cash_in.paid` pipeline.
 *
 * Mirrors {@link ./ledger-inspector.ts}: a read-only back-channel that runs
 * ONLY when the test runner is handed a `DATABASE_URL`. It never adds a public
 * API surface and never throws — on any failure it returns a skipped snapshot
 * so the scenario continues.
 *
 * Why this exists: the public poll loop can only observe latency at its own
 * granularity (TEST_POLL_INTERVAL_SECS), which masks the true internal timing.
 * Reading the DB timestamps gives the real per-stage breakdown for the charge
 * under test. For PRODUCTION (RDS is private and unreachable from a laptop) use
 * the Prometheus snapshot instead (see ./metrics-scraper.ts).
 *
 * Join model (verified against migrations/0001_initial_schema.sql):
 *   pix_charges.txid (public) → pix_charges.id / provider_name / provider_charge_id
 *   webhook_events: provider_name + provider_transaction_id = pix_charges.provider_charge_id,
 *                   normalized_status = 'paid'  (received_at → processed_at)
 *   outbox_events:  aggregate_id = pix_charges.id, event_type = 'pix_charge.paid'
 *                   (internal type; the public 'pix.cash_in.paid' is mapped only
 *                   at delivery time) — created_at → published_at
 *   client_webhook_deliveries: outbox_event_id = outbox_events.id
 *                   (created_at → delivered_at, attempt_count, status)
 *
 * Security: surfaces only timestamps + durations + delivery status/attempts for
 * the single charge under test. No provider ids, client_id, urls, or payloads.
 */

import type { PaidPipelineTiming } from './types.js';

export function skippedTiming(reason: string): PaidPipelineTiming {
  return {
    available: false,
    skipped_reason: reason,
    webhook_received_at: null,
    webhook_processed_at: null,
    charge_paid_at: null,
    outbox_created_at: null,
    outbox_published_at: null,
    delivery_created_at: null,
    delivery_delivered_at: null,
    delivery_first_attempt_started_at: null,
    delivery_first_attempt_finished_at: null,
    delivery_attempt_count: null,
    delivery_status: null,
    webhook_processing_ms: null,
    outbox_dispatch_ms: null,
    delivery_ms: null,
    end_to_end_ms: null,
    outbox_creation_latency_ms: null,
    first_attempt_start_latency_ms: null,
    first_attempt_total_latency_ms: null,
    success_latency_ms: null,
  };
}

interface ChargeRow {
  id: string;
  provider_name: string;
  provider_charge_id: string | null;
  paid_at: Date | null;
}

interface WebhookRow {
  received_at: Date | null;
  processed_at: Date | null;
}

interface OutboxRow {
  created_at: Date | null;
  published_at: Date | null;
}

interface DeliveryRow {
  created_at: Date | null;
  delivered_at: Date | null;
  first_attempt_started_at: Date | null;
  first_attempt_finished_at: Date | null;
  attempt_count: number | string | null;
  status: string | null;
}

/**
 * Inspects the server-side timing of a paid cash-in by public `txid`. Returns a
 * skipped snapshot (never throws) when `DATABASE_URL` is absent or any query
 * fails — the E2E continues and the report records the reason.
 */
export async function inspectPaidPipelineTiming(
  databaseUrl: string | undefined,
  txid: string
): Promise<PaidPipelineTiming> {
  if (!databaseUrl) {
    return skippedTiming(
      'DATABASE_URL not provided to the test runner — paid-pipeline timing skipped. ' +
        'For production use the Prometheus snapshot (RDS is private).'
    );
  }

  let Client: typeof import('pg').Client;
  try {
    ({ Client } = await import('pg'));
  } catch {
    return skippedTiming('`pg` package not available — paid-pipeline timing skipped.');
  }

  const client = new Client({ connectionString: databaseUrl, connectionTimeoutMillis: 15_000 });
  try {
    await client.connect();

    const chargeRes = await client.query<ChargeRow>(
      `SELECT id, provider_name::text AS provider_name, provider_charge_id, paid_at
         FROM pix_charges
        WHERE txid = $1
        LIMIT 1`,
      [txid]
    );
    const charge = chargeRes.rows[0];
    if (!charge) {
      return skippedTiming('No pix_charges row found for txid (internal lookup).');
    }

    // Inbound provider webhook that drove the paid transition. Prefer the
    // processed 'paid' event; fall back to the latest received row when the
    // normalized_status was not populated.
    let webhook: WebhookRow | undefined;
    if (charge.provider_charge_id) {
      const webhookRes = await client.query<WebhookRow>(
        `SELECT received_at, processed_at
           FROM webhook_events
          WHERE provider_name = $1::provider_name
            AND provider_transaction_id = $2
            AND (normalized_status = 'paid' OR normalized_status IS NULL)
          ORDER BY (normalized_status = 'paid') DESC, received_at DESC
          LIMIT 1`,
        [charge.provider_name, charge.provider_charge_id]
      );
      webhook = webhookRes.rows[0];
    }

    // event_type is the canonical public name 'pix.cash_in.paid' (migration
    // 0013 renamed the legacy internal 'pix_charge.paid'). Query both so the
    // inspector keeps working against a DB that predates the rename.
    const outboxRes = await client.query<OutboxRow & { id: string }>(
      `SELECT id, created_at, published_at
         FROM outbox_events
        WHERE aggregate_id = $1
          AND event_type IN ('pix.cash_in.paid', 'pix_charge.paid')
        ORDER BY created_at DESC
        LIMIT 1`,
      [charge.id]
    );
    const outbox = outboxRes.rows[0];

    let delivery: DeliveryRow | undefined;
    if (outbox) {
      const deliveryRes = await client.query<DeliveryRow>(
        `SELECT created_at, delivered_at, first_attempt_started_at,
                first_attempt_finished_at, attempt_count, status::text AS status
           FROM client_webhook_deliveries
          WHERE outbox_event_id = $1
          LIMIT 1`,
        [outbox.id]
      );
      delivery = deliveryRes.rows[0];
    }

    const webhookReceived = webhook?.received_at ?? null;
    const webhookProcessed = webhook?.processed_at ?? null;
    const outboxCreated = outbox?.created_at ?? null;
    const outboxPublished = outbox?.published_at ?? null;
    const deliveryCreated = delivery?.created_at ?? null;
    const deliveryDelivered = delivery?.delivered_at ?? null;
    const firstAttemptStarted = delivery?.first_attempt_started_at ?? null;
    const firstAttemptFinished = delivery?.first_attempt_finished_at ?? null;

    return {
      available: true,
      skipped_reason: null,
      webhook_received_at: toIso(webhookReceived),
      webhook_processed_at: toIso(webhookProcessed),
      charge_paid_at: toIso(charge.paid_at),
      outbox_created_at: toIso(outboxCreated),
      outbox_published_at: toIso(outboxPublished),
      delivery_created_at: toIso(deliveryCreated),
      delivery_delivered_at: toIso(deliveryDelivered),
      delivery_first_attempt_started_at: toIso(firstAttemptStarted),
      delivery_first_attempt_finished_at: toIso(firstAttemptFinished),
      delivery_attempt_count: delivery ? toIntOrNull(delivery.attempt_count) : null,
      delivery_status: delivery?.status ?? null,
      webhook_processing_ms: diffMs(webhookReceived, webhookProcessed),
      outbox_dispatch_ms: diffMs(outboxCreated, outboxPublished),
      delivery_ms: diffMs(deliveryCreated, deliveryDelivered),
      end_to_end_ms: diffMs(webhookReceived, deliveryDelivered),
      // Part-1 latencies relative to outbox_created_at.
      outbox_creation_latency_ms: diffMs(charge.paid_at, outboxCreated),
      first_attempt_start_latency_ms: diffMs(outboxCreated, firstAttemptStarted),
      first_attempt_total_latency_ms: diffMs(outboxCreated, firstAttemptFinished),
      success_latency_ms: diffMs(outboxCreated, deliveryDelivered),
    };
  } catch (err) {
    return skippedTiming(
      `Paid-pipeline timing query failed: ${err instanceof Error ? err.message : String(err)}`
    );
  } finally {
    await client.end().catch(() => undefined);
  }
}

function diffMs(start: Date | null, end: Date | null): number | null {
  if (!start || !end) return null;
  const ms = end.getTime() - start.getTime();
  return Number.isFinite(ms) ? Math.round(ms) : null;
}

function toIso(value: Date | null): string | null {
  return value ? value.toISOString() : null;
}

function toIntOrNull(value: number | string | null): number | null {
  if (value === null) return null;
  const n = typeof value === 'number' ? value : parseInt(value, 10);
  return Number.isNaN(n) ? null : n;
}
