/**
 * Certificate loader for Fyhub mTLS.
 *
 * Supports two sources:
 *   1. FYHUB_CERT_PATH    — direct path to an already-extracted PFX file.
 *   2. FYHUB_CERT_ZIP_PATH — ZIP bundle; the PFX is extracted at runtime
 *      to a temp directory (never to a versioned folder).
 *
 * The loaded PFX buffer and passphrase are kept in module-level memory
 * and are NEVER written to logs or files after loading.
 */

import { readFileSync, existsSync, mkdirSync, readdirSync } from 'node:fs';
import { execSync } from 'node:child_process';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { randomBytes } from 'node:crypto';

export interface CertBundle {
  /** Raw PFX/PKCS#12 bytes — never log or serialize. */
  pfx: Buffer;
  /** PFX passphrase — never log. */
  passphrase: string;
}

/**
 * Load PFX from a direct file path.
 * Throws if the file does not exist.
 */
export function loadCertFromPath(certPath: string, passphrase: string): CertBundle {
  if (!existsSync(certPath)) {
    throw new Error(`Certificate not found at: ${certPath}`);
  }
  const pfx = readFileSync(certPath);
  return { pfx, passphrase };
}

/**
 * Extract the first `.pfx` file from a ZIP archive into a unique temp
 * subdirectory (under `os.tmpdir()`, never inside the project tree) and
 * return the loaded bundle.
 *
 * Requires system `unzip` to be installed (available on macOS and most Linux).
 */
export function loadCertFromZip(
  zipPath: string,
  passphrase: string,
): { bundle: CertBundle; tempDir: string } {
  if (!existsSync(zipPath)) {
    throw new Error(`Certificate ZIP not found at: ${zipPath}`);
  }

  const tempDir = join(tmpdir(), `cashyin-e2e-cert-${randomBytes(8).toString('hex')}`);
  mkdirSync(tempDir, { recursive: true });

  try {
    // -q = quiet, -j = junk paths (extract flat), -d = destination
    execSync(`unzip -q -j "${zipPath}" "*.pfx" -d "${tempDir}"`, { stdio: 'pipe' });
  } catch (err) {
    throw new Error(
      `Failed to extract PFX from ZIP at ${zipPath}: ${err instanceof Error ? err.message : String(err)}`,
    );
  }

  const files = readdirSync(tempDir);
  const pfxFiles = files.filter((f) => f.toLowerCase().endsWith('.pfx'));

  if (pfxFiles.length === 0) {
    throw new Error(`No .pfx file found inside ZIP: ${zipPath}`);
  }

  const pfxPath = join(tempDir, pfxFiles[0] ?? '');
  const pfx = readFileSync(pfxPath);
  return { bundle: { pfx, passphrase }, tempDir };
}

/**
 * High-level loader: picks ZIP or direct-path source from config.
 * Preferred source: direct path when `certZipPath` is empty.
 */
export function loadCert(certPath: string, certZipPath: string, passphrase: string): CertBundle {
  if (certZipPath) {
    const { bundle } = loadCertFromZip(certZipPath, passphrase);
    return bundle;
  }
  return loadCertFromPath(certPath, passphrase);
}
