/**
 * Local mock webhook receiver for E2E latency testing.
 *
 * Starts a temporary HTTP server on a configurable port.
 * Receives and records inbound webhook deliveries from CashYin's
 * webhook dispatcher during E2E tests.
 *
 * NOT for production use. Intended only for local test runs.
 */

import { createServer, IncomingMessage, ServerResponse } from 'node:http';
import type { Server } from 'node:http';
import { createHmac } from 'node:crypto';

export interface WebhookEvent {
  receivedAt: string;
  method: string;
  path: string;
  headers: Record<string, string | string[] | undefined>;
  body: unknown;
  signatureValid: boolean | null;
}

export interface WebhookServerOptions {
  port: number;
  /** When set, verifies `x-cashyin-signature: sha256=<hmac>` */
  signingSecret?: string;
  /** Force all responses to this HTTP status (for failure-retry tests) */
  forceResponseStatus?: number;
}

export class LocalWebhookServer {
  private server: Server | null = null;
  private readonly events: WebhookEvent[] = [];
  private forceResponseStatus: number;

  constructor(private readonly opts: WebhookServerOptions) {
    this.forceResponseStatus = opts.forceResponseStatus ?? 200;
  }

  /** Start listening. Returns the localhost URL. */
  async start(): Promise<string> {
    return new Promise((resolve, reject) => {
      this.server = createServer((req, res) => this.handleRequest(req, res));
      this.server.on('error', reject);
      this.server.listen(this.opts.port, '127.0.0.1', () => {
        const url = `http://127.0.0.1:${this.opts.port}`;
        console.log(`  [webhook-server] listening on ${url}`);
        resolve(url);
      });
    });
  }

  /** Stop the server. */
  async stop(): Promise<void> {
    return new Promise((resolve, reject) => {
      if (!this.server) return resolve();
      this.server.close((err) => (err ? reject(err) : resolve()));
    });
  }

  /** All events received so far. */
  getEvents(): readonly WebhookEvent[] {
    return this.events;
  }

  /** Wait for at least `count` events or timeout. */
  async waitForEvents(
    count: number,
    timeoutMs: number,
  ): Promise<{ events: WebhookEvent[]; timedOut: boolean }> {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      if (this.events.length >= count) {
        return { events: [...this.events], timedOut: false };
      }
      await sleep(200);
    }
    return { events: [...this.events], timedOut: true };
  }

  /** Override response status for failure-retry scenario. */
  setResponseStatus(status: number): void {
    this.forceResponseStatus = status;
  }

  /** Clear recorded events. */
  clearEvents(): void {
    this.events.splice(0);
  }

  // ─── Request handler ───────────────────────────────────────────────────────

  private handleRequest(req: IncomingMessage, res: ServerResponse): void {
    const chunks: Buffer[] = [];

    req.on('data', (chunk: Buffer) => chunks.push(chunk));
    req.on('end', () => {
      const rawBody = Buffer.concat(chunks).toString('utf-8');

      let body: unknown = null;
      try {
        body = rawBody ? JSON.parse(rawBody) : null;
      } catch {
        body = rawBody;
      }

      const headers = req.headers as Record<string, string | string[] | undefined>;
      let signatureValid: boolean | null = null;

      if (this.opts.signingSecret) {
        const sig = typeof headers['x-cashyin-signature'] === 'string'
          ? headers['x-cashyin-signature']
          : '';
        signatureValid = verifySignature(rawBody, sig, this.opts.signingSecret);
      }

      const event: WebhookEvent = {
        receivedAt: new Date().toISOString(),
        method: req.method ?? 'POST',
        path: req.url ?? '/',
        headers,
        body,
        signatureValid,
      };

      this.events.push(event);

      const status = this.forceResponseStatus;
      res.writeHead(status, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ received: true, status }));
    });
  }
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function verifySignature(body: string, signatureHeader: string, secret: string): boolean {
  try {
    const expected = `sha256=${createHmac('sha256', secret).update(body).digest('hex')}`;
    return expected === signatureHeader;
  } catch {
    return false;
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
