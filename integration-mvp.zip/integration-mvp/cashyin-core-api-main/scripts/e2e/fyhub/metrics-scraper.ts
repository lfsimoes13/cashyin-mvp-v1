/**
 * Best-effort Prometheus scrape of the deployed `/internal/metrics` endpoint.
 *
 * This is the correct way to measure PRODUCTION cash_in.paid latency: the RDS
 * sits in private subnets and is unreachable from a developer laptop, so the
 * DB-timestamp inspector (./paid-pipeline-timing.ts) only works against
 * local/staging databases. The server, however, exposes per-stage histograms
 * over HTTP, which we can scrape with a bearer token.
 *
 * It is intentionally optional and never throws: any failure yields a skipped
 * snapshot so the scenario result is unaffected.
 *
 * Percentiles are bucket-interpolated approximations (same method as
 * Prometheus `histogram_quantile`). Series sharing a metric name but differing
 * in labels (e.g. event_type) are aggregated, so the numbers are coarse — good
 * enough to spot a regression, not a billing-grade measurement.
 */

import type { MetricHistogramSummary, MetricsSnapshot } from './types.js';

/** Histograms on the cash_in.paid critical path worth summarizing. */
const TARGET_HISTOGRAMS = [
  'cashyin_provider_webhook_claim_latency_seconds',
  'cashyin_provider_webhook_processing_duration_seconds',
  'cashyin_cashin_paid_processing_duration_seconds',
  'cashyin_client_webhook_delivery_duration_seconds',
] as const;

export function skippedSnapshot(reason: string): MetricsSnapshot {
  return {
    available: false,
    skipped_reason: reason,
    source_url: null,
    scraped_at: null,
    histograms: [],
  };
}

export async function scrapeMetrics(
  url: string | undefined,
  bearerToken: string | undefined,
  timeoutMs = 10_000
): Promise<MetricsSnapshot> {
  if (!url) {
    return skippedSnapshot('E2E_METRICS_URL not set — metrics snapshot skipped.');
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const headers: Record<string, string> = {};
    if (bearerToken) headers.authorization = `Bearer ${bearerToken}`;

    const res = await fetch(url, { headers, signal: controller.signal });
    if (!res.ok) {
      return skippedSnapshot(`Metrics endpoint returned HTTP ${res.status}.`);
    }
    const text = await res.text();
    const histograms = TARGET_HISTOGRAMS.map((name) => summarizeHistogram(name, text)).filter(
      (h): h is MetricHistogramSummary => h !== null
    );

    return {
      available: histograms.length > 0,
      skipped_reason:
        histograms.length > 0 ? null : 'No target histograms present in metrics output.',
      source_url: url,
      scraped_at: new Date().toISOString(),
      histograms,
    };
  } catch (err) {
    const reason =
      err instanceof Error && err.name === 'AbortError'
        ? `Metrics scrape timed out after ${timeoutMs}ms.`
        : `Metrics scrape failed: ${err instanceof Error ? err.message : String(err)}`;
    return skippedSnapshot(reason);
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Parses the `_bucket`/`_sum`/`_count` lines for one histogram name and
 * computes count, average, and bucket-interpolated p50/p95/p99. Aggregates
 * across all label sets of the metric. Returns null when the metric is absent.
 */
function summarizeHistogram(name: string, text: string): MetricHistogramSummary | null {
  const buckets = new Map<number, number>(); // le → cumulative count (summed across series)
  let count = 0;
  let sum = 0;
  let seen = false;

  for (const rawLine of text.split('\n')) {
    const line = rawLine.trim();
    if (!line || line.startsWith('#')) continue;
    if (!line.startsWith(name)) continue;

    const sumMatch = line.match(new RegExp(`^${escapeRe(name)}_sum(?:\\{[^}]*\\})?\\s+(\\S+)$`));
    if (sumMatch) {
      sum += toNum(sumMatch[1]);
      seen = true;
      continue;
    }
    const countMatch = line.match(new RegExp(`^${escapeRe(name)}_count(?:\\{[^}]*\\})?\\s+(\\S+)$`));
    if (countMatch) {
      count += toNum(countMatch[1]);
      seen = true;
      continue;
    }
    const bucketMatch = line.match(
      new RegExp(`^${escapeRe(name)}_bucket\\{([^}]*)\\}\\s+(\\S+)$`)
    );
    if (bucketMatch) {
      const le = parseLe(bucketMatch[1]);
      if (le === null) continue;
      buckets.set(le, (buckets.get(le) ?? 0) + toNum(bucketMatch[2]));
      seen = true;
    }
  }

  if (!seen) return null;

  return {
    metric: name,
    count,
    avg_seconds: count > 0 ? round(sum / count) : null,
    p50_seconds: quantile(buckets, count, 0.5),
    p95_seconds: quantile(buckets, count, 0.95),
    p99_seconds: quantile(buckets, count, 0.99),
  };
}

/**
 * Bucket-interpolated quantile, mirroring Prometheus `histogram_quantile`.
 * `buckets` maps each upper bound (`le`) to the cumulative count ≤ that bound.
 */
function quantile(buckets: Map<number, number>, total: number, q: number): number | null {
  if (total <= 0 || buckets.size === 0) return null;
  const sorted = [...buckets.entries()].sort((a, b) => a[0] - b[0]);
  const rank = q * total;

  let prevLe = 0;
  let prevCount = 0;
  for (const [le, cumCount] of sorted) {
    if (cumCount >= rank) {
      if (le === Infinity) return round(prevLe);
      const bucketCount = cumCount - prevCount;
      if (bucketCount <= 0) return round(le);
      const frac = (rank - prevCount) / bucketCount;
      return round(prevLe + (le - prevLe) * frac);
    }
    prevLe = le === Infinity ? prevLe : le;
    prevCount = cumCount;
  }
  return round(prevLe);
}

function parseLe(labels: string): number | null {
  const m = labels.match(/le="([^"]+)"/);
  if (!m) return null;
  if (m[1] === '+Inf') return Infinity;
  const n = Number(m[1]);
  return Number.isFinite(n) ? n : null;
}

function toNum(value: string | undefined): number {
  const n = Number(value);
  return Number.isFinite(n) ? n : 0;
}

function round(n: number): number {
  return Math.round(n * 1e6) / 1e6;
}

function escapeRe(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
