/**
 * Report generator for E2E scenario results.
 *
 * Generates:
 *   1. JSON machine-readable report (with public IDs only)
 *   2. Markdown human-readable report
 *
 * Output goes to `test-results/fyhub/<correlationId>/` which MUST be gitignored.
 * Internal IDs and raw payloads are only written to the gitignored local folder.
 */

import { mkdirSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';
import type {
  ScenarioReport,
  Assertion,
  RedactedRequest,
  LatencyReport,
  FinancialSettlement,
  OutboundWebhookValidation,
  LedgerInspection,
  PaidPipelineTiming,
  MetricsSnapshot,
} from './types.js';
import { settlementIcon } from './financial-settlement.js';

// ─── Save reports ─────────────────────────────────────────────────────────────

export function saveReport(report: ScenarioReport, outputDir: string): { jsonPath: string; mdPath: string } {
  const dir = resolve(join(outputDir, report.correlationId));
  mkdirSync(dir, { recursive: true });

  const jsonPath = join(dir, 'report.json');
  const mdPath = join(dir, 'report.md');

  writeFileSync(jsonPath, JSON.stringify(report, null, 2), 'utf-8');
  writeFileSync(mdPath, buildMarkdown(report), 'utf-8');

  return { jsonPath, mdPath };
}

// ─── Markdown builder ─────────────────────────────────────────────────────────

function resultEmoji(result: ScenarioReport['result']): string {
  switch (result) {
    case 'passed':  return '✅';
    case 'failed':  return '❌';
    case 'partial': return '⚠️';
    case 'dry_run': return '🔵';
    case 'skipped': return '⏭️';
  }
}

function assertionRow(a: Assertion): string {
  const icon = a.passed ? '✓' : '✗';
  const detail = a.detail ? ` — ${a.detail}` : '';
  return `| ${icon} | ${a.name}${detail} |`;
}

export function buildMarkdown(report: ScenarioReport): string {
  const lines: string[] = [];

  lines.push(`# E2E Report: ${report.scenario}`);
  lines.push('');
  lines.push(`**Result:** ${resultEmoji(report.result)} ${report.result.toUpperCase()}`);
  lines.push(`**Correlation ID:** \`${report.correlationId}\``);
  lines.push(`**Started:** ${report.startedAt}`);
  lines.push(`**Finished:** ${report.finishedAt}`);
  lines.push(`**Duration:** ${fmtMs(report.durationMs)}`);
  lines.push(`**Dry run:** ${report.dryRun ? 'Yes — no real payment was made' : 'No — real payment executed'}`);
  lines.push(`**Amount:** ${fmtCents(report.amountCents)}`);
  lines.push('');

  // Public IDs
  const ids = report.ids;
  if (Object.values(ids).some(Boolean)) {
    lines.push('## Public Identifiers');
    lines.push('');
    lines.push('| Field | Value |');
    lines.push('|-------|-------|');
    if (ids.txid)               lines.push(`| txid | \`${ids.txid}\` |`);
    if (ids.external_ref)       lines.push(`| external_ref | \`${ids.external_ref}\` |`);
    if (ids.e2e_id)              lines.push(`| e2e_id        | \`${ids.e2e_id}\` |`);
    if (ids.cashout_id)         lines.push(`| cashout_id | \`${ids.cashout_id}\` |`);
    if (ids.fyhub_payment_id)   lines.push(`| fyhub_payment_id | \`${ids.fyhub_payment_id}\` |`);
    if (ids.fyhub_end_to_end_id) lines.push(`| fyhub_end_to_end_id | \`${ids.fyhub_end_to_end_id}\` |`);
    lines.push('');
  }

  // Latency
  if (report.latency) {
    lines.push('## Latency');
    lines.push('');
    lines.push('| Metric | Value |');
    lines.push('|--------|-------|');
    const l = report.latency;
    if (l.createChargeMs !== undefined)             lines.push(`| Create charge (CashYin) | ${fmtMs(l.createChargeMs)} |`);
    if (l.fyhubPayMs !== undefined)                 lines.push(`| Pay QRC (Fyhub) | ${fmtMs(l.fyhubPayMs)} |`);
    if (l.pollToConfirmedMs !== undefined)          lines.push(`| Poll to confirmed (CashYin status=paid) | ${fmtMs(l.pollToConfirmedMs)} |`);
    if (l.fyhubAcceptedToCashyinPaidMs !== undefined) lines.push(`| Fyhub accepted → CashYin paid | ${fmtMs(l.fyhubAcceptedToCashyinPaidMs)} |`);
    if (l.bentsPaidToCashyinPaidMs !== undefined)   lines.push(`| Bents paid_at → CashYin paid | ${fmtMs(l.bentsPaidToCashyinPaidMs)} |`);
    if (l.webhookDeliveryMs !== undefined)          lines.push(`| Outbound webhook delivery | ${fmtMs(l.webhookDeliveryMs)} |`);
    if (l.cashyinPaidToWebhookMs !== undefined)     lines.push(`| CashYin paid → client webhook | ${fmtMs(l.cashyinPaidToWebhookMs)} |`);
    if (l.webhookTimestampToReceivedMs !== undefined) lines.push(`| CashYin webhook timestamp → receiver | ${fmtMs(l.webhookTimestampToReceivedMs)} |`);
    if (l.totalWithoutWebhookWaitMs !== undefined)  lines.push(`| Total E2E (no webhook wait) | ${fmtMs(l.totalWithoutWebhookWaitMs)} |`);
    if (l.totalWithWebhookMs !== undefined)         lines.push(`| **Total E2E (with webhook)** | **${fmtMs(l.totalWithWebhookMs)}** |`);
    else if (l.totalMs !== undefined)               lines.push(`| **Total E2E** | **${fmtMs(l.totalMs)}** |`);
    if (l.pollAttempts !== undefined)               lines.push(`| Poll attempts | ${l.pollAttempts} |`);
    lines.push('');
  }

  // Financial Settlement
  if (report.financial_settlement) {
    lines.push(...buildSettlementSection(report.financial_settlement));
  }

  // Outbound Webhook
  if (report.outbound_webhook) {
    lines.push(...buildOutboundWebhookSection(report.outbound_webhook));
  }

  // Internal ledger/fee inspection (test-only)
  if (report.ledger_inspection) {
    lines.push(...buildLedgerInspectionSection(report.ledger_inspection));
  }

  // Server-side paid-pipeline timing (test-only)
  if (report.paid_pipeline_timing) {
    lines.push(...buildPaidPipelineTimingSection(report.paid_pipeline_timing));
  }

  // Prometheus metrics snapshot (optional)
  if (report.metrics_snapshot) {
    lines.push(...buildMetricsSnapshotSection(report.metrics_snapshot));
  }

  // Assertions
  if (report.assertions.length > 0) {
    lines.push('## Assertions');
    lines.push('');
    lines.push('| Status | Check |');
    lines.push('|--------|-------|');
    for (const a of report.assertions) {
      lines.push(assertionRow(a));
    }
    lines.push('');
  }

  // Messages
  if (report.messages.length > 0) {
    lines.push('## Messages');
    lines.push('');
    for (const m of report.messages) {
      lines.push(`- ${m}`);
    }
    lines.push('');
  }

  // API Gaps
  if (report.gaps && report.gaps.length > 0) {
    lines.push('## API Gaps / Missing Features');
    lines.push('');
    for (const g of report.gaps) {
      lines.push(`- ⚠️ ${g}`);
    }
    lines.push('');
  }

  // Error
  if (report.error) {
    lines.push('## Error');
    lines.push('');
    lines.push('```');
    lines.push(report.error);
    lines.push('```');
    lines.push('');
  }

  // Redacted requests log
  if (report.requests.length > 0) {
    lines.push('## Request Log (redacted)');
    lines.push('');
    for (const req of report.requests) {
      lines.push(`### ${req.label}`);
      lines.push(`\`${req.method} ${req.url}\` → HTTP ${req.responseStatus ?? '?'} (${fmtMs(req.latencyMs ?? 0)})`);
      if (req.requestBodyRedacted !== undefined) {
        lines.push('');
        lines.push('**Request body (redacted):**');
        lines.push('```json');
        lines.push(JSON.stringify(req.requestBodyRedacted, null, 2));
        lines.push('```');
      }
      if (req.responseBodyRedacted !== undefined) {
        lines.push('');
        lines.push('**Response body (redacted):**');
        lines.push('```json');
        lines.push(JSON.stringify(req.responseBodyRedacted, null, 2));
        lines.push('```');
      }
      if (req.errorMessage) {
        lines.push('');
        lines.push(`**Error:** ${req.errorMessage}`);
      }
      lines.push('');
    }
  }

  lines.push('---');
  lines.push('*Generated by CashYin E2E test suite*');

  return lines.join('\n');
}

// ─── Print summary to console ────────────────────────────────────────────────

export function printSummary(report: ScenarioReport): void {
  const emoji = resultEmoji(report.result);
  const line = '═'.repeat(60);
  console.log(`\n${line}`);
  console.log(`  ${emoji} ${report.scenario.toUpperCase()} — ${report.result}`);
  console.log(`${line}`);
  console.log(`  correlation: ${report.correlationId}`);
  console.log(`  duration:    ${fmtMs(report.durationMs)}`);
  console.log(`  dry_run:     ${report.dryRun}`);
  if (report.ids.txid) console.log(`  txid:        ${report.ids.txid}`);
  if (report.ids.e2e_id) console.log(`  e2e_id:      ${report.ids.e2e_id}`);

  if (report.assertions.length) {
    console.log('');
    for (const a of report.assertions) {
      const icon = a.passed ? '  ✓' : '  ✗';
      const detail = a.detail ? ` (${a.detail})` : '';
      console.log(`${icon} ${a.name}${detail}`);
    }
  }

  if (report.latency) {
    console.log('');
    const l = report.latency;
    if (l.createChargeMs !== undefined)             console.log(`  create charge:       ${fmtMs(l.createChargeMs)}`);
    if (l.fyhubPayMs !== undefined)                 console.log(`  fyhub pay:           ${fmtMs(l.fyhubPayMs)}`);
    if (l.pollToConfirmedMs !== undefined)          console.log(`  to confirmed:        ${fmtMs(l.pollToConfirmedMs)}`);
    if (l.fyhubAcceptedToCashyinPaidMs !== undefined) console.log(`  fyhub→cashyin paid:  ${fmtMs(l.fyhubAcceptedToCashyinPaidMs)}`);
    if (l.bentsPaidToCashyinPaidMs !== undefined)   console.log(`  bents→cashyin paid:  ${fmtMs(l.bentsPaidToCashyinPaidMs)}`);
    if (l.cashyinPaidToWebhookMs !== undefined)     console.log(`  paid→webhook:        ${fmtMs(l.cashyinPaidToWebhookMs)}`);
    if (l.totalMs !== undefined)                    console.log(`  total E2E:           ${fmtMs(l.totalMs)}`);
  }

  if (report.financial_settlement) {
    const s = report.financial_settlement;
    console.log('');
    const icon = settlementIcon(s.validation_result);
    console.log(`  ${icon} financial settlement: ${s.validation_result}`);
    if (s.available_balance_delta !== null) {
      console.log(`    delta:    ${fmtCents(s.available_balance_delta)} (expected ${fmtCents(s.expected_net_amount_cents)})`);
    }
    if (s.validation_reason) console.log(`    reason:   ${s.validation_reason}`);
  }

  if (report.outbound_webhook) {
    const wh = report.outbound_webhook;
    console.log('');
    const status = wh.received
      ? `received (${fmtMs(wh.latency_ms ?? undefined)})`
      : wh.manual_verification_required
        ? 'manual verification required'
        : wh.skipped_reason
          ? 'skipped'
          : 'not received';
    const icon = wh.received ? '✅' : wh.manual_verification_required ? '🕵️' : '⏭️';
    console.log(`  ${icon} outbound webhook [${wh.mode}]: ${status}`);
    if (wh.skipped_reason) console.log(`     reason: ${wh.skipped_reason}`);
  }

  if (report.gaps?.length) {
    console.log('');
    console.log('  ⚠️  API Gaps:');
    for (const g of report.gaps) console.log(`     • ${g}`);
  }

  if (report.error) {
    console.log('');
    console.log(`  ✗ Error: ${report.error}`);
  }

  console.log('');
}

// ─── Financial Settlement section ────────────────────────────────────────────

function buildSettlementSection(s: FinancialSettlement): string[] {
  const icon = settlementIcon(s.validation_result);
  const lines: string[] = [];

  lines.push('## Financial Settlement');
  lines.push('');
  lines.push(`**Validation:** ${icon} ${s.validation_result.toUpperCase()}`);
  if (s.validation_reason) lines.push(`**Reason:** ${s.validation_reason}`);
  lines.push(`**Balance contract:** ${s.contract_is_new ? '✓ new (snake_case)' : '⚠️ legacy or unknown'}`);
  lines.push('');
  lines.push('| Field | Value |');
  lines.push('|-------|-------|');

  const b4 = s.balance_before;
  const b5 = s.balance_after;
  lines.push(`| balance_before.available | ${b4 !== null ? fmtCents(b4.available_balance) : '—'} |`);
  lines.push(`| balance_before.blocked | ${b4 !== null ? fmtCents(b4.blocked_balance) : '—'} |`);
  lines.push(`| balance_before.total | ${b4 !== null ? fmtCents(b4.total_balance) : '—'} |`);
  lines.push(`| balance_after.available | ${b5 !== null ? fmtCents(b5.available_balance) : '—'} |`);
  lines.push(`| balance_after.blocked | ${b5 !== null ? fmtCents(b5.blocked_balance) : '—'} |`);
  lines.push(`| balance_after.total | ${b5 !== null ? fmtCents(b5.total_balance) : '—'} |`);
  lines.push('| — | — |');
  lines.push(`| gross_amount | ${fmtCents(s.expected_gross_amount_cents)} |`);
  lines.push(
    `| customer_fee_amount | ${s.expected_fee_amount_cents !== null ? fmtCents(s.expected_fee_amount_cents) : '—'}` +
      ` (${feeSourceLabel(s.expected_fee_source)}) |`,
  );
  lines.push(`| expected_net_credit | ${fmtCents(s.expected_net_amount_cents)} |`);
  lines.push('| — | — |');
  lines.push(`| available_balance_delta | ${s.available_balance_delta !== null ? fmtCents(s.available_balance_delta) : '—'} |`);
  lines.push(`| blocked_balance_delta | ${s.blocked_balance_delta !== null ? fmtCents(s.blocked_balance_delta) : '—'} |`);
  lines.push(`| total_balance_delta | ${s.total_balance_delta !== null ? fmtCents(s.total_balance_delta) : '—'} |`);
  lines.push('| — | — |');
  lines.push(`| delta_matches_expected | ${s.delta_matches_expected === null ? '—' : s.delta_matches_expected ? '✓' : '✗'} |`);
  lines.push(`| total_balance_invariant | ${s.total_balance_invariant === null ? '—' : s.total_balance_invariant ? '✓' : '✗'} |`);
  lines.push(`| updated_at_advanced | ${s.updated_at_advanced === null ? '—' : s.updated_at_advanced ? '✓' : '✗'} |`);
  lines.push('');

  if (s.gaps.length > 0) {
    lines.push('### Settlement Gaps');
    lines.push('');
    for (const g of s.gaps) lines.push(`- ⚠️ ${g}`);
    lines.push('');
  }

  return lines;
}

// ─── Outbound Webhook section ─────────────────────────────────────────────────

function buildOutboundWebhookSection(wh: OutboundWebhookValidation): string[] {
  const lines: string[] = [];
  lines.push('## Outbound Webhook (Client Delivery)');
  lines.push('');
  lines.push(`**Mode:** \`${wh.mode}\``);
  lines.push(`**Received:** ${wh.received ? '✅ yes' : wh.manual_verification_required ? '🕵️ manual verification required' : wh.skipped_reason ? '⏭️ skipped' : '❌ no'}`);
  if (wh.configured_public_url) lines.push(`**Configured public URL:** \`${wh.configured_public_url}\``);
  if (wh.local_receiver_url) lines.push(`**Local receiver URL:** \`${wh.local_receiver_url}\``);
  if (wh.received_at) lines.push(`**Received at:** ${wh.received_at}`);
  if (wh.latency_ms !== null) lines.push(`**Delivery latency:** ${fmtMs(wh.latency_ms)}`);
  if (wh.http_method) lines.push(`**HTTP method:** ${wh.http_method}`);
  if (wh.skipped_reason) lines.push(`**Skipped reason:** ${wh.skipped_reason}`);
  if (wh.manual_verification_required) lines.push(`**Manual verification required:** yes`);
  if (wh.attempt_count !== null) lines.push(`**Attempt count:** ${wh.attempt_count}`);
  if (wh.last_error) lines.push(`**Last error:** ${wh.last_error}`);
  if (wh.outbox_event_status) lines.push(`**Outbox event status:** ${wh.outbox_event_status}`);
  lines.push('');

  if (wh.headers_redacted) {
    lines.push('**Headers (redacted):**');
    lines.push('```json');
    lines.push(JSON.stringify(wh.headers_redacted, null, 2));
    lines.push('```');
    lines.push('');
  }

  if (wh.payload_assertions.length > 0) {
    lines.push('| Status | Payload check |');
    lines.push('|--------|---------------|');
    for (const a of wh.payload_assertions) {
      const icon = a.passed ? '✓' : '✗';
      const detail = a.detail ? ` — ${a.detail}` : '';
      lines.push(`| ${icon} | ${a.name}${detail} |`);
    }
    lines.push('');
  }

  return lines;
}

// ─── Ledger Inspection section (test-only) ────────────────────────────────────

function buildLedgerInspectionSection(li: LedgerInspection): string[] {
  const lines: string[] = [];
  lines.push('## Internal Ledger / Fee Inspection (test-only)');
  lines.push('');
  if (!li.available) {
    lines.push(`**Status:** ⏭️ skipped — ${li.skipped_reason ?? 'unavailable'}`);
    lines.push('');
    return lines;
  }
  lines.push('**Status:** ✅ inspected via DATABASE_URL (no public API used)');
  lines.push('');
  lines.push('| Field | Value |');
  lines.push('|-------|-------|');
  lines.push(`| gross_amount | ${fmtCents(li.gross_amount_cents ?? 0)} |`);
  lines.push(`| fee_amount | ${li.fee_amount_cents !== null ? fmtCents(li.fee_amount_cents) : '—'} |`);
  lines.push(`| net_amount | ${li.net_amount_cents !== null ? fmtCents(li.net_amount_cents) : '—'} |`);
  lines.push(`| client_liability_delta | ${li.client_liability_delta_cents !== null ? fmtCents(li.client_liability_delta_cents) : '—'} |`);
  lines.push(`| ledger_entry_count | ${li.ledger_entry_count ?? '—'} |`);
  lines.push(`| ledger_idempotency_key_present | ${li.ledger_idempotency_key_present === null ? '—' : li.ledger_idempotency_key_present ? '✓' : '✗'} |`);
  lines.push(`| fee_assessment_status | ${li.fee_assessment_status ?? '—'} |`);
  lines.push('');
  return lines;
}

// ─── Paid-pipeline timing section (test-only) ─────────────────────────────────

function buildPaidPipelineTimingSection(t: PaidPipelineTiming): string[] {
  const lines: string[] = [];
  lines.push('## Paid Pipeline Latency (server-side, test-only)');
  lines.push('');
  if (!t.available) {
    lines.push(`**Status:** ⏭️ skipped — ${t.skipped_reason ?? 'unavailable'}`);
    lines.push('');
    return lines;
  }
  lines.push('**Status:** ✅ measured via DATABASE_URL timestamps (no public API used)');
  lines.push('');
  lines.push('| Stage | Latency |');
  lines.push('|-------|---------|');
  lines.push(`| Provider webhook processing (received → processed) | ${fmtMs(t.webhook_processing_ms ?? undefined)} |`);
  lines.push(`| Outbox dispatch (enqueued → published) | ${fmtMs(t.outbox_dispatch_ms ?? undefined)} |`);
  lines.push(`| Client delivery (created → delivered) | ${fmtMs(t.delivery_ms ?? undefined)} |`);
  lines.push(`| **End-to-end (webhook received → delivered)** | **${fmtMs(t.end_to_end_ms ?? undefined)}** |`);
  lines.push('');
  lines.push('### Part-1 latencies (relative to outbox_created_at)');
  lines.push('');
  lines.push('| Metric | Latency | Owner |');
  lines.push('|--------|---------|-------|');
  lines.push(`| Outbox creation (paid → outbox row, in-tx) | ${fmtMs(t.outbox_creation_latency_ms ?? undefined)} | CashYin |`);
  lines.push(`| **First-attempt start (outbox → POST start)** | **${fmtMs(t.first_attempt_start_latency_ms ?? undefined)}** | CashYin (100-200ms target) |`);
  lines.push(`| First-attempt total (outbox → first response) | ${fmtMs(t.first_attempt_total_latency_ms ?? undefined)} | + client response |`);
  lines.push(`| Success (outbox → delivered) | ${fmtMs(t.success_latency_ms ?? undefined)} | + client response/retries |`);
  lines.push('');
  lines.push(`**Delivery:** status=${t.delivery_status ?? '—'}, attempts=${t.delivery_attempt_count ?? '—'}`);
  lines.push('');
  return lines;
}

// ─── Metrics snapshot section (optional) ──────────────────────────────────────

function buildMetricsSnapshotSection(s: MetricsSnapshot): string[] {
  const lines: string[] = [];
  lines.push('## Server Metrics Snapshot (Prometheus)');
  lines.push('');
  if (!s.available) {
    lines.push(`**Status:** ⏭️ skipped — ${s.skipped_reason ?? 'unavailable'}`);
    lines.push('');
    return lines;
  }
  lines.push(`**Source:** \`${s.source_url}\` · scraped ${s.scraped_at}`);
  lines.push('');
  lines.push('_Bucket-interpolated approximations, aggregated across label sets._');
  lines.push('');
  lines.push('| Metric | count | avg | p50 | p95 | p99 |');
  lines.push('|--------|-------|-----|-----|-----|-----|');
  for (const h of s.histograms) {
    lines.push(
      `| \`${h.metric}\` | ${h.count} | ${fmtSeconds(h.avg_seconds)} | ${fmtSeconds(h.p50_seconds)} | ` +
        `${fmtSeconds(h.p95_seconds)} | ${fmtSeconds(h.p99_seconds)} |`
    );
  }
  lines.push('');
  return lines;
}

// ─── Utils ────────────────────────────────────────────────────────────────────

function fmtSeconds(seconds: number | null): string {
  if (seconds === null) return '—';
  const ms = seconds * 1000;
  if (ms < 1000) return `${ms.toFixed(1)}ms`;
  return `${seconds.toFixed(2)}s`;
}

function fmtMs(ms: number | undefined): string {
  if (ms === undefined || ms === null) return '—';
  if (ms < 1000) return `${ms}ms`;
  return `${(ms / 1000).toFixed(2)}s`;
}

function fmtCents(cents: number): string {
  return `R$ ${(cents / 100).toFixed(2)} (${cents}¢)`;
}

function feeSourceLabel(source: FinancialSettlement['expected_fee_source']): string {
  switch (source) {
    case 'ledger_inspection':
      return 'exact, from fee_assessments';
    case 'configured_default':
      return 'configured default — public API does not expose cash-in fees';
  }
}
