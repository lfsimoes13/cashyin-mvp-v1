/**
 * TEST-ONLY internal ledger/fee inspector for the E2E suite.
 *
 * Part 9 of the E2E review asks us to verify cash-in `fee_amount_cents`, the net
 * credit, and ledger idempotency — none of which are (intentionally) exposed via
 * the public API. Rather than add a public surface, this module reads the truth
 * directly from Postgres when (and only when) the test runner is handed a
 * `DATABASE_URL`. When no URL is provided the inspection is skipped with a reason.
 *
 * Security: this is a read-only back-channel for internal test environments. It
 * surfaces ONLY redacted financial aggregates + counts — never provider ids,
 * client_id, or raw ledger rows. Resolution joins are taken from the verified
 * schema:
 *   pix_charges.txid (public) → pix_charges.id
 *   fee_assessments.transaction_id = pix_charges.id (type='pix_charge', trigger='cash_in_paid')
 *   ledger_entries.transaction_id = pix_charges.id, joined to ledger_accounts
 *   ledger_idempotency_keys.key = 'cash_in_paid:' || pix_charges.id
 */

import type { LedgerInspection } from './types.js';

const CASH_IN_PAID_TRIGGER = 'cash_in_paid';

export function skippedInspection(reason: string): LedgerInspection {
  return {
    available: false,
    skipped_reason: reason,
    gross_amount_cents: null,
    fee_amount_cents: null,
    net_amount_cents: null,
    client_liability_delta_cents: null,
    ledger_entry_count: null,
    ledger_idempotency_key_present: null,
    fee_assessment_status: null
  };
}

/**
 * Inspects internal ledger/fee state for a paid cash-in by public `txid`.
 * Returns a skipped inspection (never throws) when `DATABASE_URL` is absent or
 * the query fails — the E2E continues and the report records the reason.
 */
export async function inspectCashInLedger(
  databaseUrl: string | undefined,
  txid: string
): Promise<LedgerInspection> {
  if (!databaseUrl) {
    return skippedInspection(
      'DATABASE_URL not provided to the test runner — internal ledger/fee inspection skipped.'
    );
  }

  // Lazy import so the suite has no hard dependency on `pg` unless used.
  let Client: typeof import('pg').Client;
  try {
    ({ Client } = await import('pg'));
  } catch {
    return skippedInspection('`pg` package not available — ledger inspection skipped.');
  }

  const client = new Client({ connectionString: databaseUrl, connectionTimeoutMillis: 15_000 });
  try {
    await client.connect();

    const chargeRes = await client.query<{ id: string; amount: string }>(
      `SELECT id, amount FROM pix_charges WHERE txid = $1 LIMIT 1`,
      [txid]
    );
    if (chargeRes.rowCount === 0 || !chargeRes.rows[0]) {
      return skippedInspection(`No pix_charges row found for txid (internal lookup).`);
    }
    const chargeId = chargeRes.rows[0].id;
    const grossAmountCents = toInt(chargeRes.rows[0].amount);

    const feeRes = await client.query<{ client_fee_cents: string; status: string }>(
      `SELECT client_fee_cents, status
         FROM fee_assessments
        WHERE transaction_type = 'pix_charge'
          AND transaction_id = $1
          AND trigger_event = $2
        LIMIT 1`,
      [chargeId, CASH_IN_PAID_TRIGGER]
    );
    const feeAmountCents = feeRes.rowCount ? toInt(feeRes.rows[0]!.client_fee_cents) : 0;
    const feeStatus = feeRes.rowCount ? feeRes.rows[0]!.status : null;

    const ledgerRes = await client.query<{
      entry_count: string;
      client_liability_delta: string | null;
    }>(
      `SELECT
         COUNT(*)::text AS entry_count,
         COALESCE(SUM(
           CASE WHEN la.account_type = 'client_liability'
                THEN (CASE WHEN le.direction = 'credit' THEN le.amount_cents ELSE -le.amount_cents END)
                ELSE 0 END
         ), 0)::text AS client_liability_delta
       FROM ledger_entries le
       JOIN ledger_accounts la ON la.id = le.account_id
      WHERE le.transaction_id = $1`,
      [chargeId]
    );
    const entryCount = ledgerRes.rowCount ? toInt(ledgerRes.rows[0]!.entry_count) : 0;
    const clientLiabilityDelta = ledgerRes.rowCount
      ? toInt(ledgerRes.rows[0]!.client_liability_delta)
      : 0;

    const idemRes = await client.query(
      `SELECT 1 FROM ledger_idempotency_keys WHERE key = $1 LIMIT 1`,
      [`${CASH_IN_PAID_TRIGGER}:${chargeId}`]
    );
    const idemPresent = (idemRes.rowCount ?? 0) > 0;

    return {
      available: true,
      skipped_reason: null,
      gross_amount_cents: grossAmountCents,
      fee_amount_cents: feeAmountCents,
      net_amount_cents: grossAmountCents - feeAmountCents,
      client_liability_delta_cents: clientLiabilityDelta,
      ledger_entry_count: entryCount,
      ledger_idempotency_key_present: idemPresent,
      fee_assessment_status: feeStatus
    };
  } catch (err) {
    return skippedInspection(
      `Ledger inspection query failed: ${err instanceof Error ? err.message : String(err)}`
    );
  } finally {
    await client.end().catch(() => undefined);
  }
}

function toInt(value: string | number | null): number {
  if (value === null) return 0;
  const n = typeof value === 'number' ? value : parseInt(value, 10);
  return Number.isNaN(n) ? 0 : n;
}
