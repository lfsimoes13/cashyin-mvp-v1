/**
 * CashYin API client for E2E tests.
 *
 * Registered routes:
 *   POST /v1/pix/cash-in/qrcode    → 201 CashInCharge (no Idempotency-Key; dedup by external_ref)
 *   GET  /v1/pix/cash-in/:txid     → CashInCharge
 *   POST /v1/pix/cash-out          → 201 Created (new resource) / 200 OK
 *                                    (idempotent replay), PublicCashOutResponse
 *                                    (with Idempotency-Key header). HTTP status
 *                                    reflects resource lifecycle, NOT payment
 *                                    finality — finality lives in body `status`.
 *   GET  /v1/pix/cash-out/:id      → PublicCashOutResponse
 *   GET  /v1/balance               → ClientBalance
 *   GET  /health                   → { service, status }
 *
 * Auth: Bearer `ck_<64 hex chars>` in Authorization header.
 * All amounts are in BRL **cents** on the CashYin side.
 */

import { randomBytes } from 'node:crypto';
import { fetch } from 'undici';
import { redactHeaders, redactObject } from './redact.js';
import type {
  CashInCharge,
  CashOutPixKeyType,
  ClientBalance,
  PublicBalance,
  PublicCashOutResponse,
  RawBalanceResponse,
  RedactedRequest,
} from './types.js';

// ─── Types ────────────────────────────────────────────────────────────────────

export interface CashyinClientOptions {
  baseUrl: string;
  apiKey: string;
  timeoutMs?: number;
  onRequest?: (r: RedactedRequest) => void;
}

// ─── Client ───────────────────────────────────────────────────────────────────

export class CashyinClient {
  private readonly baseUrl: string;
  private readonly apiKey: string;
  private readonly timeoutMs: number;
  private readonly onRequest?: (r: RedactedRequest) => void;

  constructor(opts: CashyinClientOptions) {
    this.baseUrl = opts.baseUrl.replace(/\/$/, '');
    this.apiKey = opts.apiKey;
    this.timeoutMs = opts.timeoutMs ?? 30_000;
    if (opts.onRequest !== undefined) this.onRequest = opts.onRequest;
  }

  // ─── Base request ──────────────────────────────────────────────────────────

  private async request<T>(
    method: 'GET' | 'POST',
    path: string,
    body?: unknown,
    extraHeaders?: Record<string, string>,
    label?: string,
  ): Promise<{ data: T; latencyMs: number; status: number }> {
    const url = `${this.baseUrl}${path}`;
    const t0 = performance.now();
    let responseStatus: number | undefined;
    let responseBody: unknown;

    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${this.apiKey}`,
      ...extraHeaders,
    };

    try {
      const res = await fetch(url, {
        method,
        headers,
        ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
        signal: AbortSignal.timeout(this.timeoutMs),
      });

      responseStatus = res.status;
      responseBody = await res.json().catch(() => ({}));
      const latencyMs = Math.round(performance.now() - t0);

      this.onRequest?.({
        label: label ?? `cashyin:${method} ${path}`,
        method,
        url,
        requestBodyRedacted: body ? redactObject(body) : undefined,
        responseStatus,
        responseBodyRedacted: redactObject(responseBody),
        latencyMs,
      });

      if (!res.ok) {
        throw new CashyinApiError(
          `CashYin ${method} ${path} failed: HTTP ${res.status}`,
          res.status,
          responseBody,
        );
      }

      return { data: responseBody as T, latencyMs, status: res.status };
    } catch (err) {
      if (err instanceof CashyinApiError) throw err;
      throw new CashyinApiError(
        `CashYin ${method} ${path}: ${err instanceof Error ? err.message : String(err)}`,
        responseStatus ?? 0,
        responseBody,
      );
    }
  }

  // ─── Cash-in ───────────────────────────────────────────────────────────────

  /**
   * POST /v1/pix/cash-in/qrcode
   *
   * Creates a new PIX charge (QR code) for cash-in via the Bents provider.
   * Returns 201 with the charge object including `pix.emv` (EMV string).
   *
   * Cash-in does NOT use the `Idempotency-Key` header. Retry-safety is the
   * `(client_id, external_ref)` business rule: repeating the same
   * `external_ref` returns the original charge.
   *
   * @param amountCents  Amount in BRL cents (e.g. 100 = R$ 1,00)
   * @param externalRef  Unique client-side reference (max 120 chars)
   */
  async createCashInCharge(
    amountCents: number,
    externalRef: string,
    description?: string,
  ): Promise<{ data: CashInCharge; latencyMs: number }> {
    const body: Record<string, unknown> = {
      amount: amountCents,
      external_ref: externalRef,
    };
    if (description) body.description = description;

    const { data, latencyMs } = await this.request<CashInCharge>(
      'POST',
      '/v1/pix/cash-in/qrcode',
      body,
      undefined,
      'cashyin:createCashIn',
    );

    return { data, latencyMs };
  }

  /**
   * GET /v1/pix/cash-in/:txid
   *
   * Fetches the current state of a charge by its CashYin txid.
   */
  async getCashInCharge(txid: string): Promise<{ data: CashInCharge; latencyMs: number }> {
    const { data, latencyMs } = await this.request<CashInCharge>(
      'GET',
      `/v1/pix/cash-in/${txid}`,
      undefined,
      undefined,
      'cashyin:getCashIn',
    );
    return { data, latencyMs };
  }

  /**
   * Poll `GET /v1/pix/cash-in/:txid` until status is terminal or timeout.
   *
   * Returns the final charge, number of poll attempts, and whether it timed out.
   */
  async pollCashInUntilTerminal(
    txid: string,
    opts?: { timeoutSecs?: number; intervalSecs?: number; onPoll?: (status: string, attempt: number) => void },
  ): Promise<{ data: CashInCharge; attempts: number; timedOut: boolean; pollMs: number }> {
    const timeout = (opts?.timeoutSecs ?? 120) * 1000;
    const interval = (opts?.intervalSecs ?? 3) * 1000;
    const deadline = Date.now() + timeout;
    const t0Poll = performance.now();
    let attempts = 0;
    let lastData: CashInCharge | undefined;

    while (Date.now() < deadline) {
      await sleep(interval);
      attempts++;
      const { data } = await this.getCashInCharge(txid);
      lastData = data;
      opts?.onPoll?.(data.status, attempts);

      const terminal = ['paid', 'expired', 'cancelled', 'failed', 'refunded'];
      if (terminal.includes(data.status)) {
        return { data, attempts, timedOut: false, pollMs: Math.round(performance.now() - t0Poll) };
      }
    }

    if (!lastData) {
      const { data } = await this.getCashInCharge(txid);
      lastData = data;
    }

    return {
      data: lastData,
      attempts,
      timedOut: true,
      pollMs: Math.round(performance.now() - t0Poll),
    };
  }

  // ─── Cash-out ──────────────────────────────────────────────────────────────

  /**
   * POST /v1/pix/cash-out
   *
   * Creates a cash-out to a PIX key via the configured provider. Sends the
   * PUBLIC nested request body the deployed contract requires:
   *   { amount, pix: { key, key_type }, receiver?: { ... }, external_ref, description }
   *
   * `pix.key_type` is REQUIRED by the API and is passed explicitly by the
   * caller (resolved from config) — never inferred here. The `Idempotency-Key`
   * header is mandatory for cash-out. Returns 201 for a new resource or 200 on
   * idempotent replay; both deserialize to {@link PublicCashOutResponse}.
   */
  async createCashOut(
    amountCents: number,
    pixKey: string,
    pixKeyType: CashOutPixKeyType,
    externalRef: string,
    idempotencyKey: string,
    description?: string,
  ): Promise<{ data: PublicCashOutResponse; latencyMs: number; status: number }> {
    const body: Record<string, unknown> = {
      amount: amountCents,
      pix: { key_type: pixKeyType, key: pixKey },
      external_ref: externalRef,
    };
    if (description) body.description = description;

    const { data, latencyMs, status } = await this.request<PublicCashOutResponse>(
      'POST',
      '/v1/pix/cash-out',
      body,
      { 'Idempotency-Key': idempotencyKey },
      'cashyin:createCashOut',
    );

    return { data, latencyMs, status };
  }

  /**
   * GET /v1/pix/cash-out/:id
   *
   * Fetches cash-out by internal UUID `id` (NOT txid — cash-outs use `id`).
   */
  async getCashOut(id: string): Promise<{ data: PublicCashOutResponse; latencyMs: number }> {
    const { data, latencyMs } = await this.request<PublicCashOutResponse>(
      'GET',
      `/v1/pix/cash-out/${id}`,
      undefined,
      undefined,
      'cashyin:getCashOut',
    );
    return { data, latencyMs };
  }

  /**
   * Poll cash-out until terminal status or timeout.
   */
  async pollCashOutUntilTerminal(
    id: string,
    opts?: { timeoutSecs?: number; intervalSecs?: number; onPoll?: (status: string, attempt: number) => void },
  ): Promise<{ data: PublicCashOutResponse; attempts: number; timedOut: boolean; pollMs: number }> {
    const timeout = (opts?.timeoutSecs ?? 120) * 1000;
    const interval = (opts?.intervalSecs ?? 3) * 1000;
    const deadline = Date.now() + timeout;
    const t0Poll = performance.now();
    let attempts = 0;
    let lastData: PublicCashOutResponse | undefined;

    while (Date.now() < deadline) {
      await sleep(interval);
      attempts++;
      const { data } = await this.getCashOut(id);
      lastData = data;
      opts?.onPoll?.(data.status, attempts);

      const terminal = ['completed', 'failed', 'returned'];
      if (terminal.includes(data.status)) {
        return { data, attempts, timedOut: false, pollMs: Math.round(performance.now() - t0Poll) };
      }
    }

    if (!lastData) {
      const { data } = await this.getCashOut(id);
      lastData = data;
    }

    return {
      data: lastData,
      attempts,
      timedOut: true,
      pollMs: Math.round(performance.now() - t0Poll),
    };
  }

  // ─── Balance ───────────────────────────────────────────────────────────────

  /**
   * GET /v1/balance
   *
   * Returns the raw balance response.
   * Detects old (`availableCents`) vs new (`available_balance`) contract.
   * Use `parsePublicBalance` to normalise and detect breaking changes.
   */
  async getBalance(): Promise<{
    data: RawBalanceResponse;
    parsed: PublicBalance | null;
    contractVersion: 'new' | 'legacy' | 'unknown';
    latencyMs: number;
  }> {
    const { data, latencyMs } = await this.request<RawBalanceResponse>(
      'GET',
      '/v1/balance',
      undefined,
      undefined,
      'cashyin:getBalance',
    );

    const { parsed, contractVersion } = parsePublicBalance(data);
    return { data, parsed, contractVersion, latencyMs };
  }

  // ─── Health ────────────────────────────────────────────────────────────────

  async health(): Promise<{ ok: boolean; latencyMs: number }> {
    try {
      const { data, latencyMs } = await this.request<{ service: string; status?: string }>(
        'GET',
        '/health',
        undefined,
        undefined,
        'cashyin:health',
      );
      return { ok: true, latencyMs };
    } catch {
      return { ok: false, latencyMs: 0 };
    }
  }
}

// ─── Error class ──────────────────────────────────────────────────────────────

export class CashyinApiError extends Error {
  constructor(
    message: string,
    public readonly httpStatus: number,
    public readonly body?: unknown,
  ) {
    super(message);
    this.name = 'CashyinApiError';
  }
}

// ─── Balance contract detection ───────────────────────────────────────────────

/**
 * Detect whether the balance response uses the new snake_case contract
 * (May 2026, fix/cash-in-paid-ledger-credit branch) or the legacy camelCase one.
 *
 * New:    { available_balance, blocked_balance, total_balance, currency, updated_at }
 * Legacy: { clientId, availableCents, currency }
 */
export function parsePublicBalance(raw: RawBalanceResponse): {
  parsed: PublicBalance | null;
  contractVersion: 'new' | 'legacy' | 'unknown';
} {
  if (raw === null || raw === undefined) {
    return { parsed: null, contractVersion: 'unknown' };
  }

  const obj = raw as unknown as Record<string, unknown>;

  // New contract detection
  if ('available_balance' in obj && 'blocked_balance' in obj && 'total_balance' in obj) {
    return {
      parsed: raw as PublicBalance,
      contractVersion: 'new',
    };
  }

  // Legacy contract detection
  if ('availableCents' in obj || 'clientId' in obj) {
    const legacy = raw as { availableCents?: number; currency: 'BRL' };
    // Convert to PublicBalance for uniform handling
    const available = legacy.availableCents ?? 0;
    return {
      parsed: {
        available_balance: available,
        blocked_balance: 0,
        total_balance: available,
        currency: 'BRL',
        updated_at: new Date(0).toISOString(),
      },
      contractVersion: 'legacy',
    };
  }

  return { parsed: null, contractVersion: 'unknown' };
}

// ─── ID generators ───────────────────────────────────────────────────────────

export function generateExternalRef(prefix: string): string {
  const ts = Date.now();
  const rnd = randomBytes(4).toString('hex');
  return `${prefix}-${ts}-${rnd}`.slice(0, 120);
}

export function generateIdempotencyKey(): string {
  return randomBytes(16).toString('hex');
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
