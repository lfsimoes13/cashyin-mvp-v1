/**
 * Environment config for the Fyhub E2E test suite.
 *
 * Loaded via `--env-file=.env.test.local` (Node 22+) or dotenv.
 * Never hardcodes credentials — all secrets come from env vars.
 */

import { readFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';
import type { CashOutPixKeyType, WebhookReceiverMode } from './types.js';

const CASH_OUT_PIX_KEY_TYPES: readonly CashOutPixKeyType[] = [
  'CPF',
  'CNPJ',
  'EMAIL',
  'PHONE',
  'EVP',
];

// ─── Safe dotenv loading (dev ergonomics, skipped in CI with --env-file) ─────

const dotenvPath = resolve(process.cwd(), '.env.test.local');
if (existsSync(dotenvPath)) {
  // Dynamic import of dotenv/config triggers its auto-load side-effect.
  // We silence the import error when dotenv is not installed (CI won't need it).
  try {
    const content = readFileSync(dotenvPath, 'utf-8');
    for (const line of content.split('\n')) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) continue;
      const eqIdx = trimmed.indexOf('=');
      if (eqIdx === -1) continue;
      const key = trimmed.slice(0, eqIdx).trim();
      const value = trimmed.slice(eqIdx + 1).trim().replace(/^["']|["']$/g, '');
      if (key && !(key in process.env)) {
        process.env[key] = value;
      }
    }
  } catch {
    // Silently skip — env vars may already be set
  }
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function requireEnv(key: string): string {
  const value = process.env[key];
  if (!value) {
    throw new Error(`Required env var ${key} is not set. See .env.test.example`);
  }
  return value;
}

function optionalEnv(key: string, fallback = ''): string {
  return process.env[key] ?? fallback;
}

function intEnv(key: string, fallback: number): number {
  const raw = process.env[key];
  if (!raw) return fallback;
  const n = parseInt(raw, 10);
  if (isNaN(n)) throw new Error(`Env var ${key} must be an integer, got: ${raw}`);
  return n;
}

/**
 * Parses a positive (possibly fractional) number env var. Used for the poll
 * interval so latency measurement runs can drop to sub-second granularity
 * (e.g. TEST_POLL_INTERVAL_SECS=0.5) instead of carrying ±3s of poll jitter.
 */
function floatEnv(key: string, fallback: number): number {
  const raw = process.env[key];
  if (!raw) return fallback;
  const n = Number(raw);
  if (!Number.isFinite(n) || n <= 0) {
    throw new Error(`Env var ${key} must be a positive number, got: ${raw}`);
  }
  return n;
}

function boolEnv(key: string, fallback: boolean): boolean {
  const raw = process.env[key];
  if (!raw) return fallback;
  return raw.trim().toLowerCase() === 'true';
}

// ─── Config shape ─────────────────────────────────────────────────────────────

export interface E2EConfig {
  fyhub: {
    baseUrl: string;
    clientId: string;
    clientSecret: string;
    /** Path to PFX file (preferred if already extracted from ZIP) */
    certPath: string;
    /** Path to the certificate ZIP bundle */
    certZipPath: string;
    /** PFX passphrase — redacted in all logs */
    certPassword: string;
    /** PIX key registered in Fyhub to receive payments */
    receiverPixKey: string;
    receiverName: string;
    receiverTaxId: string;
    timeoutMs: number;
  };
  cashyin: {
    baseUrl: string;
    apiKey: string;
    timeoutMs: number;
    /**
     * Pix key type sent on `POST /v1/pix/cash-out` (`pix_key_type`, required by
     * the public contract). Resolved from `CASHYIN_CASHOUT_PIX_KEY_TYPE`; left
     * `null` when unset so the cash-out scenario can fail early with a clear
     * message BEFORE issuing any request (never silently inferred).
     */
    cashOutPixKeyType: CashOutPixKeyType | null;
  };
  test: {
    defaultAmountCents: number;
    maxAmountCents: number;
    pollTimeoutSecs: number;
    pollIntervalSecs: number;
    webhookServerPort: number;
    /** Test-results output directory (must be gitignored) */
    outputDir: string;
  };
  /** Outbound-webhook receiver strategy (see webhook-receiver.ts). */
  webhook: {
    mode: WebhookReceiverMode;
    /** Public URL registered as the test client endpoint (tunnel/webhook.site). */
    publicUrl: string;
    /** Local mock receiver URL (default http://127.0.0.1:<port>). */
    localReceiverUrl: string;
    /** Optional webhook.site API token enabling automatic verification. */
    webhookSiteToken: string;
  };
  /**
   * Explicit expected pricing for the E2E suite. The public API never exposes
   * cash-in fees, so the suite must compute expected settlement from this
   * configuration instead of assuming a zero fee.
   *
   * All amounts are integer BRL cents. Current CashYin rule (standard test):
   *   cash-in : customer_fee=15, provider_cost=10 → margin=5, net_credit=85
   *   cash-out: customer_fee=15, provider_cost=10 → margin=5
   *
   * provider_cost and the derived margin are internal — never surfaced in
   * public responses or webhooks; the suite uses them only for internal
   * (DATABASE_URL / public cash-out fee) cross-checks.
   */
  pricing: {
    cashIn: {
      /** E2E_CASH_IN_CUSTOMER_FEE_AMOUNT — fee charged to the client (cents). */
      customerFeeAmount: number;
      /** E2E_BENTS_CASH_IN_PROVIDER_COST_AMOUNT — Bents cost to CashYin (cents). */
      providerCostAmount: number;
    };
    cashOut: {
      /** E2E_CASH_OUT_CUSTOMER_FEE_AMOUNT — fee charged to the client (cents). */
      customerFeeAmount: number;
      /** E2E_BENTS_CASH_OUT_PROVIDER_COST_AMOUNT — Bents cost to CashYin (cents). */
      providerCostAmount: number;
    };
  };
  /**
   * Optional Prometheus metrics scrape target. When set, the suite scrapes the
   * deployed `/internal/metrics` endpoint at the end of a run to capture the
   * server-side cash_in.paid latency histograms (the correct way to measure
   * production, where the RDS is private and unreachable for DB inspection).
   */
  metrics: {
    /** Full URL to the metrics endpoint, e.g. https://staging.api/internal/metrics. */
    url: string;
    /** Optional bearer token if METRICS_BEARER_TOKEN is set on the server. */
    bearerToken: string;
  };
  /** Whether real payment execution is permitted (env gate) */
  realPaymentEnabled: boolean;
  /**
   * Optional Postgres URL for TEST-ONLY internal ledger/fee inspection.
   * When absent, the inspection is skipped (no public API is ever added).
   */
  databaseUrl: string;
}

/**
 * Parses the optional cash-out Pix key type. Returns `null` when unset so the
 * cash-out scenario can fail early with an actionable message; a SET-but-invalid
 * value throws immediately (fail fast on misconfiguration).
 */
function parseCashOutPixKeyType(raw: string): CashOutPixKeyType | null {
  const v = raw.trim();
  if (!v) return null;
  const upper = v.toUpperCase() as CashOutPixKeyType;
  if (!CASH_OUT_PIX_KEY_TYPES.includes(upper)) {
    throw new Error(
      `CASHYIN_CASHOUT_PIX_KEY_TYPE must be one of ${CASH_OUT_PIX_KEY_TYPES.join('|')}, got: ${raw}`
    );
  }
  return upper;
}

function parseWebhookMode(raw: string): WebhookReceiverMode {
  const v = raw.trim().toLowerCase();
  if (v === 'public' || v === 'local' || v === 'webhook_site' || v === 'disabled') {
    return v;
  }
  throw new Error(
    `E2E_WEBHOOK_RECEIVER_MODE must be one of public|local|webhook_site|disabled, got: ${raw}`
  );
}

// ─── Load ─────────────────────────────────────────────────────────────────────

let _config: E2EConfig | null = null;

export function loadConfig(requireFyhubCert = true): E2EConfig {
  if (_config) return _config;

  const certPath = optionalEnv('FYHUB_CERT_PATH', './certs/FYHUB_59.pfx');
  const certZipPath = optionalEnv('FYHUB_CERT_ZIP_PATH', '');

  if (requireFyhubCert && !certZipPath && !existsSync(certPath)) {
    throw new Error(
      `No mTLS certificate found. Set FYHUB_CERT_PATH or FYHUB_CERT_ZIP_PATH. ` +
        `Checked: ${certPath}`,
    );
  }

  const defaultAmount = intEnv('TEST_DEFAULT_AMOUNT_CENTS', 100);
  const maxAmount = intEnv('TEST_MAX_AMOUNT_CENTS', 100);

  const webhookServerPort = intEnv('TEST_WEBHOOK_SERVER_PORT', 19876);
  const webhookMode = parseWebhookMode(optionalEnv('E2E_WEBHOOK_RECEIVER_MODE', 'local'));
  const webhookLocalUrl = optionalEnv(
    'E2E_WEBHOOK_RECEIVER_LOCAL_URL',
    `http://127.0.0.1:${webhookServerPort}`
  );

  if (defaultAmount > maxAmount) {
    throw new Error(
      `TEST_DEFAULT_AMOUNT_CENTS (${defaultAmount}) must be ≤ TEST_MAX_AMOUNT_CENTS (${maxAmount})`,
    );
  }

  _config = {
    fyhub: {
      baseUrl: optionalEnv('FYHUB_BASE_URL', 'https://pagamentos.fyhub.com.br/api/v2'),
      clientId: requireEnv('FYHUB_CLIENT_ID'),
      clientSecret: requireEnv('FYHUB_CLIENT_SECRET'),
      certPath,
      certZipPath,
      certPassword: requireEnv('FYHUB_CERT_PASSWORD'),
      receiverPixKey: requireEnv('FYHUB_RECEIVER_PIX_KEY'),
      receiverName: optionalEnv('FYHUB_RECEIVER_NAME', 'Pagamentoss global ltda'),
      receiverTaxId: optionalEnv('FYHUB_RECEIVER_TAX_ID', ''),
      timeoutMs: intEnv('FYHUB_HTTP_TIMEOUT_MS', 30_000),
    },
    cashyin: {
      baseUrl: requireEnv('CASHYIN_API_BASE_URL'),
      apiKey: requireEnv('CASHYIN_API_KEY'),
      timeoutMs: intEnv('CASHYIN_HTTP_TIMEOUT_MS', 30_000),
      cashOutPixKeyType: parseCashOutPixKeyType(optionalEnv('CASHYIN_CASHOUT_PIX_KEY_TYPE', '')),
    },
    test: {
      defaultAmountCents: defaultAmount,
      maxAmountCents: maxAmount,
      pollTimeoutSecs: intEnv('TEST_POLL_TIMEOUT_SECS', 120),
      pollIntervalSecs: floatEnv('TEST_POLL_INTERVAL_SECS', 3),
      webhookServerPort,
      outputDir: optionalEnv('TEST_OUTPUT_DIR', './test-results/fyhub'),
    },
    webhook: {
      mode: webhookMode,
      publicUrl: optionalEnv('E2E_WEBHOOK_PUBLIC_URL', ''),
      localReceiverUrl: webhookLocalUrl,
      webhookSiteToken: optionalEnv('E2E_WEBHOOK_SITE_TOKEN', ''),
    },
    pricing: {
      cashIn: {
        customerFeeAmount: intEnv('E2E_CASH_IN_CUSTOMER_FEE_AMOUNT', 15),
        providerCostAmount: intEnv('E2E_BENTS_CASH_IN_PROVIDER_COST_AMOUNT', 10),
      },
      cashOut: {
        customerFeeAmount: intEnv('E2E_CASH_OUT_CUSTOMER_FEE_AMOUNT', 15),
        providerCostAmount: intEnv('E2E_BENTS_CASH_OUT_PROVIDER_COST_AMOUNT', 10),
      },
    },
    metrics: {
      url: optionalEnv('E2E_METRICS_URL', ''),
      bearerToken: optionalEnv('E2E_METRICS_BEARER_TOKEN', ''),
    },
    realPaymentEnabled: boolEnv('REAL_PAYMENT_TESTS_ENABLED', false),
    databaseUrl: optionalEnv('DATABASE_URL', ''),
  };

  return _config;
}

/** Reset cached config (used in tests). */
export function resetConfig(): void {
  _config = null;
}
