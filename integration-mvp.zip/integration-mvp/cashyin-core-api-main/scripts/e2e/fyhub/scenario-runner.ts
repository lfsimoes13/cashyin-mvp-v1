/**
 * Scenario runner infrastructure.
 *
 * Provides:
 *   - Payment guards (max amount, real-payment flag)
 *   - Dry-run mode (all steps except real payment execution)
 *   - Correlation ID + timing
 *   - Report building helpers
 *   - Pre-run summary + explicit flag confirmation
 *
 * SECURITY RULES (enforced here, not in individual scenarios):
 *   1. Real payments require BOTH `REAL_PAYMENT_TESTS_ENABLED=true` AND
 *      the `--execute-real-payment` CLI flag.
 *   2. Amount is capped at TEST_MAX_AMOUNT_CENTS (default 100 = R$1,00).
 *   3. Tokens and secrets are never printed.
 *   4. Output goes to gitignored `test-results/fyhub/`.
 */

import { randomBytes } from 'node:crypto';
import { mkdirSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';
import type { E2EConfig } from './config.js';
import type {
  Assertion,
  FinancialSettlement,
  ISOTimestamp,
  LatencyReport,
  LedgerInspection,
  MetricsSnapshot,
  OutboundWebhookValidation,
  PaidPipelineTiming,
  RedactedRequest,
  ScenarioReport,
  ScenarioResult,
  Timings,
} from './types.js';
import { saveReport, printSummary } from './report.js';

// ─── CLI arg parsing ──────────────────────────────────────────────────────────

/** Read argv fresh each call so test suites can mutate process.argv freely. */
function getCliArgs(): string[] {
  return process.argv.slice(2);
}

export function hasFlag(flag: string): boolean {
  return getCliArgs().includes(flag);
}

export function argValue(flag: string): string | undefined {
  const entry = getCliArgs().find((a) => a.startsWith(`${flag}=`));
  return entry?.slice(flag.length + 1);
}

export const EXECUTE_REAL_PAYMENT_FLAG = '--execute-real-payment';

/** Parse `--amount-cents=N` from CLI args, falling back to config default. */
export function resolveAmountCents(cfg: E2EConfig): number {
  const fromCli = argValue('--amount-cents');
  const amount = fromCli ? parseInt(fromCli, 10) : cfg.test.defaultAmountCents;

  if (isNaN(amount) || amount <= 0) {
    throw new Error(`Invalid amount: ${fromCli}. Must be a positive integer (BRL cents).`);
  }

  return amount;
}

// ─── Guards ───────────────────────────────────────────────────────────────────

export class PaymentGuardError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'PaymentGuardError';
  }
}

/**
 * Gate for all real payment operations.
 *
 * Throws `PaymentGuardError` if any guard fails.
 * This must be called BEFORE any Fyhub payment API call.
 */
export function assertRealPaymentAllowed(cfg: E2EConfig, amountCents: number): void {
  if (!cfg.realPaymentEnabled) {
    throw new PaymentGuardError(
      'Real payments are disabled. Set REAL_PAYMENT_TESTS_ENABLED=true to enable.',
    );
  }

  if (!hasFlag(EXECUTE_REAL_PAYMENT_FLAG)) {
    throw new PaymentGuardError(
      `Real payment requires the ${EXECUTE_REAL_PAYMENT_FLAG} CLI flag.\n` +
        `Example: pnpm e2e:fyhub:cashin -- ${EXECUTE_REAL_PAYMENT_FLAG}`,
    );
  }

  assertAmountWithinLimit(cfg, amountCents);
}

/**
 * Verify amount does not exceed the configured maximum.
 * Also validates that the amount is a positive integer.
 */
export function assertAmountWithinLimit(cfg: E2EConfig, amountCents: number): void {
  if (!Number.isInteger(amountCents) || amountCents <= 0) {
    throw new PaymentGuardError(`Invalid amount ${amountCents}: must be a positive integer.`);
  }

  const max = cfg.test.maxAmountCents;
  if (amountCents > max) {
    throw new PaymentGuardError(
      `Amount ${amountCents} cents exceeds TEST_MAX_AMOUNT_CENTS=${max}. ` +
        `Increase TEST_MAX_AMOUNT_CENTS or pass a smaller amount.`,
    );
  }
}

// ─── Runner context ───────────────────────────────────────────────────────────

export interface ScenarioContext {
  correlationId: string;
  startedAt: ISOTimestamp;
  scenario: string;
  amountCents: number;
  dryRun: boolean;
  cfg: E2EConfig;
  timings: Timings;
  assertions: Assertion[];
  requests: RedactedRequest[];
  messages: string[];
  gaps: string[];
}

export function createContext(scenario: string, cfg: E2EConfig, amountCents: number): ScenarioContext {
  const isDryRun = !cfg.realPaymentEnabled || !hasFlag(EXECUTE_REAL_PAYMENT_FLAG);

  return {
    correlationId: randomBytes(8).toString('hex'),
    startedAt: new Date().toISOString(),
    scenario,
    amountCents,
    dryRun: isDryRun,
    cfg,
    timings: {},
    assertions: [],
    requests: [],
    messages: [],
    gaps: [],
  };
}

/** Record a request/response in the context (for the redacted log). */
export function recordRequest(ctx: ScenarioContext, req: RedactedRequest): void {
  ctx.requests.push(req);
}

/** Add an assertion result. */
export function assert(ctx: ScenarioContext, name: string, passed: boolean, detail?: string): boolean {
  const a: Assertion = { name, passed };
  if (detail !== undefined) a.detail = detail;
  ctx.assertions.push(a);
  return passed;
}

export function addMessage(ctx: ScenarioContext, msg: string): void {
  ctx.messages.push(msg);
}

export function addGap(ctx: ScenarioContext, gap: string): void {
  ctx.gaps.push(gap);
}

// ─── Report builder ───────────────────────────────────────────────────────────

export function buildReport(
  ctx: ScenarioContext,
  result: ScenarioResult,
  extras?: {
    ids?: ScenarioReport['ids'];
    latency?: LatencyReport;
    financialSettlement?: FinancialSettlement;
    outboundWebhook?: OutboundWebhookValidation;
    ledgerInspection?: LedgerInspection;
    paidPipelineTiming?: PaidPipelineTiming;
    metricsSnapshot?: MetricsSnapshot;
    error?: string;
  },
): ScenarioReport {
  const finishedAt = new Date().toISOString();
  const startMs = new Date(ctx.startedAt).getTime();
  const endMs = new Date(finishedAt).getTime();

  const report: ScenarioReport = {
    correlationId: ctx.correlationId,
    scenario: ctx.scenario,
    result,
    startedAt: ctx.startedAt,
    finishedAt,
    durationMs: endMs - startMs,
    dryRun: ctx.dryRun,
    amountCents: ctx.amountCents,
    timings: ctx.timings,
    ids: extras?.ids ?? {},
    assertions: ctx.assertions,
    requests: ctx.requests,
    messages: ctx.messages,
    gaps: ctx.gaps,
  };
  if (extras?.latency !== undefined) report.latency = extras.latency;
  if (extras?.financialSettlement !== undefined) report.financial_settlement = extras.financialSettlement;
  if (extras?.outboundWebhook !== undefined) report.outbound_webhook = extras.outboundWebhook;
  if (extras?.ledgerInspection !== undefined) report.ledger_inspection = extras.ledgerInspection;
  if (extras?.paidPipelineTiming !== undefined) report.paid_pipeline_timing = extras.paidPipelineTiming;
  if (extras?.metricsSnapshot !== undefined) report.metrics_snapshot = extras.metricsSnapshot;
  if (extras?.error !== undefined) report.error = extras.error;
  return report;
}

// ─── Pre-run summary ──────────────────────────────────────────────────────────

export function printPreRunSummary(ctx: ScenarioContext): void {
  const line = '─'.repeat(60);
  console.log('');
  console.log(`  CashYin × Fyhub E2E — ${ctx.scenario}`);
  console.log(line);
  console.log(`  correlation  : ${ctx.correlationId}`);
  console.log(`  mode         : ${ctx.dryRun ? 'DRY RUN (no real payment)' : 'REAL PAYMENT'}`);
  console.log(`  amount       : R$ ${(ctx.amountCents / 100).toFixed(2)} (${ctx.amountCents} cents)`);
  console.log(`  cashyin url  : ${ctx.cfg.cashyin.baseUrl}`);
  console.log(`  fyhub url    : ${ctx.cfg.fyhub.baseUrl}`);
  if (!ctx.dryRun) {
    console.log('');
    console.log('  ⚠️  WARNING: REAL PAYMENT WILL BE EXECUTED');
    console.log(`  ⚠️  Fyhub will transfer ${fmtBrl(ctx.amountCents)} via PIX`);
  }
  console.log(line);
  console.log('');
}

// ─── Final output ─────────────────────────────────────────────────────────────

export function finalizeAndSave(report: ScenarioReport, outputDir: string): void {
  const dir = resolve(outputDir);
  mkdirSync(dir, { recursive: true });

  const { jsonPath, mdPath } = saveReport(report, dir);
  printSummary(report);
  console.log(`  Report saved:`);
  console.log(`    JSON: ${jsonPath}`);
  console.log(`    MD:   ${mdPath}`);
  console.log('');
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function fmtBrl(cents: number): string {
  return `R$ ${(cents / 100).toFixed(2)}`;
}

export function now(): ISOTimestamp {
  return new Date().toISOString();
}

export function elapsedMs(since: ISOTimestamp): number {
  return Date.now() - new Date(since).getTime();
}
