/**
 * Outbound-webhook receiver resolution for the E2E suite.
 *
 * CashYin's webhook dispatcher delivers to the URL configured on the test
 * client's `client_webhook_endpoints.target_url`. When the API under test runs
 * remotely (ECS/staging/prod), it CANNOT reach a `127.0.0.1` mock on the test
 * runner's machine. This module decides, from env, how the E2E should observe
 * outbound webhooks and fails loudly on the classic misconfiguration (remote
 * API + local-only receiver).
 *
 * Modes (`E2E_WEBHOOK_RECEIVER_MODE`):
 *   - `local`       Local mock at E2E_WEBHOOK_RECEIVER_LOCAL_URL. Only valid
 *                   when the API is also local.
 *   - `public`      A tunnel (ngrok / Cloudflare Tunnel) forwards
 *                   E2E_WEBHOOK_PUBLIC_URL to the local mock, so deliveries are
 *                   still captured and auto-validated.
 *   - `webhook_site` Deliveries go to a public receiver we don't control
 *                   locally (e.g. webhook.site). Manual verification by default;
 *                   automatable when E2E_WEBHOOK_SITE_TOKEN is supplied.
 *   - `disabled`    Skip outbound-webhook observation entirely.
 *
 * No public URL is ever hardcoded — everything comes from env.
 */

import type {
  OutboundWebhookValidation,
  WebhookPayloadAssertion,
  WebhookReceiverMode
} from './types.js';

export const REMOTE_LOCAL_RECEIVER_ERROR =
  'Remote CashYin cannot deliver webhooks to local-only receiver. ' +
  'Configure E2E_WEBHOOK_PUBLIC_URL using webhook.site, ngrok, Cloudflare Tunnel or a public test receiver.';

export interface WebhookReceiverConfig {
  mode: WebhookReceiverMode;
  /** Public URL registered as the test client's endpoint (tunnel/webhook.site). */
  publicUrl: string;
  /** Local mock receiver URL (default http://127.0.0.1:19876). */
  localReceiverUrl: string;
  /** Optional webhook.site API token to enable automatic verification. */
  webhookSiteToken: string;
}

export interface WebhookReceiverPlan {
  mode: WebhookReceiverMode;
  /** Whether to boot the local mock HTTP server. */
  shouldStartLocalServer: boolean;
  /** Whether the harness should actively wait for and assert a delivery. */
  expectDelivery: boolean;
  /** True when delivery cannot be auto-observed and a human must confirm. */
  manualVerificationRequired: boolean;
  /** Redacted public URL for the report (never the full secret path). */
  configuredPublicUrlRedacted: string | null;
  /** Local receiver URL surfaced in the report. */
  localReceiverUrl: string | null;
  /** Reason the outbound-webhook check was skipped, when applicable. */
  skippedReason: string | null;
}

/** True when the host is not loopback/private — i.e. a real remote API. */
export function isRemoteApi(baseUrl: string): boolean {
  const host = safeHost(baseUrl);
  if (!host) return false;
  return !isLoopbackOrPrivateHost(host);
}

/** True when a target URL points at loopback, 0.0.0.0, or an RFC1918 IP. */
export function isLocalOnlyTarget(url: string): boolean {
  const host = safeHost(url);
  if (!host) return false;
  return isLoopbackOrPrivateHost(host);
}

/**
 * Redacts a URL for reporting: keeps scheme + host, masks the path/query so a
 * webhook.site UUID or signed tunnel token never lands in a committed report.
 */
export function redactUrl(url: string): string {
  try {
    const u = new URL(url);
    const path = u.pathname.replace(/\/+$/, '');
    if (path && path !== '') {
      const tail = path.slice(-4);
      return `${u.protocol}//${u.host}/****${tail}`;
    }
    return `${u.protocol}//${u.host}`;
  } catch {
    return '[unparseable-url-redacted]';
  }
}

/**
 * Resolves the receiver plan from env-derived config and the API base URL.
 * Throws on the unrecoverable misconfiguration (remote API + local-only
 * receiver) so the failure is explicit rather than a silent "no webhook".
 */
export function resolveWebhookReceiver(
  receiver: WebhookReceiverConfig,
  cashyinBaseUrl: string
): WebhookReceiverPlan {
  const remote = isRemoteApi(cashyinBaseUrl);
  const localUrl = receiver.localReceiverUrl;
  const publicUrl = receiver.publicUrl.trim();

  if (receiver.mode === 'disabled') {
    return basePlan('disabled', {
      shouldStartLocalServer: false,
      expectDelivery: false,
      manualVerificationRequired: false,
      configuredPublicUrlRedacted: null,
      localReceiverUrl: null,
      skippedReason: 'Outbound-webhook observation disabled (E2E_WEBHOOK_RECEIVER_MODE=disabled).'
    });
  }

  if (receiver.mode === 'local') {
    // A local mock is only reachable when the API is local too.
    if (remote) {
      throw new Error(REMOTE_LOCAL_RECEIVER_ERROR);
    }
    return basePlan('local', {
      shouldStartLocalServer: true,
      expectDelivery: true,
      manualVerificationRequired: false,
      configuredPublicUrlRedacted: null,
      localReceiverUrl: localUrl,
      skippedReason: null
    });
  }

  if (receiver.mode === 'public') {
    if (!publicUrl) {
      // Rule 1: remote API + empty public URL → skip with reason (not a generic failure).
      return basePlan('public', {
        shouldStartLocalServer: false,
        expectDelivery: false,
        manualVerificationRequired: false,
        configuredPublicUrlRedacted: null,
        localReceiverUrl: remote ? null : localUrl,
        skippedReason:
          'E2E_WEBHOOK_RECEIVER_MODE=public but E2E_WEBHOOK_PUBLIC_URL is empty. ' +
          'Set a public URL (ngrok / Cloudflare Tunnel) registered as the test client endpoint.'
      });
    }
    // Rule 2: a remote API cannot reach a local-only "public" URL.
    if (remote && isLocalOnlyTarget(publicUrl)) {
      throw new Error(REMOTE_LOCAL_RECEIVER_ERROR);
    }
    // Tunnel forwards the public URL to the local mock → still auto-observable.
    return basePlan('public', {
      shouldStartLocalServer: true,
      expectDelivery: true,
      manualVerificationRequired: false,
      configuredPublicUrlRedacted: redactUrl(publicUrl),
      localReceiverUrl: localUrl,
      skippedReason: null
    });
  }

  // mode === 'webhook_site'
  if (!publicUrl) {
    return basePlan('webhook_site', {
      shouldStartLocalServer: false,
      expectDelivery: false,
      manualVerificationRequired: true,
      configuredPublicUrlRedacted: null,
      localReceiverUrl: null,
      skippedReason:
        'E2E_WEBHOOK_RECEIVER_MODE=webhook_site but E2E_WEBHOOK_PUBLIC_URL is empty.'
    });
  }
  const hasToken = receiver.webhookSiteToken.trim().length > 0;
  return basePlan('webhook_site', {
    shouldStartLocalServer: false,
    // Automatic observation only when a token lets us poll webhook.site's API.
    expectDelivery: hasToken,
    manualVerificationRequired: !hasToken,
    configuredPublicUrlRedacted: redactUrl(publicUrl),
    localReceiverUrl: null,
    skippedReason: hasToken
      ? null
      : 'webhook.site delivery cannot be auto-observed without E2E_WEBHOOK_SITE_TOKEN; manual verification required.'
  });
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function basePlan(
  mode: WebhookReceiverMode,
  rest: Omit<WebhookReceiverPlan, 'mode'>
): WebhookReceiverPlan {
  return { mode, ...rest };
}

function safeHost(url: string): string | null {
  try {
    return new URL(url).hostname.toLowerCase();
  } catch {
    return null;
  }
}

function isLoopbackOrPrivateHost(host: string): boolean {
  if (host === 'localhost' || host === '0.0.0.0' || host === '::1' || host === '[::1]') {
    return true;
  }
  // IPv4 dotted-quad checks for RFC1918 + loopback + link-local.
  const m = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(host);
  if (!m) return false;
  const [a, b] = [Number(m[1]), Number(m[2])];
  if (a === 127) return true; // loopback
  if (a === 10) return true; // 10.0.0.0/8
  if (a === 192 && b === 168) return true; // 192.168.0.0/16
  if (a === 172 && b >= 16 && b <= 31) return true; // 172.16.0.0/12
  if (a === 169 && b === 254) return true; // 169.254.0.0/16 link-local
  return false;
}

// ─── Outbound payload assertions (Part 6) ──────────────────────────────────────

/**
 * Internal/provider fields that MUST NEVER appear anywhere in an outbound
 * client webhook — at any nesting depth. Matched case-insensitively.
 */
export const FORBIDDEN_WEBHOOK_KEYS = [
  'provider_tx_id',
  'provider_txid',
  'provider_charge_id',
  'provider_id',
  'client_id',
  'clientid',
  'signing_secret',
  'api_key',
  'apikey',
  'authorization',
  'access_token',
  'refresh_token',
  'secret',
  'password'
] as const;

export interface ExpectedCashInWebhook {
  txid: string;
  amountCents: number;
  externalRef: string;
}

/**
 * Validates an outbound cash-in webhook envelope against the Part 6 contract.
 *
 * The CashYin envelope nests the business payload under `data.*`:
 *   { id, event, schema_version, timestamp, data: { txid, type, amount, ... } }
 * so every business field is read from `data`, not the top level. (The previous
 * validator read top-level fields and silently passed empty checks — fixed here.)
 */
export function assertCashInWebhookPayload(
  body: unknown,
  expected: ExpectedCashInWebhook
): WebhookPayloadAssertion[] {
  const out: WebhookPayloadAssertion[] = [];
  const check = (name: string, passed: boolean, detail?: string) =>
    out.push(detail === undefined ? { name, passed } : { name, passed, detail });

  if (!body || typeof body !== 'object') {
    check('Webhook body is a JSON object', false, 'body is null or not an object');
    return out;
  }

  const envelope = body as Record<string, unknown>;
  const data = (envelope['data'] ?? null) as Record<string, unknown> | null;

  check('event = pix.cash_in.paid', envelope['event'] === 'pix.cash_in.paid', String(envelope['event'] ?? 'missing'));
  check('data object present', data !== null && typeof data === 'object', data ? 'yes' : 'missing');

  if (data && typeof data === 'object') {
    check('data.txid matches CashYin txid', data['txid'] === expected.txid, `${String(data['txid'])} === ${expected.txid}`);
    check('data has no type field', !('type' in data));
    check('data.amount matches', data['amount'] === expected.amountCents, `${String(data['amount'])} === ${expected.amountCents}`);
    check('data.external_ref matches', data['external_ref'] === expected.externalRef, String(data['external_ref'] ?? 'missing'));
    check('data.status = paid', data['status'] === 'paid', String(data['status'] ?? 'missing'));
    const pix = data['pix'] as Record<string, unknown> | null | undefined;
    check('data.pix object present', !!pix && typeof pix === 'object', pix ? 'yes' : 'missing');
    check(
      'data.pix.e2e_id present',
      !!pix && typeof pix['e2e_id'] === 'string' && (pix['e2e_id'] as string).length > 0,
      String(pix?.['e2e_id'] ?? 'missing'),
    );

    // payer.name only asserted when the provider emitted a payer block.
    const payer = data['payer'] as Record<string, unknown> | null | undefined;
    if (payer && typeof payer === 'object') {
      check('data.payer.name present', typeof payer['name'] === 'string' && (payer['name'] as string).length > 0, String(payer['name'] ?? 'null'));
    }
  }

  // Security: no internal/provider field may leak anywhere in the envelope.
  const leaked = findForbiddenKeys(body);
  check(
    'No internal/provider fields leaked',
    leaked.length === 0,
    leaked.length === 0 ? 'none' : `leaked: ${leaked.join(', ')}`
  );

  return out;
}

/** Deep-scans an arbitrary value for forbidden key names at any depth. */
export function findForbiddenKeys(value: unknown, depth = 0): string[] {
  if (depth > 12 || value === null || typeof value !== 'object') return [];
  const hits = new Set<string>();
  if (Array.isArray(value)) {
    for (const item of value) for (const k of findForbiddenKeys(item, depth + 1)) hits.add(k);
    return [...hits];
  }
  for (const [key, child] of Object.entries(value as Record<string, unknown>)) {
    const lower = key.toLowerCase();
    if (FORBIDDEN_WEBHOOK_KEYS.some((f) => lower === f || lower.includes(f))) {
      hits.add(key);
    }
    for (const k of findForbiddenKeys(child, depth + 1)) hits.add(k);
  }
  return [...hits];
}

/**
 * Seeds an {@link OutboundWebhookValidation} from a resolved receiver plan.
 * The harness then overlays delivery facts (received/latency/assertions).
 */
export function initialOutboundValidation(plan: WebhookReceiverPlan): OutboundWebhookValidation {
  return {
    mode: plan.mode,
    received: false,
    configured_public_url: plan.configuredPublicUrlRedacted,
    local_receiver_url: plan.localReceiverUrl,
    received_at: null,
    latency_ms: null,
    http_method: null,
    headers_redacted: null,
    payload_assertions: [],
    skipped_reason: plan.skippedReason,
    manual_verification_required: plan.manualVerificationRequired,
    attempt_count: null,
    last_error: null,
    outbox_event_status: null
  };
}
