# CashYin × Fyhub E2E Test Suite

End-to-end real-payment test harness for validating the full CashYin + Bents + Fyhub integration pipeline without impacting real clients.

---

## Architecture

```
CashYin API (Bents provider)          Fyhub API
        │                                  │
POST /v1/pix/cash-in/qrcode  ──────▶  POST /pix/payments/qrc
        │  (creates QR code)               │  (pays QR code via PIX)
        │                                  │
        ▼                                  │
   Bents receives PIX ◀────────────────────┘
        │
        ▼
POST /internal/webhooks/bents
        │
        ▼
  provider-webhook-worker
        │  (marks charge paid, enqueues outbox)
        ▼
  webhook-dispatcher-worker
        │  (delivers signed webhook to client endpoint)
        ▼
  Local webhook server (test-only)
```

---

## Setup

### 1. Copy and configure env file

```bash
cp .env.test.example .env.test.local
# Edit .env.test.local with real values (never commit)
```

### 2. Place mTLS certificate

```bash
# Copy your Fyhub ACCOUNTS PFX cert (CASH_OUT cert):
cp /path/to/FYHUB_59.pfx certs/
# certs/ is gitignored
```

### 3. Provision a test client (if not already done)

The test client's webhook endpoint (`client_webhook_endpoints.target_url`) is the
URL CashYin's dispatcher delivers to. There is **no public API** to change it — it
is provisioned in the database via `scripts/provision-test-client.mjs` using
`TEST_WEBHOOK_TARGET_URL`. Set it to wherever you want the cash-in webhook delivered:

```bash
DATABASE_URL=postgres://... \
TEST_CLIENT_LEGAL_NAME='CashYin E2E Fyhub Test' \
TEST_WEBHOOK_TARGET_URL='http://127.0.0.1:19876' \   # local API + local mock
node scripts/provision-test-client.mjs
# Copy the printed ck_... key to CASHYIN_API_KEY in .env.test.local
```

Re-running with a different `TEST_WEBHOOK_TARGET_URL` updates the existing endpoint
in place (idempotent). Never point a real client's endpoint at a test URL.

---

## Outbound-webhook validation (remote vs local API)

The cash-in scenario validates the webhook CashYin delivers to the client endpoint
after a charge is paid. **A remote CashYin (ECS/staging/prod) cannot reach a
`127.0.0.1` mock on your laptop** — so the receiver strategy must match where the
API runs. This is controlled by `E2E_WEBHOOK_RECEIVER_MODE`:

| Mode | When to use | Behaviour |
|------|-------------|-----------|
| `local` | `CASHYIN_API_BASE_URL` is local | Boots the local mock; auto-asserts the payload. **Fails fast** if the API is remote. |
| `public` | Remote API + a tunnel | Boots the local mock; the tunnel forwards `E2E_WEBHOOK_PUBLIC_URL` → mock. Auto-asserts. |
| `webhook_site` | Remote API, no tunnel | Delivery goes to webhook.site. Manual verification unless `E2E_WEBHOOK_SITE_TOKEN` is set. |
| `disabled` | Don't care about webhooks | Skips observation; report records `skipped_reason`. |

Guardrails enforced by the harness:

1. Remote API + empty `E2E_WEBHOOK_PUBLIC_URL` (mode `public`) → outbound webhook is
   **skipped with a reason**, not reported as a generic failure.
2. Remote API + a `localhost` / `127.0.0.1` / `0.0.0.0` / private-IP target →
   the run **fails** with:
   > `Remote CashYin cannot deliver webhooks to local-only receiver. Configure E2E_WEBHOOK_PUBLIC_URL using webhook.site, ngrok, Cloudflare Tunnel or a public test receiver.`
3. Local API + local receiver → mock is used normally.

### Option A — webhook.site (zero setup, manual verify)

```bash
# 1. Open https://webhook.site, copy your unique URL.
# 2. Point the test client endpoint at it:
DATABASE_URL=postgres://... \
TEST_WEBHOOK_TARGET_URL='https://webhook.site/<your-uuid>' \
node scripts/provision-test-client.mjs

# 3. Configure the E2E:
#    E2E_WEBHOOK_RECEIVER_MODE=webhook_site
#    E2E_WEBHOOK_PUBLIC_URL=https://webhook.site/<your-uuid>
#    (optional) E2E_WEBHOOK_SITE_TOKEN=<api-token>  → enables auto-polling
```

Without a token the report sets `manual_verification_required: true`; open
webhook.site and confirm the `pix.cash_in.paid` envelope arrived.

### Option B — ngrok / Cloudflare Tunnel (auto-asserted)

A tunnel forwards a public URL to the local mock, so deliveries are captured and
asserted automatically even against a remote API.

```bash
# ngrok
ngrok http 19876
#   → forwarding https://<sub>.ngrok-free.app -> http://127.0.0.1:19876

# Cloudflare Tunnel
cloudflared tunnel --url http://127.0.0.1:19876
#   → https://<random>.trycloudflare.com -> http://127.0.0.1:19876

# Provision the test client with the public tunnel URL:
DATABASE_URL=postgres://... \
TEST_WEBHOOK_TARGET_URL='https://<sub>.ngrok-free.app' \
node scripts/provision-test-client.mjs

# Configure the E2E:
#   E2E_WEBHOOK_RECEIVER_MODE=public
#   E2E_WEBHOOK_PUBLIC_URL=https://<sub>.ngrok-free.app
```

The harness boots the local mock on `TEST_WEBHOOK_SERVER_PORT`; the tunnel must
forward that same port. Public URLs are **never hardcoded** in the repo — they
come only from env, and the report shows them redacted (`scheme://host/****xxxx`).

### Interpreting `outbound_webhook` in the report

| Field | Meaning |
|-------|---------|
| `mode` | The receiver strategy used (`local`/`public`/`webhook_site`/`disabled`). |
| `received` | `true` only when a delivery was actually observed and asserted. |
| `skipped_reason` | Set when observation was deliberately skipped (e.g. mode `disabled`, or remote API with no public URL). Not a failure. |
| `manual_verification_required` | `true` for webhook.site without a token — confirm the delivery yourself. |
| `configured_public_url` | Redacted public endpoint (tunnel/webhook.site). |
| `payload_assertions` | Per-field checks on `data.*` (txid, type, amount, external_ref, status, e2e_id) + the no-leak scan. |

---

## Running scenarios

All commands use `pnpm` scripts. Pass extra args after `--`.

### Dry-run (safe, default)

No real payment is made. Only QR code creation is tested.

```bash
pnpm e2e:fyhub:cashin
pnpm e2e:fyhub:cashout
pnpm e2e:fyhub:webhook-latency
pnpm e2e:fyhub:idempotency
pnpm e2e:fyhub:fees-balance
pnpm e2e:fyhub:all
```

### Real payment (R$ 1,00)

Requires **both** `REAL_PAYMENT_TESTS_ENABLED=true` in env **and** `--execute-real-payment` flag:

```bash
REAL_PAYMENT_TESTS_ENABLED=true \
  pnpm e2e:fyhub:cashin -- --execute-real-payment

# With explicit amount (must be ≤ TEST_MAX_AMOUNT_CENTS):
REAL_PAYMENT_TESTS_ENABLED=true \
  pnpm e2e:fyhub:cashin -- --execute-real-payment --amount-cents=100
```

### Load .env.test.local automatically (Node 22)

```bash
node --env-file=.env.test.local scripts/e2e/fyhub/run.ts --scenario=cashin
```

---

## Scenarios

| Scenario | Command | Real payment? | What it validates |
|----------|---------|---------------|-------------------|
| `cashin` | `pnpm e2e:fyhub:cashin` | Optional | QR code create → Fyhub pays → CashYin confirms paid |
| `cashout` | `pnpm e2e:fyhub:cashout` | Optional | CashYin cash-out → Bents → Fyhub receives |
| `webhook-latency` | `pnpm e2e:fyhub:webhook-latency` | Optional | Full pipeline timing incl. outbound webhook delivery |
| `idempotency` | `pnpm e2e:fyhub:idempotency` | No | Idempotency-Key contract (safe, charge creation only) |
| `failure-retry` | `pnpm e2e:fyhub:failure-retry` | Optional | Dispatcher retry on 500 → eventual delivery |
| `fees-balance` | `pnpm e2e:fyhub:fees-balance` | Optional | Balance snapshot + cash-out fee inspection |
| `all` | `pnpm e2e:fyhub:all` | Optional | Runs all scenarios in sequence |

> **Cash-out (`cashout` / `fees-balance`):** the public `POST /v1/pix/cash-out`
> contract requires `pix_key_type`. Set **`CASHYIN_CASHOUT_PIX_KEY_TYPE`**
> (`CPF|CNPJ|EMAIL|PHONE|EVP`, matching `FYHUB_RECEIVER_PIX_KEY`) in
> `.env.test.local`. It is never inferred — these scenarios fail early with a
> clear message (before any request) when it is missing. The public cash-out
> response is snake_case (`amount`, `pix_key`, `pix_key_type`, `external_ref`,
> `e2e_id`, nested `receiver`, `created_at`/`completed_at`/`failed_at`/`returned_at`)
> and exposes **no** fee/cost/margin/provider fields; HTTP **201** = created,
> **200** = idempotent replay.

---

## Reports

Each run writes to `./test-results/fyhub/<correlationId>/` (gitignored):

```
test-results/fyhub/
└── <correlationId>/
    ├── report.json   ← machine-readable, all fields
    └── report.md     ← human-readable, redacted
```

### Report fields

| Field | Description |
|-------|-------------|
| `correlationId` | Unique 16-char hex ID per run |
| `result` | `passed` / `failed` / `partial` / `dry_run` / `skipped` |
| `dryRun` | `true` if no real payment was executed |
| `ids.txid` | CashYin PIX txid (public) |
| `ids.external_ref` | Your client-side reference |
| `ids.e2e_id` | Banco Central E2E ID (when available) |
| `ids.fyhub_payment_id` | Fyhub's internal payment ID |
| `latency.*` | Timing breakdowns in milliseconds |
| `assertions` | Named pass/fail checks |
| `requests` | Redacted HTTP log |
| `gaps` | Missing features / API gaps discovered |

### Interpreting latency

```
createChargeMs               = CashYin charge-create request → response
fyhubPayMs                   = Fyhub /pix/payments/qrc request → response (mTLS + queue)
fyhubAcceptedToCashyinPaidMs = Fyhub accepted → CashYin status=paid
bentsPaidToCashyinPaidMs     = Bents paid_at → CashYin marked paid
pollToConfirmedMs            = Time polling CashYin until status=paid
cashyinPaidToWebhookMs       = CashYin paid → outbound webhook received
webhookTimestampToReceivedMs = CashYin webhook `timestamp` → receiver recorded it
webhookDeliveryMs            = Wait start → first delivery observed
totalWithoutWebhookWaitMs    = Total E2E excluding the outbound-webhook wait
totalWithWebhookMs           = Total E2E including the outbound-webhook wait
```

---

## API Gaps (as of 2026-05)

These features are not yet available via the public API and are reported in scenario outputs:

1. **Cash-in fees** — `fee_assessments` table is internal only; fees are NOT returned in `POST /v1/pix/cash-in/qrcode` response.
2. **Ledger entries** — double-entry accounting (`client_liability`, `provider_clearing`) is not queryable via REST.
3. **Cash-in e2e_id** — populated only after the Bents webhook lands; may not appear in the charge response immediately.
4. **Outbox inspection** — no public endpoint to query pending/failed outbox events or retry counts.

> **Test-only workaround:** set `DATABASE_URL` for the runner and the cash-in
> scenario will read `fee_assessments` + `ledger_entries` directly to validate
> `fee_amount_cents`, the net credit, the ledger entry count and the
> `cash_in_paid` idempotency key. Results appear under
> **Internal Ledger / Fee Inspection** in the report. This adds **no** public API
> surface and only emits redacted financial aggregates (no provider ids, no
> client_id). Skipped with a reason when `DATABASE_URL` is unset.

---

## Security

- `.env.test.local` is gitignored. Never commit it.
- `certs/` and `test-results/` are gitignored.
- All API tokens, cert content, and passphrases are redacted from logs and reports.
- No client-side information is sent to real client webhook endpoints — only to the local test server.
- The `REAL_PAYMENT_TESTS_ENABLED` guard + `--execute-real-payment` flag double-gates all real payment execution.
- `TEST_MAX_AMOUNT_CENTS` (default 100 = R$1,00) hard-caps the payment amount.

---

## File structure

```
scripts/e2e/fyhub/
├── run.ts                  ← main entry point (pnpm e2e:fyhub:*)
├── types.ts                ← shared TypeScript types
├── config.ts               ← env loading + validation
├── redact.ts               ← log/report redaction
├── certificate-loader.ts   ← PFX from file or ZIP
├── fyhub.client.ts         ← Fyhub API client (mTLS, auth, pay)
├── cashyin.client.ts       ← CashYin API client (charges, poll, balance)
├── report.ts               ← JSON + Markdown report generator
├── webhook-server.ts       ← local HTTP server for outbound webhooks
├── scenario-runner.ts      ← guards, context, timing helpers
└── scenarios/
    ├── cashin-qrcode-paid-by-fyhub.ts
    ├── cashout-to-fyhub-pix-key.ts
    ├── webhook-latency.ts
    ├── idempotency.ts
    ├── failure-retry.ts
    └── fees-and-balance.ts
```

---

## Remaining risks

| Risk | Mitigation |
|------|-----------|
| Real money movement on misconfiguration | Double-gate: env var + CLI flag + amount cap |
| Cert or passphrase leaked in logs | `redact.ts` applied to all logged objects |
| Fyhub payment queued but webhook never arrives | Poll timeout + partial result report |
| Dispatcher worker not running locally | `webhook-latency` scenario reports gap, marks `partial` |
| Test client has real client webhook endpoint | Provision a dedicated test client with local server URL |
| `e2e_id` not returned synchronously | Documented as API gap, scenario passes without it |
