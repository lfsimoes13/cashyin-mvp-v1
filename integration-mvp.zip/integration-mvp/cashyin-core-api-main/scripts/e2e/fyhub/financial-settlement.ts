/**
 * Financial settlement validation for the CashYin × Fyhub E2E test suite.
 *
 * Validates that after a successful cash-in payment:
 *   1. `available_balance` increases by `grossAmount - feeAmount` (net credit).
 *   2. `total_balance = available_balance + blocked_balance` (invariant).
 *   3. `updated_at` advances past the pre-payment snapshot.
 *   4. The balance endpoint returns the new snake_case contract.
 *
 * Source of truth for the balance math (from codebase analysis):
 *   - `available_balance` = net SUM(credit − debit) on `client_liability` ledger account.
 *   - On cash-in paid: principal CREDIT (+amountCents) is always posted.
 *   - If a client fee rule exists: an additional DEBIT (−feeCents) is posted.
 *   - Net effect on available_balance = +amountCents − feeCents.
 *
 * Fee resolution (the public API never exposes cash-in fees):
 *   - When DATABASE_URL is provided, the ledger inspector reads the exact
 *     client fee from `fee_assessments` → settlement uses that value.
 *   - Otherwise the settlement uses the documented default cash-in client fee
 *     (the current CashYin rule: 15¢ on the standard test amount). It does NOT
 *     assume zero fee, because that would falsely fail a correct net credit.
 *
 * Reference fee model for the standard cash-in test (100¢):
 *   gross_amount         = 100
 *   customer_fee_amount  =  15   (charged to the client)
 *   provider_cost_amount =  10   (Bents cost — internal, never exposed)
 *   cashyin_margin       =   5   (internal, never exposed)
 *   expected_net_credit  =  85   (= gross − customer_fee)
 *
 * Only the customer-facing net credit (gross − customer_fee) is validated here.
 * Provider cost and CashYin margin are internal and never surfaced.
 */

import type {
  PublicBalance,
  FinancialSettlement,
  SettlementStatus,
  ExpectedFeeSource,
} from './types.js';

// ─── Delta calculation ────────────────────────────────────────────────────────

export interface BalanceDelta {
  available_balance_delta: number;
  blocked_balance_delta: number;
  total_balance_delta: number;
}

/**
 * Calculate the delta between two balance snapshots.
 * Returns null when either snapshot is missing.
 */
export function calculateDelta(
  before: PublicBalance | null,
  after: PublicBalance | null,
): BalanceDelta | null {
  if (!before || !after) return null;
  return {
    available_balance_delta: after.available_balance - before.available_balance,
    blocked_balance_delta: after.blocked_balance - before.blocked_balance,
    total_balance_delta: after.total_balance - before.total_balance,
  };
}

// ─── Invariant checks ─────────────────────────────────────────────────────────

/**
 * Verify that total_balance === available_balance + blocked_balance.
 * Allows ±1 cent tolerance for rounding.
 */
export function checkTotalBalanceInvariant(balance: PublicBalance): boolean {
  const expected = balance.available_balance + balance.blocked_balance;
  return Math.abs(balance.total_balance - expected) <= 1;
}

/**
 * Verify that `updated_at` of the `after` snapshot is strictly after the
 * `before` snapshot, indicating the ledger was actually written.
 */
export function checkUpdatedAtAdvanced(
  before: PublicBalance | null,
  after: PublicBalance | null,
): boolean | null {
  if (!before || !after) return null;
  const beforeMs = new Date(before.updated_at).getTime();
  const afterMs = new Date(after.updated_at).getTime();
  return afterMs > beforeMs;
}

// ─── Net amount helpers ───────────────────────────────────────────────────────

/**
 * Compute the expected available_balance delta for a cash-in payment.
 *
 * @param grossAmountCents  Charge amount (always known).
 * @param feeAmountCents    Effective client fee in cents (never null here —
 *                          callers resolve it to the exact or default fee).
 */
export function expectedNetCreditCents(
  grossAmountCents: number,
  feeAmountCents: number,
): number {
  return grossAmountCents - feeAmountCents;
}

// ─── Settlement builder ───────────────────────────────────────────────────────

export interface SettlementInput {
  balanceBefore: PublicBalance | null;
  balanceAfter: PublicBalance | null;
  contractVersionBefore: 'new' | 'legacy' | 'unknown';
  contractVersionAfter: 'new' | 'legacy' | 'unknown';
  grossAmountCents: number;
  /**
   * Exact client fee read from the internal ledger (fee_assessments) when
   * DATABASE_URL is available. `null` = not inspected → fall back to
   * `defaultExpectedFeeCents`.
   */
  feeAmountCents: number | null;
  /**
   * Documented default cash-in client fee in cents, used when `feeAmountCents`
   * is null. Reflects the current CashYin rule (15¢ on the standard test).
   */
  defaultExpectedFeeCents: number;
}

/**
 * Build the FinancialSettlement section of the report.
 * Never throws — records gaps and sets `validation_result` accordingly.
 */
export function buildSettlement(input: SettlementInput): FinancialSettlement {
  const {
    balanceBefore,
    balanceAfter,
    contractVersionBefore,
    contractVersionAfter,
    grossAmountCents,
    feeAmountCents,
    defaultExpectedFeeCents,
  } = input;

  const gaps: string[] = [];

  // Resolve the effective client fee: exact (ledger) when inspected, else the
  // documented default. Never assume zero — that would falsely fail a correct
  // net credit (gross − fee).
  const feeSource: ExpectedFeeSource =
    feeAmountCents !== null ? 'ledger_inspection' : 'configured_default';
  const effectiveFeeCents = feeAmountCents ?? defaultExpectedFeeCents;

  // Cash-in fees not exposed via public API
  if (feeSource === 'configured_default') {
    gaps.push(
      'Cash-in fee_amount_cents: not returned in public API response (internal fee_assessments only). ' +
        `Expected delta computed using the configured default cash-in client fee (${effectiveFeeCents}¢). ` +
        'Provide DATABASE_URL to validate the exact fee from fee_assessments.',
    );
  }
  gaps.push(
    'Ledger entries (ledger_entries table) not queryable via REST. ' +
      'Idempotency of ledger credit not directly verifiable from E2E tests.',
  );

  const expectedNetCents = expectedNetCreditCents(grossAmountCents, effectiveFeeCents);
  const delta = calculateDelta(balanceBefore, balanceAfter);

  // Contract version checks
  const contractIsBefore = contractVersionBefore === 'new';
  const contractIsAfter = contractVersionAfter === 'new';
  const contractIsNew = contractIsBefore && contractIsAfter;

  if (contractVersionBefore === 'legacy' || contractVersionAfter === 'legacy') {
    gaps.push(
      'GET /v1/balance returned the legacy contract (availableCents). ' +
        'Migrate to the new snake_case contract (fix/cash-in-paid-ledger-credit branch).',
    );
  }

  // Invariant checks
  const totalBalanceInvariantBefore = balanceBefore ? checkTotalBalanceInvariant(balanceBefore) : null;
  const totalBalanceInvariantAfter = balanceAfter ? checkTotalBalanceInvariant(balanceAfter) : null;
  const totalBalanceInvariant =
    totalBalanceInvariantBefore !== false && totalBalanceInvariantAfter !== false
      ? totalBalanceInvariantBefore ?? totalBalanceInvariantAfter
      : false;

  const updatedAtAdvanced = checkUpdatedAtAdvanced(balanceBefore, balanceAfter);

  // Delta match
  const deltaMatchExpected =
    delta !== null ? delta.available_balance_delta === expectedNetCents : null;

  // Determine validation_result
  let validationResult: SettlementStatus;
  let validationReason: string | undefined;

  if (!balanceBefore || !balanceAfter) {
    validationResult = 'skipped_with_reason';
    validationReason = 'Balance snapshot missing (endpoint error or permission issue).';
  } else if (contractVersionBefore === 'unknown' || contractVersionAfter === 'unknown') {
    validationResult = 'skipped_with_reason';
    validationReason = 'Unrecognised balance contract format — cannot validate delta.';
  } else if (deltaMatchExpected === true && totalBalanceInvariant !== false) {
    validationResult = 'passed';
  } else if (deltaMatchExpected === false) {
    validationResult = 'failed';
    const actual = delta?.available_balance_delta ?? 'null';
    const feeNote =
      feeSource === 'ledger_inspection'
        ? `expected fee=${effectiveFeeCents}¢ (exact, from fee_assessments)`
        : `expected fee=${effectiveFeeCents}¢ (configured default; set E2E_CASH_IN_CUSTOMER_FEE_AMOUNT or provide DATABASE_URL to confirm)`;
    validationReason =
      `available_balance_delta=${actual}, expected=${expectedNetCents} (gross=${grossAmountCents}¢ − ${feeNote}). ` +
      (delta?.available_balance_delta === 0 && expectedNetCents > 0
        ? 'Balance did not increase — possible ledger credit bug (fix/cash-in-paid-ledger-credit).'
        : 'Delta mismatch — verify the cash-in client fee rule for this test client.');
  } else if (totalBalanceInvariant === false) {
    validationResult = 'failed';
    validationReason = 'total_balance ≠ available_balance + blocked_balance (invariant violated).';
  } else {
    validationResult = 'skipped_with_reason';
    validationReason = 'Could not determine expected delta.';
  }

  const settlement: FinancialSettlement = {
    balance_before: balanceBefore,
    balance_after: balanceAfter,
    expected_gross_amount_cents: grossAmountCents,
    expected_fee_amount_cents: effectiveFeeCents,
    expected_fee_source: feeSource,
    expected_net_amount_cents: expectedNetCents,
    available_balance_delta: delta?.available_balance_delta ?? null,
    blocked_balance_delta: delta?.blocked_balance_delta ?? null,
    total_balance_delta: delta?.total_balance_delta ?? null,
    delta_matches_expected: deltaMatchExpected,
    total_balance_invariant: totalBalanceInvariant,
    updated_at_advanced: updatedAtAdvanced,
    contract_is_new: contractIsNew,
    validation_result: validationResult,
    gaps,
  };
  if (validationReason !== undefined) {
    settlement.validation_reason = validationReason;
  }
  return settlement;
}

// ─── Pretty-print helpers ─────────────────────────────────────────────────────

export function fmtCents(cents: number | null | undefined): string {
  if (cents === null || cents === undefined) return '—';
  const sign = cents >= 0 ? '+' : '';
  return `${sign}R$ ${(cents / 100).toFixed(2)} (${sign}${cents}¢)`;
}

export function settlementIcon(result: SettlementStatus): string {
  switch (result) {
    case 'passed': return '✅';
    case 'failed': return '❌';
    case 'skipped_with_reason': return '⏭️';
  }
}
