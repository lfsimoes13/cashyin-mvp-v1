/**
 * Scenario 1: Cash-in — QR Code created on CashYin/Bents, paid by Fyhub.
 *
 * Validates the FULL pipeline including financial settlement:
 *   1.  Snapshot CashYin balance (before).
 *   2.  Create PIX charge (R$1,00) via CashYin API → Bents provider.
 *   3.  Start local webhook server to receive outbound CashYin events.
 *   4.  [DRY RUN stops here by default]
 *   5.  Pay the QR code via Fyhub (requires --execute-real-payment).
 *   6.  Measure timestamps: t0…t5.
 *   7.  Poll CashYin until charge.status = 'paid' or timeout.
 *   8.  Snapshot CashYin balance (after).
 *   9.  Compute financial settlement: delta, invariant, updated_at.
 *   10. Wait for outbound webhook from CashYin dispatcher.
 *   11. Validate webhook payload (txid, event, no leaked provider fields).
 *   12. Derive derived latencies (Fyhub→paid, Bents.paid_at→paid, paid→webhook).
 *   13. Generate JSON + Markdown report with Financial Settlement section.
 *
 * Financial settlement expectations (with no fee rule configured for test client):
 *   available_balance_delta = +100¢ (= amountCents, no fee deducted)
 *   total_balance_invariant: total = available + blocked
 *   updated_at must advance after payment
 *
 * Run (dry-run):
 *   pnpm e2e:fyhub:cashin
 *
 * Run (real payment):
 *   REAL_PAYMENT_TESTS_ENABLED=true pnpm e2e:fyhub:cashin -- --execute-real-payment
 */

import type { E2EConfig } from '../config.js';
import { loadCert } from '../certificate-loader.js';
import { FyhubClient, centsToBrl } from '../fyhub.client.js';
import { CashyinClient, generateExternalRef, generateIdempotencyKey, parsePublicBalance } from '../cashyin.client.js';
import { LocalWebhookServer } from '../webhook-server.js';
import { buildSettlement } from '../financial-settlement.js';
import {
  resolveWebhookReceiver,
  initialOutboundValidation,
  assertCashInWebhookPayload,
  type WebhookReceiverPlan,
} from '../webhook-receiver.js';
import { redactHeaders } from '../redact.js';
import { inspectCashInLedger, skippedInspection } from '../ledger-inspector.js';
import { inspectPaidPipelineTiming, skippedTiming } from '../paid-pipeline-timing.js';
import { scrapeMetrics } from '../metrics-scraper.js';
import type {
  PublicBalance,
  OutboundWebhookValidation,
  LedgerInspection,
  PaidPipelineTiming,
} from '../types.js';
import {
  createContext,
  assert,
  addMessage,
  addGap,
  buildReport,
  finalizeAndSave,
  assertRealPaymentAllowed,
  assertAmountWithinLimit,
  now,
  printPreRunSummary,
  recordRequest,
} from '../scenario-runner.js';
import type { ScenarioReport } from '../types.js';

// ─── Main scenario function ───────────────────────────────────────────────────

export async function runCashInScenario(cfg: E2EConfig, amountCents: number): Promise<ScenarioReport> {
  const ctx = createContext('cashin-qrcode-paid-by-fyhub', cfg, amountCents);

  printPreRunSummary(ctx);

  try {
    assertAmountWithinLimit(cfg, amountCents);
  } catch (err) {
    const report = buildReport(ctx, 'failed', { error: String(err) });
    finalizeAndSave(report, cfg.test.outputDir);
    return report;
  }

  // ── Resolve outbound-webhook receiver strategy (fail fast on misconfig) ─────
  // Throws on the classic mistake: remote API + a local-only receiver, since a
  // remote CashYin can never reach 127.0.0.1 on this runner.
  let receiverPlan: WebhookReceiverPlan;
  try {
    receiverPlan = resolveWebhookReceiver(cfg.webhook, cfg.cashyin.baseUrl);
  } catch (err) {
    const report = buildReport(ctx, 'failed', { error: err instanceof Error ? err.message : String(err) });
    finalizeAndSave(report, cfg.test.outputDir);
    return report;
  }
  addMessage(ctx, `Outbound-webhook receiver mode: ${receiverPlan.mode}`);
  if (receiverPlan.configuredPublicUrlRedacted) {
    addMessage(ctx, `Configured public receiver: ${receiverPlan.configuredPublicUrlRedacted}`);
  }
  if (receiverPlan.skippedReason) {
    addMessage(ctx, `Outbound webhook: ${receiverPlan.skippedReason}`);
  }

  const t0Total = performance.now();

  // ── Build CashYin client ──────────────────────────────────────────────────

  const cashyin = new CashyinClient({
    baseUrl: cfg.cashyin.baseUrl,
    apiKey: cfg.cashyin.apiKey,
    timeoutMs: cfg.cashyin.timeoutMs,
    onRequest: (r) => {
      recordRequest(ctx, r);
      console.log(`  [cashyin] ${r.method} ${r.url.replace(cfg.cashyin.baseUrl, '')} → ${r.responseStatus} (${r.latencyMs}ms)`);
    },
  });

  // ── Step 1: CashYin health check ──────────────────────────────────────────

  const { ok: healthy } = await cashyin.health();
  assert(ctx, 'CashYin API reachable', healthy);
  if (!healthy) {
    const report = buildReport(ctx, 'failed', { error: 'CashYin API health check failed' });
    finalizeAndSave(report, cfg.test.outputDir);
    return report;
  }

  // ── Step 2: Balance snapshot (before) ─────────────────────────────────────

  let balanceBefore: PublicBalance | null = null;
  let contractVersionBefore: 'new' | 'legacy' | 'unknown' = 'unknown';

  try {
    const { parsed, contractVersion } = await cashyin.getBalance();
    balanceBefore = parsed;
    contractVersionBefore = contractVersion;

    if (contractVersion === 'legacy') {
      addMessage(ctx, `⚠️  Balance returned legacy contract (availableCents). Migrate to new snake_case contract.`);
      addGap(ctx, 'GET /v1/balance returned legacy contract { clientId, availableCents }. ' +
        'New contract expected: { available_balance, blocked_balance, total_balance, currency, updated_at }.');
    } else if (contractVersion === 'new' && parsed) {
      addMessage(ctx, `Balance (before): available=${parsed.available_balance}¢ blocked=${parsed.blocked_balance}¢ total=${parsed.total_balance}¢`);
      assert(ctx, 'Balance contract is new (snake_case)', true, `available=${parsed.available_balance}¢`);
    } else {
      addGap(ctx, 'Balance endpoint returned unrecognised contract format.');
    }
  } catch (err) {
    addMessage(ctx, `Balance (before) failed: ${err instanceof Error ? err.message : String(err)}`);
    addGap(ctx, 'Could not fetch balance before charge — financial settlement validation will be skipped.');
  }

  // ── Step 3: Create QR code charge ─────────────────────────────────────────

  const externalRef = generateExternalRef('e2e-fyhub-cashin');

  ctx.timings.t0_charge_create_requested = now();
  const t0Create = performance.now();
  let charge;

  try {
    const result = await cashyin.createCashInCharge(
      amountCents,
      externalRef,
      `CashYin × Fyhub E2E test ${ctx.correlationId}`,
    );
    charge = result.data;
    ctx.timings.t1_charge_create_response = now();
    ctx.timings.createChargeMs = Math.round(performance.now() - t0Create);

    assert(ctx, 'Charge created', charge.status === 'pending', `status=${charge.status}`);
    assert(ctx, 'EMV present', !!charge.pix.emv, charge.pix.emv ? 'yes' : 'missing');
    assert(ctx, 'txid present', !!charge.txid);
    assert(ctx, 'external_ref matches', charge.external_ref === externalRef);
    assert(ctx, 'amount matches', charge.amount === amountCents, `got=${charge.amount}`);
    assert(ctx, 'No provider_charge_id leaked', !('provider_charge_id' in charge));
    assert(ctx, 'No internal id leaked', !('id' in charge));
    assert(ctx, 'No client_id leaked', !('client_id' in charge) && !('clientId' in charge));
  } catch (err) {
    const report = buildReport(ctx, 'failed', {
      error: err instanceof Error ? err.message : String(err),
      ids: { external_ref: externalRef },
    });
    finalizeAndSave(report, cfg.test.outputDir);
    return report;
  }

  // ── Step 4: Start local webhook server (only if the plan calls for it) ─────
  // In `local`/`public` (tunnel) modes a local mock captures deliveries. In
  // `webhook_site`/`disabled` modes nothing is started — the plan already says
  // whether delivery is auto-observable or needs manual verification.

  const webhookServer = new LocalWebhookServer({ port: cfg.test.webhookServerPort });
  let webhookServerStarted = false;

  if (!ctx.dryRun && receiverPlan.shouldStartLocalServer) {
    try {
      const webhookServerUrl = await webhookServer.start();
      webhookServerStarted = true;
      addMessage(ctx, `Webhook receiver started at ${webhookServerUrl}`);
      if (receiverPlan.mode === 'public') {
        addMessage(ctx, `NOTE: tunnel must forward ${receiverPlan.configuredPublicUrlRedacted} → ${webhookServerUrl}`);
      } else {
        addMessage(ctx, `NOTE: test client endpoint must be set to ${webhookServerUrl} (see provision-test-client.mjs)`);
      }
    } catch (err) {
      addMessage(ctx, `Webhook server could not start (non-fatal): ${err instanceof Error ? err.message : String(err)}`);
      addGap(ctx, 'Local webhook server failed to start — outbound webhook validation skipped.');
    }
  }

  // ── Dry-run stop ──────────────────────────────────────────────────────────

  if (ctx.dryRun) {
    addMessage(ctx, 'DRY RUN: Skipping Fyhub payment. Pass --execute-real-payment to pay.');
    const report = buildReport(ctx, 'dry_run', {
      ids: { txid: charge.txid, external_ref: externalRef },
      latency: { createChargeMs: ctx.timings.createChargeMs, totalMs: Math.round(performance.now() - t0Total) },
    });
    finalizeAndSave(report, cfg.test.outputDir);
    return report;
  }

  // ── Guard real payment ────────────────────────────────────────────────────

  try {
    assertRealPaymentAllowed(cfg, amountCents);
  } catch (err) {
    if (webhookServerStarted) await webhookServer.stop();
    const report = buildReport(ctx, 'failed', {
      error: String(err),
      ids: { txid: charge.txid, external_ref: externalRef },
    });
    finalizeAndSave(report, cfg.test.outputDir);
    return report;
  }

  // ── Step 5: Load cert + build Fyhub client ────────────────────────────────

  let cert;
  try {
    cert = loadCert(cfg.fyhub.certPath, cfg.fyhub.certZipPath, cfg.fyhub.certPassword);
  } catch (err) {
    if (webhookServerStarted) await webhookServer.stop();
    const report = buildReport(ctx, 'failed', {
      error: `Certificate load failed: ${err instanceof Error ? err.message : String(err)}`,
      ids: { txid: charge.txid, external_ref: externalRef },
    });
    finalizeAndSave(report, cfg.test.outputDir);
    return report;
  }

  const fyhub = new FyhubClient({
    baseUrl: cfg.fyhub.baseUrl,
    clientId: cfg.fyhub.clientId,
    clientSecret: cfg.fyhub.clientSecret,
    cert,
    timeoutMs: cfg.fyhub.timeoutMs,
    onRequest: (r) => {
      recordRequest(ctx, r);
      console.log(`  [fyhub]   ${r.method} ${r.url.replace(cfg.fyhub.baseUrl, '')} → ${r.responseStatus} (${r.latencyMs}ms)`);
    },
  });

  // ── Step 6: Pay via Fyhub ─────────────────────────────────────────────────

  ctx.timings.t2_fyhub_payment_requested = now();
  const t0Pay = performance.now();
  let fyhubPayResult;

  try {
    fyhubPayResult = await fyhub.payQrCode(
      charge.pix.emv!,
      centsToBrl(amountCents),
      {
        description: `CashYin E2E ${ctx.correlationId}`,
        idempotencyKey: generateIdempotencyKey().slice(0, 48),
      },
    );
    ctx.timings.t3_fyhub_payment_response = now();
    ctx.timings.fyhubPayMs = Math.round(performance.now() - t0Pay);
    assert(ctx, 'Fyhub payment accepted', true, `HTTP 202, id=${fyhubPayResult.data.id}`);
    addMessage(ctx, `Fyhub payment queued: id=${fyhubPayResult.data.id}, e2eId=${fyhubPayResult.data.endToEndId ?? 'pending'}`);
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    assert(ctx, 'Fyhub payment accepted', false, msg);
    if (webhookServerStarted) await webhookServer.stop();
    await fyhub.destroy();
    const report = buildReport(ctx, 'failed', {
      error: msg,
      ids: { txid: charge.txid, external_ref: externalRef },
      latency: { createChargeMs: ctx.timings.createChargeMs, fyhubPayMs: Math.round(performance.now() - t0Pay) },
    });
    finalizeAndSave(report, cfg.test.outputDir);
    return report;
  }

  // ── Step 7: Poll CashYin until paid ──────────────────────────────────────

  addMessage(ctx, `Polling for confirmation (timeout=${cfg.test.pollTimeoutSecs}s)...`);
  const t5WaitStart = performance.now();
  process.stdout.write('  polling ');

  const { data: finalCharge, attempts, timedOut, pollMs } = await cashyin.pollCashInUntilTerminal(
    charge.txid,
    {
      timeoutSecs: cfg.test.pollTimeoutSecs,
      intervalSecs: cfg.test.pollIntervalSecs,
      onPoll: (status) => process.stdout.write(status === 'pending' ? '.' : ` [${status}]`),
    },
  );
  console.log('');

  const t5Actual = now();
  ctx.timings.t5_charge_marked_paid = finalCharge.paid_at ?? t5Actual;
  ctx.timings.pollToConfirmedMs = pollMs;

  // Provider paid_at from Bents (when the provider actually settled)
  if (finalCharge.paid_at) {
    ctx.timings.t4_bents_paid_at = finalCharge.paid_at;
  }

  // Derived latencies
  if (ctx.timings.t3_fyhub_payment_response && finalCharge.paid_at) {
    const fyhubAcceptedMs = new Date(ctx.timings.t3_fyhub_payment_response).getTime();
    const paidMs = new Date(finalCharge.paid_at).getTime();
    ctx.timings.fyhubAcceptedToCashyinPaidMs = Math.max(0, paidMs - fyhubAcceptedMs);
  }

  if (finalCharge.paid_at) {
    // Bents paid_at → CashYin poll detected paid: difference is webhook processing latency
    const bentsPaidMs = new Date(finalCharge.paid_at).getTime();
    const pollDetectedMs = new Date(t5Actual).getTime();
    ctx.timings.bentsPaidToCashyinPaidMs = Math.max(0, pollDetectedMs - bentsPaidMs);
  }

  const paid = finalCharge.status === 'paid';
  addMessage(ctx, `Final status: ${finalCharge.status} (${attempts} polls, ${pollMs}ms)`);

  // ── Step 8: Balance snapshot (after) ──────────────────────────────────────

  let balanceAfter: PublicBalance | null = null;
  let contractVersionAfter: 'new' | 'legacy' | 'unknown' = 'unknown';

  if (paid) {
    // Brief pause to let the ledger transaction commit before reading balance
    await sleep(500);
    try {
      const { parsed, contractVersion } = await cashyin.getBalance();
      balanceAfter = parsed;
      contractVersionAfter = contractVersion;

      if (parsed) {
        addMessage(ctx, `Balance (after): available=${parsed.available_balance}¢ blocked=${parsed.blocked_balance}¢ total=${parsed.total_balance}¢`);
      }
    } catch (err) {
      addMessage(ctx, `Balance (after) failed: ${err instanceof Error ? err.message : String(err)}`);
      addGap(ctx, 'Could not fetch balance after payment — financial settlement validation partial.');
    }
  }

  // ── Step 8b: Internal ledger/fee inspection (TEST-ONLY, DATABASE_URL gated) ─
  // Verifies fee_amount_cents, net credit and ledger idempotency directly from
  // the DB without adding any public API surface. Skipped (with a reason) when
  // no DATABASE_URL is provided to the runner.

  let ledgerInspection: LedgerInspection;
  if (paid) {
    ledgerInspection = await inspectCashInLedger(cfg.databaseUrl, finalCharge.txid);
    if (ledgerInspection.available) {
      addMessage(
        ctx,
        `Ledger (internal): gross=${ledgerInspection.gross_amount_cents}¢ fee=${ledgerInspection.fee_amount_cents}¢ ` +
          `net=${ledgerInspection.net_amount_cents}¢ entries=${ledgerInspection.ledger_entry_count} ` +
          `client_liability_delta=${ledgerInspection.client_liability_delta_cents}¢`,
      );
      assert(
        ctx,
        'Ledger client_liability delta = net credit',
        ledgerInspection.client_liability_delta_cents === ledgerInspection.net_amount_cents,
        `delta=${ledgerInspection.client_liability_delta_cents}¢ net=${ledgerInspection.net_amount_cents}¢`,
      );
      assert(
        ctx,
        'Ledger idempotency key present (single posting)',
        ledgerInspection.ledger_idempotency_key_present === true,
      );
    } else if (ledgerInspection.skipped_reason) {
      addMessage(ctx, `Ledger inspection skipped: ${ledgerInspection.skipped_reason}`);
    }
  } else {
    ledgerInspection = skippedInspection('Charge not paid — ledger inspection skipped.');
  }

  // ── Step 8c: Paid-pipeline timing (TEST-ONLY, DATABASE_URL gated) ───────────
  // Reads the server-side per-stage latency directly from DB timestamps so the
  // breakdown is not capped by the public poll granularity. Skipped (with a
  // reason) when no DATABASE_URL is provided. For production, prefer the
  // Prometheus snapshot below (the RDS is private and unreachable here).

  let paidPipelineTiming: PaidPipelineTiming;
  if (paid) {
    paidPipelineTiming = await inspectPaidPipelineTiming(cfg.databaseUrl, finalCharge.txid);
    if (paidPipelineTiming.available) {
      addMessage(
        ctx,
        `Paid pipeline (internal): webhook_processing=${fmtMs(paidPipelineTiming.webhook_processing_ms)} ` +
          `outbox_dispatch=${fmtMs(paidPipelineTiming.outbox_dispatch_ms)} ` +
          `delivery=${fmtMs(paidPipelineTiming.delivery_ms)} ` +
          `end_to_end=${fmtMs(paidPipelineTiming.end_to_end_ms)} ` +
          `(delivery_status=${paidPipelineTiming.delivery_status ?? 'n/a'}, ` +
          `attempts=${paidPipelineTiming.delivery_attempt_count ?? 'n/a'})`,
      );
    } else if (paidPipelineTiming.skipped_reason) {
      addMessage(ctx, `Paid-pipeline timing skipped: ${paidPipelineTiming.skipped_reason}`);
    }
  } else {
    paidPipelineTiming = skippedTiming('Charge not paid — paid-pipeline timing skipped.');
  }

  // ── Step 9: Financial settlement validation ───────────────────────────────
  // When the internal inspection found a fee, use it so the expected delta is
  // exact; otherwise fall back to the configured default cash-in client fee
  // (the current CashYin rule), NOT zero — the net credit is gross − fee.

  const settlement = buildSettlement({
    balanceBefore,
    balanceAfter,
    contractVersionBefore,
    contractVersionAfter,
    grossAmountCents: amountCents,
    feeAmountCents: ledgerInspection.available ? ledgerInspection.fee_amount_cents : null,
    defaultExpectedFeeCents: cfg.pricing.cashIn.customerFeeAmount,
  });

  // Add settlement assertions to ctx
  assert(
    ctx,
    'Balance contract is new snake_case',
    settlement.contract_is_new === true,
    settlement.contract_is_new ? 'yes' : 'no — see gaps',
  );
  if (settlement.delta_matches_expected !== null) {
    assert(
      ctx,
      `Balance increased by expected net credit ${settlement.expected_net_amount_cents}¢ ` +
        `(gross ${amountCents}¢ − fee ${settlement.expected_fee_amount_cents ?? 0}¢)`,
      settlement.delta_matches_expected,
      settlement.validation_reason ?? `delta=${settlement.available_balance_delta}¢`,
    );
  }
  if (settlement.total_balance_invariant !== null) {
    assert(ctx, 'total = available + blocked (invariant)', settlement.total_balance_invariant);
  }
  if (settlement.updated_at_advanced !== null) {
    assert(ctx, 'balance.updated_at advanced after payment', settlement.updated_at_advanced);
  }

  // Propagate settlement gaps to report
  for (const g of settlement.gaps) addGap(ctx, g);

  if (settlement.validation_result === 'failed' && settlement.validation_reason) {
    addMessage(ctx, `⚠️  Settlement FAILED: ${settlement.validation_reason}`);
  }

  // ── Step 10: Validate charge response fields ───────────────────────────────

  assert(ctx, 'Charge status is paid', paid, finalCharge.status);
  assert(ctx, 'Poll did not time out', !timedOut);

  if (paid) {
    assert(ctx, 'paid_at is set', !!finalCharge.paid_at, finalCharge.paid_at ?? 'null');
    if (finalCharge.pix.e2e_id) {
      assert(ctx, 'pix.e2e_id populated', true, finalCharge.pix.e2e_id);
    } else {
      addGap(ctx, 'pix.e2e_id not populated in charge response — may arrive via webhook only.');
    }
    assert(ctx, 'txid unchanged', finalCharge.txid === charge.txid);
    assert(ctx, 'No provider data in response', !('provider_charge_id' in finalCharge));

    // Payer validation (arrives with webhook processing)
    if (finalCharge.payer) {
      assert(ctx, 'Payer name populated', !!finalCharge.payer.name, finalCharge.payer.name ?? 'null');
    } else {
      addMessage(ctx, 'Payer info not populated (acceptable if provider did not emit payer data).');
    }
  }

  // ── Step 11: Observe outbound webhook (per receiver plan) ──────────────────

  // Wall-clock total BEFORE we (optionally) wait for the webhook, so the report
  // can separate "total without webhook wait" from "total with webhook".
  const totalWithoutWebhookWaitMs = Math.round(performance.now() - t0Total);
  ctx.timings.totalWithoutWebhookWaitMs = totalWithoutWebhookWaitMs;

  const outboundWebhook: OutboundWebhookValidation = initialOutboundValidation(receiverPlan);

  if (receiverPlan.manualVerificationRequired) {
    addMessage(
      ctx,
      `Outbound webhook requires manual verification (mode=${receiverPlan.mode}). ` +
        `Confirm delivery at the configured public receiver.`,
    );
    addGap(ctx, 'Outbound webhook delivery not auto-observable — manual verification required (see report).');
  } else if (receiverPlan.expectDelivery && webhookServerStarted && paid) {
    const webhookWaitMs = 30_000;
    addMessage(ctx, `Waiting up to ${webhookWaitMs / 1000}s for outbound client webhook...`);

    const t0Webhook = Date.now();
    const { events } = await webhookServer.waitForEvents(1, webhookWaitMs);
    const whLatencyMs = Date.now() - t0Webhook;

    if (events.length > 0) {
      const evt = events[0];
      ctx.timings.t7_client_webhook_received = evt.receivedAt;

      // CashYin paid → outbound webhook received
      if (finalCharge.paid_at) {
        const paidMs = new Date(finalCharge.paid_at).getTime();
        const webhookMs = new Date(evt.receivedAt).getTime();
        ctx.timings.cashyinPaidToWebhookMs = Math.max(0, webhookMs - paidMs);
        ctx.timings.webhookDeliveryMs = whLatencyMs;
      }

      // CashYin envelope `timestamp` → receiver recorded it
      const envelopeTs = readEnvelopeTimestamp(evt.body);
      if (envelopeTs) {
        const tsMs = new Date(envelopeTs).getTime();
        const recvMs = new Date(evt.receivedAt).getTime();
        if (!Number.isNaN(tsMs)) ctx.timings.webhookTimestampToReceivedMs = Math.max(0, recvMs - tsMs);
      }

      outboundWebhook.received = true;
      outboundWebhook.received_at = evt.receivedAt;
      outboundWebhook.latency_ms = whLatencyMs;
      outboundWebhook.http_method = evt.method;
      outboundWebhook.headers_redacted = redactHeaders(flattenHeaders(evt.headers));
      outboundWebhook.payload_assertions = assertCashInWebhookPayload(evt.body, {
        txid: finalCharge.txid,
        amountCents,
        externalRef,
      });

      // Surface payload assertions into the scenario's assertion list too.
      for (const a of outboundWebhook.payload_assertions) {
        assert(ctx, `webhook: ${a.name}`, a.passed, a.detail);
      }

      addMessage(ctx, `Outbound webhook received after ${whLatencyMs}ms`);
    } else {
      outboundWebhook.last_error = `No delivery within ${webhookWaitMs / 1000}s`;
      addMessage(ctx, `No outbound webhook received within ${webhookWaitMs / 1000}s.`);
      addGap(ctx, 'No outbound webhook received. Ensure the client endpoint points at this receiver and the dispatcher worker is running.');
    }
  } else if (receiverPlan.mode === 'disabled') {
    addMessage(ctx, 'Outbound webhook observation disabled by configuration.');
  } else if (!webhookServerStarted && receiverPlan.expectDelivery) {
    addGap(ctx, 'Outbound webhook validation skipped (local receiver did not start).');
  }

  if (webhookServerStarted) await webhookServer.stop();
  await fyhub.destroy();

  // ── Step 11b: Prometheus metrics snapshot (optional) ──────────────────────
  // Best-effort scrape of the deployed /internal/metrics endpoint to capture
  // the server-side cash_in.paid latency histograms. This is the right way to
  // measure production (private RDS). Never fails the scenario.

  const metricsSnapshot = await scrapeMetrics(cfg.metrics.url, cfg.metrics.bearerToken);
  if (metricsSnapshot.available) {
    addMessage(ctx, `Metrics snapshot captured from ${metricsSnapshot.source_url}`);
  } else if (metricsSnapshot.skipped_reason && cfg.metrics.url) {
    addMessage(ctx, `Metrics snapshot skipped: ${metricsSnapshot.skipped_reason}`);
  }

  // ── Step 12: Build final report ───────────────────────────────────────────

  const totalMs = Math.round(performance.now() - t0Total);
  ctx.timings.totalWithWebhookMs = totalMs;

  // Determine overall result
  const settlementOk = settlement.validation_result !== 'failed';
  const result = paid && settlementOk ? 'passed' : paid && !settlementOk ? 'partial' : timedOut ? 'partial' : 'failed';

  const report = buildReport(ctx, result, {
    ids: {
      txid: finalCharge.txid,
      external_ref: finalCharge.external_ref,
      e2e_id: finalCharge.pix.e2e_id ?? undefined,
      fyhub_payment_id: fyhubPayResult.data.id,
      fyhub_end_to_end_id: fyhubPayResult.data.endToEndId ?? undefined,
    },
    latency: {
      createChargeMs: ctx.timings.createChargeMs,
      fyhubPayMs: ctx.timings.fyhubPayMs,
      pollToConfirmedMs: pollMs,
      fyhubAcceptedToCashyinPaidMs: ctx.timings.fyhubAcceptedToCashyinPaidMs,
      bentsPaidToCashyinPaidMs: ctx.timings.bentsPaidToCashyinPaidMs,
      webhookDeliveryMs: ctx.timings.webhookDeliveryMs,
      cashyinPaidToWebhookMs: ctx.timings.cashyinPaidToWebhookMs,
      webhookTimestampToReceivedMs: ctx.timings.webhookTimestampToReceivedMs,
      totalMs,
      totalWithWebhookMs: totalMs,
      totalWithoutWebhookWaitMs,
      pollAttempts: attempts,
    },
    financialSettlement: settlement,
    outboundWebhook,
    ledgerInspection,
    paidPipelineTiming,
    metricsSnapshot,
    error: !paid ? `Charge did not reach paid status: ${finalCharge.status}` :
      settlement.validation_result === 'failed' ? settlement.validation_reason : undefined,
  });

  finalizeAndSave(report, cfg.test.outputDir);
  return report;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

/** Formats a nullable millisecond duration for log messages. */
function fmtMs(ms: number | null): string {
  if (ms === null) return 'n/a';
  return ms >= 1000 ? `${(ms / 1000).toFixed(2)}s` : `${ms}ms`;
}

/** Reads the envelope-level `timestamp` (ISO) when present. */
function readEnvelopeTimestamp(body: unknown): string | null {
  if (!body || typeof body !== 'object') return null;
  const ts = (body as Record<string, unknown>)['timestamp'];
  return typeof ts === 'string' ? ts : null;
}

/** Flatten node:http header values (string | string[] | undefined) to strings. */
function flattenHeaders(
  headers: Record<string, string | string[] | undefined>,
): Record<string, string | undefined> {
  const out: Record<string, string | undefined> = {};
  for (const [k, v] of Object.entries(headers)) {
    out[k] = Array.isArray(v) ? v.join(', ') : v;
  }
  return out;
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
