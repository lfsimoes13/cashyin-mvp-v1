/**
 * Scenario 4: Cash-in dedup + cash-out idempotency contract.
 *
 * Cash-in does NOT use the `Idempotency-Key` header. Retry-safety is the
 * `(client_id, external_ref)` business rule. Cash-out continues to REQUIRE
 * `Idempotency-Key`.
 *
 * Validates:
 *   1. Repeating the same external_ref on cash-in → same txid (dedup business rule)
 *   2. Distinct external_ref on cash-in → distinct txid (independent charges)
 *   3. Cash-in succeeds with NO Idempotency-Key header
 *   4. Cash-out with same Idempotency-Key twice → idempotent (real payment; skipped here)
 *
 * Does NOT execute real payments (only charge creation, no Fyhub payment).
 * This scenario is safe to run without --execute-real-payment.
 *
 * Run:
 *   pnpm e2e:fyhub:idempotency
 */

import type { E2EConfig } from '../config.js';
import { CashyinClient, generateExternalRef } from '../cashyin.client.js';
import {
  createContext,
  assert,
  addMessage,
  addGap,
  buildReport,
  finalizeAndSave,
  assertAmountWithinLimit,
  printPreRunSummary,
  recordRequest,
} from '../scenario-runner.js';
import type { ScenarioReport } from '../types.js';

export async function runIdempotencyScenario(
  cfg: E2EConfig,
  amountCents: number,
): Promise<ScenarioReport> {
  // Override: this scenario never does real payments
  const ctx = createContext('idempotency', cfg, amountCents);
  ctx.dryRun = false; // idempotency tests charge creation (safe, no payment)

  printPreRunSummary(ctx);

  try {
    assertAmountWithinLimit(cfg, amountCents);
  } catch (err) {
    const report = buildReport(ctx, 'failed', { error: String(err) });
    finalizeAndSave(report, cfg.test.outputDir);
    return report;
  }

  const t0Total = performance.now();

  const cashyin = new CashyinClient({
    baseUrl: cfg.cashyin.baseUrl,
    apiKey: cfg.cashyin.apiKey,
    timeoutMs: cfg.cashyin.timeoutMs,
    onRequest: (r) => {
      recordRequest(ctx, r);
      console.log(`  [cashyin] ${r.method} ${r.url.replace(cfg.cashyin.baseUrl, '')} → ${r.responseStatus} (${r.latencyMs}ms)`);
    },
  });

  let allPassed = true;

  // ── Test 1: Repeated external_ref → same txid (dedup business rule) ────────

  addMessage(ctx, 'Test 1: Repeat same external_ref (no Idempotency-Key) → expect same txid');
  const ref1 = generateExternalRef('e2e-idem-1');

  try {
    const r1 = await cashyin.createCashInCharge(amountCents, ref1, 'idempotency test 1');
    const r2 = await cashyin.createCashInCharge(amountCents, ref1, 'idempotency test 1');

    const sameTxid = r1.data.txid === r2.data.txid;
    assert(ctx, 'Test 1: Repeat external_ref → same txid (deduped)', sameTxid, `t1=${r1.data.txid} t2=${r2.data.txid}`);
    if (!sameTxid) allPassed = false;
    // Cash-in succeeds without ever sending Idempotency-Key.
    assert(ctx, 'Test 3: Cash-in succeeds with NO Idempotency-Key header', !!r1.data.txid, r1.data.txid);
    addMessage(ctx, `txid on both calls: ${r1.data.txid}`);
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    assert(ctx, 'Test 1: Repeat external_ref → same txid (deduped)', false, msg);
    allPassed = false;
    addMessage(ctx, `Test 1 failed: ${msg}`);
  }

  // ── Test 2: Distinct external_ref → distinct txid (independent charges) ────

  addMessage(ctx, 'Test 2: Distinct external_ref → expect distinct txid');
  const ref2a = generateExternalRef('e2e-idem-2a');
  const ref2b = generateExternalRef('e2e-idem-2b');

  try {
    const a = await cashyin.createCashInCharge(amountCents, ref2a, 'idempotency test 2a');
    const b = await cashyin.createCashInCharge(amountCents, ref2b, 'idempotency test 2b');

    const distinct = a.data.txid !== b.data.txid;
    assert(ctx, 'Test 2: Distinct external_ref → distinct txid', distinct, `a=${a.data.txid} b=${b.data.txid}`);
    if (!distinct) allPassed = false;
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    assert(ctx, 'Test 2: Distinct external_ref → distinct txid', false, msg);
    allPassed = false;
  }

  // ── Test 4: Cash-out idempotency (requires Idempotency-Key) ───────────────

  addMessage(ctx, 'Test 4: Cash-out same Idempotency-Key twice → idempotent');
  addGap(ctx, 'Cash-out idempotency test requires real payment execution (skipped in this run). ' +
    'Cash-out still REQUIRES the Idempotency-Key header.');

  // ── Report ────────────────────────────────────────────────────────────────

  const totalMs = Math.round(performance.now() - t0Total);
  const result = allPassed ? 'passed' : 'partial';

  const report = buildReport(ctx, result, {
    latency: { totalMs },
  });

  finalizeAndSave(report, cfg.test.outputDir);
  return report;
}
