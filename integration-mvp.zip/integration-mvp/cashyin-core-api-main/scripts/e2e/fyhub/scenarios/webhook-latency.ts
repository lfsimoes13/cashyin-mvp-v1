/**
 * Scenario 3: Webhook latency measurement.
 *
 * Measures the full pipeline:
 *   t0: charge create request
 *   t1: charge create response
 *   t2: Fyhub payment request
 *   t3: Fyhub payment response
 *   t5: CashYin charge status → paid (poll)
 *   t7: Local webhook server receives outbound event from CashYin dispatcher
 *
 * A temporary local HTTP server receives CashYin's outbound webhooks.
 * The test client must be provisioned with the local server URL as its
 * webhook endpoint.
 *
 * Run (dry-run, starts local server only):
 *   pnpm e2e:fyhub:webhook-latency
 *
 * Run (real):
 *   REAL_PAYMENT_TESTS_ENABLED=true \
 *   pnpm e2e:fyhub:webhook-latency -- --execute-real-payment
 */

import type { E2EConfig } from '../config.js';
import { loadCert } from '../certificate-loader.js';
import { FyhubClient, centsToBrl } from '../fyhub.client.js';
import { CashyinClient, generateExternalRef, generateIdempotencyKey } from '../cashyin.client.js';
import { LocalWebhookServer } from '../webhook-server.js';
import {
  createContext,
  assert,
  addMessage,
  addGap,
  buildReport,
  finalizeAndSave,
  assertRealPaymentAllowed,
  assertAmountWithinLimit,
  now,
  printPreRunSummary,
  recordRequest,
} from '../scenario-runner.js';
import type { ScenarioReport } from '../types.js';

export async function runWebhookLatencyScenario(
  cfg: E2EConfig,
  amountCents: number,
): Promise<ScenarioReport> {
  const ctx = createContext('webhook-latency', cfg, amountCents);

  printPreRunSummary(ctx);

  try {
    assertAmountWithinLimit(cfg, amountCents);
  } catch (err) {
    const report = buildReport(ctx, 'failed', { error: String(err) });
    finalizeAndSave(report, cfg.test.outputDir);
    return report;
  }

  const t0Total = performance.now();

  // ── Start local webhook server ─────────────────────────────────────────────

  const webhookServer = new LocalWebhookServer({ port: cfg.test.webhookServerPort });
  let serverUrl: string;

  try {
    serverUrl = await webhookServer.start();
    addMessage(ctx, `Local webhook server started at ${serverUrl}`);
    addMessage(
      ctx,
      `NOTE: For webhooks to arrive here, the CashYin test client must have ` +
        `its webhook endpoint set to ${serverUrl} (provision via scripts/provision-test-client.mjs).`,
    );
  } catch (err) {
    const msg = `Failed to start local webhook server: ${err instanceof Error ? err.message : String(err)}`;
    addMessage(ctx, msg);
    addGap(ctx, msg);
    const report = buildReport(ctx, 'failed', { error: msg });
    finalizeAndSave(report, cfg.test.outputDir);
    return report;
  }

  const cashyin = new CashyinClient({
    baseUrl: cfg.cashyin.baseUrl,
    apiKey: cfg.cashyin.apiKey,
    timeoutMs: cfg.cashyin.timeoutMs,
    onRequest: (r) => {
      recordRequest(ctx, r);
      console.log(`  [cashyin] ${r.method} ${r.url.replace(cfg.cashyin.baseUrl, '')} → ${r.responseStatus} (${r.latencyMs}ms)`);
    },
  });

  // ── Dry-run: just verify the server starts and stop ───────────────────────

  if (ctx.dryRun) {
    addMessage(ctx, 'DRY RUN: Local webhook server started successfully. Pass --execute-real-payment to run full scenario.');
    await webhookServer.stop();
    const report = buildReport(ctx, 'dry_run', {
      latency: { totalMs: Math.round(performance.now() - t0Total) },
    });
    finalizeAndSave(report, cfg.test.outputDir);
    return report;
  }

  // ── Guard ─────────────────────────────────────────────────────────────────

  try {
    assertRealPaymentAllowed(cfg, amountCents);
  } catch (err) {
    await webhookServer.stop();
    const report = buildReport(ctx, 'failed', { error: String(err) });
    finalizeAndSave(report, cfg.test.outputDir);
    return report;
  }

  // ── Create charge ─────────────────────────────────────────────────────────

  const externalRef = generateExternalRef('e2e-fyhub-wh-latency');
  ctx.timings.t0_charge_create_requested = now();
  const t0Create = performance.now();

  let charge;
  try {
    const result = await cashyin.createCashInCharge(
      amountCents,
      externalRef,
      `CashYin E2E webhook-latency ${ctx.correlationId}`,
    );
    charge = result.data;
    ctx.timings.t1_charge_create_response = now();
    ctx.timings.createChargeMs = Math.round(performance.now() - t0Create);
    addMessage(ctx, `Charge created: txid=${charge.txid}`);
  } catch (err) {
    await webhookServer.stop();
    const report = buildReport(ctx, 'failed', {
      error: err instanceof Error ? err.message : String(err),
    });
    finalizeAndSave(report, cfg.test.outputDir);
    return report;
  }

  // ── Pay via Fyhub ─────────────────────────────────────────────────────────

  const cert = loadCert(cfg.fyhub.certPath, cfg.fyhub.certZipPath, cfg.fyhub.certPassword);
  const fyhub = new FyhubClient({
    baseUrl: cfg.fyhub.baseUrl,
    clientId: cfg.fyhub.clientId,
    clientSecret: cfg.fyhub.clientSecret,
    cert,
    timeoutMs: cfg.fyhub.timeoutMs,
    onRequest: (r) => {
      recordRequest(ctx, r);
      console.log(`  [fyhub]   ${r.method} ${r.url.replace(cfg.fyhub.baseUrl, '')} → ${r.responseStatus} (${r.latencyMs}ms)`);
    },
  });

  ctx.timings.t2_fyhub_payment_requested = now();
  const t0Pay = performance.now();
  const t0AfterPay = Date.now();

  try {
    await fyhub.payQrCode(charge.pix.emv!, centsToBrl(amountCents), {
      description: `E2E webhook-latency ${ctx.correlationId}`,
      idempotencyKey: generateIdempotencyKey().slice(0, 48),
    });
    ctx.timings.t3_fyhub_payment_response = now();
    ctx.timings.fyhubPayMs = Math.round(performance.now() - t0Pay);
  } catch (err) {
    await webhookServer.stop();
    await fyhub.destroy();
    const report = buildReport(ctx, 'failed', {
      error: err instanceof Error ? err.message : String(err),
      ids: { txid: charge.txid, external_ref: externalRef },
    });
    finalizeAndSave(report, cfg.test.outputDir);
    return report;
  }

  // ── Poll for CashYin status ────────────────────────────────────────────────

  const t0Poll = performance.now();
  process.stdout.write('  polling status ');
  const { data: finalCharge, attempts, timedOut, pollMs } = await cashyin.pollCashInUntilTerminal(
    charge.txid,
    {
      timeoutSecs: cfg.test.pollTimeoutSecs,
      intervalSecs: cfg.test.pollIntervalSecs,
      onPoll: (status) => process.stdout.write(status === 'pending' ? '.' : ` [${status}]`),
    },
  );
  console.log('');
  ctx.timings.t5_charge_marked_paid = finalCharge.paid_at ?? undefined;
  ctx.timings.pollToConfirmedMs = pollMs;

  // ── Wait for outbound webhook ─────────────────────────────────────────────

  const webhookTimeoutMs = 30_000;
  addMessage(ctx, `Waiting up to ${webhookTimeoutMs / 1000}s for outbound webhook...`);
  const t0Wh = performance.now();
  const { events, timedOut: whTimedOut } = await webhookServer.waitForEvents(1, webhookTimeoutMs);
  const webhookDeliveryMs = Math.round(performance.now() - t0Wh);

  if (events.length > 0) {
    ctx.timings.t7_client_webhook_received = events[0].receivedAt;
    ctx.timings.webhookDeliveryMs = webhookDeliveryMs;
    addMessage(ctx, `Outbound webhook received after ${webhookDeliveryMs}ms (total from payment: ${Date.now() - t0AfterPay}ms)`);

    const whBody = events[0].body as Record<string, unknown> | null;
    if (whBody) {
      assert(ctx, 'Webhook body has txid', 'txid' in whBody, String(whBody['txid'] ?? 'missing'));
      assert(ctx, 'Webhook txid matches', whBody['txid'] === charge.txid);
      assert(ctx, 'No provider_charge_id in webhook', !('provider_charge_id' in whBody));
      assert(ctx, 'No provider internal id in webhook', !('providerChargeId' in whBody) && !('provider_charge_id' in whBody));
    }
  } else {
    addGap(ctx, `No outbound webhook received within ${webhookTimeoutMs / 1000}s. ` +
      'Ensure the test client webhook endpoint is set to the local server URL. ' +
      'Outbound webhook delivery depends on the dispatcher worker running.');
    ctx.timings.webhookDeliveryMs = undefined;
  }

  await webhookServer.stop();
  await fyhub.destroy();

  // ── Assertions and report ─────────────────────────────────────────────────

  const paid = finalCharge.status === 'paid';
  assert(ctx, 'Charge paid', paid, finalCharge.status);
  assert(ctx, 'Poll did not time out', !timedOut);
  assert(ctx, 'Webhook received', events.length > 0);

  const totalMs = Math.round(performance.now() - t0Total);
  const result = paid ? (events.length > 0 ? 'passed' : 'partial') : 'failed';

  const report = buildReport(ctx, result, {
    ids: { txid: finalCharge.txid, external_ref: externalRef, e2e_id: finalCharge.pix.e2e_id ?? undefined },
    latency: {
      createChargeMs: ctx.timings.createChargeMs,
      fyhubPayMs: ctx.timings.fyhubPayMs,
      pollToConfirmedMs: pollMs,
      webhookDeliveryMs: ctx.timings.webhookDeliveryMs,
      totalMs,
      pollAttempts: attempts,
    },
    error: !paid ? `Charge not paid: ${finalCharge.status}` : undefined,
  });

  finalizeAndSave(report, cfg.test.outputDir);
  return report;
}
