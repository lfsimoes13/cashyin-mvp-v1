/**
 * Scenario 2: Cash-out CashYin → Bents → Fyhub PIX key.
 *
 * Flow:
 *   1. Get CashYin balance (before)
 *   2. Create a cash-out via CashYin API using FYHUB_RECEIVER_PIX_KEY
 *   3. Poll until completed/failed/returned
 *   4. Get CashYin balance (after)
 *   5. Validate: id, providerPaymentId, e2eId, fees, balance delta
 *
 * Run (dry-run):
 *   pnpm e2e:fyhub:cashout
 *
 * Run (real):
 *   REAL_PAYMENT_TESTS_ENABLED=true pnpm e2e:fyhub:cashout -- --execute-real-payment
 */

import type { E2EConfig } from '../config.js';
import { CashyinClient, generateExternalRef, generateIdempotencyKey } from '../cashyin.client.js';
import {
  createContext,
  assert,
  addMessage,
  addGap,
  buildReport,
  finalizeAndSave,
  assertRealPaymentAllowed,
  assertAmountWithinLimit,
  now,
  printPreRunSummary,
  recordRequest,
} from '../scenario-runner.js';
import type { PublicCashOutResponse, ScenarioReport } from '../types.js';

export async function runCashOutScenario(cfg: E2EConfig, amountCents: number): Promise<ScenarioReport> {
  const ctx = createContext('cashout-to-fyhub-pix-key', cfg, amountCents);

  printPreRunSummary(ctx);

  try {
    assertAmountWithinLimit(cfg, amountCents);
  } catch (err) {
    const report = buildReport(ctx, 'failed', { error: String(err) });
    finalizeAndSave(report, cfg.test.outputDir);
    return report;
  }

  // Fail early (before ANY request) when the required public `pix_key_type`
  // is not configured. The deployed contract rejects a cash-out without it,
  // and we never silently infer it from the key shape.
  const pixKeyType = cfg.cashyin.cashOutPixKeyType;
  if (!pixKeyType) {
    addMessage(
      ctx,
      'CASHYIN_CASHOUT_PIX_KEY_TYPE is not set — required by POST /v1/pix/cash-out.'
    );
    const report = buildReport(ctx, 'failed', {
      error:
        'CASHYIN_CASHOUT_PIX_KEY_TYPE is required. Set it to the Pix key type of ' +
        'FYHUB_RECEIVER_PIX_KEY (one of CPF|CNPJ|EMAIL|PHONE|EVP) before running the cash-out scenario.',
    });
    finalizeAndSave(report, cfg.test.outputDir);
    return report;
  }

  const cashyin = new CashyinClient({
    baseUrl: cfg.cashyin.baseUrl,
    apiKey: cfg.cashyin.apiKey,
    timeoutMs: cfg.cashyin.timeoutMs,
    onRequest: (r) => {
      recordRequest(ctx, r);
      console.log(`  [cashyin] ${r.method} ${r.url.replace(cfg.cashyin.baseUrl, '')} → ${r.responseStatus} (${r.latencyMs}ms)`);
    },
  });

  const t0Total = performance.now();

  // ── Balance before ────────────────────────────────────────────────────────

  let balanceBefore = 0;
  try {
    const { parsed } = await cashyin.getBalance();
    balanceBefore = parsed?.available_balance ?? 0;
    addMessage(ctx, `Balance before: ${balanceBefore} cents`);
  } catch {
    addGap(ctx, 'Could not fetch balance before cash-out (insufficient permissions or endpoint error)');
  }

  // ── Dry-run stop ──────────────────────────────────────────────────────────

  if (ctx.dryRun) {
    addMessage(ctx, `DRY RUN: Would send R$ ${(amountCents / 100).toFixed(2)} to PIX key (type=${pixKeyType}): ${cfg.fyhub.receiverPixKey}`);
    addMessage(ctx, 'Pass --execute-real-payment to execute the cash-out.');

    const report = buildReport(ctx, 'dry_run', {
      latency: { totalMs: Math.round(performance.now() - t0Total) },
    });
    finalizeAndSave(report, cfg.test.outputDir);
    return report;
  }

  // ── Guard ─────────────────────────────────────────────────────────────────

  try {
    assertRealPaymentAllowed(cfg, amountCents);
  } catch (err) {
    const report = buildReport(ctx, 'failed', { error: String(err) });
    finalizeAndSave(report, cfg.test.outputDir);
    return report;
  }

  // ── Create cash-out ───────────────────────────────────────────────────────

  const externalId = generateExternalRef('e2e-fyhub-cashout');
  const idempotencyKey = generateIdempotencyKey();

  addMessage(ctx, `Creating cash-out: ${amountCents} cents → ${cfg.fyhub.receiverPixKey}`);
  ctx.timings.t0_charge_create_requested = now();
  const t0Create = performance.now();

  let cashOut: PublicCashOutResponse | undefined;
  try {
    const result = await cashyin.createCashOut(
      amountCents,
      cfg.fyhub.receiverPixKey,
      pixKeyType,
      externalId,
      idempotencyKey,
      `CashYin E2E cashout ${ctx.correlationId}`,
    );
    cashOut = result.data;
    ctx.timings.t1_charge_create_response = now();
    ctx.timings.createChargeMs = Math.round(performance.now() - t0Create);

    addMessage(ctx, `Cash-out created: id=${cashOut.id}, status=${cashOut.status}, http=${result.status}`);
    // HTTP semantics: 201 for a newly-created resource (whether the provider
    // settled synchronously → `completed`, or only accepted it → `processing`).
    assert(ctx, 'Created with HTTP 201', result.status === 201, `http=${result.status}`);
    assert(ctx, 'Cash-out created', ['processing', 'completed'].includes(cashOut.status), cashOut.status);
    assert(ctx, 'id present', !!cashOut.id);
    assert(ctx, 'no type field on public response', !('type' in cashOut));
    assert(ctx, 'external_ref matches', cashOut.external_ref === externalId, `got=${cashOut.external_ref}`);
    assert(ctx, 'amount matches (cents)', cashOut.amount === amountCents, `got=${cashOut.amount}`);
    assert(ctx, 'currency is BRL', cashOut.currency === 'BRL', String(cashOut.currency));
    assert(ctx, 'pix.key matches', cashOut.pix.key === cfg.fyhub.receiverPixKey);
    assert(ctx, 'pix.key_type matches', cashOut.pix.key_type === pixKeyType, `got=${cashOut.pix.key_type}`);
    assert(ctx, 'receiver object present', !!cashOut.receiver && typeof cashOut.receiver === 'object');
    assert(
      ctx,
      'receiver has all canonical keys',
      ['name', 'document_number', 'bank_name', 'bank_ispb', 'branch', 'account', 'account_type'].every(
        (k) => k in result.data.receiver,
      ),
    );
    assert(ctx, 'created_at present', !!cashOut.created_at);
    assert(ctx, 'No txid in cash-out', !('txid' in cashOut), 'cash-outs do not use txid');
    // Public contract must NOT leak internal fee/cost/margin/provider fields.
    assert(
      ctx,
      'No internal fee/provider fields in public response',
      ![
        'clientFeeCents',
        'providerCostCents',
        'marginCents',
        'totalDebitAmountCents',
        'feeAmountCents',
        'feeAssessmentId',
        'reservationId',
        'providerPaymentId',
        'provider',
        'clientId',
      ].some((k) => k in result.data),
    );
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    addMessage(ctx, `Cash-out creation failed: ${msg}`);
    const report = buildReport(ctx, 'failed', {
      error: msg,
      ids: { cashout_id: undefined },
    });
    finalizeAndSave(report, cfg.test.outputDir);
    return report;
  }

  // ── Poll until terminal ───────────────────────────────────────────────────

  addMessage(ctx, `Polling cash-out status (timeout=${cfg.test.pollTimeoutSecs}s)...`);
  process.stdout.write('  polling ');

  const { data: finalCashOut, attempts, timedOut, pollMs } = await cashyin.pollCashOutUntilTerminal(
    cashOut.id,
    {
      timeoutSecs: cfg.test.pollTimeoutSecs,
      intervalSecs: cfg.test.pollIntervalSecs,
      onPoll: (status) => process.stdout.write(status === 'processing' ? '.' : ` [${status}]`),
    },
  );
  console.log('');
  ctx.timings.pollToConfirmedMs = pollMs;

  const completed = finalCashOut.status === 'completed';
  addMessage(ctx, `Final status: ${finalCashOut.status} (${attempts} polls)`);

  // ── Validate ──────────────────────────────────────────────────────────────

  assert(ctx, 'Cash-out completed', completed, finalCashOut.status);
  assert(ctx, 'Poll did not time out', !timedOut);

  if (completed) {
    // Public-contract terminal assertions (no fee/provider fields are exposed).
    assert(ctx, 'pix.e2e_id populated on completed', !!finalCashOut.pix.e2e_id, finalCashOut.pix.e2e_id ?? 'null');
    assert(ctx, 'completed_at present on completed', !!finalCashOut.completed_at, finalCashOut.completed_at ?? 'null');
    // Null terminal timestamps are omitted (not null) on the new contract.
    assert(ctx, 'failed_at omitted on completed', !('failed_at' in finalCashOut));
    assert(ctx, 'returned_at omitted on completed', !('returned_at' in finalCashOut));

    // Receiver identity is exposed only via the nested `receiver` object;
    // there are no flat `receiver_name`/`receiver_document` mirrors.
    const r = finalCashOut.receiver;
    assert(ctx, 'receiver present on completed', !!r && typeof r === 'object');
    assert(
      ctx,
      'no flat receiver_name/receiver_document on response',
      !('receiver_name' in finalCashOut) && !('receiver_document' in finalCashOut),
    );
    addMessage(
      ctx,
      `Receiver: name=${r.name ?? 'null'}, doc=${r.document_number ?? 'null'}, bank=${r.bank_name ?? 'null'}, ispb=${r.bank_ispb ?? 'null'}`,
    );
  }

  // ── Balance after (informational) ──────────────────────────────────────────
  //
  // Fee/debit composition is no longer on the public cash-out response, so we
  // do NOT assert an exact balance delta here. The expected debit is
  // (amount + configured client fee), but validating it requires a separate
  // path (balance-delta from config, or DATABASE_URL ledger inspection). That
  // is intentionally NOT implemented here — see the gap below.
  let balanceAfter = 0;
  try {
    const { parsed } = await cashyin.getBalance();
    balanceAfter = parsed?.available_balance ?? 0;
    const delta = balanceBefore - balanceAfter;
    const expectedDebit = amountCents + cfg.pricing.cashOut.customerFeeAmount;
    addMessage(ctx, `Balance after: ${balanceAfter} cents (delta -${delta}, expected ~${expectedDebit} = amount + configured fee)`);
  } catch {
    addGap(ctx, 'Could not fetch balance after cash-out');
  }
  addGap(
    ctx,
    'Fee/debit validation not asserted: the public cash-out response no longer exposes ' +
      'clientFeeCents/providerCostCents/marginCents/totalDebitAmountCents. A separate ' +
      'balance-delta (amount + configured fee) or DATABASE_URL ledger-inspection check is ' +
      'required and is intentionally not implemented here.',
  );

  // ── Report ────────────────────────────────────────────────────────────────

  const totalMs = Math.round(performance.now() - t0Total);
  const result = completed ? 'passed' : timedOut ? 'partial' : 'failed';

  const report = buildReport(ctx, result, {
    ids: {
      cashout_id: finalCashOut.id,
      e2e_id: finalCashOut.pix.e2e_id ?? undefined,
    },
    latency: {
      createChargeMs: ctx.timings.createChargeMs,
      pollToConfirmedMs: pollMs,
      totalMs,
      pollAttempts: attempts,
    },
    error: !completed ? `Cash-out did not complete: ${finalCashOut.status}` : undefined,
  });

  finalizeAndSave(report, cfg.test.outputDir);
  return report;
}
