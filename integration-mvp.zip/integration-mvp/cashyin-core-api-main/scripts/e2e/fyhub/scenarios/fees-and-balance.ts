/**
 * Scenario 6: Fees, tarifas, and balance validation.
 *
 * What is measured:
 *   - Fyhub balance (before / after cash-out payment)
 *   - CashYin balance (before / after operations)
 *   - Cash-out: public contract fields (amount, pix_key_type, status, e2e_id…)
 *   - Fees: NOT exposed in any public API response (cash-in OR cash-out).
 *     Fee/cost/margin/total-debit live only in internal fee_assessments.
 *
 * API gaps (as of 2026-05, deployed contract 6d3c570):
 *   - Cash-in AND cash-out responses do NOT expose fee/cost/margin/total-debit.
 *   - No dedicated CashYin fee query endpoint.
 *   - fee_assessments table is internal only.
 *   - Ledger entries (double-entry accounting) are not queryable via REST.
 *   - Fee verification therefore needs a balance-delta (amount + configured
 *     fee) or DATABASE_URL ledger-inspection path — not the public response.
 *
 * Run (balance check only, safe):
 *   pnpm e2e:fyhub:fees-balance
 *
 * Run with cash-out fee verification (real payment):
 *   REAL_PAYMENT_TESTS_ENABLED=true \
 *   pnpm e2e:fyhub:fees-balance -- --execute-real-payment
 */

import type { E2EConfig } from '../config.js';
import { loadCert } from '../certificate-loader.js';
import { FyhubClient } from '../fyhub.client.js';
import { CashyinClient, generateExternalRef, generateIdempotencyKey } from '../cashyin.client.js';
import {
  createContext,
  assert,
  addMessage,
  addGap,
  buildReport,
  finalizeAndSave,
  assertRealPaymentAllowed,
  assertAmountWithinLimit,
  printPreRunSummary,
  recordRequest,
} from '../scenario-runner.js';
import type { PublicCashOutResponse, ScenarioReport } from '../types.js';

export async function runFeesAndBalanceScenario(
  cfg: E2EConfig,
  amountCents: number,
): Promise<ScenarioReport> {
  const ctx = createContext('fees-and-balance', cfg, amountCents);

  printPreRunSummary(ctx);

  const t0Total = performance.now();

  // ── Build Fyhub client ─────────────────────────────────────────────────────

  let fyhub: FyhubClient | null = null;
  try {
    const cert = loadCert(cfg.fyhub.certPath, cfg.fyhub.certZipPath, cfg.fyhub.certPassword);
    fyhub = new FyhubClient({
      baseUrl: cfg.fyhub.baseUrl,
      clientId: cfg.fyhub.clientId,
      clientSecret: cfg.fyhub.clientSecret,
      cert,
      timeoutMs: cfg.fyhub.timeoutMs,
      onRequest: (r) => {
        recordRequest(ctx, r);
        console.log(`  [fyhub]   ${r.method} ${r.url.replace(cfg.fyhub.baseUrl, '')} → ${r.responseStatus} (${r.latencyMs}ms)`);
      },
    });
  } catch (err) {
    addMessage(ctx, `Failed to load Fyhub cert: ${err instanceof Error ? err.message : String(err)}`);
    addGap(ctx, 'Fyhub mTLS cert unavailable — skipping Fyhub balance checks');
  }

  const cashyin = new CashyinClient({
    baseUrl: cfg.cashyin.baseUrl,
    apiKey: cfg.cashyin.apiKey,
    timeoutMs: cfg.cashyin.timeoutMs,
    onRequest: (r) => {
      recordRequest(ctx, r);
      console.log(`  [cashyin] ${r.method} ${r.url.replace(cfg.cashyin.baseUrl, '')} → ${r.responseStatus} (${r.latencyMs}ms)`);
    },
  });

  // ── Fyhub balance (before) ─────────────────────────────────────────────────

  let fyhubBalanceBefore = 0;
  if (fyhub) {
    try {
      const { data } = await fyhub.getBalance();
      fyhubBalanceBefore = data ? data.balanceAmount.available : 0;
      addMessage(ctx, `Fyhub balance (before): R$ ${fyhubBalanceBefore.toFixed(2)}`);
      assert(ctx, 'Fyhub balance readable', true, `R$ ${fyhubBalanceBefore.toFixed(2)}`);
    } catch (err) {
      addMessage(ctx, `Fyhub balance failed: ${err instanceof Error ? err.message : String(err)}`);
      addGap(ctx, 'Could not fetch Fyhub balance');
    }
  }

  // ── CashYin balance (before) ───────────────────────────────────────────────

  let cashyinBalanceBefore = 0;
  try {
    const { parsed } = await cashyin.getBalance();
    cashyinBalanceBefore = parsed?.available_balance ?? 0;
    addMessage(ctx, `CashYin balance (before): ${cashyinBalanceBefore} cents`);
    assert(ctx, 'CashYin balance readable', true, `${cashyinBalanceBefore} cents`);
  } catch (err) {
    addMessage(ctx, `CashYin balance failed: ${err instanceof Error ? err.message : String(err)}`);
    addGap(ctx, 'Could not fetch CashYin balance — check API key permissions');
  }

  // ── Documented gaps for cash-in ───────────────────────────────────────────

  addGap(ctx, 'Cash-in: fee data is NOT returned in the public API response. Fees are stored internally in fee_assessments table only.');
  addGap(ctx, 'Cash-in: no public endpoint to query applied fees or commission rules for a given charge.');
  addGap(ctx, 'Ledger: double-entry accounting ledger (client_liability, provider_pool) is not queryable via REST API.');

  // ── If dry-run: report balance snapshot and gaps ───────────────────────────

  if (ctx.dryRun) {
    addMessage(ctx, 'DRY RUN: Balance snapshot complete. Pass --execute-real-payment to run fee verification via cash-out.');
    const report = buildReport(ctx, 'dry_run', {
      latency: { totalMs: Math.round(performance.now() - t0Total) },
    });
    finalizeAndSave(report, cfg.test.outputDir);
    if (fyhub) await fyhub.destroy();
    return report;
  }

  // ── Guard ─────────────────────────────────────────────────────────────────

  try {
    assertAmountWithinLimit(cfg, amountCents);
    assertRealPaymentAllowed(cfg, amountCents);
  } catch (err) {
    const report = buildReport(ctx, 'failed', { error: String(err) });
    finalizeAndSave(report, cfg.test.outputDir);
    if (fyhub) await fyhub.destroy();
    return report;
  }

  // Required public `pix_key_type` — fail early (before the request) if unset.
  const pixKeyType = cfg.cashyin.cashOutPixKeyType;
  if (!pixKeyType) {
    const report = buildReport(ctx, 'failed', {
      error:
        'CASHYIN_CASHOUT_PIX_KEY_TYPE is required for the cash-out request. ' +
        'Set it (CPF|CNPJ|EMAIL|PHONE|EVP) to match FYHUB_RECEIVER_PIX_KEY.',
    });
    finalizeAndSave(report, cfg.test.outputDir);
    if (fyhub) await fyhub.destroy();
    return report;
  }

  // ── Cash-out to observe balance movement ───────────────────────────────────

  addMessage(ctx, `Creating cash-out to Fyhub PIX key to observe balance movement...`);
  const externalId = generateExternalRef('e2e-fees-cashout');

  let cashOut: PublicCashOutResponse | undefined;
  try {
    const result = await cashyin.createCashOut(
      amountCents,
      cfg.fyhub.receiverPixKey,
      pixKeyType,
      externalId,
      generateIdempotencyKey(),
      `E2E fees-balance ${ctx.correlationId}`,
    );
    cashOut = result.data;
    addMessage(ctx, `Cash-out created: id=${cashOut.id}, status=${cashOut.status}, http=${result.status}`);

    // The PUBLIC contract intentionally exposes NO fee/cost/margin/total-debit.
    // Validate the public shape instead, and record the fee-validation gap.
    assert(ctx, 'Created with HTTP 201', result.status === 201, `http=${result.status}`);
    assert(ctx, 'amount matches (cents)', cashOut.amount === amountCents, `got=${cashOut.amount}`);
    assert(ctx, 'pix.key_type matches', cashOut.pix.key_type === pixKeyType, `got=${cashOut.pix.key_type}`);
    assert(ctx, 'external_ref matches', cashOut.external_ref === externalId, `got=${cashOut.external_ref}`);
    assert(
      ctx,
      'No internal fee fields leak in public response',
      !['clientFeeCents', 'providerCostCents', 'marginCents', 'totalDebitAmountCents', 'feeAssessmentId'].some(
        (k) => k in result.data,
      ),
    );
    addGap(
      ctx,
      'Cash-out fees are NOT in the public response (clientFee/providerCost/margin/totalDebit). ' +
        'Validate via balance-delta (amount + configured fee) or DATABASE_URL ledger inspection. ' +
        `Configured expectation for reference: fee=${cfg.pricing.cashOut.customerFeeAmount}c, ` +
        `providerCost=${cfg.pricing.cashOut.providerCostAmount}c.`,
    );
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    addMessage(ctx, `Cash-out creation failed: ${msg}`);
    assert(ctx, 'Cash-out created for balance inspection', false, msg);
  }

  // ── Poll and get final state ───────────────────────────────────────────────

  if (cashOut) {
    process.stdout.write('  polling ');
    const { data: finalCO, timedOut } = await cashyin.pollCashOutUntilTerminal(cashOut.id, {
      timeoutSecs: cfg.test.pollTimeoutSecs,
      intervalSecs: cfg.test.pollIntervalSecs,
      onPoll: (s) => process.stdout.write(s === 'processing' ? '.' : ` [${s}]`),
    });
    console.log('');
    assert(ctx, 'Cash-out completed', finalCO.status === 'completed', finalCO.status);
    assert(ctx, 'Poll did not time out', !timedOut);
    if (finalCO.pix.e2e_id) {
      addMessage(ctx, `e2e_id: ${finalCO.pix.e2e_id}`);
    }
  }

  // ── Balances after ─────────────────────────────────────────────────────────

  await sleep(2000); // brief settle before reading post-operation balances

  if (fyhub) {
    try {
      const { data } = await fyhub.getBalance();
      const after = data ? data.balanceAmount.available : 0;
      const delta = after - fyhubBalanceBefore;
      addMessage(ctx, `Fyhub balance after: R$ ${after.toFixed(2)} (delta: ${delta > 0 ? '+' : ''}${delta.toFixed(2)})`);
    } catch {
      addGap(ctx, 'Could not fetch Fyhub balance after operation');
    }
    await fyhub.destroy();
  }

  try {
    const { parsed } = await cashyin.getBalance();
    const after = parsed?.available_balance ?? 0;
    const delta = after - cashyinBalanceBefore;
    const expectedDebit = amountCents + cfg.pricing.cashOut.customerFeeAmount;
    addMessage(
      ctx,
      `CashYin balance after: ${after} cents (delta: ${delta}; expected ~-${expectedDebit} = amount + configured fee)`,
    );
    // Informational only: exact debit (= amount + client fee) is not derivable
    // from the public response, so we do not hard-assert the delta here.
  } catch {
    addGap(ctx, 'Could not fetch CashYin balance after operation');
  }

  // ── Report ────────────────────────────────────────────────────────────────

  const totalMs = Math.round(performance.now() - t0Total);
  const allPassed = ctx.assertions.every((a) => a.passed);
  const result = allPassed ? 'passed' : 'partial';

  const report = buildReport(ctx, result, {
    ids: { cashout_id: cashOut?.id },
    latency: { totalMs },
  });

  finalizeAndSave(report, cfg.test.outputDir);
  return report;
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
