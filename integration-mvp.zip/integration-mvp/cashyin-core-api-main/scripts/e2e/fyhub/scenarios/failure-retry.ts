/**
 * Scenario 5: Webhook delivery failures and retries.
 *
 * Tests the CashYin outbox dispatcher retry logic by:
 *   1. Starting a local webhook server
 *   2. Configuring it to respond with 500 for the first N requests
 *   3. After a real cash-in is paid, verifying the dispatcher retries
 *   4. Switching the server to 200 and verifying eventual delivery
 *   5. Reporting retry count, delivery latency, and final status
 *
 * NOTE: This scenario requires that the test client's webhook endpoint
 * points to the local server (provision via scripts/provision-test-client.mjs).
 * The CashYin API does NOT expose an outbox/retry management endpoint,
 * so we observe retry behavior by receiving events at the local server.
 *
 * DLQ testing: The dispatcher marks events as `dlq` after exhausting
 * retries (default 8 attempts). To trigger DLQ, keep returning 500 until
 * all retry attempts are consumed. This scenario only validates the
 * success path after initial failures.
 *
 * Run (dry-run):
 *   pnpm e2e:fyhub:failure-retry
 *
 * Run (real):
 *   REAL_PAYMENT_TESTS_ENABLED=true \
 *   pnpm e2e:fyhub:failure-retry -- --execute-real-payment
 */

import type { E2EConfig } from '../config.js';
import { loadCert } from '../certificate-loader.js';
import { FyhubClient, centsToBrl } from '../fyhub.client.js';
import { CashyinClient, generateExternalRef } from '../cashyin.client.js';
import { LocalWebhookServer } from '../webhook-server.js';
import {
  createContext,
  assert,
  addMessage,
  addGap,
  buildReport,
  finalizeAndSave,
  assertRealPaymentAllowed,
  assertAmountWithinLimit,
  now,
  printPreRunSummary,
  recordRequest,
} from '../scenario-runner.js';
import type { ScenarioReport } from '../types.js';

/** How many initial 500s to serve before switching to 200 */
const INITIAL_FAILURE_COUNT = 2;

export async function runFailureRetryScenario(
  cfg: E2EConfig,
  amountCents: number,
): Promise<ScenarioReport> {
  const ctx = createContext('failure-retry', cfg, amountCents);

  printPreRunSummary(ctx);
  addMessage(ctx, `Strategy: return HTTP 500 for first ${INITIAL_FAILURE_COUNT} webhook deliveries, then 200`);

  try {
    assertAmountWithinLimit(cfg, amountCents);
  } catch (err) {
    const report = buildReport(ctx, 'failed', { error: String(err) });
    finalizeAndSave(report, cfg.test.outputDir);
    return report;
  }

  const t0Total = performance.now();

  // ── Start webhook server with forced 500s ─────────────────────────────────

  const webhookServer = new LocalWebhookServer({
    port: cfg.test.webhookServerPort,
    forceResponseStatus: 500,
  });

  let serverUrl: string;
  try {
    serverUrl = await webhookServer.start();
    addMessage(ctx, `Local webhook server at ${serverUrl} — initially returning 500`);
  } catch (err) {
    const report = buildReport(ctx, 'failed', {
      error: `Webhook server failed to start: ${err instanceof Error ? err.message : String(err)}`,
    });
    finalizeAndSave(report, cfg.test.outputDir);
    return report;
  }

  if (ctx.dryRun) {
    addMessage(ctx, 'DRY RUN: Pass --execute-real-payment to run full failure-retry scenario.');
    addGap(ctx, 'Retry behavior depends on outbox dispatcher worker being reachable from the test environment.');
    await webhookServer.stop();
    const report = buildReport(ctx, 'dry_run', {
      latency: { totalMs: Math.round(performance.now() - t0Total) },
    });
    finalizeAndSave(report, cfg.test.outputDir);
    return report;
  }

  try {
    assertRealPaymentAllowed(cfg, amountCents);
  } catch (err) {
    await webhookServer.stop();
    const report = buildReport(ctx, 'failed', { error: String(err) });
    finalizeAndSave(report, cfg.test.outputDir);
    return report;
  }

  const cashyin = new CashyinClient({
    baseUrl: cfg.cashyin.baseUrl,
    apiKey: cfg.cashyin.apiKey,
    timeoutMs: cfg.cashyin.timeoutMs,
    onRequest: (r) => {
      recordRequest(ctx, r);
      console.log(`  [cashyin] ${r.method} ${r.url.replace(cfg.cashyin.baseUrl, '')} → ${r.responseStatus} (${r.latencyMs}ms)`);
    },
  });

  // ── Create charge ─────────────────────────────────────────────────────────

  const externalRef = generateExternalRef('e2e-fyhub-retry');
  let charge;

  try {
    const result = await cashyin.createCashInCharge(
      amountCents,
      externalRef,
      `CashYin E2E failure-retry ${ctx.correlationId}`,
    );
    charge = result.data;
    ctx.timings.createChargeMs = result.latencyMs;
    addMessage(ctx, `Charge created: txid=${charge.txid}`);
  } catch (err) {
    await webhookServer.stop();
    const report = buildReport(ctx, 'failed', {
      error: err instanceof Error ? err.message : String(err),
    });
    finalizeAndSave(report, cfg.test.outputDir);
    return report;
  }

  // ── Pay via Fyhub ─────────────────────────────────────────────────────────

  const cert = loadCert(cfg.fyhub.certPath, cfg.fyhub.certZipPath, cfg.fyhub.certPassword);
  const fyhub = new FyhubClient({
    baseUrl: cfg.fyhub.baseUrl,
    clientId: cfg.fyhub.clientId,
    clientSecret: cfg.fyhub.clientSecret,
    cert,
    timeoutMs: cfg.fyhub.timeoutMs,
    onRequest: (r) => {
      recordRequest(ctx, r);
      console.log(`  [fyhub]   ${r.method} ${r.url.replace(cfg.fyhub.baseUrl, '')} → ${r.responseStatus} (${r.latencyMs}ms)`);
    },
  });

  try {
    await fyhub.payQrCode(charge.pix.emv!, centsToBrl(amountCents), {
      description: `E2E failure-retry ${ctx.correlationId}`,
    });
    ctx.timings.fyhubPayMs = Math.round(performance.now() - t0Total);
  } catch (err) {
    await webhookServer.stop();
    await fyhub.destroy();
    const report = buildReport(ctx, 'failed', {
      error: err instanceof Error ? err.message : String(err),
    });
    finalizeAndSave(report, cfg.test.outputDir);
    return report;
  }

  // ── Wait for initial failure deliveries ───────────────────────────────────

  addMessage(ctx, `Waiting for ${INITIAL_FAILURE_COUNT} failed deliveries (server returning 500)...`);
  const failureWaitMs = 60_000; // give dispatcher time to attempt and backoff
  await webhookServer.waitForEvents(INITIAL_FAILURE_COUNT, failureWaitMs);

  const failedEvents = [...webhookServer.getEvents()];
  addMessage(ctx, `Received ${failedEvents.length} webhook attempts with 500 responses`);
  assert(ctx, `Dispatcher attempted delivery (got ${failedEvents.length} attempts)`, failedEvents.length > 0);

  // ── Switch server to 200 and wait for success ─────────────────────────────

  addMessage(ctx, 'Switching webhook server to HTTP 200...');
  webhookServer.setResponseStatus(200);

  const successWaitMs = 120_000;
  addMessage(ctx, `Waiting up to ${successWaitMs / 1000}s for successful retry...`);

  // We need one MORE delivery after the switch
  const totalBefore = failedEvents.length;
  const { events: allEvents, timedOut: whTimedOut } = await webhookServer.waitForEvents(
    totalBefore + 1,
    successWaitMs,
  );

  const successEvents = allEvents.slice(totalBefore);
  const retrySucceeded = successEvents.length > 0;

  assert(ctx, 'Dispatcher retried after failure', retrySucceeded, retrySucceeded ? 'yes' : 'no retry received');
  assert(ctx, 'Webhook eventually delivered', retrySucceeded);

  if (retrySucceeded) {
    const whBody = successEvents[0].body as Record<string, unknown> | null;
    if (whBody) {
      assert(ctx, 'Successful webhook has txid', 'txid' in whBody, String(whBody['txid'] ?? 'missing'));
    }
    addMessage(ctx, `Retry succeeded after ${failedEvents.length} failed attempt(s)`);
    addMessage(ctx, `Total webhook attempts: ${allEvents.length} (${failedEvents.length} failed + ${successEvents.length} succeeded)`);
  } else {
    addMessage(ctx, `No successful retry received within ${successWaitMs / 1000}s`);
    addGap(ctx, 'Retry backoff may be too long for this test window. Check WORKER_*_INTERVAL_MS config.');
  }

  // ── Poll CashYin status ───────────────────────────────────────────────────

  const { data: finalCharge } = await cashyin.getCashInCharge(charge.txid);
  assert(ctx, 'Charge marked paid', finalCharge.status === 'paid', finalCharge.status);

  await webhookServer.stop();
  await fyhub.destroy();

  const totalMs = Math.round(performance.now() - t0Total);
  const result = retrySucceeded && finalCharge.status === 'paid' ? 'passed' : 'partial';

  const report = buildReport(ctx, result, {
    ids: { txid: charge.txid, external_ref: externalRef },
    latency: {
      createChargeMs: ctx.timings.createChargeMs,
      fyhubPayMs: ctx.timings.fyhubPayMs,
      totalMs,
    },
  });

  finalizeAndSave(report, cfg.test.outputDir);
  return report;
}
