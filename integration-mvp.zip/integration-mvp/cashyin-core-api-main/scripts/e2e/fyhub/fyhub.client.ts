/**
 * Fyhub API client for E2E tests.
 *
 * Endpoints (verified from live Fyhub OpenAPI spec, 2026-05):
 *   Auth:     POST /oauth/token            → { accessToken, expiresAt (unix), tokenType }
 *   Pay QRC:  POST /pix/payments/qrc       → 202 { endToEndId, id, payment, type }
 *   Pay key:  POST /pix/payments/dict      → 202 { endToEndId, id, payment, type }
 *   Balance:  GET  /accounts/balances/     → { data: [{ balanceAmount: { available, blocked } }] }
 *
 * Amount convention: Fyhub expects BRL float (NOT cents).
 *   R$ 1,00 = amount: 1.00
 *
 * mTLS: all PIX cash-out endpoints require the ACCOUNTS PFX certificate.
 * The auth endpoint (OAuth) also accepts the mTLS agent.
 *
 * Idempotency: POST /pix/payments/* requires `x-idempotency-key: [a-zA-Z0-9]{1,50}`
 *
 * SECURITY: This client NEVER logs tokens, cert content, or passphrase.
 */

import { randomBytes } from 'node:crypto';
import { Agent, fetch } from 'undici';
import type { CertBundle } from './certificate-loader.js';
import { redactHeaders, redactObject } from './redact.js';
import type {
  FyhubBalance,
  FyhubDictPaymentRequest,
  FyhubPaymentResponse,
  FyhubQrcPaymentRequest,
  FyhubTokenResponse,
  RedactedRequest,
} from './types.js';

// ─── Types ────────────────────────────────────────────────────────────────────

export interface FyhubClientOptions {
  baseUrl: string;
  clientId: string;
  clientSecret: string;
  cert: CertBundle;
  timeoutMs?: number;
  onRequest?: (r: RedactedRequest) => void;
}

// ─── Client ───────────────────────────────────────────────────────────────────

export class FyhubClient {
  private readonly baseUrl: string;
  private readonly clientId: string;
  private readonly clientSecret: string;
  private readonly agent: Agent;
  private readonly timeoutMs: number;
  private readonly onRequest?: (r: RedactedRequest) => void;

  private cachedToken: string | null = null;
  private tokenExpiresAtMs = 0;

  constructor(opts: FyhubClientOptions) {
    this.baseUrl = opts.baseUrl.replace(/\/$/, '');
    this.clientId = opts.clientId;
    this.clientSecret = opts.clientSecret;
    this.timeoutMs = opts.timeoutMs ?? 30_000;
    if (opts.onRequest !== undefined) this.onRequest = opts.onRequest;

    this.agent = new Agent({
      connect: {
        pfx: opts.cert.pfx,
        passphrase: opts.cert.passphrase,
        rejectUnauthorized: true,
      },
      connectTimeout: this.timeoutMs,
    });
  }

  // ─── Auth (cached) ─────────────────────────────────────────────────────────

  async getToken(): Promise<string> {
    const now = Date.now();
    if (this.cachedToken && now < this.tokenExpiresAtMs - 30_000) {
      return this.cachedToken;
    }

    const url = `${this.baseUrl}/oauth/token`;
    const body = JSON.stringify({
      clientId: this.clientId,
      clientSecret: this.clientSecret, // kept out of logs by redactObject
      grantType: 'client_credentials',
      scope: 'pix.write pix.read account.read',
    });

    const t0 = performance.now();
    let responseStatus: number | undefined;
    let responseBody: unknown;

    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body,
        dispatcher: this.agent,
        signal: AbortSignal.timeout(this.timeoutMs),
      });

      responseStatus = res.status;
      responseBody = await res.json();
      const latencyMs = Math.round(performance.now() - t0);

      this.onRequest?.({
        label: 'fyhub:auth',
        method: 'POST',
        url,
        requestBodyRedacted: { clientId: this.clientId, grantType: 'client_credentials' },
        responseStatus,
        responseBodyRedacted: redactObject(responseBody),
        latencyMs,
      });

      if (res.status !== 200 && res.status !== 202) {
        throw new FyhubApiError(`Fyhub auth failed: HTTP ${res.status}`, res.status, responseBody);
      }

      const data = responseBody as FyhubTokenResponse;
      if (!data.accessToken) {
        throw new FyhubApiError('Fyhub auth response missing accessToken', res.status, data);
      }

      this.cachedToken = data.accessToken;
      // expiresAt is a Unix timestamp in seconds
      this.tokenExpiresAtMs = data.expiresAt ? data.expiresAt * 1000 : now + 1_800_000;
      return this.cachedToken;
    } catch (err) {
      if (err instanceof FyhubApiError) throw err;
      throw new FyhubApiError(
        `Fyhub auth request failed: ${err instanceof Error ? err.message : String(err)}`,
        responseStatus ?? 0,
        responseBody,
      );
    }
  }

  // ─── Base request ──────────────────────────────────────────────────────────

  private async request<T>(
    method: 'GET' | 'POST',
    path: string,
    body?: unknown,
    extraHeaders?: Record<string, string>,
    label?: string,
  ): Promise<{ data: T; latencyMs: number; status: number }> {
    const token = await this.getToken();
    const url = `${this.baseUrl}${path}`;
    const t0 = performance.now();
    let responseStatus: number | undefined;
    let responseBody: unknown;

    try {
      const res = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
          ...extraHeaders,
        },
        ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
        dispatcher: this.agent,
        signal: AbortSignal.timeout(this.timeoutMs),
      });

      responseStatus = res.status;
      responseBody = await res.json().catch(() => ({}));
      const latencyMs = Math.round(performance.now() - t0);

      this.onRequest?.({
        label: label ?? `fyhub:${method} ${path}`,
        method,
        url,
        requestBodyRedacted: body ? redactObject(body) : undefined,
        responseStatus,
        responseBodyRedacted: redactObject(responseBody),
        latencyMs,
      });

      if (res.status !== 200 && res.status !== 202) {
        throw new FyhubApiError(
          `Fyhub ${method} ${path} failed: HTTP ${res.status}`,
          res.status,
          responseBody,
        );
      }

      return { data: responseBody as T, latencyMs, status: res.status };
    } catch (err) {
      if (err instanceof FyhubApiError) throw err;
      throw new FyhubApiError(
        `Fyhub ${method} ${path}: ${err instanceof Error ? err.message : String(err)}`,
        responseStatus ?? 0,
        responseBody,
      );
    }
  }

  // ─── Pay QR code (EMV / "copia e cola") ───────────────────────────────────

  /**
   * POST /pix/payments/qrc
   *
   * Pays a PIX QR code. Amount must be in BRL (float), not cents.
   * R$ 1,00 → amountBrl = 1.00
   */
  async payQrCode(
    qrCode: string,
    amountBrl: number,
    opts?: { description?: string; idempotencyKey?: string },
  ): Promise<{ data: FyhubPaymentResponse; latencyMs: number }> {
    const idempotencyKey = opts?.idempotencyKey ?? mintIdempotencyKey();

    const body: FyhubQrcPaymentRequest = {
      qrCode,
      payment: { currency: 'BRL', amount: amountBrl },
      paymentFlow: 'INSTANT',
      expiration: 600,
    };
    if (opts?.description !== undefined) body.description = opts.description;

    const { data, latencyMs } = await this.request<FyhubPaymentResponse>(
      'POST',
      '/pix/payments/qrc',
      body,
      { 'x-idempotency-key': idempotencyKey },
      'fyhub:payQrCode',
    );

    return { data, latencyMs };
  }

  /**
   * POST /pix/payments/dict
   *
   * Pays to a PIX key (EVP, CPF, CNPJ, phone, email).
   * Amount must be in BRL (float), not cents.
   */
  async payToPixKey(
    pixKey: string,
    amountBrl: number,
    opts?: { description?: string; idempotencyKey?: string },
  ): Promise<{ data: FyhubPaymentResponse; latencyMs: number }> {
    const idempotencyKey = opts?.idempotencyKey ?? mintIdempotencyKey();

    const body: FyhubDictPaymentRequest = {
      pixKey,
      payment: { currency: 'BRL', amount: amountBrl },
      paymentFlow: 'INSTANT',
    };
    if (opts?.description !== undefined) body.description = opts.description;

    const { data, latencyMs } = await this.request<FyhubPaymentResponse>(
      'POST',
      '/pix/payments/dict',
      body,
      { 'x-idempotency-key': idempotencyKey },
      'fyhub:payToPixKey',
    );

    return { data, latencyMs };
  }

  // ─── Account balance ───────────────────────────────────────────────────────

  /**
   * GET /accounts/balances/
   * Returns the most recent balance entry.
   */
  async getBalance(): Promise<{ data: FyhubBalance | null; latencyMs: number }> {
    const { data, latencyMs } = await this.request<{ data: FyhubBalance[] }>(
      'GET',
      '/accounts/balances/',
      undefined,
      undefined,
      'fyhub:getBalance',
    );

    const entries = data?.data ?? [];
    return { data: entries[0] ?? null, latencyMs };
  }

  // ─── Token info ────────────────────────────────────────────────────────────

  /** Decode JWT payload for inspection (no signature verification). */
  getTokenClaims(): Record<string, unknown> | null {
    if (!this.cachedToken) return null;
    try {
      const parts = this.cachedToken.split('.');
      if (parts.length !== 3) return null;
      const part = parts[1] ?? '';
      return JSON.parse(Buffer.from(part, 'base64url').toString('utf-8'));
    } catch {
      return null;
    }
  }

  /** Destroy the mTLS agent (closes keep-alive connections). */
  async destroy(): Promise<void> {
    await this.agent.destroy();
  }
}

// ─── Error class ──────────────────────────────────────────────────────────────

export class FyhubApiError extends Error {
  constructor(
    message: string,
    public readonly httpStatus: number,
    public readonly body?: unknown,
  ) {
    super(message);
    this.name = 'FyhubApiError';
  }
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

/** Mint a valid Fyhub idempotency key: [a-zA-Z0-9]{1,50} */
function mintIdempotencyKey(): string {
  return randomBytes(24).toString('hex').slice(0, 48);
}

/** Convert BRL cents to BRL float (e.g. 100 → 1.00). */
export function centsToBrl(cents: number): number {
  return cents / 100;
}
