#!/usr/bin/env bash
#
# scripts/aws-bootstrap.sh
#
# One-shot bootstrap for the Terraform remote backend. Terraform cannot manage
# the state bucket that stores its own state (chicken-and-egg), so this script
# creates the two prerequisite resources idempotently:
#
#   * An S3 bucket for the Terraform state (versioned, encrypted, public
#     access blocked).
#   * A DynamoDB table for state locking (PAY_PER_REQUEST, so it costs
#     pennies when idle).
#
# Run it once per AWS account/region using a principal that already has
# permission to create S3 buckets, set bucket policies, and create DynamoDB
# tables (in practice: AdministratorAccess for the initial bootstrap, then
# we tighten via Terraform).
#
# Usage:
#   AWS_PROFILE=cashyin-admin AWS_REGION=sa-east-1 bash scripts/aws-bootstrap.sh
#
# Environment overrides:
#   AWS_REGION              default: sa-east-1
#   TF_STATE_BUCKET         default: cashyin-terraform-state-${AWS_REGION}
#   TF_LOCK_TABLE           default: cashyin-terraform-locks
#
# The script is intentionally idempotent: re-running it after a successful
# bootstrap exits 0 without mutating anything. AWS CLI exit codes are
# inspected for the specific "already exists" errors and treated as success.

set -euo pipefail

AWS_REGION="${AWS_REGION:-sa-east-1}"
TF_STATE_BUCKET="${TF_STATE_BUCKET:-cashyin-terraform-state-${AWS_REGION}}"
TF_LOCK_TABLE="${TF_LOCK_TABLE:-cashyin-terraform-locks}"

echo "─── CashYin Terraform backend bootstrap"
echo "    region: $AWS_REGION"
echo "    bucket: $TF_STATE_BUCKET"
echo "    table:  $TF_LOCK_TABLE"
echo ""

# Sanity check: AWS CLI is configured and talks to the right account.
if ! ACCOUNT_ID="$(aws sts get-caller-identity --query Account --output text 2>/dev/null)"; then
  echo "ERROR: aws sts get-caller-identity failed."
  echo "       Configure AWS_PROFILE/AWS_ACCESS_KEY_ID before running this script."
  exit 2
fi
echo "    account: $ACCOUNT_ID"
echo ""

create_bucket() {
  echo "→ S3 bucket $TF_STATE_BUCKET"
  if aws s3api head-bucket --bucket "$TF_STATE_BUCKET" 2>/dev/null; then
    echo "  ✓ already exists, skipping create"
  else
    # us-east-1 is the only region where CreateBucket must NOT include a
    # LocationConstraint. Every other region requires it.
    if [ "$AWS_REGION" = "us-east-1" ]; then
      aws s3api create-bucket --bucket "$TF_STATE_BUCKET" --region "$AWS_REGION" >/dev/null
    else
      aws s3api create-bucket \
        --bucket "$TF_STATE_BUCKET" \
        --region "$AWS_REGION" \
        --create-bucket-configuration LocationConstraint="$AWS_REGION" >/dev/null
    fi
    echo "  ✓ created"
  fi

  echo "  → versioning"
  aws s3api put-bucket-versioning \
    --bucket "$TF_STATE_BUCKET" \
    --versioning-configuration Status=Enabled >/dev/null
  echo "    ✓ enabled"

  echo "  → public access block"
  aws s3api put-public-access-block \
    --bucket "$TF_STATE_BUCKET" \
    --public-access-block-configuration \
      "BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true" >/dev/null
  echo "    ✓ enabled"

  echo "  → default encryption (SSE-S3)"
  aws s3api put-bucket-encryption \
    --bucket "$TF_STATE_BUCKET" \
    --server-side-encryption-configuration '{"Rules":[{"ApplyServerSideEncryptionByDefault":{"SSEAlgorithm":"AES256"},"BucketKeyEnabled":true}]}' >/dev/null
  echo "    ✓ enabled"

  echo "  → enforce-https bucket policy"
  POLICY=$(cat <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "DenyInsecureTransport",
      "Effect": "Deny",
      "Principal": "*",
      "Action": "s3:*",
      "Resource": [
        "arn:aws:s3:::${TF_STATE_BUCKET}",
        "arn:aws:s3:::${TF_STATE_BUCKET}/*"
      ],
      "Condition": { "Bool": { "aws:SecureTransport": "false" } }
    }
  ]
}
EOF
)
  aws s3api put-bucket-policy --bucket "$TF_STATE_BUCKET" --policy "$POLICY" >/dev/null
  echo "    ✓ applied"
}

create_lock_table() {
  echo "→ DynamoDB table $TF_LOCK_TABLE"
  if aws dynamodb describe-table --table-name "$TF_LOCK_TABLE" --region "$AWS_REGION" >/dev/null 2>&1; then
    echo "  ✓ already exists, skipping create"
    return
  fi
  aws dynamodb create-table \
    --table-name "$TF_LOCK_TABLE" \
    --attribute-definitions AttributeName=LockID,AttributeType=S \
    --key-schema AttributeName=LockID,KeyType=HASH \
    --billing-mode PAY_PER_REQUEST \
    --region "$AWS_REGION" >/dev/null
  echo "  ✓ creating, waiting for ACTIVE..."
  aws dynamodb wait table-exists --table-name "$TF_LOCK_TABLE" --region "$AWS_REGION"
  echo "  ✓ ACTIVE"
}

create_bucket
echo ""
create_lock_table
echo ""
echo "✅ Bootstrap complete."
echo ""
echo "Next step: from infra/terraform/environments/prod-baseline run"
echo "    terraform init \\"
echo "      -backend-config=\"bucket=$TF_STATE_BUCKET\" \\"
echo "      -backend-config=\"region=$AWS_REGION\" \\"
echo "      -backend-config=\"dynamodb_table=$TF_LOCK_TABLE\""
