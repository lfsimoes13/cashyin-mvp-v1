/**
 * CashYin — canonical Pix fee and cost configuration.
 *
 * This file is the single source of truth for the initial standard pricing
 * model. All monetary values are INTEGER CENTS (never floats or decimals).
 *
 * Glossary
 * ─────────────────────────────────────────────────────────────────────────
 *  provider_cost_amount_cents  — what CashYin pays the provider (Bents)
 *                                per transaction. Stored in provider_cost_rules.
 *
 *  customer_fee_amount_cents   — what CashYin charges its client per
 *                                transaction. Stored in pricing_rules.
 *
 *  cashyin_margin_amount_cents — gross margin per transaction, derived:
 *                                customer_fee - provider_cost.
 *
 *  gross_amount_cents          — the raw Pix transaction amount (dynamic,
 *                                not stored here).
 *
 *  net_amount_cents            — value effectively applied to the client
 *                                balance after fees:
 *                                  cash-in:  gross - customer_fee (deducted from settlement)
 *                                  cash-out: gross is what the recipient gets;
 *                                            client is debited gross + customer_fee.
 *
 * DB mapping
 * ─────────────────────────────────────────────────────────────────────────
 *  provider_cost_amount_cents → provider_cost_rules.fixed_cost_cents
 *  customer_fee_amount_cents  → pricing_rules.fixed_fee_cents
 *  billing_mode (cash-in)     → 'deduct_from_settlement'
 *  billing_mode (cash-out)    → 'add_to_debit'
 *
 * The standard pricing plan is seeded by:
 *   migrations/0009_standard_pricing_plan.sql  (plan, version, rules)
 *   scripts/seed-dev.sql                       (demo client assignment)
 *   scripts/provision-provider.mjs             (production client assignment)
 */

export type PricingOperationConfig = {
  /** Provider that processes this operation type. */
  readonly provider: string;
  /** Cost CashYin incurs to the provider per transaction. Whole cents. */
  readonly provider_cost_amount_cents: number;
  /** Fee CashYin charges the client per transaction. Whole cents. */
  readonly customer_fee_amount_cents: number;
  /**
   * Gross margin per transaction.
   * Derived: customer_fee_amount_cents - provider_cost_amount_cents.
   * Positive = revenue; negative = subsidy.
   */
  readonly cashyin_margin_amount_cents: number;
  /** ISO 4217 currency code for all amounts. */
  readonly currency: 'BRL';
  /**
   * How the customer fee is settled against the client account.
   *  - 'deduct_from_settlement': fee is subtracted from the incoming Pix
   *    amount before crediting the client balance (cash-in).
   *  - 'add_to_debit': client balance is debited by principal + fee (cash-out).
   */
  readonly billing_mode: 'deduct_from_settlement' | 'add_to_debit';
};

/**
 * Standard Pix pricing configuration — Phase 1 (fixed flat fees).
 *
 * To change fees, update the values here AND create a new migration or run
 * `provision-provider.mjs` with the updated values to rotate the DB rules.
 */
export const PIX_PRICING_CONFIG = {
  cash_in: {
    provider: 'bents',
    provider_cost_amount_cents: 10,
    customer_fee_amount_cents: 15,
    cashyin_margin_amount_cents: 5, // 15 - 10
    currency: 'BRL',
    billing_mode: 'deduct_from_settlement',
  },
  cash_out: {
    provider: 'bents',
    provider_cost_amount_cents: 10,
    customer_fee_amount_cents: 15,
    cashyin_margin_amount_cents: 5, // 15 - 10
    currency: 'BRL',
    billing_mode: 'add_to_debit',
  },
} as const satisfies Record<'cash_in' | 'cash_out', PricingOperationConfig>;

/**
 * UUIDs for the standard pricing plan entities.
 *
 * Fixed (deterministic) so that:
 *  - `migrations/0009_standard_pricing_plan.sql` can use ON CONFLICT DO NOTHING
 *  - `scripts/seed-dev.sql` can reference the version directly without a query
 *  - `provision-provider.mjs` can idempotently link clients to the same plan
 */
export const STANDARD_PRICING_PLAN_IDS = {
  plan: '00000000-0000-0000-0010-000000000001',
  planVersion: '00000000-0000-0000-0011-000000000001',
} as const;
