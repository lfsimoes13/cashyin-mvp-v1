/**
 * Bents implementation of {@link ProviderWebhookAdapter}.
 *
 * Encapsulates every Bents-specific webhook concern (signature header
 * name, payload envelope shape, event-type vocabulary) so the rest of
 * the system can speak the canonical CashYin contract. The adapter
 * itself remains side-effect-free: it never writes to the database, it
 * never calls a domain service, and it never raises on unknown event
 * types — orphan or malformed shapes surface through the structured
 * `normalizedStatus.kind === 'unknown'` branch.
 *
 * The ingress route (`/internal/webhooks/bents`) goes through
 * {@link WebhookService}, which resolves this adapter from
 * {@link ProviderWebhookAdapterRegistry} and walks the three steps
 * synchronously before responding 2xx. The asynchronous processor
 * (Phase 5) is the only consumer that reads back from the persisted
 * `webhook_events` row.
 */

import { createHash } from 'node:crypto';
import {
  mapProviderCashInStatus,
  mapProviderCashOutStatus
} from '../../modules/transactions/provider-status-mappers.js';
import type { CashInStatus, CashOutStatus } from '../../modules/transactions/status.js';
import {
  redactHeaders,
  type ProviderWebhookAdapter,
  type ProviderWebhookEventFields,
  type ProviderWebhookNormalizedEvent,
  type ProviderWebhookNormalizedStatus,
  type ProviderWebhookParseInput,
  type ProviderWebhookParsedEvent,
  type ProviderWebhookVerificationInput,
  type ProviderWebhookVerificationResult
} from '../contracts/provider-webhook-adapter.js';
import type { OperationType } from '../contracts/provider-types.js';
import type { WebhookAuthStrategy } from '../contracts/webhook-auth-strategy.js';
import { NoVerificationWebhookAuthStrategy } from '../security/no-verification.strategy.js';

/**
 * Header name Bents documents for HMAC-signed payloads. The provider
 * confirmed in May/2026 that signing isn't enabled in their portal, so
 * production wiring uses {@link NoVerificationWebhookAuthStrategy}. The
 * constant stays here for the audit redactor (so we redact it if some
 * day Bents starts sending one) and as documentation.
 */
export const BENTS_SIGNATURE_HEADER = 'x-bents-signature';

const SENSITIVE_HEADERS = [
  BENTS_SIGNATURE_HEADER,
  'authorization',
  'cookie',
  'set-cookie',
  'x-api-key'
] as const;

/**
 * Event-name vocabulary the Bents docs publish — kept verbatim so the
 * mapping survives a docs re-read without code archaeology.
 *
 *   - `pix.charge.*`   — cash-in lifecycle (paid / expired / cancelled).
 *   - `pix.payment.*`  — cash-out lifecycle (sent / failed / returned).
 *   - `transfer.refunded` — cash-out cancellation (rejected withdrawal).
 *   - `med.opened` / `med.resolved` — BACEN MED contestation lifecycle.
 *
 * The legacy `charge.*`, `payment.*` and `pix.cash_in.*` / `pix.cash_out.*`
 * prefixes are kept as aliases: integration tests and historical
 * fixtures use them, and removing them now would mask future drift
 * between code and the Bents portal vocabulary.
 *
 * Anything outside these prefixes resolves to `operationType: null` and
 * surfaces in `normalizedStatus` as `missing_operation_type`.
 *
 * Out-of-scope here (handled in a follow-up PR — search for the
 * "MED + transfer.refunded" task in the planning board):
 *   - `transfer.refunded`
 *   - `med.opened`
 *   - `med.resolved`
 * They are listed for documentation purposes; for now they still fall
 * through to `missing_operation_type` so the processor records them as
 * `skipped` rather than silently dropping them.
 */
const CASH_IN_EVENT_PREFIXES = ['pix.charge.', 'charge.', 'charge_', 'pix.cash_in.'] as const;
const CASH_OUT_EVENT_PREFIXES = ['pix.payment.', 'payment.', 'payment_', 'pix.cash_out.'] as const;

/**
 * Last-segment hint vocabulary used when the payload does not carry a
 * separate `status` field and we have to infer the canonical status
 * from the event type itself (e.g. `charge.paid` → `paid`).
 */
const EVENT_VERB_TO_CASH_IN_STATUS: Record<string, CashInStatus> = {
  paid: 'paid',
  confirmed: 'paid',
  received: 'pending',
  created: 'pending',
  pending: 'pending',
  expired: 'expired',
  cancelled: 'cancelled',
  canceled: 'cancelled',
  failed: 'failed',
  refunded: 'refunded',
  reversed: 'refunded',
  devolved: 'refunded'
};

const EVENT_VERB_TO_CASH_OUT_STATUS: Record<string, CashOutStatus> = {
  completed: 'completed',
  confirmed: 'completed',
  paid: 'completed',
  success: 'completed',
  processing: 'processing',
  pending: 'processing',
  sent: 'processing',
  failed: 'failed',
  error: 'failed',
  rejected: 'failed',
  returned: 'returned',
  refunded: 'returned',
  devolved: 'returned'
};

export type BentsWebhookAdapterDeps = {
  /**
   * Auth strategy that the adapter delegates `verify()` to. Defaults
   * to {@link NoVerificationWebhookAuthStrategy} — the contract Bents
   * actually operates under as of May/2026 (their portal does not
   * issue webhook signing secrets, confirmed with their support).
   *
   * To upgrade to HMAC if/when Bents changes the contract, instantiate
   * a `Sha256HmacWebhookAuthStrategy` in the container and pass it
   * here. No adapter code needs to change.
   */
  authStrategy?: WebhookAuthStrategy;
};

export class BentsWebhookAdapter implements ProviderWebhookAdapter {
  readonly providerName = 'bents' as const;

  private readonly authStrategy: WebhookAuthStrategy;

  constructor(deps: BentsWebhookAdapterDeps = {}) {
    this.authStrategy = deps.authStrategy ?? new NoVerificationWebhookAuthStrategy();
  }

  /** Stable identifier of the auth strategy this adapter was wired with. */
  get authStrategyName(): string {
    return this.authStrategy.name;
  }

  async verify(
    input: ProviderWebhookVerificationInput
  ): Promise<ProviderWebhookVerificationResult> {
    return this.authStrategy.verify(input);
  }

  async parse(input: ProviderWebhookParseInput): Promise<ProviderWebhookParsedEvent> {
    const rawPayloadHash = sha256Hex(input.rawBody);
    const redactedHeadersOut = redactHeaders(input.headers, SENSITIVE_HEADERS);

    const envelope = isRecord(input.payload) ? input.payload : {};
    const data = extractDataObject(envelope);

    const providerEventType =
      pickString(envelope, 'event') ??
      pickString(envelope, 'event_type') ??
      pickString(envelope, 'type') ??
      '';

    const providerEventId =
      pickString(envelope, 'event_id') ??
      pickString(envelope, 'id') ??
      pickString(envelope, 'uuid');

    const providerTransactionId =
      pickString(data, 'charge_uuid') ??
      pickString(data, 'transaction_id') ??
      pickString(data, 'id') ??
      pickString(envelope, 'charge_uuid') ??
      pickString(envelope, 'transaction_id');

    const providerStatus = pickString(data, 'status') ?? pickString(envelope, 'status');

    const operationType = inferOperationType(providerEventType);

    const occurredAt =
      pickIsoDate(data, 'paid_at') ??
      pickIsoDate(data, 'completed_at') ??
      pickIsoDate(data, 'returned_at') ??
      pickIsoDate(data, 'failed_at') ??
      pickIsoDate(data, 'occurred_at') ??
      pickIsoDate(envelope, 'timestamp');

    // `pix.charge.paid` carries a nested `payer` block since May/2026
    // (https://finance.bents.com.br/docs §"Novo (maio/2026) — bloco payer").
    // Older fixtures and other event types may keep the flat
    // `payer_name` / `payer_document` shape; we honour both with the
    // nested form taking precedence. Bank fields (`bank_name`, `ispb`,
    // `branch`, `account`) follow the same precedence rule.
    const payer = extractRecord(data, 'payer');
    const bank = payer ? extractRecord(payer, 'bank') : null;

    const fields: ProviderWebhookEventFields = {
      e2e_id:
        pickString(data, 'e2e_id') ??
        pickString(data, 'end_to_end_id') ??
        pickString(envelope, 'e2e_id') ??
        pickString(envelope, 'end_to_end_id'),
      realised_amount:
        pickPositiveInt(data, 'amount_cents') ?? pickPositiveInt(envelope, 'amount_cents'),
      payer_name:
        (payer && pickString(payer, 'name')) ??
        pickString(data, 'payer_name') ??
        pickString(envelope, 'payer_name'),
      payer_document:
        (payer && pickString(payer, 'document')) ??
        pickString(data, 'payer_document') ??
        pickString(envelope, 'payer_document'),
      payer_document_type: pickDocumentType(
        (payer && pickString(payer, 'document_type')) ??
          pickString(data, 'payer_document_type') ??
          pickString(envelope, 'payer_document_type')
      ),
      payer_bank_name:
        (bank && pickString(bank, 'name')) ??
        (payer && pickString(payer, 'bank_name')) ??
        pickString(data, 'payer_bank_name'),
      payer_bank_ispb:
        (bank && pickString(bank, 'ispb')) ??
        (payer && pickString(payer, 'bank_ispb')) ??
        pickString(data, 'payer_bank_ispb'),
      payer_bank_branch:
        (bank && pickString(bank, 'branch')) ??
        (payer && pickString(payer, 'bank_branch')) ??
        pickString(data, 'payer_bank_branch'),
      payer_bank_account:
        (bank && pickString(bank, 'account')) ??
        (payer && pickString(payer, 'bank_account')) ??
        pickString(data, 'payer_bank_account')
    };

    return {
      providerName: this.providerName,
      rawPayloadHash,
      redactedHeaders: redactedHeadersOut,
      rawPayload: input.payload,
      providerEventId,
      providerEventType,
      providerTransactionId,
      providerStatus,
      operationType,
      occurredAt,
      fields
    };
  }

  async normalize(
    parsed: ProviderWebhookParsedEvent
  ): Promise<ProviderWebhookNormalizedEvent> {
    const normalizedStatus = resolveNormalizedStatus(parsed);
    return { ...parsed, normalizedStatus };
  }
}

function resolveNormalizedStatus(
  parsed: ProviderWebhookParsedEvent
): ProviderWebhookNormalizedStatus {
  if (parsed.operationType === null) {
    return { kind: 'unknown', reason: 'missing_operation_type' };
  }

  if (parsed.operationType === 'cash_in') {
    return resolveCashInStatus(parsed);
  }
  return resolveCashOutStatus(parsed);
}

function resolveCashInStatus(
  parsed: ProviderWebhookParsedEvent
): ProviderWebhookNormalizedStatus {
  // Prefer the explicit `data.status` field when present, falling back
  // to the verb embedded in the event type for status-less notifications
  // (e.g. `charge.paid` with no `status` field).
  if (parsed.providerStatus) {
    const mapped = mapProviderCashInStatus(parsed.providerStatus);
    if (mapped.kind === 'mapped') {
      return { kind: 'cash_in', status: mapped.status };
    }
  }
  const verb = lastEventSegment(parsed.providerEventType);
  if (verb) {
    const inferred = EVENT_VERB_TO_CASH_IN_STATUS[verb];
    if (inferred !== undefined) {
      return { kind: 'cash_in', status: inferred };
    }
  }
  return {
    kind: 'unknown',
    reason: parsed.providerStatus ? 'unknown_status' : 'missing_status'
  };
}

function resolveCashOutStatus(
  parsed: ProviderWebhookParsedEvent
): ProviderWebhookNormalizedStatus {
  if (parsed.providerStatus) {
    const mapped = mapProviderCashOutStatus(parsed.providerStatus);
    if (mapped.kind === 'mapped') {
      return { kind: 'cash_out', status: mapped.status };
    }
  }
  const verb = lastEventSegment(parsed.providerEventType);
  if (verb) {
    const inferred = EVENT_VERB_TO_CASH_OUT_STATUS[verb];
    if (inferred !== undefined) {
      return { kind: 'cash_out', status: inferred };
    }
  }
  return {
    kind: 'unknown',
    reason: parsed.providerStatus ? 'unknown_status' : 'missing_status'
  };
}

function inferOperationType(eventType: string): OperationType | null {
  if (!eventType) return null;
  const normalised = eventType.toLowerCase();
  for (const prefix of CASH_IN_EVENT_PREFIXES) {
    if (normalised.startsWith(prefix)) return 'cash_in';
  }
  for (const prefix of CASH_OUT_EVENT_PREFIXES) {
    if (normalised.startsWith(prefix)) return 'cash_out';
  }
  return null;
}

function lastEventSegment(eventType: string): string | null {
  if (!eventType) return null;
  const normalised = eventType.toLowerCase();
  const fromDot = normalised.split('.').pop();
  if (!fromDot) return null;
  const fromUnderscore = fromDot.split('_').pop();
  return fromUnderscore && fromUnderscore.length > 0 ? fromUnderscore : null;
}

function extractDataObject(envelope: Record<string, unknown>): Record<string, unknown> {
  const data = envelope['data'];
  if (isRecord(data)) return data;
  return envelope;
}

function extractRecord(
  source: Record<string, unknown>,
  key: string
): Record<string, unknown> | null {
  const value = source[key];
  return isRecord(value) ? value : null;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function pickString(record: Record<string, unknown>, key: string): string | null {
  const value = record[key];
  return typeof value === 'string' && value.length > 0 ? value : null;
}

/**
 * Normalises a free-text document-type token from the provider into the
 * canonical `cpf | cnpj` taxonomy enforced by the database CHECK on
 * `pix_charges.payer_document_type`. Anything outside the taxonomy is
 * treated as missing (`null`) so the row insert never fails on a
 * provider that emits, e.g., `"individual"` or `"passport"`.
 */
function pickDocumentType(raw: string | null): 'cpf' | 'cnpj' | null {
  if (!raw) return null;
  const normalised = raw.trim().toLowerCase();
  if (normalised === 'cpf' || normalised === 'cnpj') return normalised;
  return null;
}

function pickIsoDate(record: Record<string, unknown>, key: string): Date | null {
  const value = record[key];
  if (typeof value !== 'string' || value.length === 0) return null;
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}

function pickPositiveInt(record: Record<string, unknown>, key: string): number | null {
  const value = record[key];
  if (typeof value === 'number' && Number.isInteger(value) && value > 0) return value;
  if (typeof value === 'string') {
    const parsed = Number(value);
    if (Number.isInteger(parsed) && parsed > 0) return parsed;
  }
  return null;
}

function sha256Hex(input: Buffer): string {
  return createHash('sha256').update(input).digest('hex');
}
