import { request } from 'undici';
import { env } from '../../shared/config/env.js';
import { AppError } from '../../shared/errors/app-error.js';
import { metrics } from '../../shared/observability/metrics.js';
import {
  classifyProviderHttpFailure,
  classifyProviderNetworkError,
  ProviderError
} from '../contracts/provider-errors.js';

/**
 * Thin HTTP wrapper around the Bents public API.
 *
 * Per Bents' public docs (https://finance.bents.com.br/docs), the API does
 * **not** support a client-supplied idempotency key on `POST /pix/charge` or
 * `POST /pix/payment`: each POST creates a new resource. CashYin is therefore
 * solely responsible for preventing duplicate calls. We do not send any
 * `x-idempotency-key` header because doing so would imply a contract the
 * provider does not honour.
 *
 * All failures are mapped to {@link ProviderError} with an explicit
 * {@link ProviderFailureCategory}. Callers can then decide whether the
 * provider may have side-effected (ambiguous) or definitely did not (definite
 * client error).
 */
export class BentsClient {
  constructor(
    private readonly apiBaseUrl = env.BENTS_API_BASE_URL,
    private readonly apiKey = env.BENTS_API_KEY,
    private readonly timeoutMs = env.REQUEST_TIMEOUT_MS
  ) {}

  async request<TResponse>(
    method: 'GET' | 'POST',
    path: string,
    body?: unknown,
    /**
     * Per-call timeout override (ms). When supplied it replaces the
     * instance-level `timeoutMs` for this single call only. Useful for
     * applying tighter budgets on latency-critical paths (e.g. QR Code
     * charge creation) without lowering the global default that protects
     * less critical operations (status polling, lookup queries).
     */
    callTimeoutMs?: number
  ): Promise<TResponse> {
    if (!this.apiKey) {
      throw new AppError('provider_credentials_missing', 'Bents API key is not configured', 500);
    }

    const headers: Record<string, string> = {
      authorization: `Bearer ${this.apiKey}`,
      accept: 'application/json'
    };

    let serializedBody: string | undefined;
    if (body !== undefined) {
      headers['content-type'] = 'application/json';
      serializedBody = JSON.stringify(body);
    }

    const url = buildBentsRequestUrl(this.apiBaseUrl, path);
    const effectiveTimeout = callTimeoutMs ?? this.timeoutMs;
    const requestOptions = {
      method,
      headers,
      bodyTimeout: effectiveTimeout,
      headersTimeout: effectiveTimeout,
      ...(serializedBody !== undefined ? { body: serializedBody } : {})
    };

    const startedAt = process.hrtime.bigint();
    let result = 'success';
    let responseStatus = 'not_received';
    let errorCategory = 'none';

    try {
      let response;
      try {
        response = await request(url, requestOptions);
        responseStatus = String(response.statusCode);
      } catch (error) {
        throw classifyProviderNetworkError('bents', error);
      }

      let responseBody: string;
      try {
        responseBody = await response.body.text();
      } catch (error) {
        throw classifyProviderNetworkError('bents', error);
      }

      let parsed: TResponse;
      try {
        parsed = responseBody ? (JSON.parse(responseBody) as TResponse) : ({} as TResponse);
      } catch (error) {
        throw new ProviderError(
          'provider_invalid_response',
          'Bents returned a non-JSON response',
          502,
          'unknown',
          { providerName: 'bents', statusCode: response.statusCode, raw: responseBody, cause: (error as Error).message }
        );
      }

      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw classifyProviderHttpFailure('bents', response.statusCode, parsed);
      }

      return parsed;
    } catch (error) {
      result = 'failure';
      if (error instanceof ProviderError) {
        errorCategory = error.category;
      } else {
        errorCategory = 'unknown';
      }
      throw error;
    } finally {
      const labels = {
        provider: 'bents',
        method,
        path,
        result,
        response_status: responseStatus,
        error_category: errorCategory
      };
      metrics.increment('cashyin_provider_http_requests_total', 'Total outbound provider HTTP calls by provider, path and result.', labels);
      metrics.observeDurationSeconds(
        'cashyin_provider_http_request_duration_seconds',
        'Outbound provider HTTP call duration by provider, path and result.',
        startedAt,
        labels
      );
      metrics.setGauge(
        'cashyin_provider_http_timeout_ms',
        'Configured outbound provider HTTP timeout in milliseconds.',
        { provider: 'bents' },
        this.timeoutMs
      );
    }
  }
}

/**
 * Concatenates the Bents base URL with an endpoint path.
 *
 * `new URL(path, base)` cannot be used here: when `path` starts with `/` the
 * URL spec treats it as an absolute path and discards `base`'s path, so
 * `new URL('/pix/charge', 'https://host/api/v2/public')` collapses to
 * `https://host/pix/charge`. Bents publishes all endpoints under
 * `/api/v2/public/...`, so we concatenate while normalising the boundary
 * slashes.
 */
export function buildBentsRequestUrl(baseUrl: string, path: string): string {
  const trimmedBase = baseUrl.replace(/\/+$/, '');
  const normalisedPath = path.startsWith('/') ? path : `/${path}`;
  return `${trimmedBase}${normalisedPath}`;
}
