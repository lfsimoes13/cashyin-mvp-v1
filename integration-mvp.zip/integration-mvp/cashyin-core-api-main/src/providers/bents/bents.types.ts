export type BentsChargeResponse = {
  charge_uuid: string;
  status: string;
  amount_cents: number;
  pix_copia_e_cola?: string;
  txid: string;
  expires_at?: string;
  qr_code?: {
    png_base64?: string;
    png_image?: string;
  };
  sandbox?: boolean;
};

export type BentsPaymentReceiver = {
  name?: string | null;
  document?: string | null;
  bank?: string | null;
  ispb?: string | null;
  branch?: string | null;
  account?: string | null;
  account_type?: string | null;
};

export type BentsPaymentResponse = {
  transaction_id: string;
  status: string;
  e2e_id?: string;
  e2e_id_dict?: string;
  fee_amount_cents?: number;
  receiver?: BentsPaymentReceiver | null;
};

export type BentsBalanceResponse = {
  balance?: number;
  balance_cents: number;
  currency: string;
  status?: string;
};

