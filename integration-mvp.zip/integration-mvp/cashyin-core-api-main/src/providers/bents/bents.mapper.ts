import {
  mapProviderCashInStatus,
  mapProviderCashOutStatus
} from '../../modules/transactions/provider-status-mappers.js';
import type {
  ProviderPixCharge,
  ProviderPixPayment,
  ProviderReceiver
} from '../contracts/provider-types.js';
import type {
  BentsChargeResponse,
  BentsPaymentReceiver,
  BentsPaymentResponse
} from './bents.types.js';

/**
 * Bents-specific Cash-In status translation. Defers the raw → canonical
 * mapping to the shared `provider-status-mappers` module so multi-provider
 * vocabulary stays consistent and is unit-tested in one place. Unknown
 * Bents statuses default to `failed`, matching the previous behaviour.
 */
export function mapBentsChargeStatus(status: string): ProviderPixCharge['status'] {
  const result = mapProviderCashInStatus(status);
  return result.kind === 'mapped' ? result.status : 'failed';
}

/**
 * Bents-specific Cash-Out status translation. The `SENT` token Bents uses
 * for in-flight payments maps to `processing` via the shared mapper; the
 * `REFUNDED` token maps to `returned`. Unknown Bents statuses default to
 * `processing` because the cash-out can still be in flight on the
 * provider side and the safe default is to leave it non-terminal.
 */
export function mapBentsPaymentStatus(status: string): ProviderPixPayment['status'] {
  const result = mapProviderCashOutStatus(status);
  return result.kind === 'mapped' ? result.status : 'processing';
}

export function mapBentsCharge(response: BentsChargeResponse): ProviderPixCharge {
  return {
    provider: 'bents',
    provider_charge_id: response.charge_uuid,
    status: mapBentsChargeStatus(response.status),
    amount: response.amount_cents,
    // `response.txid` is the Bents-generated Pix txid. It is stored in
    // `pix_charges.provider_tx_id` for internal conciliation only. The
    // public `pix_charges.txid` is the CashYin-generated value from
    // `generatePixTxid()`, produced before this provider call.
    ...(response.txid !== undefined ? { provider_tx_id: response.txid } : {}),
    raw: response,
    ...(response.pix_copia_e_cola !== undefined ? { emv: response.pix_copia_e_cola } : {}),
    ...(response.expires_at !== undefined ? { expires_at: response.expires_at } : {})
  };
}

export function mapBentsPayment(response: BentsPaymentResponse, amountCents: number): ProviderPixPayment {
  const receiver = mapBentsReceiver(response.receiver);
  return {
    provider: 'bents',
    providerPaymentId: response.transaction_id,
    status: mapBentsPaymentStatus(response.status),
    amountCents,
    raw: response,
    ...(response.e2e_id !== undefined ? { e2eId: response.e2e_id } : {}),
    ...(response.fee_amount_cents !== undefined
      ? { feeAmountCents: response.fee_amount_cents }
      : {}),
    ...(receiver ? { receiver } : {})
  };
}

/**
 * Projects Bents' `data.receiver` block onto the provider-agnostic
 * {@link ProviderReceiver}. Only non-empty string fields are carried over;
 * a `null`/missing provider field is dropped so the downstream COALESCE
 * never overwrites an existing value with an empty one. Returns `null` when
 * the provider sent no usable receiver detail at all.
 */
export function mapBentsReceiver(
  raw: BentsPaymentReceiver | null | undefined
): ProviderReceiver | null {
  if (raw === null || typeof raw !== 'object') return null;
  const receiver: ProviderReceiver = {
    ...(nonEmpty(raw.name) ? { name: raw.name as string } : {}),
    ...(nonEmpty(raw.document) ? { document: raw.document as string } : {}),
    ...(nonEmpty(raw.bank) ? { bank: raw.bank as string } : {}),
    ...(nonEmpty(raw.ispb) ? { ispb: raw.ispb as string } : {}),
    ...(nonEmpty(raw.branch) ? { branch: raw.branch as string } : {}),
    ...(nonEmpty(raw.account) ? { account: raw.account as string } : {}),
    ...(nonEmpty(raw.account_type) ? { accountType: raw.account_type as string } : {})
  };
  return Object.keys(receiver).length > 0 ? receiver : null;
}

function nonEmpty(value: unknown): boolean {
  return typeof value === 'string' && value.length > 0;
}

