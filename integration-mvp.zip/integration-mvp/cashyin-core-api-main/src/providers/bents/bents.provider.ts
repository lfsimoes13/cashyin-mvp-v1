import { env } from '../../shared/config/env.js';
import type { PaymentProvider } from '../contracts/payment-provider.js';
import type {
  ProviderBalance,
  ProviderPixCharge,
  ProviderPixChargeRequest,
  ProviderPixPayment,
  ProviderPixPaymentRequest
} from '../contracts/provider-types.js';
import { BentsClient } from './bents.client.js';
import { mapBentsCharge, mapBentsPayment } from './bents.mapper.js';
import type { BentsBalanceResponse, BentsChargeResponse, BentsPaymentResponse } from './bents.types.js';

export class BentsProvider implements PaymentProvider {
  readonly name = 'bents' as const;

  constructor(private readonly client = new BentsClient()) {}

  async createPixCharge(input: ProviderPixChargeRequest): Promise<ProviderPixCharge> {
    // Bents `POST /pix/charge` accepts only `amount_cents` and `description`
    // and *generates* the Pix txid server-side. It does not honour
    // `external_ref`, `txid` or `x-idempotency-key`, so we MUST NOT send
    // them: doing so would imply a contract the provider does not offer
    // and would silently strip the values.
    //
    // Note on units: our canonical contract carries `amount` in cents
    // (see `provider-types.ts`). Bents happens to share the same
    // convention, so the assignment is direct. A provider that asked
    // for reais would convert here (`amount: input.amount / 100`).
    const body: Record<string, unknown> = { amount_cents: input.amount };
    if (input.description !== undefined) {
      body.description = input.description;
    }

    // Use a tighter latency budget for cash-in charge creation so the
    // POST /v1/pix/cash-in/qrcode endpoint fails fast when Bents is slow
    // rather than holding Node sockets and DB connections open for 5 s.
    const response = await this.client.request<BentsChargeResponse>(
      'POST',
      '/pix/charge',
      body,
      env.BENTS_CASHIN_CHARGE_TIMEOUT_MS
    );

    return mapBentsCharge(response);
  }

  async getPixCharge(providerChargeId: string): Promise<ProviderPixCharge> {
    const response = await this.client.request<BentsChargeResponse>('GET', `/pix/charge/${providerChargeId}`);
    return mapBentsCharge(response);
  }

  async createPixPayment(input: ProviderPixPaymentRequest): Promise<ProviderPixPayment> {
    // Bents `POST /pix/payment` accepts `amount_cents`, `pix_key`,
    // `pix_key_type`, `description` and the optional receiver identity
    // (`receiver_name`/`receiver_document`). It does not support
    // `external_id` or a client-supplied idempotency header.
    const body: Record<string, unknown> = {
      amount_cents: input.amountCents,
      pix_key: input.pixKey,
      pix_key_type: input.pixKeyType
    };
    if (input.receiverName !== undefined) {
      body.receiver_name = input.receiverName;
    }
    if (input.receiverDocument !== undefined) {
      body.receiver_document = input.receiverDocument;
    }
    if (input.description !== undefined) {
      body.description = input.description;
    }

    const response = await this.client.request<BentsPaymentResponse>(
      'POST',
      '/pix/payment',
      body
    );

    return mapBentsPayment(response, input.amountCents);
  }

  async getBalance(): Promise<ProviderBalance> {
    const response = await this.client.request<BentsBalanceResponse>('GET', '/balance');
    return {
      provider: 'bents',
      availableAmountCents: response.balance_cents,
      currency: 'BRL',
      raw: response
    };
  }
}

