/**
 * HMAC-SHA256 strategy for webhook authentication.
 *
 * Computes `sha256=<hex>` over the raw request body using a shared
 * secret and compares the result against a configurable header value
 * (e.g. `x-bents-signature`, `x-hub-signature-256`).
 *
 * Two operating modes:
 *
 *   - **Strict** (`requireSignature = true`, default): every request
 *     that doesn't carry a verifiable signature is rejected. Use this
 *     for any provider that documents HMAC signing as part of the
 *     webhook contract. Failure modes are persisted via the structured
 *     `reason` field so operators can distinguish "missing header" vs
 *     "wrong secret" vs "malformed digest".
 *
 *   - **Permissive** (`requireSignature = false`): accepts requests
 *     without a verifiable signature, but still verifies the HMAC
 *     when both the secret AND a well-formed signature header are
 *     present. Exists as a bridge for providers whose portal config
 *     hasn't enabled signing yet, or where a single tenant operates
 *     in mixed signed/unsigned mode. Tampered signatures are still
 *     rejected — permissive mode only short-circuits the "cannot
 *     check" branch.
 *
 * The strategy is stateless and safe to share across concurrent
 * adapter calls.
 */

import { verifySha256Signature } from '../../shared/security/hmac.js';
import {
  pickHeader,
  type ProviderWebhookVerificationInput,
  type ProviderWebhookVerificationResult
} from '../contracts/provider-webhook-adapter.js';
import type { WebhookAuthStrategy } from '../contracts/webhook-auth-strategy.js';

export type Sha256HmacWebhookAuthStrategyOptions = {
  /**
   * Header name carrying the signature. Case-insensitive when read.
   * Example: `'x-bents-signature'`.
   */
  signatureHeader: string;
  /**
   * Required string prefix on the header value. Most providers use
   * `'sha256='`; the strategy rejects anything else as malformed so
   * a future algorithm change is loud rather than silently accepting.
   */
  signaturePrefix: string;
  /**
   * Shared HMAC secret. `undefined` means "not configured"; behaviour
   * depends on {@link requireSignature}.
   */
  secret: string | undefined;
  /**
   * Strict (true) vs permissive (false). See class doc-comment.
   * Defaults to `true` to favour a secure default.
   */
  requireSignature?: boolean;
};

export class Sha256HmacWebhookAuthStrategy implements WebhookAuthStrategy {
  readonly name = 'sha256_hmac';

  private readonly signatureHeader: string;
  private readonly signaturePrefix: string;
  private readonly secret: string | undefined;
  private readonly requireSignature: boolean;

  constructor(options: Sha256HmacWebhookAuthStrategyOptions) {
    this.signatureHeader = options.signatureHeader;
    this.signaturePrefix = options.signaturePrefix;
    this.secret = options.secret;
    this.requireSignature = options.requireSignature ?? true;
  }

  async verify(
    input: ProviderWebhookVerificationInput
  ): Promise<ProviderWebhookVerificationResult> {
    const signature = input.signature ?? pickHeader(input.headers, this.signatureHeader);

    if (this.requireSignature) {
      if (!signature) {
        return { valid: false, reason: 'missing_signature' };
      }
      if (!this.secret) {
        return { valid: false, reason: 'missing_secret' };
      }
      if (!signature.startsWith(this.signaturePrefix)) {
        return {
          valid: false,
          reason: 'malformed_signature',
          detail: `expected ${this.signaturePrefix} prefix`
        };
      }
      const ok = verifySha256Signature(input.rawBody, signature, this.secret);
      return ok ? { valid: true } : { valid: false, reason: 'invalid_signature' };
    }

    // Permissive: verify only when both sides are present and well-formed.
    if (signature && this.secret && signature.startsWith(this.signaturePrefix)) {
      const ok = verifySha256Signature(input.rawBody, signature, this.secret);
      return ok ? { valid: true } : { valid: false, reason: 'invalid_signature' };
    }
    return { valid: true };
  }
}
