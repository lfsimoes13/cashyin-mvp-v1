/**
 * "Trust the transport" strategy for webhooks that aren't signed.
 *
 * Every request is accepted unconditionally. Authenticity must be
 * enforced elsewhere — typically via:
 *
 *   - TLS to the ingress (HTTPS-only ALB listener, HSTS, no plaintext)
 *   - Provider IP allowlist in WAF / security groups
 *   - URL obscurity (do not publish the ingress path)
 *
 * Use this strategy ONLY when the provider has confirmed in writing
 * that they do not sign callbacks. The `signature_valid = true` rows
 * persisted under this strategy are NOT a cryptographic guarantee;
 * they reflect "the ingress pipeline accepted this row" and the
 * audit log records `auth_strategy = 'no_verification'` so post-hoc
 * reviewers know the difference.
 *
 * Bents Finance (May/2026): support has confirmed there's no webhook
 * signing secret in the portal, so the production wiring binds this
 * strategy to the Bents adapter.
 */

import type {
  ProviderWebhookVerificationInput,
  ProviderWebhookVerificationResult
} from '../contracts/provider-webhook-adapter.js';
import type { WebhookAuthStrategy } from '../contracts/webhook-auth-strategy.js';

export class NoVerificationWebhookAuthStrategy implements WebhookAuthStrategy {
  readonly name = 'no_verification';

  async verify(
    _input: ProviderWebhookVerificationInput
  ): Promise<ProviderWebhookVerificationResult> {
    return { valid: true };
  }
}
