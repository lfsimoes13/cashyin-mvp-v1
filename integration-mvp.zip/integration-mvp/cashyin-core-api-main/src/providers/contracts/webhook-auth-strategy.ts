/**
 * Provider-agnostic strategy for authenticating an inbound webhook
 * request.
 *
 * Each provider integration has its own contract for "is this request
 * really from the upstream":
 *
 *   - Some providers sign the raw body with HMAC-SHA256 and ship the
 *     digest in a header (e.g. Stripe, GitHub, the documented Bents
 *     contract). `Sha256HmacWebhookAuthStrategy` covers this case.
 *
 *   - Some providers (Bents in practice, as of May/2026) don't sign
 *     callbacks at all — the only authenticity controls are TLS, the
 *     provider's outbound IP allowlist, and the obscurity of the
 *     ingress URL. `NoVerificationWebhookAuthStrategy` covers this
 *     case explicitly so we never silently fall back to "trust
 *     anything that looks like JSON".
 *
 *   - Future providers may use Bearer tokens, mutual TLS, JWT,
 *     IP-allowlist, signed JWT envelopes, etc. Each gets its own
 *     strategy implementation; the adapter delegates without knowing
 *     the wire format.
 *
 * Strategies must be stateless across requests and may be safely shared
 * between concurrent adapter calls. They never write to the database,
 * never call domain services, and never throw — they return a
 * structured {@link ProviderWebhookVerificationResult} so the caller
 * can audit failure modes.
 *
 * # Why a separate interface instead of inheritance / a flag
 *
 * Pinning the auth scheme to a constructor flag (`requireSignature`)
 * inside the adapter conflates "does this provider sign at all" with
 * "what algorithm does this provider sign with". The strategy split
 * lets the adapter stay agnostic and lets the wiring layer
 * (`container.ts`) be the single place where a provider's auth model
 * is declared.
 *
 * See `docs/provider-integration/provider-infra-webhook-architecture.md` §8.
 */

import type {
  ProviderWebhookVerificationInput,
  ProviderWebhookVerificationResult
} from './provider-webhook-adapter.js';

export interface WebhookAuthStrategy {
  /**
   * Stable identifier for the strategy. Used in structured logs and
   * audit rows so operators can tell which scheme was in effect when
   * a webhook was accepted/rejected. Examples: `'sha256_hmac'`,
   * `'no_verification'`, `'bearer_token'`, `'ip_allowlist'`.
   */
  readonly name: string;

  verify(
    input: ProviderWebhookVerificationInput
  ): Promise<ProviderWebhookVerificationResult>;
}
