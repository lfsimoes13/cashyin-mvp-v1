/**
 * Provider webhook adapter contract.
 *
 * Splits provider-specific webhook handling into three deterministic
 * steps so the ingress layer can validate, audit and process events
 * without leaking provider payload shapes into the domain services.
 *
 *   1. `verify` — cryptographic check over the raw request body. Returns
 *      a structured `{ valid, reason }` so the caller can persist the
 *      failure mode for audit even when the request is rejected.
 *   2. `parse` — purely-structural extraction of stable fields from the
 *      provider payload: provider event id, transaction id, raw status
 *      token, operation type, occurrence timestamp, plus a SHA-256 of
 *      the raw body and a redacted-header dictionary that the audit
 *      layer can persist verbatim.
 *   3. `normalize` — converts the provider-shaped parsed event into a
 *      canonical CashYin transaction event. The `normalizedStatus`
 *      union flags whether the status is a known `cash_in` / `cash_out`
 *      canonical value or an `unknown` outcome to be retried/DLQ'd.
 *
 * Adapters must never write to the database, never call domain services
 * and never throw on unknown / malformed event types — orphan and
 * unrecognised events are surfaced through the `unknown` branch of
 * `normalizedStatus` so they can be retained for reconciliation.
 *
 * See `docs/provider-integration/provider-infra-webhook-architecture.md` §8.
 */

import type { CashInStatus, CashOutStatus } from '../../modules/transactions/status.js';
import type { OperationType, ProviderName } from './provider-types.js';

/** HTTP headers as Fastify hands them to a route handler. */
export type RawHeaders = Record<string, string | string[] | undefined>;

/**
 * Input for the cryptographic verification step. `signature` is the
 * value taken from the canonical signature header the provider uses;
 * the adapter is responsible for knowing which header name applies.
 */
export type ProviderWebhookVerificationInput = {
  rawBody: Buffer;
  headers: RawHeaders;
  /**
   * Pre-extracted signature when the caller already pulled it from the
   * headers. Adapters should fall back to scanning `headers` themselves
   * when this is `null`, so the caller does not need to know the
   * provider-specific header name.
   */
  signature: string | null;
  receivedAt: Date;
};

export type ProviderWebhookVerificationFailureReason =
  | 'missing_signature'
  | 'missing_secret'
  | 'invalid_signature'
  | 'replay_window_exceeded'
  | 'malformed_signature'
  | 'unknown';

export type ProviderWebhookVerificationResult =
  | { valid: true }
  | { valid: false; reason: ProviderWebhookVerificationFailureReason; detail?: string };

export type ProviderWebhookParseInput = {
  rawBody: Buffer;
  payload: unknown;
  headers: RawHeaders;
};

/**
 * Structured but still provider-shaped event extracted from the raw
 * payload. The persistence layer should store these fields verbatim
 * alongside the raw payload so any future shape change can be replayed
 * from the audit row.
 */
export type ProviderWebhookParsedEvent = {
  providerName: ProviderName;
  /** Hex-encoded SHA-256 of the raw request body. */
  rawPayloadHash: string;
  /**
   * Redacted-header dictionary suitable for persistence. Signature
   * headers and any header the adapter classifies as sensitive are
   * replaced with `"[redacted]"`. Multi-valued headers are joined with
   * `", "` to keep the persistence shape `Record<string, string>`.
   */
  redactedHeaders: Record<string, string>;
  rawPayload: unknown;
  /** Provider's own event id, when present. Used as primary dedupe key. */
  providerEventId: string | null;
  /** Original event type token (e.g. `charge.paid`). */
  providerEventType: string;
  /** Provider transaction id (charge_uuid, transaction_id, ...). */
  providerTransactionId: string | null;
  /** Provider's reported status string when carried separately from the event type. */
  providerStatus: string | null;
  /** Operation flow inferred from the event type, or `null` for unknown shapes. */
  operationType: OperationType | null;
  /** Best-known occurrence timestamp from the payload. */
  occurredAt: Date | null;
  /** Auxiliary, well-known provider fields (e.g. `endToEndId`, `payerName`). */
  fields: ProviderWebhookEventFields;
};

/**
 * Cross-provider auxiliary fields the normalizer is expected to surface
 * verbatim. Anything else stays in `rawPayload`.
 *
 * `payer_*` fields propagate from the provider's webhook into the
 * `pix.cash_in.paid` event we publish to the client. Storing them as
 * dedicated columns on `pix_charges` (rather than a JSONB blob) keeps
 * SQL reporting cheap; the `null` shape covers providers that emit
 * a subset of the BACEN payer block.
 *
 * Snake_case here mirrors the canonical contract (DB columns + public
 * webhook payload). Cash-out auxiliary fields will move to the same
 * shape when the cash-out flow goes through the same refactor.
 */
export type ProviderWebhookEventFields = {
  e2e_id: string | null;
  /** Realised amount in cents, as reported by the provider. */
  realised_amount: number | null;
  payer_name: string | null;
  payer_document: string | null;
  payer_document_type: 'cpf' | 'cnpj' | null;
  payer_bank_name: string | null;
  payer_bank_ispb: string | null;
  payer_bank_branch: string | null;
  payer_bank_account: string | null;
};

export type ProviderWebhookUnknownReason =
  | 'unknown_event_type'
  | 'unknown_status'
  | 'missing_status'
  | 'missing_operation_type';

export type ProviderWebhookNormalizedStatus =
  | { kind: 'cash_in'; status: CashInStatus }
  | { kind: 'cash_out'; status: CashOutStatus }
  | { kind: 'unknown'; reason: ProviderWebhookUnknownReason };

/**
 * Canonical CashYin event derived from a `ProviderWebhookParsedEvent`.
 *
 * Carries every audit field from the parsed event plus the
 * `normalizedStatus` union the domain processor consumes. The processor
 * is responsible for routing `unknown` outcomes to a retry/DLQ pipeline
 * documented per provider.
 */
export type ProviderWebhookNormalizedEvent = ProviderWebhookParsedEvent & {
  normalizedStatus: ProviderWebhookNormalizedStatus;
};

export interface ProviderWebhookAdapter {
  readonly providerName: ProviderName;
  verify(input: ProviderWebhookVerificationInput): Promise<ProviderWebhookVerificationResult>;
  parse(input: ProviderWebhookParseInput): Promise<ProviderWebhookParsedEvent>;
  normalize(input: ProviderWebhookParsedEvent): Promise<ProviderWebhookNormalizedEvent>;
}

/**
 * Header-pick utility shared by adapters. Returns the first stringified
 * value for the requested header, scanning case-insensitively.
 * Multi-valued headers are joined; missing headers return `null`.
 */
export function pickHeader(headers: RawHeaders, name: string): string | null {
  const target = name.toLowerCase();
  for (const [key, value] of Object.entries(headers)) {
    if (key.toLowerCase() !== target) continue;
    if (typeof value === 'string') return value;
    if (Array.isArray(value)) return value.join(', ');
  }
  return null;
}

/**
 * Produces a persistence-ready, case-normalised header dictionary with
 * sensitive entries redacted. `sensitiveKeys` are compared
 * case-insensitively.
 */
export function redactHeaders(
  headers: RawHeaders,
  sensitiveKeys: readonly string[]
): Record<string, string> {
  const sensitiveLower = new Set(sensitiveKeys.map((k) => k.toLowerCase()));
  const out: Record<string, string> = {};
  for (const [key, value] of Object.entries(headers)) {
    const lower = key.toLowerCase();
    if (value === undefined) continue;
    if (sensitiveLower.has(lower)) {
      out[lower] = '[redacted]';
      continue;
    }
    out[lower] = Array.isArray(value) ? value.join(', ') : value;
  }
  return out;
}
