import { AppError } from '../../shared/errors/app-error.js';

/**
 * Classification of provider failures.
 *
 * - `definite_client_error` means the provider explicitly rejected the request
 *   with a 4xx (other than the retryable codes below). It is safe to assume
 *   the provider performed no side effect and that retries with the same
 *   payload will be rejected the same way.
 *
 * - `ambiguous_*` means we do not know whether the provider performed a side
 *   effect. Releasing locks or reservations in this state is **unsafe** for a
 *   provider with no replay/idempotency contract (e.g. Bents `POST /pix/charge`
 *   and `POST /pix/payment`).
 *
 * - `unknown` is the safe default for unrecognised errors: treated as
 *   ambiguous.
 */
export type ProviderFailureCategory =
  | 'definite_client_error'
  | 'ambiguous_server_status'
  | 'ambiguous_timeout'
  | 'ambiguous_network'
  | 'unknown';

export class ProviderError extends AppError {
  constructor(
    code: string,
    message: string,
    statusCode: number,
    public readonly category: ProviderFailureCategory,
    details?: unknown
  ) {
    super(code, message, statusCode, details);
    this.name = 'ProviderError';
  }

  /**
   * Only `definite_client_error` is considered safe to treat as a definitive
   * provider failure. Every other category — including `unknown` — must be
   * treated as ambiguous so that callers do not release financial locks or
   * reservations when the provider may have side-effected.
   */
  get isDefinite(): boolean {
    return this.category === 'definite_client_error';
  }
}

const TIMEOUT_CODES = new Set([
  'UND_ERR_HEADERS_TIMEOUT',
  'UND_ERR_BODY_TIMEOUT',
  'UND_ERR_CONNECT_TIMEOUT',
  'ETIMEDOUT'
]);

const NETWORK_CODES = new Set([
  'UND_ERR_ABORTED',
  'UND_ERR_SOCKET',
  'UND_ERR_CLOSED',
  'UND_ERR_DESTROYED',
  'ECONNRESET',
  'ECONNREFUSED',
  'EPIPE',
  'ENETUNREACH',
  'EAI_AGAIN',
  'ENOTFOUND'
]);

/**
 * Returns the category for an upstream HTTP status code.
 *
 * 4xx are definite client errors **except** `408`, `425` and `429`, which are
 * treated as ambiguous because they routinely indicate transient conditions
 * where the request may or may not have been processed.
 */
export function categoriseHttpStatus(statusCode: number): ProviderFailureCategory {
  if (statusCode === 408 || statusCode === 425 || statusCode === 429) {
    return 'ambiguous_server_status';
  }
  if (statusCode >= 400 && statusCode < 500) {
    return 'definite_client_error';
  }
  if (statusCode >= 500) {
    return 'ambiguous_server_status';
  }
  return 'unknown';
}

export function classifyProviderHttpFailure(
  providerName: string,
  statusCode: number,
  body: unknown
): ProviderError {
  const category = categoriseHttpStatus(statusCode);
  return new ProviderError(
    'provider_request_failed',
    `${providerName} returned HTTP ${statusCode}`,
    502,
    category,
    { providerName, providerStatusCode: statusCode, body }
  );
}

export function classifyProviderNetworkError(
  providerName: string,
  error: unknown
): ProviderError {
  const rawCode = readErrorCode(error);
  const code = rawCode ?? null;

  if (code !== null && TIMEOUT_CODES.has(code)) {
    return new ProviderError(
      'provider_timeout',
      `${providerName} request timed out (${code})`,
      504,
      'ambiguous_timeout',
      { providerName, cause: code }
    );
  }

  if (code !== null && NETWORK_CODES.has(code)) {
    return new ProviderError(
      'provider_network_error',
      `${providerName} network error (${code})`,
      502,
      'ambiguous_network',
      { providerName, cause: code }
    );
  }

  const message = error instanceof Error ? error.message : String(error);
  return new ProviderError(
    'provider_unknown_error',
    `${providerName} call failed (${code ?? message})`,
    502,
    'unknown',
    { providerName, cause: code ?? message }
  );
}

function readErrorCode(error: unknown): string | null {
  if (typeof error !== 'object' || error === null) return null;
  const candidate = (error as { code?: unknown }).code;
  if (typeof candidate === 'string' && candidate.length > 0) return candidate;
  const cause = (error as { cause?: unknown }).cause;
  if (typeof cause === 'object' && cause !== null) {
    const causeCode = (cause as { code?: unknown }).code;
    if (typeof causeCode === 'string' && causeCode.length > 0) return causeCode;
  }
  return null;
}
