export type ProviderName = 'bents';
export type OperationType = 'cash_in' | 'cash_out';

export type ProviderMoney = {
  amount: number;
  currency: 'BRL';
};

/**
 * Generic payer block returned by providers on a settled cash-in. Modeled
 * after the BACEN-standard fields so future providers (PagSeguro, Mercado
 * Pago, …) map cleanly into the same shape. Every field is optional
 * because providers vary on which subset they emit; the webhook ingress
 * adapter picks whatever it can find in the payload and the rest stays
 * NULL in the database.
 */
export type ProviderPayer = {
  name?: string;
  document?: string;
  /** BACEN-standard taxonomy. Future providers may add `passport`, etc. */
  document_type?: 'cpf' | 'cnpj';
  bank_name?: string;
  /** Identificador único do banco no SPB (Sistema de Pagamentos Brasileiro). */
  bank_ispb?: string;
  bank_branch?: string;
  bank_account?: string;
  /** Conta do pagador: `checking` / `savings` / etc., quando informado. */
  account_type?: string;
};

export type ProviderPixChargeRequest = {
  /**
   * Optional provider-level idempotency key. Cash-in does NOT use the public
   * `Idempotency-Key` header (dedup is by `(client_id, external_ref)`), and
   * Bents exposes no client idempotency on `POST /pix/charge`, so this is
   * currently unused. Kept optional for future providers that support it.
   */
  idempotency_key?: string;
  client_id: string;
  external_ref: string;
  /** Amount in BRL cents — every monetary value in the contract is cents. */
  amount: number;
  description?: string;
  /**
   * Optional. Some providers (e.g. Bents) generate the Pix `txid`
   * server-side and ignore any value supplied by the caller. The
   * adapter is responsible for forwarding this field only if its
   * provider supports it.
   */
  txid?: string;
};

export type ProviderPixCharge = {
  provider: ProviderName;
  provider_charge_id: string;
  /**
   * Canonical Cash-In status produced by the provider adapter. Maps 1:1
   * with `CashInStatus` from `src/modules/transactions/status.ts`.
   * Provider-specific raw values are translated inside the adapter via
   * `mapProviderCashInStatus` before reaching this contract.
   */
  status: 'pending' | 'paid' | 'expired' | 'cancelled' | 'failed' | 'refunded';
  amount: number;
  /**
   * The Pix `txid` returned by the provider (e.g. Bents `BentsChargeResponse.txid`).
   *
   * This is the PROVIDER's own txid, not the CashYin-issued txid.
   * It is stored in `pix_charges.provider_tx_id` for internal conciliation
   * and is NEVER exposed in public API responses, client webhooks, or
   * external documentation.
   *
   * The public `pix_charges.txid` is always the CashYin-generated value
   * produced by `generatePixTxid()` before the provider call.
   *
   * Optional because some providers may not return a txid in all scenarios
   * (e.g. a provider that only returns one at settlement time).
   */
  provider_tx_id?: string;
  /** EMV "copia e cola" payment string returned by the provider. */
  emv?: string;
  expires_at?: string;
  /**
   * Populated only after the charge is settled (typically arrives via
   * webhook, not at creation). Present here so a future provider that
   * synchronously returns payer data on charge lookup can surface it
   * through the same contract.
   */
  paid_at?: string;
  e2eId?: string;
  payer?: ProviderPayer;
  raw: unknown;
};

// -----------------------------------------------------------------------------
// Cash-out contract (untouched by the cash-in snake_case refactor). When the
// cash-out flow goes through the same treatment, mirror the cash-in shape here.
// -----------------------------------------------------------------------------

export type ProviderPixPaymentRequest = {
  idempotencyKey: string;
  clientId: string;
  externalId: string;
  amountCents: number;
  pixKey: string;
  pixKeyType: 'CPF' | 'CNPJ' | 'EMAIL' | 'PHONE' | 'EVP';
  receiverName?: string;
  receiverDocument?: string;
  description?: string;
};

/**
 * Receiver (payee) identity a provider reports for a cash-out, either
 * synchronously on the create/send call or asynchronously on the
 * confirmation webhook. Modeled after the BACEN-standard fields so future
 * providers map cleanly into the same shape. Every field is optional
 * because providers vary on which subset they emit; whatever the adapter
 * cannot find stays absent and is persisted/serialized as `null`.
 *
 * The `document` is forwarded EXACTLY as the provider sends it — already
 * masked by the provider — so CashYin never reconstructs a full CPF/CNPJ.
 */
export type ProviderReceiver = {
  name?: string;
  document?: string;
  bank?: string;
  /** Identificador único do banco no SPB (Sistema de Pagamentos Brasileiro). */
  ispb?: string;
  branch?: string;
  account?: string;
  accountType?: string;
};

export type ProviderPixPayment = {
  provider: ProviderName;
  providerPaymentId: string;
  status: 'processing' | 'completed' | 'failed' | 'returned';
  amountCents: number;
  e2eId?: string;
  feeAmountCents?: number;
  /**
   * Receiver identity when the provider returns it on the create/send
   * call (synchronous completion). Absent for providers that only confirm
   * acceptance and deliver receiver detail later via webhook.
   */
  receiver?: ProviderReceiver;
  raw: unknown;
};

export type ProviderBalance = {
  provider: ProviderName;
  availableAmountCents: number;
  currency: 'BRL';
  raw: unknown;
};
