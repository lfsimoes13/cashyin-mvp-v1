import type {
  ProviderBalance,
  ProviderName,
  ProviderPixCharge,
  ProviderPixChargeRequest,
  ProviderPixPayment,
  ProviderPixPaymentRequest
} from './provider-types.js';

/**
 * Outbound provider contract.
 *
 * Covers the CashYin → provider direction only (charge creation, lookup,
 * payment, balance). Inbound webhook concerns (signature verification,
 * payload parsing, status normalization) live behind
 * {@link ProviderWebhookAdapter} so the ingress pipeline does not need
 * to depend on the outbound HTTP client just to authenticate a callback.
 */
export interface PaymentProvider {
  readonly name: ProviderName;

  createPixCharge(input: ProviderPixChargeRequest): Promise<ProviderPixCharge>;

  getPixCharge(providerChargeId: string): Promise<ProviderPixCharge>;

  createPixPayment(input: ProviderPixPaymentRequest): Promise<ProviderPixPayment>;

  getBalance(): Promise<ProviderBalance>;
}

