/**
 * Entrypoint: public webhook dispatcher worker.
 *
 * Run as a separate process from the HTTP API. In ECS this maps to a
 * dedicated task definition whose container `command` is
 * `["node", "dist/main-webhook-dispatcher-worker.js"]`. Locally use
 * `pnpm dev:webhook-dispatcher-worker`.
 */

import { env } from './shared/config/env.js';
import { runWorkerEntrypoint, type WorkerEntrypointInput } from './workers/runtime/bootstrap.js';
import { createOutboxDispatcherWorker } from './workers/outbox-dispatcher/index.js';
import { PgNotifyWatcher } from './workers/runtime/pg-notify-watcher.js';

const buildWatcher: WorkerEntrypointInput['buildWatcher'] = env.WORKER_ENABLE_DB_NOTIFY
  ? ({ connectionString, logger }, loop) =>
      new PgNotifyWatcher({
        connectionString,
        channels: ['cashyin_outbox_events_ready'],
        onNotify: () => loop.nudge(),
        logger: logger.child({ component: 'pg-notify-watcher' }),
        reconnectDelayMs: env.WORKER_NOTIFY_RECONNECT_BASE_MS
      })
  : undefined;

const exitCode = await runWorkerEntrypoint({
  name: 'webhook-dispatcher',
  buildWorker: ({ container, logger, intervals }) =>
    createOutboxDispatcherWorker({
      dispatcher: container.clientWebhookDispatcher,
      logger,
      intervals
    }),
  ...(buildWatcher ? { buildWatcher } : {})
});

process.exit(exitCode);
