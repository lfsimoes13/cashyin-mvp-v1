import type { Sql } from '../../shared/db/sql.js';

export type LiquidityReservationStatus = 'reserved' | 'released' | 'expired' | 'consumed';

/**
 * Insert input for a new liquidity reservation.
 *
 * Backwards compatibility note: `principalAmountCents`,
 * `expectedProviderCostCents` and `feeAssessmentId` were introduced by
 * migration 0004 to support the Phase 3 pricing integration. They are
 * optional at the TypeScript level so call sites that have not been
 * migrated yet (none today; both Phase 3 paths set them explicitly) keep
 * working with sensible defaults: principal defaults to `amountCents` and
 * the cost component defaults to zero. The schema CHECK
 * `amount_cents = principal_amount_cents + expected_provider_cost_cents`
 * still has to hold, which the repository enforces by computing
 * `amount_cents` from `(principal + cost)` rather than trusting the caller.
 */
export type LiquidityReservationInsertInput = {
  clientId: string;
  providerAccountId: string;
  cashoutId: string | null;
  /**
   * The principal of the transaction being reserved against the provider.
   * Defaults to the legacy `amountCents` behaviour when omitted.
   */
  principalAmountCents?: number;
  /**
   * The provider's expected fee/cost for the operation, only when the
   * provider deducts it from the same operational balance used for the
   * principal. Defaults to `0`.
   */
  expectedProviderCostCents?: number;
  /**
   * Total reserved amount. When omitted, computed as
   * `principalAmountCents + expectedProviderCostCents`. We keep this
   * parameter for backwards compatibility with callers that already
   * compute the total themselves.
   */
  amountCents?: number;
  feeAssessmentId?: string | null;
  expiresAt: Date;
};

export type LiquidityReservationRecord = {
  id: string;
  clientId: string;
  providerAccountId: string;
  cashoutId: string | null;
  amountCents: number;
  principalAmountCents: number;
  expectedProviderCostCents: number;
  feeAssessmentId: string | null;
  releaseReason: string | null;
  status: LiquidityReservationStatus;
  expiresAt: Date;
  createdAt: Date;
  releasedAt: Date | null;
};

type LiquidityReservationRow = {
  id: string;
  client_id: string;
  provider_account_id: string;
  cashout_id: string | null;
  amount_cents: string;
  principal_amount_cents: string;
  expected_provider_cost_cents: string;
  fee_assessment_id: string | null;
  release_reason: string | null;
  status: LiquidityReservationStatus;
  expires_at: Date;
  created_at: Date;
  released_at: Date | null;
};

function mapRow(row: LiquidityReservationRow): LiquidityReservationRecord {
  return {
    id: row.id,
    clientId: row.client_id,
    providerAccountId: row.provider_account_id,
    cashoutId: row.cashout_id,
    amountCents: Number(row.amount_cents),
    principalAmountCents: Number(row.principal_amount_cents),
    expectedProviderCostCents: Number(row.expected_provider_cost_cents),
    feeAssessmentId: row.fee_assessment_id,
    releaseReason: row.release_reason,
    status: row.status,
    expiresAt: row.expires_at,
    createdAt: row.created_at,
    releasedAt: row.released_at
  };
}

export type LiquidityReleaseOptions = {
  reason?: string;
};

export interface LiquidityRepository {
  insert(sql: Sql, input: LiquidityReservationInsertInput): Promise<LiquidityReservationRecord>;
  release(sql: Sql, reservationId: string, options?: LiquidityReleaseOptions): Promise<void>;
  attachCashout(sql: Sql, reservationId: string, cashoutId: string): Promise<void>;
  /**
   * Returns the still-`reserved` reservation row that the supplied
   * cash-out attached to, if any. Used by the cash-out webhook handler
   * (Phase 8) to settle/release the reservation when the provider
   * confirms a terminal status. Returns `null` when the reservation
   * was already consumed, released, expired or never persisted.
   */
  findActiveByCashoutId(
    sql: Sql,
    cashoutId: string
  ): Promise<LiquidityReservationRecord | null>;
  /**
   * Settles a reservation by flipping `reserved → consumed`. Used when
   * a cash-out completes successfully: the held operational money has
   * actually left the provider account, so the reservation is no longer
   * a "promise" but a recorded outflow.
   */
  markConsumed(sql: Sql, reservationId: string, reason: string): Promise<void>;
}

export class PgLiquidityRepository implements LiquidityRepository {
  async insert(
    sql: Sql,
    input: LiquidityReservationInsertInput
  ): Promise<LiquidityReservationRecord> {
    const principal = input.principalAmountCents ?? input.amountCents;
    if (principal === undefined) {
      throw new Error('LiquidityRepository.insert requires principalAmountCents or amountCents');
    }
    const cost = input.expectedProviderCostCents ?? 0;
    const total = input.amountCents ?? principal + cost;
    if (total !== principal + cost) {
      throw new Error(
        `LiquidityRepository.insert: amountCents (${total}) must equal ` +
          `principalAmountCents (${principal}) + expectedProviderCostCents (${cost})`
      );
    }

    const result = await sql.query<LiquidityReservationRow>(
      `INSERT INTO liquidity_reservations
         (client_id, provider_account_id, cashout_id, amount_cents, principal_amount_cents,
          expected_provider_cost_cents, fee_assessment_id, expires_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING id, client_id, provider_account_id, cashout_id, amount_cents,
                 principal_amount_cents, expected_provider_cost_cents, fee_assessment_id,
                 release_reason, status, expires_at, created_at, released_at`,
      [
        input.clientId,
        input.providerAccountId,
        input.cashoutId,
        total,
        principal,
        cost,
        input.feeAssessmentId ?? null,
        input.expiresAt
      ]
    );
    const row = result.rows[0];
    if (!row) {
      throw new Error('Failed to insert liquidity reservation');
    }
    return mapRow(row);
  }

  async release(
    sql: Sql,
    reservationId: string,
    options: LiquidityReleaseOptions = {}
  ): Promise<void> {
    await sql.query(
      `UPDATE liquidity_reservations
          SET status = 'released',
              released_at = now(),
              release_reason = COALESCE($2, release_reason)
        WHERE id = $1
          AND status = 'reserved'`,
      [reservationId, options.reason ?? null]
    );
  }

  async attachCashout(sql: Sql, reservationId: string, cashoutId: string): Promise<void> {
    await sql.query(
      `UPDATE liquidity_reservations
          SET cashout_id = $2
        WHERE id = $1`,
      [reservationId, cashoutId]
    );
  }

  async findActiveByCashoutId(
    sql: Sql,
    cashoutId: string
  ): Promise<LiquidityReservationRecord | null> {
    const result = await sql.query<LiquidityReservationRow>(
      `SELECT id, client_id, provider_account_id, cashout_id, amount_cents,
              principal_amount_cents, expected_provider_cost_cents, fee_assessment_id,
              release_reason, status, expires_at, created_at, released_at
         FROM liquidity_reservations
        WHERE cashout_id = $1
          AND status = 'reserved'
        ORDER BY created_at DESC
        LIMIT 1`,
      [cashoutId]
    );
    const row = result.rows[0];
    return row ? mapRow(row) : null;
  }

  async markConsumed(sql: Sql, reservationId: string, reason: string): Promise<void> {
    // The `status = 'reserved'` guard makes this idempotent: a concurrent
    // worker that already settled the reservation gets a zero-row update
    // and the caller's transaction still commits cleanly.
    await sql.query(
      `UPDATE liquidity_reservations
          SET status         = 'consumed',
              released_at    = now(),
              release_reason = COALESCE($2, release_reason)
        WHERE id = $1
          AND status = 'reserved'`,
      [reservationId, reason]
    );
  }
}
