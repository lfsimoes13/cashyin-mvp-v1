import type { Sql } from '../../shared/db/sql.js';
import type {
  LiquidityReleaseOptions,
  LiquidityRepository,
  LiquidityReservationRecord
} from './liquidity.repository.js';

const DEFAULT_RESERVATION_TTL_MS = 15 * 60 * 1000;

/**
 * Service-facing input for a cash-out reservation. Either `amountCents`
 * (legacy: total) or the `principal + expectedProviderCost` breakdown
 * (Phase 3+) is accepted. When only `amountCents` is supplied, the cost
 * component defaults to zero and the principal defaults to the total —
 * keeping pre-pricing call sites byte-for-byte compatible.
 */
export type LiquidityReservationRequest = {
  clientId: string;
  providerAccountId: string;
  cashoutId: string | null;
  amountCents?: number;
  principalAmountCents?: number;
  expectedProviderCostCents?: number;
  feeAssessmentId?: string | null;
  expiresAt?: Date;
  ttlMs?: number;
};

/**
 * Persists provider-account liquidity reservations.
 *
 * Liquidity is **not** the same as client accounting balance: a successful
 * reservation indicates that operational money is held at the provider before
 * an outbound payment is initiated. Releases happen on cancel, failure, or
 * webhook confirmation depending on the cash-out lifecycle.
 *
 * Phase 3 split the reserved amount into `principal_amount_cents` and
 * `expected_provider_cost_cents` (see migration 0004) so the reservation
 * can hold enough money for both the Pix principal and the provider's
 * own fee when the provider deducts from the same operational balance.
 * Callers that don't compute pricing still pass only `amountCents`, which
 * is interpreted as the principal and yields a zero-cost reservation.
 */
export class LiquidityService {
  constructor(private readonly repository: LiquidityRepository) {}

  async reserveForCashout(
    sql: Sql,
    input: LiquidityReservationRequest
  ): Promise<LiquidityReservationRecord> {
    const expiresAt =
      input.expiresAt ?? new Date(Date.now() + (input.ttlMs ?? DEFAULT_RESERVATION_TTL_MS));

    const principal = input.principalAmountCents ?? input.amountCents;
    if (principal === undefined) {
      throw new Error(
        'LiquidityService.reserveForCashout requires principalAmountCents or amountCents'
      );
    }
    const cost = input.expectedProviderCostCents ?? 0;
    const total = principal + cost;

    return this.repository.insert(sql, {
      clientId: input.clientId,
      providerAccountId: input.providerAccountId,
      cashoutId: input.cashoutId,
      principalAmountCents: principal,
      expectedProviderCostCents: cost,
      amountCents: total,
      feeAssessmentId: input.feeAssessmentId ?? null,
      expiresAt
    });
  }

  async release(
    sql: Sql,
    reservationId: string,
    options: LiquidityReleaseOptions = {}
  ): Promise<void> {
    await this.repository.release(sql, reservationId, options);
  }

  async attachCashout(sql: Sql, reservationId: string, cashoutId: string): Promise<void> {
    await this.repository.attachCashout(sql, reservationId, cashoutId);
  }

  /**
   * Locates the still-`reserved` reservation that backs a given cash-out,
   * if any. Used by the cash-out webhook handler (Phase 8) to decide
   * whether the cash-out's terminal status should settle, release, or
   * leave the reservation alone (when it was already consumed by a
   * previous webhook delivery).
   */
  async findActiveByCashout(
    sql: Sql,
    cashoutId: string
  ): Promise<LiquidityReservationRecord | null> {
    return this.repository.findActiveByCashoutId(sql, cashoutId);
  }

  /**
   * Settles a reservation: `reserved → consumed`. Called when a cash-out
   * `completed` webhook confirms that the held operational money has
   * actually left the provider account. The reservation row stays for
   * audit; only the status changes.
   */
  async consume(
    sql: Sql,
    reservationId: string,
    options: LiquidityReleaseOptions = {}
  ): Promise<void> {
    await this.repository.markConsumed(
      sql,
      reservationId,
      options.reason ?? 'cashout_completed'
    );
  }
}
