import type { FastifyInstance, FastifyRequest } from 'fastify';
import { env } from '../../shared/config/env.js';
import { collectQueueMetrics } from '../../shared/observability/queue-metrics.js';
import { metrics } from '../../shared/observability/metrics.js';
import type { AppContainer } from '../../app/container.js';

type MetricsRouteDeps = Pick<AppContainer, 'db'>;

export async function registerMetricsRoutes(
  app: FastifyInstance,
  deps: MetricsRouteDeps
): Promise<void> {
  if (!env.METRICS_ENABLED) return;

  app.get(env.METRICS_PATH, async (request, reply) => {
    if (!isMetricsRequestAuthorized(request)) {
      return reply.code(401).send({ error: 'unauthorized' });
    }

    await collectQueueMetrics(deps.db.pool);
    reply.header('content-type', 'text/plain; version=0.0.4; charset=utf-8');
    return reply.send(metrics.renderPrometheus());
  });
}

function isMetricsRequestAuthorized(request: FastifyRequest): boolean {
  if (!env.METRICS_BEARER_TOKEN) return true;
  const authorization = request.headers.authorization;
  return authorization === `Bearer ${env.METRICS_BEARER_TOKEN}`;
}
