import type { Sql } from '../../shared/db/sql.js';
import { resolveOutboxPriority } from './outbox-priority.js';

/**
 * `dlq` is a terminal status set by `markFailed()` after retry budget is
 * exhausted. `claimNextPending` only picks up `pending` and `failed`
 * (transient retry) rows — `dlq` rows are intentionally excluded to prevent
 * the infinite-retry bug where a dead-letter row with `available_at <= now`
 * would be reprocessed forever.
 */
export type OutboxStatus = 'pending' | 'processing' | 'published' | 'failed' | 'dlq';

export type OutboxEventInsertInput = {
  aggregateType: string;
  aggregateId: string;
  eventType: string;
  payload: Record<string, unknown>;
  availableAt?: Date;
  /**
   * Delivery priority (lower = more urgent). When omitted it is derived
   * from `eventType` via {@link resolveOutboxPriority}, so callers get
   * correct prioritisation for free (Fase 2).
   */
  priority?: number;
};

export type OutboxEventRecord = {
  id: string;
  aggregateType: string;
  aggregateId: string;
  eventType: string;
  payload: Record<string, unknown>;
  status: OutboxStatus;
  attempts: number;
  priority: number;
  availableAt: Date;
  createdAt: Date;
  updatedAt: Date;
  publishedAt: Date | null;
};

type OutboxEventRow = {
  id: string;
  aggregate_type: string;
  aggregate_id: string;
  event_type: string;
  payload: Record<string, unknown>;
  status: OutboxStatus;
  attempts: number;
  priority: number | string;
  available_at: Date;
  created_at: Date;
  updated_at: Date;
  published_at: Date | null;
};

function mapRow(row: OutboxEventRow): OutboxEventRecord {
  return {
    id: row.id,
    aggregateType: row.aggregate_type,
    aggregateId: row.aggregate_id,
    eventType: row.event_type,
    payload: row.payload,
    status: row.status,
    attempts: row.attempts,
    priority: Number(row.priority),
    availableAt: row.available_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    publishedAt: row.published_at
  };
}

export type OutboxClaimInput = {
  /** Reference moment for `available_at <= now` filtering. */
  now: Date;
  /**
   * Optional whitelist of `aggregate_type` values. When the public
   * dispatcher and other consumers share the same outbox table, this
   * lets each worker drain only the rows it owns (e.g.
   * `['cash_in', 'cashout']` for the public dispatcher).
   *
   * Empty arrays are treated as "no filter" so callers can supply a
   * dynamically-built list without special-casing the empty case.
   */
  aggregateTypes?: readonly string[];
  /**
   * Optional `event_type` whitelist (Phase B1 dispatcher partitioning). When
   * set, only rows whose `event_type` is in this list are claimed, letting a
   * dedicated process drain a critical subset (e.g. `['pix.cash_in.paid']`)
   * without head-of-line blocking from slower deliveries. Empty = no filter.
   */
  eventTypes?: readonly string[];
  /**
   * Optional `event_type` blacklist. Rows whose `event_type` is in this list
   * are never claimed, so a "default" dispatcher can drain everything EXCEPT
   * the critical subset handled by a dedicated worker. Empty = no filter.
   */
  excludeEventTypes?: readonly string[];
};

export type OutboxScheduleRetryInput = {
  id: string;
  /** Wall-clock moment at which the row becomes eligible again. */
  availableAt: Date;
};

export interface OutboxRepository {
  insert(sql: Sql, event: OutboxEventInsertInput): Promise<OutboxEventRecord>;

  /**
   * Atomically claims the next ready-to-process row using
   * `FOR UPDATE SKIP LOCKED`. Flips the row from `pending`/`failed` to
   * `processing` and increments `attempts`. Returns `null` when nothing
   * is due. The transaction the caller supplies must remain open until
   * the row is finalised, otherwise the lock is released and a sibling
   * worker may race for the same row.
   */
  claimNextPending(sql: Sql, input: OutboxClaimInput): Promise<OutboxEventRecord | null>;

  /** Commits the row in `published` with `published_at` set to now. */
  markPublished(sql: Sql, id: string): Promise<void>;

  /**
   * Routes the row back to `pending` with a future `available_at`.
   * Idempotent: a follow-up claim will pick the row up only when the
   * scheduled moment has passed.
   */
  scheduleRetry(sql: Sql, input: OutboxScheduleRetryInput): Promise<void>;

  /**
   * Marks the row as `dlq` permanently (dead-letter semantics). Terminal:
   * `claimNextPending` only selects `pending`/`failed` so `dlq` rows are
   * never retried again.
   *
   * Note: do NOT use `failed` for permanent failures — `failed` is picked
   * back up by `claimNextPending` once `available_at <= now`, which would
   * cause the retry-forever bug.
   */
  markFailed(sql: Sql, id: string): Promise<void>;

  /**
   * Reclaims rows stuck in `processing` by a crashed worker. Any row whose
   * `updated_at < staleBefore` and `status = 'processing'` is flipped back
   * to `pending` with `available_at = now()` so a live worker can retry it.
   *
   * Returns the number of rows reclaimed. Safe to call from multiple workers
   * concurrently (each UPDATE is atomic per row).
   */
  reclaimStaleProcessing(sql: Sql, staleBefore: Date): Promise<number>;
}

const RETURNING_COLS = `id, aggregate_type, aggregate_id, event_type, payload, status, attempts,
                 priority, available_at, created_at, updated_at, published_at` as const;

export class PgOutboxRepository implements OutboxRepository {
  async insert(sql: Sql, event: OutboxEventInsertInput): Promise<OutboxEventRecord> {
    const priority = event.priority ?? resolveOutboxPriority(event.eventType);
    const result = await sql.query<OutboxEventRow>(
      `INSERT INTO outbox_events
         (aggregate_type, aggregate_id, event_type, payload, available_at, priority)
       VALUES ($1, $2, $3, $4::jsonb, COALESCE($5, now()), $6)
       RETURNING ${RETURNING_COLS}`,
      [
        event.aggregateType,
        event.aggregateId,
        event.eventType,
        JSON.stringify(event.payload),
        event.availableAt ?? null,
        priority
      ]
    );
    const row = result.rows[0];
    if (!row) {
      throw new Error('Failed to insert outbox_events row');
    }
    return mapRow(row);
  }

  async claimNextPending(
    sql: Sql,
    input: OutboxClaimInput
  ): Promise<OutboxEventRecord | null> {
    const params: unknown[] = [input.now];
    const filterClauses: string[] = [];
    if (input.aggregateTypes && input.aggregateTypes.length > 0) {
      params.push([...input.aggregateTypes]);
      filterClauses.push(`AND aggregate_type = ANY($${params.length}::text[])`);
    }
    if (input.eventTypes && input.eventTypes.length > 0) {
      params.push([...input.eventTypes]);
      filterClauses.push(`AND event_type = ANY($${params.length}::text[])`);
    }
    if (input.excludeEventTypes && input.excludeEventTypes.length > 0) {
      params.push([...input.excludeEventTypes]);
      filterClauses.push(`AND NOT (event_type = ANY($${params.length}::text[]))`);
    }
    const aggregateClause = filterClauses.join('\n            ');
    // `next_event` aliases the picked id as `target_id` (instead of plain
    // `id`) so the outer `RETURNING` clause references `outbox_events.id`
    // unambiguously. Without the alias both `outbox_events` and `next_event`
    // expose an `id` column to the outer query, and PostgreSQL rejects the
    // RETURNING list with `42702 ambiguous column reference: "id"`.
    const result = await sql.query<OutboxEventRow>(
      `WITH next_event AS (
         SELECT id AS target_id
           FROM outbox_events
          WHERE status IN ('pending', 'failed')
            AND available_at <= $1
            ${aggregateClause}
          ORDER BY priority ASC, available_at ASC, created_at ASC
          LIMIT 1
          FOR UPDATE SKIP LOCKED
       )
       UPDATE outbox_events e
          SET status   = 'processing',
              attempts = e.attempts + 1
         FROM next_event n
        WHERE e.id = n.target_id
       RETURNING ${RETURNING_COLS}`,
      params
    );
    const row = result.rows[0];
    return row ? mapRow(row) : null;
  }

  async markPublished(sql: Sql, id: string): Promise<void> {
    await sql.query(
      `UPDATE outbox_events
          SET status       = 'published',
              published_at = now()
        WHERE id = $1`,
      [id]
    );
  }

  async scheduleRetry(sql: Sql, input: OutboxScheduleRetryInput): Promise<void> {
    await sql.query(
      `UPDATE outbox_events
          SET status       = 'pending',
              available_at = $2
        WHERE id = $1`,
      [input.id, input.availableAt]
    );
  }

  async markFailed(sql: Sql, id: string): Promise<void> {
    await sql.query(
      `UPDATE outbox_events
          SET status = 'dlq'
        WHERE id = $1`,
      [id]
    );
  }

  async reclaimStaleProcessing(sql: Sql, staleBefore: Date): Promise<number> {
    const result = await sql.query(
      `UPDATE outbox_events
          SET status       = 'pending',
              available_at = now()
        WHERE status     = 'processing'
          AND updated_at < $1`,
      [staleBefore]
    );
    return result.rowCount ?? 0;
  }
}
