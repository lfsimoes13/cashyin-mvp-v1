import type { Sql } from '../../shared/db/sql.js';
import type { OutboxEventInsertInput, OutboxRepository } from './outbox.repository.js';

/**
 * Writes outbox events through the supplied SQL executor so that the event
 * row commits or rolls back together with the financial state transition that
 * produced it. Workers are responsible for draining the queue downstream.
 */
export class OutboxService {
  constructor(private readonly repository: OutboxRepository) {}

  async enqueue(sql: Sql, event: OutboxEventInsertInput): Promise<void> {
    await this.repository.insert(sql, event);
  }
}
