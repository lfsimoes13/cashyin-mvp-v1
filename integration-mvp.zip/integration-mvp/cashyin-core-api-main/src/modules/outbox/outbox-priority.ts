/**
 * Outbox delivery priority (Fase 2). Lower = more urgent; the dispatcher
 * claim orders by `priority ASC, available_at ASC, created_at ASC`.
 *
 * Keyed off the canonical outbox `event_type` (`pix.cash_in.*` /
 * `pix.cash_out.*`), matching the public envelope name. Legacy `cashout.*`
 * tokens are still mapped (backward compatibility for rows enqueued before
 * migration 0015). The mapping mirrors migrations 0013/0015's backfill so
 * code and SQL never drift.
 */
export const OUTBOX_PRIORITY = {
  /** Critical cash-in paid — must be delivered first. */
  CASH_IN_PAID: 10,
  /** Other terminal cash-in events (expired/cancelled/failed/refunded). */
  CASH_IN_TERMINAL: 30,
  /** Cash-out events — may tolerate queueing behind cash-in. */
  CASH_OUT: 60,
  /** Informational / default. Matches the column DEFAULT. */
  DEFAULT: 100
} as const;

/**
 * Resolves the delivery priority for an outbox event type.
 * Unknown types fall back to {@link OUTBOX_PRIORITY.DEFAULT} so a new
 * event never accidentally jumps ahead of `pix.cash_in.paid`.
 */
export function resolveOutboxPriority(eventType: string): number {
  if (eventType === 'pix.cash_in.paid') return OUTBOX_PRIORITY.CASH_IN_PAID;
  if (eventType.startsWith('pix.cash_in.')) return OUTBOX_PRIORITY.CASH_IN_TERMINAL;
  if (eventType.startsWith('pix.cash_out.')) return OUTBOX_PRIORITY.CASH_OUT;
  // Legacy token (pre-0015) — keep mapping so in-flight rows keep their lane.
  if (eventType.startsWith('cashout.')) return OUTBOX_PRIORITY.CASH_OUT;
  return OUTBOX_PRIORITY.DEFAULT;
}
