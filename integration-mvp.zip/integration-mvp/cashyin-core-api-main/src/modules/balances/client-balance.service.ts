/**
 * Per-client balance reads against the immutable ledger.
 *
 * # What "balance" means here
 *
 * The platform invariant (see `docs/architecture.md` §"ledger-first
 * accounting") is that **client balances are not derived from provider
 * balances**. The ledger is the source of truth: every cash-in that's
 * confirmed credits `client_liability[client]`; every cash-out that's
 * confirmed debits the same account. The available balance is the
 * net of those entries.
 *
 *     available_balance = SUM(credit) - SUM(debit)  on the client_liability
 *                                                   account for this client
 *
 * Blocked balance is the cents "earmarked" by in-flight cash-outs via
 * `liquidity_reservations(status='reserved')`. They have NOT been
 * debited from the ledger yet (that happens when the cash-out is
 * confirmed), but they reduce what the client may operate against.
 *
 *     blocked_balance = SUM(amount_cents) on liquidity_reservations
 *                                          for this client where status='reserved'
 *     total_balance   = available_balance + blocked_balance
 *
 * No rounding is applied — entries are stored in cents and the sum is
 * exact integer arithmetic.
 *
 * # Why not query `/v1/providers/balance`?
 *
 * The provider passthrough returns the **total** balance held by Bents
 * (a pool shared across every CashYin tenant that routes to the same
 * `provider_account`). Reporting that to a client would (a) leak third
 * parties' money and (b) lie about how much the client can actually
 * spend — the cash-out path enforces ledger semantics, not pool
 * semantics.
 *
 * # Two views: public vs internal
 *
 * Public (`/v1/balance` consumers): snake_case, includes
 * `blocked_balance`, `total_balance` and `updated_at`. See
 * {@link PublicBalanceView}.
 *
 * Internal (cash-out balance check, reconciliation jobs): just the
 * available cents as a number. See {@link getAvailableCents}.
 */

import type { Sql } from '../../shared/db/sql.js';

/**
 * Public-facing balance contract returned by `GET /v1/balance`.
 *
 * BREAKING CHANGE (May 2026): the previous shape was
 * `{ clientId, availableCents, currency }`. Clients consuming the old
 * fields must migrate to `available_balance`, `blocked_balance`,
 * `total_balance` and `updated_at`. The new shape is snake_case to
 * align with the rest of the public API (pix_charges, webhook events,
 * etc.).
 */
export type PublicBalanceView = {
  /** Net SUM(credit) − SUM(debit) on `client_liability[client]`. */
  available_balance: number;
  /** Cents reserved by in-flight cash-outs (`liquidity_reservations.status='reserved'`). */
  blocked_balance: number;
  /** `available_balance + blocked_balance` — total economic position. */
  total_balance: number;
  currency: 'BRL';
  /**
   * ISO-8601 UTC timestamp of the last balance-affecting event for the
   * client. Resolution priority:
   *   1. Latest `ledger_entries.created_at` on the client_liability account
   *   2. Latest `liquidity_reservations.created_at` for the client
   *   3. `clients.updated_at` (fallback for a client with no activity)
   */
  updated_at: string;
};

/**
 * Internal snapshot returned from the repository. Cents-as-number, raw
 * Date for `updatedAt` so the service layer owns ISO formatting.
 */
export type BalanceSnapshot = {
  availableCents: number;
  blockedCents: number;
  updatedAt: Date;
};

export interface ClientBalanceRepository {
  /**
   * Returns the live balance snapshot for a client in a single
   * round-trip. The query uses LEFT JOINs so a client with no ledger
   * activity and no liquidity reservations still resolves to
   * `availableCents=0`, `blockedCents=0`, `updatedAt=clients.updated_at`.
   */
  getSnapshot(sql: Sql, clientId: string): Promise<BalanceSnapshot | null>;
}

export class PgClientBalanceRepository implements ClientBalanceRepository {
  async getSnapshot(sql: Sql, clientId: string): Promise<BalanceSnapshot | null> {
    // CTEs let us compute available, blocked and the freshness timestamp
    // in one SQL round-trip. The outer `clients` row drives the join so
    // a client with zero activity still returns a row.
    const result = await sql.query<{
      available_cents: string;
      blocked_cents: string;
      updated_at: Date;
    }>(
      `WITH ledger_summary AS (
         SELECT COALESCE(SUM(
                  CASE WHEN le.direction = 'credit' THEN le.amount_cents
                       WHEN le.direction = 'debit'  THEN -le.amount_cents
                  END
                ), 0)::bigint AS available_cents,
                MAX(le.created_at) AS last_entry_at
           FROM ledger_entries le
           JOIN ledger_accounts la ON la.id = le.account_id
          WHERE la.client_id    = $1
            AND la.account_type = 'client_liability'
            AND la.currency     = 'BRL'
       ),
       liquidity_summary AS (
         SELECT COALESCE(SUM(amount_cents), 0)::bigint AS blocked_cents,
                MAX(created_at) AS last_reservation_at
           FROM liquidity_reservations
          WHERE client_id = $1
            AND status    = 'reserved'
       )
       SELECT ls.available_cents,
              lq.blocked_cents,
              GREATEST(
                COALESCE(ls.last_entry_at,       '-infinity'::timestamptz),
                COALESCE(lq.last_reservation_at, '-infinity'::timestamptz),
                c.updated_at
              ) AS updated_at
         FROM clients c
         CROSS JOIN ledger_summary ls
         CROSS JOIN liquidity_summary lq
        WHERE c.id = $1`,
      [clientId]
    );
    const row = result.rows[0];
    if (!row) return null;
    return {
      availableCents: Number(row.available_cents),
      blockedCents: Number(row.blocked_cents),
      updatedAt: row.updated_at
    };
  }
}

export type ClientBalanceServiceDeps = {
  repository: ClientBalanceRepository;
  sql: Sql;
};

export class ClientBalanceService {
  private readonly repository: ClientBalanceRepository;
  private readonly sql: Sql;

  constructor(deps: ClientBalanceServiceDeps) {
    this.repository = deps.repository;
    this.sql = deps.sql;
  }

  /**
   * Returns the public-facing balance view for `GET /v1/balance`. A
   * client that does not exist (or was deleted) resolves to all-zeros
   * with `updated_at = new Date(0).toISOString()` to surface the
   * missing-client condition without throwing — the route handler is
   * the appropriate place to convert that to a 404 if desired.
   */
  async getPublicBalance(clientId: string): Promise<PublicBalanceView> {
    const snapshot = await this.repository.getSnapshot(this.sql, clientId);
    if (!snapshot) {
      return {
        available_balance: 0,
        blocked_balance: 0,
        total_balance: 0,
        currency: 'BRL',
        updated_at: new Date(0).toISOString()
      };
    }
    return {
      available_balance: snapshot.availableCents,
      blocked_balance: snapshot.blockedCents,
      total_balance: snapshot.availableCents + snapshot.blockedCents,
      currency: 'BRL',
      updated_at: snapshot.updatedAt.toISOString()
    };
  }

  /**
   * Internal helper used by `CashoutService` to gate cash-out creation
   * against the available ledger balance. Returns ONLY the cents value
   * because the cash-out check has no use for the public view fields.
   */
  async getAvailableCents(clientId: string): Promise<number> {
    const snapshot = await this.repository.getSnapshot(this.sql, clientId);
    return snapshot?.availableCents ?? 0;
  }
}
