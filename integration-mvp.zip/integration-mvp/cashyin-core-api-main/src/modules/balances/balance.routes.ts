import type { FastifyInstance } from 'fastify';
import { AUTH_SCOPES } from '../../shared/auth/auth-scopes.js';
import type { AuthPreHandlers } from '../../modules/auth/auth-enforcement.js';
import type { ClientBalanceService } from './client-balance.service.js';

export type BalanceRoutesDeps = {
  clientBalanceService: ClientBalanceService;
  auth: AuthPreHandlers;
};

export async function registerBalanceRoutes(
  app: FastifyInstance,
  deps: BalanceRoutesDeps
): Promise<void> {
  /**
   * Returns the authenticated client's balance:
   *   - `available_balance`: net SUM(credit) − SUM(debit) on
   *     `client_liability[client_id]`.
   *   - `blocked_balance`:   cents reserved by in-flight cash-outs
   *     (`liquidity_reservations.status='reserved'`).
   *   - `total_balance`:     `available_balance + blocked_balance`.
   *   - `currency`:          always `BRL`.
   *   - `updated_at`:        ISO-8601 of the latest balance-affecting
   *                          event (max of ledger entry, liquidity
   *                          reservation, or `clients.updated_at`).
   *
   * BREAKING CHANGE (May 2026): the previous response was
   * `{ clientId, availableCents, currency }`. Migrate consumers to
   * the snake_case fields above.
   *
   * Replaces the legacy `/v1/providers/balance` passthrough, which
   * leaked the pool balance of the underlying provider account
   * across tenants.
   */
  // Gated by the dedicated `balance:read` scope (part of both
  // DEFAULT_CLIENT_API_SCOPES and DEFAULT_BFF_SCOPES). The scope guard is
  // staged by AUTH_ENFORCEMENT_MODE like the Pix routes (no-op in `off`).
  app.get(
    '/v1/balance',
    {
      preHandler: [
        deps.auth.authenticate,
        deps.auth.resolveAuthContext,
        deps.auth.requireScope(AUTH_SCOPES.BALANCE_READ)
      ]
    },
    async (request) => {
      const client = request.client!;
      return deps.clientBalanceService.getPublicBalance(client.clientId);
    }
  );
}
