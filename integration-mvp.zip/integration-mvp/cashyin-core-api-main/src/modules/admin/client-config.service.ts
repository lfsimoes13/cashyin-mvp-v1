/**
 * Read-only aggregation of a client's effective commercial configuration,
 * consumed by the Dashboard/BFF through `/v1/admin/config/*`.
 *
 * # Security: strict allow-list
 *
 * This service composes existing client-scoped reads (the active pricing
 * rule and the active provider assignment) and re-projects them through a
 * **deliberate allow-list** of fields. It MUST NEVER expose:
 *
 *   - provider cost rules / CashYin margin (`provider_cost_rules`,
 *     `*_margin_*`),
 *   - subsidy policy limits (`*_subsidy_limit_cents`, `subsidy_events`),
 *   - internal identifiers (`pricing_plan_version_id`, rule/assignment ids),
 *   - provider account ids or any `metadata` JSONB,
 *   - any secret (`key_hash`, `signing_secret`, provider credentials).
 *
 * Only the client-facing fee formula (what the tenant is charged) and the
 * coarse routing (which provider handles each operation) are returned.
 */

import type { Sql } from '../../shared/db/sql.js';
import type { OperationType } from '../../providers/contracts/provider-types.js';
import type { BillingMode, Bps, Cents, RoundingMode } from '../pricing/pricing.types.js';
import type { PricingRuleRepository } from '../pricing/pricing-rule.repository.js';
import type { ProviderAssignmentRepository } from '../providers/provider-assignment.repository.js';

/** Domain operations exposed by the config endpoints, in stable order. */
const OPERATIONS: readonly OperationType[] = ['cash_in', 'cash_out'];

/**
 * Canonical fee trigger per operation. Mirrors the values used by the
 * payment/cashout services when assessing fees so the "effective config"
 * the client sees matches what is actually charged.
 */
const FEE_TRIGGER_BY_OPERATION: Readonly<Record<OperationType, string>> = {
  cash_in: 'cash_in_paid',
  cash_out: 'cash_out_created'
};

/**
 * Client-facing fee formula for one operation. Strict allow-list — no
 * margin, subsidy, plan-version id or other internal fields.
 */
export type ClientFeeConfig = {
  operationType: OperationType;
  triggerEvent: string;
  fixedFeeCents: Cents;
  variableFeeBps: Bps;
  minFeeCents: Cents | null;
  maxFeeCents: Cents | null;
  billingMode: BillingMode;
  roundingMode: RoundingMode;
};

/** Coarse routing for one operation. No account id / weight / metadata. */
export type ClientRoutingConfig = {
  operationType: OperationType;
  providerName: string;
};

export type ClientConfigServiceDeps = {
  pricingRuleRepository: PricingRuleRepository;
  providerAssignmentRepository: ProviderAssignmentRepository;
  sql: Sql;
};

export class ClientConfigService {
  private readonly pricingRuleRepository: PricingRuleRepository;
  private readonly providerAssignmentRepository: ProviderAssignmentRepository;
  private readonly sql: Sql;

  constructor(deps: ClientConfigServiceDeps) {
    this.pricingRuleRepository = deps.pricingRuleRepository;
    this.providerAssignmentRepository = deps.providerAssignmentRepository;
    this.sql = deps.sql;
  }

  /**
   * Active fee formula per operation for the given tenant. Operations
   * without an active pricing rule are simply omitted (no error), matching
   * the no-op pricing semantics elsewhere in the system.
   */
  async listFees(clientId: string): Promise<ClientFeeConfig[]> {
    const out: ClientFeeConfig[] = [];
    for (const operationType of OPERATIONS) {
      const rule = await this.pricingRuleRepository.findActiveForClient(this.sql, {
        clientId,
        operationType,
        triggerEvent: FEE_TRIGGER_BY_OPERATION[operationType]
      });
      if (!rule) continue;
      out.push({
        operationType: rule.operationType,
        triggerEvent: rule.triggerEvent,
        fixedFeeCents: rule.fixedFeeCents,
        variableFeeBps: rule.variableFeeBps,
        minFeeCents: rule.minFeeCents,
        maxFeeCents: rule.maxFeeCents,
        billingMode: rule.billingMode,
        roundingMode: rule.roundingMode
      });
    }
    return out;
  }

  /**
   * Active provider routing per operation. Exposes only `providerName`;
   * the underlying account id, weight, version and metadata are withheld.
   */
  async listRouting(clientId: string): Promise<ClientRoutingConfig[]> {
    const out: ClientRoutingConfig[] = [];
    for (const operationType of OPERATIONS) {
      const assignment = await this.providerAssignmentRepository.findActive(
        this.sql,
        clientId,
        operationType
      );
      if (!assignment) continue;
      out.push({
        operationType: assignment.operationType,
        providerName: assignment.providerName
      });
    }
    return out;
  }
}
