/**
 * Administrative endpoints under `/v1/admin/*` for self-service management of
 * a client's own API keys and webhook endpoints.
 *
 * # Authorization
 *
 * Unlike the public `/v1/pix/*` routes (whose scope checks are *staged* by
 * `AUTH_ENFORCEMENT_MODE` for backward-compatible rollout), these endpoints
 * are brand new and therefore **always** enforce authentication, context
 * resolution and their scope — they are built with a hard `enforce` mode
 * regardless of the global flag. There is no legacy client to protect.
 *
 * # Tenant isolation
 *
 * The acting `clientId` is derived exclusively from the authenticated
 * principal (`request.authContext.clientId`); it is never read from the body
 * or path. Every resource operation is constrained to that client, so a
 * caller can only ever manage its own credentials and endpoints. Cross-tenant
 * references resolve to 404.
 */

import type { FastifyInstance, FastifyRequest, preHandlerAsyncHookHandler } from 'fastify';
import { z } from 'zod';
import { AppError } from '../../shared/errors/app-error.js';
import { AUTH_SCOPES, isAuthScope, type AuthScope } from '../../shared/auth/auth-scopes.js';
import { buildRequireScope, buildResolveAuthContext } from '../auth/auth-enforcement.js';
import type { ClientApiKeyService } from '../auth/client-api-key.service.js';
import type { UserClientGrantService } from '../auth/user-client-grant.js';
import type { ClientWebhookEndpointAdminService } from '../webhooks/client-webhook-endpoint.admin.js';
import type { ClientConfigService } from './client-config.service.js';

export type AdminRoutesDeps = {
  /** Shared multi-channel authenticator from the composition root. */
  authenticate: preHandlerAsyncHookHandler;
  clientApiKeyService: ClientApiKeyService;
  userClientGrantService: UserClientGrantService;
  webhookEndpointAdminService: ClientWebhookEndpointAdminService;
  clientConfigService: ClientConfigService;
};

const createApiKeySchema = z.object({
  label: z.string().trim().min(1).max(120).optional(),
  scopes: z.array(z.string()).nonempty().optional(),
  expiresAt: z.string().datetime().optional()
});

const upsertBffGrantSchema = z.object({
  scopes: z.array(z.string()).nonempty()
});

const createWebhookEndpointSchema = z.object({
  eventPattern: z.string().trim().min(1).max(200),
  targetUrl: z.string().url().max(2000),
  description: z.string().trim().max(500).optional()
});

const updateWebhookEndpointSchema = z
  .object({
    targetUrl: z.string().url().max(2000).optional(),
    status: z.enum(['active', 'disabled']).optional(),
    description: z.string().trim().max(500).optional(),
    eventPattern: z.string().trim().min(1).max(200).optional()
  })
  .refine((patch) => Object.keys(patch).length > 0, {
    message: 'At least one field must be provided'
  });

function validationError(details: unknown): AppError {
  return new AppError('validation_error', 'Invalid request payload', 422, details);
}

/**
 * Derive the acting tenant from the resolved context, narrowing the
 * optional `clientId` to a definite string. After the `enforce` scope guard
 * the context is always present; this is a defensive belt-and-braces.
 */
function requireClientId(request: FastifyRequest): string {
  const clientId = request.authContext?.clientId;
  if (clientId === undefined) {
    throw new AppError('auth_required', 'Authentication required', 401);
  }
  return clientId;
}

/** Validate + narrow an optional scope list to the canonical union. */
function parseScopes(raw: string[] | undefined): readonly AuthScope[] | undefined {
  if (raw === undefined) return undefined;
  const unknown = raw.filter((scope) => !isAuthScope(scope));
  if (unknown.length > 0) {
    throw validationError({ scopes: `Unknown scope(s): ${unknown.join(', ')}` });
  }
  return raw.filter(isAuthScope);
}

export async function registerAdminRoutes(app: FastifyInstance, deps: AdminRoutesDeps): Promise<void> {
  // Admin routes always enforce scope, independent of AUTH_ENFORCEMENT_MODE.
  // (Context resolution is unconditional; only the scope guard is hard-`enforce`.)
  const resolveAuthContext = buildResolveAuthContext();
  const requireScope = (scope: AuthScope): preHandlerAsyncHookHandler => buildRequireScope('enforce', scope);
  const guard = (scope: AuthScope): preHandlerAsyncHookHandler[] => [
    deps.authenticate,
    resolveAuthContext,
    requireScope(scope)
  ];

  // ── API keys ───────────────────────────────────────────────────────────

  app.post('/v1/admin/api-keys', { preHandler: guard(AUTH_SCOPES.API_KEYS_MANAGE) }, async (request, reply) => {
    const parsed = createApiKeySchema.safeParse(request.body ?? {});
    if (!parsed.success) {
      throw validationError(parsed.error.flatten());
    }
    const clientId = requireClientId(request);
    const scopes = parseScopes(parsed.data.scopes);
    const expiresAt = parsed.data.expiresAt ? new Date(parsed.data.expiresAt) : null;
    if (expiresAt && expiresAt.getTime() <= Date.now()) {
      throw validationError({ expiresAt: 'expiresAt must be in the future' });
    }
    const minted = await deps.clientApiKeyService.generate({
      clientId,
      ...(parsed.data.label !== undefined ? { label: parsed.data.label } : {}),
      ...(scopes !== undefined ? { scopes } : {}),
      expiresAt
    });
    return reply.status(201).send({
      id: minted.id,
      rawKey: minted.rawKey,
      keyPrefix: minted.keyPrefix,
      label: minted.label,
      scopes: minted.scopes,
      expiresAt: minted.expiresAt,
      signingSecret: minted.signingSecret
    });
  });

  app.get('/v1/admin/api-keys', { preHandler: guard(AUTH_SCOPES.API_KEYS_MANAGE) }, async (request) => {
    const clientId = requireClientId(request);
    const keys = await deps.clientApiKeyService.listByClient(clientId);
    return { data: keys };
  });

  app.post(
    '/v1/admin/api-keys/:id/rotate',
    { preHandler: guard(AUTH_SCOPES.API_KEYS_MANAGE) },
    async (request, reply) => {
      const { id } = request.params as { id: string };
      const clientId = requireClientId(request);
      const minted = await deps.clientApiKeyService.rotate(id, clientId);
      if (!minted) {
        return reply.status(404).send({
          error: { code: 'api_key_not_found', message: 'API key not found', request_id: request.id }
        });
      }
      return reply.status(201).send({
        id: minted.id,
        rawKey: minted.rawKey,
        keyPrefix: minted.keyPrefix,
        label: minted.label,
        scopes: minted.scopes,
        expiresAt: minted.expiresAt,
        signingSecret: minted.signingSecret
      });
    }
  );

  app.post(
    '/v1/admin/api-keys/:id/revoke',
    { preHandler: guard(AUTH_SCOPES.API_KEYS_MANAGE) },
    async (request, reply) => {
      const { id } = request.params as { id: string };
      const clientId = requireClientId(request);
      const revoked = await deps.clientApiKeyService.revoke(id, clientId);
      if (!revoked) {
        return reply.status(404).send({
          error: { code: 'api_key_not_found', message: 'API key not found', request_id: request.id }
        });
      }
      return reply.status(204).send();
    }
  );

  // ── BFF per-user access grants (D7) ──────────────────────────────────────
  //
  // Manage which scopes an actor (human, as identified by the BFF) may exercise
  // on the calling tenant. Gated by the elevated `clients:manage` scope (never
  // in the default sets). The grant's scopes are validated against the BFF
  // channel ceiling (DEFAULT_BFF_SCOPES) in the service.

  app.get(
    '/v1/admin/bff-grants',
    { preHandler: guard(AUTH_SCOPES.CLIENTS_MANAGE) },
    async (request) => {
      const clientId = requireClientId(request);
      const data = await deps.userClientGrantService.listByClient(clientId);
      return { data };
    }
  );

  app.put(
    '/v1/admin/bff-grants/:actorUserId',
    { preHandler: guard(AUTH_SCOPES.CLIENTS_MANAGE) },
    async (request, reply) => {
      const parsed = upsertBffGrantSchema.safeParse(request.body);
      if (!parsed.success) {
        throw validationError(parsed.error.flatten());
      }
      const { actorUserId } = request.params as { actorUserId: string };
      const clientId = requireClientId(request);
      const grant = await deps.userClientGrantService.grant({
        clientId,
        actorUserId,
        scopes: parsed.data.scopes
      });
      return reply.status(200).send(grant);
    }
  );

  app.delete(
    '/v1/admin/bff-grants/:actorUserId',
    { preHandler: guard(AUTH_SCOPES.CLIENTS_MANAGE) },
    async (request, reply) => {
      const { actorUserId } = request.params as { actorUserId: string };
      const clientId = requireClientId(request);
      const revoked = await deps.userClientGrantService.revoke(clientId, actorUserId);
      if (!revoked) {
        return reply.status(404).send({
          error: { code: 'bff_grant_not_found', message: 'BFF grant not found', request_id: request.id }
        });
      }
      return reply.status(204).send();
    }
  );

  // ── Webhook endpoints ────────────────────────────────────────────────────

  app.get(
    '/v1/admin/webhook-endpoints',
    { preHandler: guard(AUTH_SCOPES.WEBHOOKS_MANAGE) },
    async (request) => {
      const clientId = requireClientId(request);
      const endpoints = await deps.webhookEndpointAdminService.listByClient(clientId);
      return { data: endpoints };
    }
  );

  app.post(
    '/v1/admin/webhook-endpoints',
    { preHandler: guard(AUTH_SCOPES.WEBHOOKS_MANAGE) },
    async (request, reply) => {
      const parsed = createWebhookEndpointSchema.safeParse(request.body);
      if (!parsed.success) {
        throw validationError(parsed.error.flatten());
      }
      const clientId = requireClientId(request);
      const created = await deps.webhookEndpointAdminService.create({
        clientId,
        eventPattern: parsed.data.eventPattern,
        targetUrl: parsed.data.targetUrl,
        description: parsed.data.description ?? null
      });
      return reply.status(201).send({ ...created.endpoint, signingSecret: created.signingSecret });
    }
  );

  app.patch(
    '/v1/admin/webhook-endpoints/:id',
    { preHandler: guard(AUTH_SCOPES.WEBHOOKS_MANAGE) },
    async (request, reply) => {
      const parsed = updateWebhookEndpointSchema.safeParse(request.body);
      if (!parsed.success) {
        throw validationError(parsed.error.flatten());
      }
      const { id } = request.params as { id: string };
      const clientId = requireClientId(request);
      const patch = {
        ...(parsed.data.targetUrl !== undefined ? { targetUrl: parsed.data.targetUrl } : {}),
        ...(parsed.data.status !== undefined ? { status: parsed.data.status } : {}),
        ...(parsed.data.description !== undefined ? { description: parsed.data.description } : {}),
        ...(parsed.data.eventPattern !== undefined ? { eventPattern: parsed.data.eventPattern } : {})
      };
      const updated = await deps.webhookEndpointAdminService.update(clientId, id, patch);
      if (!updated) {
        return reply.status(404).send({
          error: {
            code: 'webhook_endpoint_not_found',
            message: 'Webhook endpoint not found',
            request_id: request.id
          }
        });
      }
      return updated;
    }
  );

  app.post(
    '/v1/admin/webhook-endpoints/:id/disable',
    { preHandler: guard(AUTH_SCOPES.WEBHOOKS_MANAGE) },
    async (request, reply) => {
      const { id } = request.params as { id: string };
      const clientId = requireClientId(request);
      const updated = await deps.webhookEndpointAdminService.disable(clientId, id);
      if (!updated) {
        return reply.status(404).send({
          error: {
            code: 'webhook_endpoint_not_found',
            message: 'Webhook endpoint not found',
            request_id: request.id
          }
        });
      }
      return updated;
    }
  );

  // ── Client configuration (read-only) ─────────────────────────────────────
  //
  // Effective commercial configuration for the calling tenant. Read-only and
  // gated by `clients:read` (already part of the BFF default set). The service
  // applies a strict allow-list so margin, subsidy policy, provider account
  // ids, metadata and secrets are never exposed.

  app.get(
    '/v1/admin/config/fees',
    { preHandler: guard(AUTH_SCOPES.CLIENTS_READ) },
    async (request) => {
      const clientId = requireClientId(request);
      const data = await deps.clientConfigService.listFees(clientId);
      return { data };
    }
  );

  app.get(
    '/v1/admin/config/routing',
    { preHandler: guard(AUTH_SCOPES.CLIENTS_READ) },
    async (request) => {
      const clientId = requireClientId(request);
      const data = await deps.clientConfigService.listRouting(clientId);
      return { data };
    }
  );
}
