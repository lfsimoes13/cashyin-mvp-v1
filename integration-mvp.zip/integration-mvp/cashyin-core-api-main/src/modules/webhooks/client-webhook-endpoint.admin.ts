/**
 * Administrative CRUD for `client_webhook_endpoints`.
 *
 * Kept separate from the hot-path {@link ./client-webhook-endpoint.repository.ts}
 * (used by the dispatcher) so the delivery path's repository interface stays
 * minimal. The signing secret is generated server-side, returned **once** at
 * creation, and never exposed by the list/read projections.
 */

import { randomBytes } from 'node:crypto';
import type { Sql } from '../../shared/db/sql.js';
import { AppError } from '../../shared/errors/app-error.js';
import type { ClientWebhookEndpointStatus } from './client-webhook-endpoint.repository.js';

const SIGNING_SECRET_BYTES = 32;

/** Non-secret projection returned by list/read/update. */
export type AdminWebhookEndpoint = {
  id: string;
  clientId: string;
  eventPattern: string;
  targetUrl: string;
  status: ClientWebhookEndpointStatus;
  description: string | null;
  lastDeliveredAt: Date | null;
  lastFailureAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
};

type AdminWebhookEndpointRow = {
  id: string;
  client_id: string;
  event_pattern: string;
  target_url: string;
  status: ClientWebhookEndpointStatus;
  description: string | null;
  last_delivered_at: Date | null;
  last_failure_at: Date | null;
  created_at: Date;
  updated_at: Date;
};

const SELECT_COLUMNS = `
  id, client_id, event_pattern, target_url, status,
  description, last_delivered_at, last_failure_at, created_at, updated_at
` as const;

function mapRow(row: AdminWebhookEndpointRow): AdminWebhookEndpoint {
  return {
    id: row.id,
    clientId: row.client_id,
    eventPattern: row.event_pattern,
    targetUrl: row.target_url,
    status: row.status,
    description: row.description,
    lastDeliveredAt: row.last_delivered_at,
    lastFailureAt: row.last_failure_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}

export type CreateWebhookEndpointInput = {
  clientId: string;
  eventPattern: string;
  targetUrl: string;
  signingSecret: string;
  description: string | null;
};

export type UpdateWebhookEndpointPatch = {
  targetUrl?: string;
  status?: ClientWebhookEndpointStatus;
  description?: string | null;
  eventPattern?: string;
};

export interface ClientWebhookEndpointAdminRepository {
  create(sql: Sql, input: CreateWebhookEndpointInput): Promise<AdminWebhookEndpointRow>;
  listByClient(sql: Sql, clientId: string): Promise<AdminWebhookEndpointRow[]>;
  findByIdForClient(sql: Sql, clientId: string, id: string): Promise<AdminWebhookEndpointRow | null>;
  update(
    sql: Sql,
    clientId: string,
    id: string,
    patch: UpdateWebhookEndpointPatch
  ): Promise<AdminWebhookEndpointRow | null>;
}

/** Postgres unique-violation SQLSTATE. */
const UNIQUE_VIOLATION = '23505';

function isUniqueViolation(error: unknown): boolean {
  return typeof error === 'object' && error !== null && (error as { code?: string }).code === UNIQUE_VIOLATION;
}

export class PgClientWebhookEndpointAdminRepository implements ClientWebhookEndpointAdminRepository {
  async create(sql: Sql, input: CreateWebhookEndpointInput): Promise<AdminWebhookEndpointRow> {
    const result = await sql.query<AdminWebhookEndpointRow>(
      `INSERT INTO client_webhook_endpoints (client_id, event_pattern, target_url, signing_secret, description)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING ${SELECT_COLUMNS}`,
      [input.clientId, input.eventPattern, input.targetUrl, input.signingSecret, input.description]
    );
    const row = result.rows[0];
    if (!row) {
      throw new Error('client_webhook_endpoints insert returned no row');
    }
    return row;
  }

  async listByClient(sql: Sql, clientId: string): Promise<AdminWebhookEndpointRow[]> {
    const result = await sql.query<AdminWebhookEndpointRow>(
      `SELECT ${SELECT_COLUMNS}
         FROM client_webhook_endpoints
        WHERE client_id = $1
        ORDER BY created_at DESC`,
      [clientId]
    );
    return result.rows;
  }

  async findByIdForClient(
    sql: Sql,
    clientId: string,
    id: string
  ): Promise<AdminWebhookEndpointRow | null> {
    const result = await sql.query<AdminWebhookEndpointRow>(
      `SELECT ${SELECT_COLUMNS}
         FROM client_webhook_endpoints
        WHERE id = $1 AND client_id = $2`,
      [id, clientId]
    );
    return result.rows[0] ?? null;
  }

  async update(
    sql: Sql,
    clientId: string,
    id: string,
    patch: UpdateWebhookEndpointPatch
  ): Promise<AdminWebhookEndpointRow | null> {
    // COALESCE keeps each column unchanged when its parameter is null, so a
    // partial patch only touches the fields the caller supplied. `description`
    // is intentionally only settable to a non-null value here.
    const result = await sql.query<AdminWebhookEndpointRow>(
      `UPDATE client_webhook_endpoints
          SET target_url    = COALESCE($3, target_url),
              status        = COALESCE($4, status),
              description   = COALESCE($5, description),
              event_pattern = COALESCE($6, event_pattern),
              updated_at    = now()
        WHERE id = $1 AND client_id = $2
        RETURNING ${SELECT_COLUMNS}`,
      [
        id,
        clientId,
        patch.targetUrl ?? null,
        patch.status ?? null,
        patch.description ?? null,
        patch.eventPattern ?? null
      ]
    );
    return result.rows[0] ?? null;
  }
}

export type CreatedWebhookEndpoint = {
  endpoint: AdminWebhookEndpoint;
  /** Returned once; the client must store it to verify delivery signatures. */
  signingSecret: string;
};

export type ClientWebhookEndpointAdminServiceDeps = {
  repository: ClientWebhookEndpointAdminRepository;
  sql: Sql;
  randomBytes?: (size: number) => Buffer;
};

export class ClientWebhookEndpointAdminService {
  private readonly repository: ClientWebhookEndpointAdminRepository;
  private readonly sql: Sql;
  private readonly rng: (size: number) => Buffer;

  constructor(deps: ClientWebhookEndpointAdminServiceDeps) {
    this.repository = deps.repository;
    this.sql = deps.sql;
    this.rng = deps.randomBytes ?? randomBytes;
  }

  async create(input: {
    clientId: string;
    eventPattern: string;
    targetUrl: string;
    description?: string | null;
  }): Promise<CreatedWebhookEndpoint> {
    const signingSecret = this.rng(SIGNING_SECRET_BYTES).toString('hex');
    let row: AdminWebhookEndpointRow;
    try {
      row = await this.repository.create(this.sql, {
        clientId: input.clientId,
        eventPattern: input.eventPattern,
        targetUrl: input.targetUrl,
        signingSecret,
        description: input.description ?? null
      });
    } catch (error) {
      if (isUniqueViolation(error)) {
        throw new AppError(
          'webhook_endpoint_conflict',
          `An endpoint already exists for event pattern "${input.eventPattern}"`,
          409
        );
      }
      throw error;
    }
    return { endpoint: mapRow(row), signingSecret };
  }

  async listByClient(clientId: string): Promise<AdminWebhookEndpoint[]> {
    const rows = await this.repository.listByClient(this.sql, clientId);
    return rows.map(mapRow);
  }

  /** Returns the updated endpoint, or `null` when it doesn't belong to the client. */
  async update(
    clientId: string,
    id: string,
    patch: UpdateWebhookEndpointPatch
  ): Promise<AdminWebhookEndpoint | null> {
    let row: AdminWebhookEndpointRow | null;
    try {
      row = await this.repository.update(this.sql, clientId, id, patch);
    } catch (error) {
      if (isUniqueViolation(error)) {
        throw new AppError(
          'webhook_endpoint_conflict',
          'Another endpoint already uses that event pattern',
          409
        );
      }
      throw error;
    }
    return row ? mapRow(row) : null;
  }

  /** Convenience for `PATCH … {status:'disabled'}`. */
  async disable(clientId: string, id: string): Promise<AdminWebhookEndpoint | null> {
    return this.update(clientId, id, { status: 'disabled' });
  }
}
