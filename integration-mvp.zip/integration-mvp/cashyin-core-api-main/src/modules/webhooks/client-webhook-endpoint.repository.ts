import type { Sql } from '../../shared/db/sql.js';

export type ClientWebhookEndpointStatus = 'active' | 'disabled';

export type ClientWebhookEndpointRecord = {
  id: string;
  clientId: string;
  eventPattern: string;
  targetUrl: string;
  signingSecret: string;
  status: ClientWebhookEndpointStatus;
  description: string | null;
  lastDeliveredAt: Date | null;
  lastFailureAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
};

type ClientWebhookEndpointRow = {
  id: string;
  client_id: string;
  event_pattern: string;
  target_url: string;
  signing_secret: string;
  status: ClientWebhookEndpointStatus;
  description: string | null;
  last_delivered_at: Date | null;
  last_failure_at: Date | null;
  created_at: Date;
  updated_at: Date;
};

function mapRow(row: ClientWebhookEndpointRow): ClientWebhookEndpointRecord {
  return {
    id: row.id,
    clientId: row.client_id,
    eventPattern: row.event_pattern,
    targetUrl: row.target_url,
    signingSecret: row.signing_secret,
    status: row.status,
    description: row.description,
    lastDeliveredAt: row.last_delivered_at,
    lastFailureAt: row.last_failure_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}

export interface ClientWebhookEndpointRepository {
  /**
   * Finds the active endpoint that should receive `eventType` for the
   * given client. Match preference:
   *   1. Exact `event_pattern = eventType` row.
   *   2. Wildcard `event_pattern = '*'` row.
   * Returns `null` when no active endpoint applies (the client did not
   * subscribe to this event).
   */
  findActiveForEvent(
    sql: Sql,
    clientId: string,
    eventType: string
  ): Promise<ClientWebhookEndpointRecord | null>;

  /** Stamps a successful delivery timestamp on the endpoint row. */
  markDelivered(sql: Sql, id: string, at: Date): Promise<void>;

  /** Stamps a failed delivery timestamp on the endpoint row. */
  markFailure(sql: Sql, id: string, at: Date): Promise<void>;
}

const SELECT_COLUMNS = `
  id, client_id, event_pattern, target_url, signing_secret, status,
  description, last_delivered_at, last_failure_at, created_at, updated_at
` as const;

export class PgClientWebhookEndpointRepository implements ClientWebhookEndpointRepository {
  async findActiveForEvent(
    sql: Sql,
    clientId: string,
    eventType: string
  ): Promise<ClientWebhookEndpointRecord | null> {
    // Exact match first; the `ORDER BY (event_pattern = '*') ASC` puts
    // the wildcard row last so an exact `event_pattern = eventType`
    // takes precedence when both exist.
    const result = await sql.query<ClientWebhookEndpointRow>(
      `SELECT ${SELECT_COLUMNS}
         FROM client_webhook_endpoints
        WHERE client_id = $1
          AND status = 'active'
          AND (event_pattern = $2 OR event_pattern = '*')
        ORDER BY (event_pattern = '*') ASC
        LIMIT 1`,
      [clientId, eventType]
    );
    const row = result.rows[0];
    return row ? mapRow(row) : null;
  }

  async markDelivered(sql: Sql, id: string, at: Date): Promise<void> {
    await sql.query(
      `UPDATE client_webhook_endpoints
          SET last_delivered_at = $2,
              updated_at        = now()
        WHERE id = $1`,
      [id, at]
    );
  }

  async markFailure(sql: Sql, id: string, at: Date): Promise<void> {
    await sql.query(
      `UPDATE client_webhook_endpoints
          SET last_failure_at = $2,
              updated_at      = now()
        WHERE id = $1`,
      [id, at]
    );
  }
}
