import type { FastifyInstance, FastifyPluginAsync } from 'fastify';
import { AppError } from '../../shared/errors/app-error.js';
import type { WebhookService } from './webhook.service.js';

export type WebhookRoutesDeps = {
  webhookService: WebhookService;
};

type ParsedWebhookBody = {
  rawBody: Buffer;
  payload: unknown;
};

/**
 * Provider webhook ingress (Phase 4 — responsive HTTP).
 *
 * The route is intentionally thin: it isolates the raw body, hands it
 * to {@link WebhookService}, and translates the structured outcome to
 * an HTTP status. The service runs the provider adapter (verify →
 * parse → normalize) and persists the canonical row, so the route
 * itself contains zero provider-specific logic and zero domain calls.
 *
 * Response semantics:
 *
 *   - `invalid_signature` → 401. The body is rejected without
 *     persistence (the row would be unauthenticated noise; the
 *     reverse-proxy / WAF layer is the right place to record those
 *     attempts). Phase 6 will revisit this to add an audit-only
 *     persistence path for forensic investigation.
 *
 *   - `persisted` and `duplicate` → 200 OK. The Bents documentation
 *     (§ "Webhooks" — "Sua URL de webhook deve responder com HTTP `200`
 *     em até 10 segundos") treats any non-200 as a delivery failure
 *     and schedules a retry with exponential backoff
 *     (1min → 5min → 30min → 2h). Returning 202 here would generate
 *     spurious retries from the provider side even when persistence
 *     succeeded.
 *
 *     The async processor (Phase 5) still picks up `processing_status =
 *     'pending'` rows from `webhook_events` independently of the HTTP
 *     response — the change is purely about the provider-side retry
 *     loop.
 */
export async function registerWebhookRoutes(
  app: FastifyInstance,
  deps: WebhookRoutesDeps
): Promise<void> {
  const plugin: FastifyPluginAsync = async (scope) => {
    // Webhook handlers need access to the raw request bytes to verify
    // HMAC signatures. The default Fastify JSON parser only exposes
    // the parsed body, so we register a scoped plugin that replaces
    // the parser with one that yields both `rawBody` and `payload`.
    // Encapsulating in a plugin keeps the raw-body parser from leaking
    // into the public write routes.
    scope.addContentTypeParser(
      'application/json',
      { parseAs: 'buffer' },
      (_request, body, done) => {
        try {
          const buffer = body as Buffer;
          const payload = buffer.length === 0 ? {} : (JSON.parse(buffer.toString('utf8')) as unknown);
          done(null, { rawBody: buffer, payload } satisfies ParsedWebhookBody);
        } catch (error) {
          done(error as Error);
        }
      }
    );

    scope.post('/internal/webhooks/bents', async (request, reply) => {
      const parsed = request.body as ParsedWebhookBody | undefined;
      if (!parsed || !Buffer.isBuffer(parsed.rawBody)) {
        throw new AppError('webhook_payload_invalid', 'Webhook payload could not be parsed', 400);
      }

      const result = await deps.webhookService.ingest({
        providerName: 'bents',
        rawBody: parsed.rawBody,
        headers: request.headers,
        // Let the adapter resolve its provider-specific signature header
        // itself; we do not couple the route to header names.
        signature: null,
        payload: parsed.payload
      });

      if (result.outcome === 'invalid_signature') {
        request.log.warn(
          { provider: 'bents', reason: result.reason, detail: result.detail },
          'Provider webhook rejected: signature verification failed'
        );
        throw new AppError(
          'webhook_signature_invalid',
          `Invalid bents webhook signature (${result.reason})`,
          401
        );
      }

      request.log.info(
        {
          provider: 'bents',
          eventId: result.event.id,
          providerEventId: result.event.providerEventId,
          eventType: result.event.eventType,
          providerTransactionId: result.event.providerTransactionId,
          operationType: result.event.operationType,
          normalizedStatusKind: result.event.normalizedStatusKind,
          normalizedStatus: result.event.normalizedStatus,
          unknownReason: result.event.unknownReason,
          duplicate: result.outcome === 'duplicate'
        },
        'Provider webhook accepted'
      );

      return reply.status(200).send({
        ok: true,
        duplicate: result.outcome === 'duplicate',
        eventId: result.event.id
      });
    });
  };

  await app.register(plugin);
}
