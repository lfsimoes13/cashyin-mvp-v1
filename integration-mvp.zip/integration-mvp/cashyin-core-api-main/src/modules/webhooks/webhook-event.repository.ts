import type { OperationType, ProviderName } from '../../providers/contracts/provider-types.js';
import type { ProviderWebhookUnknownReason } from '../../providers/contracts/provider-webhook-adapter.js';
import type { Sql } from '../../shared/db/sql.js';

/**
 * Persistence DTO for a provider webhook event after the adapter has
 * verified the signature, parsed the payload, and produced a canonical
 * `normalizedStatus`. Mirrors the columns introduced by migrations
 * 0001 (base columns), 0006 (audit envelope) and 0007 (parsed/normalized
 * fields). Every field maps 1:1 to a column to keep the SQL trivially
 * auditable.
 */
export type WebhookEventInsertInput = {
  providerName: ProviderName;
  eventType: string;
  providerEventId: string | null;
  providerTransactionId: string | null;
  providerStatus: string | null;
  operationType: OperationType | null;
  occurredAt: Date | null;
  normalizedStatus:
    | { kind: 'cash_in' | 'cash_out'; status: string }
    | { kind: 'unknown'; reason: ProviderWebhookUnknownReason };
  signatureValid: boolean;
  payload: unknown;
  rawPayloadHash: string;
  redactedHeaders: Record<string, string>;
  receivedAt: Date;
};

/**
 * Domain processing status mirrored from the `webhook_event_processing_status`
 * Postgres enum introduced in migration 0006.
 */
export type WebhookEventProcessingStatus =
  | 'pending'
  | 'processing'
  | 'processed'
  | 'failed'
  | 'skipped'
  | 'dlq';

export type WebhookEventRecord = {
  id: string;
  providerName: ProviderName;
  eventType: string;
  providerEventId: string | null;
  providerTransactionId: string | null;
  providerStatus: string | null;
  operationType: OperationType | null;
  occurredAt: Date | null;
  normalizedStatusKind: 'cash_in' | 'cash_out' | 'unknown';
  normalizedStatus: string | null;
  unknownReason: ProviderWebhookUnknownReason | null;
  signatureValid: boolean;
  payload: unknown;
  rawPayloadHash: string;
  redactedHeaders: Record<string, string>;
  receivedAt: Date;
  processedAt: Date | null;
  createdAt: Date;
  /**
   * Domain processing fields (migration 0006). Populated as the
   * asynchronous processor (Phase 5) claims and finalises the event.
   */
  processingStatus: WebhookEventProcessingStatus;
  processingError: string | null;
  attemptCount: number;
  lastAttemptAt: Date | null;
  nextAttemptAt: Date | null;
};

type WebhookEventRow = {
  id: string;
  provider_name: ProviderName;
  event_type: string;
  provider_event_id: string | null;
  provider_transaction_id: string | null;
  provider_status: string | null;
  operation_type: OperationType | null;
  occurred_at: Date | null;
  normalized_status_kind: 'cash_in' | 'cash_out' | 'unknown';
  normalized_status: string | null;
  unknown_reason: ProviderWebhookUnknownReason | null;
  signature_valid: boolean;
  payload: unknown;
  raw_payload_hash: string | null;
  headers_redacted: Record<string, string>;
  received_at: Date;
  processed_at: Date | null;
  created_at: Date;
  processing_status: WebhookEventProcessingStatus;
  processing_error: string | null;
  attempt_count: number | string;
  last_attempt_at: Date | null;
  next_attempt_at: Date | null;
};

function mapRow(row: WebhookEventRow): WebhookEventRecord {
  return {
    id: row.id,
    providerName: row.provider_name,
    eventType: row.event_type,
    providerEventId: row.provider_event_id,
    providerTransactionId: row.provider_transaction_id,
    providerStatus: row.provider_status,
    operationType: row.operation_type,
    occurredAt: row.occurred_at,
    normalizedStatusKind: row.normalized_status_kind,
    normalizedStatus: row.normalized_status,
    unknownReason: row.unknown_reason,
    signatureValid: row.signature_valid,
    payload: row.payload,
    rawPayloadHash: row.raw_payload_hash ?? '',
    redactedHeaders: row.headers_redacted,
    receivedAt: row.received_at,
    processedAt: row.processed_at,
    createdAt: row.created_at,
    processingStatus: row.processing_status,
    processingError: row.processing_error,
    attemptCount: Number(row.attempt_count),
    lastAttemptAt: row.last_attempt_at,
    nextAttemptAt: row.next_attempt_at
  };
}

/**
 * Translates a {@link WebhookEventClaimFilter} into SQL predicate
 * fragments, pushing each bound value onto `params` and returning the
 * `$n`-referencing clauses. Kept as a free function (not a method) so it
 * can be unit-tested in isolation and reused by future queue tables.
 */
export function buildClaimFilterClauses(
  filter: WebhookEventClaimFilter | undefined,
  params: unknown[]
): string[] {
  if (!filter) return [];
  const clauses: string[] = [];
  if (filter.operationType) {
    params.push(filter.operationType);
    clauses.push(`operation_type = $${params.length}`);
  }
  if (filter.normalizedStatusKind) {
    params.push(filter.normalizedStatusKind);
    clauses.push(`normalized_status_kind = $${params.length}`);
  }
  if (filter.normalizedStatus) {
    params.push(filter.normalizedStatus);
    clauses.push(`normalized_status = $${params.length}`);
  }
  if (filter.excludeNormalizedStatus && filter.excludeNormalizedStatus.length > 0) {
    params.push([...filter.excludeNormalizedStatus]);
    clauses.push(`(normalized_status IS NULL OR normalized_status <> ALL($${params.length}::text[]))`);
  }
  if (filter.eventTypes && filter.eventTypes.length > 0) {
    params.push([...filter.eventTypes]);
    clauses.push(`event_type = ANY($${params.length}::text[])`);
  }
  return clauses;
}

export type WebhookInsertResult = { duplicate: boolean; record: WebhookEventRecord };

/**
 * Optional, additive predicates that restrict which `webhook_events`
 * rows a worker may claim. Used to partition the queue across dedicated
 * replicas (Fase 1) so cash-out or non-paid cash-in can never delay
 * `pix.cash_in.paid`. All fields are ANDed together; an empty filter
 * preserves the historical "drain everything" behaviour.
 */
export type WebhookEventClaimFilter = {
  /** Match `operation_type` exactly. */
  operationType?: OperationType;
  /** Match `normalized_status_kind` exactly. */
  normalizedStatusKind?: 'cash_in' | 'cash_out' | 'unknown';
  /** Match `normalized_status` exactly (e.g. `paid`). */
  normalizedStatus?: string;
  /** Exclude rows whose `normalized_status` is in this list. */
  excludeNormalizedStatus?: readonly string[];
  /** Restrict to rows whose `event_type` is in this list. */
  eventTypes?: readonly string[];
};

export type WebhookEventClaimInput = {
  /** Reference moment for `next_attempt_at <= now` filtering. */
  now: Date;
  /**
   * Optional partition filter. When omitted the claim considers every
   * eligible row (back-compat with the single global worker).
   */
  filter?: WebhookEventClaimFilter;
};

export type WebhookEventFinaliseInput = {
  id: string;
  /** Final processing status to commit. */
  status: 'processed' | 'skipped' | 'dlq';
  /** Error / reason string. Persisted verbatim into `processing_error`. */
  error?: string | null;
};

export type WebhookEventRetryInput = {
  id: string;
  /** Error description recorded on the failing attempt. */
  error: string;
  /** Wall-clock moment at which the next attempt becomes eligible. */
  nextAttemptAt: Date;
};

export interface WebhookEventRepository {
  /**
   * Persists a raw webhook event together with its parsed/normalized
   * audit fields. If `providerEventId` is set, the unique
   * `(provider_name, provider_event_id)` constraint deduplicates
   * provider retries and the existing row is returned with
   * `duplicate: true`.
   *
   * The insert is the first write of the ingress pipeline: the row is
   * recorded with `processing_status='pending'` (column default from
   * migration 0006) and picked up later by the async processor.
   */
  insert(sql: Sql, input: WebhookEventInsertInput): Promise<WebhookInsertResult>;

  /**
   * Atomically claims the next ready-to-process row using
   * `FOR UPDATE SKIP LOCKED` so multiple workers may run concurrently
   * without stepping on each other. Implementation flips the row from
   * `pending` (or `failed` whose `next_attempt_at <= now`) to
   * `processing`, increments `attempt_count`, and stamps
   * `last_attempt_at`. Returns `null` when nothing is currently due.
   */
  claimNextPending(
    sql: Sql,
    input: WebhookEventClaimInput
  ): Promise<WebhookEventRecord | null>;

  /**
   * Commits the row in a terminal processing status (`processed`,
   * `skipped` or `dlq`). Clears `next_attempt_at` and stamps
   * `processed_at`.
   */
  finalise(sql: Sql, input: WebhookEventFinaliseInput): Promise<void>;

  /**
   * Moves the row back to `failed` and schedules the next attempt.
   * Used by the processor when a handler throws a retryable error.
   */
  scheduleRetry(sql: Sql, input: WebhookEventRetryInput): Promise<void>;

  /**
   * Reclaims rows stuck in `processing` by a crashed worker. Any row whose
   * `last_attempt_at < staleBefore` and `processing_status = 'processing'`
   * is flipped back to `pending` with `next_attempt_at = NULL` so the next
   * claim cycle will pick it up immediately.
   *
   * Returns the number of rows reclaimed.
   */
  reclaimStaleProcessing(sql: Sql, staleBefore: Date): Promise<number>;
}

const RETURNING_COLS = `
  id, provider_name, event_type, provider_event_id,
  provider_transaction_id, provider_status, operation_type, occurred_at,
  normalized_status_kind, normalized_status, unknown_reason,
  signature_valid, payload, raw_payload_hash, headers_redacted,
  received_at, processed_at, created_at,
  processing_status, processing_error, attempt_count,
  last_attempt_at, next_attempt_at
` as const;

function splitNormalizedStatus(input: WebhookEventInsertInput['normalizedStatus']): {
  kind: 'cash_in' | 'cash_out' | 'unknown';
  status: string | null;
  reason: ProviderWebhookUnknownReason | null;
} {
  if (input.kind === 'unknown') {
    return { kind: 'unknown', status: null, reason: input.reason };
  }
  return { kind: input.kind, status: input.status, reason: null };
}

export class PgWebhookEventRepository implements WebhookEventRepository {
  async insert(sql: Sql, input: WebhookEventInsertInput): Promise<WebhookInsertResult> {
    const { kind, status, reason } = splitNormalizedStatus(input.normalizedStatus);
    const params = [
      input.providerName,
      input.eventType,
      input.providerEventId,
      input.providerTransactionId,
      input.providerStatus,
      input.operationType,
      input.occurredAt,
      kind,
      status,
      reason,
      input.signatureValid,
      JSON.stringify(input.payload),
      input.rawPayloadHash,
      JSON.stringify(input.redactedHeaders),
      input.receivedAt
    ];

    if (input.providerEventId !== null) {
      // Provider supplied a stable event id — rely on the
      // `(provider_name, provider_event_id)` unique index for dedupe.
      const inserted = await sql.query<WebhookEventRow>(
        `INSERT INTO webhook_events (
           provider_name, event_type, provider_event_id,
           provider_transaction_id, provider_status, operation_type, occurred_at,
           normalized_status_kind, normalized_status, unknown_reason,
           signature_valid, payload, raw_payload_hash, headers_redacted, received_at
         )
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12::jsonb, $13, $14::jsonb, $15)
         ON CONFLICT (provider_name, provider_event_id) DO NOTHING
         RETURNING ${RETURNING_COLS}`,
        params
      );
      const row = inserted.rows[0];
      if (row) {
        return { duplicate: false, record: mapRow(row) };
      }

      const existing = await sql.query<WebhookEventRow>(
        `SELECT ${RETURNING_COLS}
           FROM webhook_events
          WHERE provider_name = $1 AND provider_event_id = $2`,
        [input.providerName, input.providerEventId]
      );
      const existingRow = existing.rows[0];
      if (!existingRow) {
        throw new Error('Webhook deduplication lookup returned no row after conflict');
      }
      return { duplicate: true, record: mapRow(existingRow) };
    }

    // Provider did not supply a stable event id. The caller is
    // expected to write a `dedupe_key` in a follow-up pipeline step
    // (Phase 5); we still record the row so the audit chain stays
    // append-only.
    const result = await sql.query<WebhookEventRow>(
      `INSERT INTO webhook_events (
         provider_name, event_type, provider_event_id,
         provider_transaction_id, provider_status, operation_type, occurred_at,
         normalized_status_kind, normalized_status, unknown_reason,
         signature_valid, payload, raw_payload_hash, headers_redacted, received_at
       )
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12::jsonb, $13, $14::jsonb, $15)
       RETURNING ${RETURNING_COLS}`,
      params
    );
    const row = result.rows[0];
    if (!row) {
      throw new Error('Failed to insert webhook_events row');
    }
    return { duplicate: false, record: mapRow(row) };
  }

  async claimNextPending(
    sql: Sql,
    input: WebhookEventClaimInput
  ): Promise<WebhookEventRecord | null> {
    // The inner SELECT picks one row whose status is `pending` (never
    // attempted yet) or `failed` and now eligible per
    // `next_attempt_at <= now()`. `FOR UPDATE SKIP LOCKED` lets a
    // sibling worker race to a different row without serialising the
    // whole queue. The outer UPDATE flips the row to `processing` in
    // the same transaction so the lock is released only after the
    // claim is durable.
    // `next_event` aliases the picked id as `target_id` (instead of plain
    // `id`) so the outer `RETURNING` clause references `webhook_events.id`
    // unambiguously. Without the alias both `webhook_events` and `next_event`
    // expose an `id` column to the outer query, and PostgreSQL rejects the
    // RETURNING list with `42702 ambiguous column reference: "id"`.
    // Optional partition predicates (Fase 1). Each clause is appended with
    // a positional parameter so the query stays injection-safe, and they
    // are ANDed AFTER the status-eligibility group (note the extra parens
    // wrapping the pending/failed OR) so the filter restricts both the
    // never-attempted and retry-eligible branches.
    const params: unknown[] = [input.now];
    const filterClauses = buildClaimFilterClauses(input.filter, params);
    const filterSql = filterClauses.length > 0 ? `\n            AND ${filterClauses.join('\n            AND ')}` : '';

    const result = await sql.query<WebhookEventRow>(
      `WITH next_event AS (
         SELECT id AS target_id
           FROM webhook_events
          WHERE ((processing_status = 'pending'
                  AND (next_attempt_at IS NULL OR next_attempt_at <= $1))
              OR (processing_status = 'failed' AND next_attempt_at IS NOT NULL AND next_attempt_at <= $1))${filterSql}
          ORDER BY received_at ASC
          LIMIT 1
          FOR UPDATE SKIP LOCKED
       )
       UPDATE webhook_events e
          SET processing_status = 'processing',
              attempt_count    = e.attempt_count + 1,
              last_attempt_at  = $1,
              next_attempt_at  = NULL,
              processing_error = NULL
         FROM next_event n
        WHERE e.id = n.target_id
       RETURNING ${RETURNING_COLS}`,
      params
    );
    const row = result.rows[0];
    return row ? mapRow(row) : null;
  }

  async finalise(sql: Sql, input: WebhookEventFinaliseInput): Promise<void> {
    await sql.query(
      `UPDATE webhook_events
          SET processing_status = $2,
              processing_error  = $3,
              processed_at      = now(),
              next_attempt_at   = NULL
        WHERE id = $1`,
      [input.id, input.status, input.error ?? null]
    );
  }

  async scheduleRetry(sql: Sql, input: WebhookEventRetryInput): Promise<void> {
    await sql.query(
      `UPDATE webhook_events
          SET processing_status = 'failed',
              processing_error  = $2,
              next_attempt_at   = $3
        WHERE id = $1`,
      [input.id, input.error, input.nextAttemptAt]
    );
  }

  async reclaimStaleProcessing(sql: Sql, staleBefore: Date): Promise<number> {
    const result = await sql.query(
      `UPDATE webhook_events
          SET processing_status = 'pending',
              next_attempt_at   = NULL,
              processing_error  = 'reclaimed_stale_processing'
        WHERE processing_status = 'processing'
          AND last_attempt_at   < $1`,
      [staleBefore]
    );
    return result.rowCount ?? 0;
  }
}
