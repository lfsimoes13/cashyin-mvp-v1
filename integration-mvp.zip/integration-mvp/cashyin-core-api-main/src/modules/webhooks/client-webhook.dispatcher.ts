/**
 * Phase 6/7 — Public client webhook dispatcher.
 *
 * The domain processor enqueues `pix.cash_in.<status>` (Phase 5) and
 * `pix.cash_out.<status>` (Phase 7) rows into `outbox_events`. This
 * dispatcher reads those rows, materialises the public
 * {@link buildCashInWebhookEnvelope} / {@link buildCashOutWebhookEnvelope}
 * envelope, signs the body with the per-client HMAC secret, POSTs it
 * to the configured endpoint, and persists the delivery outcome.
 *
 * Like the webhook processor, the dispatcher exposes `dispatchNext()`
 * and `dispatchBatch(limit)` rather than auto-starting from HTTP boot:
 * deployment topology (Lambda / ECS scheduled task / embedded worker)
 * is decided per environment.
 *
 *  - `outbox_events` is the durable intent-to-publish queue.
 *  - `client_webhook_deliveries` is the per-event delivery state log.
 *    Retries reuse the row by `outbox_event_id` so dashboards see one
 *    timeline per outbound event regardless of attempt count.
 *  - `client_webhook_endpoints` carries the per-client routing config
 *    (target URL, signing secret, event pattern, status).
 */

import { createHmac } from 'node:crypto';
import type { DispatchableCashInStatus } from '../transactions/public-events.js';
import type { CashOutStatus } from '../transactions/status.js';
import {
  buildCashInWebhookEnvelope,
  buildCashOutWebhookEnvelope,
  type BuildCashInEnvelopeInput,
  type BuildCashOutEnvelopeInput,
  type CashOutReceiverInput,
  type CashOutTimestamps,
  type PublicWebhookEnvelope
} from '../transactions/payload-builder.js';
import type { PublicCounterpartySource } from '../transactions/public-serialization.js';
import type { HttpClient } from '../../shared/http/http-client.js';
import type { Database } from '../../shared/db/database.js';
import type { ClientWebhookDeliveryRepository } from './client-webhook-delivery.repository.js';
import type { ClientWebhookEndpointRepository } from './client-webhook-endpoint.repository.js';
import type { OutboxEventRecord, OutboxRepository } from '../outbox/outbox.repository.js';
import { env } from '../../shared/config/env.js';
import { metrics, operationFromEventType } from '../../shared/observability/metrics.js';

const DEFAULT_RETRY_POLICY: ClientWebhookRetryPolicy = {
  baseDelayMs: 30_000,
  maxDelayMs: 60 * 60 * 1000,
  maxAttempts: 8,
  responseSnippetLength: 256,
  requestTimeoutMs: env.CLIENT_WEBHOOK_TIMEOUT_MS,
  // Tighter per-event overrides. `pix.cash_in.paid` is on the critical
  // notification path — fail fast so the dispatcher does not block on a slow
  // client endpoint and delay other paid events. The exponential-backoff retry
  // will pick it up; a short first-attempt timeout trades first-try success
  // rate for P99 queue-drain time, which is the right trade on this path.
  requestTimeoutOverrides: {
    'pix.cash_in.paid': env.CLIENT_WEBHOOK_CASHIN_PAID_TIMEOUT_MS
  }
};

const SUPPORTED_AGGREGATE_TYPES = ['cash_in', 'cashout'] as const;
type SupportedAggregateType = (typeof SUPPORTED_AGGREGATE_TYPES)[number];

/** Rows stuck in 'processing' longer than this are reclaimed as 'pending'. */
const STALE_PROCESSING_THRESHOLD_MS = 5 * 60 * 1_000; // 5 minutes

/**
 * Minimum wall-clock gap between two stale-reaper sweeps. The reaper only
 * recovers rows abandoned by a crashed worker (older than
 * STALE_PROCESSING_THRESHOLD_MS), so running it on every tick adds a needless
 * UPDATE round-trip to the latency-critical claim path. Throttling to once per
 * interval keeps the hot path lean without weakening recovery (a crashed row is
 * still reclaimed within this interval + the 5-minute threshold).
 */
const DEFAULT_STALE_REAP_MIN_INTERVAL_MS = 30_000;

export type ClientWebhookRetryPolicy = {
  baseDelayMs: number;
  maxDelayMs: number;
  maxAttempts: number;
  /** Max bytes from the response body persisted into the delivery row. */
  responseSnippetLength: number;
  /** Default per-request HTTP timeout (ms) for outgoing webhook POSTs. */
  requestTimeoutMs: number;
  /**
   * Per-event-type timeout overrides (ms). When present for a given
   * `event` name, replaces `requestTimeoutMs` for that delivery only.
   * Use to apply a tighter latency budget to critical paths (e.g.
   * `pix.cash_in.paid`) without lowering the global default.
   */
  requestTimeoutOverrides?: Record<string, number>;
};

export type ClientWebhookDispatcherDeps = {
  db: Database;
  outboxRepository: OutboxRepository;
  endpointRepository: ClientWebhookEndpointRepository;
  deliveryRepository: ClientWebhookDeliveryRepository;
  httpClient: HttpClient;
  now?: () => Date;
  retryPolicy?: ClientWebhookRetryPolicy;
  /**
   * Minimum gap (ms) between stale-reaper sweeps. Defaults to
   * {@link DEFAULT_STALE_REAP_MIN_INTERVAL_MS}. Set to 0 to reap on every tick
   * (legacy behaviour, useful in tests).
   */
  reaperMinIntervalMs?: number;
  /**
   * Optional outbox claim partition. When set, this dispatcher only claims
   * outbox rows whose `event_type` matches the include/exclude filter, so a
   * dedicated process can drain the critical `pix.cash_in.paid` path without
   * head-of-line blocking from slower deliveries. Unset = drain all supported
   * aggregate types (back-compat, single-worker behaviour).
   */
  claimFilter?: OutboxDispatchClaimFilter;
};

/**
 * Event-type partition for the dispatcher (Phase B1). Mirrors the
 * provider-webhook processor's claim-filter pattern. Both fields optional;
 * an empty filter is equivalent to no filter.
 */
export type OutboxDispatchClaimFilter = {
  /** Claim only outbox rows whose `event_type` is in this list. */
  eventTypes?: readonly string[];
  /** Never claim outbox rows whose `event_type` is in this list. */
  excludeEventTypes?: readonly string[];
};

export type DispatchOutcome =
  | { kind: 'empty' }
  | {
      kind: 'delivered';
      outboxEventId: string;
      deliveryId: string;
      eventId: string;
      eventType: string;
      httpStatus: number;
      /** ms between outbox_events.created_at and when this worker claimed the row. */
      claimLatencyMs?: number;
    }
  | {
      kind: 'skipped';
      outboxEventId: string;
      reason: DispatchSkipReason;
      /** ms between outbox_events.created_at and when this worker claimed the row. */
      claimLatencyMs?: number;
    }
  | {
      kind: 'retry';
      outboxEventId: string;
      deliveryId: string;
      attemptNumber: number;
      error: string;
      httpStatus: number | null;
      nextAttemptAt: Date;
      /** ms between outbox_events.created_at and when this worker claimed the row. */
      claimLatencyMs?: number;
    }
  | {
      kind: 'dlq';
      outboxEventId: string;
      deliveryId: string;
      attemptNumber: number;
      error: string;
      httpStatus: number | null;
      /** ms between outbox_events.created_at and when this worker claimed the row. */
      claimLatencyMs?: number;
    };

export type DispatchSkipReason =
  | 'no_endpoint_configured'
  | 'unsupported_event_type'
  | 'unsupported_aggregate_type'
  | 'malformed_payload';

export class ClientWebhookDispatcher {
  private readonly retryPolicy: ClientWebhookRetryPolicy;
  private readonly clock: () => Date;
  private readonly reaperMinIntervalMs: number;
  private readonly claimFilter: OutboxDispatchClaimFilter | undefined;
  /** Wall-clock ms of the last stale-reaper sweep; 0 = never run. */
  private lastReaperAtMs = 0;

  constructor(private readonly deps: ClientWebhookDispatcherDeps) {
    this.retryPolicy = deps.retryPolicy ?? DEFAULT_RETRY_POLICY;
    this.clock = deps.now ?? ((): Date => new Date());
    this.reaperMinIntervalMs = deps.reaperMinIntervalMs ?? DEFAULT_STALE_REAP_MIN_INTERVAL_MS;
    this.claimFilter =
      deps.claimFilter && hasClaimFilter(deps.claimFilter) ? deps.claimFilter : undefined;
  }

  async dispatchNext(): Promise<DispatchOutcome> {
    const now = this.clock();

    // Reclaim outbox rows stuck in 'processing' by crashed workers before
    // claiming the next row. No-op when nothing is stale; non-fatal on error.
    await this.reclaimStaleOutboxRows(now);

    const claimed = await this.deps.db.withTransaction((tx) =>
      this.deps.outboxRepository.claimNextPending(tx, {
        now,
        aggregateTypes: SUPPORTED_AGGREGATE_TYPES,
        ...(this.claimFilter?.eventTypes ? { eventTypes: this.claimFilter.eventTypes } : {}),
        ...(this.claimFilter?.excludeEventTypes
          ? { excludeEventTypes: this.claimFilter.excludeEventTypes }
          : {})
      })
    );
    if (!claimed) return { kind: 'empty' };

    // Milliseconds between when the domain wrote the outbox row and when
    // this dispatcher worker claimed it. Surfaced in structured logs to
    // measure Worker-2 queue-wait time end-to-end.
    const claimLatencyMs = now.getTime() - claimed.createdAt.getTime();

    if (!isSupportedAggregateType(claimed.aggregateType)) {
      // Belt-and-braces: the SQL filter already restricts the claim,
      // but if a future caller bypasses it we surface a stable skip
      // reason rather than throwing inside the dispatcher.
      return this.skip(claimed, 'unsupported_aggregate_type', claimLatencyMs);
    }

    const envelope = tryBuildEnvelope(claimed);
    if (envelope.kind === 'unsupported') {
      return this.skip(claimed, 'unsupported_event_type', claimLatencyMs);
    }
    if (envelope.kind === 'malformed') {
      return this.skip(claimed, 'malformed_payload', claimLatencyMs);
    }

    // Cash-in outbox payloads carry `client_id` (snake_case canonical
    // contract); cash-out still uses the legacy `clientId` field until
    // its refactor lands. Accept both during the migration.
    const clientId =
      pickString(claimed.payload, 'client_id') ?? pickString(claimed.payload, 'clientId');
    if (clientId === null) {
      return this.skip(claimed, 'malformed_payload', claimLatencyMs);
    }

    const endpoint = await this.deps.endpointRepository.findActiveForEvent(
      this.deps.db.pool,
      clientId,
      envelope.envelope.event
    );
    if (!endpoint) {
      return this.skip(claimed, 'no_endpoint_configured', claimLatencyMs);
    }

    const bodyText = JSON.stringify(envelope.envelope);
    const signature = signEnvelope(bodyText, endpoint.signingSecret);

    // Resolve the effective per-call timeout. Critical events (pix.cash_in.paid)
    // use a tighter budget so a slow client endpoint does not block the worker;
    // the exponential-backoff retry will pick up any first-attempt failure.
    const effectiveTimeoutMs =
      this.retryPolicy.requestTimeoutOverrides?.[envelope.envelope.event] ??
      this.retryPolicy.requestTimeoutMs;

    // Upsert the delivery row before the HTTP call so a crash mid-send
    // leaves a durable in-progress row to reconcile from.
    const delivery = await this.deps.db.withTransaction((tx) =>
      this.deps.deliveryRepository.upsertForOutbox(tx, {
        outboxEventId: claimed.id,
        clientId,
        eventId: envelope.envelope.id,
        eventType: envelope.envelope.event,
        targetUrl: endpoint.targetUrl,
        payload: envelope.envelope,
        signature,
        nextAttemptAt: now
      })
    );

    const attemptNumber = delivery.attemptCount + 1;
    const isFirstAttempt = delivery.attemptCount === 0;
    const deliveryStartedAt = process.hrtime.bigint();
    // Wall-clock instant just before the FIRST HTTP attempt. Used (only on the
    // first attempt) to persist `first_attempt_started_at` and to derive the
    // CashYin-controlled `first_attempt_start_latency` from outbox.created_at.
    const attemptStartedAtWall = this.clock();
    const httpResult = await this.tryDeliver(endpoint.targetUrl, bodyText, signature, effectiveTimeoutMs);
    recordClientWebhookDeliveryMetrics(envelope.envelope.event, httpResult, deliveryStartedAt, effectiveTimeoutMs);
    const finishedAt = this.clock();

    // First-attempt latency relative to outbox.created_at (outbox_created_at).
    // `start` is the segment CashYin owns; `total` additionally includes the
    // client's response/timeout time. Emitted once, on the first attempt only,
    // so retries do not pollute the first-try latency distribution.
    const firstAttemptStartedAtToPersist = isFirstAttempt ? attemptStartedAtWall : null;
    const firstAttemptFinishedAtToPersist = isFirstAttempt ? finishedAt : null;
    if (isFirstAttempt) {
      recordClientWebhookFirstAttemptLatencyMetrics(
        envelope.envelope.event,
        claimed.createdAt,
        attemptStartedAtWall,
        finishedAt
      );
    }

    if (httpResult.kind === 'success' && isSuccessStatus(httpResult.statusCode)) {
      await this.deps.db.withTransaction(async (tx) => {
        await this.deps.deliveryRepository.applyAttempt(tx, {
          id: delivery.id,
          status: 'delivered',
          attemptCount: attemptNumber,
          httpStatus: httpResult.statusCode,
          responseSnippet: truncate(httpResult.bodyText, this.retryPolicy.responseSnippetLength),
          error: null,
          nextAttemptAt: finishedAt,
          deliveredAt: finishedAt,
          firstAttemptStartedAt: firstAttemptStartedAtToPersist,
          firstAttemptFinishedAt: firstAttemptFinishedAtToPersist
        });
        await this.deps.endpointRepository.markDelivered(tx, endpoint.id, finishedAt);
        await this.deps.outboxRepository.markPublished(tx, claimed.id);
      });
      // delivery_success_at = finishedAt (delivered_at). Latency from
      // outbox_created_at to a successful delivery, measured off the hot path.
      recordClientWebhookSuccessLatencyMetrics(
        envelope.envelope.event,
        claimed.createdAt,
        finishedAt
      );
      return {
        kind: 'delivered',
        outboxEventId: claimed.id,
        deliveryId: delivery.id,
        eventId: envelope.envelope.id,
        eventType: envelope.envelope.event,
        httpStatus: httpResult.statusCode,
        claimLatencyMs
      };
    }

    // Failure path: either non-2xx response, transport error, or timeout.
    const httpStatus = httpResult.kind === 'success' ? httpResult.statusCode : null;
    const errorMessage =
      httpResult.kind === 'transport_error'
        ? httpResult.error
        : `non_2xx_response:${httpResult.statusCode}`;
    const responseSnippet =
      httpResult.kind === 'success'
        ? truncate(httpResult.bodyText, this.retryPolicy.responseSnippetLength)
        : null;

    if (attemptNumber >= this.retryPolicy.maxAttempts) {
      await this.deps.db.withTransaction(async (tx) => {
        await this.deps.deliveryRepository.applyAttempt(tx, {
          id: delivery.id,
          status: 'dead_letter',
          attemptCount: attemptNumber,
          httpStatus,
          responseSnippet,
          error: errorMessage,
          nextAttemptAt: finishedAt,
          deliveredAt: null,
          firstAttemptStartedAt: firstAttemptStartedAtToPersist,
          firstAttemptFinishedAt: firstAttemptFinishedAtToPersist
        });
        await this.deps.endpointRepository.markFailure(tx, endpoint.id, finishedAt);
        await this.deps.outboxRepository.markFailed(tx, claimed.id);
      });
      return {
        kind: 'dlq',
        outboxEventId: claimed.id,
        deliveryId: delivery.id,
        attemptNumber,
        error: errorMessage,
        httpStatus,
        claimLatencyMs
      };
    }

    const delayMs = backoffDelayMs(attemptNumber, this.retryPolicy);
    const nextAttemptAt = new Date(finishedAt.getTime() + delayMs);
    await this.deps.db.withTransaction(async (tx) => {
      await this.deps.deliveryRepository.applyAttempt(tx, {
        id: delivery.id,
        status: 'failed',
        attemptCount: attemptNumber,
        httpStatus,
        responseSnippet,
        error: errorMessage,
        nextAttemptAt,
        deliveredAt: null,
        firstAttemptStartedAt: firstAttemptStartedAtToPersist,
        firstAttemptFinishedAt: firstAttemptFinishedAtToPersist
      });
      await this.deps.endpointRepository.markFailure(tx, endpoint.id, finishedAt);
      await this.deps.outboxRepository.scheduleRetry(tx, {
        id: claimed.id,
        availableAt: nextAttemptAt
      });
    });
    return {
      kind: 'retry',
      outboxEventId: claimed.id,
      deliveryId: delivery.id,
      attemptNumber,
      error: errorMessage,
      httpStatus,
      nextAttemptAt,
      claimLatencyMs
    };
  }

  async dispatchBatch(limit: number): Promise<DispatchOutcome[]> {
    if (!Number.isInteger(limit) || limit <= 0) {
      throw new Error(`dispatchBatch: limit must be a positive integer (got ${limit})`);
    }
    const results: DispatchOutcome[] = [];
    for (let i = 0; i < limit; i += 1) {
      const outcome = await this.dispatchNext();
      results.push(outcome);
      if (outcome.kind === 'empty') break;
    }
    return results;
  }

  // ────────────────────────────────────────────────────────────────────

  private async reclaimStaleOutboxRows(now: Date): Promise<void> {
    const nowMs = now.getTime();
    // Throttle: skip the sweep (and its UPDATE round-trip) unless the minimum
    // interval has elapsed since the last run. Keeps the latency-critical claim
    // path free of an extra query on most ticks.
    if (nowMs - this.lastReaperAtMs < this.reaperMinIntervalMs) {
      return;
    }
    this.lastReaperAtMs = nowMs;
    const staleBefore = new Date(nowMs - STALE_PROCESSING_THRESHOLD_MS);
    try {
      await this.deps.outboxRepository.reclaimStaleProcessing(this.deps.db.pool, staleBefore);
    } catch {
      // Reaper errors are non-fatal: the main dispatch loop must not be
      // blocked by a transient DB issue in the sweep query.
    }
  }

  private async skip(
    claimed: OutboxEventRecord,
    reason: DispatchSkipReason,
    claimLatencyMs: number
  ): Promise<DispatchOutcome> {
    // Treating an unprocessable row as "published" lets the queue
    // drain so a misconfigured endpoint or a never-subscribed event
    // doesn't block unrelated traffic. The `client_webhook_deliveries`
    // table intentionally stays empty for these — the audit trail
    // lives in `outbox_events.status` + the diagnostic skip reason
    // returned to the caller.
    await this.deps.db.withTransaction((tx) =>
      this.deps.outboxRepository.markPublished(tx, claimed.id)
    );
    return { kind: 'skipped', outboxEventId: claimed.id, reason, claimLatencyMs };
  }

  private async tryDeliver(
    url: string,
    bodyText: string,
    signature: string,
    timeoutMs: number
  ): Promise<DeliveryAttemptResult> {
    try {
      const response = await this.deps.httpClient.post({
        url,
        headers: {
          'content-type': 'application/json',
          'x-cashyin-signature': signature
        },
        bodyText,
        timeoutMs
      });
      return {
        kind: 'success',
        statusCode: response.statusCode,
        bodyText: response.bodyText
      };
    } catch (error) {
      return { kind: 'transport_error', error: errorMessage(error) };
    }
  }
}

type DeliveryAttemptResult =
  | { kind: 'success'; statusCode: number; bodyText: string }
  | { kind: 'transport_error'; error: string };

function recordClientWebhookDeliveryMetrics(
  eventType: string,
  result: DeliveryAttemptResult,
  startedAt: bigint,
  timeoutMs: number
): void {
  const status = result.kind === 'success' ? String(result.statusCode) : 'transport_error';
  const success = result.kind === 'success' && result.statusCode >= 200 && result.statusCode < 300;
  const labels = {
    event_type: eventType,
    operation_type: operationFromEventType(eventType),
    result: success ? 'success' : 'failure',
    status
  };

  metrics.increment(
    'cashyin_client_webhook_delivery_total',
    'Total client webhook delivery attempts by event type and result.',
    labels
  );
  metrics.observeDurationSeconds(
    'cashyin_client_webhook_delivery_duration_seconds',
    'Duration of outbound client webhook HTTP attempts.',
    startedAt,
    labels
  );
  metrics.setGauge(
    'cashyin_client_webhook_timeout_ms',
    'Configured client webhook timeout in milliseconds by event type.',
    {
      event_type: eventType,
      operation_type: operationFromEventType(eventType)
    },
    timeoutMs
  );
}

/**
 * Histogram buckets (seconds) tuned to make the 100-200 ms first-attempt
 * delivery target legible on dashboards. Denser around 0.1-0.2 s than the
 * generic default duration buckets.
 */
const FIRST_ATTEMPT_LATENCY_BUCKETS_SECONDS = [
  0.025, 0.05, 0.075, 0.1, 0.15, 0.2, 0.3, 0.5, 1, 2, 5, 10
] as const;

/**
 * Emits the Part-1 first-attempt latency histograms, both measured from
 * `outbox_events.created_at` (outbox_created_at):
 *
 *   first_attempt_start_latency = attemptStartedAt - outboxCreatedAt
 *       The CashYin-controlled segment (enqueue -> just before HTTP send).
 *       This is the segment the 100-200 ms target applies to.
 *   first_attempt_total_latency = attemptFinishedAt - outboxCreatedAt
 *       Additionally includes the client's response/timeout time, which
 *       CashYin does not control.
 *
 * Negative diffs (clock skew between the DB `created_at` and the worker
 * wall clock) are clamped to 0 so a skewed sample never corrupts the
 * histogram sum.
 */
function recordClientWebhookFirstAttemptLatencyMetrics(
  eventType: string,
  outboxCreatedAt: Date,
  attemptStartedAt: Date,
  attemptFinishedAt: Date
): void {
  const labels = {
    event_type: eventType,
    operation_type: operationFromEventType(eventType)
  };
  metrics.observe(
    'cashyin_client_webhook_first_attempt_start_latency_seconds',
    'Latency from outbox event creation to the start of the first client webhook HTTP attempt (CashYin-controlled segment).',
    labels,
    nonNegativeSeconds(outboxCreatedAt, attemptStartedAt),
    FIRST_ATTEMPT_LATENCY_BUCKETS_SECONDS
  );
  metrics.observe(
    'cashyin_client_webhook_first_attempt_total_latency_seconds',
    'Latency from outbox event creation to the completion of the first client webhook HTTP attempt (includes client response time).',
    labels,
    nonNegativeSeconds(outboxCreatedAt, attemptFinishedAt),
    FIRST_ATTEMPT_LATENCY_BUCKETS_SECONDS
  );
}

/**
 * Emits `success_latency = delivered_at - outbox_created_at`, the end-to-end
 * internal latency to a successful delivery (includes any retries + client
 * response time). Same clamp rationale as the first-attempt metrics.
 */
function recordClientWebhookSuccessLatencyMetrics(
  eventType: string,
  outboxCreatedAt: Date,
  deliveredAt: Date
): void {
  metrics.observe(
    'cashyin_client_webhook_success_latency_seconds',
    'Latency from outbox event creation to a successful client webhook delivery.',
    {
      event_type: eventType,
      operation_type: operationFromEventType(eventType)
    },
    nonNegativeSeconds(outboxCreatedAt, deliveredAt),
    FIRST_ATTEMPT_LATENCY_BUCKETS_SECONDS
  );
}

function nonNegativeSeconds(start: Date, end: Date): number {
  const ms = end.getTime() - start.getTime();
  return ms > 0 ? ms / 1000 : 0;
}

type EnvelopeBuildResult =
  | { kind: 'ok'; envelope: PublicWebhookEnvelope }
  | { kind: 'unsupported' }
  | { kind: 'malformed' };

function isSupportedAggregateType(aggregateType: string): aggregateType is SupportedAggregateType {
  return (SUPPORTED_AGGREGATE_TYPES as readonly string[]).includes(aggregateType);
}

function hasClaimFilter(filter: OutboxDispatchClaimFilter): boolean {
  return (
    (filter.eventTypes?.length ?? 0) > 0 || (filter.excludeEventTypes?.length ?? 0) > 0
  );
}

function tryBuildEnvelope(claimed: OutboxEventRecord): EnvelopeBuildResult {
  if (claimed.aggregateType === 'cash_in') {
    return tryBuildCashInEnvelope(claimed);
  }
  if (claimed.aggregateType === 'cashout') {
    return tryBuildCashOutEnvelope(claimed);
  }
  return { kind: 'unsupported' };
}

function tryBuildCashInEnvelope(claimed: OutboxEventRecord): EnvelopeBuildResult {
  const status = cashInStatusForOutbox(claimed.eventType);
  if (status === null) return { kind: 'unsupported' };

  const txid = pickString(claimed.payload, 'txid');
  const externalRef = pickString(claimed.payload, 'external_ref');
  const amount = pickInt(claimed.payload, 'amount');
  const createdAt = pickDate(claimed.payload, 'created_at');

  if (!txid || !externalRef || amount === null || !createdAt) {
    return { kind: 'malformed' };
  }

  // Deterministic event id derived from the outbox row id so retries
  // emit byte-for-byte identical envelopes.
  const input: BuildCashInEnvelopeInput = {
    eventId: `evt_${claimed.id}`,
    txid,
    externalRef,
    status,
    amount,
    emittedAt: claimed.createdAt,
    createdAt,
    emv: pickString(claimed.payload, 'emv'),
    description: pickString(claimed.payload, 'description'),
    expiresAt: pickDate(claimed.payload, 'expires_at'),
    paidAt: pickDate(claimed.payload, 'paid_at'),
    e2eId: pickString(claimed.payload, 'e2e_id') ?? pickString(claimed.payload, 'end_to_end_id'),
    payer: pickCashInPayer(claimed.payload)
  };

  try {
    return { kind: 'ok', envelope: buildCashInWebhookEnvelope(input) };
  } catch {
    return { kind: 'malformed' };
  }
}

function pickCashInPayer(payload: Record<string, unknown>): PublicCounterpartySource | null {
  const value = payload['payer'];
  if (value === null || typeof value !== 'object' || Array.isArray(value)) {
    return null;
  }
  const record = value as Record<string, unknown>;

  // The outbox stores the payer in the normalized counterparty shape
  // (camelCase: documentNumber/bank/ispb/branch/account/accountType).
  const name = pickStringField(record, 'name');
  const documentNumber = pickStringField(record, 'documentNumber');
  const bank = pickStringField(record, 'bank');
  const ispb = pickStringField(record, 'ispb');

  // Require at least one identifying field to treat the block as present.
  if (!name && !documentNumber && !bank && !ispb) return null;

  return {
    name,
    documentNumber,
    bank,
    ispb,
    branch: pickStringField(record, 'branch'),
    account: pickStringField(record, 'account'),
    accountType: pickStringField(record, 'accountType')
  };
}

function pickStringField(record: Record<string, unknown>, key: string): string | null {
  const value = record[key];
  return typeof value === 'string' && value.length > 0 ? value : null;
}

function tryBuildCashOutEnvelope(claimed: OutboxEventRecord): EnvelopeBuildResult {
  const status = cashOutStatusForOutbox(claimed.eventType);
  if (status === null) return { kind: 'unsupported' };

  const transactionId = pickString(claimed.payload, 'cashoutId');
  // `external_ref` is optional on the public contract; a null reference is
  // valid and flows straight through to the envelope.
  const externalRef = pickString(claimed.payload, 'externalId');
  const amount = pickInt(claimed.payload, 'amountCents');
  const pixKey = pickString(claimed.payload, 'pixKey');
  const pixKeyType = pickString(claimed.payload, 'pixKeyType');
  const createdAt = pickDate(claimed.payload, 'createdAt');

  if (!transactionId || amount === null || !pixKey || !pixKeyType || !createdAt) {
    return { kind: 'malformed' };
  }

  const occurredAt = pickDate(claimed.payload, 'occurredAt');

  const timestamps: CashOutTimestamps = {
    createdAt,
    ...(status === 'completed' && occurredAt ? { completedAt: occurredAt } : {}),
    ...(status === 'failed' && occurredAt ? { failedAt: occurredAt } : {}),
    ...(status === 'returned' && occurredAt ? { returnedAt: occurredAt } : {})
  };

  const e2eId = pickString(claimed.payload, 'e2eId') ?? pickString(claimed.payload, 'endToEndId');
  const failureReason = pickString(claimed.payload, 'failureReason');
  const receiver: CashOutReceiverInput = {
    name: pickString(claimed.payload, 'receiverName'),
    document: pickString(claimed.payload, 'receiverDocument'),
    bank: pickString(claimed.payload, 'receiverBank'),
    ispb: pickString(claimed.payload, 'receiverIspb'),
    branch: pickString(claimed.payload, 'receiverBranch'),
    account: pickString(claimed.payload, 'receiverAccount'),
    accountType: pickString(claimed.payload, 'receiverAccountType')
  };
  const input: BuildCashOutEnvelopeInput = {
    eventId: `evt_${claimed.id}`,
    transactionId,
    externalRef,
    status,
    amount,
    pixKey,
    pixKeyType,
    emittedAt: claimed.createdAt,
    timestamps,
    receiver,
    ...(e2eId ? { counterparty: { e2eId } } : {}),
    ...(failureReason ? { failureReason } : {})
  };

  try {
    return { kind: 'ok', envelope: buildCashOutWebhookEnvelope(input) };
  } catch {
    return { kind: 'malformed' };
  }
}

function cashInStatusForOutbox(eventType: string): DispatchableCashInStatus | null {
  switch (eventType) {
    case 'pix.cash_in.paid':
      return 'paid';
    case 'pix.cash_in.expired':
      return 'expired';
    case 'pix.cash_in.cancelled':
      return 'cancelled';
    case 'pix.cash_in.failed':
      return 'failed';
    case 'pix.cash_in.refunded':
      return 'refunded';
    default:
      return null;
  }
}

function cashOutStatusForOutbox(eventType: string): CashOutStatus | null {
  // Accept BOTH the canonical internal tokens (`pix.cash_out.*`) and the
  // legacy ones (`cashout.*`) so the dispatcher keeps draining any in-flight
  // rows enqueued before migration 0015 / the producer rename. New rows are
  // always written as `pix.cash_out.*` going forward.
  switch (eventType) {
    // Product decision: the `processing` lifecycle stage is NOT surfaced as a
    // public cash-out webhook. Clients only receive terminal cash-out events
    // (`completed`/`failed`/`returned`). The internal `*.initiated` and
    // `*.processing` outbox rows are therefore skipped here (treated as
    // `unsupported_event_type`, marked published) so the queue drains without
    // ever POSTing `pix.cash_out.processing`.
    case 'pix.cash_out.initiated':
    case 'pix.cash_out.processing':
    case 'cashout.initiated':
    case 'cashout.processing':
      return null;
    case 'pix.cash_out.completed':
    case 'cashout.completed':
      return 'completed';
    case 'pix.cash_out.failed':
    case 'cashout.failed':
      return 'failed';
    case 'pix.cash_out.returned':
    case 'cashout.returned':
      return 'returned';
    default:
      return null;
  }
}

function signEnvelope(bodyText: string, secret: string): string {
  const mac = createHmac('sha256', secret).update(bodyText).digest('hex');
  return `sha256=${mac}`;
}

function isSuccessStatus(statusCode: number): boolean {
  return statusCode >= 200 && statusCode < 300;
}

function truncate(text: string, max: number): string {
  if (text.length <= max) return text;
  return `${text.slice(0, max)}…`;
}

function backoffDelayMs(attemptNumber: number, policy: ClientWebhookRetryPolicy): number {
  const exponent = Math.max(0, attemptNumber - 1);
  return Math.min(policy.baseDelayMs * 2 ** exponent, policy.maxDelayMs);
}

function errorMessage(error: unknown): string {
  if (error instanceof Error) return error.message;
  return String(error);
}

function pickString(payload: Record<string, unknown>, key: string): string | null {
  const value = payload[key];
  return typeof value === 'string' && value.length > 0 ? value : null;
}

function pickInt(payload: Record<string, unknown>, key: string): number | null {
  const value = payload[key];
  if (typeof value === 'number' && Number.isInteger(value) && value >= 0) return value;
  if (typeof value === 'string') {
    const parsed = Number(value);
    if (Number.isInteger(parsed) && parsed >= 0) return parsed;
  }
  return null;
}

function pickDate(payload: Record<string, unknown>, key: string): Date | null {
  const value = payload[key];
  if (typeof value !== 'string' || value.length === 0) return null;
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}
