import type { ProviderName } from '../../providers/contracts/provider-types.js';
import type {
  ProviderWebhookNormalizedEvent,
  ProviderWebhookNormalizedStatus,
  ProviderWebhookVerificationFailureReason,
  RawHeaders
} from '../../providers/contracts/provider-webhook-adapter.js';
import type { Database } from '../../shared/db/database.js';
import type { ProviderWebhookAdapterRegistry } from './provider-webhook-adapter-registry.js';
import type {
  WebhookEventInsertInput,
  WebhookEventRecord,
  WebhookEventRepository
} from './webhook-event.repository.js';

export type WebhookIngestionInput = {
  providerName: ProviderName;
  rawBody: Buffer;
  headers: RawHeaders;
  /**
   * Optional pre-extracted signature value. When `null`, the adapter
   * pulls the signature from its provider-specific header (e.g.
   * `x-bents-signature`) directly out of `headers`.
   */
  signature: string | null;
  payload: unknown;
  receivedAt?: Date;
};

export type WebhookIngestionResult =
  | {
      outcome: 'invalid_signature';
      reason: ProviderWebhookVerificationFailureReason;
      detail?: string;
    }
  | {
      outcome: 'persisted' | 'duplicate';
      event: WebhookEventRecord;
      normalizedStatus: ProviderWebhookNormalizedStatus;
    };

/**
 * Phase 4 webhook ingress orchestrator.
 *
 * The service walks the request through the provider adapter's
 * three-step protocol (verify → parse → normalize) and persists the
 * resulting canonical event in `webhook_events`. It deliberately does
 * NOT call any domain handler: the persisted row is picked up by the
 * asynchronous processor (Phase 5), which is responsible for resolving
 * the `provider_transaction_id` to a CashYin transaction, applying the
 * state-machine transition, and enqueueing the public webhook outbox
 * event.
 *
 * Outcomes:
 *
 *   - `invalid_signature` — verification failed. The row is NOT
 *     persisted (defence against arbitrary unauthenticated bodies
 *     filling the table); the caller maps this to HTTP 401. The
 *     `reason` discriminator is the same vocabulary the adapter
 *     produces so dashboards can group failures.
 *
 *   - `persisted`         — first sighting of a valid event. Row is
 *     stored with `processing_status='pending'` (default from
 *     migration 0006).
 *
 *   - `duplicate`         — provider retry: the existing row is
 *     returned untouched. Caller maps to HTTP 200.
 */
export class WebhookService {
  constructor(
    private readonly db: Database,
    private readonly adapterRegistry: ProviderWebhookAdapterRegistry,
    private readonly repository: WebhookEventRepository
  ) {}

  async ingest(input: WebhookIngestionInput): Promise<WebhookIngestionResult> {
    const adapter = this.adapterRegistry.get(input.providerName);
    const receivedAt = input.receivedAt ?? new Date();

    const verification = await adapter.verify({
      rawBody: input.rawBody,
      headers: input.headers,
      signature: input.signature,
      receivedAt
    });

    if (!verification.valid) {
      const result: WebhookIngestionResult = {
        outcome: 'invalid_signature',
        reason: verification.reason
      };
      if (verification.detail !== undefined) {
        result.detail = verification.detail;
      }
      return result;
    }

    const parsed = await adapter.parse({
      rawBody: input.rawBody,
      payload: input.payload,
      headers: input.headers
    });
    const normalized = await adapter.normalize(parsed);

    return this.db.withTransaction(async (tx) => {
      const inserted = await this.repository.insert(
        tx,
        toInsertInput(normalized, receivedAt)
      );
      return {
        outcome: inserted.duplicate ? 'duplicate' : 'persisted',
        event: inserted.record,
        normalizedStatus: normalized.normalizedStatus
      };
    });
  }
}

function toInsertInput(
  normalized: ProviderWebhookNormalizedEvent,
  receivedAt: Date
): WebhookEventInsertInput {
  return {
    providerName: normalized.providerName,
    eventType: normalized.providerEventType,
    providerEventId: normalized.providerEventId,
    providerTransactionId: normalized.providerTransactionId,
    providerStatus: normalized.providerStatus,
    operationType: normalized.operationType,
    occurredAt: normalized.occurredAt,
    normalizedStatus: normalized.normalizedStatus,
    // Signature was already verified before we got here; any row this
    // service persists corresponds to a valid signature.
    signatureValid: true,
    payload: normalized.rawPayload,
    rawPayloadHash: normalized.rawPayloadHash,
    redactedHeaders: normalized.redactedHeaders,
    receivedAt
  };
}
