/**
 * Phase 5 — Asynchronous provider-webhook processor.
 *
 * The HTTP ingress (Phase 4) commits a row in `webhook_events` and
 * returns 2xx; the processor implemented here walks the queue in the
 * background, applies the domain transition, and finalises the row.
 *
 * Design notes
 * ------------
 *  - Each `processNext()` call runs a small pipeline: claim row →
 *    handle → finalise. The handler runs in its own transaction
 *    (delegated through `PaymentService.handleChargePaid` /
 *    `.handleChargeTerminal`), which keeps the claim transaction
 *    short and lets us call into the existing payment service without
 *    re-implementing its idempotency / ledger / outbox plumbing.
 *
 *  - The processor never auto-starts during HTTP boot. It is exposed
 *    via the composition container so a CLI/worker process, an admin
 *    HTTP endpoint, or a unit test can drive it manually. This keeps
 *    Phase 5 reviewable without committing to a deployment topology
 *    yet (Lambda vs. ECS scheduled task vs. embedded worker).
 *
 *  - Retries use deterministic exponential backoff with a 1-hour cap
 *    and a max-attempt threshold. Anything beyond that is routed to
 *    DLQ (`processing_status='dlq'`) so on-call dashboards can pick
 *    it up without affecting the live queue.
 *
 *  - `cash_out` events (Phase 7) route to
 *    {@link CashoutService.handleCashoutStatusUpdate}, which transitions
 *    `cashouts.status` and enqueues a `pix.cash_out.<status>` outbox row.
 *    `processing` re-confirmations are skipped (the initial create
 *    already wrote that status) and unknown cash-out statuses fall
 *    through to `unsupported_cash_out_status` so the audit trail stays
 *    explicit.
 */

import type {
  CashoutService,
  CashoutStatusUpdateEvent
} from '../cashouts/cashout.service.js';
import type { TerminalCashoutStatus } from '../cashouts/cashout.repository.js';
import type { ChargeTerminalEvent, PaymentService } from '../payments/payment.service.js';
import type { TerminalCashInFailureStatus } from '../payments/cash-in.repository.js';
import type { CashOutStatus } from '../transactions/status.js';
import type { Database } from '../../shared/db/database.js';
import type {
  WebhookEventClaimFilter,
  WebhookEventRecord,
  WebhookEventRepository
} from './webhook-event.repository.js';
import type {
  WebhookProcessingAttemptOutcome,
  WebhookProcessingAttemptRepository
} from './webhook-processing-attempt.repository.js';
import { metrics } from '../../shared/observability/metrics.js';

const TERMINAL_CASH_IN_FAILURES: ReadonlySet<TerminalCashInFailureStatus> = new Set<
  TerminalCashInFailureStatus
>(['expired', 'cancelled', 'failed', 'refunded']);

/** Rows stuck in 'processing' longer than this are reclaimed as 'pending'. */
const STALE_PROCESSING_THRESHOLD_MS = 5 * 60 * 1_000; // 5 minutes

const TERMINAL_CASH_OUT_STATUSES: ReadonlySet<TerminalCashoutStatus> = new Set<
  TerminalCashoutStatus
>(['completed', 'failed', 'returned']);

const DEFAULT_RETRY_POLICY: WebhookRetryPolicy = {
  baseDelayMs: 30_000,
  maxDelayMs: 60 * 60 * 1000,
  maxAttempts: 8
};

export type WebhookRetryPolicy = {
  /** Backoff for the first failed attempt, in milliseconds. */
  baseDelayMs: number;
  /** Upper bound on `baseDelayMs * 2^(attempt-1)`. */
  maxDelayMs: number;
  /** Attempts exceeding this number are sent to DLQ instead of retried. */
  maxAttempts: number;
};

export type WebhookEventProcessorDeps = {
  db: Database;
  webhookEventRepository: WebhookEventRepository;
  attemptRepository: WebhookProcessingAttemptRepository;
  paymentService: PaymentService;
  cashoutService: CashoutService;
  /**
   * Override clock for deterministic testing. Defaults to `() => new Date()`.
   */
  now?: () => Date;
  /** Override retry policy for tests / future tuning. */
  retryPolicy?: WebhookRetryPolicy;
  /**
   * Identifier persisted into `provider_webhook_processing_attempts.worker_id`.
   * Useful for multi-worker deployments; defaults to `null`.
   */
  workerId?: string;
  /**
   * Logical worker role (e.g. `cashin-paid`). Surfaced in the `worker`
   * metric label and structured logs so dashboards can attribute work to
   * the right partition. Defaults to `'default'`.
   */
  workerName?: string;
  /**
   * Optional partition filter forwarded to {@link WebhookEventRepository.claimNextPending}.
   * When omitted the processor drains the whole queue (back-compat).
   */
  claimFilter?: WebhookEventClaimFilter;
};

/**
 * Result of a single `processNext()` invocation.
 *
 *   - `empty`       — no rows were due; the caller should sleep.
 *   - `processed`   — the handler ran successfully and the row is
 *                     committed in `processing_status='processed'`.
 *   - `noop`        — the handler short-circuited because the
 *                     underlying domain row was already in a terminal
 *                     state (duplicate / out-of-order delivery). The
 *                     row is committed as `processed` because the
 *                     processor has finished with it.
 *   - `skipped`     — the event is one we deliberately don't process
 *                     (unknown / cash_out / missing fields); the row is
 *                     committed as `skipped` with the reason recorded.
 *   - `retry`       — the handler threw a retryable error and the row
 *                     was put back to `processing_status='failed'` with
 *                     a future `next_attempt_at`.
 *   - `dlq`         — retry budget exhausted; row was committed as
 *                     `dlq` with the last error attached.
 *
 * All non-empty outcomes include `claimLatencyMs`: milliseconds between
 * when the provider sent the webhook (`webhook_events.received_at`) and
 * when this worker successfully claimed the row. Use this to measure
 * Worker-1 queue-wait time in structured logs / dashboards.
 */
export type ProcessOutcome =
  | { kind: 'empty' }
  | {
      kind: 'processed';
      eventId: string;
      /** ms between webhook_events.received_at and the claim timestamp. */
      claimLatencyMs?: number;
      detail:
        | { flow: 'cash_in_paid'; chargeId: string; ledgerEntriesPosted: number }
        | { flow: 'cash_in_terminal'; chargeId: string; status: TerminalCashInFailureStatus }
        | {
            flow: 'cash_out_status_update';
            cashoutId: string;
            previousStatus: CashOutStatus;
            newStatus: TerminalCashoutStatus;
          };
    }
  | {
      kind: 'noop';
      eventId: string;
      /** ms between webhook_events.received_at and the claim timestamp. */
      claimLatencyMs?: number;
      reason:
        | 'charge_not_found'
        | 'already_paid'
        | 'already_terminal'
        | 'transition_not_allowed'
        | 'cashout_not_found'
        | 'already_in_status'
        | 'invalid_transition';
    }
  | {
      kind: 'skipped';
      eventId: string;
      /** ms between webhook_events.received_at and the claim timestamp. */
      claimLatencyMs?: number;
      reason: WebhookSkipReason;
    }
  | {
      kind: 'retry';
      eventId: string;
      /** ms between webhook_events.received_at and the claim timestamp. */
      claimLatencyMs?: number;
      attemptNumber: number;
      error: string;
      nextAttemptAt: Date;
    }
  | {
      kind: 'dlq';
      eventId: string;
      /** ms between webhook_events.received_at and the claim timestamp. */
      claimLatencyMs?: number;
      attemptNumber: number;
      error: string;
    };

export type WebhookSkipReason =
  | 'unknown_normalized_status'
  | 'cash_out_processing_reconfirm'
  | 'missing_provider_transaction_id'
  | 'unsupported_cash_in_status'
  | 'unsupported_cash_out_status';

export class WebhookEventProcessor {
  private readonly retryPolicy: WebhookRetryPolicy;
  private readonly clock: () => Date;
  private readonly workerId: string | null;
  private readonly workerName: string;
  private readonly claimFilter: WebhookEventClaimFilter | undefined;

  constructor(private readonly deps: WebhookEventProcessorDeps) {
    this.retryPolicy = deps.retryPolicy ?? DEFAULT_RETRY_POLICY;
    this.clock = deps.now ?? ((): Date => new Date());
    this.workerId = deps.workerId ?? null;
    this.workerName = deps.workerName ?? 'default';
    this.claimFilter = deps.claimFilter;
  }

  /**
   * Claim and process the next due row. Returns `{ kind: 'empty' }`
   * when the queue has no eligible entries.
   *
   * Before claiming, runs the stale-processing reaper to reclaim any rows
   * left in `processing` by a previously-crashed worker.
   */
  async processNext(): Promise<ProcessOutcome> {
    const startedAt = this.clock();
    const startedHr = process.hrtime.bigint();

    // Reclaim rows stuck in 'processing' by crashed workers before claiming
    // the next row. This is a no-op when nothing is stale, so the overhead
    // per tick is a single cheap UPDATE with a partial-index predicate.
    await this.reclaimStaleWebhookEvents(startedAt);

    const claimed = await this.deps.db.withTransaction((tx) =>
      this.deps.webhookEventRepository.claimNextPending(tx, {
        now: startedAt,
        ...(this.claimFilter ? { filter: this.claimFilter } : {})
      })
    );
    if (!claimed) {
      return { kind: 'empty' };
    }

    // Milliseconds between when the provider delivered the webhook to the
    // HTTP ingress and when this worker claimed it for processing. Surfaced
    // in structured logs so ops can measure queue-wait time for Worker-1.
    const claimLatencyMs = startedAt.getTime() - claimed.receivedAt.getTime();

    try {
      const handled = await this.dispatch(claimed);
      await this.commit(claimed, handled, startedAt);
      const outcome = { ...handled, claimLatencyMs } as ProcessOutcome;
      recordProviderWebhookProcessingMetrics(claimed, outcome, startedHr, this.workerName);
      return outcome;
    } catch (error) {
      const failed = await this.handleFailure(claimed, error, startedAt);
      const outcome = { ...failed, claimLatencyMs } as ProcessOutcome;
      recordProviderWebhookProcessingMetrics(claimed, outcome, startedHr, this.workerName);
      return outcome;
    }
  }

  /**
   * Drains up to `limit` events. Stops early on the first `empty`
   * outcome so callers don't loop forever on a quiet queue.
   */
  async processBatch(limit: number): Promise<ProcessOutcome[]> {
    if (!Number.isInteger(limit) || limit <= 0) {
      throw new Error(`processBatch: limit must be a positive integer (got ${limit})`);
    }
    const results: ProcessOutcome[] = [];
    for (let i = 0; i < limit; i += 1) {
      const outcome = await this.processNext();
      results.push(outcome);
      if (outcome.kind === 'empty') break;
    }
    return results;
  }

  // ────────────────────────────────────────────────────────────────────
  // Internal pipeline
  // ────────────────────────────────────────────────────────────────────

  private async reclaimStaleWebhookEvents(now: Date): Promise<void> {
    const staleBefore = new Date(now.getTime() - STALE_PROCESSING_THRESHOLD_MS);
    try {
      await this.deps.webhookEventRepository.reclaimStaleProcessing(
        this.deps.db.pool,
        staleBefore
      );
    } catch {
      // Reaper errors are non-fatal: the main processing loop must not be
      // blocked by a transient DB issue in the sweep query.
    }
  }

  private async dispatch(event: WebhookEventRecord): Promise<ProcessOutcome> {
    if (event.normalizedStatusKind === 'unknown') {
      return { kind: 'skipped', eventId: event.id, reason: 'unknown_normalized_status' };
    }
    if (event.providerTransactionId === null) {
      return { kind: 'skipped', eventId: event.id, reason: 'missing_provider_transaction_id' };
    }

    if (event.normalizedStatusKind === 'cash_out') {
      return this.dispatchCashOut(event);
    }

    if (event.normalizedStatus === 'paid') {
      return this.dispatchCashInPaid(event);
    }
    if (
      event.normalizedStatus !== null &&
      TERMINAL_CASH_IN_FAILURES.has(event.normalizedStatus as TerminalCashInFailureStatus)
    ) {
      return this.dispatchCashInTerminal(
        event,
        event.normalizedStatus as TerminalCashInFailureStatus
      );
    }

    return { kind: 'skipped', eventId: event.id, reason: 'unsupported_cash_in_status' };
  }

  private async dispatchCashOut(event: WebhookEventRecord): Promise<ProcessOutcome> {
    const providerPaymentId = event.providerTransactionId;
    if (providerPaymentId === null) {
      return { kind: 'skipped', eventId: event.id, reason: 'missing_provider_transaction_id' };
    }
    if (event.normalizedStatus === null) {
      return { kind: 'skipped', eventId: event.id, reason: 'unsupported_cash_out_status' };
    }
    // `processing` is the initial status the createCashout flow already
    // wrote; a webhook re-confirming it adds no information. We skip
    // (rather than noop) to keep the trail explicit for ops dashboards.
    if (event.normalizedStatus === 'processing') {
      return { kind: 'skipped', eventId: event.id, reason: 'cash_out_processing_reconfirm' };
    }
    if (!TERMINAL_CASH_OUT_STATUSES.has(event.normalizedStatus as TerminalCashoutStatus)) {
      return { kind: 'skipped', eventId: event.id, reason: 'unsupported_cash_out_status' };
    }

    // Best-effort failure reason for non-success terminals: the adapter
    // does not normalise a dedicated reason field, so we fall back to the
    // raw provider status string. The service defaults to
    // `provider_rejected` when nothing usable is available.
    const failureReason =
      (event.normalizedStatus === 'failed' || event.normalizedStatus === 'returned') &&
      event.providerStatus
        ? event.providerStatus
        : null;

    // Receiver identity reported by the provider (e.g. Bents
    // `data.receiver.{name,document,bank,ispb,branch,account,account_type}`).
    // The document is forwarded exactly as the provider sends it — already
    // masked — and every field is applied with COALESCE semantics downstream
    // so a request- or earlier-webhook-supplied value is never lost. The
    // BACEN end-to-end id (`e2e_id`) is re-extracted here too: for an
    // asynchronous provider it may only arrive on this confirmation webhook,
    // so it must be backfilled onto the cash-out row (it survives only inside
    // `webhook_events.payload` otherwise).
    const receiver = extractCashOutReceiver(event.payload);
    const e2eId = extractCashOutE2eId(event.payload);

    const payload: CashoutStatusUpdateEvent = {
      providerName: event.providerName,
      providerPaymentId,
      status: event.normalizedStatus as TerminalCashoutStatus,
      occurredAt: event.occurredAt ?? event.receivedAt,
      failureReason,
      ...(receiver.name !== undefined ? { receiverName: receiver.name } : {}),
      ...(receiver.document !== undefined ? { receiverDocument: receiver.document } : {}),
      ...(receiver.bank !== undefined ? { receiverBank: receiver.bank } : {}),
      ...(receiver.ispb !== undefined ? { receiverIspb: receiver.ispb } : {}),
      ...(receiver.branch !== undefined ? { receiverBranch: receiver.branch } : {}),
      ...(receiver.account !== undefined ? { receiverAccount: receiver.account } : {}),
      ...(receiver.accountType !== undefined ? { receiverAccountType: receiver.accountType } : {}),
      ...(e2eId !== undefined ? { e2eId } : {})
    };
    const result = await this.deps.cashoutService.handleCashoutStatusUpdate(payload);
    if (result.status === 'updated') {
      return {
        kind: 'processed',
        eventId: event.id,
        detail: {
          flow: 'cash_out_status_update',
          cashoutId: result.cashoutId,
          previousStatus: result.previousStatus,
          newStatus: result.newStatus
        }
      };
    }
    return { kind: 'noop', eventId: event.id, reason: result.reason };
  }

  private async dispatchCashInPaid(event: WebhookEventRecord): Promise<ProcessOutcome> {
    const providerChargeId = event.providerTransactionId;
    if (providerChargeId === null) {
      // Already guarded in `dispatch`; reassures the type checker.
      return { kind: 'skipped', eventId: event.id, reason: 'missing_provider_transaction_id' };
    }
    const paidAt = event.occurredAt ?? event.receivedAt;
    // Auxiliary fields (e2e id, realised amount, payer block) aren't
    // promoted to first-class columns on `webhook_events` today; the
    // adapter extracts them while parsing but they only survive inside
    // `payload`. Re-extract from the persisted JSON so the domain can
    // record the BACEN end-to-end identifier and the payer fields on
    // the charge (without those we can't reconcile to MED events or to
    // bank statements). Strictly best-effort: when the payload is
    // missing these fields, `handleChargePaid` keeps the
    // already-recorded values via `COALESCE` in the repository.
    const extras = extractCashInPaidExtras(event.payload);
    const result = await this.deps.paymentService.handleChargePaid({
      provider_name: event.providerName,
      provider_charge_id: providerChargeId,
      paid_at: paidAt,
      ...(extras.e2e_id !== undefined ? { e2e_id: extras.e2e_id } : {}),
      ...(extras.realised_amount !== undefined
        ? { realised_amount: extras.realised_amount }
        : {}),
      ...(extras.payer ? { payer: extras.payer } : {})
    });
    if (result.status === 'updated') {
      return {
        kind: 'processed',
        eventId: event.id,
        detail: {
          flow: 'cash_in_paid',
          chargeId: result.charge_id,
          ledgerEntriesPosted: result.ledger_entries_posted
        }
      };
    }
    return { kind: 'noop', eventId: event.id, reason: result.reason };
  }

  private async dispatchCashInTerminal(
    event: WebhookEventRecord,
    status: TerminalCashInFailureStatus
  ): Promise<ProcessOutcome> {
    const providerChargeId = event.providerTransactionId;
    if (providerChargeId === null) {
      return { kind: 'skipped', eventId: event.id, reason: 'missing_provider_transaction_id' };
    }
    const payload: ChargeTerminalEvent = {
      provider_name: event.providerName,
      provider_charge_id: providerChargeId,
      status,
      occurred_at: event.occurredAt ?? event.receivedAt
    };
    const result = await this.deps.paymentService.handleChargeTerminal(payload);
    if (result.status === 'updated') {
      return {
        kind: 'processed',
        eventId: event.id,
        detail: { flow: 'cash_in_terminal', chargeId: result.charge_id, status: result.new_status }
      };
    }
    return { kind: 'noop', eventId: event.id, reason: result.reason };
  }

  private async commit(
    event: WebhookEventRecord,
    outcome: ProcessOutcome,
    startedAt: Date
  ): Promise<void> {
    if (outcome.kind === 'retry' || outcome.kind === 'dlq' || outcome.kind === 'empty') {
      // `retry` and `dlq` are emitted only from `handleFailure`, which
      // owns its own commit path. `empty` cannot reach this method.
      return;
    }
    const finishedAt = this.clock();
    const finaliseStatus = outcome.kind === 'skipped' ? 'skipped' : 'processed';
    const finaliseError = outcome.kind === 'skipped' ? outcome.reason : null;

    await this.deps.db.withTransaction(async (tx) => {
      await this.deps.webhookEventRepository.finalise(tx, {
        id: event.id,
        status: finaliseStatus,
        error: finaliseError
      });
      await this.deps.attemptRepository.insert(tx, {
        webhookEventId: event.id,
        attemptNumber: event.attemptCount,
        workerId: this.workerId,
        startedAt,
        finishedAt,
        outcome: attemptOutcomeFor(outcome),
        errorCode: null,
        errorMessage: outcome.kind === 'skipped' ? outcome.reason : null
      });
    });
  }

  private async handleFailure(
    event: WebhookEventRecord,
    error: unknown,
    startedAt: Date
  ): Promise<ProcessOutcome> {
    const finishedAt = this.clock();
    const message = errorMessage(error);
    const attemptNumber = event.attemptCount;

    if (attemptNumber >= this.retryPolicy.maxAttempts) {
      await this.deps.db.withTransaction(async (tx) => {
        await this.deps.webhookEventRepository.finalise(tx, {
          id: event.id,
          status: 'dlq',
          error: message
        });
        await this.deps.attemptRepository.insert(tx, {
          webhookEventId: event.id,
          attemptNumber,
          workerId: this.workerId,
          startedAt,
          finishedAt,
          outcome: 'permanent_failure',
          errorCode: 'max_attempts_exceeded',
          errorMessage: message
        });
      });
      return { kind: 'dlq', eventId: event.id, attemptNumber, error: message };
    }

    const delayMs = backoffDelayMs(attemptNumber, this.retryPolicy);
    const nextAttemptAt = new Date(finishedAt.getTime() + delayMs);
    await this.deps.db.withTransaction(async (tx) => {
      await this.deps.webhookEventRepository.scheduleRetry(tx, {
        id: event.id,
        error: message,
        nextAttemptAt
      });
      await this.deps.attemptRepository.insert(tx, {
        webhookEventId: event.id,
        attemptNumber,
        workerId: this.workerId,
        startedAt,
        finishedAt,
        outcome: 'retryable_failure',
        errorCode: null,
        errorMessage: message
      });
    });
    return { kind: 'retry', eventId: event.id, attemptNumber, error: message, nextAttemptAt };
  }
}

function recordProviderWebhookProcessingMetrics(
  event: WebhookEventRecord,
  outcome: ProcessOutcome,
  startedHr: bigint,
  workerName = 'default'
): void {
  const operationType = event.normalizedStatusKind === 'cash_out'
    ? 'cash_out'
    : event.normalizedStatusKind === 'unknown'
      ? 'unknown'
      : 'cash_in';
  const labels = {
    worker: workerName,
    provider: event.providerName,
    operation_type: operationType,
    normalized_status: event.normalizedStatus ?? 'unknown',
    result: outcome.kind,
    detail: outcome.kind === 'skipped' || outcome.kind === 'noop' ? outcome.reason : 'none'
  };

  metrics.increment(
    'cashyin_provider_webhook_processing_total',
    'Total provider webhook events processed by operation, normalized status and outcome.',
    labels
  );
  metrics.observeDurationSeconds(
    'cashyin_provider_webhook_processing_duration_seconds',
    'Duration of provider webhook worker processing after an event is claimed.',
    startedHr,
    labels
  );
  if (outcome.kind !== 'empty' && outcome.claimLatencyMs !== undefined) {
    metrics.observe(
      'cashyin_provider_webhook_claim_latency_seconds',
      'Delay between provider webhook ingress and provider webhook worker claim.',
      {
        worker: workerName,
        provider: event.providerName,
        operation_type: operationType,
        normalized_status: event.normalizedStatus ?? 'unknown'
      },
      outcome.claimLatencyMs / 1000
    );
  }
}

function attemptOutcomeFor(
  outcome: Exclude<ProcessOutcome, { kind: 'retry' } | { kind: 'dlq' } | { kind: 'empty' }>
): WebhookProcessingAttemptOutcome {
  if (outcome.kind === 'skipped') return 'permanent_failure';
  // `processed` and `noop` are both successes from the processor's
  // perspective: the row reached a terminal state without the handler
  // raising.
  return 'success';
}

function backoffDelayMs(attemptNumber: number, policy: WebhookRetryPolicy): number {
  // attemptNumber is 1-indexed (the attempt that just failed). The
  // sequence: 30s, 60s, 120s, 240s, … (capped at maxDelayMs).
  const exponent = Math.max(0, attemptNumber - 1);
  const raw = policy.baseDelayMs * 2 ** exponent;
  return Math.min(raw, policy.maxDelayMs);
}

function errorMessage(error: unknown): string {
  if (error instanceof Error) return error.message;
  return String(error);
}

type CashInPaidExtraPayer = {
  name?: string;
  document?: string;
  document_type?: 'cpf' | 'cnpj';
  bank_name?: string;
  bank_ispb?: string;
  bank_branch?: string;
  bank_account?: string;
  account_type?: string;
};

/**
 * Re-extracts the cash-in supplemental fields the adapter parsed at
 * ingress (e2e id, realised amount, payer block) directly from the
 * persisted payload JSON. This duplicates a small slice of the
 * adapter's logic on purpose: `webhook_events` does not promote
 * these auxiliary fields to typed columns, so the processor either
 * re-parses or loses them.
 *
 * Returns an object whose keys are present only when the corresponding
 * value was found — used with object spread so we don't synthesise an
 * `e2e_id: undefined` (`exactOptionalPropertyTypes` would
 * reject that downstream in `ChargePaidEvent`).
 *
 * The output key is the canonical CashYin `e2e_id`; the provider's raw
 * `end_to_end_id` / `e2e_id` payload keys are only read as inputs below.
 *
 * The payer extraction honours both the May/2026 nested
 * `{ payer: { name, document, bank: { … } } }` envelope and the
 * legacy flat `payer_name` / `payer_document` shape.
 */
function extractCashInPaidExtras(payload: unknown): {
  e2e_id?: string;
  realised_amount?: number;
  payer?: CashInPaidExtraPayer;
} {
  if (payload === null || typeof payload !== 'object' || Array.isArray(payload)) {
    return {};
  }
  const envelope = payload as Record<string, unknown>;
  const dataValue = envelope['data'];
  const data: Record<string, unknown> =
    dataValue !== null && typeof dataValue === 'object' && !Array.isArray(dataValue)
      ? (dataValue as Record<string, unknown>)
      : envelope;

  const out: {
    e2e_id?: string;
    realised_amount?: number;
    payer?: CashInPaidExtraPayer;
  } = {};

  // Provider payloads may carry the BACEN identifier under `e2e_id`
  // (canonical) or the legacy `end_to_end_id` key; we read both at this
  // adapter boundary but always emit the canonical `e2e_id` downstream.
  const e2eRaw =
    pickStringField(data, 'e2e_id') ??
    pickStringField(data, 'end_to_end_id') ??
    pickStringField(envelope, 'e2e_id') ??
    pickStringField(envelope, 'end_to_end_id');
  if (e2eRaw) {
    out.e2e_id = e2eRaw;
  }

  const realisedRaw =
    pickPositiveIntField(data, 'amount_cents') ??
    pickPositiveIntField(envelope, 'amount_cents');
  if (realisedRaw !== null) {
    out.realised_amount = realisedRaw;
  }

  const payerObj = pickRecord(data, 'payer');
  const bankObj = payerObj ? pickRecord(payerObj, 'bank') : null;
  const payer: CashInPaidExtraPayer = {};

  const name =
    (payerObj && pickStringField(payerObj, 'name')) ??
    pickStringField(data, 'payer_name') ??
    pickStringField(envelope, 'payer_name');
  if (name) payer.name = name;

  const document =
    (payerObj && pickStringField(payerObj, 'document')) ??
    pickStringField(data, 'payer_document') ??
    pickStringField(envelope, 'payer_document');
  if (document) payer.document = document;

  const documentTypeRaw =
    (payerObj && pickStringField(payerObj, 'document_type')) ??
    pickStringField(data, 'payer_document_type');
  if (documentTypeRaw) {
    const normalised = documentTypeRaw.trim().toLowerCase();
    if (normalised === 'cpf' || normalised === 'cnpj') {
      payer.document_type = normalised;
    }
  }

  const bankName =
    (bankObj && pickStringField(bankObj, 'name')) ??
    (payerObj && pickStringField(payerObj, 'bank_name')) ??
    pickStringField(data, 'payer_bank_name');
  if (bankName) payer.bank_name = bankName;

  const bankIspb =
    (bankObj && pickStringField(bankObj, 'ispb')) ??
    (payerObj && pickStringField(payerObj, 'bank_ispb')) ??
    pickStringField(data, 'payer_bank_ispb');
  if (bankIspb) payer.bank_ispb = bankIspb;

  const bankBranch =
    (bankObj && pickStringField(bankObj, 'branch')) ??
    (payerObj && pickStringField(payerObj, 'bank_branch')) ??
    pickStringField(data, 'payer_bank_branch');
  if (bankBranch) payer.bank_branch = bankBranch;

  const bankAccount =
    (bankObj && pickStringField(bankObj, 'account')) ??
    (payerObj && pickStringField(payerObj, 'bank_account')) ??
    pickStringField(data, 'payer_bank_account');
  if (bankAccount) payer.bank_account = bankAccount;

  const accountType =
    (bankObj && pickStringField(bankObj, 'account_type')) ??
    (payerObj && pickStringField(payerObj, 'account_type')) ??
    pickStringField(data, 'payer_account_type');
  if (accountType) payer.account_type = accountType;

  if (Object.keys(payer).length > 0) {
    out.payer = payer;
  }

  return out;
}

/**
 * Extracts the cash-out receiver block the provider attaches to terminal
 * webhooks (`data.receiver.{name,document}` for Bents). Returns keys only
 * when a usable value was found, for object-spread into the optional
 * `CashoutStatusUpdateEvent` fields under `exactOptionalPropertyTypes`.
 * The document is returned verbatim (already masked by the provider); we
 * never expose bank/ispb/branch/account, which are not part of the public
 * cash-out contract.
 */
type ExtractedCashOutReceiver = {
  name?: string;
  document?: string;
  bank?: string;
  ispb?: string;
  branch?: string;
  account?: string;
  accountType?: string;
};

function extractCashOutReceiver(payload: unknown): ExtractedCashOutReceiver {
  const data = cashOutPayloadData(payload);
  if (!data) return {};
  const envelope = payload as Record<string, unknown>;

  const receiver = pickRecord(data, 'receiver') ?? pickRecord(envelope, 'receiver');
  if (!receiver) return {};

  const out: ExtractedCashOutReceiver = {};
  const name = pickStringField(receiver, 'name');
  if (name) out.name = name;
  const document = pickStringField(receiver, 'document');
  if (document) out.document = document;
  const bank = pickStringField(receiver, 'bank');
  if (bank) out.bank = bank;
  const ispb = pickStringField(receiver, 'ispb');
  if (ispb) out.ispb = ispb;
  const branch = pickStringField(receiver, 'branch');
  if (branch) out.branch = branch;
  const account = pickStringField(receiver, 'account');
  if (account) out.account = account;
  const accountType = pickStringField(receiver, 'account_type');
  if (accountType) out.accountType = accountType;
  return out;
}

/**
 * Re-extracts the BACEN end-to-end id from the persisted webhook payload.
 * Honours both the nested `data.e2e_id` and the legacy `end_to_end_id`
 * spellings, at either the `data` or envelope level.
 */
function extractCashOutE2eId(payload: unknown): string | undefined {
  const data = cashOutPayloadData(payload);
  if (!data) return undefined;
  const envelope = payload as Record<string, unknown>;
  return (
    pickStringField(data, 'e2e_id') ??
    pickStringField(data, 'end_to_end_id') ??
    pickStringField(envelope, 'e2e_id') ??
    pickStringField(envelope, 'end_to_end_id') ??
    undefined
  );
}

function cashOutPayloadData(payload: unknown): Record<string, unknown> | null {
  if (payload === null || typeof payload !== 'object' || Array.isArray(payload)) {
    return null;
  }
  const envelope = payload as Record<string, unknown>;
  const dataValue = envelope['data'];
  return dataValue !== null && typeof dataValue === 'object' && !Array.isArray(dataValue)
    ? (dataValue as Record<string, unknown>)
    : envelope;
}

function pickStringField(record: Record<string, unknown>, key: string): string | null {
  const value = record[key];
  return typeof value === 'string' && value.length > 0 ? value : null;
}

function pickPositiveIntField(record: Record<string, unknown>, key: string): number | null {
  const value = record[key];
  if (typeof value === 'number' && Number.isInteger(value) && value > 0) return value;
  if (typeof value === 'string') {
    const parsed = Number(value);
    if (Number.isInteger(parsed) && parsed > 0) return parsed;
  }
  return null;
}

function pickRecord(record: Record<string, unknown>, key: string): Record<string, unknown> | null {
  const value = record[key];
  return value !== null && typeof value === 'object' && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : null;
}
