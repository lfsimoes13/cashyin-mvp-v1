import type { ProviderWebhookAdapter } from '../../providers/contracts/provider-webhook-adapter.js';
import type { ProviderName } from '../../providers/contracts/provider-types.js';
import { AppError } from '../../shared/errors/app-error.js';

/**
 * Provider-keyed registry of {@link ProviderWebhookAdapter} instances.
 *
 * Separated from {@link ProviderRegistry} (which serves
 * {@link PaymentProvider} synchronously to domain services) so the
 * provider webhook ingress can resolve its adapter without dragging in
 * the outbound provider client. The split also lets the ingress
 * deployment ship without the outbound HTTP client when we eventually
 * extract it into its own process.
 */
export class ProviderWebhookAdapterRegistry {
  private readonly adapters = new Map<ProviderName, ProviderWebhookAdapter>();

  constructor(adapters: ProviderWebhookAdapter[] = []) {
    for (const adapter of adapters) {
      this.adapters.set(adapter.providerName, adapter);
    }
  }

  get(providerName: ProviderName): ProviderWebhookAdapter {
    const adapter = this.adapters.get(providerName);
    if (!adapter) {
      throw new AppError(
        'provider_webhook_adapter_not_registered',
        `No webhook adapter registered for provider ${providerName}`,
        500
      );
    }
    return adapter;
  }

  has(providerName: ProviderName): boolean {
    return this.adapters.has(providerName);
  }

  list(): readonly ProviderName[] {
    return [...this.adapters.keys()];
  }
}
