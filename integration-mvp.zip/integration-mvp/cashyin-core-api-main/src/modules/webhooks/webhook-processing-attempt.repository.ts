import type { Sql } from '../../shared/db/sql.js';

/**
 * Outcome vocabulary mirrored from the CHECK constraint on
 * `provider_webhook_processing_attempts.outcome` (migration 0006).
 *
 *   - `success`            — the handler ran and the domain transition
 *                            was applied (or was already terminal).
 *   - `retryable_failure`  — the handler threw an error the processor
 *                            classifies as transient; the row will
 *                            be re-tried.
 *   - `permanent_failure`  — non-retryable: either max attempts were
 *                            reached or the handler signalled an
 *                            unrecoverable issue. The webhook row is
 *                            sent to the DLQ.
 *
 * (`in_progress` is also allowed by the table CHECK but the processor
 * inserts attempts only after the handler returns, so we never emit it
 * from this repository — the `webhook_events.processing_status` field
 * already captures the in-flight state.)
 */
export type WebhookProcessingAttemptOutcome =
  | 'success'
  | 'retryable_failure'
  | 'permanent_failure';

export type WebhookProcessingAttemptInsertInput = {
  webhookEventId: string;
  attemptNumber: number;
  workerId: string | null;
  startedAt: Date;
  finishedAt: Date;
  outcome: WebhookProcessingAttemptOutcome;
  errorCode: string | null;
  errorMessage: string | null;
};

export interface WebhookProcessingAttemptRepository {
  /**
   * Appends one row to the per-event attempt log. The
   * `(webhook_event_id, attempt_number)` UNIQUE constraint guarantees
   * the log is append-only and stays consistent with
   * `webhook_events.attempt_count`.
   */
  insert(sql: Sql, input: WebhookProcessingAttemptInsertInput): Promise<void>;
}

export class PgWebhookProcessingAttemptRepository
  implements WebhookProcessingAttemptRepository
{
  async insert(sql: Sql, input: WebhookProcessingAttemptInsertInput): Promise<void> {
    await sql.query(
      `INSERT INTO provider_webhook_processing_attempts (
         webhook_event_id, attempt_number, worker_id, started_at, finished_at,
         outcome, error_code, error_message
       )
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
      [
        input.webhookEventId,
        input.attemptNumber,
        input.workerId,
        input.startedAt,
        input.finishedAt,
        input.outcome,
        input.errorCode,
        input.errorMessage
      ]
    );
  }
}
