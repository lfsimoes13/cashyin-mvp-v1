import type { Sql } from '../../shared/db/sql.js';

/**
 * Mirrors the `client_webhook_delivery_status` enum from migration 0006.
 */
export type ClientWebhookDeliveryStatus =
  | 'pending'
  | 'in_progress'
  | 'delivered'
  | 'failed'
  | 'dead_letter';

export type ClientWebhookDeliveryInsertInput = {
  outboxEventId: string;
  clientId: string;
  eventId: string;
  eventType: string;
  targetUrl: string;
  payload: Record<string, unknown>;
  signature: string | null;
  /** Future moment at which the first delivery should be attempted. */
  nextAttemptAt: Date;
};

export type ClientWebhookDeliveryRecord = {
  id: string;
  outboxEventId: string;
  clientId: string;
  eventId: string;
  eventType: string;
  targetUrl: string;
  payload: Record<string, unknown>;
  signature: string | null;
  status: ClientWebhookDeliveryStatus;
  attemptCount: number;
  lastHttpStatus: number | null;
  lastResponseSnippet: string | null;
  lastError: string | null;
  nextAttemptAt: Date;
  deliveredAt: Date | null;
  /** Wall-clock just before the FIRST HTTP attempt; null until first attempt. */
  firstAttemptStartedAt: Date | null;
  /** Wall-clock when the first attempt returned (response or timeout). */
  firstAttemptFinishedAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
};

type ClientWebhookDeliveryRow = {
  id: string;
  outbox_event_id: string;
  client_id: string;
  event_id: string;
  event_type: string;
  target_url: string;
  payload: Record<string, unknown>;
  signature: string | null;
  status: ClientWebhookDeliveryStatus;
  attempt_count: number | string;
  last_http_status: number | null;
  last_response_snippet: string | null;
  last_error: string | null;
  next_attempt_at: Date;
  delivered_at: Date | null;
  first_attempt_started_at: Date | null;
  first_attempt_finished_at: Date | null;
  created_at: Date;
  updated_at: Date;
};

function mapRow(row: ClientWebhookDeliveryRow): ClientWebhookDeliveryRecord {
  return {
    id: row.id,
    outboxEventId: row.outbox_event_id,
    clientId: row.client_id,
    eventId: row.event_id,
    eventType: row.event_type,
    targetUrl: row.target_url,
    payload: row.payload,
    signature: row.signature,
    status: row.status,
    attemptCount: Number(row.attempt_count),
    lastHttpStatus: row.last_http_status,
    lastResponseSnippet: row.last_response_snippet,
    lastError: row.last_error,
    nextAttemptAt: row.next_attempt_at,
    deliveredAt: row.delivered_at,
    firstAttemptStartedAt: row.first_attempt_started_at,
    firstAttemptFinishedAt: row.first_attempt_finished_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}

export type ClientWebhookDeliveryAttemptUpdate = {
  id: string;
  status: ClientWebhookDeliveryStatus;
  attemptCount: number;
  httpStatus: number | null;
  responseSnippet: string | null;
  error: string | null;
  /** Wall-clock moment at which retry becomes eligible (only meaningful for `failed`). */
  nextAttemptAt: Date;
  deliveredAt: Date | null;
  /**
   * First-attempt latency timestamps. Written with COALESCE semantics so only
   * the FIRST attempt's instants ever stick; retries pass them again harmlessly.
   * Omit (or pass null) on retries — the persisted first-attempt values are
   * preserved. Internal observability only; never part of the public payload.
   */
  firstAttemptStartedAt?: Date | null;
  firstAttemptFinishedAt?: Date | null;
};

export interface ClientWebhookDeliveryRepository {
  /**
   * Upserts the per-outbox-event delivery row. The
   * `UNIQUE (outbox_event_id)` constraint guarantees one row per
   * source event — retries reuse the same row by id.
   */
  upsertForOutbox(
    sql: Sql,
    input: ClientWebhookDeliveryInsertInput
  ): Promise<ClientWebhookDeliveryRecord>;

  /** Loads the existing delivery row keyed by outbox event id, if any. */
  findByOutboxEvent(
    sql: Sql,
    outboxEventId: string
  ): Promise<ClientWebhookDeliveryRecord | null>;

  /**
   * Commits the result of a single delivery attempt. Used for every
   * terminal status (`delivered`, `failed`, `dead_letter`); `failed`
   * also writes the next `next_attempt_at`.
   */
  applyAttempt(sql: Sql, input: ClientWebhookDeliveryAttemptUpdate): Promise<void>;
}

const SELECT_COLUMNS = `
  id, outbox_event_id, client_id, event_id, event_type, target_url, payload,
  signature, status, attempt_count, last_http_status, last_response_snippet,
  last_error, next_attempt_at, delivered_at, first_attempt_started_at,
  first_attempt_finished_at, created_at, updated_at
` as const;

export class PgClientWebhookDeliveryRepository implements ClientWebhookDeliveryRepository {
  async upsertForOutbox(
    sql: Sql,
    input: ClientWebhookDeliveryInsertInput
  ): Promise<ClientWebhookDeliveryRecord> {
    // ON CONFLICT (outbox_event_id) refreshes the next-attempt timestamp
    // and keeps the row's identity stable, so the dispatcher can reuse
    // the same row across retries while still being able to recover
    // when it was inserted previously by an aborted run.
    const result = await sql.query<ClientWebhookDeliveryRow>(
      `INSERT INTO client_webhook_deliveries (
         outbox_event_id, client_id, event_id, event_type, target_url,
         payload, signature, next_attempt_at
       )
       VALUES ($1, $2, $3, $4, $5, $6::jsonb, $7, $8)
       ON CONFLICT (outbox_event_id) DO UPDATE
         SET target_url    = EXCLUDED.target_url,
             event_type    = EXCLUDED.event_type,
             event_id      = EXCLUDED.event_id,
             payload       = EXCLUDED.payload,
             signature     = EXCLUDED.signature,
             updated_at    = now()
       RETURNING ${SELECT_COLUMNS}`,
      [
        input.outboxEventId,
        input.clientId,
        input.eventId,
        input.eventType,
        input.targetUrl,
        JSON.stringify(input.payload),
        input.signature,
        input.nextAttemptAt
      ]
    );
    const row = result.rows[0];
    if (!row) {
      throw new Error('Failed to upsert client_webhook_deliveries row');
    }
    return mapRow(row);
  }

  async findByOutboxEvent(
    sql: Sql,
    outboxEventId: string
  ): Promise<ClientWebhookDeliveryRecord | null> {
    const result = await sql.query<ClientWebhookDeliveryRow>(
      `SELECT ${SELECT_COLUMNS}
         FROM client_webhook_deliveries
        WHERE outbox_event_id = $1`,
      [outboxEventId]
    );
    const row = result.rows[0];
    return row ? mapRow(row) : null;
  }

  async applyAttempt(sql: Sql, input: ClientWebhookDeliveryAttemptUpdate): Promise<void> {
    // first_attempt_* use COALESCE so the persisted values reflect the FIRST
    // attempt only — passing them again on a retry is a no-op. delivered_at
    // follows the same idempotent-once pattern.
    await sql.query(
      `UPDATE client_webhook_deliveries
          SET status                    = $2,
              attempt_count             = $3,
              last_http_status          = $4,
              last_response_snippet     = $5,
              last_error                = $6,
              next_attempt_at           = $7,
              delivered_at              = COALESCE(delivered_at, $8),
              first_attempt_started_at  = COALESCE(first_attempt_started_at, $9),
              first_attempt_finished_at = COALESCE(first_attempt_finished_at, $10),
              updated_at                = now()
        WHERE id = $1`,
      [
        input.id,
        input.status,
        input.attemptCount,
        input.httpStatus,
        input.responseSnippet,
        input.error,
        input.nextAttemptAt,
        input.deliveredAt,
        input.firstAttemptStartedAt ?? null,
        input.firstAttemptFinishedAt ?? null
      ]
    );
  }
}
