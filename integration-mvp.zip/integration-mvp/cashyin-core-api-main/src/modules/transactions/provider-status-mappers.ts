/**
 * Provider raw status → canonical CashYin domain status.
 *
 * This module belongs at the boundary between the provider adapter and
 * the domain services: provider adapters call into it when normalising
 * webhook events, and the canonical result is what flows into the state
 * machine and the public webhook envelope builders.
 *
 * The mapping intentionally returns a discriminated union including a
 * `kind: 'unknown'` branch rather than silently coercing unrecognised
 * provider statuses to `failed`. Silent coercion in financial systems
 * tends to hide real protocol drift, so the caller (Phase 5 processor)
 * is responsible for deciding the policy: route to DLQ, retry parsing,
 * page on-call, etc. Both branches carry the original raw status and the
 * normalised lookup key so audit and observability code can compare
 * what arrived against what was understood.
 *
 * See `docs/webhooks/transaction-status-refactor-plan.md` §7 and
 * `docs/provider-integration/provider-infra-webhook-architecture.md` §8.
 */

import type { CashInStatus, CashOutStatus } from './status.js';

const CASH_IN_RAW_TO_CANONICAL: Record<string, CashInStatus> = {
  PENDING: 'pending',
  CREATED: 'pending',
  RECEIVED: 'pending',
  PAID: 'paid',
  CONFIRMED: 'paid',
  SUCCESS: 'paid',
  EXPIRED: 'expired',
  CANCELLED: 'cancelled',
  CANCELED: 'cancelled',
  FAILED: 'failed',
  ERROR: 'failed',
  REJECTED: 'failed',
  REFUNDED: 'refunded',
  REVERSED: 'refunded',
  DEVOLVED: 'refunded'
};

const CASH_OUT_RAW_TO_CANONICAL: Record<string, CashOutStatus> = {
  PROCESSING: 'processing',
  PENDING: 'processing',
  SENT: 'processing',
  CONFIRMED: 'completed',
  PAID: 'completed',
  SUCCESS: 'completed',
  COMPLETED: 'completed',
  FAILED: 'failed',
  ERROR: 'failed',
  REJECTED: 'failed',
  CANCELLED: 'failed',
  CANCELED: 'failed',
  REFUNDED: 'returned',
  RETURNED: 'returned',
  DEVOLVED: 'returned'
};

export type ProviderCashInMappingResult =
  | { kind: 'mapped'; status: CashInStatus; rawStatus: string; normalisedKey: string }
  | { kind: 'unknown'; rawStatus: string; normalisedKey: string };

export type ProviderCashOutMappingResult =
  | { kind: 'mapped'; status: CashOutStatus; rawStatus: string; normalisedKey: string }
  | { kind: 'unknown'; rawStatus: string; normalisedKey: string };

export function mapProviderCashInStatus(rawStatus: string): ProviderCashInMappingResult {
  const normalisedKey = normaliseProviderStatusKey(rawStatus);
  const mapped = CASH_IN_RAW_TO_CANONICAL[normalisedKey];
  if (mapped !== undefined) {
    return { kind: 'mapped', status: mapped, rawStatus, normalisedKey };
  }
  return { kind: 'unknown', rawStatus, normalisedKey };
}

export function mapProviderCashOutStatus(rawStatus: string): ProviderCashOutMappingResult {
  const normalisedKey = normaliseProviderStatusKey(rawStatus);
  const mapped = CASH_OUT_RAW_TO_CANONICAL[normalisedKey];
  if (mapped !== undefined) {
    return { kind: 'mapped', status: mapped, rawStatus, normalisedKey };
  }
  return { kind: 'unknown', rawStatus, normalisedKey };
}

function normaliseProviderStatusKey(rawStatus: string): string {
  return rawStatus.trim().toUpperCase();
}
