/**
 * Pure state machine for canonical CashYin transaction transitions.
 *
 * Defines the allowed transitions per flow and exposes deterministic
 * predicates and result objects so that the caller (provider webhook
 * processor, reconciliation job, manual adjustment, etc.) can decide
 * whether to apply a state change, reject it, or audit it as an
 * idempotent no-op.
 *
 * The state machine deliberately does NOT throw on invalid transitions:
 * webhook retries from a provider may attempt to "move" an already-final
 * status, and the caller must be free to log/discard those without
 * raising errors that would bubble up to the HTTP layer.
 *
 * See `docs/webhooks/transaction-status-refactor-plan.md` §6.
 */

import type { CashInStatus, CashOutStatus } from './status.js';

const CASH_IN_ALLOWED: Record<CashInStatus, ReadonlySet<CashInStatus>> = {
  pending: new Set<CashInStatus>(['paid', 'expired', 'cancelled', 'failed']),
  paid: new Set<CashInStatus>(['refunded']),
  expired: new Set<CashInStatus>(),
  cancelled: new Set<CashInStatus>(),
  failed: new Set<CashInStatus>(),
  refunded: new Set<CashInStatus>()
};

const CASH_OUT_ALLOWED: Record<CashOutStatus, ReadonlySet<CashOutStatus>> = {
  processing: new Set<CashOutStatus>(['completed', 'failed', 'returned']),
  completed: new Set<CashOutStatus>(['returned']),
  failed: new Set<CashOutStatus>(),
  returned: new Set<CashOutStatus>()
};

export type TransitionInvalidReason = 'same_status' | 'transition_not_allowed';

export type TransitionResult<S extends string> =
  | { ok: true; from: S; to: S }
  | { ok: false; from: S; to: S; reason: TransitionInvalidReason };

export function canTransitionCashIn(from: CashInStatus, to: CashInStatus): boolean {
  if (from === to) return false;
  return CASH_IN_ALLOWED[from].has(to);
}

export function canTransitionCashOut(from: CashOutStatus, to: CashOutStatus): boolean {
  if (from === to) return false;
  return CASH_OUT_ALLOWED[from].has(to);
}

export function transitionCashIn(
  from: CashInStatus,
  to: CashInStatus
): TransitionResult<CashInStatus> {
  if (from === to) return { ok: false, from, to, reason: 'same_status' };
  if (CASH_IN_ALLOWED[from].has(to)) return { ok: true, from, to };
  return { ok: false, from, to, reason: 'transition_not_allowed' };
}

export function transitionCashOut(
  from: CashOutStatus,
  to: CashOutStatus
): TransitionResult<CashOutStatus> {
  if (from === to) return { ok: false, from, to, reason: 'same_status' };
  if (CASH_OUT_ALLOWED[from].has(to)) return { ok: true, from, to };
  return { ok: false, from, to, reason: 'transition_not_allowed' };
}

/**
 * Returns the full set of statuses that `from` may legally transition to.
 * Useful for tests, audit dashboards and policy review tooling.
 */
export function allowedNextCashInStatuses(from: CashInStatus): ReadonlySet<CashInStatus> {
  return CASH_IN_ALLOWED[from];
}

export function allowedNextCashOutStatuses(from: CashOutStatus): ReadonlySet<CashOutStatus> {
  return CASH_OUT_ALLOWED[from];
}
