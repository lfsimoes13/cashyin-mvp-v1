/**
 * Canonical CashYin transaction status types.
 *
 * Cash-In and Cash-Out have intentionally distinct status sets so the
 * domain cannot accidentally surface a Cash-Out-only status (e.g. `returned`)
 * on a Cash-In transaction or vice versa. Provider-specific names
 * (`confirmed`, `refunded`, `reversed`, `SUCCESS`, ...) must be converted
 * to one of these values inside the provider adapter layer before reaching
 * any domain service.
 *
 * See `docs/webhooks/transaction-status-refactor-plan.md` §4.
 */

export const CASH_IN_STATUSES = ['pending', 'paid', 'expired', 'cancelled', 'failed', 'refunded'] as const;
export type CashInStatus = (typeof CASH_IN_STATUSES)[number];

export const CASH_OUT_STATUSES = ['processing', 'completed', 'failed', 'returned'] as const;
export type CashOutStatus = (typeof CASH_OUT_STATUSES)[number];

export const TRANSACTION_TYPES = ['cash_in', 'cash_out'] as const;
export type TransactionType = (typeof TRANSACTION_TYPES)[number];

/**
 * Statuses from which no further transition is allowed in this phase.
 * Cash-In: `paid`, `expired`, `cancelled`, `failed`, `refunded`.
 * Cash-Out: `completed` (returnable, see state machine), `failed`, `returned`.
 *
 * `completed` is intentionally treated as terminal here but the state
 * machine still allows the documented `completed -> returned` transition
 * for post-success bank returns. The set is used by callers that need to
 * know "is this a happy/sad final state for display/listing purposes".
 */
export const TERMINAL_CASH_IN_STATUSES: ReadonlySet<CashInStatus> = new Set<CashInStatus>([
  'paid',
  'expired',
  'cancelled',
  'failed',
  'refunded'
]);

export const TERMINAL_CASH_OUT_STATUSES: ReadonlySet<CashOutStatus> = new Set<CashOutStatus>([
  'completed',
  'failed',
  'returned'
]);

export function isCashInStatus(value: unknown): value is CashInStatus {
  return typeof value === 'string' && (CASH_IN_STATUSES as readonly string[]).includes(value);
}

export function isCashOutStatus(value: unknown): value is CashOutStatus {
  return typeof value === 'string' && (CASH_OUT_STATUSES as readonly string[]).includes(value);
}

export function isTransactionType(value: unknown): value is TransactionType {
  return value === 'cash_in' || value === 'cash_out';
}

export function isTerminalCashInStatus(status: CashInStatus): boolean {
  return TERMINAL_CASH_IN_STATUSES.has(status);
}

export function isTerminalCashOutStatus(status: CashOutStatus): boolean {
  return TERMINAL_CASH_OUT_STATUSES.has(status);
}
