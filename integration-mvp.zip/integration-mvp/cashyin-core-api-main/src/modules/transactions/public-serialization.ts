/**
 * Single source of truth for the PUBLIC shape of Pix transactions.
 *
 * Every public surface — the REST responses (`POST`/`GET` cash-in and
 * cash-out) and the client webhook `data` blocks — is produced here, from a
 * normalized camelCase "source" object. Keeping one mapper per resource means
 * a future contract change (rename a field, nest another block, omit a value)
 * is a single edit that both REST and webhooks inherit automatically.
 *
 * Conventions:
 *   - Money is always integer cents (`amount`); never decimals or `_cents`.
 *   - Nullable identity blocks (`receiver`/`payer`) share one shape via
 *     {@link toPublicPixCounterparty}.
 *   - `null`/absent timestamps and optional ids are OMITTED, never emitted as
 *     `null`, so payloads stay lean and presence is meaningful.
 */

import type { CashOutStatus } from './status.js';

// ─── Shared Pix counterparty (receiver / payer) ──────────────────────────────

/** Normalized counterparty input (camelCase) mapped from any internal record. */
export type PublicCounterpartySource = {
  name: string | null;
  documentNumber: string | null;
  bank: string | null;
  ispb: string | null;
  branch: string | null;
  account: string | null;
  accountType: string | null;
};

/**
 * Public counterparty block, shared by the cash-out `receiver` and the
 * cash-in `payer`. Always emitted with nullable children when present.
 */
export type PublicPixCounterparty = {
  name: string | null;
  document_number: string | null;
  bank_name: string | null;
  bank_ispb: string | null;
  branch: string | null;
  account: string | null;
  account_type: string | null;
};

export function toPublicPixCounterparty(src: PublicCounterpartySource): PublicPixCounterparty {
  return {
    name: src.name,
    document_number: src.documentNumber,
    bank_name: src.bank,
    bank_ispb: src.ispb,
    branch: src.branch,
    account: src.account,
    account_type: src.accountType
  };
}

/** True when at least one counterparty field carries data. */
export function counterpartyHasData(src: PublicCounterpartySource): boolean {
  return (
    src.name !== null ||
    src.documentNumber !== null ||
    src.bank !== null ||
    src.ispb !== null ||
    src.branch !== null ||
    src.account !== null ||
    src.accountType !== null
  );
}

type TimeInput = Date | string | null | undefined;

/** ISO string, or `undefined` when the value is absent (so the key is omitted). */
function toIso(value: TimeInput): string | undefined {
  if (value === null || value === undefined) return undefined;
  return value instanceof Date ? value.toISOString() : value;
}

function toIsoRequired(value: Date | string): string {
  return value instanceof Date ? value.toISOString() : value;
}

// ─── Cash-out ────────────────────────────────────────────────────────────────

export type CashOutPublicSource = {
  id: string;
  externalRef: string | null;
  status: CashOutStatus;
  amountCents: number;
  pixKey: string;
  pixKeyType: string;
  e2eId: string | null;
  receiver: PublicCounterpartySource;
  createdAt: Date | string;
  completedAt?: TimeInput;
  failedAt?: TimeInput;
  returnedAt?: TimeInput;
  failureReason?: string | null;
};

export type PublicCashOutPix = {
  key: string;
  key_type: string;
  e2e_id?: string;
};

export type PublicCashOut = {
  id: string;
  external_ref: string | null;
  status: CashOutStatus;
  amount: number;
  currency: 'BRL';
  pix: PublicCashOutPix;
  receiver: PublicPixCounterparty;
  created_at: string;
  completed_at?: string;
  failed_at?: string;
  returned_at?: string;
  failure_reason?: string;
};

export function toPublicCashOut(src: CashOutPublicSource): PublicCashOut {
  const completedAt = toIso(src.completedAt);
  const failedAt = toIso(src.failedAt);
  const returnedAt = toIso(src.returnedAt);
  // `failure_reason` is only meaningful for transfers that did not settle.
  const isNonSuccessTerminal = src.status === 'failed' || src.status === 'returned';

  return {
    id: src.id,
    external_ref: src.externalRef,
    status: src.status,
    amount: src.amountCents,
    currency: 'BRL',
    pix: {
      key: src.pixKey,
      key_type: src.pixKeyType,
      ...(src.e2eId ? { e2e_id: src.e2eId } : {})
    },
    receiver: toPublicPixCounterparty(src.receiver),
    created_at: toIsoRequired(src.createdAt),
    ...(completedAt ? { completed_at: completedAt } : {}),
    ...(failedAt ? { failed_at: failedAt } : {}),
    ...(returnedAt ? { returned_at: returnedAt } : {}),
    ...(isNonSuccessTerminal && src.failureReason ? { failure_reason: src.failureReason } : {})
  };
}

// ─── Cash-in ─────────────────────────────────────────────────────────────────

export type CashInPublicSource = {
  txid: string;
  externalRef: string;
  status: string;
  amountCents: number;
  /** EMV "copia e cola" payload. */
  emv: string | null;
  expiresAt: TimeInput;
  e2eId: string | null;
  payer: PublicCounterpartySource | null;
  paidAt?: TimeInput;
  description: string | null;
  createdAt: Date | string;
};

export type PublicCashInPix = {
  emv: string | null;
  expires_at?: string;
  e2e_id?: string;
};

export type PublicCashIn = {
  txid: string;
  external_ref: string;
  amount: number;
  pix: PublicCashInPix;
  payer?: PublicPixCounterparty;
  status: string;
  description: string | null;
  paid_at?: string;
  created_at: string;
};

export function toPublicCashIn(src: CashInPublicSource): PublicCashIn {
  const expiresAt = toIso(src.expiresAt);
  const paidAt = toIso(src.paidAt);
  const includePayer = src.payer !== null && counterpartyHasData(src.payer);

  return {
    txid: src.txid,
    external_ref: src.externalRef,
    amount: src.amountCents,
    pix: {
      emv: src.emv,
      ...(expiresAt ? { expires_at: expiresAt } : {}),
      ...(src.e2eId ? { e2e_id: src.e2eId } : {})
    },
    ...(includePayer && src.payer ? { payer: toPublicPixCounterparty(src.payer) } : {}),
    status: src.status,
    description: src.description,
    ...(paidAt ? { paid_at: paidAt } : {}),
    created_at: toIsoRequired(src.createdAt)
  };
}
