/**
 * Deterministic builders for the public client webhook envelope.
 *
 * The `data` field of every cash-in/cash-out envelope is produced by the same
 * shared serializer that powers the REST responses
 * ({@link toPublicCashIn} / {@link toPublicCashOut} in
 * `public-serialization.ts`). This guarantees the webhook `data` is identical
 * to `POST`/`GET` bodies — clients reuse one parser for both, with no field
 * remapping.
 *
 * The builders are pure: they never read clocks, repositories or providers.
 * Callers supply the emission timestamp explicitly so retries reuse the same
 * envelope bit-for-bit (idempotency).
 */

import {
  type CashInEventName,
  type CashOutEventName,
  type DispatchableCashInStatus,
  eventNameForCashInStatus,
  eventNameForCashOutStatus
} from './public-events.js';
import {
  toPublicCashIn,
  toPublicCashOut,
  type PublicCashIn,
  type PublicCashOut,
  type PublicCounterpartySource
} from './public-serialization.js';
import type { CashOutStatus } from './status.js';

export const PUBLIC_WEBHOOK_SCHEMA_VERSION = '2026-06-01';
export const PUBLIC_WEBHOOK_CURRENCY = 'BRL';

export type PublicWebhookCurrency = typeof PUBLIC_WEBHOOK_CURRENCY;
export type PublicWebhookSchemaVersion = typeof PUBLIC_WEBHOOK_SCHEMA_VERSION;

// ─── Cash-in types ───────────────────────────────────────────────────────────

/**
 * Input for {@link buildCashInWebhookEnvelope}. Field names mirror the
 * normalized serializer source so callers pass values directly. The public
 * `data` shape (nested `pix`, optional `payer`, omitted nulls) is decided by
 * {@link toPublicCashIn}.
 */
export type BuildCashInEnvelopeInput = {
  /** Stable event identifier; must start with `evt_`. Reused across retries. */
  eventId: string;
  /** Pix `txid` — the canonical public identifier. */
  txid: string;
  /** Client-supplied reference from charge creation. */
  externalRef: string;
  status: DispatchableCashInStatus;
  /** Amount in BRL cents. */
  amount: number;
  /** Moment in UTC when the envelope is being emitted. */
  emittedAt: Date;
  createdAt: Date;
  /** EMV "copia e cola" payment string. */
  emv: string | null;
  description: string | null;
  expiresAt: Date | null;
  paidAt: Date | null;
  e2eId: string | null;
  payer: PublicCounterpartySource | null;
};

// ─── Cash-out types ───────────────────────────────────────────────────────────

export type CashOutTimestamps = {
  createdAt: Date;
  completedAt?: Date;
  failedAt?: Date;
  returnedAt?: Date;
};

export type CashOutCounterparty = {
  e2eId?: string;
};

/**
 * Receiver (payee) identity reported by the provider, synchronously or via
 * webhook. Every field is optional on input; the serializer normalises any
 * missing field to `null` in the always-present nested `receiver` object.
 */
export type CashOutReceiverInput = {
  name?: string | null;
  document?: string | null;
  bank?: string | null;
  ispb?: string | null;
  branch?: string | null;
  account?: string | null;
  accountType?: string | null;
};

export type BuildCashOutEnvelopeInput = {
  eventId: string;
  transactionId: string;
  /** Client-supplied reference. Optional on the public contract (may be null). */
  externalRef: string | null;
  status: CashOutStatus;
  /** Pix amount in BRL cents. Public contract exposes this as `amount`. */
  amount: number;
  /** Destination Pix key. Surfaced publicly under `pix.key`. */
  pixKey: string;
  /** Uppercase Pix key type echoed from the request (`CPF`/`CNPJ`/…). */
  pixKeyType: string;
  /** Receiver identity. Rendered as the always-present nested `receiver` object. */
  receiver?: CashOutReceiverInput;
  emittedAt: Date;
  timestamps: CashOutTimestamps;
  counterparty?: CashOutCounterparty;
  /**
   * Reason the transfer did not settle. Included in the public `data` only
   * for non-success terminal states (`failed`, `returned`).
   */
  failureReason?: string;
};

// ─── Envelope wrappers ────────────────────────────────────────────────────────

export type CashInEnvelope = {
  id: string;
  event: CashInEventName;
  schema_version: PublicWebhookSchemaVersion;
  timestamp: string;
  data: PublicCashIn;
};

export type CashOutEnvelope = {
  id: string;
  event: CashOutEventName;
  schema_version: PublicWebhookSchemaVersion;
  timestamp: string;
  data: PublicCashOut;
};

export type PublicWebhookEnvelope = CashInEnvelope | CashOutEnvelope;

// ─── Builders ─────────────────────────────────────────────────────────────────

export function buildCashInWebhookEnvelope(input: BuildCashInEnvelopeInput): CashInEnvelope {
  validateAmount(input.amount);
  validateEventId(input.eventId);
  validateNonEmpty('txid', input.txid);
  validateNonEmpty('externalRef', input.externalRef);

  const data = toPublicCashIn({
    txid: input.txid,
    externalRef: input.externalRef,
    status: input.status,
    amountCents: input.amount,
    emv: input.emv,
    expiresAt: input.expiresAt,
    e2eId: input.e2eId,
    payer: input.payer,
    paidAt: input.paidAt,
    description: input.description,
    createdAt: input.createdAt
  });

  return {
    id: input.eventId,
    event: eventNameForCashInStatus(input.status),
    schema_version: PUBLIC_WEBHOOK_SCHEMA_VERSION,
    timestamp: input.emittedAt.toISOString(),
    data
  };
}

export function buildCashOutWebhookEnvelope(input: BuildCashOutEnvelopeInput): CashOutEnvelope {
  validateAmount(input.amount);
  validateEventId(input.eventId);
  validateNonEmpty('transactionId', input.transactionId);
  validateNonEmpty('pixKey', input.pixKey);
  validateNonEmpty('pixKeyType', input.pixKeyType);

  const data = toPublicCashOut({
    id: input.transactionId,
    externalRef: input.externalRef,
    status: input.status,
    amountCents: input.amount,
    pixKey: input.pixKey,
    pixKeyType: input.pixKeyType,
    e2eId: input.counterparty?.e2eId ?? null,
    receiver: {
      name: input.receiver?.name ?? null,
      documentNumber: input.receiver?.document ?? null,
      bank: input.receiver?.bank ?? null,
      ispb: input.receiver?.ispb ?? null,
      branch: input.receiver?.branch ?? null,
      account: input.receiver?.account ?? null,
      accountType: input.receiver?.accountType ?? null
    },
    createdAt: input.timestamps.createdAt,
    completedAt: input.timestamps.completedAt,
    failedAt: input.timestamps.failedAt,
    returnedAt: input.timestamps.returnedAt,
    failureReason: input.failureReason ?? null
  });

  return {
    id: input.eventId,
    event: eventNameForCashOutStatus(input.status),
    schema_version: PUBLIC_WEBHOOK_SCHEMA_VERSION,
    timestamp: input.emittedAt.toISOString(),
    data
  };
}

/**
 * Formats an integer cents amount as a fixed-point decimal string.
 * No longer used by the public envelopes (which expose integer cents),
 * but retained as a reusable display helper for internal tooling.
 */
export function formatAmountFromCents(amountCents: number): string {
  validateAmount(amountCents);
  const integer = Math.floor(amountCents / 100);
  const cents = amountCents % 100;
  return `${integer}.${String(cents).padStart(2, '0')}`;
}

function validateAmount(amount: number): void {
  if (!Number.isInteger(amount)) {
    throw new TypeError(`amount must be a non-negative integer (got ${amount})`);
  }
  if (amount < 0) {
    throw new RangeError(`amount must be non-negative (got ${amount})`);
  }
}

function validateEventId(eventId: string): void {
  if (!eventId.startsWith('evt_') || eventId.length <= 'evt_'.length) {
    throw new TypeError(
      `eventId must start with "evt_" and carry a non-empty suffix (got "${eventId}")`
    );
  }
}

function validateNonEmpty(label: string, value: string): void {
  if (value.length === 0) {
    throw new TypeError(`${label} must be a non-empty string`);
  }
}
