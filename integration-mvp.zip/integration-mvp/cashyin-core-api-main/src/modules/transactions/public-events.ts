/**
 * Canonical public webhook event names used in payloads delivered to
 * CashYin clients. Internal/provider event names (e.g. Bents `charge.paid`)
 * are not part of this surface; they are mapped to one of these names by
 * the provider webhook adapter and the asynchronous processor.
 *
 * See `docs/webhooks/transaction-status-refactor-plan.md` §5.
 *
 * Note: `pix.cash_in.pending` is intentionally absent. The `pending` status
 * is internal — it represents a charge that was created but not yet paid.
 * Clients are NOT notified when a charge is created; they receive
 * notifications only for terminal or payment transitions.
 */

import type { CashInStatus, CashOutStatus, TransactionType } from './status.js';

/**
 * The subset of CashIn statuses that have a corresponding public webhook
 * event. `pending` is excluded because the pending state is not dispatched
 * to clients.
 */
export type DispatchableCashInStatus = Exclude<CashInStatus, 'pending'>;

export const CASH_IN_EVENT_NAMES = [
  'pix.cash_in.paid',
  'pix.cash_in.expired',
  'pix.cash_in.cancelled',
  'pix.cash_in.failed',
  'pix.cash_in.refunded'
] as const;
export type CashInEventName = (typeof CASH_IN_EVENT_NAMES)[number];

export const CASH_OUT_EVENT_NAMES = [
  'pix.cash_out.processing',
  'pix.cash_out.completed',
  'pix.cash_out.failed',
  'pix.cash_out.returned'
] as const;
export type CashOutEventName = (typeof CASH_OUT_EVENT_NAMES)[number];

export type PublicWebhookEventName = CashInEventName | CashOutEventName;

const CASH_IN_STATUS_TO_EVENT: Record<DispatchableCashInStatus, CashInEventName> = {
  paid: 'pix.cash_in.paid',
  expired: 'pix.cash_in.expired',
  cancelled: 'pix.cash_in.cancelled',
  failed: 'pix.cash_in.failed',
  refunded: 'pix.cash_in.refunded'
};

const CASH_OUT_STATUS_TO_EVENT: Record<CashOutStatus, CashOutEventName> = {
  processing: 'pix.cash_out.processing',
  completed: 'pix.cash_out.completed',
  failed: 'pix.cash_out.failed',
  returned: 'pix.cash_out.returned'
};

const EVENT_TO_CASH_IN_STATUS: Record<CashInEventName, DispatchableCashInStatus> = {
  'pix.cash_in.paid': 'paid',
  'pix.cash_in.expired': 'expired',
  'pix.cash_in.cancelled': 'cancelled',
  'pix.cash_in.failed': 'failed',
  'pix.cash_in.refunded': 'refunded'
};

const EVENT_TO_CASH_OUT_STATUS: Record<CashOutEventName, CashOutStatus> = {
  'pix.cash_out.processing': 'processing',
  'pix.cash_out.completed': 'completed',
  'pix.cash_out.failed': 'failed',
  'pix.cash_out.returned': 'returned'
};

export function eventNameForCashInStatus(status: DispatchableCashInStatus): CashInEventName {
  return CASH_IN_STATUS_TO_EVENT[status];
}

export function eventNameForCashOutStatus(status: CashOutStatus): CashOutEventName {
  return CASH_OUT_STATUS_TO_EVENT[status];
}

export function statusForCashInEvent(event: CashInEventName): DispatchableCashInStatus {
  return EVENT_TO_CASH_IN_STATUS[event];
}

export function statusForCashOutEvent(event: CashOutEventName): CashOutStatus {
  return EVENT_TO_CASH_OUT_STATUS[event];
}

/**
 * Type-safe overload that routes through the correct mapper based on
 * the transaction type. Useful when both flows are handled by the same
 * code path (e.g. a generic outbox writer).
 */
export function eventNameForStatus(
  type: 'cash_in',
  status: DispatchableCashInStatus
): CashInEventName;
export function eventNameForStatus(type: 'cash_out', status: CashOutStatus): CashOutEventName;
export function eventNameForStatus(
  type: TransactionType,
  status: DispatchableCashInStatus | CashOutStatus
): PublicWebhookEventName {
  if (type === 'cash_in') {
    return CASH_IN_STATUS_TO_EVENT[status as DispatchableCashInStatus];
  }
  return CASH_OUT_STATUS_TO_EVENT[status as CashOutStatus];
}

export function isCashInEventName(value: unknown): value is CashInEventName {
  return typeof value === 'string' && (CASH_IN_EVENT_NAMES as readonly string[]).includes(value);
}

export function isCashOutEventName(value: unknown): value is CashOutEventName {
  return typeof value === 'string' && (CASH_OUT_EVENT_NAMES as readonly string[]).includes(value);
}

export function isPublicWebhookEventName(value: unknown): value is PublicWebhookEventName {
  return isCashInEventName(value) || isCashOutEventName(value);
}
