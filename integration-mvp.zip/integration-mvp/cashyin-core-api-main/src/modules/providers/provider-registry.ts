import { BentsProvider } from '../../providers/bents/bents.provider.js';
import type { PaymentProvider } from '../../providers/contracts/payment-provider.js';
import type { ProviderName } from '../../providers/contracts/provider-types.js';
import { AppError } from '../../shared/errors/app-error.js';

export class ProviderRegistry {
  private readonly providers = new Map<ProviderName, PaymentProvider>();

  constructor(providers: PaymentProvider[] = [new BentsProvider()]) {
    for (const provider of providers) {
      this.providers.set(provider.name, provider);
    }
  }

  get(providerName: ProviderName): PaymentProvider {
    const provider = this.providers.get(providerName);
    if (!provider) {
      throw new AppError('provider_not_registered', `Provider ${providerName} is not registered`, 500);
    }
    return provider;
  }
}

export const providerRegistry = new ProviderRegistry();

