import type { Sql } from '../../shared/db/sql.js';
import type { OperationType, ProviderName } from '../../providers/contracts/provider-types.js';

export type ProviderAssignment = {
  id: string;
  clientId: string;
  operationType: OperationType;
  providerName: ProviderName;
  providerAccountId: string;
  weight: number;
  version: number;
};

type ProviderAssignmentRow = {
  id: string;
  client_id: string;
  operation_type: OperationType;
  provider_name: ProviderName;
  provider_account_id: string;
  weight: number;
  version: number;
};

export interface ProviderAssignmentRepository {
  findActive(
    sql: Sql,
    clientId: string,
    operationType: OperationType
  ): Promise<ProviderAssignment | null>;
}

export class PgProviderAssignmentRepository implements ProviderAssignmentRepository {
  async findActive(
    sql: Sql,
    clientId: string,
    operationType: OperationType
  ): Promise<ProviderAssignment | null> {
    const result = await sql.query<ProviderAssignmentRow>(
      `SELECT id, client_id, operation_type, provider_name, provider_account_id, weight, version
         FROM client_provider_assignments
        WHERE client_id = $1
          AND operation_type = $2
          AND status = 'active'
          AND valid_from <= now()
          AND (valid_to IS NULL OR valid_to > now())
        ORDER BY version DESC, valid_from DESC
        LIMIT 1`,
      [clientId, operationType]
    );
    const row = result.rows[0];
    if (!row) return null;
    return {
      id: row.id,
      clientId: row.client_id,
      operationType: row.operation_type,
      providerName: row.provider_name,
      providerAccountId: row.provider_account_id,
      weight: row.weight,
      version: row.version
    };
  }
}
