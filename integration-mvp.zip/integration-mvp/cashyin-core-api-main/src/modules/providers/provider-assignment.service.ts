import type { Sql } from '../../shared/db/sql.js';
import type { Database } from '../../shared/db/database.js';
import { AppError } from '../../shared/errors/app-error.js';
import type { OperationType } from '../../providers/contracts/provider-types.js';
import type {
  ProviderAssignment,
  ProviderAssignmentRepository
} from './provider-assignment.repository.js';

/**
 * Resolves the active provider assignment for a (client, operation) pair.
 *
 * Provider selection is owned by versioned `client_provider_assignments` rows.
 * Domain services must not branch on provider identity; they ask this service
 * for the canonical assignment and the provider registry for the adapter.
 */
export class ProviderAssignmentService {
  constructor(
    private readonly db: Database,
    private readonly repository: ProviderAssignmentRepository
  ) {}

  async requireActive(
    clientId: string,
    operationType: OperationType
  ): Promise<ProviderAssignment> {
    return this.requireActiveWith(this.db.pool, clientId, operationType);
  }

  async requireActiveWith(
    sql: Sql,
    clientId: string,
    operationType: OperationType
  ): Promise<ProviderAssignment> {
    const assignment = await this.repository.findActive(sql, clientId, operationType);
    if (!assignment) {
      throw new AppError(
        'provider_assignment_not_found',
        'No active provider assignment for this client and operation',
        422,
        { clientId, operationType }
      );
    }
    return assignment;
  }
}
