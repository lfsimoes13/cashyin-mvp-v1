import { z } from 'zod';
import { amountCentsSchema } from '../../shared/validation/money.js';
import { isValidPixKeyForType } from '../../shared/validation/pix.js';

/**
 * Public Pix key types accepted on the cash-out request. Uppercase per the
 * public contract; echoed back verbatim on responses and webhooks.
 */
export const PIX_KEY_TYPES = ['CPF', 'CNPJ', 'EMAIL', 'PHONE', 'EVP'] as const;
export type PixKeyType = (typeof PIX_KEY_TYPES)[number];

// Public cash-out request body (snake_case). `clientId` is resolved from the
// Bearer credential by the `requireClientAuth` preHandler — never from the
// body. `Idempotency-Key` is carried in the header, not here.
export const createCashoutBodySchema = z
  .object({
    external_ref: z.string().min(1).max(120).optional(),
    amount: amountCentsSchema,
    pix: z.object({
      key_type: z.enum(PIX_KEY_TYPES),
      key: z.string().min(3).max(140)
    }),
    receiver: z
      .object({
        name: z.string().min(1).max(140).optional(),
        // CPF (11 digits) or CNPJ (14 digits), digits only.
        document_number: z
          .string()
          .regex(
            /^\d{11}$|^\d{14}$/,
            'receiver.document_number must be a CPF (11 digits) or CNPJ (14 digits)'
          )
          .optional()
      })
      .optional(),
    description: z.string().max(140).optional()
  })
  // The destination key must be well-formed for its declared type (BACEN/DICT),
  // so a malformed key is rejected as a 422 before any reservation or provider
  // call — not surfaced later as an opaque provider error.
  .superRefine((body, ctx) => {
    if (!isValidPixKeyForType(body.pix.key_type, body.pix.key)) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['pix', 'key'],
        message: `pix.key is not a valid ${body.pix.key_type} key`
      });
    }
  });

export type CreateCashoutBody = z.infer<typeof createCashoutBodySchema>;

/**
 * Internal cash-out creation input. Field names stay in the established
 * internal camelCase shape; the public snake_case request is mapped onto it
 * by {@link toCreateCashoutInput} at the HTTP boundary.
 */
export type CreateCashoutInput = {
  clientId: string;
  externalRef: string | null;
  amountCents: number;
  pixKey: string;
  pixKeyType: PixKeyType;
  receiverName: string | null;
  receiverDocument: string | null;
  description?: string;
};

export function toCreateCashoutInput(body: CreateCashoutBody, clientId: string): CreateCashoutInput {
  return {
    clientId,
    externalRef: body.external_ref ?? null,
    amountCents: body.amount,
    pixKey: body.pix.key,
    pixKeyType: body.pix.key_type,
    receiverName: body.receiver?.name ?? null,
    receiverDocument: body.receiver?.document_number ?? null,
    ...(body.description !== undefined ? { description: body.description } : {})
  };
}
