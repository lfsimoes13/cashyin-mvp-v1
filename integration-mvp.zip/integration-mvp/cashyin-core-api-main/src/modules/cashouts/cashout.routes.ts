import type { FastifyInstance, FastifyRequest } from 'fastify';
import { AppError } from '../../shared/errors/app-error.js';
import { AUTH_SCOPES } from '../../shared/auth/auth-scopes.js';
import { stepUpRequiredError } from '../../shared/auth/auth-errors.js';
import type { AuthPreHandlers } from '../../modules/auth/auth-enforcement.js';
import { createCashoutBodySchema, toCreateCashoutInput } from './cashout.schemas.js';
import { type CashoutService, toPublicCashout } from './cashout.service.js';
import {
  canonicalCashoutHash,
  STEP_UP_PROOF_HEADER,
  type CashoutStepUpMode,
  type CashoutStepUpService
} from './cashout-step-up.js';

export type CashoutRoutesDeps = {
  cashoutService: CashoutService;
  auth: AuthPreHandlers;
  /**
   * Step-up enforcement for human-initiated (`frontend_bff`) cash-outs.
   * Staged by `CASHOUT_STEPUP_MODE`; `api_direct` machine cash-outs are
   * exempt. `off` makes the whole layer inert.
   */
  stepUp: {
    mode: CashoutStepUpMode;
    service: CashoutStepUpService;
  };
};

function headerString(request: FastifyRequest, name: string): string | undefined {
  const value = request.headers[name];
  return typeof value === 'string' && value.length > 0 ? value : undefined;
}

export async function registerCashoutRoutes(
  app: FastifyInstance,
  deps: CashoutRoutesDeps
): Promise<void> {
  app.post(
    '/v1/pix/cash-out',
    {
      preHandler: [
        deps.auth.authenticate,
        deps.auth.resolveAuthContext,
        deps.auth.requireScope(AUTH_SCOPES.PIX_CASH_OUT_CREATE)
      ]
    },
    async (request, reply) => {
      const parsed = createCashoutBodySchema.safeParse(request.body);
      if (!parsed.success) {
        throw new AppError(
          'validation_error',
          'Invalid cash-out payload',
          422,
          parsed.error.flatten()
        );
      }

      const idempotencyKey = request.headers['idempotency-key'];
      if (!idempotencyKey || Array.isArray(idempotencyKey)) {
        throw new AppError('idempotency_key_required', 'Idempotency-Key header is required', 400);
      }

      const client = request.client!;

      // Step-up: only human-initiated (frontend_bff) cash-outs are gated;
      // api_direct machine credentials are exempt. Consume the proof BEFORE
      // creating the cash-out so a proof is strictly single-use.
      if (deps.stepUp.mode !== 'off' && request.authPrincipal?.channel === 'frontend_bff') {
        const transactionHash = canonicalCashoutHash(client.clientId, parsed.data);
        const proofId = headerString(request, STEP_UP_PROOF_HEADER);
        if (deps.stepUp.mode === 'enforce') {
          if (!proofId) {
            throw stepUpRequiredError('missing');
          }
          const proof = await deps.stepUp.service.consume({
            proofId,
            clientId: client.clientId,
            transactionHash
          });
          if (!proof) {
            // Missing/expired/reused/wrong-operation are deliberately uniform.
            throw stepUpRequiredError('mismatch');
          }
        } else {
          const ok = proofId
            ? await deps.stepUp.service.peek({ proofId, clientId: client.clientId, transactionHash })
            : false;
          if (!ok) {
            request.log.warn(
              { authShadow: true, stepUp: 'cashout', actorUserId: request.authPrincipal.actorUserId },
              'cash-out would be denied: step-up proof missing or not bound to this operation'
            );
          }
        }
      }
      const { cashout, replayed } = await deps.cashoutService.createCashoutWithDisposition(
        toCreateCashoutInput(parsed.data, client.clientId),
        idempotencyKey
      );

      // HTTP status reflects RESOURCE lifecycle, never payment finality:
      //   - 201 Created when a new cash-out resource is created — whether the
      //     provider settled synchronously (`status: completed`) or only
      //     accepted it (`status: processing`).
      //   - 200 OK on idempotent replay / stale-lock recovery returning the
      //     existing resource.
      // Payment finality lives in the body `status` and in webhooks; clients
      // poll `GET /v1/pix/cash-out/:id` for the canonical current state.
      const body = toPublicCashout(cashout);
      if (replayed) {
        return reply.status(200).send(body);
      }
      reply.header('Location', `/v1/pix/cash-out/${body.id}`);
      return reply.status(201).send(body);
    }
  );

  /**
   * Lookup by cashout `id` — the UUID returned by `POST /v1/pix/cash-out`.
   *
   * Identifier semantics for cash-out:
   *   - `id`                 Internal UUID; the canonical public lookup key.
   *   - `external_ref`       Client-supplied reference (idempotency / their order id).
   *   - `provider_payment_id`Internal; the PSP's own transaction reference.
   *   - `e2e_id`             BACEN SPI settlement id; present only after completion.
   *
   * A cash-out does NOT have a Pix `txid`. The `txid` concept belongs
   * exclusively to cash-in (Pix QR code charges) per BACEN §3.3.2. Using
   * `:txid` as the route parameter here was a naming error that this
   * endpoint corrects.
   *
   * Scoped to the authenticated client — a cashout owned by another
   * tenant returns 404 (uniform with "row doesn't exist") so ownership
   * doesn't leak.
   */
  app.get(
    '/v1/pix/cash-out/:id',
    {
      preHandler: [
        deps.auth.authenticate,
        deps.auth.resolveAuthContext,
        deps.auth.requireScope(AUTH_SCOPES.PIX_CASH_OUT_READ)
      ]
    },
    async (request, reply) => {
      const params = request.params as { id: string };
      const client = request.client!;
      const cashout = await deps.cashoutService.getCashoutById(client.clientId, params.id);
      if (!cashout) {
        return reply.status(404).send({
          error: {
            code: 'cashout_not_found',
            message: `No cash-out found for id=${params.id}`,
            request_id: request.id
          }
        });
      }
      return toPublicCashout(cashout);
    }
  );

  /**
   * Mint a step-up proof for an intended cash-out. The trusted BFF calls this
   * AFTER completing the human's MFA challenge, passing the exact cash-out
   * parameters it is about to submit. The returned `proofId` is then presented
   * on `POST /v1/pix/cash-out` via the `X-CashYin-Step-Up-Proof` header.
   *
   * The proof is bound to the canonical hash of the supplied parameters, so it
   * only authorises that one operation. Registered regardless of mode (a no-op
   * for callers that never enable enforcement).
   */
  app.post(
    '/v1/pix/cash-out/step-up',
    {
      preHandler: [
        deps.auth.authenticate,
        deps.auth.resolveAuthContext,
        deps.auth.requireScope(AUTH_SCOPES.PIX_CASH_OUT_CREATE)
      ]
    },
    async (request, reply) => {
      const parsed = createCashoutBodySchema.safeParse(request.body);
      if (!parsed.success) {
        throw new AppError('validation_error', 'Invalid cash-out payload', 422, parsed.error.flatten());
      }
      const client = request.client!;
      const transactionHash = canonicalCashoutHash(client.clientId, parsed.data);
      const issued = await deps.stepUp.service.issue({
        clientId: client.clientId,
        actorUserId: request.authPrincipal?.actorUserId ?? null,
        transactionHash,
        amr: request.authContext?.amr ?? []
      });
      return reply.status(201).send({
        proof_id: issued.proofId,
        transaction_hash: issued.transactionHash,
        expires_at: issued.expiresAt
      });
    }
  );
}
