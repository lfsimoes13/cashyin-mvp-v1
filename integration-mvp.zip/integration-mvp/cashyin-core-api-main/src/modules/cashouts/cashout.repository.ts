import type { Sql } from '../../shared/db/sql.js';
import type { ProviderName } from '../../providers/contracts/provider-types.js';
import type { CashOutStatus } from '../transactions/status.js';
import type { PixKeyType } from './cashout.schemas.js';

/**
 * Statuses the asynchronous webhook processor may transition a cashout
 * to. `processing` is excluded because the only path into `processing`
 * is the original `createCashout` insert; webhook re-confirmations of
 * `processing` map to a no-op in the service layer.
 */
export type TerminalCashoutStatus = Exclude<CashOutStatus, 'processing'>;

/**
 * Persisted Cash-Out status. Identical to the canonical `CashOutStatus`
 * defined in `src/modules/transactions/status.ts`; aliased here so
 * repository consumers do not need to know about the canonical layer.
 */
export type CashoutStatus = CashOutStatus;

/**
 * Receiver (payee) identity persisted on `cashouts`. `name`/`document`
 * predate this contract (migration 0011); the remaining fields were added
 * by migration 0016 so the full provider-reported receiver block survives.
 * Every field is nullable: providers vary on what they emit and the value
 * may arrive synchronously on create or later via webhook.
 */
export type CashoutReceiverFields = {
  receiverName: string | null;
  receiverDocument: string | null;
  receiverBank: string | null;
  receiverIspb: string | null;
  receiverBranch: string | null;
  receiverAccount: string | null;
  receiverAccountType: string | null;
};

export type CashoutInsertInput = {
  clientId: string;
  providerName: ProviderName;
  providerAccountId: string;
  externalId: string | null;
  providerPaymentId: string | null;
  amountCents: number;
  pixKey: string;
  pixKeyType: PixKeyType;
  receiverName: string | null;
  receiverDocument: string | null;
  receiverBank: string | null;
  receiverIspb: string | null;
  receiverBranch: string | null;
  receiverAccount: string | null;
  receiverAccountType: string | null;
  status: CashoutStatus;
  e2eId: string | null;
  feeAmountCents: number;
  metadata: Record<string, unknown>;
};

export type CashoutRecord = {
  id: string;
  clientId: string;
  providerName: ProviderName;
  providerAccountId: string;
  externalId: string | null;
  providerPaymentId: string | null;
  amountCents: number;
  currency: 'BRL';
  pixKey: string;
  pixKeyType: PixKeyType;
  receiverName: string | null;
  receiverDocument: string | null;
  receiverBank: string | null;
  receiverIspb: string | null;
  receiverBranch: string | null;
  receiverAccount: string | null;
  receiverAccountType: string | null;
  status: CashoutStatus;
  e2eId: string | null;
  feeAmountCents: number;
  /**
   * Reason the transfer did not settle, captured from the provider on a
   * `failed`/`returned` transition. `null` while processing or once
   * completed. Surfaced on non-success public cash-out webhooks only.
   */
  failureReason: string | null;
  createdAt: Date;
  /**
   * Lifecycle timestamps capturing WHEN the cash-out reached each terminal
   * status. Set on the transition (or synchronously at create time when the
   * provider settles on the send call). `null` until/unless the status is
   * reached. Surfaced publicly as `completed_at` / `failed_at` / `returned_at`.
   */
  completedAt: Date | null;
  failedAt: Date | null;
  returnedAt: Date | null;
  updatedAt: Date;
};

type CashoutRow = {
  id: string;
  client_id: string;
  provider_name: ProviderName;
  provider_account_id: string;
  external_id: string | null;
  provider_payment_id: string | null;
  amount_cents: string;
  currency: 'BRL';
  pix_key: string;
  pix_key_type: PixKeyType;
  receiver_name: string | null;
  receiver_document: string | null;
  receiver_bank: string | null;
  receiver_ispb: string | null;
  receiver_branch: string | null;
  receiver_account: string | null;
  receiver_account_type: string | null;
  status: CashoutStatus;
  e2e_id: string | null;
  fee_amount_cents: string;
  failure_reason: string | null;
  completed_at: Date | null;
  failed_at: Date | null;
  returned_at: Date | null;
  created_at: Date;
  updated_at: Date;
};

/**
 * Canonical projection of every `cashouts` column, shared by all SELECT
 * and RETURNING clauses so the row shape can never drift between queries.
 */
const CASHOUT_COLUMNS = `id, client_id, provider_name, provider_account_id, external_id,
       provider_payment_id, amount_cents, currency, pix_key, pix_key_type,
       receiver_name, receiver_document, receiver_bank, receiver_ispb,
       receiver_branch, receiver_account, receiver_account_type,
       status, e2e_id, fee_amount_cents, failure_reason,
       completed_at, failed_at, returned_at, created_at, updated_at`;

function mapRow(row: CashoutRow): CashoutRecord {
  return {
    id: row.id,
    clientId: row.client_id,
    providerName: row.provider_name,
    providerAccountId: row.provider_account_id,
    externalId: row.external_id,
    providerPaymentId: row.provider_payment_id,
    amountCents: Number(row.amount_cents),
    currency: row.currency,
    pixKey: row.pix_key,
    pixKeyType: row.pix_key_type,
    receiverName: row.receiver_name,
    receiverDocument: row.receiver_document,
    receiverBank: row.receiver_bank,
    receiverIspb: row.receiver_ispb,
    receiverBranch: row.receiver_branch,
    receiverAccount: row.receiver_account,
    receiverAccountType: row.receiver_account_type,
    status: row.status,
    e2eId: row.e2e_id,
    feeAmountCents: Number(row.fee_amount_cents),
    failureReason: row.failure_reason,
    createdAt: row.created_at,
    completedAt: row.completed_at,
    failedAt: row.failed_at,
    returnedAt: row.returned_at,
    updatedAt: row.updated_at
  };
}

/**
 * Allowed transitions enforced at the SQL level by `markStatus`.
 * Mirrors `CASH_OUT_ALLOWED` in `transactions/state-machine.ts`. The
 * service layer also consults the canonical state machine before
 * calling into the repository, but enforcing the rules in the UPDATE
 * predicate guards against a concurrent worker that already advanced
 * the row.
 */
const ALLOWED_TRANSITIONS: Record<CashoutStatus, readonly CashoutStatus[]> = {
  processing: ['completed', 'failed', 'returned'],
  completed: ['returned'],
  failed: [],
  returned: []
};

export type MarkCashoutStatusResult =
  | { kind: 'updated'; record: CashoutRecord }
  | { kind: 'not_found' }
  | { kind: 'transition_not_allowed'; currentStatus: CashoutStatus };

export interface CashoutRepository {
  insert(sql: Sql, input: CashoutInsertInput): Promise<CashoutRecord>;
  findById(sql: Sql, id: string): Promise<CashoutRecord | null>;
  findByClientExternalId(
    sql: Sql,
    clientId: string,
    externalId: string
  ): Promise<CashoutRecord | null>;
  findByProviderPaymentId(
    sql: Sql,
    providerName: ProviderName,
    providerPaymentId: string
  ): Promise<CashoutRecord | null>;
  /**
   * Atomically transitions a cashout to `status` only when the current
   * row matches one of the canonical predecessors of `status`. Returns
   * an explicit discriminated union so callers can distinguish "already
   * in this terminal state" (no-op) from "row missing" (audit signal).
   */
  markStatus(
    sql: Sql,
    id: string,
    status: TerminalCashoutStatus,
    opts?: { failureReason?: string | null; occurredAt?: Date }
  ): Promise<MarkCashoutStatusResult>;
  /**
   * Fills the receiver columns and `e2e_id` from provider-reported values
   * using COALESCE semantics: an existing (request- or earlier-webhook-
   * supplied) value is never overwritten; a column that is currently `NULL`
   * is set to the provided value. This makes partial-then-complete receiver
   * delivery safe — a later webhook with more complete data fills the gaps
   * without clobbering what is already known. Returns the updated record, or
   * `null` when the row is missing. Idempotent — safe to call on webhook
   * retries.
   */
  applyProviderConfirmation(
    sql: Sql,
    id: string,
    confirmation: ProviderConfirmationPatch
  ): Promise<CashoutRecord | null>;
}

/**
 * Provider-reported fields a confirmation webhook may backfill. All fields
 * are optional/nullable; `null` and `undefined` both leave the existing
 * column untouched (COALESCE).
 */
export type ProviderConfirmationPatch = {
  receiverName?: string | null;
  receiverDocument?: string | null;
  receiverBank?: string | null;
  receiverIspb?: string | null;
  receiverBranch?: string | null;
  receiverAccount?: string | null;
  receiverAccountType?: string | null;
  e2eId?: string | null;
};

export class PgCashoutRepository implements CashoutRepository {
  async insert(sql: Sql, input: CashoutInsertInput): Promise<CashoutRecord> {
    // Stamp the matching lifecycle timestamp when the provider settles the
    // transfer synchronously on the create call (status already terminal).
    // `now()` is the transaction timestamp, so it is identical to the row's
    // `created_at` default — sync completion reports the same instant for
    // `created_at` and `completed_at`. A `processing` create leaves all
    // lifecycle timestamps NULL.
    //
    // `$16` (status) is referenced both as the `cashout_status` column value
    // and inside the timestamp CASE comparisons against text literals. Without
    // a cast Postgres deduces two conflicting types for the same parameter and
    // aborts with "inconsistent types deduced for parameter $16". Casting once
    // via `$16::text::cashout_status` pins the bind type to text, so every use
    // of `$16` agrees while the column still receives the enum.
    const result = await sql.query<CashoutRow>(
      `INSERT INTO cashouts
         (client_id, provider_name, provider_account_id, external_id, provider_payment_id,
          amount_cents, pix_key, pix_key_type, receiver_name, receiver_document,
          receiver_bank, receiver_ispb, receiver_branch, receiver_account, receiver_account_type,
          status, e2e_id, fee_amount_cents, metadata,
          completed_at, failed_at, returned_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15,
               $16::text::cashout_status, $17, $18, $19::jsonb,
               CASE WHEN $16 = 'completed' THEN now() END,
               CASE WHEN $16 = 'failed'    THEN now() END,
               CASE WHEN $16 = 'returned'  THEN now() END)
       RETURNING ${CASHOUT_COLUMNS}`,
      [
        input.clientId,
        input.providerName,
        input.providerAccountId,
        input.externalId,
        input.providerPaymentId,
        input.amountCents,
        input.pixKey,
        input.pixKeyType,
        input.receiverName,
        input.receiverDocument,
        input.receiverBank,
        input.receiverIspb,
        input.receiverBranch,
        input.receiverAccount,
        input.receiverAccountType,
        input.status,
        input.e2eId,
        input.feeAmountCents,
        JSON.stringify(input.metadata)
      ]
    );
    const row = result.rows[0];
    if (!row) {
      throw new Error('Failed to insert cashout row');
    }
    return mapRow(row);
  }

  async findById(sql: Sql, id: string): Promise<CashoutRecord | null> {
    const result = await sql.query<CashoutRow>(
      `SELECT ${CASHOUT_COLUMNS}
         FROM cashouts
        WHERE id = $1`,
      [id]
    );
    const row = result.rows[0];
    return row ? mapRow(row) : null;
  }

  async findByClientExternalId(
    sql: Sql,
    clientId: string,
    externalId: string
  ): Promise<CashoutRecord | null> {
    const result = await sql.query<CashoutRow>(
      `SELECT ${CASHOUT_COLUMNS}
         FROM cashouts
        WHERE client_id = $1 AND external_id = $2`,
      [clientId, externalId]
    );
    const row = result.rows[0];
    return row ? mapRow(row) : null;
  }

  async findByProviderPaymentId(
    sql: Sql,
    providerName: ProviderName,
    providerPaymentId: string
  ): Promise<CashoutRecord | null> {
    const result = await sql.query<CashoutRow>(
      `SELECT ${CASHOUT_COLUMNS}
         FROM cashouts
        WHERE provider_name = $1 AND provider_payment_id = $2`,
      [providerName, providerPaymentId]
    );
    const row = result.rows[0];
    return row ? mapRow(row) : null;
  }

  async markStatus(
    sql: Sql,
    id: string,
    status: TerminalCashoutStatus,
    opts?: { failureReason?: string | null; occurredAt?: Date }
  ): Promise<MarkCashoutStatusResult> {
    const allowedFrom = ALLOWED_PREDECESSORS[status];
    // The `status IN (...)` predicate enforces the state machine at the
    // SQL level: if a concurrent worker already moved the row past this
    // transition, the UPDATE matches zero rows and we fall into the
    // "transition_not_allowed" branch after a single follow-up read.
    //
    // `failure_reason` is overwritten on every transition: non-success
    // terminals carry the provider reason, success clears it to NULL.
    //
    // The matching lifecycle timestamp is stamped from the provider's
    // `occurredAt` (falling back to `now()`), and COALESCE'd so a replayed
    // webhook never moves an already-recorded terminal timestamp.
    //
    // `$2` (status) is both assigned to the `cashout_status` column and
    // compared against text literals in the CASE branches. As with the insert,
    // the `$2::text::cashout_status` cast keeps the bind type single (text) and
    // avoids the "inconsistent types deduced" parameter error.
    const result = await sql.query<CashoutRow>(
      `UPDATE cashouts
          SET status         = $2::text::cashout_status,
              failure_reason = $4,
              completed_at   = CASE WHEN $2 = 'completed' THEN COALESCE(completed_at, $5) ELSE completed_at END,
              failed_at      = CASE WHEN $2 = 'failed'    THEN COALESCE(failed_at, $5)    ELSE failed_at END,
              returned_at    = CASE WHEN $2 = 'returned'  THEN COALESCE(returned_at, $5)  ELSE returned_at END,
              updated_at     = now()
        WHERE id = $1 AND status = ANY($3::cashout_status[])
       RETURNING ${CASHOUT_COLUMNS}`,
      [id, status, allowedFrom, opts?.failureReason ?? null, opts?.occurredAt ?? new Date()]
    );
    const row = result.rows[0];
    if (row) {
      return { kind: 'updated', record: mapRow(row) };
    }
    const current = await this.findById(sql, id);
    if (!current) return { kind: 'not_found' };
    return { kind: 'transition_not_allowed', currentStatus: current.status };
  }

  async applyProviderConfirmation(
    sql: Sql,
    id: string,
    confirmation: ProviderConfirmationPatch
  ): Promise<CashoutRecord | null> {
    const result = await sql.query<CashoutRow>(
      `UPDATE cashouts
          SET receiver_name         = COALESCE(receiver_name, $2),
              receiver_document     = COALESCE(receiver_document, $3),
              receiver_bank         = COALESCE(receiver_bank, $4),
              receiver_ispb         = COALESCE(receiver_ispb, $5),
              receiver_branch       = COALESCE(receiver_branch, $6),
              receiver_account      = COALESCE(receiver_account, $7),
              receiver_account_type = COALESCE(receiver_account_type, $8),
              e2e_id                = COALESCE(e2e_id, $9),
              updated_at            = now()
        WHERE id = $1
       RETURNING ${CASHOUT_COLUMNS}`,
      [
        id,
        confirmation.receiverName ?? null,
        confirmation.receiverDocument ?? null,
        confirmation.receiverBank ?? null,
        confirmation.receiverIspb ?? null,
        confirmation.receiverBranch ?? null,
        confirmation.receiverAccount ?? null,
        confirmation.receiverAccountType ?? null,
        confirmation.e2eId ?? null
      ]
    );
    const row = result.rows[0];
    return row ? mapRow(row) : null;
  }
}

/**
 * Inverted view of {@link ALLOWED_TRANSITIONS}: for each target status,
 * the list of statuses we accept transitioning from. Used by the SQL
 * `status = ANY(...)` predicate in `markStatus`.
 */
const ALLOWED_PREDECESSORS: Record<TerminalCashoutStatus, readonly CashoutStatus[]> = {
  completed: collectPredecessors('completed'),
  failed: collectPredecessors('failed'),
  returned: collectPredecessors('returned')
};

function collectPredecessors(target: CashoutStatus): readonly CashoutStatus[] {
  const sources: CashoutStatus[] = [];
  for (const [from, tos] of Object.entries(ALLOWED_TRANSITIONS) as Array<
    [CashoutStatus, readonly CashoutStatus[]]
  >) {
    if (tos.includes(target)) sources.push(from);
  }
  return sources;
}
