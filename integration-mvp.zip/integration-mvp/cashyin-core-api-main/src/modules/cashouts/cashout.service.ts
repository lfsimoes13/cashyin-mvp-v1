import type { Database } from '../../shared/db/database.js';
import type { Sql } from '../../shared/db/sql.js';
import { AppError } from '../../shared/errors/app-error.js';
import { ProviderError } from '../../providers/contracts/provider-errors.js';
import type {
  ProviderPixPayment,
  ProviderPixPaymentRequest
} from '../../providers/contracts/provider-types.js';
import { hashRequest } from '../idempotency/idempotency.hash.js';
import type { ClientBalanceService } from '../balances/client-balance.service.js';
import type { IdempotencyService } from '../idempotency/idempotency.service.js';
import type { LiquidityService } from '../liquidity/liquidity.service.js';
import type { OutboxService } from '../outbox/outbox.service.js';
import type { PricingService } from '../pricing/pricing.service.js';
import type { CashoutPricingAssessment } from '../pricing/pricing.service.js';
import type { FeeAssessmentRecord } from '../pricing/fee-assessment.repository.js';
import type { ProviderAssignmentService } from '../providers/provider-assignment.service.js';
import type { ProviderRegistry } from '../providers/provider-registry.js';
import type { ProviderName } from '../../providers/contracts/provider-types.js';
import type { LedgerService } from '../ledger/ledger.service.js';
import type { CashOutStatus } from '../transactions/status.js';
import { toPublicCashOut, type PublicCashOut } from '../transactions/public-serialization.js';
import type {
  CashoutRecord,
  CashoutRepository,
  TerminalCashoutStatus
} from './cashout.repository.js';
import type { CreateCashoutInput, PixKeyType } from './cashout.schemas.js';

export type CashoutServiceDeps = {
  db: Database;
  idempotency: IdempotencyService;
  providerAssignment: ProviderAssignmentService;
  providerRegistry: ProviderRegistry;
  cashoutRepository: CashoutRepository;
  liquidity: LiquidityService;
  outbox: OutboxService;
  /**
   * Optional pricing integration. When provided, `createCashout` resolves
   * pricing/provider-cost rules before reserving liquidity and persists a
   * `fee_assessment` row in the same transaction as the cash-out row. When
   * omitted (or when {@link PricingService.assessForCashout} returns `null`),
   * the service behaves exactly like Phase 2: no pricing lookup, no extra
   * persistence, response keeps `clientFeeCents`/`providerCostCents`/
   * `totalDebitAmountCents` at `0` for backwards compatibility.
   */
  pricing?: PricingService;
  /**
   * Optional ledger integration (Phase 8). When provided AND the cash-out
   * has a persisted `fee_assessment`, `handleCashoutStatusUpdate` posts
   * the balanced double-entry batch for `completed` and the principal
   * reversal pair for `completed → returned` inside the same transaction
   * that promotes the assessment status. Omitted in non-financial
   * deployments and in unit tests that focus on status transitions alone.
   */
  ledger?: LedgerService;
  /**
   * Optional ledger-balance check. When provided, `createCashout`
   * compares `client_liability[client]` against the total amount that
   * will eventually debit the client (`amountCents + clientFeeCents`,
   * where the fee is read from the pricing assessment for this request).
   * Insufficient balance is rejected with HTTP 422 `insufficient_funds`
   * before liquidity is reserved and BEFORE the provider is called —
   * the provider never sees requests we can't honour contractually.
   *
   * Omitted in unit tests that exercise the cash-out state machine
   * without the ledger, and in non-financial deployments. Keeping it
   * optional preserves the test surface that pre-dates the balance
   * check.
   */
  balances?: ClientBalanceService;
  log?: ReconciliationLogger;
};

export type CreateCashoutResponse = {
  id: string;
  clientId: string;
  externalRef: string | null;
  amountCents: number;
  currency: 'BRL';
  pixKey: string;
  pixKeyType: PixKeyType;
  receiverName: string | null;
  receiverDocument: string | null;
  receiverBank: string | null;
  receiverIspb: string | null;
  receiverBranch: string | null;
  receiverAccount: string | null;
  receiverAccountType: string | null;
  status: CashoutRecord['status'];
  provider: CashoutRecord['providerName'];
  providerPaymentId: string | null;
  e2eId: string | null;
  /**
   * Provider-reported fee, as returned in `ProviderPixPayment.feeAmountCents`.
   * This is whatever the provider says it charged for the operation and
   * remains in the response for backward compatibility. The CashYin
   * commercial fee charged to the client is `clientFeeCents`, computed
   * from the pricing engine.
   */
  feeAmountCents: number;
  /**
   * CashYin commercial fee charged to the client (in cents). `0` when no
   * pricing rule is configured for this client+operation.
   */
  clientFeeCents: number;
  /**
   * Provider's expected cost charged to CashYin (in cents). `0` when no
   * provider cost rule is configured for the provider account+operation.
   */
  providerCostCents: number;
  /**
   * `clientFeeCents - providerCostCents`. Signed: negative means CashYin
   * is subsidising this transaction. `0` when pricing is not configured.
   */
  marginCents: number;
  /**
   * Total amount the client is expected to pay out (`amountCents +
   * clientFeeCents` when `billingMode === 'add_to_debit'`). Mirrors
   * `amountCents` when no pricing rule applies.
   */
  totalDebitAmountCents: number;
  /**
   * Identifier of the persisted `fee_assessments` row, when one was created.
   */
  feeAssessmentId: string | null;
  reservationId: string | null;
  createdAt: string;
  /**
   * Lifecycle timestamps (ISO-8601) marking when the cash-out reached each
   * terminal status; `null` until/unless reached. Surfaced publicly as
   * `completed_at` / `failed_at` / `returned_at`.
   */
  completedAt: string | null;
  failedAt: string | null;
  returnedAt: string | null;
};

/**
 * Projects the internal {@link CreateCashoutResponse} onto the public
 * contract via the shared serializer ({@link toPublicCashOut}). This is the
 * single boundary where internal cash-out state is narrowed for clients; the
 * rich internal object is still used for outbox payloads and idempotency
 * bookkeeping.
 *
 * Receiver identity is emitted only as the canonical nested `receiver` object;
 * `e2e_id` lives under `pix`; null lifecycle timestamps are omitted.
 */
export function toPublicCashout(internal: CreateCashoutResponse): PublicCashOut {
  return toPublicCashOut({
    id: internal.id,
    externalRef: internal.externalRef,
    status: internal.status,
    amountCents: internal.amountCents,
    pixKey: internal.pixKey,
    pixKeyType: internal.pixKeyType,
    e2eId: internal.e2eId,
    receiver: {
      name: internal.receiverName,
      documentNumber: internal.receiverDocument,
      bank: internal.receiverBank,
      ispb: internal.receiverIspb,
      branch: internal.receiverBranch,
      account: internal.receiverAccount,
      accountType: internal.receiverAccountType
    },
    createdAt: internal.createdAt,
    completedAt: internal.completedAt,
    failedAt: internal.failedAt,
    returnedAt: internal.returnedAt
  });
}

export type CashoutStatusUpdateEvent = {
  providerName: ProviderName;
  providerPaymentId: string;
  status: TerminalCashoutStatus;
  occurredAt: Date;
  /**
   * Provider-reported reason a transfer did not settle. Persisted on
   * `failed`/`returned` transitions and surfaced on the public webhook;
   * ignored for `completed`.
   */
  failureReason?: string | null;
  /**
   * Receiver identity reported by the provider in the confirmation
   * webhook (e.g. Bents `data.receiver.*`). Applied with COALESCE
   * semantics: only fills a `cashouts` receiver column when the row does
   * not already carry a value (a request- or earlier-webhook-supplied
   * value is never overwritten). The document is persisted exactly as the
   * provider sends it — already masked — so the public surface never
   * exposes a full CPF/CNPJ.
   */
  receiverName?: string | null;
  receiverDocument?: string | null;
  receiverBank?: string | null;
  receiverIspb?: string | null;
  receiverBranch?: string | null;
  receiverAccount?: string | null;
  receiverAccountType?: string | null;
  /**
   * End-to-end (BACEN SPI) settlement id reported by an asynchronous
   * provider on the confirmation webhook. Backfilled with COALESCE so a
   * value already captured at create time is never overwritten.
   */
  e2eId?: string | null;
};

export type CashoutFinancialEffect = {
  /**
   * `cash_out_completed`  → primary posting on terminal success.
   * `cash_out_returned`   → full reversal (principal + fee) on chargeback.
   * `none`                → no money moved (failed / processing→returned).
   */
  ledger: 'cash_out_completed' | 'cash_out_returned' | 'none';
  ledgerEntriesPosted: number;
  /**
   * `consumed`  → reservation was settled (money left the provider).
   * `released`  → reservation was released back to operational pool.
   * `not_found` → no `reserved` reservation matched the cash-out (already
   *               settled by a previous webhook, or never created).
   */
  reservation: 'consumed' | 'released' | 'not_found';
  /**
   * `posted` → assessment moved from `estimated` to `posted` (or was
   *            already posted on a duplicate webhook).
   * `cancelled` → assessment moved from `estimated` to `cancelled`.
   * `none`    → no `fee_assessment` row exists for this cash-out.
   */
  /**
   * `posted`   → fee was debited and is retained (normal completion).
   * `reversed` → fee was refunded to the client (completed → returned).
   * `cancelled` → assessment existed as `estimated` and was voided (failed / pre-completion returned).
   * `none`     → no assessment existed.
   */
  feeAssessment: 'posted' | 'reversed' | 'cancelled' | 'none';
  feeAssessmentId: string | null;
};

export type CashoutStatusUpdateResult =
  | {
      status: 'updated';
      cashoutId: string;
      previousStatus: CashOutStatus;
      newStatus: TerminalCashoutStatus;
      financial: CashoutFinancialEffect;
    }
  | {
      status: 'noop';
      reason: 'cashout_not_found';
    }
  | {
      status: 'noop';
      reason: 'already_in_status';
      cashoutId: string;
    }
  | {
      status: 'noop';
      reason: 'invalid_transition';
      cashoutId: string;
      fromStatus: CashOutStatus;
      toStatus: TerminalCashoutStatus;
    };

export type ReconciliationLogger = (event: ReconciliationEvent) => void;

export type ReconciliationEvent = {
  code: string;
  operationType: 'cash_out';
  recordId: string;
  clientId: string;
  externalRef: string | null;
  reservationId: string | null;
  reason: string;
  cause: string;
  providerState: string;
};

/**
 * @see {@link PaymentService} for the full rationale on the ProviderState
 * machine. The same reasoning applies here, with the additional caveat that
 * liquidity reservations behave like idempotency locks: they may only be
 * released when we are certain the provider did NOT side-effect.
 */
type ProviderState =
  | { kind: 'not_started' }
  | { kind: 'in_flight' }
  | { kind: 'settled_success' }
  | { kind: 'settled_definite_failure'; error: ProviderError }
  | { kind: 'ambiguous'; error: Error };

/**
 * Orchestrates cash-out initiation:
 *
 * 1. Acquire idempotency lock for `(clientId, key, cash_out)`.
 * 2. On stale-lock takeover, probe the local `cashouts` table; without a
 *    local row we cannot prove the provider did not already send the Pix and
 *    must refuse with a reconciliation conflict.
 * 3. Resolve the active provider assignment for cash-out.
 * 4. Reserve provider liquidity inside a dedicated transaction so a failure
 *    after the provider call still has a durable reservation row that can be
 *    released by reconciliation. Liquidity must be held before any outbound
 *    network call to avoid double-spending operational money.
 * 5. Initiate the provider payment outside any DB transaction.
 * 6. Persist the cash-out row, attach it to the reservation, enqueue the
 *    outbox event, and finalise the idempotency response in a single tx.
 * 7. On error, only release locks/reservations when the provider state proves
 *    the provider did not side-effect; otherwise emit a reconciliation
 *    signal and retain everything for human/cron resolution.
 *
 * Ledger posting for cash-out (debit client liability, credit provider
 * clearing) is implemented in roadmap phase 4 when webhook-driven transitions
 * go live.
 */
export class CashoutService {
  constructor(private readonly deps: CashoutServiceDeps) {}

  /**
   * Thin wrapper preserving the original return shape for existing callers
   * (unit tests, internal use). HTTP callers that need to distinguish a
   * freshly-created resource (`201`) from an idempotent replay (`200`)
   * should use {@link createCashoutWithDisposition}.
   */
  async createCashout(
    input: CreateCashoutInput,
    idempotencyKey: string
  ): Promise<CreateCashoutResponse> {
    const { cashout } = await this.createCashoutWithDisposition(input, idempotencyKey);
    return cashout;
  }

  /**
   * Same orchestration as {@link createCashout}, additionally reporting
   * whether the returned resource was newly created (`replayed === false`)
   * or served from an idempotent replay / stale-lock recovery
   * (`replayed === true`). The route maps this to `201 Created` vs
   * `200 OK` — payment finality is never encoded in the HTTP status, only
   * in the body `status` and webhooks.
   */
  async createCashoutWithDisposition(
    input: CreateCashoutInput,
    idempotencyKey: string
  ): Promise<{ cashout: CreateCashoutResponse; replayed: boolean }> {
    const requestHash = hashRequest({
      route: 'POST /v1/pix/cash-out',
      body: input
    });

    const acquired = await this.deps.idempotency.acquire({
      clientId: input.clientId,
      key: idempotencyKey,
      operationType: 'cash_out',
      requestHash,
      lockTtlMs: this.deps.idempotency.defaultLockTtlMs
    });

    if (acquired.kind === 'replay') {
      return { cashout: acquired.response as CreateCashoutResponse, replayed: true };
    }

    const recordId = acquired.recordId;

    if (acquired.wasStale) {
      const recovered = await this.recoverFromStaleLock(input, recordId, idempotencyKey);
      return { cashout: recovered, replayed: true };
    }

    let providerState: ProviderState = { kind: 'not_started' };
    let reservationId: string | null = null;

    try {
      const assignment = await this.deps.providerAssignment.requireActive(
        input.clientId,
        'cash_out'
      );
      const provider = this.deps.providerRegistry.get(assignment.providerName);

      // Pricing assessment runs OUTSIDE any DB transaction so we can reject
      // policy-violating requests (e.g. unauthorised negative margin, daily
      // subsidy cap exceeded) before reserving any liquidity or touching
      // the provider. The pool-level executor is fine here: we are only
      // reading current rules and last-known subsidy aggregates.
      const assessment = this.deps.pricing
        ? await this.deps.pricing.assessForCashout(this.deps.db.pool, {
            clientId: input.clientId,
            providerAccountId: assignment.providerAccountId,
            amountCents: input.amountCents
          })
        : null;

      if (assessment && assessment.policyDecision.kind === 'rejected') {
        throw new AppError(
          assessment.policyDecision.code,
          assessment.policyDecision.reason,
          422,
          {
            clientId: input.clientId,
            externalRef: input.externalRef,
            subsidyCents: assessment.policyDecision.subsidyCents,
            dailySubsidyTotalBeforeCents:
              assessment.policyDecision.dailySubsidyTotalBeforeCents,
            monthlySubsidyTotalBeforeCents:
              assessment.policyDecision.monthlySubsidyTotalBeforeCents
          }
        );
      }

      const expectedProviderCost = assessment?.providerCostCents ?? 0;
      const chargedFromBalance =
        assessment?.providerCostRuleSnapshot.chargedFromProviderBalance ?? false;
      const liquidityCostComponent = chargedFromBalance ? expectedProviderCost : 0;
      const clientFeeCents = assessment?.clientFeeCents ?? 0;
      const totalDebitCents = input.amountCents + clientFeeCents;

      // Ledger balance check (multi-tenant safety). Confirms the client
      // has the funds in `client_liability` BEFORE we reserve liquidity
      // or call the provider. The check is opportunistic: it can only
      // happen if a balance service was wired (production wires one;
      // some test setups don't). We deliberately do the read AFTER the
      // pricing assessment so the rejection reflects the realised
      // `clientFee`, not a stale 0.
      //
      // Race note: this is a snapshot read against the connection pool,
      // not inside the reservation transaction. Two concurrent cash-out
      // requests for the same client could both pass the check and
      // then race to reserve. We accept the race because:
      //   1. Liquidity reservation is the operational hold, not the
      //      ledger debit. The ledger entry only lands on `completed`.
      //   2. A subsequent `reserveForCashout` for the same pool would
      //      also race today. Adding row-level locking on
      //      `client_liability` is tracked as a follow-up alongside the
      //      `client_provider_quotas` work.
      //   3. The check still prevents the dominant failure mode:
      //      single-tenant request with manifestly insufficient ledger
      //      balance.
      if (this.deps.balances) {
        const availableCents = await this.deps.balances.getAvailableCents(input.clientId);
        if (availableCents < totalDebitCents) {
          throw new AppError(
            'insufficient_funds',
            'Client ledger balance is below the required total debit for this cash-out',
            422,
            {
              clientId: input.clientId,
              externalRef: input.externalRef,
              requiredCents: totalDebitCents,
              availableCents,
              amountCents: input.amountCents,
              clientFeeCents,
              currency: 'BRL'
            }
          );
        }
      }

      const reservation = await this.deps.db.withTransaction(async (tx) =>
        this.deps.liquidity.reserveForCashout(tx, {
          clientId: input.clientId,
          providerAccountId: assignment.providerAccountId,
          cashoutId: null,
          principalAmountCents: input.amountCents,
          expectedProviderCostCents: liquidityCostComponent
        })
      );
      reservationId = reservation.id;

      const providerRequest: ProviderPixPaymentRequest = {
        idempotencyKey,
        clientId: input.clientId,
        // `external_ref` is optional on the public contract; fall back to the
        // idempotency key so the provider always receives a stable reference.
        externalId: input.externalRef ?? idempotencyKey,
        amountCents: input.amountCents,
        pixKey: input.pixKey,
        pixKeyType: input.pixKeyType,
        ...(input.receiverName !== null ? { receiverName: input.receiverName } : {}),
        ...(input.receiverDocument !== null ? { receiverDocument: input.receiverDocument } : {}),
        ...(input.description !== undefined ? { description: input.description } : {})
      };

      providerState = { kind: 'in_flight' };
      let providerResult: ProviderPixPayment;
      try {
        providerResult = await provider.createPixPayment(providerRequest);
        providerState = { kind: 'settled_success' };
      } catch (callError) {
        providerState = classifyProviderCallError(callError);
        throw callError;
      }

      const response = await this.deps.db.withTransaction(async (tx) => {
        // The provider adapter already produces a canonical `CashOutStatus`
        // (`processing|completed|failed|returned`), so the value flows
        // straight into the persisted column with no extra mapping step.
        // Receiver precedence: a request-supplied name/document wins; the
        // synchronous provider response fills any gap (and is the only
        // source for bank/ispb/branch/account/account_type, which the
        // request never carries). Asynchronous providers leave these NULL
        // here and backfill them later via the confirmation webhook.
        const providerReceiver = providerResult.receiver;
        const cashout = await this.deps.cashoutRepository.insert(tx, {
          clientId: input.clientId,
          providerName: assignment.providerName,
          providerAccountId: assignment.providerAccountId,
          externalId: input.externalRef,
          providerPaymentId: providerResult.providerPaymentId,
          amountCents: input.amountCents,
          pixKey: input.pixKey,
          pixKeyType: input.pixKeyType,
          receiverName: input.receiverName ?? providerReceiver?.name ?? null,
          receiverDocument: input.receiverDocument ?? providerReceiver?.document ?? null,
          receiverBank: providerReceiver?.bank ?? null,
          receiverIspb: providerReceiver?.ispb ?? null,
          receiverBranch: providerReceiver?.branch ?? null,
          receiverAccount: providerReceiver?.account ?? null,
          receiverAccountType: providerReceiver?.accountType ?? null,
          status: providerResult.status,
          e2eId: providerResult.e2eId ?? null,
          feeAmountCents: providerResult.feeAmountCents ?? 0,
          metadata: {}
        });

        await this.deps.liquidity.attachCashout(tx, reservation.id, cashout.id);

        let feeAssessmentRecord: FeeAssessmentRecord | null = null;
        if (this.deps.pricing && assessment) {
          // Persist the assessment as `estimated`: the cost is the rule's
          // projected charge; Phase 4 promotes it to `posted` (or adjusts)
          // when the provider's webhook confirms the realised cost.
          feeAssessmentRecord = await this.deps.pricing.persistAssessment(tx, {
            assessment,
            transactionType: 'cashout',
            transactionId: cashout.id,
            clientId: input.clientId,
            providerAccountId: assignment.providerAccountId,
            operationType: 'cash_out',
            triggerEvent: 'cash_out_created',
            principalAmountCents: input.amountCents,
            status: 'estimated',
            metadata: { externalRef: input.externalRef }
          });

          if (
            assessment.policyDecision.kind === 'approved' &&
            assessment.policyDecision.subsidyCents > 0
          ) {
            await this.deps.pricing.persistSubsidyEvent(tx, {
              feeAssessmentId: feeAssessmentRecord.id,
              clientId: input.clientId,
              transactionType: 'cashout',
              transactionId: cashout.id,
              subsidyCents: assessment.policyDecision.subsidyCents,
              status: 'approved',
              reason: 'cashout subsidy approved by pricing policy',
              policy: assessment.policy,
              dailySubsidyTotalBeforeCents:
                assessment.policyDecision.dailySubsidyTotalBeforeCents,
              monthlySubsidyTotalBeforeCents:
                assessment.policyDecision.monthlySubsidyTotalBeforeCents
            });
          }
        }

        const body = buildResponse(
          cashout,
          reservation.id,
          assessment,
          feeAssessmentRecord
        );

        if (isTerminalCashoutStatus(cashout.status)) {
          // The provider settled (or definitively failed/returned) the
          // transfer synchronously on the create call. Run the same
          // financial closure and emit the same terminal public event the
          // async webhook path would. Without this, the confirming webhook
          // later hits `already_in_status` and NEITHER the ledger batch nor
          // the `pix.cash_out.<terminal>` webhook would ever fire — the bug
          // that delivered only `pix.cash_out.processing` to clients.
          const financial = await this.applyFinancialClosure(tx, {
            previousStatus: 'processing',
            cashout,
            triggerOccurredAt: cashout.createdAt
          });
          await this.enqueueCashoutTerminalEvent(tx, {
            cashout,
            occurredAt: cashout.createdAt,
            financial
          });
        } else {
          // `processing` create. Internal lifecycle marker only: the public
          // dispatcher skips `pix.cash_out.initiated`, so the client is NOT
          // sent a `pix.cash_out.processing` webhook (product decision). The
          // terminal public event is emitted later by
          // `handleCashoutStatusUpdate`.
          await this.deps.outbox.enqueue(tx, {
            aggregateType: 'cashout',
            aggregateId: cashout.id,
            eventType: 'pix.cash_out.initiated',
            payload: {
              cashoutId: cashout.id,
              externalId: cashout.externalId,
              clientId: cashout.clientId,
              provider: cashout.providerName,
              providerPaymentId: cashout.providerPaymentId,
              status: cashout.status,
              amountCents: cashout.amountCents,
              pixKey: cashout.pixKey,
              pixKeyType: cashout.pixKeyType,
              receiverName: cashout.receiverName,
              receiverDocument: cashout.receiverDocument,
              receiverBank: cashout.receiverBank,
              receiverIspb: cashout.receiverIspb,
              receiverBranch: cashout.receiverBranch,
              receiverAccount: cashout.receiverAccount,
              receiverAccountType: cashout.receiverAccountType,
              createdAt: cashout.createdAt.toISOString(),
              e2eId: cashout.e2eId,
              clientFeeCents: body.clientFeeCents,
              providerCostCents: body.providerCostCents,
              marginCents: body.marginCents,
              feeAssessmentId: body.feeAssessmentId
            }
          });
        }

        await this.deps.idempotency.finalizeWith(tx, recordId, body);

        return body;
      });

      return { cashout: response, replayed: false };
    } catch (error) {
      const release = canReleaseIdempotency(providerState);
      if (release) {
        if (reservationId !== null) {
          await safeReleaseReservation(
            this.deps.db,
            this.deps.liquidity,
            reservationId,
            errorCause(error)
          );
        }
        await safeReleaseIdempotency(this.deps.idempotency, recordId);
      } else {
        this.emitReconciliation({
          code: 'cashout_provider_state_requires_reconciliation',
          operationType: 'cash_out',
          recordId,
          clientId: input.clientId,
          externalRef: input.externalRef,
          reservationId,
          reason:
            'provider may have processed the Pix payment; liquidity reservation and idempotency lock retained',
          cause: errorCause(error),
          providerState: providerState.kind
        });
      }
      throw error;
    }
  }

  /**
   * Returns a cash-out owned by `clientId`, or `null` when no row
   * exists or the row belongs to a different tenant.
   *
   * Scoped by `clientId` so a client can never read another tenant's
   * cash-out even when they share the same provider account.
   */
  async getCashoutById(clientId: string, id: string): Promise<CreateCashoutResponse | null> {
    const record = await this.deps.cashoutRepository.findById(this.deps.db.pool, id);
    if (!record || record.clientId !== clientId) return null;
    return buildResponseFromRecord(record);
  }

  /**
   * Async webhook entrypoint for cash-out lifecycle events. Driven by
   * {@link WebhookEventProcessor} once a provider webhook resolves to
   * `normalizedStatusKind = 'cash_out'`.
   *
   * The handler applies the full financial closure for each terminal
   * status inside the same transaction that flips `cashouts.status`,
   * so observers either see the new status with all of its side-effects
   * or none of them:
   *
   *   - `processing → completed`: settle the liquidity reservation
   *     (`reserved → consumed`), promote/create the `fee_assessment`
   *     to `posted`, and post a balanced `cash_out_completed` batch on
   *     the ledger (principal + fees + subsidy).
   *
   *   - `processing → failed`: release the reservation
   *     (`reserved → released`), cancel the `estimated`
   *     `fee_assessment` if one exists. No ledger movement — the
   *     money never left the provider account.
   *
   *   - `processing → returned`: net-zero economic effect (the money
   *     left and came back immediately). Treated like `failed` for
   *     liquidity and fees; no ledger entries.
   *
   *   - `completed → returned` (chargeback): post a principal-only
   *     reversal on the ledger. The reservation was already consumed
   *     and the `fee_assessment` stays `posted` per CashYin's
   *     fee-retention policy on chargebacks.
   *
   * The outbox event is always enqueued so the public dispatcher can
   * notify the client of the new status regardless of which financial
   * closure path executed.
   *
   * @see {@link LedgerService.postFeeAssessment}, {@link LedgerService.postCashoutReturnReversal}
   */
  async handleCashoutStatusUpdate(
    event: CashoutStatusUpdateEvent
  ): Promise<CashoutStatusUpdateResult> {
    return this.deps.db.withTransaction(async (tx) => {
      const existing = await this.deps.cashoutRepository.findByProviderPaymentId(
        tx,
        event.providerName,
        event.providerPaymentId
      );
      if (!existing) {
        return { status: 'noop', reason: 'cashout_not_found' } as const;
      }

      if (existing.status === event.status) {
        return {
          status: 'noop',
          reason: 'already_in_status',
          cashoutId: existing.id
        } as const;
      }

      // Persist the provider reason only for non-success terminals; a
      // successful completion clears any earlier reason to NULL.
      const failureReason =
        event.status === 'failed' || event.status === 'returned'
          ? (event.failureReason ?? 'provider_rejected')
          : null;

      const updateResult = await this.deps.cashoutRepository.markStatus(
        tx,
        existing.id,
        event.status,
        { failureReason, occurredAt: event.occurredAt }
      );

      if (updateResult.kind === 'not_found') {
        return { status: 'noop', reason: 'cashout_not_found' } as const;
      }
      if (updateResult.kind === 'transition_not_allowed') {
        return {
          status: 'noop',
          reason: 'invalid_transition',
          cashoutId: existing.id,
          fromStatus: updateResult.currentStatus,
          toStatus: event.status
        } as const;
      }

      let updated = updateResult.record;

      // Backfill receiver identity and `e2e_id` from the provider's
      // confirmation webhook when the row does not already carry them.
      // COALESCE in the repository guarantees a request- or earlier-webhook-
      // supplied value is never overwritten, so partial-then-complete
      // receiver delivery fills gaps safely. The provider document is stored
      // as-is (already masked). This is the path that lets an asynchronous
      // provider deliver `e2e_id` and full receiver detail after an initial
      // `processing` create.
      const confirmation: Parameters<CashoutRepository['applyProviderConfirmation']>[2] = {
        ...(event.receiverName != null ? { receiverName: event.receiverName } : {}),
        ...(event.receiverDocument != null ? { receiverDocument: event.receiverDocument } : {}),
        ...(event.receiverBank != null ? { receiverBank: event.receiverBank } : {}),
        ...(event.receiverIspb != null ? { receiverIspb: event.receiverIspb } : {}),
        ...(event.receiverBranch != null ? { receiverBranch: event.receiverBranch } : {}),
        ...(event.receiverAccount != null ? { receiverAccount: event.receiverAccount } : {}),
        ...(event.receiverAccountType != null
          ? { receiverAccountType: event.receiverAccountType }
          : {}),
        ...(event.e2eId != null ? { e2eId: event.e2eId } : {})
      };
      if (Object.keys(confirmation).length > 0) {
        const patched = await this.deps.cashoutRepository.applyProviderConfirmation(
          tx,
          updated.id,
          confirmation
        );
        if (patched) {
          updated = patched;
        }
      }

      const financial = await this.applyFinancialClosure(tx, {
        previousStatus: existing.status,
        cashout: updated,
        triggerOccurredAt: event.occurredAt
      });

      // The outbox snapshot is built from the FINAL persisted state
      // (`updated`), so the public webhook payload always reflects the
      // committed status — never the pre-transition state.
      await this.enqueueCashoutTerminalEvent(tx, {
        cashout: updated,
        occurredAt: event.occurredAt,
        financial
      });

      return {
        status: 'updated',
        cashoutId: updated.id,
        previousStatus: existing.status,
        // `markStatus` enforces the transition guard, so `updated.status`
        // is necessarily the `TerminalCashoutStatus` we requested. We
        // re-use `event.status` to keep the narrower type without an
        // assertion.
        newStatus: event.status,
        financial
      } as const;
    });
  }

  /**
   * Enqueues the public terminal cash-out outbox event
   * (`pix.cash_out.completed` / `pix.cash_out.failed` /
   * `pix.cash_out.returned`) from a
   * fully-settled cash-out record. Shared by the synchronous create path
   * and the asynchronous webhook path so both produce a byte-identical
   * public envelope. The payload is a self-contained snapshot of the
   * FINAL persisted state; the dispatcher never re-reads `cashouts`.
   *
   * The internal-only fields (`feeAssessmentId`, `feeAssessmentStatus`,
   * `reservationOutcome`, `provider*`, `clientId`) are consumed by the
   * dispatcher/observability and are stripped from the public envelope by
   * {@link buildCashOutWebhookEnvelope} — they never reach the client.
   */
  private async enqueueCashoutTerminalEvent(
    tx: Sql,
    input: {
      cashout: CashoutRecord;
      occurredAt: Date;
      financial: CashoutFinancialEffect;
    }
  ): Promise<void> {
    const { cashout, occurredAt, financial } = input;
    await this.deps.outbox.enqueue(tx, {
      aggregateType: 'cashout',
      aggregateId: cashout.id,
      eventType: `pix.cash_out.${cashout.status}`,
      payload: {
        cashoutId: cashout.id,
        externalId: cashout.externalId,
        clientId: cashout.clientId,
        provider: cashout.providerName,
        providerPaymentId: cashout.providerPaymentId,
        status: cashout.status,
        amountCents: cashout.amountCents,
        pixKey: cashout.pixKey,
        pixKeyType: cashout.pixKeyType,
        receiverName: cashout.receiverName,
        receiverDocument: cashout.receiverDocument,
        receiverBank: cashout.receiverBank,
        receiverIspb: cashout.receiverIspb,
        receiverBranch: cashout.receiverBranch,
        receiverAccount: cashout.receiverAccount,
        receiverAccountType: cashout.receiverAccountType,
        createdAt: cashout.createdAt.toISOString(),
        occurredAt: occurredAt.toISOString(),
        e2eId: cashout.e2eId,
        failureReason: cashout.failureReason,
        ledgerEntriesPosted: financial.ledgerEntriesPosted,
        feeAssessmentId: financial.feeAssessmentId,
        feeAssessmentStatus: financial.feeAssessment,
        reservationOutcome: financial.reservation
      }
    });
  }

  /**
   * Dispatches to the per-status financial closure routine. Each branch
   * keeps its own side-effects inside the caller's transaction so the
   * status update, ledger, liquidity and fee_assessment all commit
   * together or roll back together.
   */
  private async applyFinancialClosure(
    tx: Sql,
    input: {
      previousStatus: CashOutStatus;
      cashout: CashoutRecord;
      triggerOccurredAt: Date;
    }
  ): Promise<CashoutFinancialEffect> {
    const { previousStatus, cashout } = input;
    const target = cashout.status;
    if (target === 'completed') {
      return this.closeOnCompleted(tx, cashout);
    }
    if (target === 'failed') {
      return this.closeOnFailed(tx, cashout, 'cashout_failed');
    }
    if (target === 'returned') {
      if (previousStatus === 'completed') {
        return this.closeOnReturnedAfterCompleted(tx, cashout);
      }
      // processing → returned: net-zero movement, same closure as
      // `failed` plus a distinct release_reason for auditability.
      return this.closeOnFailed(tx, cashout, 'cashout_returned_pre_completion');
    }
    // Defensive: `processing` is excluded by `TerminalCashoutStatus` at
    // compile time. This branch keeps the runtime safe if a future
    // status sneaks through the type system.
    return {
      ledger: 'none',
      ledgerEntriesPosted: 0,
      reservation: 'not_found',
      feeAssessment: 'none',
      feeAssessmentId: null
    };
  }

  private async closeOnCompleted(
    tx: Sql,
    cashout: CashoutRecord
  ): Promise<CashoutFinancialEffect> {
    const reservation = await this.deps.liquidity.findActiveByCashout(tx, cashout.id);
    let reservationOutcome: CashoutFinancialEffect['reservation'] = 'not_found';
    if (reservation) {
      await this.deps.liquidity.consume(tx, reservation.id, {
        reason: 'cashout_completed'
      });
      reservationOutcome = 'consumed';
    }

    const assessmentRecord = await this.resolveOrPromoteAssessment(tx, cashout, 'posted');

    let ledgerEntriesPosted = 0;
    let ledgerKind: CashoutFinancialEffect['ledger'] = 'none';
    if (this.deps.ledger && assessmentRecord) {
      const postingResult = await this.deps.ledger.postFeeAssessment(tx, {
        transactionId: cashout.id,
        triggerEvent: 'cash_out_completed',
        operationType: 'cash_out',
        clientId: cashout.clientId,
        providerName: cashout.providerName,
        providerAccountId: cashout.providerAccountId,
        providerReferenceId: cashout.providerPaymentId,
        principalAmountCents: cashout.amountCents,
        clientFeeCents: assessmentRecord.clientFeeCents,
        providerCostCents: assessmentRecord.providerCostCents,
        subsidyCents: assessmentRecord.subsidyCents,
        feeAssessmentId: assessmentRecord.id,
        metadata: {
          cashoutExternalId: cashout.externalId,
          providerPaymentId: cashout.providerPaymentId
        }
      });
      // `duplicate_skipped` occurs when a previous worker (or webhook
      // replay) already posted this batch — the cash-out completion
      // financial effect is unchanged, but no new entries are written.
      if (postingResult.kind === 'first_post') {
        ledgerEntriesPosted = postingResult.entries.length;
      }
      ledgerKind = 'cash_out_completed';
    }

    return {
      ledger: ledgerKind,
      ledgerEntriesPosted,
      reservation: reservationOutcome,
      feeAssessment: assessmentRecord ? 'posted' : 'none',
      feeAssessmentId: assessmentRecord?.id ?? null
    };
  }

  private async closeOnFailed(
    tx: Sql,
    cashout: CashoutRecord,
    releaseReason: string
  ): Promise<CashoutFinancialEffect> {
    const reservation = await this.deps.liquidity.findActiveByCashout(tx, cashout.id);
    let reservationOutcome: CashoutFinancialEffect['reservation'] = 'not_found';
    if (reservation) {
      await this.deps.liquidity.release(tx, reservation.id, { reason: releaseReason });
      reservationOutcome = 'released';
    }

    let assessmentOutcome: CashoutFinancialEffect['feeAssessment'] = 'none';
    let assessmentId: string | null = null;
    if (this.deps.pricing) {
      const existing = await this.deps.pricing.findAssessmentByTransaction(
        tx,
        'cashout',
        cashout.id,
        'cash_out_created'
      );
      if (existing) {
        assessmentId = existing.id;
        if (existing.status === 'estimated') {
          await this.deps.pricing.promoteAssessmentStatus(tx, existing.id, 'cancelled');
          assessmentOutcome = 'cancelled';
        } else {
          // Already posted/cancelled/reconciled — keep as-is. This path
          // is hit when a duplicate webhook delivery re-runs the
          // handler after a previous run already closed the books.
          assessmentOutcome = existing.status === 'cancelled' ? 'cancelled' : 'none';
        }
      }
    }

    return {
      ledger: 'none',
      ledgerEntriesPosted: 0,
      reservation: reservationOutcome,
      feeAssessment: assessmentOutcome,
      feeAssessmentId: assessmentId
    };
  }

  private async closeOnReturnedAfterCompleted(
    tx: Sql,
    cashout: CashoutRecord
  ): Promise<CashoutFinancialEffect> {
    // Load the full assessment to obtain clientFeeCents for the fee reversal.
    let assessmentRecord: FeeAssessmentRecord | null = null;
    if (this.deps.pricing) {
      assessmentRecord = await this.deps.pricing.findAssessmentByTransaction(
        tx,
        'cashout',
        cashout.id,
        'cash_out_created'
      );
    }
    const assessmentId = assessmentRecord?.id ?? null;
    const clientFeeCents = assessmentRecord?.clientFeeCents ?? 0;

    let ledgerEntriesPosted = 0;
    let ledgerKind: CashoutFinancialEffect['ledger'] = 'none';
    if (this.deps.ledger) {
      const entries = await this.deps.ledger.postCashoutReturnReversal(tx, {
        transactionId: cashout.id,
        clientId: cashout.clientId,
        providerName: cashout.providerName,
        providerAccountId: cashout.providerAccountId,
        providerReferenceId: cashout.providerPaymentId,
        principalAmountCents: cashout.amountCents,
        clientFeeCents,
        feeAssessmentId: assessmentId,
        metadata: {
          cashoutExternalId: cashout.externalId,
          providerPaymentId: cashout.providerPaymentId
        }
      });
      ledgerEntriesPosted = entries.length;
      ledgerKind = 'cash_out_returned';
    }

    // The fee_assessment row is kept as `posted` (immutable audit trail);
    // the reversal is expressed as new compensating ledger entries.
    const feeAssessmentOutcome: CashoutFinancialEffect['feeAssessment'] =
      assessmentId
        ? clientFeeCents > 0
          ? 'reversed'
          : 'posted'
        : 'none';

    return {
      ledger: ledgerKind,
      ledgerEntriesPosted,
      // The reservation was consumed at completion time; nothing remains to
      // release. We report `not_found` because no `reserved` row exists at
      // this point in the lifecycle.
      reservation: 'not_found',
      feeAssessment: feeAssessmentOutcome,
      feeAssessmentId: assessmentId
    };
  }

  /**
   * Locates or creates the `posted` `fee_assessment` row for a
   * `cash_out_created` trigger event. Cash-outs always book their
   * assessment at create time (Phase 3), so the usual path here is
   * `findAssessmentByTransaction → promoteAssessmentStatus`. The
   * backfill branch only fires when the cash-out was created before
   * pricing was wired or when pricing returned `null` for the
   * client/provider pair at creation time.
   */
  private async resolveOrPromoteAssessment(
    tx: Sql,
    cashout: CashoutRecord,
    targetStatus: 'posted'
  ): Promise<FeeAssessmentRecord | null> {
    const pricing = this.deps.pricing;
    if (!pricing) return null;

    const existing = await pricing.findAssessmentByTransaction(
      tx,
      'cashout',
      cashout.id,
      'cash_out_created'
    );

    if (existing) {
      if (existing.status === 'estimated') {
        return pricing.promoteAssessmentStatus(tx, existing.id, targetStatus);
      }
      return existing;
    }

    const fresh = await pricing.assessForCashout(tx, {
      clientId: cashout.clientId,
      providerAccountId: cashout.providerAccountId,
      amountCents: cashout.amountCents
    });
    if (!fresh || fresh.policyDecision.kind === 'rejected') return null;

    return pricing.persistAssessment(tx, {
      assessment: fresh,
      transactionType: 'cashout',
      transactionId: cashout.id,
      clientId: cashout.clientId,
      providerAccountId: cashout.providerAccountId,
      operationType: 'cash_out',
      triggerEvent: 'cash_out_created',
      principalAmountCents: cashout.amountCents,
      status: targetStatus,
      metadata: {
        externalId: cashout.externalId,
        backfilled: true,
        reason: 'no_estimated_assessment_at_completed_time'
      }
    });
  }

  private async recoverFromStaleLock(
    input: CreateCashoutInput,
    recordId: string,
    idempotencyKey: string
  ): Promise<CreateCashoutResponse> {
    // Recovery by client external reference is only possible when the caller
    // supplied one. `external_ref` is optional on the public contract, so a
    // null reference falls straight through to the reconciliation error.
    const existing =
      input.externalRef !== null
        ? await this.deps.cashoutRepository.findByClientExternalId(
            this.deps.db.pool,
            input.clientId,
            input.externalRef
          )
        : null;

    if (existing) {
      const cached = buildResponseFromRecord(existing);
      await this.deps.idempotency.finalize(recordId, cached);
      return cached;
    }

    throw new AppError(
      'cashout_stale_lock_requires_reconciliation',
      'A previous request with this Idempotency-Key may have submitted a Pix payment with the provider but never persisted it locally; manual reconciliation is required',
      409,
      {
        clientId: input.clientId,
        externalRef: input.externalRef,
        idempotencyKey
      }
    );
  }

  private emitReconciliation(event: ReconciliationEvent): void {
    const logger = this.deps.log ?? defaultReconciliationLogger;
    try {
      logger(event);
    } catch {
      // Never fail the original request because logging threw.
    }
  }
}

function classifyProviderCallError(error: unknown): ProviderState {
  if (error instanceof ProviderError) {
    if (error.isDefinite) {
      return { kind: 'settled_definite_failure', error };
    }
    return { kind: 'ambiguous', error };
  }
  const wrapped = error instanceof Error ? error : new Error(String(error));
  return { kind: 'ambiguous', error: wrapped };
}

function canReleaseIdempotency(state: ProviderState): boolean {
  return state.kind === 'not_started' || state.kind === 'settled_definite_failure';
}

/**
 * Narrows a persisted {@link CashOutStatus} to a {@link TerminalCashoutStatus}.
 * `processing` is the only non-terminal state; everything else is a
 * terminal status that warrants financial closure and a public webhook.
 */
function isTerminalCashoutStatus(status: CashOutStatus): status is TerminalCashoutStatus {
  return status !== 'processing';
}

function buildResponse(
  cashout: CashoutRecord,
  reservationId: string,
  assessment: CashoutPricingAssessment | null,
  feeAssessmentRecord: FeeAssessmentRecord | null
): CreateCashoutResponse {
  const clientFeeCents = assessment?.clientFeeCents ?? 0;
  const providerCostCents = assessment?.providerCostCents ?? 0;
  const marginCents = assessment?.marginCents ?? 0;
  const totalDebitAmountCents =
    assessment?.billingMode === 'add_to_debit'
      ? cashout.amountCents + clientFeeCents
      : cashout.amountCents;
  return {
    id: cashout.id,
    clientId: cashout.clientId,
    externalRef: cashout.externalId,
    amountCents: cashout.amountCents,
    currency: cashout.currency,
    pixKey: cashout.pixKey,
    pixKeyType: cashout.pixKeyType,
    receiverName: cashout.receiverName,
    receiverDocument: cashout.receiverDocument,
    receiverBank: cashout.receiverBank,
    receiverIspb: cashout.receiverIspb,
    receiverBranch: cashout.receiverBranch,
    receiverAccount: cashout.receiverAccount,
    receiverAccountType: cashout.receiverAccountType,
    status: cashout.status,
    provider: cashout.providerName,
    providerPaymentId: cashout.providerPaymentId,
    e2eId: cashout.e2eId,
    feeAmountCents: cashout.feeAmountCents,
    clientFeeCents,
    providerCostCents,
    marginCents,
    totalDebitAmountCents,
    feeAssessmentId: feeAssessmentRecord?.id ?? null,
    reservationId,
    createdAt: cashout.createdAt.toISOString(),
    completedAt: cashout.completedAt?.toISOString() ?? null,
    failedAt: cashout.failedAt?.toISOString() ?? null,
    returnedAt: cashout.returnedAt?.toISOString() ?? null
  };
}

/**
 * Builds a replay response from a persisted record alone. The reservationId
 * is unavailable in this path (we do not join the reservations table here);
 * callers can resolve it via `GET /v1/pix/cash-out/{id}` if needed.
 *
 * Phase 3 note: pricing fields (`clientFeeCents`, `providerCostCents`,
 * `marginCents`, `totalDebitAmountCents`, `feeAssessmentId`) are returned as
 * `0` / `null` in the stale-lock recovery path because we don't re-load
 * `fee_assessments` here.
 */
function buildResponseFromRecord(cashout: CashoutRecord): CreateCashoutResponse {
  return {
    id: cashout.id,
    clientId: cashout.clientId,
    externalRef: cashout.externalId,
    amountCents: cashout.amountCents,
    currency: cashout.currency,
    pixKey: cashout.pixKey,
    pixKeyType: cashout.pixKeyType,
    receiverName: cashout.receiverName,
    receiverDocument: cashout.receiverDocument,
    receiverBank: cashout.receiverBank,
    receiverIspb: cashout.receiverIspb,
    receiverBranch: cashout.receiverBranch,
    receiverAccount: cashout.receiverAccount,
    receiverAccountType: cashout.receiverAccountType,
    status: cashout.status,
    provider: cashout.providerName,
    providerPaymentId: cashout.providerPaymentId,
    e2eId: cashout.e2eId,
    feeAmountCents: cashout.feeAmountCents,
    clientFeeCents: 0,
    providerCostCents: 0,
    marginCents: 0,
    totalDebitAmountCents: cashout.amountCents,
    feeAssessmentId: null,
    reservationId: null,
    createdAt: cashout.createdAt.toISOString(),
    completedAt: cashout.completedAt?.toISOString() ?? null,
    failedAt: cashout.failedAt?.toISOString() ?? null,
    returnedAt: cashout.returnedAt?.toISOString() ?? null
  };
}

async function safeReleaseReservation(
  db: Database,
  liquidity: LiquidityService,
  reservationId: string,
  reason: string
): Promise<void> {
  try {
    await liquidity.release(db.pool, reservationId, { reason });
  } catch {
    // Reservation row remains and will be reconciled; expiration TTL also clears it.
  }
}

async function safeReleaseIdempotency(
  idempotency: IdempotencyService,
  recordId: string
): Promise<void> {
  try {
    await idempotency.release(recordId);
  } catch {
    // Lock expires via locked_until; swallow so the caller sees the original error.
  }
}

function errorCause(error: unknown): string {
  if (error instanceof ProviderError) {
    return `${error.code}:${error.category}`;
  }
  if (error instanceof Error) {
    return error.message;
  }
  return String(error);
}

function defaultReconciliationLogger(event: ReconciliationEvent): void {
  const payload = {
    level: 'error',
    ...event,
    msg: 'reconciliation_required'
  };
  console.error(JSON.stringify(payload));
}
