/**
 * Per-operation step-up (second-factor) proofs for human-initiated cash-outs.
 *
 * Flow (only active when `CASHOUT_STEPUP_MODE !== 'off'`):
 *   1. The trusted BFF performs an MFA challenge with the human, then calls
 *      `POST /v1/pix/cash-out/step-up` with the intended cash-out parameters.
 *      The Core computes a canonical {@link canonicalCashoutHash} and persists
 *      an `issued` proof bound to that hash + tenant, returning the proof id.
 *   2. The BFF submits the cash-out presenting the proof id. The Core recomputes
 *      the hash from the actual request and atomically consumes the matching
 *      `issued`, non-expired proof (single-use). A mismatch/expiry/reuse is
 *      indistinguishable — all surface as `auth_step_up_required`.
 *
 * The proof binding prevents a stolen session/credential from being used to
 * authorise a *different* transfer than the human approved.
 */

import { createHash } from 'node:crypto';
import type { Sql } from '../../shared/db/sql.js';
import type { StepUpProof } from '../../shared/auth/auth-context.js';
import type { CreateCashoutBody } from './cashout.schemas.js';

export type CashoutStepUpMode = 'off' | 'shadow' | 'enforce';

/** Header carrying the step-up proof id on the cash-out request. */
export const STEP_UP_PROOF_HEADER = 'x-cashyin-step-up-proof' as const;

/**
 * Deterministic SHA-256 over the *binding* cash-out parameters: the tenant,
 * the amount and the destination (plus the client's external reference). The
 * key order is fixed so issue-time and consume-time hashes match exactly.
 * Cosmetic fields (description, receiver_name) are intentionally excluded.
 */
export function canonicalCashoutHash(clientId: string, body: CreateCashoutBody): string {
  const canonical = JSON.stringify({
    clientId,
    amount: body.amount,
    pixKey: body.pix.key,
    pixKeyType: body.pix.key_type,
    externalRef: body.external_ref ?? null,
    receiverDocument: body.receiver?.document_number ?? null
  });
  return createHash('sha256').update(canonical).digest('hex');
}

type StepUpProofRow = {
  amr: string[];
  transaction_hash: string;
  issued_at: Date;
  expires_at: Date;
};

export type InsertStepUpProofInput = {
  clientId: string;
  actorUserId: string | null;
  transactionHash: string;
  amr: readonly string[];
  expiresAt: Date;
};

export type ConsumeStepUpInput = {
  proofId: string;
  clientId: string;
  transactionHash: string;
};

export interface CashoutStepUpRepository {
  insert(sql: Sql, input: InsertStepUpProofInput): Promise<{ id: string }>;
  /**
   * Atomically mark a matching `issued`, non-expired, hash-bound proof as
   * consumed and return it. Returns `null` when nothing matched (single-use).
   */
  consumeMatching(sql: Sql, input: ConsumeStepUpInput): Promise<StepUpProofRow | null>;
  /** Non-consuming read of a still-valid proof, for shadow-mode logging. */
  findValid(sql: Sql, proofId: string, clientId: string): Promise<StepUpProofRow | null>;
}

export class PgCashoutStepUpRepository implements CashoutStepUpRepository {
  async insert(sql: Sql, input: InsertStepUpProofInput): Promise<{ id: string }> {
    const result = await sql.query<{ id: string }>(
      `INSERT INTO cashout_step_up_proofs (client_id, actor_user_id, transaction_hash, amr, expires_at)
       VALUES ($1, $2, $3, $4::text[], $5)
       RETURNING id`,
      [input.clientId, input.actorUserId, input.transactionHash, input.amr as string[], input.expiresAt]
    );
    const row = result.rows[0];
    if (!row) {
      throw new Error('cashout_step_up_proofs insert returned no row');
    }
    return { id: row.id };
  }

  async consumeMatching(sql: Sql, input: ConsumeStepUpInput): Promise<StepUpProofRow | null> {
    const result = await sql.query<StepUpProofRow>(
      `UPDATE cashout_step_up_proofs
          SET status = 'consumed', consumed_at = now()
        WHERE id = $1
          AND client_id = $2
          AND transaction_hash = $3
          AND status = 'issued'
          AND expires_at > now()
        RETURNING amr, transaction_hash, issued_at, expires_at`,
      [input.proofId, input.clientId, input.transactionHash]
    );
    return result.rows[0] ?? null;
  }

  async findValid(sql: Sql, proofId: string, clientId: string): Promise<StepUpProofRow | null> {
    const result = await sql.query<StepUpProofRow>(
      `SELECT amr, transaction_hash, issued_at, expires_at
         FROM cashout_step_up_proofs
        WHERE id = $1
          AND client_id = $2
          AND status = 'issued'
          AND expires_at > now()`,
      [proofId, clientId]
    );
    return result.rows[0] ?? null;
  }
}

export type IssuedStepUpProof = {
  proofId: string;
  transactionHash: string;
  expiresAt: Date;
};

export type CashoutStepUpServiceDeps = {
  repository: CashoutStepUpRepository;
  sql: Sql;
  /** Proof lifetime in milliseconds (CASHOUT_STEPUP_TTL_MS). */
  ttlMs: number;
  now?: () => number;
};

function toStepUpProof(row: StepUpProofRow): StepUpProof {
  return {
    amr: row.amr,
    transactionHash: row.transaction_hash,
    issuedAt: row.issued_at.getTime(),
    expiresAt: row.expires_at.getTime()
  };
}

export class CashoutStepUpService {
  private readonly repository: CashoutStepUpRepository;
  private readonly sql: Sql;
  private readonly ttlMs: number;
  private readonly now: () => number;

  constructor(deps: CashoutStepUpServiceDeps) {
    this.repository = deps.repository;
    this.sql = deps.sql;
    this.ttlMs = deps.ttlMs;
    this.now = deps.now ?? Date.now;
  }

  async issue(input: {
    clientId: string;
    actorUserId?: string | null;
    transactionHash: string;
    amr?: readonly string[];
  }): Promise<IssuedStepUpProof> {
    const expiresAt = new Date(this.now() + this.ttlMs);
    const { id } = await this.repository.insert(this.sql, {
      clientId: input.clientId,
      actorUserId: input.actorUserId ?? null,
      transactionHash: input.transactionHash,
      amr: input.amr ?? [],
      expiresAt
    });
    return { proofId: id, transactionHash: input.transactionHash, expiresAt };
  }

  /** Atomically consume a matching proof. Returns the proof or `null`. */
  async consume(input: ConsumeStepUpInput): Promise<StepUpProof | null> {
    const row = await this.repository.consumeMatching(this.sql, input);
    return row ? toStepUpProof(row) : null;
  }

  /** Non-consuming check used by shadow mode. */
  async peek(input: ConsumeStepUpInput): Promise<boolean> {
    const row = await this.repository.findValid(this.sql, input.proofId, input.clientId);
    return row !== null && row.transaction_hash === input.transactionHash;
  }
}
