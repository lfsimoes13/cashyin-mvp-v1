/**
 * PricingService — orchestrates the pure pricing calculator with the
 * persistence layer for cash-out (and later cash-in) operations.
 *
 * Design contract:
 *
 *  1. **No-op fallback.** When either the active pricing rule OR the active
 *     provider cost rule is missing for the requested
 *     (client, providerAccount, operation, triggerEvent) tuple, the
 *     service returns `null` from {@link assessForCashout}. The cash-out
 *     service treats `null` as "no fee, no cost, no fee_assessment row".
 *     This keeps the system safe for clients that haven't been onboarded
 *     into the pricing model yet (which is the entire user base on the
 *     day Phase 3 ships, until the seed-baseline PR plants a default
 *     plan).
 *
 *  2. **Policy enforcement is deterministic.** {@link evaluatePolicyWithAggregates}
 *     extends the pure calculator with database-backed daily/monthly
 *     subsidy caps. It never throws for normal business decisions: the
 *     return value carries a discriminated rejection code that callers
 *     consume.
 *
 *  3. **Persistence is the caller's transaction.** {@link persistAssessment}
 *     and {@link persistSubsidyEvent} accept an arbitrary `Sql` executor
 *     so the cash-out service can fold the inserts into the same
 *     transaction that writes the cash-out row, the outbox event and
 *     the idempotency finalisation.
 *
 *  4. **All money stays integer cents.** The service layer never reaches
 *     for floats; the pure calculator handles the only arithmetic that
 *     matters.
 */

import type { Sql } from '../../shared/db/sql.js';
import type { OperationType } from '../../providers/contracts/provider-types.js';
import {
  calculateFee,
  calculateProviderCost,
  calculateMarginAndSubsidy,
  evaluateNegativeMarginPolicy
} from './pricing.calculator.js';
import { PRICING_ERROR_CODES } from './pricing.errors.js';
import type {
  BillingMode,
  Cents,
  FeeFormula,
  NegativeMarginPolicy,
  ProviderCostFormula,
  RoundingMode
} from './pricing.types.js';
import type {
  PricingRuleRecord,
  PricingRuleRepository
} from './pricing-rule.repository.js';
import type {
  ProviderCostRuleRecord,
  ProviderCostRuleRepository
} from './provider-cost-rule.repository.js';
import type {
  FeeAssessmentInsertInput,
  FeeAssessmentRecord,
  FeeAssessmentRepository,
  FeeAssessmentStatus,
  FeeAssessmentTransactionType
} from './fee-assessment.repository.js';
import type {
  SubsidyEventInsertInput,
  SubsidyEventRecord,
  SubsidyEventRepository
} from './subsidy-event.repository.js';

/**
 * Result of a successful assessment lookup + calculation.
 *
 * Importantly, `policyDecision` may still be `rejected`. The service does
 * NOT decide to abort or persist; callers (e.g. CashoutService) take that
 * branch explicitly so they can roll back idempotency and skip the
 * provider call before any side effect.
 *
 * This shape is intentionally identical for cash-in and cash-out: the
 * difference between operations is captured by the underlying
 * `pricingRuleSnapshot.operationType` and `triggerEvent`, not by the
 * envelope. {@link CashoutPricingAssessment} is kept as a legacy alias for
 * Phase 3 call sites.
 */
export type PricingAssessment = {
  clientFeeCents: Cents;
  providerCostCents: Cents;
  marginCents: number;
  subsidyCents: Cents;
  billingMode: BillingMode;
  roundingMode: RoundingMode;
  pricingRuleId: string;
  providerCostRuleId: string;
  pricingRuleSnapshot: PricingRuleRecord;
  providerCostRuleSnapshot: ProviderCostRuleRecord;
  policy: NegativeMarginPolicy;
  /**
   * Result of evaluating the negative-margin policy, augmented with daily
   * and monthly subsidy aggregates loaded from `subsidy_events`. Callers
   * treat any non-`approved` value as a hard reject before touching the
   * provider.
   */
  policyDecision: PolicyDecisionWithAggregates;
};

/** @deprecated Use {@link PricingAssessment}. Kept for Phase 3 call sites. */
export type CashoutPricingAssessment = PricingAssessment;

export type DailySubsidyExceededCode = 'pricing_negative_margin_exceeds_daily_limit';
export type MonthlySubsidyExceededCode = 'pricing_negative_margin_exceeds_monthly_limit';

export type ExtendedNegativeMarginRejectionCode =
  | 'pricing_negative_margin_not_allowed'
  | 'pricing_negative_margin_exceeds_per_txn_limit'
  | DailySubsidyExceededCode
  | MonthlySubsidyExceededCode;

export type PolicyDecisionWithAggregates =
  | {
      kind: 'approved';
      subsidyCents: Cents;
      dailySubsidyTotalBeforeCents: Cents;
      monthlySubsidyTotalBeforeCents: Cents;
    }
  | {
      kind: 'rejected';
      code: ExtendedNegativeMarginRejectionCode;
      subsidyCents: Cents;
      reason: string;
      dailySubsidyTotalBeforeCents: Cents;
      monthlySubsidyTotalBeforeCents: Cents;
    };

export type AssessCashoutInput = {
  clientId: string;
  providerAccountId: string;
  amountCents: Cents;
  /**
   * Trigger event for the pricing rule lookup. Phase 3 uses
   * `cash_out_created` at the point the operation is authorised; Phase 4
   * will use `cash_out_confirmed` once the webhook arrives.
   */
  triggerEvent?: string;
  /** Defaults to `new Date()`. Injectable for deterministic tests. */
  now?: Date;
};

export type AssessCashInInput = {
  clientId: string;
  providerAccountId: string;
  amountCents: Cents;
  /**
   * Trigger event for the pricing rule lookup. Phase 4 uses
   * `cash_in_paid` because charge fees are only assessed when the payment
   * is actually received (per docs/tariff-system-plan.md §5).
   */
  triggerEvent?: string;
  now?: Date;
};

export type EvaluatePolicyAggregatesInput = {
  clientId: string;
  policy: NegativeMarginPolicy;
  /** Subsidy that WOULD be incurred if this txn is approved. */
  prospectiveSubsidyCents: Cents;
  /** Defaults to `new Date()`. */
  now?: Date;
};

export type PersistAssessmentInput = {
  assessment: PricingAssessment;
  transactionType: FeeAssessmentInsertInput['transactionType'];
  transactionId: string;
  clientId: string;
  providerAccountId: string;
  operationType: OperationType;
  triggerEvent: string;
  principalAmountCents: Cents;
  status: FeeAssessmentInsertInput['status'];
  metadata?: Record<string, unknown>;
};

export class PricingService {
  constructor(
    private readonly pricingRules: PricingRuleRepository,
    private readonly providerCostRules: ProviderCostRuleRepository,
    private readonly feeAssessments: FeeAssessmentRepository,
    private readonly subsidyEvents: SubsidyEventRepository
  ) {}

  /**
   * Resolves the active pricing + provider-cost rules and computes the
   * client fee, provider cost, margin, subsidy and negative-margin policy
   * decision. Returns `null` when either side of the configuration is
   * missing so the caller can fall back to no-fee/no-cost behaviour.
   *
   * IMPORTANT: this method does NOT persist anything. The caller invokes
   * {@link persistAssessment} (and optionally {@link persistSubsidyEvent})
   * inside its own transaction once it has decided to proceed.
   */
  async assessForCashout(
    sql: Sql,
    input: AssessCashoutInput
  ): Promise<PricingAssessment | null> {
    return this.assess(sql, {
      clientId: input.clientId,
      providerAccountId: input.providerAccountId,
      amountCents: input.amountCents,
      operationType: 'cash_out',
      triggerEvent: input.triggerEvent ?? 'cash_out_created',
      ...(input.now !== undefined ? { now: input.now } : {})
    });
  }

  /**
   * Cash-in counterpart of {@link assessForCashout}. The default trigger
   * event is `cash_in_paid` because per {@link docs/tariff-system-plan.md}
   * §5 cash-in fees and provider costs are only RECOGNISED at the moment
   * of payment confirmation. The caller (PaymentService.createPixCharge)
   * may still pre-compute an `estimated` assessment at charge creation by
   * calling this method with the default trigger event and persisting the
   * result with status='estimated'; the webhook handler then promotes the
   * row to status='posted' on `pix.cash_in.paid`.
   */
  async assessForCashIn(
    sql: Sql,
    input: AssessCashInInput
  ): Promise<PricingAssessment | null> {
    return this.assess(sql, {
      clientId: input.clientId,
      providerAccountId: input.providerAccountId,
      amountCents: input.amountCents,
      operationType: 'cash_in',
      triggerEvent: input.triggerEvent ?? 'cash_in_paid',
      ...(input.now !== undefined ? { now: input.now } : {})
    });
  }

  private async assess(
    sql: Sql,
    input: {
      clientId: string;
      providerAccountId: string;
      amountCents: Cents;
      operationType: 'cash_in' | 'cash_out';
      triggerEvent: string;
      now?: Date;
    }
  ): Promise<PricingAssessment | null> {
    const [pricingRule, providerCostRule] = await Promise.all([
      this.pricingRules.findActiveForClient(sql, {
        clientId: input.clientId,
        operationType: input.operationType,
        triggerEvent: input.triggerEvent
      }),
      this.providerCostRules.findActiveForProviderAccount(sql, {
        providerAccountId: input.providerAccountId,
        operationType: input.operationType,
        triggerEvent: input.triggerEvent
      })
    ]);

    if (!pricingRule || !providerCostRule) {
      return null;
    }

    const feeFormula: FeeFormula = {
      fixedFeeCents: pricingRule.fixedFeeCents,
      variableFeeBps: pricingRule.variableFeeBps,
      minFeeCents: pricingRule.minFeeCents,
      maxFeeCents: pricingRule.maxFeeCents,
      roundingMode: pricingRule.roundingMode,
      billingMode: pricingRule.billingMode
    };
    const costFormula: ProviderCostFormula = {
      fixedCostCents: providerCostRule.fixedCostCents,
      variableCostBps: providerCostRule.variableCostBps,
      minCostCents: providerCostRule.minCostCents,
      maxCostCents: providerCostRule.maxCostCents,
      roundingMode: providerCostRule.roundingMode,
      chargedFromProviderBalance: providerCostRule.chargedFromProviderBalance
    };

    const fee = calculateFee({ amountCents: input.amountCents, formula: feeFormula });
    const cost = calculateProviderCost({
      amountCents: input.amountCents,
      formula: costFormula
    });
    const { marginCents, subsidyCents } = calculateMarginAndSubsidy(
      fee.clientFeeCents,
      cost.providerCostCents
    );

    const policy: NegativeMarginPolicy = {
      allowNegativeMargin: pricingRule.allowNegativeMargin,
      maxNegativeMarginCentsPerTxn: pricingRule.maxNegativeMarginCentsPerTxn,
      dailySubsidyLimitCents: pricingRule.dailySubsidyLimitCents,
      monthlySubsidyLimitCents: pricingRule.monthlySubsidyLimitCents
    };

    const policyDecision = await this.evaluatePolicyWithAggregates(sql, {
      clientId: input.clientId,
      policy,
      prospectiveSubsidyCents: subsidyCents,
      ...(input.now !== undefined ? { now: input.now } : {})
    });

    return {
      clientFeeCents: fee.clientFeeCents,
      providerCostCents: cost.providerCostCents,
      marginCents,
      subsidyCents,
      billingMode: feeFormula.billingMode,
      roundingMode: feeFormula.roundingMode,
      pricingRuleId: pricingRule.id,
      providerCostRuleId: providerCostRule.id,
      pricingRuleSnapshot: pricingRule,
      providerCostRuleSnapshot: providerCostRule,
      policy,
      policyDecision
    };
  }

  /**
   * Runs the pure per-txn policy check, then (if approved AND any
   * aggregate cap is configured) loads `subsidy_events` totals to enforce
   * daily/monthly caps. Either side of the decision is fully deterministic.
   */
  async evaluatePolicyWithAggregates(
    sql: Sql,
    input: EvaluatePolicyAggregatesInput
  ): Promise<PolicyDecisionWithAggregates> {
    const now = input.now ?? new Date();
    const pureDecision = evaluateNegativeMarginPolicy({
      // We don't have client/provider amounts here, just the prospective
      // subsidy. Express the inputs so the pure calculator's algebra still
      // holds: subsidy = max(0, cost - fee). We use fee=0, cost=subsidy.
      clientFeeCents: 0,
      providerCostCents: input.prospectiveSubsidyCents,
      policy: input.policy
    });

    if (pureDecision.kind === 'rejected') {
      return {
        kind: 'rejected',
        code: pureDecision.code,
        subsidyCents: pureDecision.subsidyCents,
        reason: pureDecision.reason,
        dailySubsidyTotalBeforeCents: 0,
        monthlySubsidyTotalBeforeCents: 0
      };
    }

    if (pureDecision.subsidyCents === 0) {
      return {
        kind: 'approved',
        subsidyCents: 0,
        dailySubsidyTotalBeforeCents: 0,
        monthlySubsidyTotalBeforeCents: 0
      };
    }

    const needsDaily = input.policy.dailySubsidyLimitCents !== null;
    const needsMonthly = input.policy.monthlySubsidyLimitCents !== null;

    let dailyTotal: Cents = 0;
    let monthlyTotal: Cents = 0;

    if (needsDaily) {
      const { from, to } = dayWindow(now);
      dailyTotal = await this.subsidyEvents.sumApprovedBetween(sql, {
        clientId: input.clientId,
        from,
        to
      });
      const limit = input.policy.dailySubsidyLimitCents as Cents;
      if (dailyTotal + pureDecision.subsidyCents > limit) {
        return {
          kind: 'rejected',
          code: 'pricing_negative_margin_exceeds_daily_limit',
          subsidyCents: pureDecision.subsidyCents,
          reason:
            `Daily subsidy total ${dailyTotal} + prospective ${pureDecision.subsidyCents} ` +
            `would exceed the configured daily limit ${limit}`,
          dailySubsidyTotalBeforeCents: dailyTotal,
          monthlySubsidyTotalBeforeCents: 0
        };
      }
    }

    if (needsMonthly) {
      const { from, to } = monthWindow(now);
      monthlyTotal = await this.subsidyEvents.sumApprovedBetween(sql, {
        clientId: input.clientId,
        from,
        to
      });
      const limit = input.policy.monthlySubsidyLimitCents as Cents;
      if (monthlyTotal + pureDecision.subsidyCents > limit) {
        return {
          kind: 'rejected',
          code: 'pricing_negative_margin_exceeds_monthly_limit',
          subsidyCents: pureDecision.subsidyCents,
          reason:
            `Monthly subsidy total ${monthlyTotal} + prospective ${pureDecision.subsidyCents} ` +
            `would exceed the configured monthly limit ${limit}`,
          dailySubsidyTotalBeforeCents: dailyTotal,
          monthlySubsidyTotalBeforeCents: monthlyTotal
        };
      }
    }

    return {
      kind: 'approved',
      subsidyCents: pureDecision.subsidyCents,
      dailySubsidyTotalBeforeCents: dailyTotal,
      monthlySubsidyTotalBeforeCents: monthlyTotal
    };
  }

  /**
   * Looks up an existing fee_assessment for the given transaction. Used by
   * the cash-in webhook handler to find an `estimated` row created at
   * charge time so it can be promoted to `posted`.
   */
  async findAssessmentByTransaction(
    sql: Sql,
    transactionType: FeeAssessmentTransactionType,
    transactionId: string,
    triggerEvent: string
  ): Promise<FeeAssessmentRecord | null> {
    return this.feeAssessments.findByTransaction(
      sql,
      transactionType,
      transactionId,
      triggerEvent
    );
  }

  /**
   * Promotes an existing fee_assessment to a new status. Returns the
   * updated record, or `null` if the row no longer exists.
   *
   * Phase 4 uses this exclusively to transition `estimated` → `posted`
   * on `cash_in_paid` (and, in a follow-up PR, `cash_out_confirmed`).
   */
  async promoteAssessmentStatus(
    sql: Sql,
    id: string,
    status: FeeAssessmentStatus
  ): Promise<FeeAssessmentRecord | null> {
    return this.feeAssessments.updateStatus(sql, id, status);
  }

  /**
   * Persists a fee_assessment row inside the caller's transaction. Returns
   * the persisted record so the caller can link it to the cashout row, the
   * outbox event and the idempotency replay payload.
   */
  async persistAssessment(
    sql: Sql,
    input: PersistAssessmentInput
  ): Promise<FeeAssessmentRecord> {
    return this.feeAssessments.insert(sql, {
      transactionType: input.transactionType,
      transactionId: input.transactionId,
      clientId: input.clientId,
      providerAccountId: input.providerAccountId,
      operationType: input.operationType,
      triggerEvent: input.triggerEvent,
      principalAmountCents: input.principalAmountCents,
      clientFeeCents: input.assessment.clientFeeCents,
      providerCostCents: input.assessment.providerCostCents,
      marginCents: input.assessment.marginCents,
      subsidyCents: input.assessment.subsidyCents,
      pricingRuleId: input.assessment.pricingRuleId,
      providerCostRuleId: input.assessment.providerCostRuleId,
      billingMode: input.assessment.billingMode,
      roundingMode: input.assessment.roundingMode,
      status: input.status,
      metadata: input.metadata ?? {}
    });
  }

  /**
   * Persists a subsidy_event row inside the caller's transaction. Only
   * called when the assessed subsidy is strictly positive AND the policy
   * decision is `approved`. The audit trail keeps both approved and
   * rejected subsidies in scope for Phase 6 reporting; Phase 3 only writes
   * approved ones because rejected operations short-circuit before any
   * provider side-effect.
   */
  async persistSubsidyEvent(
    sql: Sql,
    input: Omit<SubsidyEventInsertInput, 'policySnapshot'> & {
      policy: NegativeMarginPolicy;
      dailySubsidyTotalBeforeCents: Cents;
      monthlySubsidyTotalBeforeCents: Cents;
    }
  ): Promise<SubsidyEventRecord> {
    return this.subsidyEvents.insert(sql, {
      feeAssessmentId: input.feeAssessmentId,
      clientId: input.clientId,
      transactionType: input.transactionType,
      transactionId: input.transactionId,
      subsidyCents: input.subsidyCents,
      status: input.status,
      reason: input.reason,
      policySnapshot: {
        allowNegativeMargin: input.policy.allowNegativeMargin,
        maxNegativeMarginCentsPerTxn: input.policy.maxNegativeMarginCentsPerTxn,
        dailySubsidyLimitCents: input.policy.dailySubsidyLimitCents,
        monthlySubsidyLimitCents: input.policy.monthlySubsidyLimitCents,
        dailySubsidyTotalBeforeCents: input.dailySubsidyTotalBeforeCents,
        monthlySubsidyTotalBeforeCents: input.monthlySubsidyTotalBeforeCents
      }
    });
  }
}

/**
 * `[from, to)` UTC day window for aggregation purposes. We use UTC instead
 * of America/Sao_Paulo to avoid DST edges; the comparison column
 * `subsidy_events.created_at` is `timestamptz` so both reads and writes are
 * timezone-canonical.
 */
function dayWindow(now: Date): { from: Date; to: Date } {
  const from = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
  const to = new Date(from.getTime() + 24 * 60 * 60 * 1000);
  return { from, to };
}

function monthWindow(now: Date): { from: Date; to: Date } {
  const from = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1));
  const to = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 1));
  return { from, to };
}

/**
 * Re-exported helper that callers can use to distinguish rejection codes
 * coming from the pure calculator vs. the aggregate enforcement.
 */
export const EXTENDED_REJECTION_CODES = {
  notAllowed: PRICING_ERROR_CODES.negativeMarginNotAllowed,
  perTxnLimit: PRICING_ERROR_CODES.negativeMarginExceedsPerTxnLimit,
  dailyLimit: 'pricing_negative_margin_exceeds_daily_limit',
  monthlyLimit: 'pricing_negative_margin_exceeds_monthly_limit'
} as const;
