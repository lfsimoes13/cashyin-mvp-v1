/**
 * Public surface of the pricing module.
 *
 * Phase 2 shipped the pure calculator + types. Phase 3 adds the
 * persistence-aware {@link PricingService}, four repositories, and the
 * extended policy decision that includes daily/monthly aggregates from
 * `subsidy_events`. Integration with `CashoutService` (the actual consumer)
 * lands in this same PR; integration with `PaymentService` is Phase 4.
 */

export {
  calculateFee,
  calculateProviderCost,
  calculateMargin,
  calculateSubsidy,
  calculateMarginAndSubsidy,
  evaluateNegativeMarginPolicy,
  calculateProviderLiquidityRequired
} from './pricing.calculator.js';

export { PRICING_ERROR_CODES, invalidInput } from './pricing.errors.js';
export type { PricingErrorCode } from './pricing.errors.js';

export type {
  AppliedRule,
  BillingMode,
  Bps,
  Cents,
  FeeCalculationInput,
  FeeCalculationResult,
  FeeFormula,
  MarginAndSubsidy,
  NegativeMarginEvaluation,
  NegativeMarginPolicy,
  NegativeMarginPolicyInput,
  NegativeMarginRejectionCode,
  PricingOperationType,
  ProviderCostCalculationInput,
  ProviderCostCalculationResult,
  ProviderCostFormula,
  ProviderLiquidityRequirementInput,
  ProviderLiquidityRequirementResult,
  RoundingMode
} from './pricing.types.js';

export {
  PgPricingRuleRepository
} from './pricing-rule.repository.js';
export type {
  PricingRuleRecord,
  PricingRuleRepository,
  PricingRuleLookup
} from './pricing-rule.repository.js';

export {
  PgProviderCostRuleRepository
} from './provider-cost-rule.repository.js';
export type {
  ProviderCostRuleRecord,
  ProviderCostRuleRepository,
  ProviderCostRuleLookup
} from './provider-cost-rule.repository.js';

export {
  PgFeeAssessmentRepository
} from './fee-assessment.repository.js';
export type {
  FeeAssessmentInsertInput,
  FeeAssessmentRecord,
  FeeAssessmentRepository,
  FeeAssessmentStatus,
  FeeAssessmentTransactionType
} from './fee-assessment.repository.js';

export {
  PgSubsidyEventRepository
} from './subsidy-event.repository.js';
export type {
  SubsidyAggregateInput,
  SubsidyEventInsertInput,
  SubsidyEventRecord,
  SubsidyEventRepository,
  SubsidyEventStatus,
  SubsidyEventTransactionType
} from './subsidy-event.repository.js';

export { PricingService, EXTENDED_REJECTION_CODES } from './pricing.service.js';
export type {
  AssessCashoutInput,
  CashoutPricingAssessment,
  EvaluatePolicyAggregatesInput,
  ExtendedNegativeMarginRejectionCode,
  PersistAssessmentInput,
  PolicyDecisionWithAggregates
} from './pricing.service.js';
