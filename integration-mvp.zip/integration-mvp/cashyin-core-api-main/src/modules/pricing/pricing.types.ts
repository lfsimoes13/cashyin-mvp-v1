/**
 * Pricing domain types.
 *
 * These types model the foundation introduced by `migrations/0003_pricing_and_provider_costs.sql`.
 * They are deliberately decoupled from persistence: the pricing calculator
 * (see `pricing.calculator.ts`) consumes pure values and returns deterministic
 * results so the engine can be unit-tested without a database.
 *
 * Money & percentage conventions (enforced everywhere in this module):
 * - All monetary fields are integer cents stored as `number`. Callers must
 *   round at the boundary; the calculator rejects non-integer inputs.
 * - Percentages use INTEGER basis points (`100 bps = 1%`). The calculator
 *   performs the `amount * bps / 10000` multiplication using `bigint`
 *   internally to remain safe even when the intermediate product exceeds
 *   `Number.MAX_SAFE_INTEGER`.
 * - `marginCents` is the ONLY signed value in the domain: it may be negative
 *   when the client fee is below the provider cost (subsidy scenario).
 */

import type { OperationType } from '../../providers/contracts/provider-types.js';

/**
 * Integer cents. Non-negative for every public field except
 * {@link MarginAndSubsidy.marginCents}.
 */
export type Cents = number;

/**
 * Basis points (1/100 of a percent). 100 bps = 1%.
 * Always a non-negative integer.
 */
export type Bps = number;

/**
 * How the client fee is settled against the client account.
 *
 * `deduct_from_settlement` — net the fee out of the principal credited
 *   to the client on cash-in.
 * `add_to_debit` — debit `principal + fee` on cash-out.
 * `postpaid_invoice` — accumulate the fee as a receivable for later billing.
 * `waived` — no fee charged to the client (typically combined with a subsidy).
 * `separate_balance_debit` — fee posted as an independent ledger debit so
 *   reporting can split principal from fees on the same operation.
 */
export type BillingMode =
  | 'deduct_from_settlement'
  | 'add_to_debit'
  | 'postpaid_invoice'
  | 'waived'
  | 'separate_balance_debit';

/**
 * Explicit rounding strategy applied to the variable-fee/cost component.
 * The choice MUST come from configuration; the calculator never applies a
 * silent default.
 */
export type RoundingMode = 'floor' | 'ceil' | 'round_half_up';

/**
 * Classifies which branch of the formula produced the returned fee. Useful
 * for audit logs and assessing whether a pricing rule is reaching its
 * configured bounds in production.
 */
export type AppliedRule =
  | 'zero'
  | 'fixed_only'
  | 'variable_only'
  | 'fixed_plus_variable'
  | 'min_floor'
  | 'max_ceiling';

/**
 * Commercial fee formula applied to compute the client fee.
 */
export type FeeFormula = {
  fixedFeeCents: Cents;
  variableFeeBps: Bps;
  minFeeCents: Cents | null;
  maxFeeCents: Cents | null;
  roundingMode: RoundingMode;
  billingMode: BillingMode;
};

/**
 * Cost formula applied to compute the provider's expected charge to CashYin.
 *
 * `chargedFromProviderBalance` distinguishes providers that net their fee
 * from the same operational balance used for the principal (so the cash-out
 * liquidity reservation must cover `principal + cost`) from providers that
 * bill out-of-band.
 */
export type ProviderCostFormula = {
  fixedCostCents: Cents;
  variableCostBps: Bps;
  minCostCents: Cents | null;
  maxCostCents: Cents | null;
  roundingMode: RoundingMode;
  chargedFromProviderBalance: boolean;
};

export type FeeCalculationInput = {
  amountCents: Cents;
  formula: FeeFormula;
};

export type FeeCalculationResult = {
  clientFeeCents: Cents;
  appliedRule: AppliedRule;
};

export type ProviderCostCalculationInput = {
  amountCents: Cents;
  formula: ProviderCostFormula;
};

export type ProviderCostCalculationResult = {
  providerCostCents: Cents;
  appliedRule: AppliedRule;
};

export type MarginAndSubsidy = {
  /** Signed: positive = CashYin revenue, negative = subsidy. */
  marginCents: number;
  /** `max(0, providerCostCents - clientFeeCents)`. Always non-negative. */
  subsidyCents: Cents;
};

/**
 * Negative-margin policy attached to a pricing rule. Limits beyond
 * `maxNegativeMarginCentsPerTxn` are modelled here but NOT enforced by the
 * calculator: daily/monthly aggregation belongs to Phase 3 once the
 * subsidy aggregation repository is introduced.
 */
export type NegativeMarginPolicy = {
  allowNegativeMargin: boolean;
  maxNegativeMarginCentsPerTxn: Cents | null;
  dailySubsidyLimitCents: Cents | null;
  monthlySubsidyLimitCents: Cents | null;
};

export type NegativeMarginRejectionCode =
  | 'pricing_negative_margin_not_allowed'
  | 'pricing_negative_margin_exceeds_per_txn_limit';

/**
 * Outcome of {@link evaluateNegativeMarginPolicy}. This is a *deterministic*
 * domain result, not a thrown error: callers integrate the rejection into
 * their own transactional decision (e.g. block the cash-out before reserving
 * liquidity).
 */
export type NegativeMarginEvaluation =
  | {
      kind: 'approved';
      subsidyCents: Cents;
    }
  | {
      kind: 'rejected';
      code: NegativeMarginRejectionCode;
      subsidyCents: Cents;
      reason: string;
    };

export type NegativeMarginPolicyInput = {
  clientFeeCents: Cents;
  providerCostCents: Cents;
  policy: NegativeMarginPolicy;
};

export type ProviderLiquidityRequirementInput = {
  amountCents: Cents;
  expectedProviderCostCents: Cents;
  chargedFromProviderBalance: boolean;
};

export type ProviderLiquidityRequirementResult = {
  providerLiquidityRequiredCents: Cents;
  components: {
    principal: Cents;
    providerCost: Cents;
  };
};

/**
 * Re-exported here so consumers of `src/modules/pricing` do not have to
 * reach into the provider contracts module for the discriminator. Kept as
 * an explicit type alias rather than a new union so the two sources of
 * truth stay in lock-step.
 */
export type PricingOperationType = OperationType;
