import type { Sql } from '../../shared/db/sql.js';
import type { Cents } from './pricing.types.js';

export type SubsidyEventStatus = 'approved' | 'rejected' | 'reversed';
export type SubsidyEventTransactionType = 'cash_in' | 'cashout';

export type SubsidyEventInsertInput = {
  feeAssessmentId: string;
  clientId: string;
  transactionType: SubsidyEventTransactionType;
  transactionId: string;
  subsidyCents: Cents;
  policySnapshot: Record<string, unknown>;
  status: SubsidyEventStatus;
  reason: string | null;
};

export type SubsidyEventRecord = {
  id: string;
  feeAssessmentId: string;
  clientId: string;
  transactionType: SubsidyEventTransactionType;
  transactionId: string;
  subsidyCents: Cents;
  status: SubsidyEventStatus;
  reason: string | null;
  createdAt: Date;
};

type SubsidyEventRow = {
  id: string;
  fee_assessment_id: string;
  client_id: string;
  transaction_type: SubsidyEventTransactionType;
  transaction_id: string;
  subsidy_cents: string;
  status: SubsidyEventStatus;
  reason: string | null;
  created_at: Date;
};

function mapRow(row: SubsidyEventRow): SubsidyEventRecord {
  return {
    id: row.id,
    feeAssessmentId: row.fee_assessment_id,
    clientId: row.client_id,
    transactionType: row.transaction_type,
    transactionId: row.transaction_id,
    subsidyCents: Number(row.subsidy_cents),
    status: row.status,
    reason: row.reason,
    createdAt: row.created_at
  };
}

export type SubsidyAggregateInput = {
  clientId: string;
  from: Date;
  to: Date;
};

export interface SubsidyEventRepository {
  insert(sql: Sql, input: SubsidyEventInsertInput): Promise<SubsidyEventRecord>;
  /**
   * Returns the sum of `subsidy_cents` for approved subsidy events of the
   * given client within `[from, to)`. Returns `0` when there are no rows.
   *
   * The aggregation is used by {@link PricingService.evaluatePolicyWithAggregates}
   * to enforce the per-day and per-month subsidy caps configured on a
   * pricing rule. We deliberately do not memoise the result: the caller
   * runs inside the same transaction as the prospective subsidy write, so
   * each call must observe the latest committed-but-not-yet-flushed
   * subsidies for that client.
   */
  sumApprovedBetween(sql: Sql, input: SubsidyAggregateInput): Promise<Cents>;
}

export class PgSubsidyEventRepository implements SubsidyEventRepository {
  async insert(sql: Sql, input: SubsidyEventInsertInput): Promise<SubsidyEventRecord> {
    const result = await sql.query<SubsidyEventRow>(
      `INSERT INTO subsidy_events
         (fee_assessment_id, client_id, transaction_type, transaction_id, subsidy_cents,
          policy_snapshot, status, reason)
       VALUES ($1, $2, $3, $4, $5, $6::jsonb, $7::subsidy_event_status, $8)
       RETURNING id, fee_assessment_id, client_id, transaction_type, transaction_id,
                 subsidy_cents, status, reason, created_at`,
      [
        input.feeAssessmentId,
        input.clientId,
        input.transactionType,
        input.transactionId,
        input.subsidyCents,
        JSON.stringify(input.policySnapshot),
        input.status,
        input.reason
      ]
    );
    const row = result.rows[0];
    if (!row) {
      throw new Error('Failed to insert subsidy_event row');
    }
    return mapRow(row);
  }

  async sumApprovedBetween(sql: Sql, input: SubsidyAggregateInput): Promise<Cents> {
    const result = await sql.query<{ total: string | null }>(
      `SELECT COALESCE(SUM(subsidy_cents), 0)::text AS total
         FROM subsidy_events
        WHERE client_id = $1
          AND status = 'approved'
          AND created_at >= $2
          AND created_at < $3`,
      [input.clientId, input.from, input.to]
    );
    const total = result.rows[0]?.total ?? '0';
    return Number(total);
  }
}
