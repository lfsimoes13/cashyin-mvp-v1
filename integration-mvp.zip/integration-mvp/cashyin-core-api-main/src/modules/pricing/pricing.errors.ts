/**
 * Pricing domain error codes.
 *
 * Two classes of codes exist here:
 *
 * 1. `pricing_invalid_input` — a programmer / configuration error.
 *    The calculator throws an {@link AppError} so the bug surfaces loudly
 *    instead of silently producing a wrong fee. Examples: non-integer
 *    cents, negative basis points, `maxFeeCents < minFeeCents`.
 *
 * 2. `pricing_negative_margin_not_allowed`
 *    `pricing_negative_margin_exceeds_per_txn_limit` — these are
 *    **business decisions**, not exceptions. They are returned as part of
 *    {@link NegativeMarginEvaluation} so callers can take an explicit branch
 *    (e.g. reject the cash-out, retry with a different plan, escalate to
 *    admin review) without unwinding the call stack.
 */

import { AppError } from '../../shared/errors/app-error.js';

export const PRICING_ERROR_CODES = {
  invalidInput: 'pricing_invalid_input',
  negativeMarginNotAllowed: 'pricing_negative_margin_not_allowed',
  negativeMarginExceedsPerTxnLimit: 'pricing_negative_margin_exceeds_per_txn_limit'
} as const;

export type PricingErrorCode = (typeof PRICING_ERROR_CODES)[keyof typeof PRICING_ERROR_CODES];

/**
 * Thrown for contract violations. Uses HTTP 400 because the input is a
 * shape/value mismatch, not an internal failure: pricing inputs come from
 * other CashYin services (and tests), and we want callers to fix the
 * caller, not retry blindly.
 */
export function invalidInput(message: string, details?: Record<string, unknown>): AppError {
  return new AppError(PRICING_ERROR_CODES.invalidInput, message, 400, details);
}
