import type { Sql } from '../../shared/db/sql.js';
import type { OperationType } from '../../providers/contracts/provider-types.js';
import type { BillingMode, Cents, RoundingMode } from './pricing.types.js';

export type FeeAssessmentTransactionType = 'cash_in' | 'cashout';
export type FeeAssessmentStatus = 'estimated' | 'posted' | 'cancelled' | 'reconciled';

export type FeeAssessmentInsertInput = {
  transactionType: FeeAssessmentTransactionType;
  transactionId: string;
  clientId: string;
  providerAccountId: string;
  operationType: OperationType;
  triggerEvent: string;
  principalAmountCents: Cents;
  clientFeeCents: Cents;
  providerCostCents: Cents;
  marginCents: number;
  subsidyCents: Cents;
  pricingRuleId: string | null;
  providerCostRuleId: string | null;
  billingMode: BillingMode;
  roundingMode: RoundingMode;
  status: FeeAssessmentStatus;
  metadata: Record<string, unknown>;
};

export type FeeAssessmentRecord = {
  id: string;
  transactionType: FeeAssessmentTransactionType;
  transactionId: string;
  clientId: string;
  providerAccountId: string;
  operationType: OperationType;
  triggerEvent: string;
  principalAmountCents: Cents;
  clientFeeCents: Cents;
  providerCostCents: Cents;
  marginCents: number;
  subsidyCents: Cents;
  pricingRuleId: string | null;
  providerCostRuleId: string | null;
  billingMode: BillingMode;
  roundingMode: RoundingMode;
  status: FeeAssessmentStatus;
  createdAt: Date;
  updatedAt: Date;
};

type FeeAssessmentRow = {
  id: string;
  transaction_type: FeeAssessmentTransactionType;
  transaction_id: string;
  client_id: string;
  provider_account_id: string;
  operation_type: OperationType;
  trigger_event: string;
  principal_amount_cents: string;
  client_fee_cents: string;
  provider_cost_cents: string;
  margin_cents: string;
  subsidy_cents: string;
  pricing_rule_id: string | null;
  provider_cost_rule_id: string | null;
  billing_mode: BillingMode;
  rounding_mode: RoundingMode;
  status: FeeAssessmentStatus;
  created_at: Date;
  updated_at: Date;
};

function mapRow(row: FeeAssessmentRow): FeeAssessmentRecord {
  return {
    id: row.id,
    transactionType: row.transaction_type,
    transactionId: row.transaction_id,
    clientId: row.client_id,
    providerAccountId: row.provider_account_id,
    operationType: row.operation_type,
    triggerEvent: row.trigger_event,
    principalAmountCents: Number(row.principal_amount_cents),
    clientFeeCents: Number(row.client_fee_cents),
    providerCostCents: Number(row.provider_cost_cents),
    marginCents: Number(row.margin_cents),
    subsidyCents: Number(row.subsidy_cents),
    pricingRuleId: row.pricing_rule_id,
    providerCostRuleId: row.provider_cost_rule_id,
    billingMode: row.billing_mode,
    roundingMode: row.rounding_mode,
    status: row.status,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}

export interface FeeAssessmentRepository {
  insert(sql: Sql, input: FeeAssessmentInsertInput): Promise<FeeAssessmentRecord>;
  findById(sql: Sql, id: string): Promise<FeeAssessmentRecord | null>;
  findByTransaction(
    sql: Sql,
    transactionType: FeeAssessmentTransactionType,
    transactionId: string,
    triggerEvent: string
  ): Promise<FeeAssessmentRecord | null>;
  /**
   * Updates the status of an existing fee_assessment row. Used by the
   * cash-in webhook handler to promote `estimated` → `posted` once the
   * provider confirms the payment, and (in future phases) by the cash-out
   * webhook handler to promote `estimated` → `posted` on completion.
   *
   * Returns the updated record, or `null` if no row exists with the given
   * id (the caller should treat that as a benign noop because it means a
   * duplicate webhook arrived before the fee_assessment was ever created,
   * which is captured separately via the UNIQUE constraint on
   * (transaction_type, transaction_id, trigger_event)).
   */
  updateStatus(
    sql: Sql,
    id: string,
    status: FeeAssessmentStatus
  ): Promise<FeeAssessmentRecord | null>;
}

export class PgFeeAssessmentRepository implements FeeAssessmentRepository {
  async insert(sql: Sql, input: FeeAssessmentInsertInput): Promise<FeeAssessmentRecord> {
    const result = await sql.query<FeeAssessmentRow>(
      `INSERT INTO fee_assessments
         (transaction_type, transaction_id, client_id, provider_account_id, operation_type,
          trigger_event, principal_amount_cents, client_fee_cents, provider_cost_cents,
          margin_cents, subsidy_cents, pricing_rule_id, provider_cost_rule_id,
          billing_mode, rounding_mode, status, metadata)
       VALUES ($1, $2, $3, $4, $5::operation_type, $6, $7, $8, $9, $10, $11,
               $12, $13, $14::billing_mode, $15::rounding_mode, $16::fee_assessment_status, $17::jsonb)
       RETURNING id, transaction_type, transaction_id, client_id, provider_account_id,
                 operation_type, trigger_event, principal_amount_cents, client_fee_cents,
                 provider_cost_cents, margin_cents, subsidy_cents, pricing_rule_id,
                 provider_cost_rule_id, billing_mode, rounding_mode, status, created_at, updated_at`,
      [
        input.transactionType,
        input.transactionId,
        input.clientId,
        input.providerAccountId,
        input.operationType,
        input.triggerEvent,
        input.principalAmountCents,
        input.clientFeeCents,
        input.providerCostCents,
        input.marginCents,
        input.subsidyCents,
        input.pricingRuleId,
        input.providerCostRuleId,
        input.billingMode,
        input.roundingMode,
        input.status,
        JSON.stringify(input.metadata)
      ]
    );
    const row = result.rows[0];
    if (!row) {
      throw new Error('Failed to insert fee_assessment row');
    }
    return mapRow(row);
  }

  async findById(sql: Sql, id: string): Promise<FeeAssessmentRecord | null> {
    const result = await sql.query<FeeAssessmentRow>(
      `SELECT id, transaction_type, transaction_id, client_id, provider_account_id,
              operation_type, trigger_event, principal_amount_cents, client_fee_cents,
              provider_cost_cents, margin_cents, subsidy_cents, pricing_rule_id,
              provider_cost_rule_id, billing_mode, rounding_mode, status, created_at, updated_at
         FROM fee_assessments
        WHERE id = $1`,
      [id]
    );
    const row = result.rows[0];
    return row ? mapRow(row) : null;
  }

  async findByTransaction(
    sql: Sql,
    transactionType: FeeAssessmentTransactionType,
    transactionId: string,
    triggerEvent: string
  ): Promise<FeeAssessmentRecord | null> {
    const result = await sql.query<FeeAssessmentRow>(
      `SELECT id, transaction_type, transaction_id, client_id, provider_account_id,
              operation_type, trigger_event, principal_amount_cents, client_fee_cents,
              provider_cost_cents, margin_cents, subsidy_cents, pricing_rule_id,
              provider_cost_rule_id, billing_mode, rounding_mode, status, created_at, updated_at
         FROM fee_assessments
        WHERE transaction_type = $1
          AND transaction_id = $2
          AND trigger_event = $3`,
      [transactionType, transactionId, triggerEvent]
    );
    const row = result.rows[0];
    return row ? mapRow(row) : null;
  }

  async updateStatus(
    sql: Sql,
    id: string,
    status: FeeAssessmentStatus
  ): Promise<FeeAssessmentRecord | null> {
    const result = await sql.query<FeeAssessmentRow>(
      `UPDATE fee_assessments
          SET status = $2::fee_assessment_status,
              updated_at = now()
        WHERE id = $1
        RETURNING id, transaction_type, transaction_id, client_id, provider_account_id,
                  operation_type, trigger_event, principal_amount_cents, client_fee_cents,
                  provider_cost_cents, margin_cents, subsidy_cents, pricing_rule_id,
                  provider_cost_rule_id, billing_mode, rounding_mode, status,
                  created_at, updated_at`,
      [id, status]
    );
    const row = result.rows[0];
    return row ? mapRow(row) : null;
  }
}
