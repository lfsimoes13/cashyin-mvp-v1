import type { Sql } from '../../shared/db/sql.js';
import type { OperationType } from '../../providers/contracts/provider-types.js';
import type { Cents, Bps, RoundingMode } from './pricing.types.js';

export type ProviderCostRuleRecord = {
  id: string;
  providerAccountId: string;
  operationType: OperationType;
  triggerEvent: string;
  fixedCostCents: Cents;
  variableCostBps: Bps;
  minCostCents: Cents | null;
  maxCostCents: Cents | null;
  chargedFromProviderBalance: boolean;
  roundingMode: RoundingMode;
};

export type ProviderCostRuleLookup = {
  providerAccountId: string;
  operationType: OperationType;
  triggerEvent: string;
};

type ProviderCostRuleRow = {
  id: string;
  provider_account_id: string;
  operation_type: OperationType;
  trigger_event: string;
  fixed_cost_cents: string;
  variable_cost_bps: number;
  min_cost_cents: string | null;
  max_cost_cents: string | null;
  charged_from_provider_balance: boolean;
  rounding_mode: RoundingMode;
};

function mapRow(row: ProviderCostRuleRow): ProviderCostRuleRecord {
  return {
    id: row.id,
    providerAccountId: row.provider_account_id,
    operationType: row.operation_type,
    triggerEvent: row.trigger_event,
    fixedCostCents: Number(row.fixed_cost_cents),
    variableCostBps: row.variable_cost_bps,
    minCostCents: row.min_cost_cents === null ? null : Number(row.min_cost_cents),
    maxCostCents: row.max_cost_cents === null ? null : Number(row.max_cost_cents),
    chargedFromProviderBalance: row.charged_from_provider_balance,
    roundingMode: row.rounding_mode
  };
}

export interface ProviderCostRuleRepository {
  findActiveForProviderAccount(
    sql: Sql,
    lookup: ProviderCostRuleLookup
  ): Promise<ProviderCostRuleRecord | null>;
}

export class PgProviderCostRuleRepository implements ProviderCostRuleRepository {
  async findActiveForProviderAccount(
    sql: Sql,
    lookup: ProviderCostRuleLookup
  ): Promise<ProviderCostRuleRecord | null> {
    const result = await sql.query<ProviderCostRuleRow>(
      `SELECT id,
              provider_account_id,
              operation_type,
              trigger_event,
              fixed_cost_cents,
              variable_cost_bps,
              min_cost_cents,
              max_cost_cents,
              charged_from_provider_balance,
              rounding_mode
         FROM provider_cost_rules
        WHERE provider_account_id = $1
          AND operation_type = $2::operation_type
          AND trigger_event = $3
          AND status = 'active'
          AND (valid_to IS NULL OR valid_to > now())
        ORDER BY valid_from DESC
        LIMIT 1`,
      [lookup.providerAccountId, lookup.operationType, lookup.triggerEvent]
    );
    const row = result.rows[0];
    return row ? mapRow(row) : null;
  }
}
