import type { Sql } from '../../shared/db/sql.js';
import type { OperationType } from '../../providers/contracts/provider-types.js';
import type {
  BillingMode,
  Cents,
  Bps,
  RoundingMode
} from './pricing.types.js';

/**
 * Concrete row shape returned by {@link PricingRuleRepository.findActiveForClient}.
 *
 * The repository resolves the lookup by joining three tables:
 *   client_pricing_assignments → pricing_plan_versions → pricing_rules
 *
 * and only returns rows whose entire chain is active and currently valid:
 *   - assignment.status='active' AND assignment.valid_to IS NULL
 *   - plan_version.status='active' AND (plan_version.valid_to IS NULL OR now() < valid_to)
 *   - matching rule.operation_type AND rule.trigger_event
 *
 * Returning `null` when nothing matches is deliberate: callers (notably the
 * `PricingService`) treat the absence of a pricing rule as a no-op so that
 * clients without configured pricing keep working through Phase 3.
 */
export type PricingRuleRecord = {
  id: string;
  pricingPlanVersionId: string;
  operationType: OperationType;
  triggerEvent: string;
  fixedFeeCents: Cents;
  variableFeeBps: Bps;
  minFeeCents: Cents | null;
  maxFeeCents: Cents | null;
  billingMode: BillingMode;
  roundingMode: RoundingMode;
  allowNegativeMargin: boolean;
  maxNegativeMarginCentsPerTxn: Cents | null;
  dailySubsidyLimitCents: Cents | null;
  monthlySubsidyLimitCents: Cents | null;
};

export type PricingRuleLookup = {
  clientId: string;
  operationType: OperationType;
  triggerEvent: string;
};

type PricingRuleRow = {
  id: string;
  pricing_plan_version_id: string;
  operation_type: OperationType;
  trigger_event: string;
  fixed_fee_cents: string;
  variable_fee_bps: number;
  min_fee_cents: string | null;
  max_fee_cents: string | null;
  billing_mode: BillingMode;
  rounding_mode: RoundingMode;
  allow_negative_margin: boolean;
  max_negative_margin_cents_per_txn: string | null;
  daily_subsidy_limit_cents: string | null;
  monthly_subsidy_limit_cents: string | null;
};

function mapRow(row: PricingRuleRow): PricingRuleRecord {
  return {
    id: row.id,
    pricingPlanVersionId: row.pricing_plan_version_id,
    operationType: row.operation_type,
    triggerEvent: row.trigger_event,
    fixedFeeCents: Number(row.fixed_fee_cents),
    variableFeeBps: row.variable_fee_bps,
    minFeeCents: row.min_fee_cents === null ? null : Number(row.min_fee_cents),
    maxFeeCents: row.max_fee_cents === null ? null : Number(row.max_fee_cents),
    billingMode: row.billing_mode,
    roundingMode: row.rounding_mode,
    allowNegativeMargin: row.allow_negative_margin,
    maxNegativeMarginCentsPerTxn:
      row.max_negative_margin_cents_per_txn === null
        ? null
        : Number(row.max_negative_margin_cents_per_txn),
    dailySubsidyLimitCents:
      row.daily_subsidy_limit_cents === null
        ? null
        : Number(row.daily_subsidy_limit_cents),
    monthlySubsidyLimitCents:
      row.monthly_subsidy_limit_cents === null
        ? null
        : Number(row.monthly_subsidy_limit_cents)
  };
}

export interface PricingRuleRepository {
  findActiveForClient(sql: Sql, lookup: PricingRuleLookup): Promise<PricingRuleRecord | null>;
}

export class PgPricingRuleRepository implements PricingRuleRepository {
  async findActiveForClient(
    sql: Sql,
    lookup: PricingRuleLookup
  ): Promise<PricingRuleRecord | null> {
    const result = await sql.query<PricingRuleRow>(
      `SELECT pr.id,
              pr.pricing_plan_version_id,
              pr.operation_type,
              pr.trigger_event,
              pr.fixed_fee_cents,
              pr.variable_fee_bps,
              pr.min_fee_cents,
              pr.max_fee_cents,
              pr.billing_mode,
              pr.rounding_mode,
              pr.allow_negative_margin,
              pr.max_negative_margin_cents_per_txn,
              pr.daily_subsidy_limit_cents,
              pr.monthly_subsidy_limit_cents
         FROM pricing_rules pr
         JOIN pricing_plan_versions ppv
           ON ppv.id = pr.pricing_plan_version_id
         JOIN client_pricing_assignments cpa
           ON cpa.pricing_plan_version_id = ppv.id
        WHERE cpa.client_id = $1
          AND cpa.operation_type = $2::operation_type
          AND cpa.status = 'active'
          AND cpa.valid_to IS NULL
          AND ppv.status = 'active'
          AND (ppv.valid_to IS NULL OR ppv.valid_to > now())
          AND pr.operation_type = $2::operation_type
          AND pr.trigger_event = $3
        ORDER BY cpa.valid_from DESC
        LIMIT 1`,
      [lookup.clientId, lookup.operationType, lookup.triggerEvent]
    );
    const row = result.rows[0];
    return row ? mapRow(row) : null;
  }
}
