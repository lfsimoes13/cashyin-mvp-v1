/**
 * Pure pricing calculator.
 *
 * Every function in this file is deterministic, side-effect-free and
 * dependency-free. The goal is twofold:
 *
 *  1. Make pricing exhaustively unit-testable without spinning up a DB,
 *     mocking providers, or running a webhook simulator.
 *  2. Centralise the financial invariants (integer cents, basis-point
 *     percentages, explicit rounding, deterministic negative-margin
 *     decisions) so the transactional services that will eventually call
 *     into this module (Phase 3 cash-out, Phase 4 cash-in paid) cannot
 *     accidentally reinvent them.
 *
 * Numerical correctness:
 *   - Cents are passed and returned as `number`, but the variable component
 *     `amountCents * variableBps / 10000` is computed using `bigint` to
 *     remove any risk of intermediate-product overflow against
 *     `Number.MAX_SAFE_INTEGER` (2^53 - 1). The final BigInt result is
 *     re-checked against MAX_SAFE_INTEGER before conversion back to
 *     `number`, so a fee that cannot be represented exactly raises
 *     `pricing_invalid_input` instead of silently truncating.
 *   - Rounding is performed in integer arithmetic. `round_half_up` is
 *     evaluated as `floor((2r + d) / 2d)`, which is exact for ties: a value
 *     of exactly 0.5 rounds up, matching the contract documented in
 *     `docs/tariff-system-plan.md`.
 */

import type {
  AppliedRule,
  Cents,
  FeeCalculationInput,
  FeeCalculationResult,
  FeeFormula,
  MarginAndSubsidy,
  NegativeMarginEvaluation,
  NegativeMarginPolicyInput,
  ProviderCostCalculationInput,
  ProviderCostCalculationResult,
  ProviderCostFormula,
  ProviderLiquidityRequirementInput,
  ProviderLiquidityRequirementResult,
  RoundingMode
} from './pricing.types.js';
import { PRICING_ERROR_CODES, invalidInput } from './pricing.errors.js';

const BPS_DENOMINATOR = 10_000n;
const MAX_SAFE_INTEGER_BIG = BigInt(Number.MAX_SAFE_INTEGER);

/**
 * Computes the commercial fee CashYin charges the client.
 */
export function calculateFee(input: FeeCalculationInput): FeeCalculationResult {
  const { amountCents, formula } = input;
  ensureNonNegativeInteger(amountCents, 'amountCents');
  validateFeeFormula(formula);

  const variableCents = computeVariableComponent(
    amountCents,
    formula.variableFeeBps,
    formula.roundingMode
  );

  return clampWithBounds({
    fixedCents: formula.fixedFeeCents,
    variableBps: formula.variableFeeBps,
    rawCents: addCents(formula.fixedFeeCents, variableCents, 'clientFeeCents'),
    minCents: formula.minFeeCents,
    maxCents: formula.maxFeeCents
  });
}

/**
 * Computes the cost the provider will charge CashYin. Structurally identical
 * to {@link calculateFee} but kept as a separate function so the two domains
 * (commercial vs. operational) cannot accidentally drift.
 */
export function calculateProviderCost(
  input: ProviderCostCalculationInput
): ProviderCostCalculationResult {
  const { amountCents, formula } = input;
  ensureNonNegativeInteger(amountCents, 'amountCents');
  validateProviderCostFormula(formula);

  const variableCents = computeVariableComponent(
    amountCents,
    formula.variableCostBps,
    formula.roundingMode
  );

  const clamped = clampWithBounds({
    fixedCents: formula.fixedCostCents,
    variableBps: formula.variableCostBps,
    rawCents: addCents(formula.fixedCostCents, variableCents, 'providerCostCents'),
    minCents: formula.minCostCents,
    maxCents: formula.maxCostCents
  });

  return {
    providerCostCents: clamped.clientFeeCents,
    appliedRule: clamped.appliedRule
  };
}

/**
 * `clientFeeCents - providerCostCents`. May be negative when the client pays
 * less than the provider charges (subsidy scenario).
 */
export function calculateMargin(clientFeeCents: Cents, providerCostCents: Cents): number {
  ensureNonNegativeInteger(clientFeeCents, 'clientFeeCents');
  ensureNonNegativeInteger(providerCostCents, 'providerCostCents');
  return clientFeeCents - providerCostCents;
}

/**
 * `max(0, providerCostCents - clientFeeCents)`. Always non-negative.
 */
export function calculateSubsidy(clientFeeCents: Cents, providerCostCents: Cents): Cents {
  ensureNonNegativeInteger(clientFeeCents, 'clientFeeCents');
  ensureNonNegativeInteger(providerCostCents, 'providerCostCents');
  return providerCostCents > clientFeeCents ? providerCostCents - clientFeeCents : 0;
}

/**
 * Combined helper exposed for callers that need both values without paying
 * the validation cost twice.
 */
export function calculateMarginAndSubsidy(
  clientFeeCents: Cents,
  providerCostCents: Cents
): MarginAndSubsidy {
  ensureNonNegativeInteger(clientFeeCents, 'clientFeeCents');
  ensureNonNegativeInteger(providerCostCents, 'providerCostCents');
  const marginCents = clientFeeCents - providerCostCents;
  const subsidyCents = marginCents < 0 ? -marginCents : 0;
  return { marginCents, subsidyCents };
}

/**
 * Evaluates whether a (potentially) negative margin is allowed by the
 * configured policy. Returns a deterministic result instead of throwing so
 * callers can branch on the decision without try/catch in their happy path.
 *
 * Daily / monthly subsidy limits are modelled in {@link NegativeMarginPolicy}
 * but NOT enforced here: they require aggregation over historical
 * `subsidy_events`, which is out of scope for Phase 2. The fields are
 * intentionally part of the input so Phase 3 can wire enforcement without
 * changing the function signature.
 */
export function evaluateNegativeMarginPolicy(
  input: NegativeMarginPolicyInput
): NegativeMarginEvaluation {
  const { clientFeeCents, providerCostCents, policy } = input;
  ensureNonNegativeInteger(clientFeeCents, 'clientFeeCents');
  ensureNonNegativeInteger(providerCostCents, 'providerCostCents');
  validateNegativeMarginPolicy(policy);

  const subsidyCents = providerCostCents > clientFeeCents ? providerCostCents - clientFeeCents : 0;

  if (subsidyCents === 0) {
    return { kind: 'approved', subsidyCents: 0 };
  }

  if (!policy.allowNegativeMargin) {
    return {
      kind: 'rejected',
      code: PRICING_ERROR_CODES.negativeMarginNotAllowed,
      subsidyCents,
      reason:
        'Negative margin is not allowed by the configured pricing rule; ' +
        `subsidy would be ${subsidyCents} cents`
    };
  }

  if (
    policy.maxNegativeMarginCentsPerTxn !== null &&
    subsidyCents > policy.maxNegativeMarginCentsPerTxn
  ) {
    return {
      kind: 'rejected',
      code: PRICING_ERROR_CODES.negativeMarginExceedsPerTxnLimit,
      subsidyCents,
      reason:
        `Per-transaction subsidy of ${subsidyCents} cents exceeds the configured ` +
        `limit of ${policy.maxNegativeMarginCentsPerTxn} cents`
    };
  }

  return { kind: 'approved', subsidyCents };
}

/**
 * How much operational money must be held at the provider to safely run
 * this operation. Returns the principal plus the expected provider cost
 * only when the provider deducts its fee from the same balance.
 */
export function calculateProviderLiquidityRequired(
  input: ProviderLiquidityRequirementInput
): ProviderLiquidityRequirementResult {
  ensureNonNegativeInteger(input.amountCents, 'amountCents');
  ensureNonNegativeInteger(input.expectedProviderCostCents, 'expectedProviderCostCents');

  const providerCostComponent: Cents = input.chargedFromProviderBalance
    ? input.expectedProviderCostCents
    : 0;
  const required = addCents(
    input.amountCents,
    providerCostComponent,
    'providerLiquidityRequiredCents'
  );

  return {
    providerLiquidityRequiredCents: required,
    components: {
      principal: input.amountCents,
      providerCost: providerCostComponent
    }
  };
}

function computeVariableComponent(
  amountCents: Cents,
  variableBps: number,
  roundingMode: RoundingMode
): Cents {
  if (variableBps === 0 || amountCents === 0) {
    return 0;
  }

  const numerator = BigInt(amountCents) * BigInt(variableBps);
  const result = divideWithRounding(numerator, BPS_DENOMINATOR, roundingMode);

  if (result > MAX_SAFE_INTEGER_BIG) {
    throw invalidInput(
      'Variable fee/cost overflows Number.MAX_SAFE_INTEGER; reduce amount or bps',
      { amountCents, variableBps, computed: result.toString() }
    );
  }

  return Number(result);
}

/**
 * Integer division `numerator / denominator` with explicit rounding.
 *
 * - `floor` is plain BigInt division (truncation toward zero; both operands
 *   are non-negative here, so this is mathematical floor).
 * - `ceil` adds `denominator - 1` before the divide.
 * - `round_half_up` evaluates `floor((2n + d) / 2d)`. Algebra:
 *     n/d + 1/2  ==  (2n + d) / (2d)
 *   so the floor of that expression is exactly half-up for non-negative
 *   inputs. Ties (`n*2 == k*d`) round up because adding `d` then dividing
 *   by `2d` lands on the next integer.
 */
function divideWithRounding(
  numerator: bigint,
  denominator: bigint,
  mode: RoundingMode
): bigint {
  switch (mode) {
    case 'floor':
      return numerator / denominator;
    case 'ceil':
      return (numerator + denominator - 1n) / denominator;
    case 'round_half_up':
      return (numerator * 2n + denominator) / (denominator * 2n);
  }
}

type ClampInput = {
  fixedCents: Cents;
  variableBps: number;
  rawCents: Cents;
  minCents: Cents | null;
  maxCents: Cents | null;
};

function clampWithBounds(input: ClampInput): FeeCalculationResult {
  let final = input.rawCents;
  let appliedRule: AppliedRule = classifyFormulaBranch(input.fixedCents, input.variableBps);

  if (input.minCents !== null && final < input.minCents) {
    final = input.minCents;
    appliedRule = 'min_floor';
  }
  if (input.maxCents !== null && final > input.maxCents) {
    final = input.maxCents;
    appliedRule = 'max_ceiling';
  }

  return { clientFeeCents: final, appliedRule };
}

function classifyFormulaBranch(fixedCents: Cents, variableBps: number): AppliedRule {
  if (fixedCents > 0 && variableBps > 0) return 'fixed_plus_variable';
  if (fixedCents > 0) return 'fixed_only';
  if (variableBps > 0) return 'variable_only';
  return 'zero';
}

function validateFeeFormula(formula: FeeFormula): void {
  ensureNonNegativeInteger(formula.fixedFeeCents, 'formula.fixedFeeCents');
  ensureNonNegativeInteger(formula.variableFeeBps, 'formula.variableFeeBps');
  if (formula.minFeeCents !== null) {
    ensureNonNegativeInteger(formula.minFeeCents, 'formula.minFeeCents');
  }
  if (formula.maxFeeCents !== null) {
    ensureNonNegativeInteger(formula.maxFeeCents, 'formula.maxFeeCents');
  }
  if (
    formula.minFeeCents !== null &&
    formula.maxFeeCents !== null &&
    formula.maxFeeCents < formula.minFeeCents
  ) {
    throw invalidInput(
      'formula.maxFeeCents must be greater than or equal to formula.minFeeCents',
      { minFeeCents: formula.minFeeCents, maxFeeCents: formula.maxFeeCents }
    );
  }
}

function validateProviderCostFormula(formula: ProviderCostFormula): void {
  ensureNonNegativeInteger(formula.fixedCostCents, 'formula.fixedCostCents');
  ensureNonNegativeInteger(formula.variableCostBps, 'formula.variableCostBps');
  if (formula.minCostCents !== null) {
    ensureNonNegativeInteger(formula.minCostCents, 'formula.minCostCents');
  }
  if (formula.maxCostCents !== null) {
    ensureNonNegativeInteger(formula.maxCostCents, 'formula.maxCostCents');
  }
  if (
    formula.minCostCents !== null &&
    formula.maxCostCents !== null &&
    formula.maxCostCents < formula.minCostCents
  ) {
    throw invalidInput(
      'formula.maxCostCents must be greater than or equal to formula.minCostCents',
      { minCostCents: formula.minCostCents, maxCostCents: formula.maxCostCents }
    );
  }
}

function validateNegativeMarginPolicy(
  policy: NegativeMarginPolicyInput['policy']
): void {
  if (policy.maxNegativeMarginCentsPerTxn !== null) {
    ensureNonNegativeInteger(
      policy.maxNegativeMarginCentsPerTxn,
      'policy.maxNegativeMarginCentsPerTxn'
    );
  }
  if (policy.dailySubsidyLimitCents !== null) {
    ensureNonNegativeInteger(policy.dailySubsidyLimitCents, 'policy.dailySubsidyLimitCents');
  }
  if (policy.monthlySubsidyLimitCents !== null) {
    ensureNonNegativeInteger(
      policy.monthlySubsidyLimitCents,
      'policy.monthlySubsidyLimitCents'
    );
  }
}

function ensureNonNegativeInteger(value: number, label: string): void {
  if (typeof value !== 'number' || !Number.isFinite(value)) {
    throw invalidInput(`${label} must be a finite number`, { value });
  }
  if (!Number.isInteger(value)) {
    throw invalidInput(`${label} must be an integer (received ${value})`, { value });
  }
  if (value < 0) {
    throw invalidInput(`${label} must be non-negative (received ${value})`, { value });
  }
  if (value > Number.MAX_SAFE_INTEGER) {
    throw invalidInput(
      `${label} exceeds Number.MAX_SAFE_INTEGER and cannot be represented safely`,
      { value }
    );
  }
}

/**
 * Adds two non-negative cent values and refuses to silently overflow
 * `Number.MAX_SAFE_INTEGER`. Both addends are already validated by their
 * callers; this guard exists because two safe-range values can still sum
 * past the safe range.
 */
function addCents(a: Cents, b: Cents, label: string): Cents {
  const sum = a + b;
  if (sum > Number.MAX_SAFE_INTEGER) {
    throw invalidInput(`${label} sum exceeds Number.MAX_SAFE_INTEGER`, { a, b });
  }
  return sum;
}
