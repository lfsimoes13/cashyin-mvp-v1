import type { FastifyInstance } from 'fastify';
import { env } from '../../shared/config/env.js';
import { AppError } from '../../shared/errors/app-error.js';
import { AUTH_SCOPES } from '../../shared/auth/auth-scopes.js';
import type { AuthPreHandlers } from '../../modules/auth/auth-enforcement.js';
import { createCashInBodySchema } from './payment.schemas.js';
import type { PaymentService } from './payment.service.js';

export type PaymentRoutesDeps = {
  paymentService: PaymentService;
  /**
   * Auth preHandler bundle. `requireClientAuth` enforces the Bearer
   * credential (so handlers can rely on `request.client.clientId` and never
   * validate a body-supplied `client_id`); `resolveAuthContext` populates
   * `request.authContext`; `requireScope` applies the per-route scope guard
   * staged by `AUTH_ENFORCEMENT_MODE`.
   */
  auth: AuthPreHandlers;
};

export async function registerPaymentRoutes(
  app: FastifyInstance,
  deps: PaymentRoutesDeps
): Promise<void> {
  app.post(
    '/v1/pix/cash-in/qrcode',
    {
      preHandler: [
        deps.auth.authenticate,
        deps.auth.resolveAuthContext,
        deps.auth.requireScope(AUTH_SCOPES.PIX_CASH_IN_CREATE)
      ],
      // Per-route rate limit override. QR Code creation is the high-volume
      // cash-in entry point; clients legitimately fire many requests/s in
      // checkout flows. The global limit (RATE_LIMIT_MAX) is intentionally
      // lower for unknown/unauthenticated endpoints; here we give each
      // authenticated client a larger burst budget while still capping
      // runaway clients individually.
      config: {
        rateLimit: {
          max: env.RATE_LIMIT_QRCODE_MAX,
          timeWindow: env.RATE_LIMIT_QRCODE_WINDOW
        }
      }
    },
    async (request, reply) => {
      const parsed = createCashInBodySchema.safeParse(request.body);
      if (!parsed.success) {
        throw new AppError(
          'validation_error',
          'Invalid PIX charge payload',
          422,
          parsed.error.flatten()
        );
      }

      // Cash-in does NOT use the `Idempotency-Key` header. Retry-safety is
      // provided by the `(client_id, external_ref)` business rule: a given
      // external_ref maps to exactly one charge (see PaymentService.createCashIn).
      // Any `Idempotency-Key` a client happens to send is silently ignored for
      // passive backward-compatibility — it is never read, validated, persisted
      // or forwarded.
      const client = request.client!;
      const charge = await deps.paymentService.createCashIn({
        ...parsed.data,
        client_id: client.clientId
      });
      return reply.status(201).send(charge);
    }
  );

  /**
   * Lookup by Pix `txid` (the canonical public identifier returned in
   * the POST response). Scoped to the authenticated client — a charge
   * owned by another tenant on the same provider account returns 404
   * (uniform with "row doesn't exist") so ownership doesn't leak.
   */
  app.get(
    '/v1/pix/cash-in/:txid',
    {
      preHandler: [
        deps.auth.authenticate,
        deps.auth.resolveAuthContext,
        deps.auth.requireScope(AUTH_SCOPES.PIX_CASH_IN_READ)
      ]
    },
    async (request, reply) => {
      const params = request.params as { txid: string };
      const client = request.client!;
      const charge = await deps.paymentService.getChargeByTxid(client.clientId, params.txid);
      if (!charge) {
        return reply.status(404).send({
          error: {
            code: 'charge_not_found',
            message: `No charge found for txid=${params.txid}`,
            request_id: request.id
          }
        });
      }
      return charge;
    }
  );
}
