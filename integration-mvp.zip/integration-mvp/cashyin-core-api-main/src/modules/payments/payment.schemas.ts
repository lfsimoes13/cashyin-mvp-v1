import { z } from 'zod';
import { amountSchema } from '../../shared/validation/money.js';

/**
 * Public contract for `POST /v1/pix/cash-in/qrcode`.
 *
 * Field naming follows the canonical snake_case convention used across
 * the platform's public contracts (HTTP request/response, outbound
 * webhook payloads, DB columns). The internal TS layer below the route
 * picks the same keys so the shape travels through the system without
 * a per-layer rename.
 *
 * `client_id` is intentionally NOT part of the body — it's resolved
 * from the `Authorization: Bearer ...` credential via the
 * `requireClientAuth` preHandler and injected by the route handler
 * before calling the service. Letting callers smuggle a `client_id`
 * in the JSON would let any authenticated principal operate against
 * any tenant.
 */
export const createCashInBodySchema = z.object({
  external_ref: z.string().min(1).max(120),
  amount: amountSchema,
  description: z.string().max(140).optional()
});

export type CreateCashInBody = z.infer<typeof createCashInBodySchema>;

/** Shape consumed by the service, including the auth-resolved client id. */
export type CreateCashInInput = CreateCashInBody & { client_id: string };
