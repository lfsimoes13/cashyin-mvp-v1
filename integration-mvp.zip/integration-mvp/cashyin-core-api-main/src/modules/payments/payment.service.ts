import type { Database } from '../../shared/db/database.js';
import { ProviderError } from '../../providers/contracts/provider-errors.js';
import type {
  ProviderName,
  ProviderPixCharge,
  ProviderPixChargeRequest
} from '../../providers/contracts/provider-types.js';
import { generatePixTxid } from '../../shared/validation/pix.js';
import type { Sql } from '../../shared/db/sql.js';
import type { LedgerService } from '../ledger/ledger.service.js';
import type { OutboxService } from '../outbox/outbox.service.js';
import type {
  FeeAssessmentRecord
} from '../pricing/fee-assessment.repository.js';
import type {
  PricingAssessment,
  PricingService
} from '../pricing/pricing.service.js';
import type { ProviderAssignmentService } from '../providers/provider-assignment.service.js';
import type { ProviderRegistry } from '../providers/provider-registry.js';
import type {
  CashInPayer,
  CashInRecord,
  CashInRepository,
  CashInRecordStatus,
  TerminalCashInFailureStatus
} from './cash-in.repository.js';
import { canTransitionCashIn } from '../transactions/state-machine.js';
import {
  toPublicCashIn,
  type PublicCashIn,
  type PublicCounterpartySource
} from '../transactions/public-serialization.js';
import type { CreateCashInInput } from './payment.schemas.js';
import { metrics } from '../../shared/observability/metrics.js';

export type PaymentServiceDeps = {
  db: Database;
  providerAssignment: ProviderAssignmentService;
  providerRegistry: ProviderRegistry;
  chargeRepository: CashInRepository;
  outbox: OutboxService;
  defaultProvider: 'bents';
  pricing?: PricingService;
  ledger?: LedgerService;
  log?: ReconciliationLogger;
  /**
   * Optional structured observability sink for cash-in paid events.
   * Emitted ONCE per webhook delivery (after the transaction commits).
   * Defaults to a stdout JSON line when not supplied. Never includes
   * payer PII beyond what is already public in the outbox payload.
   */
  observabilityLog?: CashInPaidObservabilityLogger;
};

/**
 * Public response shape for `POST /v1/pix/cash-in/qrcode` and
 * `GET /v1/pix/cash-in/:txid`. The shape is produced by the shared
 * serializer ({@link toPublicCashIn}) so it stays byte-for-byte identical to
 * the cash-in webhook `data` block: nested `pix:{emv,expires_at?,e2e_id?}`,
 * an optional `payer` block (omitted while pending), and `paid_at` only once
 * the charge settles. It never exposes CashYin-internal identifiers or
 * commercial pricing fields.
 */
export type CashInResponse = PublicCashIn;

export type ChargePaidEvent = {
  provider_name: ProviderName;
  provider_charge_id: string;
  paid_at: Date;
  e2e_id?: string;
  /**
   * Provider-realised principal at payment time. When omitted, the
   * original charge amount is used (cash-in normally settles for the
   * exact amount). The fee_assessment uses the originally-estimated
   * principal because pricing rules were computed from it; the
   * realised amount is only persisted for audit.
   */
  realised_amount?: number;
  /**
   * Payer block extracted by the webhook adapter. Every field is
   * optional because providers vary on which subset they emit; the
   * repository's `markPaid` uses `COALESCE` to avoid wiping a
   * complete block already recorded by a previous webhook.
   */
  payer?: Partial<CashInPayer>;
};

export type ChargePaidResult =
  | { status: 'noop'; reason: 'charge_not_found' | 'already_paid' }
  | {
      status: 'updated';
      charge_id: string;
      fee_assessment_id: string | null;
      ledger_entries_posted: number;
      /**
       * Outcome of the ledger idempotency guard for this batch. Useful
       * for ops to distinguish a first-time post from a webhook replay
       * that was correctly de-duplicated at the ledger layer.
       */
      idempotency_result: LedgerIdempotencyResult;
    };

export type LedgerIdempotencyResult =
  /** Ledger batch was just posted for the first time. */
  | 'first_post'
  /**
   * Ledger writes were skipped because another worker / replay had
   * already posted the same batch (idempotency key already claimed).
   */
  | 'duplicate_skipped'
  /**
   * No pricing/cost rules exist for this client+provider+operation, so
   * the principal was credited with zero fees. The fee_assessment row
   * was NOT created — operators should configure pricing for a clean
   * audit trail. The principal credit IS recorded.
   */
  | 'no_assessment_zero_fee_credit'
  /**
   * No ledger dep wired (lightweight test container or boot path).
   * Should never happen in production.
   */
  | 'ledger_not_wired';

export type CashInPaidObservabilityEvent = {
  code: 'cash_in_paid';
  client_id: string;
  charge_id: string;
  txid: string;
  provider_name: ProviderName;
  provider_charge_id: string;
  e2e_id: string | null;
  gross_amount_cents: number;
  fee_amount_cents: number;
  net_amount_cents: number;
  ledger_entries_posted: number;
  fee_assessment_id: string | null;
  idempotency_result: LedgerIdempotencyResult;
};

export type CashInPaidObservabilityLogger = (event: CashInPaidObservabilityEvent) => void;

export type ChargeTerminalEvent = {
  provider_name: ProviderName;
  provider_charge_id: string;
  status: TerminalCashInFailureStatus;
  occurred_at: Date;
};

export type ChargeTerminalResult =
  | { status: 'noop'; reason: 'charge_not_found' | 'already_terminal' | 'transition_not_allowed' }
  | {
      status: 'updated';
      charge_id: string;
      previous_status: CashInRecordStatus;
      new_status: TerminalCashInFailureStatus;
    };

// Reconciliation events are an *internal* observability shape (they
// only flow into a logger), so they intentionally keep camelCase
// identifiers — they never cross a wire or DB boundary.
export type ReconciliationLogger = (event: ReconciliationEvent) => void;

export type ReconciliationEvent = {
  code: string;
  operationType: 'cash_in' | 'cash_out';
  /**
   * Idempotency record id, when the flow that emitted the event used one.
   * Cash-in no longer uses `Idempotency-Key`, so it omits this field and
   * keys reconciliation on `(clientId, externalRef)` instead.
   */
  recordId?: string;
  clientId: string;
  externalRef: string;
  reason: string;
  cause: string;
  providerState: string;
};

/**
 * Internal state machine that tracks how far the provider call
 * progressed for a given request. The catch handler uses this to
 * decide whether it is safe to release the idempotency lock.
 *
 * For Bents — which exposes **no** server-side idempotency on
 * `POST /pix/*` — we may only release the lock when we are certain
 * the provider did not side-effect: either we never called it
 * (`not_started`) or it explicitly rejected the call with a
 * non-retryable 4xx (`settled_definite_failure`). In every other
 * case (`in_flight`, `settled_success`, `ambiguous`) the lock MUST
 * remain held so a second call cannot enqueue a duplicate charge
 * while a reconciliation job catches up.
 */
type ProviderState =
  | { kind: 'not_started' }
  | { kind: 'in_flight' }
  | { kind: 'settled_success' }
  | { kind: 'settled_definite_failure'; error: ProviderError }
  | { kind: 'ambiguous'; error: Error };

export class PaymentService {
  constructor(private readonly deps: PaymentServiceDeps) {}

  /**
   * Creates a Pix cash-in (QR code) charge.
   *
   * Cash-in does **not** use the `Idempotency-Key` header. Retry-safety is a
   * business rule keyed on `(client_id, external_ref)`: the pair maps to
   * exactly one charge. A client that retries with the same `external_ref`
   * gets the original charge back (no duplicate Pix charge is created at the
   * provider). The DB enforces this with `UNIQUE (client_id, external_ref)`.
   *
   * Trade-off vs. the previous header-based lock: two *concurrent* requests
   * carrying the same `external_ref` can both reach the provider before either
   * row is persisted. Only one row wins the unique constraint; the loser
   * returns the winning charge and emits a reconciliation event so the
   * orphaned provider-side charge (Bents has no client idempotency) can be
   * cleaned up. See the reconciliation handling in the `catch` below.
   */
  async createCashIn(input: CreateCashInInput): Promise<CashInResponse> {
    const startedAt = process.hrtime.bigint();
    let metricProvider: ProviderName | 'unknown' = 'unknown';
    let metricResult = 'error';

    try {
    // Business-rule dedup: if a charge already exists for this
    // (client_id, external_ref) pair, return it instead of creating a new
    // Pix charge. This makes the endpoint safe to retry without a header.
    const existing = await this.deps.chargeRepository.findByClientExternalRef(
      this.deps.db.pool,
      input.client_id,
      input.external_ref
    );
    if (existing) {
      metricResult = 'dedup_hit';
      return buildResponseFromRecord(existing);
    }

    let providerState: ProviderState = { kind: 'not_started' };

    try {
      const assignment = await this.deps.providerAssignment.requireActive(
        input.client_id,
        'cash_in'
      );
      metricProvider = assignment.providerName;
      const provider = this.deps.providerRegistry.get(assignment.providerName);

      // Generate the CashYin-owned Pix txid BEFORE calling the provider.
      // This ensures:
      //   1. The public identifier is always CashYin-controlled and opaque.
      //   2. Future providers that accept a caller-supplied txid receive it.
      const cashyinTxid = generatePixTxid();

      const providerRequest: ProviderPixChargeRequest = {
        client_id: input.client_id,
        external_ref: input.external_ref,
        amount: input.amount,
        // Pass the CashYin txid so providers that honour a caller-supplied
        // txid (unlike Bents, which generates it server-side) can use it.
        txid: cashyinTxid,
        ...(input.description !== undefined ? { description: input.description } : {})
      };

      providerState = { kind: 'in_flight' };
      let providerResult: ProviderPixCharge;
      const providerCallStartedAt = process.hrtime.bigint();
      let providerCallResult = 'error';
      try {
        providerResult = await provider.createPixCharge(providerRequest);
        providerState = { kind: 'settled_success' };
        providerCallResult = 'success';
      } catch (callError) {
        providerState = classifyProviderCallError(callError);
        providerCallResult = providerState.kind === 'settled_definite_failure'
          ? 'definite_client_error'
          : 'ambiguous_error';
        throw callError;
      } finally {
        // Isolated provider call timing is the single most important
        // latency signal for the QR Code fast path. Records how long
        // `provider.createPixCharge()` took regardless of outcome, so
        // dashboards can separate provider degradation from local overhead.
        metrics.observeDurationSeconds(
          'cashyin_provider_charge_create_duration_seconds',
          'Duration of the outbound createPixCharge call to the payment provider.',
          providerCallStartedAt,
          { provider: metricProvider, result: providerCallResult }
        );
        metrics.increment(
          'cashyin_provider_charge_create_total',
          'Total createPixCharge calls to the payment provider by result.',
          { provider: metricProvider, result: providerCallResult }
        );
      }

      // Pre-compute the pricing assessment OUTSIDE the persistence
      // transaction: it only reads pricing/cost rules and subsidy
      // aggregates from the pool. The transaction below persists the
      // resulting `fee_assessment(estimated)` row alongside the
      // charge. Unlike cash-out, we do NOT reject on
      // `policyDecision.rejected` here: the charge has already been
      // created at the provider and the client should still be
      // allowed to RECEIVE money.
      const assessment = this.deps.pricing
        ? await this.deps.pricing.assessForCashIn(this.deps.db.pool, {
            clientId: input.client_id,
            providerAccountId: assignment.providerAccountId,
            amountCents: input.amount
          })
        : null;

      metricResult = 'success';
      const response = await this.deps.db.withTransaction(async (tx) => {
        const charge = await this.deps.chargeRepository.insert(tx, {
          client_id: input.client_id,
          provider_name: assignment.providerName,
          provider_account_id: assignment.providerAccountId,
          external_ref: input.external_ref,
          provider_charge_id: providerResult.provider_charge_id,
          txid: cashyinTxid,
          provider_tx_id: providerResult.provider_tx_id ?? null,
          amount: input.amount,
          status: providerResult.status,
          emv: providerResult.emv ?? null,
          description: input.description ?? null,
          expires_at: providerResult.expires_at ? new Date(providerResult.expires_at) : null
        });

        let _feeAssessmentRecord: FeeAssessmentRecord | null = null;
        if (this.deps.pricing && assessment) {
          _feeAssessmentRecord = await this.deps.pricing.persistAssessment(tx, {
            assessment,
            transactionType: 'cash_in',
            transactionId: charge.id,
            clientId: input.client_id,
            providerAccountId: assignment.providerAccountId,
            operationType: 'cash_in',
            triggerEvent: 'cash_in_paid',
            principalAmountCents: input.amount,
            status: 'estimated',
            metadata: { external_ref: input.external_ref }
          });
        }

        return buildResponseFromRecord(charge);
      });

      return response;
    } catch (error) {
      metricResult = 'error';
      // Concurrent-duplicate race: another request with the same
      // (client_id, external_ref) won the UNIQUE constraint while this one
      // was in flight. Return the winning charge so the client still gets a
      // coherent result. If THIS request had already side-effected at the
      // provider, the provider charge is now orphaned — flag it for
      // reconciliation (Bents exposes no client idempotency to dedupe it).
      const winner = await this.deps.chargeRepository
        .findByClientExternalRef(this.deps.db.pool, input.client_id, input.external_ref)
        .catch(() => null);
      if (winner) {
        if (providerStateMaySideEffect(providerState)) {
          this.emitReconciliation({
            code: 'cashin_duplicate_external_ref_orphaned_provider_charge',
            operationType: 'cash_in',
            clientId: input.client_id,
            externalRef: input.external_ref,
            reason:
              'concurrent request with same external_ref won the unique constraint; ' +
              'this provider charge may be orphaned and require reconciliation',
            cause: errorCause(error),
            providerState: providerState.kind
          });
        }
        return buildResponseFromRecord(winner);
      }

      // No winning row: the provider may have side-effected but we failed to
      // persist locally. Surface for reconciliation when that is possible.
      if (providerStateMaySideEffect(providerState)) {
        this.emitReconciliation({
          code: 'cashin_provider_state_requires_reconciliation',
          operationType: 'cash_in',
          clientId: input.client_id,
          externalRef: input.external_ref,
          reason: 'provider may have side-effected but the charge was not persisted locally',
          cause: errorCause(error),
          providerState: providerState.kind
        });
      }
      throw error;
    }
    } finally {
      metrics.increment(
        'cashyin_qrcode_create_total',
        'Total QR Code creation requests by provider and result.',
        { provider: metricProvider, result: metricResult }
      );
      metrics.observeDurationSeconds(
        'cashyin_qrcode_create_duration_seconds',
        'End-to-end duration of POST /v1/pix/cash-in/qrcode.',
        startedAt,
        { provider: metricProvider, result: metricResult }
      );
    }
  }

  /**
   * Returns a charge by Pix `txid` **scoped to the caller's client**.
   * Returns `null` when the row doesn't exist or belongs to a
   * different tenant — the route handler should map both branches
   * to a uniform `404 charge_not_found` so ownership doesn't leak.
   *
   * Reads exclusively from the local database — no passthrough to
   * the provider. Status transitions arrive via the webhook
   * pipeline, which keeps the local row authoritative.
   */
  async getChargeByTxid(
    clientId: string,
    txid: string
  ): Promise<CashInResponse | null> {
    const charge = await this.deps.chargeRepository.findByTxid(this.deps.db.pool, txid);
    if (!charge || charge.client_id !== clientId) {
      return null;
    }
    return buildResponseFromRecord(charge);
  }

  /**
   * Domain reaction to the `pix.cash_in.paid` webhook event. Steps:
   *
   *  1. Locate the charge by `(provider_name, provider_charge_id)`.
   *  2. If already terminal, return noop (idempotent for replays).
   *  3. `markPaid` transitions the row and persists `paid_at`,
   *     `e2e_id` and the seven `payer_*` columns on first
   *     observation (subsequent webhook deliveries with a partial
   *     payer block won't wipe the already-recorded values).
   *  4. Resolve or promote the `fee_assessment` to `posted`.
   *  5. Post the ledger batch when both pricing and ledger are wired.
   *  6. Enqueue the public outbox event `pix.cash_in.paid` carrying
   *     the canonical payload (snake_case, includes the payer block).
   */
  async handleChargePaid(event: ChargePaidEvent): Promise<ChargePaidResult> {
    const startedAt = process.hrtime.bigint();
    let metricResult = 'error';

    try {
    const existing = await this.deps.chargeRepository.findByProviderChargeId(
      this.deps.db.pool,
      event.provider_name,
      event.provider_charge_id
    );

    if (!existing) {
      metricResult = 'noop_charge_not_found';
      return { status: 'noop', reason: 'charge_not_found' };
    }

    if (existing.status !== 'pending') {
      metricResult = 'noop_already_paid';
      return { status: 'noop', reason: 'already_paid' };
    }

    const txOutcome = await this.deps.db.withTransaction<
      | { kind: 'noop'; reason: 'already_paid' }
      | { kind: 'updated'; result: Extract<ChargePaidResult, { status: 'updated' }>; observability: CashInPaidObservabilityEvent }
    >(async (tx) => {
      const paid = await this.deps.chargeRepository.markPaid(tx, existing.id, {
        paid_at: event.paid_at,
        e2e_id: event.e2e_id ?? null,
        ...(event.payer ? { payer: event.payer } : {})
      });

      if (!paid) {
        return { kind: 'noop', reason: 'already_paid' };
      }

      // Monotonic marker for the moment the charge is persisted as paid.
      // outbox_creation_latency = (outbox row created) - (paid persisted).
      // Both happen inside this one transaction, so this is the in-tx ledger +
      // fee work between the two writes; it is near-zero by design and is
      // measured to prove the outbox row is created essentially immediately.
      const paidPersistedHr = process.hrtime.bigint();

      let feeAssessmentRecord: FeeAssessmentRecord | null = null;
      if (this.deps.pricing) {
        feeAssessmentRecord = await this.resolveOrPromoteAssessment(tx, paid);
      }

      // The ledger MUST credit the principal regardless of whether
      // pricing/cost rules are configured. A missing fee_assessment
      // means we cannot bill the client for a fee, but we still owe
      // them the money — so we post a zero-fee principal-only batch
      // and surface `idempotency_result='no_assessment_zero_fee_credit'`
      // for ops to backfill pricing later.
      let ledgerEntriesPosted = 0;
      let idempotencyResult: LedgerIdempotencyResult = 'ledger_not_wired';
      if (this.deps.ledger) {
        const postingResult = await this.deps.ledger.postFeeAssessment(tx, {
          transactionId: paid.id,
          triggerEvent: 'cash_in_paid',
          operationType: 'cash_in',
          clientId: paid.client_id,
          providerName: paid.provider_name,
          providerAccountId: paid.provider_account_id,
          providerReferenceId: paid.provider_charge_id,
          principalAmountCents: paid.amount,
          clientFeeCents: feeAssessmentRecord?.clientFeeCents ?? 0,
          providerCostCents: feeAssessmentRecord?.providerCostCents ?? 0,
          subsidyCents: feeAssessmentRecord?.subsidyCents ?? 0,
          feeAssessmentId: feeAssessmentRecord?.id ?? null,
          metadata: {
            charge_external_ref: paid.external_ref,
            provider_charge_id: paid.provider_charge_id
          }
        });
        if (postingResult.kind === 'first_post') {
          ledgerEntriesPosted = postingResult.entries.length;
          idempotencyResult = feeAssessmentRecord ? 'first_post' : 'no_assessment_zero_fee_credit';
        } else {
          idempotencyResult = 'duplicate_skipped';
        }
      }

      await this.deps.outbox.enqueue(tx, {
        aggregateType: 'cash_in',
        aggregateId: paid.id,
        eventType: 'pix.cash_in.paid',
        payload: {
          charge_id: paid.id,
          external_ref: paid.external_ref,
          client_id: paid.client_id,
          provider: paid.provider_name,
          provider_charge_id: paid.provider_charge_id,
          txid: paid.txid,
          status: paid.status,
          amount: paid.amount,
          emv: paid.emv,
          description: paid.description,
          created_at: paid.created_at.toISOString(),
          paid_at: paid.paid_at?.toISOString() ?? event.paid_at.toISOString(),
          e2e_id: paid.e2e_id,
          payer: payerToCounterpartySource(paid.payer),
          fee_assessment_id: feeAssessmentRecord?.id ?? null,
          ledger_entries_posted: ledgerEntriesPosted
        }
      });

      metrics.observeDurationSeconds(
        'cashyin_cash_in_paid_outbox_creation_latency_seconds',
        'In-transaction latency between persisting a cash-in as paid and creating the pix.cash_in.paid outbox row.',
        paidPersistedHr,
        { provider: event.provider_name }
      );

      const feeAmountCents = feeAssessmentRecord?.clientFeeCents ?? 0;
      const grossAmountCents = paid.amount;
      return {
        kind: 'updated',
        result: {
          status: 'updated',
          charge_id: paid.id,
          fee_assessment_id: feeAssessmentRecord?.id ?? null,
          ledger_entries_posted: ledgerEntriesPosted,
          idempotency_result: idempotencyResult
        },
        observability: {
          code: 'cash_in_paid',
          client_id: paid.client_id,
          charge_id: paid.id,
          txid: paid.txid,
          provider_name: paid.provider_name,
          provider_charge_id: paid.provider_charge_id ?? event.provider_charge_id,
          e2e_id: paid.e2e_id,
          gross_amount_cents: grossAmountCents,
          fee_amount_cents: feeAmountCents,
          net_amount_cents: grossAmountCents - feeAmountCents,
          ledger_entries_posted: ledgerEntriesPosted,
          fee_assessment_id: feeAssessmentRecord?.id ?? null,
          idempotency_result: idempotencyResult
        }
      };
    });

    if (txOutcome.kind === 'noop') {
      metricResult = `noop_${txOutcome.reason}`;
      return { status: 'noop', reason: txOutcome.reason };
    }

    this.emitCashInPaidObservability(txOutcome.observability);
    metricResult = 'updated';
    return txOutcome.result;
    } finally {
      metrics.increment(
        'cashyin_cashin_paid_processing_total',
        'Total processed cash-in paid domain events by result.',
        { provider: event.provider_name, result: metricResult }
      );
      metrics.observeDurationSeconds(
        'cashyin_cashin_paid_processing_duration_seconds',
        'Duration of cash-in paid domain processing before client outbox dispatch.',
        startedAt,
        { provider: event.provider_name, result: metricResult }
      );
    }
  }

  private emitCashInPaidObservability(event: CashInPaidObservabilityEvent): void {
    const logger = this.deps.observabilityLog ?? defaultCashInPaidObservabilityLogger;
    try {
      logger(event);
    } catch {
      // Never let logging crash the post-commit continuation.
    }
  }

  async handleChargeTerminal(event: ChargeTerminalEvent): Promise<ChargeTerminalResult> {
    const existing = await this.deps.chargeRepository.findByProviderChargeId(
      this.deps.db.pool,
      event.provider_name,
      event.provider_charge_id
    );

    if (!existing) {
      return { status: 'noop', reason: 'charge_not_found' };
    }

    if (existing.status === event.status) {
      return { status: 'noop', reason: 'already_terminal' };
    }

    if (!canTransitionCashIn(existing.status, event.status)) {
      return { status: 'noop', reason: 'transition_not_allowed' };
    }

    return this.deps.db.withTransaction<ChargeTerminalResult>(async (tx) => {
      // Pass `existing.status` as the expected current status for optimistic
      // concurrency: a concurrent worker that already advanced the row causes
      // the UPDATE to match 0 rows, returning null so we surface a no-op.
      const updated = await this.deps.chargeRepository.markTerminal(
        tx,
        existing.id,
        event.status,
        existing.status
      );

      if (!updated) {
        return { status: 'noop', reason: 'already_terminal' };
      }

      await this.deps.outbox.enqueue(tx, {
        aggregateType: 'cash_in',
        aggregateId: updated.id,
        eventType: `pix.cash_in.${event.status}`,
        payload: {
          charge_id: updated.id,
          external_ref: updated.external_ref,
          client_id: updated.client_id,
          provider: updated.provider_name,
          provider_charge_id: updated.provider_charge_id,
          txid: updated.txid,
          status: updated.status,
          amount: updated.amount,
          emv: updated.emv,
          description: updated.description,
          created_at: updated.created_at.toISOString(),
          occurred_at: event.occurred_at.toISOString()
        }
      });

      return {
        status: 'updated',
        charge_id: updated.id,
        previous_status: existing.status,
        new_status: event.status
      };
    });
  }

  private async resolveOrPromoteAssessment(
    tx: Sql,
    paid: CashInRecord
  ): Promise<FeeAssessmentRecord | null> {
    const pricing = this.deps.pricing;
    if (!pricing) return null;

    const existing = await pricing.findAssessmentByTransaction(
      tx,
      'cash_in',
      paid.id,
      'cash_in_paid'
    );

    if (existing) {
      if (existing.status === 'estimated') {
        return pricing.promoteAssessmentStatus(tx, existing.id, 'posted');
      }
      return existing;
    }

    const fresh: PricingAssessment | null = await pricing.assessForCashIn(tx, {
      clientId: paid.client_id,
      providerAccountId: paid.provider_account_id,
      amountCents: paid.amount
    });
    if (!fresh) return null;
    return pricing.persistAssessment(tx, {
      assessment: fresh,
      transactionType: 'cash_in',
      transactionId: paid.id,
      clientId: paid.client_id,
      providerAccountId: paid.provider_account_id,
      operationType: 'cash_in',
      triggerEvent: 'cash_in_paid',
      principalAmountCents: paid.amount,
      status: 'posted',
      metadata: {
        external_ref: paid.external_ref,
        backfilled: true,
        reason: 'no_estimated_assessment_at_paid_time'
      }
    });
  }

  private emitReconciliation(event: ReconciliationEvent): void {
    const logger = this.deps.log ?? defaultReconciliationLogger;
    try {
      logger(event);
    } catch {
      // Never fail the original request because logging threw.
    }
  }
}

function classifyProviderCallError(error: unknown): ProviderState {
  if (error instanceof ProviderError) {
    if (error.isDefinite) {
      return { kind: 'settled_definite_failure', error };
    }
    return { kind: 'ambiguous', error };
  }
  const wrapped = error instanceof Error ? error : new Error(String(error));
  return { kind: 'ambiguous', error: wrapped };
}

/**
 * True when the provider call may have side-effected (created a charge at the
 * provider) and we therefore cannot silently drop the request: either the call
 * was in flight, succeeded, or failed ambiguously. `not_started` and
 * `settled_definite_failure` (an explicit non-retryable provider rejection)
 * are the only states where we are certain nothing was created.
 */
function providerStateMaySideEffect(state: ProviderState): boolean {
  return state.kind !== 'not_started' && state.kind !== 'settled_definite_failure';
}

/**
 * Public response shape from a persisted record. The same builder
 * powers both `POST` (after the provider call commits) and `GET`
 * (lookup by `txid`). Returning the same shape on both endpoints
 * means the client can cache the POST response and refresh status
 * later via GET without remapping fields.
 */
function buildResponseFromRecord(charge: CashInRecord): CashInResponse {
  return toPublicCashIn({
    txid: charge.txid,
    externalRef: charge.external_ref,
    status: charge.status,
    amountCents: charge.amount,
    emv: charge.emv,
    expiresAt: charge.expires_at,
    e2eId: charge.e2e_id,
    payer: payerToCounterpartySource(charge.payer),
    paidAt: charge.paid_at,
    description: charge.description,
    createdAt: charge.created_at
  });
}

/**
 * Maps the internal {@link CashInPayer} (BACEN-style `bank_*` keys) onto the
 * shared {@link PublicCounterpartySource}. The serializer omits the public
 * `payer` block entirely when every field is null.
 */
function payerToCounterpartySource(payer: CashInPayer): PublicCounterpartySource {
  return {
    name: payer.name,
    documentNumber: payer.document,
    bank: payer.bank_name,
    ispb: payer.bank_ispb,
    branch: payer.bank_branch,
    account: payer.bank_account,
    accountType: payer.account_type
  };
}

function errorCause(error: unknown): string {
  if (error instanceof ProviderError) {
    return `${error.code}:${error.category}`;
  }
  if (error instanceof Error) {
    return error.message;
  }
  return String(error);
}

function defaultReconciliationLogger(event: ReconciliationEvent): void {
  const payload = {
    level: 'error',
    ...event,
    msg: 'reconciliation_required'
  };
  console.error(JSON.stringify(payload));
}

function defaultCashInPaidObservabilityLogger(event: CashInPaidObservabilityEvent): void {
  // Emitted to stdout (level=info) so a log shipper can route to the
  // billing/observability sink. Severity is bumped to `warn` for the
  // operational degradation case so the on-call sees it without paging.
  const level = event.idempotency_result === 'no_assessment_zero_fee_credit' ? 'warn' : 'info';
  console.log(
    JSON.stringify({
      level,
      msg: 'cash_in_paid',
      ...event
    })
  );
}
