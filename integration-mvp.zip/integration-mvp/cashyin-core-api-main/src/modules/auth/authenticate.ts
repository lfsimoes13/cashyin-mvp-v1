/**
 * Unified, multi-channel authentication entry point for `/v1/*` routes.
 *
 * Produces a transport-agnostic {@link ResolvedPrincipal} (and a back-compat
 * `request.client` shim) from whichever credential the caller presented:
 *
 *   - `frontend_bff` — the trusted Backend-for-Frontend presents a shared
 *     secret in `X-CashYin-BFF-Token` plus trusted `X-CashYin-Actor-User-Id`
 *     and `X-CashYin-Client-Id` headers. Verified locally (timing-safe, no
 *     remote IdP call on the hot path). Gated by `BFF_AUTH_MODE`.
 *   - `api_direct`  — a CashYin-issued Bearer API key (`ck_…`), resolved via
 *     {@link ClientApiKeyService}. Always available.
 *
 * Authentication is always enforced (a request with no usable credential is
 * rejected 401). Scope *authorization* is a separate, flag-staged layer
 * (`auth-enforcement.ts`). The downstream `resolveAuthContext` reads the
 * `ResolvedPrincipal` set here to build the normalised `AuthContext`.
 */

import type { FastifyReply, FastifyRequest, preHandlerAsyncHookHandler } from 'fastify';
import type { AuthChannel, PrincipalType } from '../../shared/auth/auth-context.js';
import { AUTH_SCOPES, type AuthScope } from '../../shared/auth/auth-scopes.js';
import { clientMismatchError, invalidAuthError } from '../../shared/auth/auth-errors.js';
import { timingSafeEqualString } from '../../shared/security/hmac.js';
import type { ClientApiKeyService } from './client-api-key.service.js';
import { buildRequireClientAuth } from './require-client-auth.js';
import type { ApiHmacVerifier } from './api-hmac.js';

/** Trusted BFF headers (lower-cased, as Fastify normalises them). */
export const BFF_TOKEN_HEADER = 'x-cashyin-bff-token' as const;
export const BFF_ACTOR_USER_HEADER = 'x-cashyin-actor-user-id' as const;
export const BFF_CLIENT_HEADER = 'x-cashyin-client-id' as const;

/**
 * Scopes granted to the `frontend_bff` channel. The Core remains the
 * authority (the BFF cannot escalate beyond this set); fine-grained
 * per-actor roles are a later iteration. Excludes administrative grants
 * (`api_keys:manage`, `clients:manage`) which must be issued to a dedicated
 * credential intentionally.
 */
export const DEFAULT_BFF_SCOPES: readonly AuthScope[] = Object.freeze([
  AUTH_SCOPES.PIX_CASH_IN_CREATE,
  AUTH_SCOPES.PIX_CASH_IN_READ,
  AUTH_SCOPES.PIX_CASH_OUT_CREATE,
  AUTH_SCOPES.PIX_CASH_OUT_READ,
  AUTH_SCOPES.BALANCE_READ,
  AUTH_SCOPES.WEBHOOKS_MANAGE,
  AUTH_SCOPES.CLIENTS_READ
]);

/**
 * Normalised description of the authenticated caller, independent of how it
 * authenticated. `resolveAuthContext` maps this onto the `AuthContext`.
 */
export type ResolvedPrincipal = {
  channel: AuthChannel;
  principalType: PrincipalType;
  principalId: string;
  clientId: string;
  scopes: readonly AuthScope[];
  /** Present for `frontend_bff`: the human the BFF acts on behalf of. */
  actorUserId?: string;
  /** Credential id for audit/rotation (api-key id, or `'bff'`). */
  credentialId?: string;
};

declare module 'fastify' {
  interface FastifyRequest {
    /**
     * Channel-agnostic principal set by {@link buildAuthenticate}. Reading it
     * on a route without the authenticator is a programming error.
     */
    authPrincipal?: ResolvedPrincipal;
  }
}

export type AuthenticateDeps = {
  clientApiKeyService: ClientApiKeyService;
  /** `'off'` ignores BFF tokens; `'enforce'` accepts + verifies them. */
  bffMode: 'off' | 'enforce';
  /** Shared secret for the BFF channel; required when `bffMode='enforce'`. */
  bffSecret?: string;
  /**
   * Optional per-user RBAC for the BFF channel (deviation D7). In `'enforce'`,
   * the actor's granted scopes are resolved and intersected with
   * `DEFAULT_BFF_SCOPES`; an actor with no active grant is rejected. In
   * `'off'` (or when absent), every authenticated BFF actor gets the full
   * `DEFAULT_BFF_SCOPES`.
   */
  bffRbac?: {
    mode: 'off' | 'enforce';
    resolveScopes: (actorUserId: string, clientId: string) => Promise<readonly AuthScope[] | null>;
  };
  /**
   * Optional request-signature verifier for the `api_direct` channel. When
   * present, runs after the Bearer key resolves (no-op in its own `off`
   * mode). Absent ⇒ no signature checks.
   */
  apiHmac?: ApiHmacVerifier;
};

function headerString(request: FastifyRequest, name: string): string | undefined {
  const value = request.headers[name];
  return typeof value === 'string' && value.length > 0 ? value : undefined;
}

/**
 * Build the unified authenticator preHandler. The BFF branch only activates
 * when `bffMode='enforce'` AND a BFF token header is present; otherwise the
 * request falls through to the Bearer (`api_direct`) path, preserving today's
 * behaviour when BFF is off.
 */
export function buildAuthenticate(deps: AuthenticateDeps): preHandlerAsyncHookHandler {
  const requireClientAuth = buildRequireClientAuth(deps.clientApiKeyService);
  const bffEnabled = deps.bffMode === 'enforce';

  return async function authenticate(request: FastifyRequest, reply: FastifyReply): Promise<void> {
    if (bffEnabled) {
      const token = headerString(request, BFF_TOKEN_HEADER);
      if (token !== undefined) {
        // A presented BFF token must verify — never silently fall back to
        // Bearer, to avoid ambiguous denial semantics.
        if (!deps.bffSecret || !timingSafeEqualString(token, deps.bffSecret)) {
          throw invalidAuthError();
        }
        const actorUserId = headerString(request, BFF_ACTOR_USER_HEADER);
        const clientId = headerString(request, BFF_CLIENT_HEADER);
        if (!actorUserId || !clientId) {
          throw invalidAuthError();
        }

        // Per-user RBAC (D7): when enabled, narrow the channel ceiling
        // (DEFAULT_BFF_SCOPES) to the actor's granted scopes. No active grant
        // ⇒ the actor is not authorised for this tenant.
        let scopes: readonly AuthScope[] = DEFAULT_BFF_SCOPES;
        if (deps.bffRbac?.mode === 'enforce') {
          const granted = await deps.bffRbac.resolveScopes(actorUserId, clientId);
          if (granted === null) {
            throw clientMismatchError();
          }
          scopes = granted.filter((scope) => DEFAULT_BFF_SCOPES.includes(scope));
        }

        request.authPrincipal = {
          channel: 'frontend_bff',
          principalType: 'user',
          principalId: actorUserId,
          clientId,
          actorUserId,
          credentialId: 'bff',
          scopes
        };
        // Back-compat shim so existing handlers reading `request.client.clientId`
        // keep working under the BFF channel.
        request.client = {
          clientId,
          apiKeyId: `bff:${actorUserId}`,
          keyPrefix: 'bff',
          label: 'frontend_bff',
          scopes
        };
        return;
      }
    }

    // api_direct (Bearer) — unchanged path; throws 401 on missing/invalid.
    // Invoke with the Fastify instance as `this` to satisfy the preHandler
    // hook signature when called directly (outside the hook dispatcher).
    await requireClientAuth.call(request.server, request, reply);
    const principal = request.client!;
    request.authPrincipal = {
      channel: 'api_direct',
      principalType: 'api_client',
      principalId: principal.clientId,
      clientId: principal.clientId,
      credentialId: principal.apiKeyId,
      scopes: principal.scopes
    };

    // Optional request-signature layer (API_HMAC_MODE). No-op when off.
    if (deps.apiHmac) {
      await deps.apiHmac.assert(request, principal.apiKeyId);
    }
  };
}
