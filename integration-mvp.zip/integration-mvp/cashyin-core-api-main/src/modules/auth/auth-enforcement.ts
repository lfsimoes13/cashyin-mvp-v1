/**
 * Resolution + staged enforcement of the normalised {@link AuthContext} for
 * the `api_direct` channel (CashYin-issued Bearer keys).
 *
 * This is the runtime "seam" the foundation (see
 * `docs/adr/auth-authorization-boundary.md`) was built for: it turns the
 * already-resolved {@link ClientPrincipal} (set by `requireClientAuth`) into
 * a transport-agnostic `AuthContext`, and applies scope guards behind the
 * `AUTH_ENFORCEMENT_MODE` feature flag so the rollout is staged.
 *
 * The `AuthContext` is **always resolved** when a principal is present
 * (independent of the flag), so the tenant and audit actor are available
 * everywhere; the flag governs only the additive *scope-authorization* layer:
 *
 *   - `off`     — no scope checks (the scope layer is inert). The context is
 *                 still resolved and Bearer authentication still runs via
 *                 `requireClientAuth`.
 *   - `shadow`  — evaluate scope guards, but never deny: would-be denials are
 *                 logged + counted so we can size the blast radius before
 *                 flipping to `enforce`.
 *   - `enforce` — deny missing-scope requests with the stable, non-leaky
 *                 `AppError`s from `auth-errors.ts`.
 *
 * Importantly, none of this changes the *authentication* contract: every
 * `/v1/*` route is still gated by `requireClientAuth` regardless of mode.
 */

import type { FastifyReply, FastifyRequest, preHandlerAsyncHookHandler } from 'fastify';
import type { AuthContext } from '../../shared/auth/auth-context.js';
import type { AuthScope } from '../../shared/auth/auth-scopes.js';
import { requireScope } from '../../shared/auth/guards.js';
import { AppError } from '../../shared/errors/app-error.js';
import { metrics } from '../../shared/observability/metrics.js';
import { buildAuthenticate, type AuthenticateDeps, type ResolvedPrincipal } from './authenticate.js';

export type AuthEnforcementMode = 'off' | 'shadow' | 'enforce';

const AUTH_DECISIONS_METRIC = 'cashyin_auth_scope_decisions_total';
const AUTH_DECISIONS_HELP =
  'Scope-authorization decisions by enforcement mode, decision and required scope.';

/**
 * Project a channel-agnostic {@link ResolvedPrincipal} onto the normalised
 * {@link AuthContext}. Carries the audit actor for the `frontend_bff` channel
 * and the credential id for audit/rotation. Machine principals carry no
 * `amr`; human (BFF) principals will gain `amr`/`stepUp` in later PRs.
 */
export function mapPrincipalToAuthContext(principal: ResolvedPrincipal): AuthContext {
  return {
    channel: principal.channel,
    principalType: principal.principalType,
    principalId: principal.principalId,
    clientId: principal.clientId,
    scopes: principal.scopes,
    amr: [],
    ...(principal.actorUserId !== undefined ? { actorUserId: principal.actorUserId } : {}),
    ...(principal.credentialId !== undefined ? { credentialId: principal.credentialId } : {})
  };
}

/**
 * preHandler that populates `request.authContext` from `request.authPrincipal`.
 *
 * Runs *after* the authenticator (which sets `request.authPrincipal`). The
 * context is resolved **unconditionally** whenever a principal is present, so
 * the tenant and audit metadata (the BFF actor, the credential id) are always
 * available regardless of `AUTH_ENFORCEMENT_MODE` — the flag governs only the
 * scope-authorization layer (`buildRequireScope`), not resolution. If no
 * principal was resolved (a route that forgot the authenticator), it stays a
 * no-op — the scope guard then treats the request as unauthenticated.
 */
export function buildResolveAuthContext(): preHandlerAsyncHookHandler {
  return async function resolveAuthContext(request: FastifyRequest): Promise<void> {
    const principal = request.authPrincipal;
    if (!principal) return;
    request.authContext = mapPrincipalToAuthContext(principal);
  };
}

/**
 * preHandler factory that requires `scope` on the resolved
 * {@link AuthContext}, staged by `mode`:
 *
 *   - `off`     — no-op.
 *   - `shadow`  — evaluate; on would-be denial log + count, then allow.
 *   - `enforce` — evaluate; on denial throw the guard's `AppError`.
 *
 * Allowed decisions are also counted (not logged) so dashboards can show the
 * allow/deny ratio per route during a `shadow` rollout.
 */
export function buildRequireScope(
  mode: AuthEnforcementMode,
  scope: AuthScope
): preHandlerAsyncHookHandler {
  return async function requireScopePreHandler(request: FastifyRequest, _reply: FastifyReply): Promise<void> {
    if (mode === 'off') return;

    const route = request.routeOptions.url ?? request.url;
    try {
      requireScope(request, scope);
      metrics.increment(AUTH_DECISIONS_METRIC, AUTH_DECISIONS_HELP, {
        mode,
        decision: 'allow',
        scope,
        route
      });
    } catch (error) {
      const code = error instanceof AppError ? error.code : 'unknown';
      metrics.increment(AUTH_DECISIONS_METRIC, AUTH_DECISIONS_HELP, {
        mode,
        decision: mode === 'enforce' ? 'deny' : 'would_deny',
        scope,
        route,
        code
      });

      if (mode === 'enforce') {
        throw error;
      }

      // shadow: surface the decision for rollout analysis without denying.
      // Only ids/scope names are logged — never credentials or payloads.
      request.log.warn(
        {
          authShadow: true,
          requiredScope: scope,
          route,
          code,
          clientId: request.authContext?.clientId,
          credentialId: request.authContext?.credentialId
        },
        'auth shadow: request would be denied for insufficient scope'
      );
    }
  };
}

/**
 * Bundle of auth preHandlers shared across `/v1` route modules, built once in
 * the composition root. Route modules compose these into their `preHandler`
 * arrays rather than each reaching for `env`, the authenticator and the
 * guards directly.
 */
export type AuthPreHandlers = {
  /** Multi-channel authentication; always enforced regardless of scope mode. */
  authenticate: preHandlerAsyncHookHandler;
  /** Populates `request.authContext` whenever a principal is present. */
  resolveAuthContext: preHandlerAsyncHookHandler;
  /** Builds a per-route scope guard staged by the enforcement mode. */
  requireScope: (scope: AuthScope) => preHandlerAsyncHookHandler;
};

export type AuthPreHandlersConfig = {
  /** Scope-enforcement mode (`AUTH_ENFORCEMENT_MODE`). */
  mode: AuthEnforcementMode;
} & AuthenticateDeps;

/**
 * Assemble the {@link AuthPreHandlers} bundle: the unified authenticator plus
 * the staged AuthContext resolution and scope guard.
 */
export function buildAuthPreHandlers(config: AuthPreHandlersConfig): AuthPreHandlers {
  const { mode, ...authenticateDeps } = config;
  return {
    authenticate: buildAuthenticate(authenticateDeps),
    resolveAuthContext: buildResolveAuthContext(),
    requireScope: (scope: AuthScope) => buildRequireScope(mode, scope)
  };
}
