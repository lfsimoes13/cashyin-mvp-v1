/**
 * Persistence + crypto for client API keys.
 *
 * # Key format
 *
 * Raw keys look like `ck_<64 hex chars>`. The runtime never persists
 * the raw value — only `SHA-256(rawKey)` (lowercase hex). The
 * 8-character `key_prefix` (first 8 chars after `ck_`) is also
 * persisted so verify() can short-circuit to a small candidate set
 * indexed by prefix.
 *
 * # Why SHA-256 (not bcrypt/argon2)?
 *
 * Raw keys are 256-bit CSPRNG tokens. Rainbow-table and offline
 * brute-force attacks are not viable against full-entropy random
 * material — a salted slow hash buys nothing here and would add
 * verify-time cost on the hot path. Switch to argon2id only if we
 * accept user-chosen credentials.
 *
 * # Constant-time comparison
 *
 * `verifyKey()` uses `crypto.timingSafeEqual` over equal-length Buffers
 * to avoid timing-channel leaks during candidate matching. The
 * candidate set is bounded by the prefix index, so the loop is short.
 */

import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';
import type { Sql } from '../../shared/db/sql.js';
import {
  DEFAULT_CLIENT_API_SCOPES,
  isAuthScope,
  type AuthScope
} from '../../shared/auth/auth-scopes.js';

export const API_KEY_PREFIX = 'ck_' as const;
const RAW_KEY_BYTES = 32;
const RAW_KEY_HEX_LENGTH = RAW_KEY_BYTES * 2;
const PREFIX_LENGTH = 8;
const SIGNING_SECRET_BYTES = 32;

export type GeneratedApiKey = {
  /**
   * The full raw key, returned once at generation. Never persisted in
   * this form; callers must surface it to the operator immediately and
   * forget it.
   */
  rawKey: string;
  /** Persisted row id (uuid). */
  id: string;
  clientId: string;
  keyPrefix: string;
  label: string | null;
  /** Capability grants minted onto the key. */
  scopes: readonly AuthScope[];
  /** Hard expiry, or `null` when the key never expires. */
  expiresAt: Date | null;
  /**
   * Per-key HMAC signing secret, returned **once** at issuance. The client
   * uses it to sign requests (API_HMAC_MODE). Never logged; never re-read in
   * raw form except by the request-signature verifier.
   */
  signingSecret: string;
};

export type ClientPrincipal = {
  /** Database id of the client this key authenticates. */
  clientId: string;
  /** Database id of the API key row that authenticated the request. */
  apiKeyId: string;
  /** First 8 chars after `ck_` — safe for audit logs. */
  keyPrefix: string;
  /** Optional operator-supplied label (e.g. "Postman", "Production"). */
  label: string | null;
  /**
   * Canonical capability grants carried by the key. Unknown strings in the
   * persisted array are dropped here so callers only ever see scopes the
   * current build recognises.
   */
  scopes: readonly AuthScope[];
};

type ApiKeyRow = {
  id: string;
  client_id: string;
  key_prefix: string;
  key_hash: string;
  label: string | null;
  scopes: string[];
  expires_at: Date | null;
};

/** Row shape returned by {@link ClientApiKeyRepository.findById}. */
type ApiKeyByIdRow = {
  id: string;
  client_id: string;
  status: 'active' | 'revoked';
  label: string | null;
  scopes: string[];
  expires_at: Date | null;
  signing_secret: string | null;
};

/** Row shape returned by {@link ClientApiKeyRepository.listByClient}. */
type ApiKeySummaryRow = {
  id: string;
  key_prefix: string;
  label: string | null;
  scopes: string[];
  status: 'active' | 'revoked';
  created_at: Date;
  last_used_at: Date | null;
  expires_at: Date | null;
  revoked_at: Date | null;
};

/**
 * Non-secret projection of a key for administrative listing. Never carries
 * the raw key or hash; `keyPrefix` is the only identifier safe to display.
 */
export type ApiKeySummary = {
  id: string;
  keyPrefix: string;
  label: string | null;
  scopes: readonly AuthScope[];
  status: 'active' | 'revoked';
  createdAt: Date;
  lastUsedAt: Date | null;
  expiresAt: Date | null;
  revokedAt: Date | null;
};

/**
 * Narrows a persisted `scopes` array to the canonical {@link AuthScope}
 * union, silently dropping anything the current build does not recognise.
 * Defensive: a scope removed in a future deploy must not crash auth.
 */
function toKnownScopes(raw: readonly string[]): AuthScope[] {
  return raw.filter(isAuthScope);
}

/**
 * Splits a raw key into its persistable shape. Returns `null` for
 * inputs that don't match the documented format so the caller can
 * short-circuit into the same 401 path as a missing/wrong key.
 */
export function parseRawApiKey(rawKey: string): { prefix: string; hash: string } | null {
  if (!rawKey.startsWith(API_KEY_PREFIX)) return null;
  const tail = rawKey.slice(API_KEY_PREFIX.length);
  if (tail.length !== RAW_KEY_HEX_LENGTH) return null;
  if (!/^[0-9a-f]+$/.test(tail)) return null;
  const prefix = tail.slice(0, PREFIX_LENGTH);
  const hash = createHash('sha256').update(rawKey).digest('hex');
  return { prefix, hash };
}

/** Constant-time equality for hex digests of equal length. */
function timingSafeEqualHex(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  return timingSafeEqual(Buffer.from(a, 'hex'), Buffer.from(b, 'hex'));
}

export type InsertApiKeyInput = {
  clientId: string;
  keyPrefix: string;
  keyHash: string;
  label: string | null;
  scopes: readonly string[];
  expiresAt: Date | null;
  signingSecret: string;
};

export interface ClientApiKeyRepository {
  findActiveByPrefix(sql: Sql, prefix: string): Promise<ApiKeyRow[]>;
  findById(sql: Sql, id: string): Promise<ApiKeyByIdRow | null>;
  listByClient(sql: Sql, clientId: string): Promise<ApiKeySummaryRow[]>;
  insert(sql: Sql, input: InsertApiKeyInput): Promise<{ id: string }>;
  touchLastUsed(sql: Sql, id: string): Promise<void>;
  revoke(sql: Sql, id: string): Promise<void>;
}

export class PgClientApiKeyRepository implements ClientApiKeyRepository {
  async findActiveByPrefix(sql: Sql, prefix: string): Promise<ApiKeyRow[]> {
    const result = await sql.query<ApiKeyRow>(
      `SELECT id, client_id, key_prefix, key_hash, label, scopes, expires_at
         FROM client_api_keys
        WHERE key_prefix = $1
          AND status = 'active'`,
      [prefix]
    );
    return result.rows;
  }

  async findById(sql: Sql, id: string): Promise<ApiKeyByIdRow | null> {
    const result = await sql.query<ApiKeyByIdRow>(
      `SELECT id, client_id, status, label, scopes, expires_at, signing_secret
         FROM client_api_keys
        WHERE id = $1`,
      [id]
    );
    return result.rows[0] ?? null;
  }

  async listByClient(sql: Sql, clientId: string): Promise<ApiKeySummaryRow[]> {
    const result = await sql.query<ApiKeySummaryRow>(
      `SELECT id, key_prefix, label, scopes, status,
              created_at, last_used_at, expires_at, revoked_at
         FROM client_api_keys
        WHERE client_id = $1
        ORDER BY created_at DESC`,
      [clientId]
    );
    return result.rows;
  }

  async insert(sql: Sql, input: InsertApiKeyInput): Promise<{ id: string }> {
    const result = await sql.query<{ id: string }>(
      `INSERT INTO client_api_keys (client_id, key_prefix, key_hash, label, scopes, expires_at, signing_secret)
       VALUES ($1, $2, $3, $4, $5::text[], $6, $7)
       RETURNING id`,
      [
        input.clientId,
        input.keyPrefix,
        input.keyHash,
        input.label,
        input.scopes as string[],
        input.expiresAt,
        input.signingSecret
      ]
    );
    const row = result.rows[0];
    if (!row) {
      throw new Error('client_api_keys insert returned no row');
    }
    return { id: row.id };
  }

  async touchLastUsed(sql: Sql, id: string): Promise<void> {
    await sql.query(
      `UPDATE client_api_keys SET last_used_at = now() WHERE id = $1`,
      [id]
    );
  }

  async revoke(sql: Sql, id: string): Promise<void> {
    await sql.query(
      `UPDATE client_api_keys
          SET status = 'revoked', revoked_at = now()
        WHERE id = $1
          AND status = 'active'`,
      [id]
    );
  }
}

/**
 * Runs `fn` inside a database transaction. Mirrors
 * {@link import('../../shared/db/database.js').Database.withTransaction}
 * but kept as a narrow callback so the service stays decoupled from the
 * `Database` class and is trivially fakeable in unit tests.
 */
export type WithTransaction = <T>(fn: (tx: Sql) => Promise<T>) => Promise<T>;

export type ClientApiKeyServiceDeps = {
  repository: ClientApiKeyRepository;
  sql: Sql;
  /**
   * Transaction runner used by {@link ClientApiKeyService.rotate} so the
   * mint-new + revoke-old pair commits atomically. Defaults to running the
   * callback directly against `sql` (no transaction) — acceptable for tests
   * and single-statement paths, but the composition root injects the real
   * `Database.withTransaction` so rotation is all-or-nothing in production.
   */
  withTransaction?: WithTransaction;
  /**
   * Backdoor for tests — generation injects this to produce a
   * deterministic raw key. Defaults to {@link randomBytes}.
   */
  randomBytes?: (size: number) => Buffer;
};

export class ClientApiKeyService {
  private readonly repository: ClientApiKeyRepository;
  private readonly sql: Sql;
  private readonly withTransaction: WithTransaction;
  private readonly rng: (size: number) => Buffer;

  constructor(deps: ClientApiKeyServiceDeps) {
    this.repository = deps.repository;
    this.sql = deps.sql;
    this.withTransaction = deps.withTransaction ?? ((fn) => fn(this.sql));
    this.rng = deps.randomBytes ?? randomBytes;
  }

  /**
   * Mint a new key for `clientId`. The raw value is returned **once** —
   * callers must hand it to the operator and not log it anywhere.
   * The persisted row stores only `SHA-256(rawKey)` + the 8-char prefix.
   *
   * `scopes` defaults to {@link DEFAULT_CLIENT_API_SCOPES}; `expiresAt`
   * defaults to `null` (never expires).
   */
  async generate(input: {
    clientId: string;
    label?: string | null;
    scopes?: readonly AuthScope[];
    expiresAt?: Date | null;
  }): Promise<GeneratedApiKey> {
    return this.insertKey(this.sql, {
      clientId: input.clientId,
      label: input.label ?? null,
      scopes: input.scopes ?? DEFAULT_CLIENT_API_SCOPES,
      expiresAt: input.expiresAt ?? null
    });
  }

  /**
   * Atomically rotate an existing key: mint a replacement carrying the same
   * client, scopes and expiry, then revoke the old key in the same
   * transaction. Returns the freshly minted key (raw value shown once), or
   * `null` when `apiKeyId` does not exist or is already revoked — the caller
   * surfaces that as a 404 without disclosing which.
   *
   * The new credential intentionally inherits the rotated key's scopes and
   * expiry so a routine rotation never silently changes a client's
   * capabilities; adjust scopes through a dedicated admin path instead.
   */
  async rotate(apiKeyId: string, ownerClientId?: string): Promise<GeneratedApiKey | null> {
    return this.withTransaction(async (tx) => {
      const existing = await this.repository.findById(tx, apiKeyId);
      if (!existing || existing.status !== 'active') {
        return null;
      }
      // Tenant isolation: an admin caller may only rotate keys owned by the
      // client it is authenticated for. A mismatch is surfaced as 404 (same
      // as "not found") so ownership never leaks.
      if (ownerClientId !== undefined && existing.client_id !== ownerClientId) {
        return null;
      }
      const minted = await this.insertKey(tx, {
        clientId: existing.client_id,
        label: existing.label,
        scopes: toKnownScopes(existing.scopes),
        expiresAt: existing.expires_at
      });
      await this.repository.revoke(tx, apiKeyId);
      return minted;
    });
  }

  /**
   * Revoke a key by id. Idempotent: revoking an already-revoked key still
   * returns `true` (it exists). Returns `false` when the key does not exist
   * or — when `ownerClientId` is supplied — belongs to a different client, so
   * an admin route can map that to 404 without leaking ownership.
   */
  async revoke(apiKeyId: string, ownerClientId?: string): Promise<boolean> {
    const existing = await this.repository.findById(this.sql, apiKeyId);
    if (!existing) return false;
    if (ownerClientId !== undefined && existing.client_id !== ownerClientId) {
      return false;
    }
    await this.repository.revoke(this.sql, apiKeyId);
    return true;
  }

  /**
   * Fetch the HMAC signing secret for a key id, or `null` when the key does
   * not exist or predates signing-secret issuance. Used exclusively by the
   * request-signature verifier; the secret is never surfaced elsewhere.
   */
  async getSigningSecret(apiKeyId: string): Promise<string | null> {
    const row = await this.repository.findById(this.sql, apiKeyId);
    return row?.signing_secret ?? null;
  }

  /**
   * List a client's keys for administrative display. Returns non-secret
   * metadata only (never the raw key or hash), newest first.
   */
  async listByClient(clientId: string): Promise<ApiKeySummary[]> {
    const rows = await this.repository.listByClient(this.sql, clientId);
    return rows.map((row) => ({
      id: row.id,
      keyPrefix: row.key_prefix,
      label: row.label,
      scopes: toKnownScopes(row.scopes),
      status: row.status,
      createdAt: row.created_at,
      lastUsedAt: row.last_used_at,
      expiresAt: row.expires_at,
      revokedAt: row.revoked_at
    }));
  }

  /**
   * Validate a raw key. Returns the principal on success, `null` on any
   * failure (unknown prefix, wrong hash, malformed input, expired key). The
   * caller should treat any `null` as 401 unauthorized without leaking which
   * branch failed.
   *
   * Bumps `last_used_at` opportunistically — best-effort, so a write
   * failure does not block the authenticated request.
   */
  async verify(rawKey: string): Promise<ClientPrincipal | null> {
    const parsed = parseRawApiKey(rawKey);
    if (!parsed) return null;

    const candidates = await this.repository.findActiveByPrefix(this.sql, parsed.prefix);
    let matched: ApiKeyRow | null = null;
    for (const candidate of candidates) {
      if (timingSafeEqualHex(parsed.hash, candidate.key_hash)) {
        matched = candidate;
        // Don't break — keep iterating to keep timing roughly constant
        // across "1 candidate matched" vs "N candidates inspected".
      }
    }
    if (!matched) return null;

    // Reject an expired key uniformly with an unknown/wrong key. Checked
    // here (not only in SQL) so the rule is explicit and unit-testable.
    if (matched.expires_at !== null && matched.expires_at.getTime() <= Date.now()) {
      return null;
    }

    try {
      await this.repository.touchLastUsed(this.sql, matched.id);
    } catch {
      // Non-fatal: a failed bookkeeping write should not deny an
      // otherwise-authenticated request. The pool error handler logs
      // the underlying cause.
    }

    return {
      clientId: matched.client_id,
      apiKeyId: matched.id,
      keyPrefix: matched.key_prefix,
      label: matched.label,
      scopes: toKnownScopes(matched.scopes)
    };
  }

  /** Shared mint path used by {@link generate} and {@link rotate}. */
  private async insertKey(
    sql: Sql,
    input: {
      clientId: string;
      label: string | null;
      scopes: readonly AuthScope[];
      expiresAt: Date | null;
    }
  ): Promise<GeneratedApiKey> {
    const tail = this.rng(RAW_KEY_BYTES).toString('hex');
    const rawKey = `${API_KEY_PREFIX}${tail}`;
    const prefix = tail.slice(0, PREFIX_LENGTH);
    const hash = createHash('sha256').update(rawKey).digest('hex');
    const signingSecret = this.rng(SIGNING_SECRET_BYTES).toString('hex');
    const { id } = await this.repository.insert(sql, {
      clientId: input.clientId,
      keyPrefix: prefix,
      keyHash: hash,
      label: input.label,
      scopes: input.scopes,
      expiresAt: input.expiresAt,
      signingSecret
    });
    return {
      rawKey,
      id,
      clientId: input.clientId,
      keyPrefix: prefix,
      label: input.label,
      scopes: input.scopes,
      expiresAt: input.expiresAt,
      signingSecret
    };
  }
}
