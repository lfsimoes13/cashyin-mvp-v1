/**
 * Per-user access grants for the trusted `frontend_bff` channel (deviation D7).
 *
 * The BFF authenticates a human and presents `(actorUserId, clientId)` to the
 * Core. Without RBAC, every such actor receives the fixed `DEFAULT_BFF_SCOPES`.
 * This module adds an optional per-`(actorUserId, clientId)` grant: when
 * `BFF_RBAC_MODE='enforce'`, the authenticator resolves the actor's granted
 * scopes and **intersects** them with `DEFAULT_BFF_SCOPES` (defence in depth —
 * the Core's default set remains the hard ceiling; the BFF can never escalate).
 *
 * An actor with no active grant for the tenant is rejected (the BFF must
 * provision a grant first, via the admin endpoints). Grants are tenant-scoped:
 * an operator manages only its own client's actors.
 */

import type { Sql } from '../../shared/db/sql.js';
import { AppError } from '../../shared/errors/app-error.js';
import { isAuthScope, type AuthScope } from '../../shared/auth/auth-scopes.js';
import { DEFAULT_BFF_SCOPES } from './authenticate.js';

export type UserClientGrant = {
  actorUserId: string;
  clientId: string;
  scopes: readonly AuthScope[];
  status: 'active' | 'revoked';
  createdAt: Date;
  updatedAt: Date;
};

type UserClientGrantRow = {
  actor_user_id: string;
  client_id: string;
  scopes: string[];
  status: 'active' | 'revoked';
  created_at: Date;
  updated_at: Date;
};

function mapRow(row: UserClientGrantRow): UserClientGrant {
  return {
    actorUserId: row.actor_user_id,
    clientId: row.client_id,
    scopes: row.scopes.filter(isAuthScope),
    status: row.status,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}

export interface UserClientGrantRepository {
  /** Scopes of the active grant for `(actorUserId, clientId)`, or null when none. */
  findActiveScopes(sql: Sql, actorUserId: string, clientId: string): Promise<string[] | null>;
  upsert(
    sql: Sql,
    input: { actorUserId: string; clientId: string; scopes: readonly string[] }
  ): Promise<UserClientGrantRow>;
  listByClient(sql: Sql, clientId: string): Promise<UserClientGrantRow[]>;
  /** Mark the grant revoked. Returns false when no row matched. */
  revoke(sql: Sql, clientId: string, actorUserId: string): Promise<boolean>;
}

export class PgUserClientGrantRepository implements UserClientGrantRepository {
  async findActiveScopes(sql: Sql, actorUserId: string, clientId: string): Promise<string[] | null> {
    const result = await sql.query<{ scopes: string[] }>(
      `SELECT scopes
         FROM user_client_grants
        WHERE actor_user_id = $1 AND client_id = $2 AND status = 'active'`,
      [actorUserId, clientId]
    );
    return result.rows[0]?.scopes ?? null;
  }

  async upsert(
    sql: Sql,
    input: { actorUserId: string; clientId: string; scopes: readonly string[] }
  ): Promise<UserClientGrantRow> {
    const result = await sql.query<UserClientGrantRow>(
      `INSERT INTO user_client_grants (actor_user_id, client_id, scopes, status)
       VALUES ($1, $2, $3::text[], 'active')
       ON CONFLICT (actor_user_id, client_id)
       DO UPDATE SET scopes = EXCLUDED.scopes, status = 'active', updated_at = now()
       RETURNING actor_user_id, client_id, scopes, status, created_at, updated_at`,
      [input.actorUserId, input.clientId, input.scopes as string[]]
    );
    const row = result.rows[0];
    if (!row) {
      throw new Error('user_client_grants upsert returned no row');
    }
    return row;
  }

  async listByClient(sql: Sql, clientId: string): Promise<UserClientGrantRow[]> {
    const result = await sql.query<UserClientGrantRow>(
      `SELECT actor_user_id, client_id, scopes, status, created_at, updated_at
         FROM user_client_grants
        WHERE client_id = $1
        ORDER BY created_at DESC`,
      [clientId]
    );
    return result.rows;
  }

  async revoke(sql: Sql, clientId: string, actorUserId: string): Promise<boolean> {
    const result = await sql.query(
      `UPDATE user_client_grants
          SET status = 'revoked', updated_at = now()
        WHERE client_id = $1 AND actor_user_id = $2 AND status = 'active'`,
      [clientId, actorUserId]
    );
    return (result.rowCount ?? 0) > 0;
  }
}

export type UserClientGrantServiceDeps = {
  repository: UserClientGrantRepository;
  sql: Sql;
};

export class UserClientGrantService {
  private readonly repository: UserClientGrantRepository;
  private readonly sql: Sql;

  constructor(deps: UserClientGrantServiceDeps) {
    this.repository = deps.repository;
    this.sql = deps.sql;
  }

  /**
   * Resolve the BFF scopes granted to `(actorUserId, clientId)`, narrowed to
   * known scopes. Returns `null` when the actor has no active grant for the
   * tenant. The caller (authenticator) intersects this with the ceiling
   * (`DEFAULT_BFF_SCOPES`).
   */
  async resolveBffScopes(actorUserId: string, clientId: string): Promise<readonly AuthScope[] | null> {
    const scopes = await this.repository.findActiveScopes(this.sql, actorUserId, clientId);
    if (scopes === null) return null;
    return scopes.filter(isAuthScope);
  }

  /**
   * Upsert a grant. Scopes must be a subset of `DEFAULT_BFF_SCOPES` — the BFF
   * channel ceiling — so a grant can never reference an out-of-band capability.
   */
  async grant(input: {
    clientId: string;
    actorUserId: string;
    scopes: readonly string[];
  }): Promise<UserClientGrant> {
    const unknown = input.scopes.filter((scope) => !isAuthScope(scope));
    if (unknown.length > 0) {
      throw new AppError('validation_error', `Unknown scope(s): ${unknown.join(', ')}`, 422);
    }
    const overCeiling = input.scopes.filter(
      (scope) => !(DEFAULT_BFF_SCOPES as readonly string[]).includes(scope)
    );
    if (overCeiling.length > 0) {
      throw new AppError(
        'validation_error',
        `Scope(s) not grantable to the BFF channel: ${overCeiling.join(', ')}`,
        422
      );
    }
    const row = await this.repository.upsert(this.sql, {
      actorUserId: input.actorUserId,
      clientId: input.clientId,
      scopes: input.scopes
    });
    return mapRow(row);
  }

  async listByClient(clientId: string): Promise<UserClientGrant[]> {
    const rows = await this.repository.listByClient(this.sql, clientId);
    return rows.map(mapRow);
  }

  /** Returns false when no active grant matched (404 at the route layer). */
  async revoke(clientId: string, actorUserId: string): Promise<boolean> {
    return this.repository.revoke(this.sql, clientId, actorUserId);
  }
}
