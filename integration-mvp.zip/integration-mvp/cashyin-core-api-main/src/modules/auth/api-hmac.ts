/**
 * Request-signature (HMAC) verification for the `api_direct` channel.
 *
 * A client signs a canonical string with the per-key `signing_secret`
 * (returned once at issuance) and sends:
 *
 *   - `X-CashYin-Timestamp` — epoch milliseconds when the request was signed.
 *   - `X-CashYin-Nonce`     — unique per request (replay protection).
 *   - `X-CashYin-Signature` — `sha256=<hex>` HMAC of the canonical string.
 *
 * Canonical string (newline-joined):
 *
 *   METHOD \n URL \n TIMESTAMP \n NONCE \n SHA256(canonical-json-body)
 *
 * where the body digest is over a deterministic (sorted-key) JSON encoding so
 * the client and server agree without the server needing the raw bytes. An
 * empty body hashes the empty string.
 *
 * Staged by `API_HMAC_MODE`:
 *   - `off`     — headers ignored.
 *   - `shadow`  — verify when present; log mismatches/missing; never block.
 *   - `enforce` — require a valid, fresh, non-replayed signature.
 *
 * Replay protection "spends" each nonce once within the validity window via a
 * pluggable {@link ApiHmacNonceStore}. The default is an in-process store
 * (single-instance correct); inject {@link PgApiHmacNonceStore} for a shared,
 * cross-instance store before enabling enforcement in a fleet (deviation D16).
 * See docs/security/auth-threat-model.md.
 */

import { createHmac } from 'node:crypto';
import { createHash } from 'node:crypto';
import type { FastifyRequest } from 'fastify';
import { timingSafeEqualString } from '../../shared/security/hmac.js';
import { invalidAuthError } from '../../shared/auth/auth-errors.js';
import { metrics } from '../../shared/observability/metrics.js';
import {
  InMemoryApiHmacNonceStore,
  type ApiHmacNonceStore
} from './api-hmac-nonce-store.js';

export type ApiHmacMode = 'off' | 'shadow' | 'enforce';

export const HMAC_TIMESTAMP_HEADER = 'x-cashyin-timestamp' as const;
export const HMAC_NONCE_HEADER = 'x-cashyin-nonce' as const;
export const HMAC_SIGNATURE_HEADER = 'x-cashyin-signature' as const;

const HMAC_DECISIONS_METRIC = 'cashyin_api_hmac_decisions_total';
const HMAC_DECISIONS_HELP = 'Request-signature decisions by mode and decision.';

/** Deterministic JSON: object keys sorted recursively, no insignificant whitespace. */
export function stableStringify(value: unknown): string {
  if (value === null || typeof value !== 'object') {
    return JSON.stringify(value) ?? 'null';
  }
  if (Array.isArray(value)) {
    return `[${value.map((item) => stableStringify(item)).join(',')}]`;
  }
  const entries = Object.keys(value as Record<string, unknown>)
    .sort()
    .map((key) => `${JSON.stringify(key)}:${stableStringify((value as Record<string, unknown>)[key])}`);
  return `{${entries.join(',')}}`;
}

export function canonicalBodyDigest(body: unknown): string {
  const serialized = body === undefined ? '' : stableStringify(body);
  return createHash('sha256').update(serialized).digest('hex');
}

export function buildCanonicalString(parts: {
  method: string;
  url: string;
  timestamp: string;
  nonce: string;
  bodyDigest: string;
}): string {
  return [parts.method.toUpperCase(), parts.url, parts.timestamp, parts.nonce, parts.bodyDigest].join('\n');
}

function headerString(request: FastifyRequest, name: string): string | undefined {
  const value = request.headers[name];
  return typeof value === 'string' && value.length > 0 ? value : undefined;
}

export type ApiHmacVerifierDeps = {
  mode: ApiHmacMode;
  clockSkewMs: number;
  /** Resolve the signing secret for the authenticated key, or null if none. */
  getSigningSecret: (apiKeyId: string) => Promise<string | null>;
  /**
   * Replay-protection store. Defaults to an in-process store (single-instance
   * only). Inject a shared store (e.g. {@link PgApiHmacNonceStore}) for
   * multi-instance enforcement.
   */
  nonceStore?: ApiHmacNonceStore;
  now?: () => number;
};

type Outcome = { ok: true } | { ok: false; reason: string };

export class ApiHmacVerifier {
  private readonly mode: ApiHmacMode;
  private readonly clockSkewMs: number;
  private readonly getSigningSecret: (apiKeyId: string) => Promise<string | null>;
  private readonly now: () => number;
  private readonly nonces: ApiHmacNonceStore;

  constructor(deps: ApiHmacVerifierDeps) {
    this.mode = deps.mode;
    this.clockSkewMs = deps.clockSkewMs;
    this.getSigningSecret = deps.getSigningSecret;
    this.now = deps.now ?? Date.now;
    this.nonces = deps.nonceStore ?? new InMemoryApiHmacNonceStore();
  }

  /**
   * Verify the request signature for an authenticated `api_direct` key.
   * No-op in `off`. In `shadow` it logs but never throws. In `enforce` it
   * throws {@link invalidAuthError} on any failure.
   */
  async assert(request: FastifyRequest, apiKeyId: string): Promise<void> {
    if (this.mode === 'off') return;

    const outcome = await this.evaluate(request, apiKeyId);
    const route = request.routeOptions.url ?? request.url;

    if (outcome.ok) {
      metrics.increment(HMAC_DECISIONS_METRIC, HMAC_DECISIONS_HELP, { mode: this.mode, decision: 'allow', route });
      return;
    }

    metrics.increment(HMAC_DECISIONS_METRIC, HMAC_DECISIONS_HELP, {
      mode: this.mode,
      decision: this.mode === 'enforce' ? 'deny' : 'would_deny',
      route,
      reason: outcome.reason
    });

    if (this.mode === 'enforce') {
      throw invalidAuthError();
    }

    // shadow: never block; surface coarse reason only (no secrets/payloads).
    request.log.warn({ authShadow: true, apiHmac: true, reason: outcome.reason, route }, 'request signature would be rejected');
  }

  private async evaluate(request: FastifyRequest, apiKeyId: string): Promise<Outcome> {
    const timestamp = headerString(request, HMAC_TIMESTAMP_HEADER);
    const nonce = headerString(request, HMAC_NONCE_HEADER);
    const signature = headerString(request, HMAC_SIGNATURE_HEADER);
    if (!timestamp || !nonce || !signature) {
      return { ok: false, reason: 'missing_headers' };
    }

    const tsMs = Number(timestamp);
    if (!Number.isFinite(tsMs)) {
      return { ok: false, reason: 'bad_timestamp' };
    }
    const nowMs = this.now();
    if (Math.abs(nowMs - tsMs) > this.clockSkewMs) {
      return { ok: false, reason: 'stale_timestamp' };
    }

    const secret = await this.getSigningSecret(apiKeyId);
    if (!secret) {
      return { ok: false, reason: 'no_signing_secret' };
    }

    const canonical = buildCanonicalString({
      method: request.method,
      url: request.url,
      timestamp,
      nonce,
      bodyDigest: canonicalBodyDigest(request.body)
    });
    const expected = `sha256=${createHmac('sha256', secret).update(canonical).digest('hex')}`;
    if (!timingSafeEqualString(signature, expected)) {
      return { ok: false, reason: 'bad_signature' };
    }

    // Signature valid — only now spend the nonce (so a bad signature can't
    // burn a legitimate nonce). Window = 2× skew to cover clock drift both ways.
    const fresh = await this.nonces.checkAndRecord(
      apiKeyId,
      nonce,
      nowMs + this.clockSkewMs * 2,
      nowMs
    );
    if (!fresh) {
      return { ok: false, reason: 'replayed_nonce' };
    }

    return { ok: true };
  }
}
