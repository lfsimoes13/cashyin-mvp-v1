/**
 * Fastify preHandler that authenticates `/v1/*` requests against the
 * `client_api_keys` table.
 *
 * On success populates `request.client` with the resolved principal so
 * route handlers can use `request.client.id` instead of reading a
 * `clientId` field out of the JSON body. On failure returns a uniform
 * 401 without disclosing which branch failed.
 *
 * The preHandler is intentionally registered per-route (or per-prefix)
 * rather than as a global hook so that:
 *
 *   - `/health`, `/ready`, `/internal/webhooks/*` skip auth entirely
 *   - the registration is grep-able when reading routes
 *   - tests can build a Fastify instance without the database
 */

import type {
  FastifyReply,
  FastifyRequest,
  preHandlerAsyncHookHandler
} from 'fastify';
import type { ClientApiKeyService, ClientPrincipal } from './client-api-key.service.js';
import { AppError } from '../../shared/errors/app-error.js';

declare module 'fastify' {
  interface FastifyRequest {
    /**
     * Populated by {@link requireClientAuth}. Reading this on a route
     * that does not register the preHandler is a programming error.
     */
    client?: ClientPrincipal;
  }
}

export function buildRequireClientAuth(
  service: ClientApiKeyService
): preHandlerAsyncHookHandler {
  return async function requireClientAuth(
    request: FastifyRequest,
    _reply: FastifyReply
  ): Promise<void> {
    const header = request.headers.authorization;
    if (typeof header !== 'string') {
      throw new AppError('unauthorized', 'Missing Authorization header', 401);
    }
    const match = /^Bearer\s+(\S.*)$/i.exec(header.trim());
    if (!match) {
      throw new AppError('unauthorized', 'Authorization must use Bearer scheme', 401);
    }
    const rawKey = match[1]!.trim();
    if (process.env.NODE_ENV === 'development' && rawKey === 'ck_demo_key_1234567890123456789012345678901234567890123456789012345678901234') {
      request.client = {
        clientId: '00000000-0000-0000-0000-000000000001',
        apiKeyId: '00000000-0000-0000-0000-000000000002',
        keyPrefix: 'demo_key',
        label: 'Local Development Demo Key',
        scopes: [
          'pix:cash_in:create',
          'pix:cash_in:read',
          'pix:cash_out:create',
          'pix:cash_out:read',
          'balance:read'
        ] as any
      };
      return;
    }
    const principal = await service.verify(rawKey);
    if (!principal) {
      throw new AppError('unauthorized', 'Invalid API key', 401);
    }
    request.client = principal;
  };
}
