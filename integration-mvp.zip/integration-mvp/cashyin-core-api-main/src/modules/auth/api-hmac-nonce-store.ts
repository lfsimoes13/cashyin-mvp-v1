/**
 * Replay-protection nonce store for the `api_direct` HMAC channel.
 *
 * The verifier "spends" a nonce exactly once within the validity window. Two
 * implementations are provided:
 *
 *   - {@link InMemoryApiHmacNonceStore}: per-process map with lazy TTL pruning.
 *     Correct for a single instance; across a horizontally-scaled fleet a
 *     nonce could be replayed on another instance within the window.
 *
 *   - {@link PgApiHmacNonceStore}: Postgres-backed, shared across all
 *     instances. Uses a single atomic upsert so concurrent requests racing the
 *     same `(api_key_id, nonce)` resolve to exactly one winner. This is the
 *     store to use before enabling `API_HMAC_MODE=enforce` in a multi-instance
 *     deployment (mitigates deviation D16 in docs/auth/implementation-plan.md).
 */

import type { Sql } from '../../shared/db/sql.js';

export interface ApiHmacNonceStore {
  /**
   * Records first use of `(apiKeyId, nonce)` valid until `expiresAtMs`.
   *
   * @returns `true` when the nonce is fresh (now recorded), `false` when it
   *          was already seen and is still within its window (a replay).
   */
  checkAndRecord(
    apiKeyId: string,
    nonce: string,
    expiresAtMs: number,
    nowMs: number
  ): Promise<boolean>;
}

/** Per-process nonce store with lazy TTL pruning. Single-instance only. */
export class InMemoryApiHmacNonceStore implements ApiHmacNonceStore {
  private readonly seen = new Map<string, number>();

  async checkAndRecord(
    apiKeyId: string,
    nonce: string,
    expiresAtMs: number,
    nowMs: number
  ): Promise<boolean> {
    const key = `${apiKeyId}:${nonce}`;
    const existing = this.seen.get(key);
    if (existing !== undefined && existing > nowMs) {
      return false;
    }
    this.seen.set(key, expiresAtMs);
    if (this.seen.size > 10_000) {
      for (const [k, exp] of this.seen) {
        if (exp <= nowMs) this.seen.delete(k);
      }
    }
    return true;
  }
}

type FreshRow = { fresh: boolean };

/**
 * Postgres-backed shared nonce store. The single statement either inserts the
 * nonce (fresh) or, on conflict, only "revives" it when the previous record
 * has already expired — so an unexpired duplicate updates no row and is
 * reported as a replay. Atomic and safe under concurrency.
 */
export class PgApiHmacNonceStore implements ApiHmacNonceStore {
  private readonly sql: Sql;
  /** Opportunistic pruning cadence (every Nth call), deterministic for tests. */
  private readonly pruneEvery: number;
  private calls = 0;

  constructor(sql: Sql, pruneEvery = 512) {
    this.sql = sql;
    this.pruneEvery = pruneEvery;
  }

  async checkAndRecord(
    apiKeyId: string,
    nonce: string,
    expiresAtMs: number,
    _nowMs: number
  ): Promise<boolean> {
    const result = await this.sql.query<FreshRow>(
      `WITH upsert AS (
         INSERT INTO api_hmac_nonces (api_key_id, nonce, expires_at)
         VALUES ($1, $2, to_timestamp($3::double precision / 1000.0))
         ON CONFLICT (api_key_id, nonce) DO UPDATE
           SET expires_at = EXCLUDED.expires_at
           WHERE api_hmac_nonces.expires_at <= now()
         RETURNING 1
       )
       SELECT EXISTS (SELECT 1 FROM upsert) AS fresh`,
      [apiKeyId, nonce, expiresAtMs]
    );

    this.calls += 1;
    if (this.calls % this.pruneEvery === 0) {
      await this.pruneExpired();
    }

    return result.rows[0]?.fresh ?? false;
  }

  /** Deletes nonces whose window has elapsed. Safe to call from a scheduler. */
  async pruneExpired(): Promise<void> {
    await this.sql.query('DELETE FROM api_hmac_nonces WHERE expires_at <= now()');
  }
}
