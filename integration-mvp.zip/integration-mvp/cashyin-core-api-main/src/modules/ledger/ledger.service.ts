import type { Sql } from '../../shared/db/sql.js';
import { AppError } from '../../shared/errors/app-error.js';
import type { ProviderName } from '../../providers/contracts/provider-types.js';
import type {
  LedgerAccountRecord,
  LedgerAccountRepository,
  LedgerAccountScope
} from './ledger-account.repository.js';
import type { LedgerIdempotencyKeyRepository } from './ledger-idempotency.repository.js';
import type {
  LedgerEntryInsertInput,
  LedgerEntryRecord,
  LedgerEntryRepository
} from './ledger.repository.js';
import type { LedgerEntryDraft } from './ledger.types.js';

/**
 * Canonical account_type discriminators used by {@link LedgerService}. The
 * `system:` prefix marks accounts that are NOT scoped to a client or
 * provider — they aggregate platform-wide P&L (revenue, expense, subsidy)
 * and have a single canonical row in `ledger_accounts` with both client_id
 * and provider_account_id NULL.
 */
export const LEDGER_ACCOUNT_TYPES = {
  clientLiability: 'client_liability',
  providerClearing: 'provider_clearing',
  cashyinFeeRevenue: 'system:cashyin_fee_revenue',
  providerFeeExpense: 'system:provider_fee_expense',
  subsidyExpense: 'system:subsidy_expense'
} as const;

export type CashoutReturnReversalPosting = {
  transactionId: string;
  clientId: string;
  providerName: ProviderName;
  providerAccountId: string;
  providerReferenceId: string | null;
  principalAmountCents: number;
  /**
   * CashYin commercial fee originally charged to the client on
   * `cash_out_completed`. When > 0 the reversal batch includes two
   * additional entries that return the fee from `cashyin_fee_revenue`
   * back to `client_liability`, so the client's net effect is zero.
   * Defaults to 0 (principal-only reversal) for callers that do not
   * have the assessment loaded.
   */
  clientFeeCents?: number;
  /**
   * Audit reference to the original posted `fee_assessment`. The
   * reversal does NOT mutate that row; the id is only persisted in
   * the entry metadata for traceability.
   */
  feeAssessmentId: string | null;
  metadata?: Record<string, unknown>;
};

export type FeeAssessmentPosting = {
  transactionId: string;
  /**
   * Cash-in: `cash_in_paid`. Cash-out: `cash_out_confirmed` (planned for a
   * follow-up PR; Phase 5 currently only invokes the helper from the
   * cash-in webhook handler). The trigger event is recorded in the entry
   * metadata for audit and to disambiguate multiple postings against the
   * same underlying transaction id.
   */
  triggerEvent: string;
  operationType: 'cash_in' | 'cash_out';
  clientId: string;
  providerName: ProviderName;
  providerAccountId: string;
  /** External provider-side identifier (charge id, payment id, e2e id). */
  providerReferenceId: string | null;
  /** Principal amount being moved (gross). */
  principalAmountCents: number;
  /** CashYin commercial fee charged to the client. */
  clientFeeCents: number;
  /** Provider cost charged to CashYin. */
  providerCostCents: number;
  /**
   * Subsidy magnitude when `provider_cost > client_fee`. The service
   * computes this from the two values; the field is here so callers can
   * pass through an already-reconciled value from the fee_assessment row
   * and the service asserts consistency.
   */
  subsidyCents: number;
  /**
   * Audit reference to the fee_assessment row. Nullable because the
   * cash-in webhook handler MUST credit the client even when no
   * pricing/cost rules are configured (a zero-fee posting still credits
   * the principal). When null, the principal pair is the only batch
   * leg and `clientFeeCents` / `providerCostCents` MUST also be 0.
   */
  feeAssessmentId: string | null;
  metadata?: Record<string, unknown>;
};

/**
 * Options applied to {@link LedgerService.appendEntries} when the caller
 * wants the batch to be deduplicated across re-deliveries (webhook
 * replays, worker crashes mid-flight). When `idempotencyKey` is
 * provided, the service tries to claim the key in
 * `ledger_idempotency_keys` inside the caller's transaction; on
 * conflict the batch is treated as already posted and the method
 * returns an empty array.
 */
export type AppendEntriesOptions = {
  idempotencyKey?: string;
};

/**
 * Outcome of a posting that supports idempotency. Distinct from
 * `LedgerEntryRecord[]` so the caller can tell "I just posted N entries"
 * (`first_post`) apart from "another worker already posted this batch"
 * (`duplicate_skipped`). Used by `PaymentService.handleChargePaid` to
 * emit a structured observability event with `idempotency_result`.
 */
export type PostFeeAssessmentResult =
  | { kind: 'first_post'; entries: LedgerEntryRecord[] }
  | { kind: 'duplicate_skipped'; idempotencyKey: string };

/**
 * Owns the append-only ledger invariants: every batch must be balanced and
 * entries are never updated in place. Reversals must be expressed as new
 * compensating batches; this service does not expose mutation primitives.
 */
export class LedgerService {
  constructor(
    private readonly entryRepository: LedgerEntryRepository,
    private readonly accountRepository: LedgerAccountRepository,
    private readonly idempotencyRepository?: LedgerIdempotencyKeyRepository
  ) {}

  async ensureAccount(sql: Sql, scope: LedgerAccountScope) {
    return this.accountRepository.ensure(sql, scope);
  }

  async appendEntries(
    sql: Sql,
    entries: LedgerEntryDraft[],
    options: AppendEntriesOptions = {}
  ): Promise<LedgerEntryRecord[]> {
    if (entries.length < 2) {
      throw new AppError(
        'ledger_double_entry_required',
        'Ledger postings must use at least two balanced entries',
        500
      );
    }

    if (options.idempotencyKey && this.idempotencyRepository) {
      const acquired = await this.idempotencyRepository.tryAcquire(sql, options.idempotencyKey);
      if (!acquired) {
        return [];
      }
    }

    let totalDebit = 0;
    let totalCredit = 0;
    for (const entry of entries) {
      if (entry.amountCents <= 0) {
        throw new AppError(
          'ledger_amount_invalid',
          'Ledger entry amount must be a positive integer',
          500
        );
      }
      if (entry.direction === 'debit') totalDebit += entry.amountCents;
      else totalCredit += entry.amountCents;
    }

    if (totalDebit !== totalCredit) {
      throw new AppError('ledger_not_balanced', 'Ledger entries are not balanced', 500);
    }

    const inserts: LedgerEntryInsertInput[] = entries.map((entry) => ({
      transactionId: entry.transactionId,
      accountId: entry.accountId,
      clientId: entry.clientId,
      providerName: entry.providerName ?? null,
      providerReferenceId: entry.providerReferenceId ?? null,
      direction: entry.direction,
      amountCents: entry.amountCents,
      reason: entry.reason,
      metadata: options.idempotencyKey
        ? { ...(entry.metadata ?? {}), idempotencyKey: options.idempotencyKey }
        : entry.metadata ?? {}
    }));

    return this.entryRepository.appendBatch(sql, inserts);
  }

  /**
   * Posts a complete double-entry batch for one fee_assessment:
   *
   *   Cash-in `paid`:
   *     debit  provider_clearing[provider_account]   principal
   *     credit client_liability[client]              principal
   *     debit  client_liability[client]              client_fee     (when > 0)
   *     credit cashyin_fee_revenue                   client_fee
   *     debit  provider_fee_expense                  provider_cost  (when > 0)
   *     credit provider_clearing[provider_account]   provider_cost
   *
   *   Cash-out `confirmed`:
   *     debit  client_liability[client]              principal
   *     credit provider_clearing[provider_account]   principal
   *     debit  client_liability[client]              client_fee     (when > 0)
   *     credit cashyin_fee_revenue                   client_fee
   *     debit  provider_fee_expense                  provider_cost  (when > 0)
   *     credit provider_clearing[provider_account]   provider_cost
   *
   *   Subsidy (per docs/tariff-system-plan.md §10.3): when subsidy > 0
   *   (i.e. provider_cost > client_fee) the platform absorbs the
   *   difference via:
   *     debit  subsidy_expense                       subsidy
   *     credit cashyin_fee_revenue                   subsidy
   *   This keeps the revenue line gross while the subsidy line carries
   *   the absorbed loss; for reporting, `net_revenue = revenue - subsidy`.
   *
   * Invariants enforced:
   *   - Every entry has amount_cents > 0 (entries with amount 0 are skipped).
   *   - The batch as a whole is balanced (asserted by appendEntries).
   *   - `subsidyCents` provided by the caller MUST match
   *     `max(0, provider_cost - client_fee)`; otherwise we throw a 500
   *     (this is a programming error — caller hydrated from fee_assessments
   *     which has the same check at the DB level).
   */
  async postFeeAssessment(
    sql: Sql,
    posting: FeeAssessmentPosting
  ): Promise<PostFeeAssessmentResult> {
    assertConsistentSubsidy(posting);
    assertConsistentNullAssessment(posting);

    const accounts = await this.resolveFeeAccounts(sql, posting);
    const drafts = buildFeeAssessmentDrafts(posting, accounts);

    if (drafts.length === 0) {
      // Defensive: every posting must move at least the principal pair.
      // A non-positive principal is rejected here instead of silently
      // emitting an empty batch (which `appendEntries` would also reject).
      throw new AppError(
        'ledger_posting_empty',
        'Fee assessment posting produced no ledger drafts (principal must be > 0)',
        500
      );
    }

    const idempotencyKey = `${posting.triggerEvent}:${posting.transactionId}`;
    const entries = await this.appendEntries(sql, drafts, { idempotencyKey });
    if (entries.length === 0) {
      return { kind: 'duplicate_skipped', idempotencyKey };
    }
    return { kind: 'first_post', entries };
  }

  /**
   * Posts a chargeback / Pix-return reversal for a cash-out that
   * previously settled in `completed`. The destination bank pushed the
   * money back so the posting is fully reversed:
   *
   *   debit  provider_clearing[provider_account]   principal
   *   credit client_liability[client]              principal
   *   debit  cashyin_fee_revenue                   client_fee  (when > 0)
   *   credit client_liability[client]              client_fee  (when > 0)
   *
   * The client fee is always refunded on return — the client should not
   * be charged for a transfer that did not settle. Pass `clientFeeCents`
   * from the `fee_assessment` row to include the fee reversal entries in
   * the same idempotent batch; omit it (or pass 0) for a principal-only
   * reversal (back-compat with callers that do not load the assessment).
   *
   * The reversal batch carries `reason='cash_out.*.reversal.*'` so it is
   * easy to distinguish from the original `cash_out_completed` posting in
   * reporting queries.
   */
  async postCashoutReturnReversal(
    sql: Sql,
    posting: CashoutReturnReversalPosting
  ): Promise<LedgerEntryRecord[]> {
    if (posting.principalAmountCents <= 0) {
      throw new AppError(
        'ledger_reversal_principal_invalid',
        'Cash-out reversal principal must be a positive integer',
        500
      );
    }
    const clientFeeCents = posting.clientFeeCents ?? 0;
    const idempotencyKey = `cash_out_returned:${posting.transactionId}`;

    const accountResolvers: Promise<LedgerAccountRecord>[] = [
      this.accountRepository.ensure(sql, {
        kind: 'client',
        clientId: posting.clientId,
        accountType: LEDGER_ACCOUNT_TYPES.clientLiability
      }),
      this.accountRepository.ensure(sql, {
        kind: 'provider',
        providerAccountId: posting.providerAccountId,
        accountType: LEDGER_ACCOUNT_TYPES.providerClearing
      })
    ];
    if (clientFeeCents > 0) {
      accountResolvers.push(
        this.accountRepository.ensure(sql, {
          kind: 'system',
          accountType: LEDGER_ACCOUNT_TYPES.cashyinFeeRevenue
        })
      );
    }
    const [client, provider, feeRevenue] = await Promise.all(accountResolvers);

    const metadata = {
      triggerEvent: 'cash_out_returned',
      operationType: 'cash_out' as const,
      ...(posting.feeAssessmentId !== null ? { feeAssessmentId: posting.feeAssessmentId } : {}),
      ...(posting.metadata ?? {})
    };

    const drafts: LedgerEntryDraft[] = [
      {
        transactionId: posting.transactionId,
        accountId: provider!.id,
        clientId: null,
        direction: 'debit',
        amountCents: posting.principalAmountCents,
        reason: 'cash_out.principal.reversal.debit',
        providerName: posting.providerName,
        providerReferenceId: posting.providerReferenceId,
        metadata
      },
      {
        transactionId: posting.transactionId,
        accountId: client!.id,
        clientId: client!.clientId,
        direction: 'credit',
        amountCents: posting.principalAmountCents,
        reason: 'cash_out.principal.reversal.credit',
        providerName: posting.providerName,
        providerReferenceId: posting.providerReferenceId,
        metadata
      }
    ];

    if (clientFeeCents > 0 && feeRevenue) {
      drafts.push(
        {
          transactionId: posting.transactionId,
          accountId: feeRevenue.id,
          clientId: null,
          direction: 'debit',
          amountCents: clientFeeCents,
          reason: 'cash_out.fee.reversal.debit',
          providerName: posting.providerName,
          providerReferenceId: posting.providerReferenceId,
          metadata
        },
        {
          transactionId: posting.transactionId,
          accountId: client!.id,
          clientId: client!.clientId,
          direction: 'credit',
          amountCents: clientFeeCents,
          reason: 'cash_out.fee.reversal.credit',
          providerName: posting.providerName,
          providerReferenceId: posting.providerReferenceId,
          metadata
        }
      );
    }

    return this.appendEntries(sql, drafts, { idempotencyKey });
  }

  private async resolveFeeAccounts(
    sql: Sql,
    posting: FeeAssessmentPosting
  ): Promise<FeeAccountSet> {
    const [client, provider, feeRevenue, providerExpense, subsidyExpense] = await Promise.all([
      this.accountRepository.ensure(sql, {
        kind: 'client',
        clientId: posting.clientId,
        accountType: LEDGER_ACCOUNT_TYPES.clientLiability
      }),
      this.accountRepository.ensure(sql, {
        kind: 'provider',
        providerAccountId: posting.providerAccountId,
        accountType: LEDGER_ACCOUNT_TYPES.providerClearing
      }),
      this.accountRepository.ensure(sql, {
        kind: 'system',
        accountType: LEDGER_ACCOUNT_TYPES.cashyinFeeRevenue
      }),
      this.accountRepository.ensure(sql, {
        kind: 'system',
        accountType: LEDGER_ACCOUNT_TYPES.providerFeeExpense
      }),
      this.accountRepository.ensure(sql, {
        kind: 'system',
        accountType: LEDGER_ACCOUNT_TYPES.subsidyExpense
      })
    ]);
    return { client, provider, feeRevenue, providerExpense, subsidyExpense };
  }
}

type FeeAccountSet = {
  client: LedgerAccountRecord;
  provider: LedgerAccountRecord;
  feeRevenue: LedgerAccountRecord;
  providerExpense: LedgerAccountRecord;
  subsidyExpense: LedgerAccountRecord;
};

function assertConsistentSubsidy(posting: FeeAssessmentPosting): void {
  const expectedSubsidy = Math.max(0, posting.providerCostCents - posting.clientFeeCents);
  if (posting.subsidyCents !== expectedSubsidy) {
    throw new AppError(
      'ledger_subsidy_inconsistent',
      `subsidyCents (${posting.subsidyCents}) does not equal max(0, providerCostCents - clientFeeCents) = ${expectedSubsidy}`,
      500,
      {
        clientFeeCents: posting.clientFeeCents,
        providerCostCents: posting.providerCostCents,
        subsidyCents: posting.subsidyCents
      }
    );
  }
}

/**
 * When `feeAssessmentId` is `null` (cash-in paid with no pricing rules
 * configured), the platform is intentionally skipping the fee/cost/subsidy
 * pairs and only crediting the principal. Asserting that fee and cost are
 * both 0 keeps that contract honest — a caller that wants to post fees
 * MUST first persist a `fee_assessment` row.
 */
function assertConsistentNullAssessment(posting: FeeAssessmentPosting): void {
  if (posting.feeAssessmentId !== null) return;
  if (posting.clientFeeCents !== 0 || posting.providerCostCents !== 0 || posting.subsidyCents !== 0) {
    throw new AppError(
      'ledger_null_assessment_with_fees',
      'feeAssessmentId is null but clientFeeCents/providerCostCents/subsidyCents are non-zero (caller must persist a fee_assessment row first)',
      500,
      {
        clientFeeCents: posting.clientFeeCents,
        providerCostCents: posting.providerCostCents,
        subsidyCents: posting.subsidyCents
      }
    );
  }
}

function buildFeeAssessmentDrafts(
  posting: FeeAssessmentPosting,
  accounts: FeeAccountSet
): LedgerEntryDraft[] {
  const drafts: LedgerEntryDraft[] = [];

  const baseMetadata = {
    triggerEvent: posting.triggerEvent,
    operationType: posting.operationType,
    ...(posting.feeAssessmentId !== null ? { feeAssessmentId: posting.feeAssessmentId } : {}),
    ...(posting.metadata ?? {})
  };

  const principalDebit = posting.operationType === 'cash_in'
    ? accounts.provider
    : accounts.client;
  const principalCredit = posting.operationType === 'cash_in'
    ? accounts.client
    : accounts.provider;

  if (posting.principalAmountCents > 0) {
    drafts.push({
      transactionId: posting.transactionId,
      accountId: principalDebit.id,
      clientId: principalDebit.clientId,
      direction: 'debit',
      amountCents: posting.principalAmountCents,
      reason: `${posting.operationType}.principal.debit`,
      providerName: posting.providerName,
      providerReferenceId: posting.providerReferenceId,
      metadata: baseMetadata
    });
    drafts.push({
      transactionId: posting.transactionId,
      accountId: principalCredit.id,
      clientId: principalCredit.clientId,
      direction: 'credit',
      amountCents: posting.principalAmountCents,
      reason: `${posting.operationType}.principal.credit`,
      providerName: posting.providerName,
      providerReferenceId: posting.providerReferenceId,
      metadata: baseMetadata
    });
  }

  if (posting.clientFeeCents > 0) {
    drafts.push({
      transactionId: posting.transactionId,
      accountId: accounts.client.id,
      clientId: accounts.client.clientId,
      direction: 'debit',
      amountCents: posting.clientFeeCents,
      reason: `${posting.operationType}.client_fee.debit`,
      providerName: posting.providerName,
      providerReferenceId: posting.providerReferenceId,
      metadata: baseMetadata
    });
    drafts.push({
      transactionId: posting.transactionId,
      accountId: accounts.feeRevenue.id,
      clientId: null,
      direction: 'credit',
      amountCents: posting.clientFeeCents,
      reason: `${posting.operationType}.client_fee.credit`,
      providerName: posting.providerName,
      providerReferenceId: posting.providerReferenceId,
      metadata: baseMetadata
    });
  }

  if (posting.providerCostCents > 0) {
    drafts.push({
      transactionId: posting.transactionId,
      accountId: accounts.providerExpense.id,
      clientId: null,
      direction: 'debit',
      amountCents: posting.providerCostCents,
      reason: `${posting.operationType}.provider_cost.debit`,
      providerName: posting.providerName,
      providerReferenceId: posting.providerReferenceId,
      metadata: baseMetadata
    });
    drafts.push({
      transactionId: posting.transactionId,
      accountId: accounts.provider.id,
      clientId: null,
      direction: 'credit',
      amountCents: posting.providerCostCents,
      reason: `${posting.operationType}.provider_cost.credit`,
      providerName: posting.providerName,
      providerReferenceId: posting.providerReferenceId,
      metadata: baseMetadata
    });
  }

  if (posting.subsidyCents > 0) {
    // Subsidy absorption pair: debit subsidy_expense, credit
    // cashyin_fee_revenue. This grosses up revenue and books the absorbed
    // loss separately so reporting can show
    // `net_revenue = revenue - subsidy_expense` per period.
    drafts.push({
      transactionId: posting.transactionId,
      accountId: accounts.subsidyExpense.id,
      clientId: null,
      direction: 'debit',
      amountCents: posting.subsidyCents,
      reason: `${posting.operationType}.subsidy.debit`,
      providerName: posting.providerName,
      providerReferenceId: posting.providerReferenceId,
      metadata: baseMetadata
    });
    drafts.push({
      transactionId: posting.transactionId,
      accountId: accounts.feeRevenue.id,
      clientId: null,
      direction: 'credit',
      amountCents: posting.subsidyCents,
      reason: `${posting.operationType}.subsidy.credit`,
      providerName: posting.providerName,
      providerReferenceId: posting.providerReferenceId,
      metadata: baseMetadata
    });
  }

  return drafts;
}
