import type { Sql } from '../../shared/db/sql.js';

/**
 * Global guard for ledger batch postings.
 *
 * `ledger_entries` is partitioned by RANGE (created_at), and PostgreSQL
 * requires every UNIQUE index on a partitioned table to include the
 * partition key. A unique on `(idempotency_key, created_at)` would
 * therefore NOT prevent the same logical batch from being re-posted in a
 * different month (e.g. webhook re-delivery after a partition rotation).
 *
 * The `ledger_idempotency_keys` table (migration 0007) is a small
 * unpartitioned guard: one row per logical batch. {@link tryAcquire}
 * tries to claim the key inside the caller's transaction; the success
 * boolean tells the LedgerService whether to proceed with the insert
 * (`true`) or treat the batch as already posted (`false`).
 */
export interface LedgerIdempotencyKeyRepository {
  /**
   * Attempts to register the supplied key. Returns `true` if this caller
   * is the first to register it (caller should proceed with the ledger
   * insert), `false` if a previous transaction already registered it
   * (caller should treat the batch as a duplicate and skip).
   *
   * MUST run inside the same transaction as the ledger insert so that
   * a rollback releases the key for a future retry.
   */
  tryAcquire(sql: Sql, key: string): Promise<boolean>;
}

export class PgLedgerIdempotencyKeyRepository implements LedgerIdempotencyKeyRepository {
  async tryAcquire(sql: Sql, key: string): Promise<boolean> {
    const result = await sql.query<{ key: string }>(
      `INSERT INTO ledger_idempotency_keys (key)
       VALUES ($1)
       ON CONFLICT (key) DO NOTHING
       RETURNING key`,
      [key]
    );
    return result.rowCount === 1;
  }
}
