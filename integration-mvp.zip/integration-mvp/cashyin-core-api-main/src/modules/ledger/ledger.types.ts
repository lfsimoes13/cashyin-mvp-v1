import type { ProviderName } from '../../providers/contracts/provider-types.js';
import type { LedgerEntryDirection } from './ledger.repository.js';

export type { LedgerEntryDirection } from './ledger.repository.js';

export type LedgerEntryDraft = {
  transactionId: string;
  accountId: string;
  clientId: string | null;
  direction: LedgerEntryDirection;
  amountCents: number;
  reason: string;
  providerName?: ProviderName | null;
  providerReferenceId?: string | null;
  metadata?: Record<string, unknown>;
};
