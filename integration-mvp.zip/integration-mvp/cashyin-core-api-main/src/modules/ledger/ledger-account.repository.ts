import type { Sql } from '../../shared/db/sql.js';

/**
 * Identifies a ledger account by its owning scope and a textual
 * account_type discriminator. The three kinds map to the three columns
 * the underlying `ledger_accounts` row uses to disambiguate scope:
 *
 *  - `client`: client_liability accounts, scoped to one client_id.
 *  - `provider`: provider_clearing accounts, scoped to one provider_account_id.
 *  - `system`: platform-wide accounts (cashyin_fee_revenue,
 *    provider_fee_expense, subsidy_expense) with NULL client_id and NULL
 *    provider_account_id. The unique constraint
 *    `UNIQUE(client_id, provider_account_id, account_type, currency)`
 *    treats `(NULL, NULL, ...)` as a distinct key per account_type, so
 *    each system account has a single canonical row.
 *
 * Phase 5 introduces the `system` kind in support of fee-revenue,
 * provider-cost-expense and subsidy-expense postings; the migration
 * `0005_phase5_ledger_system_accounts.sql` pre-seeds the three canonical
 * system rows so callers can resolve them by `(kind: 'system', accountType: 'system:...')`.
 */
export type LedgerAccountScope =
  | { kind: 'client'; clientId: string; accountType: string }
  | { kind: 'provider'; providerAccountId: string; accountType: string }
  | { kind: 'system'; accountType: string };

export type LedgerAccountRecord = {
  id: string;
  clientId: string | null;
  providerAccountId: string | null;
  accountType: string;
  currency: 'BRL';
};

type LedgerAccountRow = {
  id: string;
  client_id: string | null;
  provider_account_id: string | null;
  account_type: string;
  currency: 'BRL';
};

function mapRow(row: LedgerAccountRow): LedgerAccountRecord {
  return {
    id: row.id,
    clientId: row.client_id,
    providerAccountId: row.provider_account_id,
    accountType: row.account_type,
    currency: row.currency
  };
}

export interface LedgerAccountRepository {
  /**
   * Returns the ledger account for the given scope, creating it on first use.
   * The unique key on `ledger_accounts` enforces a single row per scope.
   */
  ensure(sql: Sql, scope: LedgerAccountScope): Promise<LedgerAccountRecord>;
}

export class PgLedgerAccountRepository implements LedgerAccountRepository {
  async ensure(sql: Sql, scope: LedgerAccountScope): Promise<LedgerAccountRecord> {
    const clientId = scope.kind === 'client' ? scope.clientId : null;
    const providerAccountId =
      scope.kind === 'provider' ? scope.providerAccountId : null;

    const existing = await sql.query<LedgerAccountRow>(
      `SELECT id, client_id, provider_account_id, account_type, currency
         FROM ledger_accounts
        WHERE client_id IS NOT DISTINCT FROM $1
          AND provider_account_id IS NOT DISTINCT FROM $2
          AND account_type = $3
          AND currency = 'BRL'`,
      [clientId, providerAccountId, scope.accountType]
    );
    const found = existing.rows[0];
    if (found) return mapRow(found);

    const inserted = await sql.query<LedgerAccountRow>(
      `INSERT INTO ledger_accounts (client_id, provider_account_id, account_type, currency)
       VALUES ($1, $2, $3, 'BRL')
       ON CONFLICT (client_id, provider_account_id, account_type, currency) DO UPDATE
         SET account_type = EXCLUDED.account_type
       RETURNING id, client_id, provider_account_id, account_type, currency`,
      [clientId, providerAccountId, scope.accountType]
    );
    const row = inserted.rows[0];
    if (!row) {
      throw new Error('Failed to ensure ledger account');
    }
    return mapRow(row);
  }
}
