import type { Sql } from '../../shared/db/sql.js';
import type { ProviderName } from '../../providers/contracts/provider-types.js';

export type LedgerEntryDirection = 'debit' | 'credit';

export type LedgerEntryInsertInput = {
  transactionId: string;
  accountId: string;
  clientId: string | null;
  providerName: ProviderName | null;
  providerReferenceId: string | null;
  direction: LedgerEntryDirection;
  amountCents: number;
  reason: string;
  metadata: Record<string, unknown>;
};

export type LedgerEntryRecord = {
  id: string;
  transactionId: string;
  accountId: string;
  clientId: string | null;
  providerName: ProviderName | null;
  providerReferenceId: string | null;
  direction: LedgerEntryDirection;
  amountCents: number;
  currency: 'BRL';
  reason: string;
  createdAt: Date;
};

type LedgerEntryRow = {
  id: string;
  transaction_id: string;
  account_id: string;
  client_id: string | null;
  provider_name: ProviderName | null;
  provider_reference_id: string | null;
  direction: LedgerEntryDirection;
  amount_cents: string;
  currency: 'BRL';
  reason: string;
  created_at: Date;
};

function mapRow(row: LedgerEntryRow): LedgerEntryRecord {
  return {
    id: row.id,
    transactionId: row.transaction_id,
    accountId: row.account_id,
    clientId: row.client_id,
    providerName: row.provider_name,
    providerReferenceId: row.provider_reference_id,
    direction: row.direction,
    amountCents: Number(row.amount_cents),
    currency: row.currency,
    reason: row.reason,
    createdAt: row.created_at
  };
}

export interface LedgerEntryRepository {
  /**
   * Appends a batch of ledger entries. Callers are responsible for asserting
   * the double-entry invariant before invoking this method; the repository
   * never updates or deletes posted entries.
   */
  appendBatch(sql: Sql, entries: LedgerEntryInsertInput[]): Promise<LedgerEntryRecord[]>;
}

export class PgLedgerEntryRepository implements LedgerEntryRepository {
  async appendBatch(sql: Sql, entries: LedgerEntryInsertInput[]): Promise<LedgerEntryRecord[]> {
    if (entries.length === 0) return [];

    const values: string[] = [];
    const params: unknown[] = [];
    let i = 1;
    for (const entry of entries) {
      values.push(
        `($${i++}, $${i++}, $${i++}, $${i++}, $${i++}, $${i++}, $${i++}::bigint, $${i++}, $${i++}::jsonb)`
      );
      params.push(
        entry.transactionId,
        entry.accountId,
        entry.clientId,
        entry.providerName,
        entry.providerReferenceId,
        entry.direction,
        entry.amountCents,
        entry.reason,
        JSON.stringify(entry.metadata)
      );
    }

    const result = await sql.query<LedgerEntryRow>(
      `INSERT INTO ledger_entries
         (transaction_id, account_id, client_id, provider_name, provider_reference_id,
          direction, amount_cents, reason, metadata)
       VALUES ${values.join(', ')}
       RETURNING id, transaction_id, account_id, client_id, provider_name,
                 provider_reference_id, direction, amount_cents, currency, reason, created_at`,
      params
    );

    return result.rows.map(mapRow);
  }
}
