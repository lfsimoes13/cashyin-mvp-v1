import type { Sql } from '../../shared/db/sql.js';
import type { IdempotencyOperationType, IdempotencyRecord } from './idempotency.types.js';

type IdempotencyRow = {
  id: string;
  client_id: string;
  key: string;
  operation_type: IdempotencyOperationType;
  request_hash: string;
  response_body: unknown;
  locked_until: Date | null;
  completed_at: Date | null;
};

export type IdempotencyInsertInput = {
  clientId: string;
  key: string;
  operationType: IdempotencyOperationType;
  requestHash: string;
  lockTtlMs: number;
};

export interface IdempotencyRepository {
  /**
   * Inserts a new pending idempotency row. Returns the inserted record if the
   * insert succeeded, or `null` if a row already exists for the same scope.
   */
  insertIfAbsent(sql: Sql, input: IdempotencyInsertInput): Promise<IdempotencyRecord | null>;

  /**
   * Loads the existing record for the (client, key, operation) scope and locks
   * its row for the current transaction.
   */
  loadForUpdate(
    sql: Sql,
    clientId: string,
    key: string,
    operationType: IdempotencyOperationType
  ): Promise<IdempotencyRecord | null>;

  /**
   * Refreshes the lock window on a stale record so a retry can take ownership.
   */
  refreshLock(sql: Sql, recordId: string, lockTtlMs: number): Promise<void>;

  /**
   * Persists the final response body and clears the lock for replay-safe reads.
   */
  finalize(sql: Sql, recordId: string, response: unknown): Promise<void>;

  /**
   * Removes an in-flight record so a retry can be re-acquired. Only deletes
   * rows that have not been finalised.
   */
  release(sql: Sql, recordId: string): Promise<void>;
}

function mapRow(row: IdempotencyRow): IdempotencyRecord {
  return {
    id: row.id,
    clientId: row.client_id,
    key: row.key,
    operationType: row.operation_type,
    requestHash: row.request_hash,
    responseBody: row.response_body,
    lockedUntil: row.locked_until,
    completedAt: row.completed_at
  };
}

export class PgIdempotencyRepository implements IdempotencyRepository {
  async insertIfAbsent(sql: Sql, input: IdempotencyInsertInput): Promise<IdempotencyRecord | null> {
    const result = await sql.query<IdempotencyRow>(
      `INSERT INTO idempotency_keys
         (client_id, key, operation_type, request_hash, locked_until)
       VALUES ($1, $2, $3, $4, now() + ($5::bigint || ' milliseconds')::interval)
       ON CONFLICT (client_id, key, operation_type) DO NOTHING
       RETURNING id, client_id, key, operation_type, request_hash, response_body, locked_until, completed_at`,
      [input.clientId, input.key, input.operationType, input.requestHash, input.lockTtlMs]
    );
    const row = result.rows[0];
    return row ? mapRow(row) : null;
  }

  async loadForUpdate(
    sql: Sql,
    clientId: string,
    key: string,
    operationType: IdempotencyOperationType
  ): Promise<IdempotencyRecord | null> {
    const result = await sql.query<IdempotencyRow>(
      `SELECT id, client_id, key, operation_type, request_hash, response_body, locked_until, completed_at
         FROM idempotency_keys
        WHERE client_id = $1 AND key = $2 AND operation_type = $3
        FOR UPDATE`,
      [clientId, key, operationType]
    );
    const row = result.rows[0];
    return row ? mapRow(row) : null;
  }

  async refreshLock(sql: Sql, recordId: string, lockTtlMs: number): Promise<void> {
    await sql.query(
      `UPDATE idempotency_keys
          SET locked_until = now() + ($2::bigint || ' milliseconds')::interval
        WHERE id = $1 AND completed_at IS NULL`,
      [recordId, lockTtlMs]
    );
  }

  async finalize(sql: Sql, recordId: string, response: unknown): Promise<void> {
    await sql.query(
      `UPDATE idempotency_keys
          SET response_body = $2::jsonb,
              completed_at = now(),
              locked_until = NULL
        WHERE id = $1`,
      [recordId, JSON.stringify(response)]
    );
  }

  async release(sql: Sql, recordId: string): Promise<void> {
    await sql.query(
      `DELETE FROM idempotency_keys
        WHERE id = $1 AND completed_at IS NULL`,
      [recordId]
    );
  }
}
