import { createHash } from 'node:crypto';

/**
 * Produces a stable JSON representation that is invariant to property ordering.
 *
 * Idempotency hashes must be deterministic: clients legitimately retrying the
 * same request with the same key but a JSON serialiser that reorders keys must
 * not be rejected as a hash conflict.
 */
export function stableStringify(value: unknown): string {
  if (value === null) return 'null';
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) {
      throw new TypeError('Cannot stably stringify non-finite numbers');
    }
    return JSON.stringify(value);
  }
  if (typeof value === 'string' || typeof value === 'boolean') {
    return JSON.stringify(value);
  }
  if (typeof value === 'bigint') {
    return JSON.stringify(value.toString());
  }
  if (Array.isArray(value)) {
    return `[${value.map((item) => stableStringify(item)).join(',')}]`;
  }
  if (typeof value === 'object') {
    const entries = Object.entries(value as Record<string, unknown>)
      .filter(([, v]) => v !== undefined)
      .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0));
    const parts = entries.map(([k, v]) => `${JSON.stringify(k)}:${stableStringify(v)}`);
    return `{${parts.join(',')}}`;
  }
  throw new TypeError(`Unsupported value type for idempotency hash: ${typeof value}`);
}

export function hashRequest(value: unknown): string {
  return createHash('sha256').update(stableStringify(value)).digest('hex');
}
