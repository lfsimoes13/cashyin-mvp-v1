import type { Sql } from '../../shared/db/sql.js';
import type { Database } from '../../shared/db/database.js';
import { AppError } from '../../shared/errors/app-error.js';
import type { IdempotencyRepository } from './idempotency.repository.js';
import type {
  IdempotencyAcquireInput,
  IdempotencyAcquireResult,
  IdempotencyOperationType
} from './idempotency.types.js';

const DEFAULT_LOCK_TTL_MS = 30_000;

export type IdempotencyServiceOptions = {
  lockTtlMs?: number;
};

/**
 * Enforces the idempotency invariants described in {@link docs/architecture.md}.
 *
 * - Same `(clientId, key, operationType)` with matching request hash returns
 *   the previously-persisted response once the original request completed.
 * - Same scope with a mismatched request hash is rejected with a 409 conflict
 *   so the API never produces ambiguous financial operations.
 * - A duplicate request while the original is still in flight is rejected with
 *   a 409 to avoid double-spend windows; the lock is released on success,
 *   on failure, or when its TTL expires (so retries after a crash are safe).
 */
export class IdempotencyService {
  private readonly lockTtlMs: number;

  constructor(
    private readonly db: Database,
    private readonly repository: IdempotencyRepository,
    options: IdempotencyServiceOptions = {}
  ) {
    this.lockTtlMs = options.lockTtlMs ?? DEFAULT_LOCK_TTL_MS;
  }

  async acquire(input: IdempotencyAcquireInput): Promise<IdempotencyAcquireResult> {
    return this.db.withTransaction(async (tx) => this.acquireWithExecutor(tx, input));
  }

  async finalize(recordId: string, response: unknown): Promise<void> {
    await this.repository.finalize(this.db.pool, recordId, response);
  }

  async finalizeWith(sql: Sql, recordId: string, response: unknown): Promise<void> {
    await this.repository.finalize(sql, recordId, response);
  }

  async release(recordId: string): Promise<void> {
    await this.repository.release(this.db.pool, recordId);
  }

  private async acquireWithExecutor(
    sql: Sql,
    input: IdempotencyAcquireInput
  ): Promise<IdempotencyAcquireResult> {
    const inserted = await this.repository.insertIfAbsent(sql, {
      clientId: input.clientId,
      key: input.key,
      operationType: input.operationType,
      requestHash: input.requestHash,
      lockTtlMs: input.lockTtlMs
    });

    if (inserted) {
      return { kind: 'fresh', recordId: inserted.id, wasStale: false };
    }

    const existing = await this.repository.loadForUpdate(
      sql,
      input.clientId,
      input.key,
      input.operationType
    );

    if (!existing) {
      throw new AppError(
        'idempotency_lookup_failed',
        'Idempotency key disappeared between insert and lookup',
        500
      );
    }

    if (existing.requestHash !== input.requestHash) {
      throw idempotencyConflict(input.key, input.operationType);
    }

    if (existing.completedAt !== null) {
      return { kind: 'replay', response: existing.responseBody };
    }

    const now = Date.now();
    const lockedUntilMs = existing.lockedUntil?.getTime() ?? 0;
    if (lockedUntilMs > now) {
      throw new AppError(
        'idempotency_in_progress',
        'A request with this Idempotency-Key is currently being processed',
        409,
        { key: input.key, operationType: input.operationType }
      );
    }

    await this.repository.refreshLock(sql, existing.id, input.lockTtlMs);
    return { kind: 'fresh', recordId: existing.id, wasStale: true };
  }

  get defaultLockTtlMs(): number {
    return this.lockTtlMs;
  }
}

function idempotencyConflict(key: string, operationType: IdempotencyOperationType): AppError {
  return new AppError(
    'idempotency_key_conflict',
    'Idempotency-Key reused with a different request payload',
    409,
    { key, operationType }
  );
}
