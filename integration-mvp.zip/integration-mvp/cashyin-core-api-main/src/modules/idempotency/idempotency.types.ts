import type { OperationType } from '../../providers/contracts/provider-types.js';

export type IdempotencyOperationType = OperationType;

export type IdempotencyRecord = {
  id: string;
  clientId: string;
  key: string;
  operationType: IdempotencyOperationType;
  requestHash: string;
  responseBody: unknown;
  lockedUntil: Date | null;
  completedAt: Date | null;
};

export type IdempotencyAcquireInput = {
  clientId: string;
  key: string;
  operationType: IdempotencyOperationType;
  requestHash: string;
  lockTtlMs: number;
};

export type IdempotencyAcquireResult =
  | {
      kind: 'fresh';
      recordId: string;
      /**
       * True when the existing lock had expired (`locked_until <= now()`) and
       * this caller is taking it over. Callers MUST probe their own durable
       * state before invoking any provider, because the previous owner may
       * have already succeeded at the provider without committing locally.
       */
      wasStale: boolean;
    }
  | { kind: 'replay'; response: unknown };
