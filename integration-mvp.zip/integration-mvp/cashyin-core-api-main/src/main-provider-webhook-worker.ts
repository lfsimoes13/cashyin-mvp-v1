/**
 * Entrypoint: provider webhook processor worker.
 *
 * Run as a separate process from the HTTP API. In ECS this maps to a
 * dedicated task definition whose container `command` is
 * `["node", "dist/main-provider-webhook-worker.js"]`. Locally use
 * `pnpm dev:provider-webhook-worker`.
 */

import { env } from './shared/config/env.js';
import { runWorkerEntrypoint, type WorkerEntrypointInput } from './workers/runtime/bootstrap.js';
import { createProviderWebhookProcessorWorker } from './workers/provider-webhook-processor/index.js';
import { PgNotifyWatcher } from './workers/runtime/pg-notify-watcher.js';

const buildWatcher: WorkerEntrypointInput['buildWatcher'] = env.WORKER_ENABLE_DB_NOTIFY
  ? ({ connectionString, logger }, loop) =>
      new PgNotifyWatcher({
        connectionString,
        channels: ['cashyin_webhook_events_ready'],
        onNotify: () => loop.nudge(),
        logger: logger.child({ component: 'pg-notify-watcher' }),
        reconnectDelayMs: env.WORKER_NOTIFY_RECONNECT_BASE_MS
      })
  : undefined;

const exitCode = await runWorkerEntrypoint({
  name: 'provider-webhook-processor',
  buildWorker: ({ container, logger, intervals }) =>
    createProviderWebhookProcessorWorker({
      processor: container.webhookEventProcessor,
      logger,
      intervals
    }),
  ...(buildWatcher ? { buildWatcher } : {})
});

process.exit(exitCode);
