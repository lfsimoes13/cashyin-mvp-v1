/**
 * Generic worker loop primitive.
 *
 * The CashYin Core API has a fleet of background pollers (provider
 * webhook processor, public webhook dispatcher, future reconciliation
 * sweeper) that all follow the same shape:
 *
 *   1. Poll a queue / outbox for the next due item.
 *   2. Process it (or report `idle` when nothing is due).
 *   3. Sleep for a duration that adapts to recent outcomes.
 *
 * `WorkerLoop` owns the polling cadence, structured logging, graceful
 * shutdown, and error backoff so each worker implementation can stay
 * focused on `tick()`. The loop is dependency-injected (`sleep`, `now`,
 * `logger`, OS signal hooks) so it is fully unit-testable without
 * timers or process state.
 *
 * Lifecycle invariants
 * --------------------
 *   - `run()` resolves only after `stop()` is called (or the process
 *     is signalled). It never throws; tick errors are logged + backed
 *     off but the loop keeps running until shutdown.
 *   - `stop()` is idempotent and async-safe: calls during an in-flight
 *     tick wait for the tick to complete before resolving the loop.
 *   - Signals (`SIGINT`, `SIGTERM`) registered via
 *     `registerShutdownSignals()` call `stop()` once each and detach
 *     themselves so a second Ctrl-C does not double-fire.
 *   - The loop is single-threaded by design: there is at most one
 *     in-flight tick at any moment, which is what
 *     {@link WebhookEventProcessor.processNext} and
 *     {@link ClientWebhookDispatcher.dispatchNext} expect (each call
 *     claims its own row with `FOR UPDATE SKIP LOCKED`, so horizontal
 *     scaling is achieved by running multiple processes, not by
 *     parallelising ticks inside one process).
 */

import type { Logger } from 'pino';

/**
 * Reason why the loop started its last tick. Exposed on `WorkerTickOutcome`
 * so structured logs can distinguish NOTIFY-driven ticks from polling-
 * fallback ticks without post-processing the log stream.
 *
 *   - `'startup'`          — very first tick after `run()` was called
 *   - `'notify'`           — woken by `nudge()` (PgNotifyWatcher received a NOTIFY)
 *   - `'polling_fallback'` — woke up because the idle/error backoff timer fired
 *   - `'busy_loop'`        — previous tick processed work; short busy-interval sleep elapsed
 */
export type WakeReason = 'startup' | 'notify' | 'polling_fallback' | 'busy_loop';

export type WorkerTickOutcome = {
  /**
   * `true` when the tick found nothing to do (queue empty). The loop
   * sleeps longer between idle ticks via {@link WorkerLoopIntervals.idleStartMs}
   * up to {@link WorkerLoopIntervals.idleMaxMs}.
   */
  idle: boolean;
  /**
   * Optional discriminator persisted as a log field (e.g. `'processed'`,
   * `'noop'`, `'retry'`, `'dlq'`, `'skipped'`). The loop never branches
   * on this value; it is purely observability.
   */
  outcome?: string;
  /**
   * Free-form payload attached to the structured log of this tick.
   * Useful for `eventId`, `outboxEventId`, attempt numbers, etc.
   */
  details?: Record<string, unknown>;
};

export type WorkerLoopIntervals = {
  /** Sleep when the previous tick processed work (i.e. NOT idle). */
  busyMs: number;
  /** Initial sleep after the first idle tick. */
  idleStartMs: number;
  /** Cap on the exponential backoff applied to consecutive idle ticks. */
  idleMaxMs: number;
  /** Initial sleep after a tick threw. */
  errorBaseMs: number;
  /** Cap on the exponential backoff applied to consecutive errored ticks. */
  errorMaxMs: number;
  /**
   * Maximum time `stop()` waits for the in-flight tick to complete.
   * After this deadline the loop resolves even if the tick is still
   * running; the orphaned promise is logged but not awaited so the
   * process can exit cleanly.
   */
  shutdownTimeoutMs: number;
};

export type WorkerLoopDeps = {
  name: string;
  logger: Logger;
  tick: () => Promise<WorkerTickOutcome>;
  intervals: WorkerLoopIntervals;
  /**
   * Promise-returning sleep. Defaults to `setTimeout` but injected so
   * unit tests can replace it with a deterministic queue.
   */
  sleep?: (ms: number) => Promise<void>;
  /** Defaults to `Date.now()`. */
  now?: () => number;
};

type LoopState =
  | { kind: 'idle'; consecutiveIdleTicks: number }
  | { kind: 'busy' }
  | { kind: 'error'; consecutiveErrors: number };

export type WorkerLoopStats = {
  ticks: number;
  processed: number;
  idle: number;
  errors: number;
  startedAt: number;
  stoppedAt: number | null;
};

/**
 * Default sleep used by the loop when callers do not inject a sleep
 * function. Exported so the keep-alive contract (see below) can be
 * asserted in unit tests; not intended as a public API.
 *
 * IMPORTANT: do NOT `unref()` this timer. In a long-running worker
 * process the timer is frequently the ONLY active handle on the
 * event loop (the pg client is idle between ticks). If the timer is
 * unref'd Node 22 considers the loop drained while the top-level
 * `await runWorkerEntrypoint(...)` is still pending, emits a
 * "Detected unsettled top-level await" warning and exits with code
 * 13. ECS then restarts the task and the worker bootstraps again,
 * producing a ~30s crash-loop instead of steady-state polling.
 * Shutdown still wakes a pending sleep immediately via the
 * `interruptibleSleep()` resolver path on `stop()`.
 */
export const defaultSleep = (ms: number): Promise<void> =>
  new Promise((resolve) => {
    setTimeout(resolve, ms);
  });

export class WorkerLoop {
  private readonly name: string;
  private readonly logger: Logger;
  private readonly tick: () => Promise<WorkerTickOutcome>;
  private readonly intervals: WorkerLoopIntervals;
  private readonly sleep: (ms: number) => Promise<void>;
  private readonly now: () => number;

  private stopping = false;
  private inFlight: Promise<unknown> | null = null;
  /**
   * Resolver that wakes a pending sleep so `stop()` can interrupt the
   * idle wait without waiting for the full sleep duration. Reset every
   * iteration before `await sleep()`.
   */
  private wakeFromSleep: (() => void) | null = null;
  /**
   * Set to `true` by `nudge()`. The loop reads this flag after waking from
   * sleep to determine whether the wake was triggered by an external
   * NOTIFY (PgNotifyWatcher) or by the backoff timer expiring.
   */
  private pendingNudge = false;
  private readonly stats: WorkerLoopStats;
  private readonly registeredSignals = new Map<NodeJS.Signals, NodeJS.SignalsListener>();

  constructor(deps: WorkerLoopDeps) {
    this.name = deps.name;
    this.logger = deps.logger.child({ worker: deps.name });
    this.tick = deps.tick;
    this.intervals = deps.intervals;
    this.sleep = deps.sleep ?? defaultSleep;
    this.now = deps.now ?? ((): number => Date.now());
    this.stats = {
      ticks: 0,
      processed: 0,
      idle: 0,
      errors: 0,
      startedAt: this.now(),
      stoppedAt: null
    };
  }

  /**
   * Runs until {@link stop} is called. Resolves cleanly; never throws.
   */
  async run(): Promise<WorkerLoopStats> {
    this.logger.info({ intervals: this.intervals }, 'worker started');
    let state: LoopState = { kind: 'idle', consecutiveIdleTicks: 0 };
    let wakeReason: WakeReason = 'startup';

    while (!this.stopping) {
      const tickStartedAt = this.now();
      this.stats.ticks += 1;

      let nextState: LoopState;
      try {
        const promise = this.tick();
        this.inFlight = promise;
        const outcome = await promise;
        this.inFlight = null;

        if (outcome.idle) {
          this.stats.idle += 1;
          const previousIdle: number = state.kind === 'idle' ? state.consecutiveIdleTicks : 0;
          nextState = { kind: 'idle', consecutiveIdleTicks: previousIdle + 1 };
          this.logger.debug(
            {
              durationMs: this.now() - tickStartedAt,
              wakeReason,
              outcome: outcome.outcome ?? 'idle',
              consecutiveIdleTicks: nextState.consecutiveIdleTicks,
              ...(outcome.details ?? {})
            },
            'worker tick idle'
          );
        } else {
          this.stats.processed += 1;
          nextState = { kind: 'busy' };
          this.logger.info(
            {
              durationMs: this.now() - tickStartedAt,
              wakeReason,
              outcome: outcome.outcome ?? 'processed',
              ...(outcome.details ?? {})
            },
            'worker tick processed'
          );
        }
      } catch (error) {
        this.inFlight = null;
        this.stats.errors += 1;
        const previousErrors: number = state.kind === 'error' ? state.consecutiveErrors : 0;
        nextState = { kind: 'error', consecutiveErrors: previousErrors + 1 };
        this.logger.error(
          {
            error,
            durationMs: this.now() - tickStartedAt,
            wakeReason,
            consecutiveErrors: nextState.consecutiveErrors
          },
          'worker tick failed'
        );
      }

      state = nextState;
      if (this.stopping) break;

      const sleepMs = this.computeSleepMs(state);

      // If a nudge() arrived during the tick, skip the sleep entirely so
      // the next row is claimed without delay.
      if (!this.pendingNudge) {
        await this.interruptibleSleep(sleepMs);
      }

      // Determine why the loop woke for the upcoming tick. Must be read
      // AFTER the potential sleep so a nudge() that arrived mid-sleep is
      // captured correctly.
      if (this.pendingNudge) {
        wakeReason = 'notify';
        this.pendingNudge = false;
      } else if (state.kind === 'busy') {
        wakeReason = 'busy_loop';
      } else {
        wakeReason = 'polling_fallback';
      }
    }

    this.stats.stoppedAt = this.now();
    this.logger.info({ stats: this.stats }, 'worker stopped');
    return this.stats;
  }

  /**
   * Signals the loop to exit after the current tick. Awaitable: resolves
   * once the in-flight tick is observed or the shutdown timeout fires.
   * Safe to call multiple times; only the first call has an effect.
   */
  async stop(): Promise<void> {
    if (this.stopping) {
      if (this.inFlight) {
        await this.awaitInFlight();
      }
      return;
    }
    this.stopping = true;
    this.logger.info('worker stop requested');
    this.wake();
    if (this.inFlight) {
      await this.awaitInFlight();
    }
  }

  /**
   * Registers `SIGINT`/`SIGTERM` listeners that call `stop()` exactly
   * once each. Returns a disposer for test cleanup; the listeners are
   * also detached automatically the first time they fire.
   */
  registerShutdownSignals(
    signals: readonly NodeJS.Signals[] = ['SIGINT', 'SIGTERM']
  ): () => void {
    for (const signal of signals) {
      const handler: NodeJS.SignalsListener = (received) => {
        this.logger.info({ signal: received }, 'worker received shutdown signal');
        process.off(signal, handler);
        this.registeredSignals.delete(signal);
        void this.stop();
      };
      process.on(signal, handler);
      this.registeredSignals.set(signal, handler);
    }
    return () => this.disposeSignals();
  }

  private disposeSignals(): void {
    for (const [signal, handler] of this.registeredSignals) {
      process.off(signal, handler);
    }
    this.registeredSignals.clear();
  }

  private computeSleepMs(state: LoopState): number {
    if (state.kind === 'busy') return this.intervals.busyMs;
    if (state.kind === 'idle') {
      const n = state.consecutiveIdleTicks;
      // Exponential backoff: idleStartMs * 2^(n-1), capped by idleMaxMs.
      const exp = this.intervals.idleStartMs * 2 ** Math.max(0, n - 1);
      return Math.min(exp, this.intervals.idleMaxMs);
    }
    // error
    const n = state.consecutiveErrors;
    const exp = this.intervals.errorBaseMs * 2 ** Math.max(0, n - 1);
    return Math.min(exp, this.intervals.errorMaxMs);
  }

  private interruptibleSleep(ms: number): Promise<void> {
    if (ms <= 0) return Promise.resolve();
    return new Promise<void>((resolve) => {
      let resolved = false;
      const finish = (): void => {
        if (resolved) return;
        resolved = true;
        this.wakeFromSleep = null;
        resolve();
      };
      this.wakeFromSleep = finish;
      void this.sleep(ms).then(finish);
    });
  }

  private wake(): void {
    if (this.wakeFromSleep) {
      const wake = this.wakeFromSleep;
      this.wakeFromSleep = null;
      wake();
    }
  }

  private async awaitInFlight(): Promise<void> {
    const promise = this.inFlight;
    if (!promise) return;
    const timeoutMs = this.intervals.shutdownTimeoutMs;
    let timer: ReturnType<typeof setTimeout> | undefined;
    const timeout = new Promise<'timeout'>((resolve) => {
      timer = setTimeout(() => resolve('timeout'), timeoutMs);
      timer.unref?.();
    });
    const result = await Promise.race([
      promise.then(() => 'done' as const).catch(() => 'done' as const),
      timeout
    ]);
    if (timer) clearTimeout(timer);
    if (result === 'timeout') {
      this.logger.warn(
        { shutdownTimeoutMs: timeoutMs },
        'worker shutdown timed out waiting for in-flight tick'
      );
    }
  }

  /**
   * Interrupts the current sleep so the loop ticks immediately.
   *
   * Intended for external callers (e.g. {@link PgNotifyWatcher}) that
   * learn about new queue items out-of-band and want to wake the loop
   * without waiting for the next scheduled tick. Safe to call from any
   * context — has no effect when the loop is not sleeping (tick already
   * in progress) or when the loop is stopping.
   *
   * Sets `pendingNudge` so the loop logs `wakeReason: 'notify'` for the
   * next tick, enabling ops teams to distinguish NOTIFY-driven ticks from
   * polling-fallback ticks in structured logs.
   */
  nudge(): void {
    this.pendingNudge = true;
    this.wake();
  }

  /** Test helper — read current counters without ending the loop. */
  snapshot(): WorkerLoopStats {
    return { ...this.stats };
  }

  /** Test helper — whether the loop has begun the shutdown sequence. */
  isStopping(): boolean {
    return this.stopping;
  }
}
