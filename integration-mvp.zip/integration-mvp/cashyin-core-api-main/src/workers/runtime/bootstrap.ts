/**
 * Worker bootstrap helpers.
 *
 * Shared between every `src/main-*-worker.ts` entrypoint: build a
 * dependency-injection container, materialise a pino logger that
 * shares the API's redact configuration, derive intervals from
 * environment variables, and orchestrate a graceful shutdown that
 * (a) lets the in-flight tick finish, (b) closes the database pool,
 * and (c) exits with the appropriate code.
 *
 * Keeping this out of the per-worker file makes each entrypoint a
 * thin three-line script and ensures consistent shutdown semantics
 * across the fleet (so a single misbehaving worker can not hold up
 * the process by, say, forgetting to close the DB).
 */

import { hostname } from 'node:os';
import pino, { type Logger } from 'pino';
import { env } from '../../shared/config/env.js';
import { createContainer, type AppContainer } from '../../app/container.js';
import type { WebhookEventClaimFilter } from '../../modules/webhooks/webhook-event.repository.js';
import type { WorkerLoop, WorkerLoopIntervals } from './worker-loop.js';
import type { PgNotifyWatcher } from './pg-notify-watcher.js';

const HARD_EXIT_FALLBACK_MS = 5_000;

export type WorkerEntrypointInput = {
  /** Stable kebab-case identifier; used in logs and the worker id field. */
  name: string;
  /**
   * Factory that receives the shared container and returns a configured
   * {@link WorkerLoop}. The entrypoint owns the lifecycle, so the
   * factory should NOT call `run()` itself.
   */
  buildWorker: (input: BuildWorkerInput) => WorkerLoop;
  /**
   * Optional factory for a {@link PgNotifyWatcher} that wakes the loop
   * immediately when new rows are inserted into the worker's queue table.
   * When provided, the watcher is started before `run()` and stopped
   * after `run()` resolves. The loop falls back to normal polling if the
   * watcher connection drops.
   */
  buildWatcher?: (input: BuildWorkerInput, loop: WorkerLoop) => PgNotifyWatcher;
};

export type BuildWorkerInput = {
  container: AppContainer;
  logger: Logger;
  intervals: WorkerLoopIntervals;
  /**
   * PostgreSQL connection string resolved from the environment.
   * Exposed here so worker factories can pass it to PgNotifyWatcher
   * without re-importing env themselves.
   */
  connectionString: string;
};

/**
 * Reads {@link env} once and produces the canonical intervals object
 * consumed by every worker. Exported so unit tests can derive the
 * same shape without re-implementing the math.
 */
export function intervalsFromEnv(): WorkerLoopIntervals {
  return {
    busyMs: env.WORKER_BUSY_INTERVAL_MS,
    idleStartMs: env.WORKER_IDLE_INTERVAL_MS,
    idleMaxMs: env.WORKER_MAX_IDLE_INTERVAL_MS,
    errorBaseMs: env.WORKER_ERROR_BACKOFF_MS,
    errorMaxMs: env.WORKER_MAX_ERROR_BACKOFF_MS,
    shutdownTimeoutMs: env.WORKER_SHUTDOWN_TIMEOUT_MS
  };
}

/**
 * Resolves the worker id used in logs and persisted on
 * `provider_webhook_processing_attempts.worker_id`. Defaults to
 * `${hostname}-${pid}-${workerName}` so replicas remain
 * distinguishable without explicit env config.
 */
export function resolveWorkerId(name: string): string {
  if (env.WORKER_ID) return env.WORKER_ID;
  return `${hostname()}-${process.pid}-${name}`;
}

/**
 * Assembles the provider-webhook claim partition filter from
 * `WEBHOOK_WORKER_*` env vars. Returns `undefined` when no filter is
 * configured so the worker drains the whole queue (back-compat). Only
 * the provider-webhook processor reads this; other workers ignore it.
 */
export function webhookClaimFilterFromEnv(): WebhookEventClaimFilter | undefined {
  const filter: WebhookEventClaimFilter = {
    ...(env.WEBHOOK_WORKER_OPERATION_TYPE ? { operationType: env.WEBHOOK_WORKER_OPERATION_TYPE } : {}),
    ...(env.WEBHOOK_WORKER_NORMALIZED_STATUS_KIND
      ? { normalizedStatusKind: env.WEBHOOK_WORKER_NORMALIZED_STATUS_KIND }
      : {}),
    ...(env.WEBHOOK_WORKER_NORMALIZED_STATUS
      ? { normalizedStatus: env.WEBHOOK_WORKER_NORMALIZED_STATUS }
      : {}),
    ...(env.WEBHOOK_WORKER_EXCLUDE_NORMALIZED_STATUS
      ? { excludeNormalizedStatus: env.WEBHOOK_WORKER_EXCLUDE_NORMALIZED_STATUS }
      : {}),
    ...(env.WEBHOOK_WORKER_EVENT_TYPES ? { eventTypes: env.WEBHOOK_WORKER_EVENT_TYPES } : {})
  };
  return Object.keys(filter).length > 0 ? filter : undefined;
}

/**
 * Runs a worker entrypoint end-to-end. Resolves with the appropriate
 * exit code: `0` for a clean shutdown, `1` for a startup or shutdown
 * failure. The caller is expected to forward it via `process.exit`.
 */
export async function runWorkerEntrypoint(input: WorkerEntrypointInput): Promise<number> {
  const workerId = resolveWorkerId(input.name);
  const logger = pino({
    level: env.LOG_LEVEL,
    // Mirrors create-app.ts so worker logs never leak signatures or
    // raw payloads, even though workers never see HTTP headers
    // directly (they only see persisted, already-redacted rows).
    redact: {
      paths: [
        '*.password',
        '*.secret',
        '*.apiKey',
        '*.api_key',
        '*.token',
        'signingSecret',
        'rawBody',
        'body.rawBody',
        'payload.rawBody'
      ],
      censor: '[REDACTED]',
      remove: false
    },
    base: { service: 'cashyin-core-api', worker: input.name, workerId }
  });

  logger.info({ env: env.NODE_ENV }, 'worker bootstrap');

  const webhookClaimFilter = webhookClaimFilterFromEnv();
  const webhookWorkerName = env.WEBHOOK_WORKER_NAME ?? input.name;
  if (webhookClaimFilter) {
    logger.info(
      { webhookWorkerName, webhookClaimFilter },
      'provider-webhook claim partition filter active'
    );
  }

  let container: AppContainer;
  try {
    container = createContainer({
      workerId,
      webhookWorkerName,
      ...(webhookClaimFilter ? { webhookClaimFilter } : {})
    });
  } catch (error) {
    logger.error({ error }, 'worker bootstrap failed');
    return 1;
  }

  if (!env.DATABASE_URL) {
    logger.error('DATABASE_URL is required for worker bootstrap');
    return 1;
  }
  const connectionString = env.DATABASE_URL;

  const worker = input.buildWorker({
    container,
    logger,
    intervals: intervalsFromEnv(),
    connectionString
  });

  const watcher = input.buildWatcher?.({ container, logger, intervals: intervalsFromEnv(), connectionString }, worker);

  // Signals stop the loop cleanly; the awaitable `run()` resolves
  // after the in-flight tick (or shutdownTimeoutMs).
  worker.registerShutdownSignals(['SIGINT', 'SIGTERM']);

  // A hard-exit fallback covers the edge case where graceful shutdown
  // somehow hangs (e.g. the DB pool refuses to close because a tick
  // got stuck). The timer is unref'd so it does not delay a clean
  // exit, and only arms once a stop is requested.
  process.once('SIGINT', () => armHardExit(logger));
  process.once('SIGTERM', () => armHardExit(logger));

  let exitCode = 0;
  try {
    if (watcher) await watcher.start();
    await worker.run();
  } catch (error) {
    // `worker.run()` is documented to never throw — but if a future
    // change breaks that contract we still want a structured log
    // before the process exits, not an unhandled rejection.
    logger.error({ error }, 'worker loop crashed');
    exitCode = 1;
  } finally {
    if (watcher) {
      try {
        await watcher.stop();
      } catch (error) {
        logger.warn({ error }, 'pg-notify-watcher stop failed (non-fatal)');
      }
    }
    try {
      await container.close();
      logger.info('worker container closed');
    } catch (error) {
      logger.error({ error }, 'worker container close failed');
      exitCode = exitCode || 1;
    }
  }
  return exitCode;
}

function armHardExit(logger: Logger): void {
  const timer = setTimeout(() => {
    logger.error(
      { fallbackMs: HARD_EXIT_FALLBACK_MS },
      'worker hard-exit fallback fired; container close stuck'
    );
    process.exit(1);
  }, HARD_EXIT_FALLBACK_MS);
  timer.unref?.();
}
