/**
 * PgNotifyWatcher — dedicated PostgreSQL LISTEN connection for worker wake-up.
 *
 * Problem: WorkerLoop polls the database on a fixed interval (busyMs / idleMs).
 * When a new row is inserted into `webhook_events` or `outbox_events`, the
 * worker does not know about it until the next scheduled tick. Under low
 * traffic the loop backs off up to WORKER_MAX_IDLE_INTERVAL_MS (default 5 s),
 * adding that duration to the end-to-end webhook latency.
 *
 * Solution: PostgreSQL LISTEN/NOTIFY. A trigger on each queue table calls
 * pg_notify when a row is inserted. This watcher subscribes to the channel
 * on a dedicated connection (pg LISTEN is not allowed on a pool client that
 * may be borrowed for queries) and calls WorkerLoop.nudge() on every
 * notification — interrupting the sleep and triggering an immediate tick.
 *
 * Reliability contract:
 * - The watcher is strictly additive: it can only make workers faster. If
 *   the LISTEN connection drops, the worker falls back to normal polling.
 * - Reconnect is automatic with exponential backoff (1 s → 2 s → … → 30 s).
 * - Notifications are best-effort: a row inserted while the watcher is
 *   reconnecting is not re-notified. The polling fallback handles it.
 * - The watcher does NOT process any data; it only wakes the worker.
 *
 * Usage:
 *   const watcher = new PgNotifyWatcher({ connectionString, channels, onNotify, logger });
 *   await watcher.start();   // opens connection and begins LISTEN
 *   // ... worker runs ...
 *   await watcher.stop();    // closes connection cleanly
 */

import { Client } from 'pg';
import type { Logger } from 'pino';

export type PgNotifyWatcherOptions = {
  /**
   * Full PostgreSQL connection string. A dedicated `Client` (not a pool)
   * is opened so LISTEN can remain active indefinitely.
   */
  connectionString: string;
  /**
   * One or more notification channel names to subscribe to.
   * Passed verbatim to `LISTEN "<channel>"`.
   */
  channels: readonly string[];
  /**
   * Called synchronously whenever a notification arrives on any of the
   * subscribed channels. Typically calls `workerLoop.nudge()`.
   */
  onNotify: (channel: string, payload: string) => void;
  logger: Logger;
  /** Initial reconnect delay in ms. Default: 1 000. */
  reconnectDelayMs?: number;
  /** Maximum reconnect delay in ms. Default: 30 000. */
  maxReconnectDelayMs?: number;
  /**
   * @internal Override the pg Client constructor — injected by tests so
   * they can pass a mock client without module-level mocking.
   */
  _clientFactory?: (connectionString: string) => Client;
};

export class PgNotifyWatcher {
  private readonly opts: Required<PgNotifyWatcherOptions>;
  private client: Client | null = null;
  private stopped = false;
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private currentDelay: number;

  constructor(opts: PgNotifyWatcherOptions) {
    this.opts = {
      reconnectDelayMs: 1_000,
      maxReconnectDelayMs: 30_000,
      _clientFactory: (cs) => new Client({ connectionString: cs }),
      ...opts
    };
    this.currentDelay = this.opts.reconnectDelayMs;
  }

  /**
   * Opens the dedicated LISTEN connection. Resolves once the first
   * connection attempt completes (success or failure — failure triggers
   * reconnect silently). Safe to call multiple times; subsequent calls
   * are no-ops if already started.
   */
  async start(): Promise<void> {
    if (this.client || this.stopped) return;
    await this.connect();
  }

  /**
   * Closes the LISTEN connection and cancels any pending reconnect.
   * After stop() returns, no further notifications will be delivered.
   */
  async stop(): Promise<void> {
    this.stopped = true;
    if (this.reconnectTimer !== null) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    if (this.client !== null) {
      const c = this.client;
      this.client = null;
      try {
        await c.end();
      } catch {
        // Ignore close errors — process may be exiting anyway.
      }
    }
  }

  private async connect(): Promise<void> {
    if (this.stopped) return;

    const client = this.opts._clientFactory(this.opts.connectionString);

    client.on('error', (err: Error) => {
      this.opts.logger.warn({ err: err.message }, 'pg-notify-watcher: client error, scheduling reconnect');
      this.client = null;
      this.scheduleReconnect();
    });

    client.on('end', () => {
      if (this.stopped) return;
      this.opts.logger.warn('pg-notify-watcher: client disconnected, scheduling reconnect');
      this.client = null;
      this.scheduleReconnect();
    });

    client.on('notification', (msg) => {
      this.opts.onNotify(msg.channel, msg.payload ?? '');
    });

    try {
      await client.connect();
      for (const channel of this.opts.channels) {
        await client.query(`LISTEN "${channel}"`);
      }
      this.client = client;
      this.currentDelay = this.opts.reconnectDelayMs; // reset on success
      this.opts.logger.info(
        { channels: this.opts.channels },
        'pg-notify-watcher: listening'
      );
    } catch (err) {
      this.opts.logger.warn(
        { err: err instanceof Error ? err.message : String(err) },
        'pg-notify-watcher: connect failed, scheduling reconnect'
      );
      try {
        await client.end();
      } catch {
        // best-effort cleanup
      }
      this.scheduleReconnect();
    }
  }

  private scheduleReconnect(): void {
    if (this.stopped || this.reconnectTimer !== null) return;

    const delay = this.currentDelay;
    this.currentDelay = Math.min(delay * 2, this.opts.maxReconnectDelayMs);

    this.opts.logger.info(
      { delayMs: delay },
      'pg-notify-watcher: reconnecting'
    );

    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      void this.connect();
    }, delay);

    // unref so a pending reconnect does not prevent graceful process exit
    this.reconnectTimer.unref?.();
  }
}
