/**
 * Provider webhook processor worker.
 *
 * Drains `webhook_events` rows via {@link WebhookEventProcessor.processNext}
 * and dispatches each one to the domain handler (payment / cashout).
 * Like {@link createOutboxDispatcherWorker} this file is wiring only;
 * domain decisions live in `WebhookEventProcessor` and the services it
 * delegates to.
 */

import type { Logger } from 'pino';
import type { WebhookEventProcessor } from '../../modules/webhooks/webhook-event.processor.js';
import { WorkerLoop, type WorkerLoopIntervals } from '../runtime/worker-loop.js';

export type ProviderWebhookProcessorWorkerDeps = {
  processor: WebhookEventProcessor;
  logger: Logger;
  intervals: WorkerLoopIntervals;
};

export function createProviderWebhookProcessorWorker(
  deps: ProviderWebhookProcessorWorkerDeps
): WorkerLoop {
  return new WorkerLoop({
    name: 'provider-webhook-processor',
    logger: deps.logger,
    intervals: deps.intervals,
    tick: async () => {
      const outcome = await deps.processor.processNext();
      if (outcome.kind === 'empty') {
        return { idle: true, outcome: 'empty' };
      }
      return { idle: false, outcome: outcome.kind, details: buildDetails(outcome) };
    }
  });
}

function buildDetails(
  outcome: Awaited<ReturnType<WebhookEventProcessor['processNext']>>
): Record<string, unknown> {
  switch (outcome.kind) {
    case 'empty':
      return {};
    case 'processed':
      return {
        eventId: outcome.eventId,
        claimLatencyMs: outcome.claimLatencyMs,
        detail: outcome.detail
      };
    case 'noop':
      return {
        eventId: outcome.eventId,
        claimLatencyMs: outcome.claimLatencyMs,
        reason: outcome.reason
      };
    case 'skipped':
      return {
        eventId: outcome.eventId,
        claimLatencyMs: outcome.claimLatencyMs,
        reason: outcome.reason
      };
    case 'retry':
      return {
        eventId: outcome.eventId,
        claimLatencyMs: outcome.claimLatencyMs,
        attemptNumber: outcome.attemptNumber,
        error: outcome.error,
        nextAttemptAt: outcome.nextAttemptAt.toISOString()
      };
    case 'dlq':
      return {
        eventId: outcome.eventId,
        claimLatencyMs: outcome.claimLatencyMs,
        attemptNumber: outcome.attemptNumber,
        error: outcome.error
      };
  }
}
