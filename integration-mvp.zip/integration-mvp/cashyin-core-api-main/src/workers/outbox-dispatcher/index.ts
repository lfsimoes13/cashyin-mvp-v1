/**
 * Public webhook dispatcher worker.
 *
 * Drains `outbox_events` rows via {@link ClientWebhookDispatcher.dispatchNext}
 * and POSTs the signed envelope to each client endpoint. This file is
 * the wiring layer between the dispatcher domain class and the generic
 * {@link WorkerLoop} runtime: it does NOT contain business logic and
 * never reaches into the database directly.
 *
 * Folder kept (rather than renamed to `client-webhook-dispatcher`)
 * because the queue being drained is the outbox; the layering is
 * "outbox-dispatcher → ClientWebhookDispatcher → HTTP POST". A future
 * reconciliation worker may share this folder.
 */

import type { Logger } from 'pino';
import type { ClientWebhookDispatcher } from '../../modules/webhooks/client-webhook.dispatcher.js';
import { WorkerLoop, type WorkerLoopIntervals } from '../runtime/worker-loop.js';

export type OutboxDispatcherWorkerDeps = {
  dispatcher: ClientWebhookDispatcher;
  logger: Logger;
  intervals: WorkerLoopIntervals;
};

export function createOutboxDispatcherWorker(deps: OutboxDispatcherWorkerDeps): WorkerLoop {
  return new WorkerLoop({
    name: 'webhook-dispatcher',
    logger: deps.logger,
    intervals: deps.intervals,
    tick: async () => {
      const outcome = await deps.dispatcher.dispatchNext();
      if (outcome.kind === 'empty') {
        return { idle: true, outcome: 'empty' };
      }
      // All non-empty outcomes count as "progress" for cadence purposes
      // (delivered / skipped / retry / dlq). Detailed branching lives in
      // the structured log payload so dashboards can split by reason
      // without forcing the loop to model every status.
      const details = buildDetails(outcome);
      return { idle: false, outcome: outcome.kind, details };
    }
  });
}

function buildDetails(
  outcome: Awaited<ReturnType<ClientWebhookDispatcher['dispatchNext']>>
): Record<string, unknown> {
  switch (outcome.kind) {
    case 'empty':
      return {};
    case 'delivered':
      return {
        outboxEventId: outcome.outboxEventId,
        deliveryId: outcome.deliveryId,
        eventType: outcome.eventType,
        eventId: outcome.eventId,
        httpStatus: outcome.httpStatus,
        claimLatencyMs: outcome.claimLatencyMs
      };
    case 'skipped':
      return {
        outboxEventId: outcome.outboxEventId,
        reason: outcome.reason,
        claimLatencyMs: outcome.claimLatencyMs
      };
    case 'retry':
      return {
        outboxEventId: outcome.outboxEventId,
        deliveryId: outcome.deliveryId,
        attemptNumber: outcome.attemptNumber,
        error: outcome.error,
        httpStatus: outcome.httpStatus,
        nextAttemptAt: outcome.nextAttemptAt.toISOString(),
        claimLatencyMs: outcome.claimLatencyMs
      };
    case 'dlq':
      return {
        outboxEventId: outcome.outboxEventId,
        deliveryId: outcome.deliveryId,
        attemptNumber: outcome.attemptNumber,
        error: outcome.error,
        httpStatus: outcome.httpStatus,
        claimLatencyMs: outcome.claimLatencyMs
      };
  }
}
