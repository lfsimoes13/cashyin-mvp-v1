import { createApp } from './app/create-app.js';
import { env } from './shared/config/env.js';

const GRACEFUL_SHUTDOWN_TIMEOUT_MS = 10_000;

const app = await createApp();

let shutdownPromise: Promise<void> | undefined;

const shutdown = (signal: NodeJS.Signals): Promise<void> => {
  if (shutdownPromise) {
    app.log.warn({ signal }, 'Shutdown already in progress');
    return shutdownPromise;
  }

  shutdownPromise = (async () => {
    app.log.info({ signal }, 'Shutting down CashYin Core API');

    const fallbackTimer = setTimeout(() => {
      app.log.error(
        { signal, timeoutMs: GRACEFUL_SHUTDOWN_TIMEOUT_MS },
        'Graceful shutdown timed out; forcing process exit'
      );
      process.exit(1);
    }, GRACEFUL_SHUTDOWN_TIMEOUT_MS);
    fallbackTimer.unref();

    try {
      await app.close();
      clearTimeout(fallbackTimer);
      app.log.info({ signal }, 'CashYin Core API shutdown completed');
      process.exit(0);
    } catch (error) {
      clearTimeout(fallbackTimer);
      app.log.error({ error, signal }, 'Error during shutdown');
      process.exit(1);
    }
  })();

  return shutdownPromise;
};

process.on('SIGINT', (signal) => {
  void shutdown(signal);
});
process.on('SIGTERM', (signal) => {
  void shutdown(signal);
});

try {
  await app.listen({ port: env.PORT, host: '0.0.0.0' });
  app.log.info({ port: env.PORT }, 'CashYin Core API started');
} catch (error) {
  app.log.error({ error }, 'Failed to start CashYin Core API');
  process.exit(1);
}
