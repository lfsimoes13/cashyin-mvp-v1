import cors from '@fastify/cors';
import helmet from '@fastify/helmet';
import rateLimit from '@fastify/rate-limit';
import Fastify, { type FastifyInstance } from 'fastify';
import { registerRoutes } from './routes.js';
import { type AppContainer, createContainer } from './container.js';
import { env } from '../shared/config/env.js';
import { toHttpError } from '../shared/errors/app-error.js';
import { metrics } from '../shared/observability/metrics.js';

export type CreateAppOptions = {
  container?: AppContainer;
};

export type CashYinApp = FastifyInstance & {
  cashyin: { container: AppContainer };
};

export async function createApp(options: CreateAppOptions = {}): Promise<CashYinApp> {
  const container = options.container ?? createContainer();

  const requestStartedAt = new WeakMap<object, bigint>();

  const app = Fastify({
    logger: {
      level: env.LOG_LEVEL,
      // Pino redact paths are evaluated against every log object. The list
      // covers every place a secret can plausibly travel into a log line:
      //   - Inbound auth headers and webhook signatures on the request log.
      //   - Outbound headers we mint to call Bents (the `authorization`
      //     entry catches the `Bearer dk_...` we set in BentsClient).
      //   - Raw webhook bodies, which by definition contain provider state
      //     before signature verification.
      //   - Generic key names that show up in domain payloads (passwords,
      //     api keys, secrets, tokens), captured with wildcard paths.
      redact: {
        paths: [
          'req.headers.authorization',
          'req.headers["x-bents-signature"]',
          'req.headers.cookie',
          'request.headers.authorization',
          'request.headers["x-bents-signature"]',
          'request.headers.cookie',
          'res.headers["set-cookie"]',
          'response.headers["set-cookie"]',
          'headers.authorization',
          'headers["x-bents-signature"]',
          'rawBody',
          'body.rawBody',
          'payload.rawBody',
          '*.password',
          '*.secret',
          '*.apiKey',
          '*.api_key',
          '*.token'
        ],
        censor: '[REDACTED]',
        remove: false
      }
    },
    requestIdHeader: 'x-request-id'
  });

  await app.register(helmet);
  await app.register(cors, {
    origin: (origin, cb) => {
      const allowedOrigins = env.CORS_ORIGINS ?? ['http://localhost:5173', 'http://localhost:5174'];
      
      if (!origin || allowedOrigins.includes('*')) {
        cb(null, true);
        return;
      }

      if (allowedOrigins.includes(origin)) {
        cb(null, true);
        return;
      }

      cb(new Error('Not allowed by CORS'), false);
    },
    credentials: true
  });
  // Key rate limits by the client's Bearer API key (Bearer <token>) so each
  // tenant gets its own bucket. Authenticated clients on the same egress IP
  // (common in multi-tenant SaaS gateway setups) therefore don't share
  // capacity. Falls back to the first forwarded IP, then the socket IP, for
  // unauthenticated paths (provider webhooks, /health, /ready).
  await app.register(rateLimit, {
    max: env.RATE_LIMIT_MAX,
    timeWindow: env.RATE_LIMIT_WINDOW,
    keyGenerator: (request) => {
      const auth = request.headers.authorization;
      if (typeof auth === 'string' && auth.startsWith('Bearer ')) {
        return auth.slice(7);
      }
      const forwarded = request.headers['x-forwarded-for'];
      const ip = Array.isArray(forwarded)
        ? forwarded[0]
        : forwarded?.split(',')[0]?.trim();
      return ip ?? request.socket.remoteAddress ?? 'unknown';
    }
  });

  if (env.METRICS_ENABLED) {
    app.addHook('onRequest', async (request) => {
      requestStartedAt.set(request, process.hrtime.bigint());
    });

    app.addHook('onResponse', async (request, reply) => {
      const startedAt = requestStartedAt.get(request);
      const route = request.routeOptions.url ?? request.url;
      const labels = {
        method: request.method,
        route,
        status_code: String(reply.statusCode)
      };
      metrics.increment('cashyin_http_requests_total', 'Total HTTP requests by method, route and status.', labels);
      if (startedAt) {
        metrics.observeDurationSeconds(
          'cashyin_http_request_duration_seconds',
          'HTTP request duration by method, route and status.',
          startedAt,
          labels
        );
      }
    });
  }

  app.setErrorHandler((error, request, reply) => {
    const httpError = toHttpError(error);
    request.log.error({ error, requestId: request.id }, 'request failed');
    void reply.status(httpError.statusCode).send({
      error: {
        code: httpError.code,
        message: httpError.message,
        requestId: request.id
      }
    });
  });

  app.addHook('onClose', async () => {
    if (!options.container) {
      await container.close();
    }
  });

  await registerRoutes(app, container);

  const decorated = app as unknown as CashYinApp;
  decorated.cashyin = { container };
  return decorated;
}
