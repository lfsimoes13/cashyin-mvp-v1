import { Database } from '../shared/db/database.js';
import { env } from '../shared/config/env.js';
import {
  ClientApiKeyService,
  PgClientApiKeyRepository
} from '../modules/auth/client-api-key.service.js';
import {
  UserClientGrantService,
  PgUserClientGrantRepository
} from '../modules/auth/user-client-grant.js';
import {
  ClientBalanceService,
  PgClientBalanceRepository
} from '../modules/balances/client-balance.service.js';
import { PgCashoutRepository } from '../modules/cashouts/cashout.repository.js';
import { CashoutService } from '../modules/cashouts/cashout.service.js';
import { PgIdempotencyRepository } from '../modules/idempotency/idempotency.repository.js';
import { IdempotencyService } from '../modules/idempotency/idempotency.service.js';
import { PgLedgerAccountRepository } from '../modules/ledger/ledger-account.repository.js';
import { PgLedgerIdempotencyKeyRepository } from '../modules/ledger/ledger-idempotency.repository.js';
import { PgLedgerEntryRepository } from '../modules/ledger/ledger.repository.js';
import { LedgerService } from '../modules/ledger/ledger.service.js';
import { PgLiquidityRepository } from '../modules/liquidity/liquidity.repository.js';
import { LiquidityService } from '../modules/liquidity/liquidity.service.js';
import { PgOutboxRepository } from '../modules/outbox/outbox.repository.js';
import { OutboxService } from '../modules/outbox/outbox.service.js';
import { PgCashInRepository } from '../modules/payments/cash-in.repository.js';
import { PaymentService } from '../modules/payments/payment.service.js';
import {
  PgFeeAssessmentRepository,
  PgPricingRuleRepository,
  PgProviderCostRuleRepository,
  PgSubsidyEventRepository,
  PricingService
} from '../modules/pricing/index.js';
import { PgProviderAssignmentRepository } from '../modules/providers/provider-assignment.repository.js';
import { ProviderAssignmentService } from '../modules/providers/provider-assignment.service.js';
import { ProviderRegistry } from '../modules/providers/provider-registry.js';
import {
  ClientWebhookDispatcher,
  type OutboxDispatchClaimFilter
} from '../modules/webhooks/client-webhook.dispatcher.js';
import { PgClientWebhookDeliveryRepository } from '../modules/webhooks/client-webhook-delivery.repository.js';
import { PgClientWebhookEndpointRepository } from '../modules/webhooks/client-webhook-endpoint.repository.js';
import {
  ClientWebhookEndpointAdminService,
  PgClientWebhookEndpointAdminRepository
} from '../modules/webhooks/client-webhook-endpoint.admin.js';
import { ClientConfigService } from '../modules/admin/client-config.service.js';
import {
  CashoutStepUpService,
  PgCashoutStepUpRepository
} from '../modules/cashouts/cashout-step-up.js';
import { ProviderWebhookAdapterRegistry } from '../modules/webhooks/provider-webhook-adapter-registry.js';
import {
  PgWebhookEventRepository,
  type WebhookEventClaimFilter
} from '../modules/webhooks/webhook-event.repository.js';
import { WebhookEventProcessor } from '../modules/webhooks/webhook-event.processor.js';
import { PgWebhookProcessingAttemptRepository } from '../modules/webhooks/webhook-processing-attempt.repository.js';
import { WebhookService } from '../modules/webhooks/webhook.service.js';
import {
  BentsWebhookAdapter,
  BENTS_SIGNATURE_HEADER
} from '../providers/bents/bents-webhook.adapter.js';
import { NoVerificationWebhookAuthStrategy } from '../providers/security/no-verification.strategy.js';
import { Sha256HmacWebhookAuthStrategy } from '../providers/security/sha256-hmac.strategy.js';
import type { WebhookAuthStrategy } from '../providers/contracts/webhook-auth-strategy.js';
import { UndiciHttpClient } from '../shared/http/http-client.js';

/**
 * Optional configuration applied to services that need runtime-specific
 * context (e.g. worker identity for multi-replica observability).
 */
export type ContainerOptions = {
  /**
   * Stable worker identifier propagated to `WebhookEventProcessor` so
   * `provider_webhook_processing_attempts.worker_id` is populated in
   * multi-replica ECS deployments. Falls back to `null` when not provided
   * (HTTP API containers don't need a worker id).
   */
  workerId?: string;
  /**
   * Logical role for the provider-webhook processor (e.g. `cashin-paid`).
   * Surfaced in metrics/logs. Defaults to `'default'`.
   */
  webhookWorkerName?: string;
  /**
   * Partition filter for the provider-webhook processor claim. Lets a
   * replica drain only a subset of `webhook_events` (Fase 1).
   */
  webhookClaimFilter?: WebhookEventClaimFilter;
  /**
   * Partition filter for the outbox dispatcher claim (Fase B1). Lets a
   * dedicated dispatcher process drain only a subset of `outbox_events`
   * by `event_type` (e.g. the critical `pix.cash_in.paid` path). When
   * omitted, falls back to the `DISPATCHER_WORKER_*` env vars; if those
   * are also unset the dispatcher drains the whole queue (back-compat).
   */
  dispatcherClaimFilter?: OutboxDispatchClaimFilter;
};

export type AppContainer = {
  db: Database;
  providerRegistry: ProviderRegistry;
  providerWebhookAdapterRegistry: ProviderWebhookAdapterRegistry;
  paymentService: PaymentService;
  cashoutService: CashoutService;
  webhookService: WebhookService;
  clientApiKeyService: ClientApiKeyService;
  userClientGrantService: UserClientGrantService;
  webhookEndpointAdminService: ClientWebhookEndpointAdminService;
  clientConfigService: ClientConfigService;
  cashoutStepUpService: CashoutStepUpService;
  clientBalanceService: ClientBalanceService;
  /**
   * Phase 5 async processor. Not auto-started from HTTP boot; consume
   * via a worker process, scheduled task, or unit-test driver.
   */
  webhookEventProcessor: WebhookEventProcessor;
  /**
   * Phase 6 outbound dispatcher. Drains `outbox_events`, signs the
   * public envelope, POSTs to each client's configured endpoint, and
   * persists the delivery state. Like the processor it is exposed but
   * not auto-started — deployment topology owns the loop.
   */
  clientWebhookDispatcher: ClientWebhookDispatcher;
  ledgerService: LedgerService;
  idempotencyService: IdempotencyService;
  liquidityService: LiquidityService;
  outboxService: OutboxService;
  providerAssignmentService: ProviderAssignmentService;
  pricingService: PricingService;
  close: () => Promise<void>;
};

/**
 * Composition root for the CashYin Core API.
 *
 * Repositories are pure adapters over a {@link Database}; services own the
 * domain rules and orchestrate transactions through that database. Routes
 * receive ready-made services through this container and never construct
 * repositories or open Pools themselves.
 */
export function createContainer(options: ContainerOptions = {}): AppContainer {
  const db = new Database();

  const clientApiKeyRepository = new PgClientApiKeyRepository();
  const idempotencyRepository = new PgIdempotencyRepository();
  const chargeRepository = new PgCashInRepository();
  const cashoutRepository = new PgCashoutRepository();
  const ledgerAccountRepository = new PgLedgerAccountRepository();
  const ledgerEntryRepository = new PgLedgerEntryRepository();
  const ledgerIdempotencyRepository = new PgLedgerIdempotencyKeyRepository();
  const liquidityRepository = new PgLiquidityRepository();
  const outboxRepository = new PgOutboxRepository();
  const providerAssignmentRepository = new PgProviderAssignmentRepository();
  const webhookEventRepository = new PgWebhookEventRepository();
  const webhookProcessingAttemptRepository = new PgWebhookProcessingAttemptRepository();
  const clientWebhookEndpointRepository = new PgClientWebhookEndpointRepository();
  const clientWebhookDeliveryRepository = new PgClientWebhookDeliveryRepository();
  const pricingRuleRepository = new PgPricingRuleRepository();
  const providerCostRuleRepository = new PgProviderCostRuleRepository();
  const feeAssessmentRepository = new PgFeeAssessmentRepository();
  const subsidyEventRepository = new PgSubsidyEventRepository();

  const providerRegistry = new ProviderRegistry();
  // Bents webhook auth wiring. Every provider declares its own auth
  // model here so the adapter itself stays agnostic. The selection is
  // operator-controlled via `BENTS_WEBHOOK_AUTH_MODE`:
  //
  //   - `'none'` (default in production): Bents support confirmed
  //     May/2026 that their portal does NOT issue webhook signing
  //     secrets. The ingress trusts the transport (TLS + provider IP)
  //     only.
  //
  //   - `'hmac'`: requires `BENTS_WEBHOOK_SECRET` to be set; flips on
  //     `X-Bents-Signature` validation. Use this if Bents enables
  //     signing in the portal.
  //
  // Adding a third provider with a different scheme (Bearer, mTLS,
  // JWT, …) is a matter of implementing a new `WebhookAuthStrategy`
  // and wiring it in the corresponding adapter constructor.
  const bentsAuthStrategy: WebhookAuthStrategy =
    env.BENTS_WEBHOOK_AUTH_MODE === 'hmac'
      ? new Sha256HmacWebhookAuthStrategy({
          signatureHeader: BENTS_SIGNATURE_HEADER,
          signaturePrefix: 'sha256=',
          secret: env.BENTS_WEBHOOK_SECRET,
          requireSignature: env.BENTS_WEBHOOK_REQUIRE_SIGNATURE
        })
      : new NoVerificationWebhookAuthStrategy();
  const providerWebhookAdapterRegistry = new ProviderWebhookAdapterRegistry([
    new BentsWebhookAdapter({ authStrategy: bentsAuthStrategy })
  ]);
  const idempotencyService = new IdempotencyService(db, idempotencyRepository);
  const ledgerService = new LedgerService(
    ledgerEntryRepository,
    ledgerAccountRepository,
    ledgerIdempotencyRepository
  );
  const liquidityService = new LiquidityService(liquidityRepository);
  const outboxService = new OutboxService(outboxRepository);
  const clientBalanceService = new ClientBalanceService({
    repository: new PgClientBalanceRepository(),
    sql: db.pool
  });
  const providerAssignmentService = new ProviderAssignmentService(db, providerAssignmentRepository);
  const pricingService = new PricingService(
    pricingRuleRepository,
    providerCostRuleRepository,
    feeAssessmentRepository,
    subsidyEventRepository
  );

  const paymentService = new PaymentService({
    db,
    providerAssignment: providerAssignmentService,
    providerRegistry,
    chargeRepository,
    outbox: outboxService,
    defaultProvider: env.DEFAULT_PROVIDER,
    pricing: pricingService,
    ledger: ledgerService
  });

  const cashoutService = new CashoutService({
    db,
    idempotency: idempotencyService,
    providerAssignment: providerAssignmentService,
    providerRegistry,
    cashoutRepository,
    liquidity: liquidityService,
    outbox: outboxService,
    pricing: pricingService,
    ledger: ledgerService,
    balances: clientBalanceService
  });

  const webhookService = new WebhookService(
    db,
    providerWebhookAdapterRegistry,
    webhookEventRepository
  );

  const clientApiKeyService = new ClientApiKeyService({
    repository: clientApiKeyRepository,
    sql: db.pool,
    withTransaction: (fn) => db.withTransaction(fn)
  });

  const userClientGrantService = new UserClientGrantService({
    repository: new PgUserClientGrantRepository(),
    sql: db.pool
  });

  const webhookEndpointAdminService = new ClientWebhookEndpointAdminService({
    repository: new PgClientWebhookEndpointAdminRepository(),
    sql: db.pool
  });

  const clientConfigService = new ClientConfigService({
    pricingRuleRepository,
    providerAssignmentRepository,
    sql: db.pool
  });

  const cashoutStepUpService = new CashoutStepUpService({
    repository: new PgCashoutStepUpRepository(),
    sql: db.pool,
    ttlMs: env.CASHOUT_STEPUP_TTL_MS
  });

  const webhookEventProcessor = new WebhookEventProcessor({
    db,
    webhookEventRepository,
    attemptRepository: webhookProcessingAttemptRepository,
    paymentService,
    cashoutService,
    ...(options.workerId !== undefined ? { workerId: options.workerId } : {}),
    ...(options.webhookWorkerName !== undefined ? { workerName: options.webhookWorkerName } : {}),
    ...(options.webhookClaimFilter !== undefined ? { claimFilter: options.webhookClaimFilter } : {})
  });

  const clientWebhookHttpClient = new UndiciHttpClient({
    keepAliveTimeoutMs: env.CLIENT_WEBHOOK_KEEPALIVE_TIMEOUT_MS,
    keepAliveMaxTimeoutMs: env.CLIENT_WEBHOOK_KEEPALIVE_MAX_TIMEOUT_MS,
    connectionsPerOrigin: env.CLIENT_WEBHOOK_KEEPALIVE_CONNECTIONS
  });

  // Phase B1: optional outbox event-type partition for the dispatcher,
  // resolved from env (default off). When set, a dedicated dispatcher
  // process drains only the matching `event_type` rows (e.g. the critical
  // `pix.cash_in.paid` path) without head-of-line blocking from slower
  // deliveries. An explicit option overrides the env-derived filter.
  const dispatcherClaimFilter =
    options.dispatcherClaimFilter ?? dispatcherClaimFilterFromEnv();

  const clientWebhookDispatcher = new ClientWebhookDispatcher({
    db,
    outboxRepository,
    endpointRepository: clientWebhookEndpointRepository,
    deliveryRepository: clientWebhookDeliveryRepository,
    httpClient: clientWebhookHttpClient,
    reaperMinIntervalMs: env.OUTBOX_REAPER_MIN_INTERVAL_MS,
    ...(dispatcherClaimFilter ? { claimFilter: dispatcherClaimFilter } : {})
  });

  return {
    db,
    providerRegistry,
    providerWebhookAdapterRegistry,
    paymentService,
    cashoutService,
    webhookService,
    clientApiKeyService,
    userClientGrantService,
    webhookEndpointAdminService,
    clientConfigService,
    cashoutStepUpService,
    clientBalanceService,
    webhookEventProcessor,
    clientWebhookDispatcher,
    ledgerService,
    idempotencyService,
    liquidityService,
    outboxService,
    providerAssignmentService,
    pricingService,
    close: async () => {
      // Drain the outbound keep-alive pool first so in-flight deliveries are
      // not abruptly severed, then close the database pool.
      await clientWebhookHttpClient.close();
      await db.close();
    }
  };
}

/**
 * Builds the dispatcher's outbox claim partition from
 * `DISPATCHER_WORKER_*` env vars. Returns `undefined` when neither include
 * nor exclude is configured, so the dispatcher drains the whole queue
 * (back-compat). Default OFF.
 */
function dispatcherClaimFilterFromEnv(): OutboxDispatchClaimFilter | undefined {
  const filter: OutboxDispatchClaimFilter = {
    ...(env.DISPATCHER_WORKER_EVENT_TYPES
      ? { eventTypes: env.DISPATCHER_WORKER_EVENT_TYPES }
      : {}),
    ...(env.DISPATCHER_WORKER_EXCLUDE_EVENT_TYPES
      ? { excludeEventTypes: env.DISPATCHER_WORKER_EXCLUDE_EVENT_TYPES }
      : {})
  };
  return (filter.eventTypes?.length ?? 0) > 0 || (filter.excludeEventTypes?.length ?? 0) > 0
    ? filter
    : undefined;
}
