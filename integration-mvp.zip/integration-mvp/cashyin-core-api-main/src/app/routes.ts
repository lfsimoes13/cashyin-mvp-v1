import type { FastifyInstance } from 'fastify';
import { env } from '../shared/config/env.js';
import { buildAuthPreHandlers } from '../modules/auth/auth-enforcement.js';
import { ApiHmacVerifier } from '../modules/auth/api-hmac.js';
import { PgApiHmacNonceStore } from '../modules/auth/api-hmac-nonce-store.js';
import { registerBalanceRoutes } from '../modules/balances/balance.routes.js';
import { registerCashoutRoutes } from '../modules/cashouts/cashout.routes.js';
import { registerPaymentRoutes } from '../modules/payments/payment.routes.js';
import { registerMetricsRoutes } from '../modules/operations/metrics.routes.js';
import { registerWebhookRoutes } from '../modules/webhooks/webhook.routes.js';
import { registerAdminRoutes } from '../modules/admin/admin.routes.js';
import type { AppContainer } from './container.js';

export async function registerRoutes(app: FastifyInstance, container: AppContainer): Promise<void> {
  app.get('/health', async () => ({
    status: 'ok',
    service: 'cashyin-core-api',
    version: env.APP_VERSION
  }));
  app.get('/ready', async () => {
    try {
      await container.db.ping();
      return { status: 'ready' };
    } catch (error) {
      app.log.error({ error }, 'Database readiness check failed');
      throw error;
    }
  });

  await registerMetricsRoutes(app, { db: container.db });

  // Multi-channel authentication shared across `/v1/*` routes. `/health`,
  // `/ready` and `/internal/webhooks/*` deliberately skip this; the
  // webhook ingress authenticates the upstream via a provider-specific
  // WebhookAuthStrategy instead.
  //
  // The bundle layers AuthContext resolution + staged scope enforcement on
  // top, governed by `AUTH_ENFORCEMENT_MODE` (default `off` — no behaviour
  // change). The `frontend_bff` channel is gated by `BFF_AUTH_MODE`
  // (default `off`). Authentication itself is always enforced.
  const apiHmac = new ApiHmacVerifier({
    mode: env.API_HMAC_MODE,
    clockSkewMs: env.API_HMAC_CLOCK_SKEW_MS,
    getSigningSecret: (apiKeyId) => container.clientApiKeyService.getSigningSecret(apiKeyId),
    // Shared, cross-instance replay store (D16): a nonce spent on one replica
    // is rejected on every other replica within the validity window.
    nonceStore: new PgApiHmacNonceStore(container.db.pool)
  });

  const auth = buildAuthPreHandlers({
    mode: env.AUTH_ENFORCEMENT_MODE,
    clientApiKeyService: container.clientApiKeyService,
    bffMode: env.BFF_AUTH_MODE,
    ...(env.BFF_SHARED_SECRET !== undefined ? { bffSecret: env.BFF_SHARED_SECRET } : {}),
    // Per-user BFF RBAC (D7): no-op in `off`; in `enforce` the actor's grant is
    // resolved and intersected with DEFAULT_BFF_SCOPES.
    bffRbac: {
      mode: env.BFF_RBAC_MODE,
      resolveScopes: (actorUserId, clientId) =>
        container.userClientGrantService.resolveBffScopes(actorUserId, clientId)
    },
    apiHmac
  });

  await registerPaymentRoutes(app, {
    paymentService: container.paymentService,
    auth
  });
  await registerCashoutRoutes(app, {
    cashoutService: container.cashoutService,
    auth,
    stepUp: {
      mode: env.CASHOUT_STEPUP_MODE,
      service: container.cashoutStepUpService
    }
  });
  await registerBalanceRoutes(app, {
    clientBalanceService: container.clientBalanceService,
    auth
  });
  await registerWebhookRoutes(app, {
    webhookService: container.webhookService
  });

  // Administrative self-service endpoints. These always enforce their scope
  // (independent of AUTH_ENFORCEMENT_MODE) — see admin.routes.ts.
  await registerAdminRoutes(app, {
    authenticate: auth.authenticate,
    clientApiKeyService: container.clientApiKeyService,
    userClientGrantService: container.userClientGrantService,
    webhookEndpointAdminService: container.webhookEndpointAdminService,
    clientConfigService: container.clientConfigService
  });
}
