import { randomBytes } from 'node:crypto';

const ALPHANUMERIC = /[^A-Za-z0-9]/g;

export function generateTxid(prefix = 'TX'): string {
  const randomPart = randomBytes(32).toString('base64url').replace(ALPHANUMERIC, '').slice(0, 30);
  return `${prefix}${randomPart}`;
}

export function isValidTxid(txid: string): boolean {
  return /^[A-Za-z0-9]{28,37}$/.test(txid);
}

