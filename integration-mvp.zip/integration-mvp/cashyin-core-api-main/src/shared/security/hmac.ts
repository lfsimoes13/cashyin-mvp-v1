import { createHmac, timingSafeEqual } from 'node:crypto';

export function signSha256(payload: Buffer | string, secret: string): string {
  return `sha256=${createHmac('sha256', secret).update(payload).digest('hex')}`;
}

export function timingSafeEqualString(left: string, right: string): boolean {
  const leftBuffer = Buffer.from(left);
  const rightBuffer = Buffer.from(right);

  if (leftBuffer.length !== rightBuffer.length) {
    return false;
  }

  return timingSafeEqual(leftBuffer, rightBuffer);
}

export function verifySha256Signature(payload: Buffer | string, signature: string, secret: string): boolean {
  const expected = signSha256(payload, secret);
  return timingSafeEqualString(signature, expected);
}

