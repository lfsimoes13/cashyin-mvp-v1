/**
 * Pix identifier helpers — generation and validation.
 *
 * BACEN identifier vocabulary
 * ---------------------------
 *
 *   txid          ^[a-zA-Z0-9]{26,35}$
 *                 The public Pix charge identifier. In CashYin, this value
 *                 is ALWAYS generated internally before the provider call
 *                 (see `generatePixTxid`). It is opaque and non-enumerable —
 *                 it carries no provider, client, amount, date, or sequence
 *                 information. The provider's own txid is stored separately
 *                 in `pix_charges.provider_tx_id` and is never exposed in
 *                 public API responses or client webhooks.
 *                 Reference: Manual de Padrões para Iniciação do Pix, BACEN, §3.3.2.
 *
 *   provider_tx_id — the txid returned by the external provider (e.g. Bents).
 *                 Stored for internal conciliation only. Never public.
 *
   *   e2e_id        ^E[a-zA-Z0-9]{29}$  (32 chars total)
 *                 Assigned by the SPI rail at settlement time. Present on
 *                 both paid cash-in and completed cash-out records. Shared
 *                 with the client for reconciliation. CashYin standardises
 *                 this as `e2e_id` — providers may call it `endToEndId` or
 *                 `end_to_end_id` but those names only appear at the adapter
 *                 boundary and are never part of the public contract.
 *
 * Cash-out identifiers
 * --------------------
 *   A cash-out does NOT have a `txid`. The public identifier is the
 *   internal UUID (`id`), and the retry-safety key is `Idempotency-Key`
 *   (stored in `idempotency_keys`). The SPI settlement identifier is
 *   `e2e_id`.
 */

import { randomUUID } from 'node:crypto';

/** BACEN Pix `txid` regex — 26 to 35 alphanumeric characters. */
const PIX_TXID_REGEX = /^[a-zA-Z0-9]{26,35}$/;

/**
 * Generates a CashYin-issued Pix `txid`.
 *
 * Implementation: UUID v4 without hyphens, lowercased.
 *   `randomUUID().replaceAll('-', '').toLowerCase()`
 *
 * Properties:
 *   - 32 characters of lowercase hex → within BACEN range 26-35.
 *   - 128 bits of randomness — globally unique, non-enumerable.
 *   - Opaque: no provider, client, amount, date or sequence embedded.
 *   - Always passes `isValidPixTxid()` and the DB CHECK constraint.
 *
 * Call this BEFORE the provider API call so the txid is owned by CashYin
 * regardless of what the provider returns. Pass the result to the
 * `ProviderPixChargeRequest.txid` field so future providers that accept a
 * caller-supplied txid can use it directly.
 */
export function generatePixTxid(): string {
  return randomUUID().replaceAll('-', '').toLowerCase();
}

/**
 * Returns `true` when `value` is a BACEN-valid Pix `txid`.
 *
 * Use for validating incoming URL parameters (e.g. `GET /v1/pix/cash-in/:txid`)
 * or provider-returned `provider_tx_id` values before persisting them, so
 * an unexpected format surfaces as an explicit error rather than a silent
 * DB CHECK constraint violation.
 */
export function isValidPixTxid(value: unknown): value is string {
  return typeof value === 'string' && PIX_TXID_REGEX.test(value);
}

/**
 * Per-type Pix key format validation (BACEN / DICT).
 * ---------------------------------------------------
 *
 * A Pix key is only well-formed relative to its declared type. CashYin
 * validates the destination `pix.key` against `pix.key_type` at the cash-out
 * request boundary so a malformed key is rejected as a `422 validation_error`
 * before any balance reservation or provider call — never surfacing later as
 * an opaque provider rejection.
 *
 * Formats (aligned with the BACEN DICT key specification):
 *   - `CPF`   — 11 digits, digits only.
 *   - `CNPJ`  — 14 digits, digits only.
 *   - `PHONE` — E.164: `+` followed by a country code and subscriber number
 *               (up to 15 digits total). e.g. `+5511999999999`.
 *   - `EMAIL` — RFC-style local-part `@` domain; matched case-insensitively.
 *   - `EVP`   — random key issued by BACEN, a lowercase hex UUID v4. Matched
 *               case-insensitively so a pasted upper-case UUID is accepted.
 */
export const PIX_KEY_FORMAT_REGEX: Record<string, RegExp> = {
  CPF: /^\d{11}$/,
  CNPJ: /^\d{14}$/,
  PHONE: /^\+[1-9]\d{1,14}$/,
  EMAIL:
    /^[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)*$/i,
  EVP: /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i
};

/**
 * Returns `true` when `key` matches the canonical format for `keyType`.
 *
 * An unknown `keyType` returns `true` (the enum is validated separately, so a
 * format check should not double-reject); callers that need the type itself
 * validated must do so before calling this helper.
 */
export function isValidPixKeyForType(keyType: string, key: string): boolean {
  const regex = PIX_KEY_FORMAT_REGEX[keyType];
  return regex ? regex.test(key) : true;
}
