import { z } from 'zod';

/**
 * Canonical money schema for the public contract. Amounts are always
 * integers in BRL cents — every API surface that takes/returns an
 * amount uses this schema directly so the unit convention can never
 * drift between endpoints.
 *
 * The cap (100M cents = R$ 1.000.000,00) is a defensive ceiling, not a
 * business limit; reject obviously-malformed requests at the schema
 * layer rather than letting them reach the provider.
 */
export const amountSchema = z.number().int().positive().max(100_000_000);

/**
 * Legacy alias kept for the cash-out flow, which still uses the
 * pre-refactor `amount_cents` naming on its public contract. Will be
 * removed once the cash-out flow goes through the snake_case +
 * "cents are implicit" refactor.
 */
export const amountCentsSchema = amountSchema;
