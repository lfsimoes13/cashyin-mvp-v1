import 'dotenv/config';
import { z } from 'zod';

/**
 * Splits a comma-separated env value into a trimmed, non-empty string
 * array. Returns `undefined` when the var is unset or contains only
 * blanks, so downstream "no filter" logic can rely on `undefined`.
 */
function csvToStringArray(value: string | undefined): string[] | undefined {
  if (value === undefined) return undefined;
  const items = value
    .split(',')
    .map((entry) => entry.trim())
    .filter((entry) => entry.length > 0);
  return items.length > 0 ? items : undefined;
}

const EnvSchema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'staging', 'production']).default('development'),
  PORT: z.coerce.number().int().positive().default(3000),
  CORS_ORIGINS: z.string().optional().transform(csvToStringArray),
  LOG_LEVEL: z.enum(['fatal', 'error', 'warn', 'info', 'debug', 'trace', 'silent']).default('info'),
  /**
   * Build identifier surfaced by `/health` so operators can confirm which
   * commit is actually running in an environment. Set at image build time
   * via the `GIT_SHA` Docker build-arg (see Dockerfile + deploy.yml); falls
   * back to `'unknown'` for local/dev runs where no build stamp exists.
   */
  APP_VERSION: z.string().min(1).default('unknown'),
  DATABASE_URL: z.string().url().optional(),
  DATABASE_POOL_MAX: z.coerce.number().int().positive().max(200).default(10),
  DATABASE_STATEMENT_TIMEOUT_MS: z.coerce.number().int().positive().default(10_000),
  DATABASE_CONNECTION_TIMEOUT_MS: z.coerce.number().int().positive().default(2_000),
  REDIS_URL: z.string().url().optional(),
  API_BASE_URL: z.string().url().default('https://api.cashyin.example'),
  BENTS_API_BASE_URL: z.string().url().default('https://finance.bents.com.br/api/v2/public'),
  BENTS_API_KEY: z.string().min(1).optional(),
  BENTS_WEBHOOK_SECRET: z.string().min(1).optional(),
  /**
   * Selects the webhook authentication strategy applied to inbound
   * Bents callbacks. Defaults to `'none'` because Bents support
   * confirmed (May/2026) that their portal does not issue webhook
   * signing secrets — the strategy must accept unsigned bodies.
   *
   *   - `'none'` — {@link NoVerificationWebhookAuthStrategy}: every
   *     authenticated-at-transport request is accepted. Trust comes
   *     from TLS + provider IP allowlist + URL obscurity.
   *
   *   - `'hmac'` — {@link Sha256HmacWebhookAuthStrategy}: verifies
   *     `X-Bents-Signature` (sha256= HMAC over raw body) using
   *     `BENTS_WEBHOOK_SECRET`. Strictness controlled by
   *     {@link BENTS_WEBHOOK_REQUIRE_SIGNATURE}.
   *
   * Flip to `'hmac'` only after Bents enables signing in the portal
   * and you've populated `BENTS_WEBHOOK_SECRET` in Secrets Manager.
   */
  BENTS_WEBHOOK_AUTH_MODE: z.enum(['none', 'hmac']).default('none'),
  /**
   * Used **only** when `BENTS_WEBHOOK_AUTH_MODE = 'hmac'`. Controls
   * whether the HMAC strategy operates in strict mode (default `true`,
   * rejects requests without a verifiable signature) or permissive
   * mode (`false`, accepts unsigned but still verifies when both
   * secret + header are present). Ignored when the auth mode is
   * `'none'`.
   */
  BENTS_WEBHOOK_REQUIRE_SIGNATURE: z
    .string()
    .optional()
    .transform((value) => {
      if (value === undefined) return true;
      const normalised = value.trim().toLowerCase();
      return !(normalised === 'false' || normalised === '0' || normalised === 'no');
    }),
  /**
   * Controls the per-route scope-authorization layer. The normalised
   * `AuthContext` is resolved **unconditionally** when a principal is present
   * (so tenant + audit actor are always available); this flag only stages the
   * scope *guards*:
   *
   *   - `'off'`     — no scope checks (the scope layer is inert). Bearer/BFF
   *                   authentication still runs; the context is still resolved.
   *   - `'shadow'`  — evaluate + log/measure scope decisions without denying.
   *   - `'enforce'` — deny requests lacking the required scope.
   *
   * Defaults to `'off'` so the scope layer is inert until explicitly enabled.
   */
  AUTH_ENFORCEMENT_MODE: z.enum(['off', 'shadow', 'enforce']).default('off'),
  /**
   * Controls acceptance of the trusted Backend-for-Frontend (BFF) channel.
   * The BFF authenticates a human via Cognito/e-mail+password on its own
   * side and then calls the Core API with a shared-secret token plus trusted
   * actor/tenant headers (`X-CashYin-BFF-Token`, `X-CashYin-Actor-User-Id`,
   * `X-CashYin-Client-Id`). The Core verifies the token locally (no remote
   * IdP call on the critical path) and represents the human as an audit
   * actor.
   *
   *   - `'off'`     — BFF tokens are ignored; only the `api_direct` Bearer
   *                   credential authenticates (current behaviour).
   *   - `'enforce'` — BFF tokens are accepted and verified against
   *                   `BFF_SHARED_SECRET`; requests presenting a BFF token
   *                   resolve into the `frontend_bff` channel.
   *
   * Independent of `AUTH_ENFORCEMENT_MODE`, which governs scope enforcement.
   */
  BFF_AUTH_MODE: z.enum(['off', 'enforce']).default('off'),
  /**
   * Shared secret the trusted BFF presents in `X-CashYin-BFF-Token`. Compared
   * timing-safe. Required (and must be ≥ 32 chars) when `BFF_AUTH_MODE` is
   * `'enforce'`; stored in Secrets Manager, never logged. Optional otherwise.
   */
  BFF_SHARED_SECRET: z.string().min(32).optional(),
  /**
   * Per-user RBAC for the trusted BFF channel (deviation D7). Only meaningful
   * when `BFF_AUTH_MODE='enforce'`.
   *
   *   - `'off'`     — every authenticated BFF actor receives the full
   *                   `DEFAULT_BFF_SCOPES` (current behaviour).
   *   - `'enforce'` — the actor's scopes are resolved from `user_client_grants`
   *                   and intersected with `DEFAULT_BFF_SCOPES`; an actor with
   *                   no active grant for the tenant is rejected (403).
   */
  BFF_RBAC_MODE: z.enum(['off', 'enforce']).default('off'),
  /**
   * Step-up (per-operation second factor) enforcement for human-initiated
   * (`frontend_bff`) cash-outs. The BFF performs the MFA challenge with the
   * human, mints a proof via `POST /v1/pix/cash-out/step-up`, then presents
   * the returned proof id on the cash-out request. `api_direct` machine
   * cash-outs are exempt (the API key is the credential).
   *
   *   - `'off'`     — no step-up checks (current behaviour).
   *   - `'shadow'`  — log would-be denials; never block.
   *   - `'enforce'` — require a valid, single-use, hash-bound proof.
   */
  CASHOUT_STEPUP_MODE: z.enum(['off', 'shadow', 'enforce']).default('off'),
  /** Lifetime of an issued cash-out step-up proof (ms). Default 5 minutes. */
  CASHOUT_STEPUP_TTL_MS: z.coerce.number().int().positive().default(300_000),
  /**
   * Request-signing (HMAC) enforcement for the `api_direct` channel. The
   * client signs a canonical string (method, path, timestamp, nonce, body
   * digest) with the per-key `signing_secret` returned at issuance, sending
   * `X-CashYin-Timestamp`, `X-CashYin-Nonce` and `X-CashYin-Signature`.
   *
   *   - `'off'`     — signature headers ignored (current behaviour).
   *   - `'shadow'`  — verify when present, log mismatches; never block.
   *   - `'enforce'` — require a valid signature; keys must carry a
   *                   `signing_secret` (rotate legacy keys first).
   */
  API_HMAC_MODE: z.enum(['off', 'shadow', 'enforce']).default('off'),
  /** Max allowed clock skew for the signed timestamp (ms). Default 5 minutes. */
  API_HMAC_CLOCK_SKEW_MS: z.coerce.number().int().positive().default(300_000),
  DEFAULT_PROVIDER: z.literal('bents').default('bents'),
  REQUEST_TIMEOUT_MS: z.coerce.number().int().positive().default(5000),
  /**
   * Timeout (ms) applied specifically to `POST /pix/charge` calls during
   * `POST /v1/pix/cash-in/qrcode`. Kept tighter than the global
   * `REQUEST_TIMEOUT_MS` so the QR Code endpoint fails fast when Bents
   * is slow, rather than holding open Node sockets and DB connections.
   * Recommended range: 800–2 000 ms. Default: 2 000 ms.
   */
  BENTS_CASHIN_CHARGE_TIMEOUT_MS: z.coerce.number().int().positive().default(2_000),
  RATE_LIMIT_MAX: z.coerce.number().int().positive().default(600),
  RATE_LIMIT_WINDOW: z.string().default('1 minute'),
  /**
   * Per-client rate limit specifically for `POST /v1/pix/cash-in/qrcode`.
   * Keeps high-volume QR Code bursts from one client from blocking others
   * while still letting genuine high-throughput clients operate above the
   * global default. Default: 1 200 (2× global, ~20 rps per client key).
   */
  RATE_LIMIT_QRCODE_MAX: z.coerce.number().int().positive().default(1_200),
  RATE_LIMIT_QRCODE_WINDOW: z.string().default('1 minute'),
  /**
   * Default HTTP timeout (ms) for outgoing webhook POSTs to client endpoints.
   * 10 s is generous; high for the critical cash-in paid path but acceptable
   * for non-critical events where we prefer waiting over early retries.
   */
  CLIENT_WEBHOOK_TIMEOUT_MS: z.coerce.number().int().positive().default(10_000),
  /**
   * Tighter timeout (ms) for `pix.cash_in.paid` webhook deliveries.
   * A slow client endpoint on the critical path should not hold the dispatcher
   * worker; fail fast and let the exponential-backoff retry pick it up.
   * Recommended: 1 000–3 000 ms. Default: 3 000 ms.
   */
  CLIENT_WEBHOOK_CASHIN_PAID_TIMEOUT_MS: z.coerce.number().int().positive().default(3_000),

  // ─── Operational metrics ──────────────────────────────────────────────
  METRICS_ENABLED: z
    .string()
    .optional()
    .transform((value) => {
      if (value === undefined) return true;
      const normalized = value.trim().toLowerCase();
      return !(normalized === 'false' || normalized === '0' || normalized === 'no');
    }),
  METRICS_PATH: z.string().min(1).default('/internal/metrics'),
  /** Optional bearer token required by `/internal/metrics` when set. */
  METRICS_BEARER_TOKEN: z.string().min(1).optional(),

  // ─── Worker runtime ─────────────────────────────────────────────────
  //
  // Shared by every background worker (provider webhook processor,
  // public webhook dispatcher). The defaults target a low-volume
  // dev/prod-baseline profile: snappy when work is present, gentle
  // when the queue is empty. Tune per environment via ECS task env.
  //
  // With LISTEN/NOTIFY (PgNotifyWatcher) wired in both workers, the
  // idle intervals are only the fallback for when the notify connection
  // is temporarily down. They are kept low so the polling fallback is
  // still fast:
  //
  //   WORKER_IDLE_INTERVAL_MS     = 200  ms  (was 1 000 ms — reduced 5×)
  //   WORKER_MAX_IDLE_INTERVAL_MS = 5 000 ms  (was 30 000 ms — reduced 6×)
  //
  // The loop sleeps `WORKER_BUSY_INTERVAL_MS` after a successful
  // tick that processed work, ramps up to
  // `WORKER_MAX_IDLE_INTERVAL_MS` on consecutive idle ticks
  // (starting from `WORKER_IDLE_INTERVAL_MS`), and applies an
  // exponential backoff up to `WORKER_MAX_ERROR_BACKOFF_MS` on
  // consecutive errored ticks (starting from
  // `WORKER_ERROR_BACKOFF_MS`).
  WORKER_BUSY_INTERVAL_MS: z.coerce.number().int().nonnegative().default(50),
  WORKER_IDLE_INTERVAL_MS: z.coerce.number().int().positive().default(200),
  WORKER_MAX_IDLE_INTERVAL_MS: z.coerce.number().int().positive().default(5_000),
  WORKER_ERROR_BACKOFF_MS: z.coerce.number().int().positive().default(5_000),
  WORKER_MAX_ERROR_BACKOFF_MS: z.coerce.number().int().positive().default(60_000),
  WORKER_SHUTDOWN_TIMEOUT_MS: z.coerce.number().int().positive().default(15_000),
  /**
   * Optional process identifier persisted into
   * `provider_webhook_processing_attempts.worker_id` (and surfaced in
   * structured logs). Defaults to `${hostname}-${pid}` at runtime so
   * concurrent replicas remain distinguishable without manual config.
   */
  WORKER_ID: z.string().min(1).optional(),

  /**
   * Set to `false` / `0` / `no` to disable the PgNotifyWatcher on all
   * workers. When disabled the loops rely entirely on polling-fallback
   * intervals (`WORKER_IDLE_INTERVAL_MS` / `WORKER_MAX_IDLE_INTERVAL_MS`).
   * Useful for environments that cannot maintain a persistent TCP connection
   * to Postgres (e.g. serverless runtimes, short-lived debug containers).
   * Defaults to `true` (watcher always on).
   */
  WORKER_ENABLE_DB_NOTIFY: z
    .string()
    .optional()
    .transform((v) => {
      if (v === undefined) return true;
      const n = v.trim().toLowerCase();
      return !(n === 'false' || n === '0' || n === 'no');
    }),

  /**
   * Initial reconnect delay for the PgNotifyWatcher after a lost LISTEN
   * connection. Doubles on each failed attempt up to `maxReconnectDelayMs`
   * (hardcoded at 30 000 ms inside PgNotifyWatcher). Expressed in ms.
   * Default: 1 000.
   */
  WORKER_NOTIFY_RECONNECT_BASE_MS: z.coerce.number().int().positive().default(1_000),

  // ─── Provider webhook worker partitioning (Fase 1) ────────────────────
  //
  // Optional claim filters that let multiple provider-webhook-processor
  // replicas drain DISJOINT subsets of `webhook_events`, so a backlog of
  // cash-out (or non-paid cash-in) can never delay `pix.cash_in.paid`.
  // When every filter is unset the worker drains the whole queue exactly
  // as before (back-compat: the historical single-worker behaviour).
  //
  //   cashin-paid     OPERATION_TYPE=cash_in  NORMALIZED_STATUS=paid
  //   cashin-default  OPERATION_TYPE=cash_in  EXCLUDE_NORMALIZED_STATUS=paid
  //   cashout         OPERATION_TYPE=cash_out
  //
  /** Logical worker role; surfaced in logs and the `worker` metric label. */
  WEBHOOK_WORKER_NAME: z.string().min(1).optional(),
  /** Claim only events of this operation type. */
  WEBHOOK_WORKER_OPERATION_TYPE: z.enum(['cash_in', 'cash_out']).optional(),
  /** Claim only events with this normalized status kind. */
  WEBHOOK_WORKER_NORMALIZED_STATUS_KIND: z.enum(['cash_in', 'cash_out', 'unknown']).optional(),
  /** Claim only events with this normalized status (e.g. `paid`). */
  WEBHOOK_WORKER_NORMALIZED_STATUS: z.string().min(1).optional(),
  /** Skip events whose normalized status is in this comma-separated list. */
  WEBHOOK_WORKER_EXCLUDE_NORMALIZED_STATUS: z.string().optional().transform(csvToStringArray),
  /** Claim only events whose `event_type` is in this comma-separated list. */
  WEBHOOK_WORKER_EVENT_TYPES: z.string().optional().transform(csvToStringArray),

  // ─── Outbox dispatcher partitioning (Fase B1) ─────────────────────────
  //
  // Optional claim filters that let multiple webhook-dispatcher replicas
  // drain DISJOINT subsets of `outbox_events` by `event_type`, so a backlog
  // of slow cash-out / non-critical deliveries can never head-of-line block
  // `pix.cash_in.paid`. DEFAULT OFF: when both are unset the dispatcher drains
  // every supported aggregate type exactly as before (back-compat).
  //
  //   cashin-paid (dedicated)  DISPATCHER_WORKER_EVENT_TYPES=pix.cash_in.paid
  //   default     (everything  DISPATCHER_WORKER_EXCLUDE_EVENT_TYPES=pix.cash_in.paid
  //               except paid)
  //
  /** Claim only outbox rows whose `event_type` is in this comma-separated list. */
  DISPATCHER_WORKER_EVENT_TYPES: z.string().optional().transform(csvToStringArray),
  /** Never claim outbox rows whose `event_type` is in this comma-separated list. */
  DISPATCHER_WORKER_EXCLUDE_EVENT_TYPES: z.string().optional().transform(csvToStringArray),
  /**
   * Minimum gap (ms) between outbox stale-reaper sweeps in the dispatcher.
   * The reaper only recovers rows abandoned by a crashed worker, so it does
   * not need to run on every (latency-critical) tick. Default: 30 000 ms.
   */
  OUTBOX_REAPER_MIN_INTERVAL_MS: z.coerce.number().int().nonnegative().default(30_000),

  // ─── Outbound webhook HTTP keep-alive (B4) ────────────────────────────
  //
  // Connection pool reuse for outbound client webhook POSTs. Reusing TLS
  // sockets removes the handshake from the critical first-attempt path.
  /** Idle keep-alive window before an outbound socket may be closed (ms). */
  CLIENT_WEBHOOK_KEEPALIVE_TIMEOUT_MS: z.coerce.number().int().positive().default(30_000),
  /** Hard cap on the keep-alive window the client server may request (ms). */
  CLIENT_WEBHOOK_KEEPALIVE_MAX_TIMEOUT_MS: z.coerce.number().int().positive().default(60_000),
  /** Max simultaneous outbound connections per client origin. */
  CLIENT_WEBHOOK_KEEPALIVE_CONNECTIONS: z.coerce.number().int().positive().default(64)
}).superRefine((value, ctx) => {
  if (value.BFF_AUTH_MODE === 'enforce' && !value.BFF_SHARED_SECRET) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      path: ['BFF_SHARED_SECRET'],
      message: 'BFF_SHARED_SECRET is required when BFF_AUTH_MODE=enforce'
    });
  }
  if (value.BFF_RBAC_MODE === 'enforce' && value.BFF_AUTH_MODE !== 'enforce') {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      path: ['BFF_RBAC_MODE'],
      message: 'BFF_RBAC_MODE=enforce requires BFF_AUTH_MODE=enforce'
    });
  }
});

export const env = EnvSchema.parse(process.env);
export type Env = typeof env;

