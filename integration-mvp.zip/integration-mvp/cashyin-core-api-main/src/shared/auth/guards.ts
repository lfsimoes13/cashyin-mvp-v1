import { timingSafeEqualString } from '../security/hmac.js';
import type { AuthContext } from './auth-context.js';
import type { AuthScope } from './auth-scopes.js';
import {
  clientMismatchError,
  insufficientScopeError,
  invalidAuthError,
  missingAuthError,
  stepUpRequiredError
} from './auth-errors.js';

/**
 * Pure, side-effect-free authorization guards over an {@link AuthContext}.
 *
 * Each guard accepts EITHER a resolved `AuthContext` or any object that
 * carries one under `authContext` (e.g. a `FastifyRequest`). This keeps
 * route code idiomatic (`requireScope(request, ...)`) while unit tests can
 * pass a plain context object with no Fastify dependency.
 *
 * Guards never perform I/O — no DB, cache, or network — so they add no
 * latency to hot paths. On denial they throw the stable, non-leaky
 * `AppError`s defined in `./auth-errors.ts`.
 */

/** Anything carrying an optional {@link AuthContext} (e.g. a request). */
export type AuthContextCarrier = { authContext?: AuthContext | undefined };

/** A guard input: a context directly, or something carrying one. */
export type AuthContextSource = AuthContext | AuthContextCarrier;

function looksLikeAuthContext(value: AuthContextSource): value is AuthContext {
  const candidate = value as Partial<AuthContext>;
  return (
    typeof candidate.channel === 'string' &&
    typeof candidate.principalType === 'string' &&
    typeof candidate.principalId === 'string' &&
    Array.isArray(candidate.scopes)
  );
}

/**
 * Extract the {@link AuthContext} from a guard input, or `undefined` when
 * none is present.
 */
export function extractAuthContext(source: AuthContextSource | null | undefined): AuthContext | undefined {
  if (source === null || source === undefined) return undefined;
  if (looksLikeAuthContext(source)) return source;
  return source.authContext ?? undefined;
}

/**
 * Require an authenticated caller. Returns the resolved context for
 * convenient chaining.
 *
 * @throws missing-auth (401) when no context is present.
 * @throws invalid-auth (401) when the context is present but expired.
 */
export function requireAuth(source: AuthContextSource | null | undefined): AuthContext {
  const context = extractAuthContext(source);
  if (!context) {
    throw missingAuthError();
  }
  if (typeof context.expiresAt === 'number' && context.expiresAt <= Date.now()) {
    throw invalidAuthError();
  }
  return context;
}

/**
 * Require the caller to hold a specific scope.
 *
 * @throws missing/invalid-auth (401) per {@link requireAuth}.
 * @throws insufficient-scope (403) when the scope is absent.
 */
export function requireScope(source: AuthContextSource | null | undefined, scope: AuthScope): AuthContext {
  const context = requireAuth(source);
  if (!context.scopes.includes(scope)) {
    throw insufficientScopeError(scope);
  }
  return context;
}

/**
 * Require the caller to be scoped to a specific client/tenant.
 *
 * @throws missing/invalid-auth (401) per {@link requireAuth}.
 * @throws client-mismatch (403) when the context's `clientId` is absent or
 *         differs from the requested one.
 */
export function requireClientAccess(
  source: AuthContextSource | null | undefined,
  clientId: string
): AuthContext {
  const context = requireAuth(source);
  if (context.clientId === undefined || context.clientId !== clientId) {
    throw clientMismatchError();
  }
  return context;
}

/**
 * Require at least one of the supplied authentication methods (`amr`) to
 * be present on the session.
 *
 * @throws missing/invalid-auth (401) per {@link requireAuth}.
 * @throws step-up-required (403, reason `insufficient_amr`) when none of
 *         the required methods are present.
 */
export function requireAnyAmr(
  source: AuthContextSource | null | undefined,
  methods: readonly string[]
): AuthContext {
  const context = requireAuth(source);
  const present = context.amr ?? [];
  const satisfied = methods.some((method) => present.includes(method));
  if (!satisfied) {
    throw stepUpRequiredError('insufficient_amr');
  }
  return context;
}

/**
 * Require a valid, non-expired step-up proof bound to a specific cash-out
 * operation. The proof's `transactionHash` must match the operation's
 * hash exactly (timing-safe comparison).
 *
 * @throws missing/invalid-auth (401) per {@link requireAuth}.
 * @throws step-up-required (403) with a coarse reason when the proof is
 *         missing, expired, or bound to a different operation.
 */
export function requireCashoutStepUp(
  source: AuthContextSource | null | undefined,
  transactionHash: string
): AuthContext {
  const context = requireAuth(source);
  const proof = context.stepUp;
  if (!proof) {
    throw stepUpRequiredError('missing');
  }
  if (proof.expiresAt <= Date.now()) {
    throw stepUpRequiredError('expired');
  }
  if (!timingSafeEqualString(proof.transactionHash, transactionHash)) {
    throw stepUpRequiredError('mismatch');
  }
  return context;
}
