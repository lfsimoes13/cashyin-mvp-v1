import { AppError } from '../errors/app-error.js';

/**
 * Stable, non-leaky authentication / authorization errors.
 *
 * Every factory returns an {@link AppError} with a stable machine `code`
 * and a generic, caller-safe `message`. They MUST NOT embed secrets,
 * tokens, signatures, OTPs, cookies, `Authorization` header values, or raw
 * request payloads — only coarse, already-known identifiers (a scope name,
 * a client id the caller supplied) where that aids debugging without
 * disclosing anything sensitive.
 *
 * Denial responses are deliberately uniform so probing callers cannot
 * distinguish "missing" from "malformed" credentials.
 */

/** Stable error codes emitted by the auth layer. Additive only. */
export const AUTH_ERROR_CODES = {
  MISSING_AUTH: 'auth_required',
  INVALID_AUTH: 'auth_invalid',
  INSUFFICIENT_SCOPE: 'auth_insufficient_scope',
  CLIENT_MISMATCH: 'auth_client_mismatch',
  STEP_UP_REQUIRED: 'auth_step_up_required'
} as const;

/** No authentication context was present on the request. */
export function missingAuthError(): AppError {
  return new AppError(AUTH_ERROR_CODES.MISSING_AUTH, 'Authentication required', 401);
}

/**
 * Authentication was present but could not be trusted (malformed,
 * expired, or otherwise unverifiable). Kept indistinguishable from the
 * missing case at the HTTP layer to avoid leaking credential state.
 */
export function invalidAuthError(): AppError {
  return new AppError(AUTH_ERROR_CODES.INVALID_AUTH, 'Invalid authentication', 401);
}

/**
 * The principal is authenticated but lacks a required capability. The
 * required scope name is safe to surface — it is part of the public API
 * contract, not a secret.
 */
export function insufficientScopeError(requiredScope: string): AppError {
  return new AppError(
    AUTH_ERROR_CODES.INSUFFICIENT_SCOPE,
    'Insufficient scope for this operation',
    403,
    { requiredScope }
  );
}

/**
 * The principal tried to act on a tenant / client it is not authorised
 * for. We do not echo back the principal's own clientId to avoid
 * confirming cross-tenant existence; the requested id is the one the
 * caller already supplied.
 */
export function clientMismatchError(): AppError {
  return new AppError(
    AUTH_ERROR_CODES.CLIENT_MISMATCH,
    'Not authorized for the requested client',
    403
  );
}

/**
 * A sensitive action requires a step-up / multi-factor proof that was
 * absent, expired, or not bound to this operation. The reason is a coarse
 * enum, never the OTP, factor secret, or proof material.
 */
export function stepUpRequiredError(
  reason: 'missing' | 'expired' | 'mismatch' | 'insufficient_amr' = 'missing'
): AppError {
  return new AppError(
    AUTH_ERROR_CODES.STEP_UP_REQUIRED,
    'Step-up authentication required',
    403,
    { reason }
  );
}
