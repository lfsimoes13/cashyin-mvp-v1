import type { AuthContext } from './auth-context.js';

/**
 * Module augmentation exposing the normalised {@link AuthContext} on every
 * Fastify request.
 *
 * PR 1 only adds the typing — nothing populates `request.authContext` yet,
 * so it is optional and existing routes keep using `request.client`
 * unchanged. A later PR adds the preHandler that resolves the caller's
 * credentials into an `AuthContext` and the guards in `./guards.ts` that
 * read it.
 *
 * Importing this file anywhere in the `src` graph (it is picked up by the
 * `src/**\/*.ts` include in both `tsconfig.json` and `tsconfig.build.json`)
 * is sufficient for the augmentation to apply project-wide.
 */
declare module 'fastify' {
  interface FastifyRequest {
    /**
     * Normalised authenticated caller. Populated by a future auth
     * preHandler; reading it on a route that has no such preHandler is a
     * programming error and yields `undefined`.
     */
    authContext?: AuthContext;
  }
}

export {};
