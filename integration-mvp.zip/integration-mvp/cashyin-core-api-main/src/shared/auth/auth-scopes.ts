/**
 * Canonical OAuth-style scope strings recognised by the Core API.
 *
 * Scopes are coarse-grained capability grants attached to an
 * {@link import('./auth-context.js').AuthContext}. They are intentionally
 * transport- and issuer-agnostic: the BFF, a direct HMAC client, or an
 * internal service all normalise into the same scope strings so guards
 * (see `./guards.ts`) never branch on the authentication channel.
 *
 * Naming convention: `<domain>:<resource>:<action>`, lower-case, colon
 * separated. The Pix resources mirror the domain vocabulary used
 * everywhere else in the system (`cash_in` / `cash_out`, the
 * `operation_type` enum, the route paths and webhook event types) so a
 * scope never has to be mentally mapped onto a different word. Keep this
 * list small and additive — removing or renaming a scope is a breaking
 * change for every credential already carrying it.
 */
export const AUTH_SCOPES = {
  PIX_CASH_IN_CREATE: 'pix:cash_in:create',
  PIX_CASH_IN_READ: 'pix:cash_in:read',
  PIX_CASH_OUT_CREATE: 'pix:cash_out:create',
  PIX_CASH_OUT_READ: 'pix:cash_out:read',
  PIX_CASH_OUT_APPROVE: 'pix:cash_out:approve',
  /** Read the calling client's balance via `GET /v1/balance`. */
  BALANCE_READ: 'balance:read',
  WEBHOOKS_MANAGE: 'webhooks:manage',
  CLIENTS_READ: 'clients:read',
  /**
   * Administrative management of the calling client's own API keys
   * (issue/list/rotate/revoke) via `/v1/admin/api-keys`. Elevated: never
   * part of {@link DEFAULT_CLIENT_API_SCOPES} or the BFF default set; must be
   * granted intentionally to an operator/admin credential.
   */
  API_KEYS_MANAGE: 'api_keys:manage',
  /**
   * Manage the calling client's per-user BFF access grants
   * (`/v1/admin/bff-grants`). Elevated: never part of the default sets; must
   * be granted intentionally to an operator/admin credential.
   */
  CLIENTS_MANAGE: 'clients:manage'
} as const;

/**
 * Union of every recognised scope string, derived from {@link AUTH_SCOPES}
 * so the type can never drift from the runtime constant.
 */
export type AuthScope = (typeof AUTH_SCOPES)[keyof typeof AUTH_SCOPES];

/**
 * Frozen list of all known scopes. Useful for validation, documentation,
 * and admin tooling that enumerates assignable capabilities.
 */
export const ALL_AUTH_SCOPES: readonly AuthScope[] = Object.freeze(
  Object.values(AUTH_SCOPES)
);

/**
 * Narrow an arbitrary string to a known {@link AuthScope}. Lets callers
 * (e.g. credential loaders) reject unknown scopes without a hard-coded
 * switch.
 */
export function isAuthScope(value: string): value is AuthScope {
  return (ALL_AUTH_SCOPES as readonly string[]).includes(value);
}

/**
 * Default capability set granted to a standard, machine-to-machine client
 * API key when none is specified explicitly at issuance time.
 *
 * It covers exactly what a tenant integrating the public `/v1/pix/*`
 * endpoints needs today — creating and reading cash-in charges and
 * cash-outs, plus reading its own balance — and deliberately excludes
 * elevated/administrative scopes (`pix:cash_out:approve`, `webhooks:manage`,
 * `clients:read`, `api_keys:manage`), which must be granted intentionally.
 *
 * This constant is the source of truth for the backfill in
 * `migrations/0017_*` / `migrations/0022_*` and for
 * `scripts/provision-test-client.mjs`; keep the SQL literals in those
 * migrations in sync with this list.
 */
export const DEFAULT_CLIENT_API_SCOPES: readonly AuthScope[] = Object.freeze([
  AUTH_SCOPES.PIX_CASH_IN_CREATE,
  AUTH_SCOPES.PIX_CASH_IN_READ,
  AUTH_SCOPES.PIX_CASH_OUT_CREATE,
  AUTH_SCOPES.PIX_CASH_OUT_READ,
  AUTH_SCOPES.BALANCE_READ
]);
