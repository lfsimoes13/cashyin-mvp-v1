import type { AuthScope } from './auth-scopes.js';

/**
 * Transport / origin of an authenticated request.
 *
 *   - `frontend_bff`   — a trusted Backend-for-Frontend forwarding an
 *                        end-user session (human acting through the UI).
 *   - `api_direct`     — a CashYin-issued machine credential calling the
 *                        API directly (HMAC-signed in a later PR).
 *   - `internal`       — a first-party service / worker inside the trust
 *                        boundary (no external principal).
 *   - `webhook_provider` — an inbound provider callback authenticated by a
 *                        provider-specific {@link WebhookAuthStrategy}.
 */
export type AuthChannel = 'frontend_bff' | 'api_direct' | 'internal' | 'webhook_provider';

/**
 * Nature of the principal the request acts as.
 *
 *   - `user`       — a human end-user (typically via `frontend_bff`).
 *   - `api_client` — a machine API client / tenant credential.
 *   - `service`    — a first-party internal service or worker.
 *   - `provider`   — an external payment provider (webhook ingress).
 */
export type PrincipalType = 'user' | 'api_client' | 'service' | 'provider';

/**
 * Proof that a step-up / multi-factor challenge was satisfied for a
 * sensitive action (e.g. cash-out). PR 1 only models the shape; issuing
 * and verifying step-up proofs lands in a later PR.
 *
 * The proof is deliberately bound to a specific operation via
 * `transactionHash` so a step-up obtained for one cash-out cannot be
 * replayed against another.
 */
export type StepUpProof = {
  /**
   * Authentication-method references that satisfied the step-up (e.g.
   * `['otp']`, `['webauthn']`). Mirrors OIDC `amr` semantics.
   */
  amr: readonly string[];
  /**
   * Opaque hash binding the proof to the exact operation it authorises.
   * Compared verbatim by guards; never log its source material.
   */
  transactionHash: string;
  /** Epoch milliseconds at which the step-up proof was issued. */
  issuedAt: number;
  /** Epoch milliseconds after which the proof is no longer valid. */
  expiresAt: number;
};

/**
 * Normalised, transport-agnostic description of the authenticated caller.
 *
 * Every authentication mechanism (BFF session, direct HMAC credential,
 * internal service identity, provider webhook) is reduced to this single
 * shape so downstream guards and, eventually, services never branch on
 * how the caller proved who they are.
 *
 * This type is intentionally independent of Cognito, HMAC, JWT, or any
 * BFF wire format. It carries only the claims the Core API authorises on.
 */
export type AuthContext = {
  /** How the request entered the trust boundary. */
  channel: AuthChannel;
  /** What kind of principal the request acts as. */
  principalType: PrincipalType;
  /**
   * Stable identifier of the principal within its `principalType`
   * (e.g. user id, api-client id, service name, provider slug).
   */
  principalId: string;
  /**
   * When a `frontend_bff` request acts on behalf of a human, the end-user
   * id. Absent for pure machine principals.
   */
  actorUserId?: string;
  /**
   * Tenant / client the request is scoped to. Transitional: today routes
   * still read `clientId` from the body; later PRs derive it from here and
   * enforce that the two agree (see ADR).
   */
  clientId?: string;
  /** Coarse-grained capabilities granted to this principal. */
  scopes: readonly AuthScope[];
  /** Optional role labels for coarse RBAC layered on top of scopes. */
  roles?: readonly string[];
  /**
   * Authentication-method references for the session itself (OIDC `amr`
   * semantics, e.g. `['pwd']`, `['pwd','otp']`). Distinct from a per-action
   * {@link StepUpProof}.
   */
  amr?: readonly string[];
  /** Proof of a satisfied step-up challenge, when one was performed. */
  stepUp?: StepUpProof;
  /**
   * Identifier of the credential that authenticated the request (e.g. an
   * HMAC key id). Useful for audit and rotation; never the secret itself.
   */
  credentialId?: string;
  /** Epoch milliseconds the underlying auth artefact was issued. */
  issuedAt?: number;
  /** Epoch milliseconds the underlying auth artefact expires. */
  expiresAt?: number;
};
