export type MetricLabels = Record<string, string | number | boolean | null | undefined>;

export type HistogramBucketSet = readonly number[];

const DEFAULT_DURATION_BUCKETS_SECONDS = [
  0.005,
  0.01,
  0.025,
  0.05,
  0.1,
  0.25,
  0.5,
  1,
  2,
  3,
  5,
  10,
  30
] as const;

const DEFAULT_QUEUE_AGE_BUCKETS_SECONDS = [1, 5, 10, 30, 60, 120, 300, 600, 1_800, 3_600] as const;

type MetricType = 'counter' | 'gauge' | 'histogram';

type MetricDefinition = {
  name: string;
  help: string;
  type: MetricType;
};

type LabelPair = readonly [string, string];

type SampleValue = {
  labels: readonly LabelPair[];
  value: number;
};

type HistogramValue = {
  labels: readonly LabelPair[];
  buckets: number[];
  count: number;
  sum: number;
};

export class MetricsRegistry {
  private readonly definitions = new Map<string, MetricDefinition>();
  private readonly counters = new Map<string, SampleValue>();
  private readonly gauges = new Map<string, SampleValue>();
  private readonly histograms = new Map<string, HistogramValue>();

  increment(name: string, help: string, labels: MetricLabels = {}, value = 1): void {
    this.ensureDefinition(name, help, 'counter');
    const normalizedLabels = normalizeLabels(labels);
    const key = sampleKey(name, normalizedLabels);
    const current = this.counters.get(key)?.value ?? 0;
    this.counters.set(key, { labels: normalizedLabels, value: current + value });
  }

  setGauge(name: string, help: string, labels: MetricLabels = {}, value: number): void {
    this.ensureDefinition(name, help, 'gauge');
    const normalizedLabels = normalizeLabels(labels);
    this.gauges.set(sampleKey(name, normalizedLabels), { labels: normalizedLabels, value });
  }

  observe(
    name: string,
    help: string,
    labels: MetricLabels = {},
    value: number,
    buckets: HistogramBucketSet = DEFAULT_DURATION_BUCKETS_SECONDS
  ): void {
    this.ensureDefinition(name, help, 'histogram');
    const normalizedLabels = normalizeLabels(labels);
    const key = sampleKey(name, normalizedLabels);
    const existing = this.histograms.get(key);
    const bucketValues = existing?.buckets ?? Array.from({ length: buckets.length }, () => 0);

    buckets.forEach((bucket, index) => {
      if (value <= bucket) {
        bucketValues[index] = (bucketValues[index] ?? 0) + 1;
      }
    });

    this.histograms.set(key, {
      labels: normalizedLabels,
      buckets: bucketValues,
      count: (existing?.count ?? 0) + 1,
      sum: (existing?.sum ?? 0) + value
    });
  }

  observeDurationSeconds(
    name: string,
    help: string,
    startedAt: bigint,
    labels: MetricLabels = {},
    buckets: HistogramBucketSet = DEFAULT_DURATION_BUCKETS_SECONDS
  ): number {
    const durationSeconds = Number(process.hrtime.bigint() - startedAt) / 1_000_000_000;
    this.observe(name, help, labels, durationSeconds, buckets);
    return durationSeconds;
  }

  renderPrometheus(): string {
    const lines: string[] = [];
    const names = [...this.definitions.keys()].sort();

    for (const name of names) {
      const definition = this.definitions.get(name);
      if (!definition) continue;
      lines.push(`# HELP ${definition.name} ${escapeHelp(definition.help)}`);
      lines.push(`# TYPE ${definition.name} ${definition.type}`);

      if (definition.type === 'counter') {
        this.renderSamples(lines, definition.name, this.counters);
      } else if (definition.type === 'gauge') {
        this.renderSamples(lines, definition.name, this.gauges);
      } else {
        this.renderHistograms(lines, definition.name);
      }
    }

    return `${lines.join('\n')}\n`;
  }

  private renderSamples(lines: string[], name: string, samples: Map<string, SampleValue>): void {
    for (const [key, sample] of [...samples.entries()].sort(([left], [right]) => left.localeCompare(right))) {
      if (!key.startsWith(`${name}|`)) continue;
      lines.push(`${name}${formatLabels(sample.labels)} ${formatNumber(sample.value)}`);
    }
  }

  private renderHistograms(lines: string[], name: string): void {
    const buckets = DEFAULT_DURATION_BUCKETS_SECONDS;
    for (const [key, histogram] of [...this.histograms.entries()].sort(([left], [right]) =>
      left.localeCompare(right)
    )) {
      if (!key.startsWith(`${name}|`)) continue;

      buckets.forEach((bucket, index) => {
        lines.push(
          `${name}_bucket${formatLabels([...histogram.labels, ['le', String(bucket)]])} ${formatNumber(
            histogram.buckets[index] ?? 0
          )}`
        );
      });
      lines.push(`${name}_bucket${formatLabels([...histogram.labels, ['le', '+Inf']])} ${formatNumber(histogram.count)}`);
      lines.push(`${name}_sum${formatLabels(histogram.labels)} ${formatNumber(histogram.sum)}`);
      lines.push(`${name}_count${formatLabels(histogram.labels)} ${formatNumber(histogram.count)}`);
    }
  }

  private ensureDefinition(name: string, help: string, type: MetricType): void {
    const existing = this.definitions.get(name);
    if (existing) {
      if (existing.type !== type) {
        throw new Error(`Metric ${name} already registered as ${existing.type}, cannot use as ${type}`);
      }
      return;
    }
    this.definitions.set(name, { name, help, type });
  }
}

export const metrics = new MetricsRegistry();

export const durationBucketsSeconds = DEFAULT_DURATION_BUCKETS_SECONDS;
export const queueAgeBucketsSeconds = DEFAULT_QUEUE_AGE_BUCKETS_SECONDS;

export async function recordAsyncDuration<T>(
  name: string,
  help: string,
  labels: MetricLabels,
  fn: () => Promise<T>,
  buckets: HistogramBucketSet = DEFAULT_DURATION_BUCKETS_SECONDS
): Promise<T> {
  const startedAt = process.hrtime.bigint();
  try {
    return await fn();
  } finally {
    metrics.observeDurationSeconds(name, help, startedAt, labels, buckets);
  }
}

export function operationFromEventType(eventType: string | null | undefined): 'cash_in' | 'cash_out' | 'unknown' {
  if (!eventType) return 'unknown';
  if (eventType.startsWith('pix.cash_in.')) return 'cash_in';
  if (eventType.startsWith('pix.cash_out.')) return 'cash_out';
  // Legacy token (pre-0015) — still classified as cash_out for metrics.
  if (eventType.startsWith('cashout.')) return 'cash_out';
  return 'unknown';
}

function normalizeLabels(labels: MetricLabels): readonly LabelPair[] {
  return Object.entries(labels)
    .filter((entry): entry is [string, string | number | boolean] => entry[1] !== undefined && entry[1] !== null)
    .map(([key, value]) => [sanitizeLabelName(key), String(value)] as const)
    .sort(([left], [right]) => left.localeCompare(right));
}

function sampleKey(name: string, labels: readonly LabelPair[]): string {
  return `${name}|${labels.map(([key, value]) => `${key}=${value}`).join(',')}`;
}

function formatLabels(labels: readonly LabelPair[]): string {
  if (labels.length === 0) return '';
  return `{${labels.map(([key, value]) => `${key}="${escapeLabelValue(value)}"`).join(',')}}`;
}

function sanitizeLabelName(name: string): string {
  return name.replace(/[^a-zA-Z0-9_]/g, '_');
}

function escapeLabelValue(value: string): string {
  return value.replace(/\\/g, '\\\\').replace(/\n/g, '\\n').replace(/"/g, '\\"');
}

function escapeHelp(value: string): string {
  return value.replace(/\\/g, '\\\\').replace(/\n/g, '\\n');
}

function formatNumber(value: number): string {
  if (!Number.isFinite(value)) return '0';
  return String(value);
}
