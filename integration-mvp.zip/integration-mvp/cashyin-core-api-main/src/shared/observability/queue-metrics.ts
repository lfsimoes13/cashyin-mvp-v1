import type { Pool } from 'pg';
import { metrics } from './metrics.js';

type WebhookQueueRow = {
  provider_name: string | null;
  operation_type: string | null;
  normalized_status_kind: string | null;
  normalized_status: string | null;
  processing_status: string;
  pending_total: string | number;
  oldest_age_seconds: string | number | null;
};

type OutboxQueueRow = {
  aggregate_type: string;
  event_type: string;
  operation_type: string;
  status: string;
  pending_total: string | number;
  oldest_age_seconds: string | number | null;
};

/**
 * Collects DB-backed gauges at scrape time. The queries intentionally aggregate
 * over indexed queue predicates and avoid high-cardinality labels such as ids,
 * txids, client ids or provider transaction ids.
 */
export async function collectQueueMetrics(pool: Pool): Promise<void> {
  await Promise.all([collectProviderWebhookQueueMetrics(pool), collectOutboxQueueMetrics(pool)]);
}

async function collectProviderWebhookQueueMetrics(pool: Pool): Promise<void> {
  const result = await pool.query<WebhookQueueRow>(
    `SELECT provider_name,
            operation_type,
            normalized_status_kind,
            normalized_status,
            processing_status,
            COUNT(*)::bigint AS pending_total,
            EXTRACT(EPOCH FROM (now() - MIN(received_at))) AS oldest_age_seconds
       FROM webhook_events
      WHERE processing_status IN ('pending', 'failed', 'processing', 'dlq')
      GROUP BY provider_name, operation_type, normalized_status_kind, normalized_status, processing_status`
  );

  for (const row of result.rows) {
    const labels = {
      provider: row.provider_name ?? 'unknown',
      operation_type: row.operation_type ?? row.normalized_status_kind ?? 'unknown',
      normalized_status: row.normalized_status ?? 'unknown',
      processing_status: row.processing_status
    };
    metrics.setGauge(
      'cashyin_provider_webhook_queue_events',
      'Number of provider webhook events grouped by queue status.',
      labels,
      Number(row.pending_total)
    );
    metrics.setGauge(
      'cashyin_provider_webhook_queue_oldest_age_seconds',
      'Age in seconds of the oldest provider webhook event in each queue group.',
      labels,
      Number(row.oldest_age_seconds ?? 0)
    );
  }
}

async function collectOutboxQueueMetrics(pool: Pool): Promise<void> {
  const result = await pool.query<OutboxQueueRow>(
    `SELECT aggregate_type,
            event_type,
            CASE
              WHEN event_type LIKE 'pix.cash_in.%' THEN 'cash_in'
              WHEN event_type LIKE 'cashout.%' THEN 'cash_out'
              ELSE 'unknown'
            END AS operation_type,
            status,
            COUNT(*)::bigint AS pending_total,
            EXTRACT(EPOCH FROM (now() - MIN(created_at))) AS oldest_age_seconds
       FROM outbox_events
      WHERE status IN ('pending', 'failed', 'processing', 'dlq')
      GROUP BY aggregate_type, event_type, operation_type, status`
  );

  for (const row of result.rows) {
    const labels = {
      aggregate_type: row.aggregate_type,
      event_type: row.event_type,
      operation_type: row.operation_type,
      status: row.status
    };
    metrics.setGauge(
      'cashyin_outbox_queue_events',
      'Number of client outbox events grouped by event type and status.',
      labels,
      Number(row.pending_total)
    );
    metrics.setGauge(
      'cashyin_outbox_queue_oldest_age_seconds',
      'Age in seconds of the oldest client outbox event in each queue group.',
      labels,
      Number(row.oldest_age_seconds ?? 0)
    );
  }
}
