import { Pool, type PoolClient, type PoolConfig } from 'pg';
import { env } from '../config/env.js';
import { AppError } from '../errors/app-error.js';

export type DatabaseOptions = {
  connectionString?: string;
  poolConfig?: Omit<PoolConfig, 'connectionString'>;
  /**
   * Invoked when the pg Pool emits an `error` event for an idle client. The
   * default implementation writes a structured record to stderr; callers can
   * inject a logger here once one is available in the composition root.
   */
  onPoolError?: (error: Error) => void;
};

/**
 * Thin wrapper over a single pg connection Pool.
 *
 * Persistence rules:
 * - Repositories accept a `Sql` executor and never own a transaction.
 * - Multi-statement state transitions (charge + outbox + idempotency finalize,
 *   webhook persist + dispatch enqueue, etc.) must run through
 *   {@link Database.withTransaction} so they share a single PoolClient and
 *   commit or roll back atomically.
 * - `pg.Pool` emits `error` for idle backend failures (server restart, network
 *   reset, idle-in-transaction termination). Unhandled, those events crash the
 *   Node process. The constructor wires a default handler so a transient
 *   backend issue does not take the API down with it.
 */
export class Database {
  readonly pool: Pool;
  private readonly onPoolError: (error: Error) => void;
  private closePromise: Promise<void> | undefined;

  constructor(options: DatabaseOptions = {}) {
    const connectionString = options.connectionString ?? env.DATABASE_URL;
    if (!connectionString) {
      throw new AppError(
        'database_url_missing',
        'DATABASE_URL is required to initialise PostgreSQL persistence',
        500
      );
    }

    const poolConfig: PoolConfig = {
      connectionString,
      max: options.poolConfig?.max ?? env.DATABASE_POOL_MAX,
      connectionTimeoutMillis:
        options.poolConfig?.connectionTimeoutMillis ?? env.DATABASE_CONNECTION_TIMEOUT_MS,
      idleTimeoutMillis: options.poolConfig?.idleTimeoutMillis ?? 10_000,
      statement_timeout:
        options.poolConfig?.statement_timeout ?? env.DATABASE_STATEMENT_TIMEOUT_MS,
      ...(options.poolConfig ?? {})
    };

    this.pool = new Pool(poolConfig);
    this.onPoolError = options.onPoolError ?? defaultOnPoolError;
    this.pool.on('error', (error) => this.onPoolError(error));
  }

  /**
   * Runs `fn` inside a `BEGIN`/`COMMIT` block. On any thrown error the
   * transaction is rolled back. If `ROLLBACK` itself fails (typically when
   * the underlying socket is dead), the PoolClient is destroyed rather than
   * returned to the pool, so the next consumer does not inherit an aborted
   * transaction.
   */
  async withTransaction<T>(fn: (tx: PoolClient) => Promise<T>): Promise<T> {
    const client = await this.pool.connect();
    let releaseError: Error | undefined;
    try {
      await client.query('BEGIN');
      try {
        const result = await fn(client);
        await client.query('COMMIT');
        return result;
      } catch (error) {
        try {
          await client.query('ROLLBACK');
        } catch (rollbackError) {
          releaseError =
            rollbackError instanceof Error
              ? rollbackError
              : new Error(String(rollbackError));
        }
        throw error;
      }
    } finally {
      client.release(releaseError);
    }
  }

  async ping(): Promise<void> {
    await this.pool.query('SELECT 1');
  }

  async close(): Promise<void> {
    this.closePromise ??= this.pool.end();
    await this.closePromise;
  }
}

function defaultOnPoolError(error: Error): void {
  const payload = {
    level: 'error',
    code: 'pg_pool_idle_client_error',
    msg: 'PostgreSQL pool emitted an idle-client error',
    error: error.message,
    stack: error.stack
  };
  console.error(JSON.stringify(payload));
}
