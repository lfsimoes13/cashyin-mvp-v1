import type { Pool, PoolClient } from 'pg';

/**
 * Narrow executor type that both pg.Pool and pg.PoolClient satisfy.
 *
 * Repositories accept this type so that the same method can run either standalone
 * against the connection pool or inside an explicit transaction managed by the
 * caller (see {@link Database.withTransaction}).
 */
export type Sql = Pool | PoolClient;
