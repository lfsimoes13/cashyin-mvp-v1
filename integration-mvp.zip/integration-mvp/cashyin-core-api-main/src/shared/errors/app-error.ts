export class AppError extends Error {
  constructor(
    public readonly code: string,
    message: string,
    public readonly statusCode = 500,
    public readonly details?: unknown
  ) {
    super(message);
    this.name = 'AppError';
  }
}

export type HttpError = {
  code: string;
  message: string;
  statusCode: number;
};

export function toHttpError(error: unknown): HttpError {
  if (error instanceof AppError) {
    return { code: error.code, message: error.message, statusCode: error.statusCode };
  }

  if (error instanceof Error) {
    return { code: 'internal_error', message: error.message, statusCode: 500 };
  }

  return { code: 'internal_error', message: 'Unexpected error', statusCode: 500 };
}

export function assertDefined<T>(value: T | null | undefined, code: string, message: string): T {
  if (value === null || value === undefined) {
    throw new AppError(code, message, 500);
  }
  return value;
}

