import { Agent, request, type Dispatcher } from 'undici';

/**
 * Minimal HTTP client abstraction so the rest of the codebase can issue
 * outbound POSTs (e.g. the public webhook dispatcher) without coupling
 * to a specific runtime library, and so unit tests can inject a fake
 * implementation that captures requests and returns scripted responses.
 *
 * The interface is intentionally narrower than `fetch`: we only need
 * synchronous POST-with-string-body and don't expose streaming, cookies,
 * abort signals or redirects yet.
 */

export type HttpRequestInput = {
  url: string;
  headers: Record<string, string>;
  /**
   * The body is pre-serialised by the caller so the wire bytes match
   * exactly what was signed (HMAC over the same string).
   */
  bodyText: string;
  /** Per-request timeout in milliseconds. */
  timeoutMs: number;
};

export type HttpResponse = {
  statusCode: number;
  bodyText: string;
};

export interface HttpClient {
  post(input: HttpRequestInput): Promise<HttpResponse>;
}

/**
 * Tuning for the keep-alive connection pool used by {@link UndiciHttpClient}.
 * Reusing TLS connections across deliveries removes the TCP+TLS handshake from
 * the critical first-attempt path for `pix.cash_in.paid`, which is otherwise a
 * large, variable chunk of the client-facing latency.
 */
export type UndiciHttpClientOptions = {
  /** Idle keep-alive window before a socket is eligible for closing (ms). */
  keepAliveTimeoutMs?: number;
  /** Hard cap on the keep-alive window the server may request (ms). */
  keepAliveMaxTimeoutMs?: number;
  /** Max simultaneous connections per origin. */
  connectionsPerOrigin?: number;
};

const DEFAULT_KEEP_ALIVE_TIMEOUT_MS = 30_000;
const DEFAULT_KEEP_ALIVE_MAX_TIMEOUT_MS = 60_000;
const DEFAULT_CONNECTIONS_PER_ORIGIN = 64;

/**
 * Production HTTP client backed by undici (already a project dep). We
 * use the low-level `request` rather than `fetch` because we want a
 * configurable per-call `headersTimeout`/`bodyTimeout`, and `request`
 * exposes them directly without spinning up an abort-controller dance.
 *
 * A dedicated keep-alive {@link Agent} is used as the dispatcher so outbound
 * webhook connections are pooled and reused per origin instead of being
 * re-established on every POST.
 */
export class UndiciHttpClient implements HttpClient {
  private readonly agent: Dispatcher;

  constructor(options: UndiciHttpClientOptions = {}) {
    this.agent = new Agent({
      keepAliveTimeout: options.keepAliveTimeoutMs ?? DEFAULT_KEEP_ALIVE_TIMEOUT_MS,
      keepAliveMaxTimeout: options.keepAliveMaxTimeoutMs ?? DEFAULT_KEEP_ALIVE_MAX_TIMEOUT_MS,
      connections: options.connectionsPerOrigin ?? DEFAULT_CONNECTIONS_PER_ORIGIN
    });
  }

  async post(input: HttpRequestInput): Promise<HttpResponse> {
    const { statusCode, body } = await request(input.url, {
      method: 'POST',
      headers: input.headers,
      body: input.bodyText,
      headersTimeout: input.timeoutMs,
      bodyTimeout: input.timeoutMs,
      dispatcher: this.agent
    });
    const bodyText = await body.text();
    return { statusCode, bodyText };
  }

  /** Closes the underlying connection pool. Call on graceful worker shutdown. */
  async close(): Promise<void> {
    await this.agent.close();
  }
}
