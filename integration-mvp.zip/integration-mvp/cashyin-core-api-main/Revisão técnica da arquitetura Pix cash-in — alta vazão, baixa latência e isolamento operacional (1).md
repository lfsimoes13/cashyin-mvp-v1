# Revisão técnica da arquitetura Pix cash-in — alta vazão, baixa latência e isolamento operacional

**Autor:** Manus AI  
**Repositório analisado:** `area-bank/cashyin-core-api`  
**Branch:** `main`  
**Commit revisado:** `0c0eba297ab8f455ae9131348ee23ec6d473e33c`  
**Data da análise:** 29 de maio de 2026

## Sumário executivo

A arquitetura atual possui uma base boa para consistência financeira: há autenticação por cliente, idempotência obrigatória no endpoint de criação de QR Code, persistência transacional, ingestão rápida de webhooks do provedor, processamento assíncrono de eventos e outbox para entrega de webhooks aos clientes. O fluxo de webhook também está corretamente desenhado para responder `200 OK` ao provedor após persistir o evento, sem executar a lógica de domínio dentro da requisição HTTP de entrada.[^webhook-route]

O principal risco para o cenário descrito — **quantidade muito alta de requests por segundo e tempo de resposta muito rápido em `POST /v1/pix/cash-in/qrcode`** — está no fato de que a geração de QR Code ainda depende de uma **chamada síncrona ao provedor externo** antes da transação local que insere a cobrança e finaliza a idempotência.[^payment-create] Isso significa que a latência e a disponibilidade do endpoint crítico são dominadas pelo provedor Bents e pela rede, não apenas pela API CashYin. Como o próprio cliente Bents documenta no código que o provedor não honra idempotência server-side em `POST /pix/charge`, a aplicação precisa manter locks locais em situações ambíguas para evitar duplicidade, o que é correto para segurança, mas reduz a elasticidade do caminho crítico sob falhas ou timeouts.[^bents-client]

No processamento de status pago, o desenho já separa a entrada do webhook do processamento de domínio e da entrega ao cliente, o que é positivo. Entretanto, **cash-in e cash-out ainda competem dentro da mesma fila de eventos de provedor (`webhook_events`) e no mesmo worker `provider-webhook-worker`**, com claim FIFO global por `received_at` e apenas um item por chamada de `processNext()`.[^webhook-claim] Na infraestrutura baseline, esse worker tem `desired_count = 1`, e o dispatcher de webhooks ao cliente também tem `desired_count = 1`, ambos com 256 CPU e 512 MiB.[^infra-vars] Assim, um backlog de cash-out, eventos com retry ou clientes lentos pode aumentar a latência percebida de notificação de pagamento pago.

A recomendação central é tratar **cash-in pago** como trilha prioritária e isolada. Isso envolve separar filas ou particionar claims por tipo de operação/evento, escalar workers independentemente, criar prioridade para `pix.cash_in.paid`, reduzir o trabalho transacional no processamento de pagamento confirmado e proteger o endpoint de QR Code com orçamentos de timeout, pool sizing, circuit breaker, observabilidade de percentis e, idealmente, uma estratégia multi-provider com provedores que aceitem idempotência/txid do cliente.

## Validação executada

Além da leitura arquitetural do código, executei validação local de consistência. As dependências foram instaladas com `pnpm install`, a suíte de testes foi executada com `pnpm test`, e o build TypeScript foi executado com `pnpm build`. O resultado local foi **659 testes passando em 36 arquivos de teste** e build TypeScript concluído sem erro.

| Item validado | Resultado | Interpretação |
|---|---:|---|
| Testes unitários e de componentes | 659 testes passaram | O comportamento coberto pela suíte atual está consistente com a implementação. |
| Build TypeScript | Sucesso | Não há erro estático evidente no estado revisado. |
| Migrações | Ordenadas lexicograficamente por arquivo | A ordem é previsível; migrations com prefixos duplicados exigem disciplina operacional para evitar ambiguidade futura. |
| Infra baseline | API com 2 tasks; workers com 1 task cada | Adequado para baseline, não para alta vazão sem tuning e autoscaling. |

## Arquitetura observada

A aplicação HTTP usa Fastify, registra `helmet`, `cors` e rate limit global configurado por `RATE_LIMIT_MAX` e `RATE_LIMIT_WINDOW`.[^create-app] O endpoint `POST /v1/pix/cash-in/qrcode` exige autenticação de cliente, valida o payload, exige o header `Idempotency-Key` e delega a criação da cobrança ao `PaymentService.createPixCharge`.[^payment-route]

O banco é PostgreSQL via `pg.Pool`, com `DATABASE_POOL_MAX` default de 10, `statement_timeout` default de 10 segundos e `connectionTimeoutMillis` default de 2 segundos.[^database] O valor default de rate limit é `600` por `1 minute`, o que equivale a aproximadamente **10 requisições por segundo por instância/processo ou por configuração efetiva do plugin**, dependendo de como o rate limit for persistido/compartilhado no deploy.[^env]

O fluxo assíncrono de status é composto por duas etapas principais. A primeira etapa recebe webhooks do provedor, verifica/normaliza e persiste em `webhook_events`, respondendo `200 OK` quando o evento foi persistido ou identificado como duplicado.[^webhook-route] A segunda etapa é executada pelo `provider-webhook-worker`, que drena `webhook_events` e chama `PaymentService` para cash-in ou `CashoutService` para cash-out.[^webhook-processor] Depois, o domínio grava eventos em `outbox_events`, e o `webhook-dispatcher-worker` envia webhooks assinados aos clientes.[^dispatcher]

| Componente | Responsabilidade atual | Avaliação para alta vazão |
|---|---|---|
| API HTTP | Recebe criação de QR Code e consultas | Precisa de rate limit e pool dimensionados por cliente/tenant e por rota, não apenas global. |
| `PaymentService.createPixCharge` | Idempotência, escolha de provedor, chamada externa, pricing e persistência | Caminho crítico é síncrono e dependente do provedor; é o maior gargalo de latência. |
| Bents provider | Criação de cobrança Pix via HTTP | Não há idempotência server-side no contrato implementado; falhas ambíguas seguram locks locais. |
| `webhook_events` | Fila persistente de webhooks do provedor | Mistura cash-in e cash-out com FIFO global; falta prioridade para `paid`. |
| `provider-webhook-worker` | Processa cash-in e cash-out do provedor | Precisa ser particionado por operação/prioridade para evitar interferência entre fluxos. |
| `outbox_events` | Fila de webhooks públicos ao cliente | Também mistura eventos; precisa de prioridade e isolamento para `pix.cash_in.paid`. |
| `webhook-dispatcher-worker` | POST assinado ao cliente | Um endpoint lento pode consumir tempo de worker; precisa de concorrência controlada por cliente e prioridade. |

## Fluxo crítico: `POST /v1/pix/cash-in/qrcode`

O caminho síncrono do QR Code executa as etapas seguintes: calcula hash da requisição, adquire lock de idempotência por cliente/chave/operação, resolve o provider ativo de cash-in, gera `txid`, chama `provider.createPixCharge`, calcula assessment de pricing fora da transação, abre transação no banco, insere `pix_charge`, persiste assessment estimado quando aplicável e finaliza a resposta cacheada na tabela de idempotência.[^payment-create]

> **Diagnóstico:** o endpoint só consegue responder depois que o provedor externo respondeu. Portanto, se o provedor tiver latência P95/P99 alta, throttling ou instabilidade, o endpoint da CashYin herdará esse comportamento. A API local pode ser otimizada, mas não conseguirá garantir tempo muito baixo de resposta enquanto a geração de QR depender de uma chamada externa síncrona.

| Ponto do caminho | Custo esperado | Risco sob alta vazão | Recomendação |
|---|---:|---|---|
| Autenticação e validação | Baixo | Pouco relevante isoladamente | Manter, mas medir latência por middleware. |
| Idempotência local | Médio | Contenção por chave e crescimento da tabela | Índices, TTL/reaper e métricas de lock wait por cliente. |
| Chamada ao provedor | Alto e variável | Principal fonte de latência e falhas ambíguas | Timeout agressivo, circuit breaker, bulkhead por provider e estratégia multi-provider. |
| Pricing assessment | Médio | Leituras extras antes de persistir cobrança | Avaliar simplificação no fast path e materialização de regras em cache. |
| Transação de insert/finalize | Médio | Pool de DB pode saturar | Pool sizing por serviço, PgBouncer/RDS Proxy e redução de roundtrips. |
| Resposta com QR | Depende do provedor | Não é cacheável por ser cobrança única | Considerar provedores com SLA e idempotência nativa. |

### Gargalo primário: chamada externa síncrona

O cliente Bents usa `REQUEST_TIMEOUT_MS`, default de 5 segundos, como `bodyTimeout` e `headersTimeout`.[^bents-client] Esse é um limite alto para uma API que pretende responder QR Code com latência muito baixa. Em alta vazão, uma pequena degradação do provedor pode manter muitas requisições presas aguardando socket/timeout, consumindo conexões do Node, pool, CPU e memória. Como não há idempotência server-side no provedor Bents para criação de cobrança, o código evita liberar o lock quando o estado da chamada pode ter sido ambíguo, o que preserva segurança financeira, mas cria dependência de conciliação para recuperar casos incertos.[^payment-create]

A melhoria recomendada é definir um **orçamento de latência por rota**, por exemplo P95 abaixo de 300–500 ms quando o provedor estiver saudável, e timeout externo bem menor que o timeout global, como 800–1500 ms para o fast path, com circuito aberto quando a taxa de timeout ultrapassar limite. Se o negócio exige QR Code imediato, não há como retirar totalmente a chamada externa, mas é possível reduzir dano com bulkheads por provider, conexão keep-alive explícita, limite de concorrência por provider/cliente e fallback para outro provedor ativo.

### Gargalo secundário: pool e roundtrips de banco

O default de `DATABASE_POOL_MAX = 10` é conservador.[^env] Em alta vazão, a API, os workers e o dispatcher devem ter pools separados e dimensionados conforme o número de tasks, CPUs, limite do banco e volume esperado. Um erro comum é aumentar horizontalmente tasks sem recalcular o número total de conexões ao banco. Por exemplo, 20 tasks com pool 20 significam até 400 conexões, antes de considerar workers e migrações.

A recomendação é dimensionar por serviço. A API de QR Code deve ter pool suficiente para seu fast path, mas os workers de webhook e dispatcher devem ter pools próprios, menores e isolados. Para produção de alta vazão, recomendo usar PgBouncer ou RDS Proxy, métricas de fila do pool (`waitingCount`, `idleCount`, `totalCount`) e alertas quando o tempo de aquisição de conexão ultrapassar poucos milissegundos.

## Processamento de pagamento pago e webhooks ao cliente

Quando um evento de pagamento pago é processado, o worker localiza a cobrança, verifica se ainda está `pending`, abre uma transação, marca a cobrança como paga, resolve/promove assessment, posta ledger quando disponível, enfileira o evento `pix.cash_in.paid` no outbox e depois emite observabilidade.[^payment-paid] Esse desenho garante atomicidade entre estado financeiro e intenção de publicação do webhook, o que é correto.

O problema de performance é que o processamento do evento `paid` executa várias operações dentro da mesma transação. Em cenários de pico, qualquer custo adicional de pricing/ledger/outbox alonga a duração da transação e aumenta concorrência sobre o banco. Como o objetivo do usuário é notificar pagamento pago rapidamente, a etapa crítica deveria ser reduzida ao mínimo: **marcar pago, registrar evento prioritário e liberar a transação**. Operações não essenciais para a notificação imediata, como enriquecimentos, liquidações contábeis complexas ou cálculos complementares, podem ir para uma segunda fila interna, desde que não comprometam saldo correto e consistência financeira.

| Etapa após webhook pago | Estado atual | Risco | Ajuste sugerido |
|---|---|---|---|
| Claim do evento | FIFO global em `webhook_events` | Cash-out pode atrasar cash-in | Separar fila/claim de `cash_in.paid` ou priorizar por tipo. |
| `markPaid` | Dentro de transação | Necessário | Manter otimista e indexado. |
| Pricing/assessment | Dentro do fluxo de pago | Pode alongar transação | Usar dados pré-computados ou mover parte para pós-processamento. |
| Ledger | Dentro do fluxo de pago | Necessário se saldo depende disso | Manter somente lançamento mínimo indispensável; adiar reconciliações. |
| Outbox `pix.cash_in.paid` | Dentro da mesma transação | Correto para confiabilidade | Marcar evento com prioridade alta. |
| Dispatcher HTTP ao cliente | Serial por item no worker | Clientes lentos atrasam fila | Concorrência controlada, timeout menor e isolamento por cliente/prioridade. |

## Conflito entre cash-in e cash-out

A separação de processos existe parcialmente: API, `provider-webhook-worker` e `webhook-dispatcher-worker` são serviços ECS separados.[^workers-tf] Porém, dentro do `provider-webhook-worker`, o mesmo processador trata `cash_in` e `cash_out`.[^webhook-processor] O SQL de claim escolhe um único evento elegível em `webhook_events`, ordenado por `received_at ASC`, sem filtro por operação, prioridade ou tipo de evento.[^webhook-claim]

> **Conclusão:** o sistema ainda permite interferência operacional entre cash-in e cash-out. Se houver alto volume de cash-out, retries de cash-out, ou eventos antigos elegíveis antes de eventos `paid`, o worker pode gastar ciclos com itens menos críticos enquanto pagamentos pagos aguardam na fila.

O mesmo padrão se repete no outbox: o dispatcher suporta `pix_charge` e `cashout`, constrói envelopes para ambos e faz POST ao endpoint do cliente com timeout default de 10 segundos.[^dispatcher] Embora falhas sejam reagendadas, cada tentativa consome tempo do worker. Um cliente com endpoint lento ou instável não deve atrasar notificações `pix.cash_in.paid` de outros clientes ou do mesmo cliente em fluxo crítico.

| Risco de interferência | Evidência | Impacto prático | Prioridade |
|---|---|---|---:|
| Cash-in e cash-out na mesma fila de provedor | `claimNextPending` sem filtro por operação | Backlog de cash-out aumenta latência de `paid` | P0 |
| Um worker baseline para eventos de provedor | `provider_webhook_worker_desired_count = 1` | Capacidade baixa e sem isolamento | P0 |
| Dispatcher único para cash-in/cash-out | Dispatcher suporta ambos os agregados | Webhooks menos críticos competem com `pix.cash_in.paid` | P1 |
| Timeout de webhook ao cliente de 10 s | `requestTimeoutMs = 10_000` | Endpoint lento ocupa worker | P1 |
| Sem autoscaling explícito no baseline | Desired count fixo | Operação manual em pico | P1 |

## Recomendações priorizadas

### P0 — Separar o caminho crítico de cash-in pago

A primeira mudança recomendada é criar isolamento real para eventos críticos de cash-in. Existem duas formas boas de fazer isso. A opção mais simples é manter a tabela `webhook_events`, mas alterar o claim para aceitar filtros de `operation_type`, `normalized_status_kind` e `normalized_status`, criando workers distintos: `cashin-paid-worker`, `cashin-terminal-worker` e `cashout-worker`. A opção mais robusta é separar fisicamente as filas/tabelas, por exemplo `cashin_webhook_events` e `cashout_webhook_events`, ou usar uma fila externa como SQS/Kafka com tópicos separados.

| Worker proposto | Eventos | SLA | Observação |
|---|---|---:|---|
| `cashin-paid-worker` | `operation_type='cash_in'` e `normalized_status='paid'` | Mais crítico | Deve escalar primeiro e nunca disputar com cash-out. |
| `cashin-terminal-worker` | Expirado, cancelado, falhou, refund | Médio | Importante, mas menos urgente que pago. |
| `cashout-worker` | Status de cash-out | Médio/baixo | Pode ter fila e backoff sem afetar cash-in. |
| `webhook-dispatcher-cashin-paid` | `pix.cash_in.paid` | Mais crítico | Deve ter timeout e retry próprios. |
| `webhook-dispatcher-default` | Demais eventos | Normal | Pode absorver backlog sem prejudicar pago. |

Essa mudança endereça diretamente a preocupação do usuário: **cash-in não deve conflitar com cash-out**. Mesmo que cash-out esteja lento, com filas ou sob erro do provedor, o caminho de pagamento recebido continua drenando em workers dedicados.

### P0 — Priorizar `pix.cash_in.paid` no outbox

O outbox deveria possuir prioridade explícita, como `priority`, `operation_type`, `event_type` e talvez `client_id` no índice de claim. O claim do dispatcher deve preferir `pix.cash_in.paid` antes de qualquer outro evento. Em Postgres, isso pode ser feito inicialmente com uma coluna `priority SMALLINT NOT NULL DEFAULT 100` e índice parcial para eventos pendentes. Para `pix.cash_in.paid`, a prioridade poderia ser `10`; para terminal cash-in, `30`; para cash-out, `60`; para eventos informativos, `100`.

A entrega ao cliente também precisa de isolamento por endpoint/cliente. Recomendo limitar concorrência por cliente para evitar que um único cliente com endpoint lento consuma toda a capacidade, mantendo concorrência global alta para clientes saudáveis. Além disso, o timeout default de 10 segundos é alto para uma trilha que pretende notificar rápido; eu recomendaria um timeout inicial entre 1 e 3 segundos para eventos críticos, com retry assíncrono e DLQ.

### P0 — Definir orçamento de latência do endpoint de QR Code

O endpoint `POST /v1/pix/cash-in/qrcode` deve ter metas explícitas de SLO: P50, P95 e P99. Recomendo medir separadamente: tempo de autenticação, tempo de lock de idempotência, tempo de provider assignment, tempo de chamada ao provedor, tempo de pricing, tempo de transação de banco e tempo total da rota.

| Métrica | Meta inicial sugerida | Por quê |
|---|---:|---|
| Latência total P95 do QR Code | 300–500 ms em provedor saudável | Mantém experiência rápida em checkout. |
| Latência total P99 do QR Code | < 1.000–1.500 ms | Evita acúmulo de sockets sob pico. |
| Timeout de provedor no fast path | 800–1.500 ms | Falhar rápido é melhor que saturar recursos. |
| Tempo de aquisição de conexão DB P95 | < 10 ms | Indica pool saudável. |
| Tempo de transação DB P95 | < 50 ms | Evita contenção e locks longos. |
| Taxa de locks de idempotência stale | Próxima de zero | Indica falhas ambíguas no provedor. |

### P0 — Multi-provider ativo para cash-in

Como o provedor Bents não oferece idempotência server-side no contrato usado, o cash-in de alto volume ficaria mais resiliente com roteamento multi-provider. O sistema já possui conceito de provider assignment, o que é um bom ponto de partida. A recomendação é evoluir para roteamento com health score por provider, limites de concorrência por provider, failover por cliente e capacidade de migrar clientes sem impacto operacional.

A regra prática é não enviar retry automático de criação de cobrança para o mesmo provedor quando o resultado for ambíguo. Em vez disso, o lock local deve preservar segurança, e um reconciliador deve consultar o provedor. Para novos provedores, priorize contratos que aceitem `txid` e idempotency key do lado do provedor, pois isso reduz drasticamente o risco de duplicidade e o custo operacional em timeouts.

### P1 — Ajustar infraestrutura baseline para produção de alta vazão

A infraestrutura baseline tem `api_desired_count = 2`, `provider_webhook_worker_desired_count = 1` e `webhook_dispatcher_worker_desired_count = 1`.[^infra-vars] Isso é compatível com ambiente inicial, mas insuficiente para alta vazão. O mínimo recomendado é dimensionar API e workers separadamente, com autoscaling por métricas de fila e latência.

| Serviço | Métrica de escala | Ação recomendada |
|---|---|---|
| API QR Code | RPS, CPU, event loop lag, latência P95/P99 | Autoscaling horizontal e pool calculado. |
| Cash-in paid worker | Idade do evento mais antigo, eventos pendentes, claim latency | Escalar agressivamente; prioridade máxima. |
| Cash-out worker | Backlog e idade do evento | Escalar moderadamente; pode tolerar fila. |
| Dispatcher cash-in paid | Idade do outbox `pix.cash_in.paid` | Escalar e isolar por endpoint/cliente. |
| Dispatcher default | Backlog geral | Escalar conforme capacidade de clientes. |

Há também uma divergência importante de defaults: o código define `WORKER_IDLE_INTERVAL_MS = 200` e `WORKER_MAX_IDLE_INTERVAL_MS = 5.000`, mas o Terraform baseline ainda injeta `1.000` e `30.000`.[^env] [^infra-vars] Se o LISTEN/NOTIFY falhar ou estiver desabilitado, o polling fallback em produção pode ser mais lento do que o esperado pelo código. Recomendo alinhar Terraform aos defaults mais rápidos ou, preferencialmente, depender de notify com alerta quando o watcher cair.

### P1 — Reduzir trabalho transacional no pagamento pago

O método `handleChargePaid` faz `markPaid`, assessment/pricing, ledger e enqueue de outbox dentro da transação.[^payment-paid] Isso é correto para consistência, mas deve ser medido. Se o lançamento de ledger for indispensável para disponibilizar saldo, ele deve permanecer no caminho crítico, mas otimizado para poucas escritas, índices corretos e idempotência barata. Qualquer enriquecimento que não seja necessário para saldo e notificação imediata deve ir para processamento posterior.

Uma abordagem prática é criar dois eventos internos: `cash_in_paid_core_committed`, emitido imediatamente após marcar pago e creditar saldo mínimo, e `cash_in_paid_enrichment_requested`, usado para cálculos complementares, conciliação ou relatórios. O webhook público `pix.cash_in.paid` deve depender apenas do core financeiro correto, não de rotinas analíticas ou relatórios.

### P1 — Melhorar rate limit por rota e tenant

O rate limit global default de `600` por minuto é baixo para o cenário de alta vazão e, ao mesmo tempo, pouco seletivo.[^env] Para produção, recomendo rate limit por `client_id`, por rota, por provider e por operação. Um cliente com tráfego excessivo ou comportamento anômalo não deve derrubar a capacidade dos demais. O endpoint de QR Code deve ter limites diferentes de consultas e endpoints internos.

O Redis já aparece como dependência opcional no ambiente, mas a configuração atual do rate limit global precisa ser revisada para garantir consistência multi-instância. Se o rate limit for em memória por task, a capacidade efetiva muda com o número de réplicas e pode ficar imprevisível. Para controle real em múltiplas tasks, use Redis ou camada de gateway/WAF com política por tenant.

### P2 — Observabilidade e teste de carga

Antes de mudanças maiores, recomendo instrumentar métricas de alto valor. O código já expõe `claimLatencyMs` nos workers, o que é positivo.[^webhook-processor] A prioridade agora é transformar isso em dashboards e alertas por tipo de operação, cliente e evento.

| Métrica | Dimensões mínimas | Alerta sugerido |
|---|---|---|
| `qrcode_request_duration_ms` | cliente, provider, status | P95/P99 acima do SLO por 5 min. |
| `provider_create_charge_duration_ms` | provider, status, categoria de erro | Aumento de timeout ou erro ambíguo. |
| `idempotency_acquire_duration_ms` | cliente, operação | Contenção ou lock wait elevado. |
| `webhook_event_oldest_age_seconds` | operação, status normalizado | Pago aguardando mais que poucos segundos. |
| `outbox_oldest_age_seconds` | event_type, cliente | `pix.cash_in.paid` atrasado. |
| `client_webhook_delivery_duration_ms` | cliente, endpoint, event_type | Endpoint lento consumindo worker. |
| `db_pool_wait_ms` | serviço | Saturação de pool. |
| `event_loop_lag_ms` | serviço | CPU/GC bloqueando Node. |

O teste de carga deve simular não apenas RPS no endpoint de QR Code, mas também webhooks simultâneos, endpoints de cliente lentos, timeouts do provedor, bursts de cash-out e replays de idempotência. Sem esses cenários, o sistema pode parecer saudável em teste de rota isolada e falhar em produção quando os fluxos assíncronos competirem.

## Plano de evolução sugerido

| Horizonte | Mudança | Resultado esperado |
|---|---|---|
| 0–7 dias | Dashboards por rota, provider, worker e fila; alinhar Terraform aos defaults rápidos; reduzir timeout de webhook ao cliente crítico | Visibilidade e redução de atrasos óbvios. |
| 1–2 semanas | Criar worker separado para `cash_in.paid` com claim filtrado; aumentar réplicas; priorizar outbox `pix.cash_in.paid` | Cash-in pago deixa de competir com cash-out. |
| 2–4 semanas | Rate limit por tenant/rota/provider; pool sizing por serviço; PgBouncer/RDS Proxy; circuit breaker do provedor | Maior estabilidade em pico e falha parcial. |
| 1–2 meses | Multi-provider ativo para cash-in; health-based routing; contrato de provider com idempotência nativa | Menor dependência de um único provedor e melhor recuperação de incidentes. |
| Contínuo | Teste de carga com caos: provedor lento, cliente lento, cash-out em backlog e webhook replay | Confiança operacional antes de escalar volume real. |

## Conclusão

A implementação atual é sólida em consistência e possui bons fundamentos de idempotência, transações e outbox. Porém, para o cenário de **altíssimo RPS com resposta muito rápida de QR Code** e **notificação quase imediata de pagamento pago**, ela ainda precisa de ajustes arquiteturais importantes.

O primeiro limite é externo: a criação do QR Code depende de uma chamada síncrona ao provedor, e o provedor atual não oferece idempotência server-side no contrato implementado. O segundo limite é interno: cash-in e cash-out compartilham filas/workers nos pontos críticos de processamento de webhook e outbox. O terceiro limite é operacional: a infraestrutura baseline usa poucos workers, sem autoscaling explícito e com defaults de polling mais lentos no Terraform do que no código.

Minha recomendação objetiva é priorizar três frentes: **isolar cash-in pago de cash-out**, **reduzir e proteger o caminho síncrono de QR Code**, e **escalar workers por prioridade de evento em vez de por fila única global**. Com essas mudanças, o sistema ficará mais preparado para alto volume sem permitir que cash-out, endpoints lentos de clientes ou falhas ambíguas de provedor prejudiquem o fluxo mais crítico: recebimento Pix confirmado e notificação rápida ao cliente.

## Referências

[^payment-route]: [`src/modules/payments/payment.routes.ts`, linhas 21–44 — endpoint `POST /v1/pix/cash-in/qrcode`](https://github.com/area-bank/cashyin-core-api/blob/0c0eba297ab8f455ae9131348ee23ec6d473e33c/src/modules/payments/payment.routes.ts#L21-L44).
[^payment-create]: [`src/modules/payments/payment.service.ts`, linhas 232–354 — fluxo de criação de cobrança Pix](https://github.com/area-bank/cashyin-core-api/blob/0c0eba297ab8f455ae9131348ee23ec6d473e33c/src/modules/payments/payment.service.ts#L232-L354).
[^payment-paid]: [`src/modules/payments/payment.service.ts`, linhas 396–539 — processamento de pagamento pago e enqueue de outbox](https://github.com/area-bank/cashyin-core-api/blob/0c0eba297ab8f455ae9131348ee23ec6d473e33c/src/modules/payments/payment.service.ts#L396-L539).
[^bents-client]: [`src/providers/bents/bents.client.ts`, linhas 10–18 e 25–94 — cliente HTTP Bents, timeout e ausência de idempotência server-side](https://github.com/area-bank/cashyin-core-api/blob/0c0eba297ab8f455ae9131348ee23ec6d473e33c/src/providers/bents/bents.client.ts#L10-L94).
[^webhook-route]: [`src/modules/webhooks/webhook.routes.ts`, linhas 14–43 e 69–117 — ingestão rápida e resposta `200 OK`](https://github.com/area-bank/cashyin-core-api/blob/0c0eba297ab8f455ae9131348ee23ec6d473e33c/src/modules/webhooks/webhook.routes.ts#L14-L117).
[^webhook-processor]: [`src/modules/webhooks/webhook-event.processor.ts`, linhas 206–234 e 270–336 — processamento assíncrono e roteamento cash-in/cash-out](https://github.com/area-bank/cashyin-core-api/blob/0c0eba297ab8f455ae9131348ee23ec6d473e33c/src/modules/webhooks/webhook-event.processor.ts#L206-L336).
[^webhook-claim]: [`src/modules/webhooks/webhook-event.repository.ts`, linhas 314–337 — claim FIFO global em `webhook_events`](https://github.com/area-bank/cashyin-core-api/blob/0c0eba297ab8f455ae9131348ee23ec6d473e33c/src/modules/webhooks/webhook-event.repository.ts#L314-L337).
[^dispatcher]: [`src/modules/webhooks/client-webhook.dispatcher.ts`, linhas 42–48, 132–205 e 301–311 — dispatcher, timeout e execução por item](https://github.com/area-bank/cashyin-core-api/blob/0c0eba297ab8f455ae9131348ee23ec6d473e33c/src/modules/webhooks/client-webhook.dispatcher.ts#L42-L311).
[^create-app]: [`src/app/create-app.ts`, linhas 18–66 — criação da aplicação e rate limit global](https://github.com/area-bank/cashyin-core-api/blob/0c0eba297ab8f455ae9131348ee23ec6d473e33c/src/app/create-app.ts#L18-L66).
[^env]: [`src/shared/config/env.ts`, linhas 4–116 — defaults de pool, timeout, rate limit e workers](https://github.com/area-bank/cashyin-core-api/blob/0c0eba297ab8f455ae9131348ee23ec6d473e33c/src/shared/config/env.ts#L4-L116).
[^database]: [`src/shared/db/database.ts`, linhas 45–58 e 68–90 — configuração de pool e transações](https://github.com/area-bank/cashyin-core-api/blob/0c0eba297ab8f455ae9131348ee23ec6d473e33c/src/shared/db/database.ts#L45-L90).
[^infra-vars]: [`infra/terraform/environments/prod-baseline/variables.tf`, linhas 161–264 — capacidade baseline de API e workers](https://github.com/area-bank/cashyin-core-api/blob/0c0eba297ab8f455ae9131348ee23ec6d473e33c/infra/terraform/environments/prod-baseline/variables.tf#L161-L264).
[^workers-tf]: [`infra/terraform/modules/ecs/workers.tf`, linhas 2–70 — topologia ECS dos workers](https://github.com/area-bank/cashyin-core-api/blob/0c0eba297ab8f455ae9131348ee23ec6d473e33c/infra/terraform/modules/ecs/workers.tf#L2-L70).
