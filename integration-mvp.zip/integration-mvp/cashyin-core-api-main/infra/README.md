# CashYin Core API — Infrastructure

Terraform code for the CashYin Core API AWS environment. The full rollout
plan lives in [`docs/aws-deploy-plan.md`](../docs/aws-deploy-plan.md); this
README only covers how to operate what is in this PR (**foundation**:
networking, ECR, GitHub OIDC).

## Layout

```
infra/
├── README.md                 ← you are here
└── terraform/
    ├── environments/
    │   └── prod-baseline/    ← composes modules below; the one you `apply`
    └── modules/
        ├── network/          ← VPC, subnets, NAT, SGs
        ├── ecr/              ← container registry + lifecycle policy
        ├── github-oidc/      ← OIDC trust + deploy IAM role
        ├── rds/              ← Postgres 16 + DATABASE_URL secret
        ├── secrets/          ← Empty secrets for Bents credentials
        ├── cloudwatch-logs/  ← Log group for ECS containers
        ├── alb/              ← Public ALB + target group + HTTP listener
        └── ecs/              ← Fargate cluster + roles + task defs + service
```

Each leaf directory has its own `versions.tf`, `variables.tf`, `main.tf`
and `outputs.tf` so CI can run `terraform init/validate` against any of
them in isolation.

## Prerequisites (one-time per AWS account)

You need:

- Terraform `>= 1.10.0` on `PATH`.
- The AWS CLI configured with a principal that can create S3 buckets,
  DynamoDB tables, IAM roles, OIDC providers and VPC resources (for the
  bootstrap step this realistically means `AdministratorAccess`; we tighten
  later).
- Your AWS account ID (`aws sts get-caller-identity --query Account --output text`).
- The GitHub repository in `owner/repo` form (e.g. `area-bank/cashyin-core-api`).

### 1. Bootstrap the Terraform backend

Terraform cannot manage the state bucket that stores its own state, so we
provision it once with a shell script. The script is idempotent — re-running
it after success is a no-op.

```bash
AWS_PROFILE=<your-admin-profile> AWS_REGION=sa-east-1 bash scripts/aws-bootstrap.sh
```

The script creates two resources in `sa-east-1`:

- `cashyin-terraform-state-sa-east-1` — S3 bucket (versioned, encrypted,
  public access blocked, enforces TLS).
- `cashyin-terraform-locks` — DynamoDB table for state locking (PAY_PER_REQUEST).

Override the names by exporting `TF_STATE_BUCKET` and `TF_LOCK_TABLE`
before running, if your org already standardised on different names.

### 2. Configure the environment

```bash
cd infra/terraform/environments/prod-baseline
cp terraform.tfvars.example terraform.tfvars
# edit terraform.tfvars: at minimum, fill in `github_repository`.
```

`terraform.tfvars` is git-ignored. The example file documents every
variable, including the rare case where this AWS account already trusts
the GitHub OIDC provider (set `github_oidc_create_provider = false` and
provide the existing ARN).

### 3. Initialise Terraform against the remote backend

```bash
AWS_PROFILE=<your-admin-profile> terraform init \
  -backend-config="bucket=cashyin-terraform-state-sa-east-1" \
  -backend-config="region=sa-east-1" \
  -backend-config="dynamodb_table=cashyin-terraform-locks"
```

### 4. Plan and apply the foundation

```bash
AWS_PROFILE=<your-admin-profile> terraform plan -out=plan.tfplan
AWS_PROFILE=<your-admin-profile> terraform apply plan.tfplan
```

Expected resources created on first apply (PR #1 + PR #2 + PR #3):

- **PR #1 — foundation**: 1× VPC, 1× IGW, 1× NAT, 2× public subnets, 2× private
  subnets, 2× route tables, 3× security groups; 1× ECR repository + lifecycle
  policy; 1× IAM OIDC provider (if not already present), 1× IAM role,
  1× inline ECR policy.
- **PR #2 — RDS + Secrets**: 1× DB subnet group, 1× DB parameter group,
  1× RDS instance (Postgres 16, db.t4g.micro), 1× Secrets Manager secret
  for the assembled DATABASE_URL, 2× empty Secrets Manager secrets for
  Bents credentials.
- **PR #3 — ECS + ALB**: 1× CloudWatch log group, 1× ALB + target group +
  HTTP listener, 1× ECS cluster (FARGATE + FARGATE_SPOT capacity providers),
  1× execution role + 1× task role + IAM policies, 2× task definitions
  (`-api` long-running + `-migrate` one-shot), 1× ECS service. The GHA
  deploy role is extended with ECS deploy + `iam:PassRole` + log tailing.

The plan output names every resource explicitly; read it before applying.
The RDS instance creation takes ~7-10 minutes; the rest of the apply is
~30 seconds.

### 5. Verify

```bash
terraform output
```

You should see `ecr_repository_url`, `github_actions_role_arn`, the VPC
and subnet IDs, plus (after PR #2) `rds_endpoint`,
`database_url_secret_name` and `bents_secret_names`.

### 6. Populate the Bents secrets (post-apply)

The Bents secrets are created **empty** by Terraform on purpose — the
credentials never travel through state. Write them once via the AWS CLI:

```bash
# Production Bents API key (same one currently in .env)
aws secretsmanager put-secret-value \
  --secret-id cashyin/prod-baseline/bents-api-key \
  --secret-string "$BENTS_API_KEY"

# Webhook signing secret (HMAC SHA-256 shared secret with Bents)
aws secretsmanager put-secret-value \
  --secret-id cashyin/prod-baseline/bents-webhook-secret \
  --secret-string "$BENTS_WEBHOOK_SECRET"
```

The `DATABASE_URL` secret is populated automatically by the RDS module
on first apply and refreshed if the master password ever changes.

### 7. Bootstrap deploy and run the migrations

After Terraform finishes, the ECS service is up but the database is
empty. Run the one-shot migration task once to apply
`migrations/*.sql`:

```bash
PRIVATE_SUBNETS="$(terraform output -raw private_subnet_ids | tr -d '[]" ' | head -1)"
API_SG="$(terraform output -raw api_security_group_id)"
CLUSTER="$(terraform output -raw ecs_cluster_name)"
MIGRATE_FAMILY="$(terraform output -raw migrate_task_definition_family)"

aws ecs run-task --cluster "$CLUSTER" \
  --launch-type FARGATE \
  --task-definition "$MIGRATE_FAMILY" \
  --network-configuration "awsvpcConfiguration={subnets=[$PRIVATE_SUBNETS],securityGroups=[$API_SG],assignPublicIp=DISABLED}"
```

The task auto-exits when migrations finish (exit code 0). Tail logs in
CloudWatch under `/cashyin/prod-baseline/api` stream prefix `migrate/`.

Subsequent deploys are handled by `.github/workflows/deploy.yml`, which
runs the same migration task on every push to `main` before flipping
the API service to the new image.

### 8. Smoke test through the ALB

```bash
ALB="$(terraform output -raw alb_dns_name)"
curl -sS "http://$ALB/health"
curl -sS "http://$ALB/ready"
# `/v1/balance` is the per-client ledger balance endpoint (Bearer-auth).
# It replaced `/v1/providers/balance`, which leaked the shared provider
# pool balance across tenants.
curl -sS "http://$ALB/v1/balance" -H "Authorization: Bearer ck_<rawApiKey>"
```

Until `api_public_domain` is set (see step 9 below), the ALB is reachable
over plain HTTP only. Once HTTPS is wired in, prefer the canonical URL:

```bash
URL="$(terraform output -raw api_public_url)"   # https://api.cashyin.com or http://<alb-dns>
curl -sS "$URL/health"
```

### 9. Wire HTTPS / public domain (`api.cashyin.com`)

Bringing TLS online is a three-step interaction between Terraform and the
external DNS provider (Cloudflare). Terraform does not own the DNS zone, so
two of the steps are manual.

1. **Set the variable and apply once.** Edit `terraform.tfvars`:
   ```hcl
   api_public_domain      = "api.cashyin.com"
   # api_tls_policy         = "ELBSecurityPolicy-TLS13-1-2-2021-06"  # default
   # redirect_http_to_https = true                                    # default
   ```
   Then `terraform apply`. The apply will request an ACM cert for the
   domain in this region and then **block** on `aws_acm_certificate_validation`
   until the DNS validation record exists. Read the records that Terraform
   surfaced (still during the apply, in another shell):
   ```bash
   terraform output -json acm_validation_records
   ```
   Each entry is `{ name, type, value }`.

2. **Create the validation CNAME(s) in Cloudflare** with the proxy DISABLED
   (DNS only / grey cloud). Example for the typical single-record case:
   ```
   _<token>.api.cashyin.com   CNAME   _<value>.<region>.acm-validations.aws.
   ```
   ACM normally flips the cert to ISSUED within 1–5 minutes; the apply
   that was waiting will then resume on its own and create the HTTPS:443
   listener (and the HTTP:80 redirect when `redirect_http_to_https=true`),
   roll a new task-def revision with `API_BASE_URL=https://api.cashyin.com`,
   and the API service rolls forward.

3. **Create the public CNAME in Cloudflare** so callers can resolve the
   domain to the ALB. Recommended to start with proxy DISABLED to isolate
   any TLS issues end-to-end:
   ```
   api.cashyin.com   CNAME   <alb_dns_name>   (proxy: DNS only)
   ```
   You can flip the proxy on later if you want Cloudflare CDN/WAF in
   front; that adds a TLS-termination layer at the edge.

4. **Validate.**
   ```bash
   curl -v https://api.cashyin.com/health         # 200
   curl -v http://api.cashyin.com/health          # 301 -> https when redirect is on
   ```

To turn HTTPS back off (emergency rollback), unset `api_public_domain` in
`terraform.tfvars` and `terraform apply`. The HTTPS listener is destroyed,
the HTTP listener reverts to forwarding to the target group, and
`API_BASE_URL` falls back to `http://<alb_dns_name>`. The ACM cert itself
is left in place (orphaned) so re-enabling is a no-op restore.

### 10. Wire the private BFF endpoint (ECS Service Connect)

The BFF (Backend-for-Frontend) must reach the Core over the **VPC**, not the
public `api.cashyin.com`. When the BFF runs as an **ECS service in this VPC**
(its own or a sibling cluster), the recommended east-west path is **ECS Service
Connect**: the Core is reachable at a stable internal name
(`api.cashyin.internal`) with **managed mTLS**, client-side retries and
telemetry — and **no internal ALB** (lower cost, one fewer hop). The auth
contract is identical to the public path; only the base URL changes (see
[`docs/auth/bff-integration-guide.md`](../docs/auth/bff-integration-guide.md)).

Setting `enable_service_connect = true` provisions:

- A Cloud Map **HTTP namespace** (`cashyin.internal`).
- A `service_connect_configuration` on the API ECS service advertising it as
  `api.cashyin.internal` (discovery name `core-api`), alongside the existing
  public ALB registration.
- API **security-group ingress** from the BFF (by SG and/or CIDR) on the
  container port — the east-west connection rides the task ENIs directly.

The BFF joins the **same namespace** as a Service-Connect-enabled ECS service
and resolves `api.cashyin.internal` locally via its Service Connect proxy
(cross-cluster works as long as both share the namespace and VPC connectivity).

> **Rollout — mind `ignore_changes = [task_definition]`.** The API service
> ignores `task_definition` so the deploy workflow owns the running revision.
> Service Connect references a **named port** on the running task definition, so
> enable it in this order:
>
> 1. `terraform apply` with `enable_service_connect = false` first. This adds
>    the named port (`api`) to the API task definition — registering a new
>    revision (now the latest of the family) without touching the service.
> 2. Trigger a deploy (push to `main` or `workflow_dispatch`). The workflow
>    re-registers from the **latest** family revision (which now carries the
>    named port) and rolls the service, so the **running** task definition gains
>    the named port.
> 3. `terraform apply` with `enable_service_connect = true` (+ the BFF SG/CIDR).
>    The Service Connect service block now resolves its `port_name` against the
>    running task definition and the rollout succeeds.

1. **Authorise the BFF and enable** (after step 1–2 above):
   ```hcl
   enable_service_connect                     = true
   service_connect_dns_name                   = "api.cashyin.internal"
   service_connect_allowed_security_group_ids = ["sg-0bff..."]   # the BFF's ECS SG
   # service_connect_allowed_cidr_blocks      = ["10.20.20.0/24"] # or BFF CIDRs
   ```

2. **Verify** from a Service-Connect-enabled task in the same namespace (the BFF,
   or a temporary test service):
   ```bash
   curl -sS "$(terraform output -raw bff_core_endpoint)/health"   # http://api.cashyin.internal/health -> 200
   ```
   `terraform output service_connect_namespace_arn` gives the BFF stack the
   namespace to join.

> **Turn it off** by setting `enable_service_connect = false` and re-applying:
> the namespace, the service's Service Connect config and the BFF SG ingress are
> removed and the service falls back to the public ALB only. The named port on
> the task definition is harmless and can stay.

## Tearing it down

> Foundation resources are inexpensive but **non-zero** (the NAT Gateway
> costs ~$32/month even idle). Destroy when you are not actively iterating.

```bash
cd infra/terraform/environments/prod-baseline
terraform destroy
```

The S3 state bucket and DynamoDB table are **not** managed by Terraform on
purpose, so `destroy` will not nuke them; if you really want them gone,
delete them manually after `destroy` finishes.

## CI

Every push runs `terraform fmt -check` and `terraform validate` on each
leaf directory via `.github/workflows/ci.yml`. CI does not run `terraform
plan/apply`; that is reserved for the deploy workflow (added in a later
PR with OIDC credentials).

## CI / CD

- `.github/workflows/ci.yml` runs on every PR + push to main: pnpm
  lint/test/tsc, docker build (smoke), terraform fmt + validate. No
  AWS credentials.
- `.github/workflows/deploy.yml` runs on push to main (and via
  `workflow_dispatch`): assumes the GHA OIDC role, builds + pushes the
  image, registers a new revision of the migrate task definition,
  runs the migration to completion, registers a new API task
  definition revision and updates the service. Fails fast if the
  migration exits non-zero.

## Provisioning a test client (Postman / smoke tests)

The public API enforces Bearer authentication via `client_api_keys`.
To exercise `POST /v1/pix/charges` end-to-end from Postman, you need
five rows (client, provider_account, two `client_provider_assignments`,
`client_webhook_endpoints`) plus a freshly-minted API key. The
[`scripts/provision-test-client.mjs`](../scripts/provision-test-client.mjs)
script provisions all of them inside a single transaction:

```bash
# From an ECS exec session inside the API task (DATABASE_URL is set):
TEST_WEBHOOK_TARGET_URL='https://webhook.site/<your-uuid>' \
TEST_CLIENT_LEGAL_NAME='CashYin Postman Test' \
node scripts/provision-test-client.mjs
```

Sample run via `aws ecs execute-command`:

```bash
TASK_ARN=$(aws ecs list-tasks \
  --cluster cashyin-core-api \
  --service-name cashyin-core-api-api \
  --region sa-east-1 \
  --query 'taskArns[0]' --output text)

aws ecs execute-command \
  --cluster cashyin-core-api \
  --task "$TASK_ARN" \
  --container api \
  --command "/bin/sh -c 'TEST_WEBHOOK_TARGET_URL=https://webhook.site/<uuid> node scripts/provision-test-client.mjs'" \
  --interactive --region sa-east-1
```

The script prints `clientId`, `apiKey` (raw — shown ONCE), the API key id and prefix, the
provider account id, the webhook endpoint id, and the webhook signing secret.
Save these somewhere safe; the raw `apiKey` cannot be recovered. Re-running the
script reuses every row except the API key (a fresh one is minted every run, so
you can rotate without revoking the old row from the panel).

Postman setup once you have the credentials:

1. Import [`postman/cashyin-core-api.postman_collection.json`](../postman/cashyin-core-api.postman_collection.json).
2. Create an environment with `baseUrl=https://api.cashyin.com`,
   `apiKey=ck_…`, `cashinAmountCents=100`, `cashoutAmountCents=100`,
   `cashoutPixKey=…`. The collection-level Bearer auth picks `apiKey`
   up automatically.
3. Run the "Health" folder to verify connectivity, then "Cash-in" →
   "Create PIX charge (fresh)" to exercise `POST /v1/pix/charges`. The
   `/internal/webhooks/bents` requests deliberately remove the Bearer
   header before posting.

## Enabling auth enforcement (BFF channel + api_direct)

The auth **code** (BFF channel, `api_direct` scopes + HMAC, per-user RBAC,
cash-out step-up) ships in the image, but enforcement is **off** until the
env reaches the API task. The Terraform vars below (defaults `"off"`) wire it,
and `BFF_SHARED_SECRET` is injected from Secrets Manager **only** when
`bff_auth_mode = "enforce"`.

| tfvar | env | values | governs |
|---|---|---|---|
| `bff_auth_mode` | `BFF_AUTH_MODE` | off, enforce | accept/verify `X-CashYin-BFF-Token` |
| `auth_enforcement_mode` | `AUTH_ENFORCEMENT_MODE` | off, shadow, enforce | scope gate on `/v1/pix/*` |
| `api_hmac_mode` | `API_HMAC_MODE` | off, shadow, enforce | request signing for `api_direct` |
| `bff_rbac_mode` | `BFF_RBAC_MODE` | off, enforce | per-user RBAC (needs `bff_auth_mode=enforce`) |
| `cashout_stepup_mode` | `CASHOUT_STEPUP_MODE` | off, shadow, enforce | step-up (2FA) for human cash-out |

> **Rollout caveat:** `aws_ecs_service.api` has `ignore_changes =
> [task_definition]`, so `terraform apply` only **registers** a new task
> definition revision — it does not switch the running service. The deploy
> workflow registers the next revision from the **latest** family revision
> (swapping only the image), so the new env/secret propagate when a deploy
> runs *after* the apply. Populate the secret **before** rolling an `enforce`
> revision, or the task fails to start (`GetSecretValue` on an empty secret).

Staged rollout (BFF on + scopes measured, then enforced):

```bash
cd infra/terraform/environments/prod-baseline

# 1. Apply with modes still "off" — creates the empty bff-shared-secret.
terraform init && terraform apply

# 2. Populate the secret (>= 32 chars), without echoing it. Share the SAME
#    value with the BFF (it must read it from Secrets Manager).
aws secretsmanager put-secret-value --region sa-east-1 \
  --secret-id "$(terraform output -raw bff_shared_secret_name)" \
  --secret-string "$(openssl rand -base64 48 | tr -d '\n')"

# 3. Turn the BFF channel on + measure scopes without blocking, then apply.
#    In terraform.tfvars:
#      bff_auth_mode         = "enforce"
#      auth_enforcement_mode = "shadow"
terraform apply

# 4. Roll the new revision onto the running tasks (deploy pipeline).
gh workflow run "Deploy (prod-baseline)" --ref main && gh run watch

# 5. Verify, then flip the scope gate on: auth_enforcement_mode = "enforce"
#    + repeat steps 3–4. (Optional: api_hmac_mode "shadow" -> "enforce" once
#    keys carry a signing_secret.)
```

Smoke checks after step 4 (clientId + `ck_…` come from the provisioning script above):

```bash
# BFF channel: valid token + actor + tenant -> 200
curl -s -o /dev/null -w '%{http_code}\n' https://api.cashyin.com/v1/balance \
  -H "X-CashYin-BFF-Token: <secret value>" \
  -H "X-CashYin-Actor-User-Id: smoke-1" \
  -H "X-CashYin-Client-Id: <clientId>"

# api_direct: Bearer key still works (scopes only measured while shadow) -> 200
curl -s -o /dev/null -w '%{http_code}\n' https://api.cashyin.com/v1/balance \
  -H "Authorization: Bearer ck_…"
```

## What is NOT in this PR series

- A real `seed-baseline` task that pre-creates a tenant + provider
  assignment so the API can immediately serve `POST /v1/pix/charges`.
  Today the workaround is `scripts/provision-test-client.mjs` (above)
  or applying `scripts/seed-dev.sql` through a custom run-task.
- CloudWatch alarms and dashboards — PR #4 (in plan).
- ACM cert + HTTPS:443 listener wiring — **shipped**: see "Wire HTTPS / public
  domain (`api.cashyin.com`)" in step 9 above. Terraform now owns the cert
  request, the validation wait, the listener, the optional HTTP→HTTPS
  redirect, and the `API_BASE_URL` switch. The DNS provider (Cloudflare in
  our case) is still external — operators create the validation CNAME and
  the public CNAME by hand.
- **Worker autoscaling on a custom queue-lag metric** — `desired_count`
  is configurable but Application Auto Scaling on a CloudWatch metric
  filter against `webhook_events` / `outbox_events` pending rows is a
  follow-up PR (see ["Worker autoscaling (follow-up)"](#worker-autoscaling-follow-up)).

## Background workers

The provider webhook processor (`webhook_events` → domain handlers)
and the public webhook dispatcher (`outbox_events` → client HTTPS
endpoints) run as **separate ECS services** from the HTTP API. The
same Docker image contains all three entrypoints; the process is
chosen at container start via the `command` field.

| ECS service                                     | Task family                                     | Container command                                              | CloudWatch log group                              | Purpose                                                |
| ----------------------------------------------- | ----------------------------------------------- | -------------------------------------------------------------- | ------------------------------------------------- | ------------------------------------------------------ |
| `cashyin-core-api-api`                          | `cashyin-core-api-api`                          | `node dist/src/main.js`                                        | `/cashyin/prod-baseline/api`                      | Public HTTPS surface behind the ALB.                   |
| `cashyin-core-api-provider-webhook-worker`      | `cashyin-core-api-provider-webhook-worker`      | `node dist/src/main-provider-webhook-worker.js`                | `/cashyin/prod-baseline/provider-webhook-worker`  | Drains `webhook_events` for inbound provider webhooks. |
| `cashyin-core-api-webhook-dispatcher-worker`    | `cashyin-core-api-webhook-dispatcher-worker`    | `node dist/src/main-webhook-dispatcher-worker.js`              | `/cashyin/prod-baseline/webhook-dispatcher-worker` | Drains `outbox_events` and POSTs to client endpoints.  |

The exact names live in Terraform outputs — verify with
`terraform output worker_service_names`.

### Runtime guarantees

Both workers:

- share the **same Docker image, execution role, task role, security
  group, secrets and DB pool semantics** as the API. The only thing
  that differs is `command`, CPU/memory, and the log group;
- claim rows with `FOR UPDATE SKIP LOCKED`, so scaling `desired_count
  > 1` is safe — replicas never process the same row twice;
- expose a single in-flight tick at any moment and back off
  exponentially on idle + on error (tunable via `WORKER_*` env vars,
  surfaced as Terraform variables `worker_busy_interval_ms`,
  `worker_idle_interval_ms`, etc.);
- listen to `SIGINT` and `SIGTERM` for graceful shutdown, awaiting the
  in-flight tick before exiting; ECS sends SIGTERM, waits
  `stopTimeout = 30s`, then SIGKILLs. The application's
  `WORKER_SHUTDOWN_TIMEOUT_MS = 15_000ms` default leaves 15s of
  headroom for the container to close the DB pool.

### Local development

```bash
pnpm dev:api                            # HTTP API
pnpm dev:provider-webhook-worker        # webhook_events processor
pnpm dev:webhook-dispatcher-worker      # outbox_events dispatcher
```

These wrap `tsx watch`; the compiled equivalents are `pnpm
start:api`, `pnpm start:provider-webhook-worker`, `pnpm
start:webhook-dispatcher-worker` (used by the Docker image's
`command` overrides).

### Deploying workers

`.github/workflows/deploy.yml` rolls the API, then the provider
webhook worker, then the dispatcher worker on every push to `main`.
Each rollout registers a new task definition revision with the
freshly-pushed image, calls `UpdateService`, and waits for the
service to reach steady state. Rolling order is intentional:

1. Migrations apply first (single-shot run-task) so DDL never lags
   the code on the new image.
2. The API rolls next so customer-facing endpoints reach the new
   build first.
3. Workers roll after the API is stable. A worker rollout failure
   does NOT roll back the API — open `CloudWatch → log group →
   stream prefix` (`provider-webhook-worker/` or
   `webhook-dispatcher-worker/`) to diagnose.

### Verifying logs

Each worker writes to its own CloudWatch log group, so `aws logs
tail` is enough to focus on one concern:

```bash
# Provider webhook processor (last 5 minutes, follow):
aws logs tail /cashyin/prod-baseline/provider-webhook-worker \
  --since 5m --follow --format short

# Public webhook dispatcher (last 1 hour, filter for failures):
aws logs tail /cashyin/prod-baseline/webhook-dispatcher-worker \
  --since 1h --filter-pattern '"worker tick failed"' --format short
```

Useful log fields the worker emits at every tick:

- `outcome` — `processed` / `noop` / `skipped` / `retry` / `dlq` /
  `empty` / `error`.
- `eventId` (provider worker) / `outboxEventId` (dispatcher).
- `attemptNumber`, `nextAttemptAt` for retry rows.
- `durationMs` for tick latency.

Every log line is JSON; pipe through `| jq` for human readers.

### Scaling

To horizontally scale a worker, increase `desired_count` and
re-apply Terraform:

```bash
cd infra/terraform/environments/prod-baseline
# In terraform.tfvars (or via -var=):
#   provider_webhook_worker_desired_count   = 3
#   webhook_dispatcher_worker_desired_count = 2
terraform apply
```

Or, for an ad-hoc bump that survives until the next deploy (Terraform
ignores `desired_count` on these services on purpose):

```bash
aws ecs update-service \
  --cluster cashyin-core-api \
  --service cashyin-core-api-provider-webhook-worker \
  --desired-count 3
```

There is no maximum count — replicas are coordinated through
`FOR UPDATE SKIP LOCKED` at the database level. The practical ceiling
is the RDS connection pool (each task opens its own pool; today the
pool defaults are conservative enough that 5–10 replicas per worker
is safe on `db.t4g.micro`).

### Pausing a worker in an emergency

If an outbound endpoint is melting, a provider is sending malformed
events, or you simply want to stop processing while you ship a fix,
**scale the service to zero**. The DB queue rows stay put and resume
processing as soon as you scale back up.

```bash
# Stop the dispatcher RIGHT NOW (no Terraform apply needed):
aws ecs update-service \
  --cluster cashyin-core-api \
  --service cashyin-core-api-webhook-dispatcher-worker \
  --desired-count 0

# Resume when ready:
aws ecs update-service \
  --cluster cashyin-core-api \
  --service cashyin-core-api-webhook-dispatcher-worker \
  --desired-count 1
```

To persist the pause across deploys, also set
`webhook_dispatcher_worker_desired_count = 0` in
`terraform.tfvars` and apply. The Terraform `ignore_changes =
[desired_count]` lifecycle keeps a manual `update-service` sticky
until the next `terraform apply` reconciles it.

### Worker autoscaling (follow-up)

`desired_count` is a fixed knob today. The follow-up PR will add
Application Auto Scaling on a custom CloudWatch metric emitted by a
small Lambda (or directly via a `PutMetricData` call from the worker
itself):

- **Metric**: pending rows in `webhook_events`
  (`processing_status = 'pending' AND next_attempt_at <= NOW()`) and
  `outbox_events` (`status = 'pending'`).
- **Policy**: target-tracking on `pending_rows / running_tasks`,
  e.g. target = 200 rows per task.
- **Bounds**: `min_capacity = 1`, `max_capacity = 10` per worker
  initially.

Until then, treat the `worker_*_desired_count` Terraform variables as
the manual scaling control.

## Hardening trade-offs accepted in baseline

These exist because the goal of `prod-baseline` is a cheap, throwaway
environment for response-time testing. Document them before promoting
this stack to true production:

- **RDS master password generated by `random_password`** and ends up in
  Terraform state (S3 + SSE-S3 + TLS-only bucket policy). Hardening =
  `manage_master_user_password = true` + IAM database auth + RDS Proxy.
- **Single-AZ RDS, `deletion_protection = false`,
  `skip_final_snapshot = true`**. Flip all three for real prod.
- **`recovery_window_in_days = 0`** on every Secrets Manager secret so
  destroy is immediate. Real prod should keep the default 7-30 days so
  an accidental destroy can be undone.
- **No KMS CMK** — RDS and Secrets Manager use the AWS-managed key.
  Real prod gets a customer-managed key per environment with key
  rotation enabled.
