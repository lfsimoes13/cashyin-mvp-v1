terraform {
  required_version = ">= 1.10.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.83"
    }
  }

  # Backend uses S3 + DynamoDB locking. The bucket, region and lock table
  # values are passed at `terraform init` time via -backend-config flags
  # so the same code can be reused across accounts without editing this
  # file (see infra/README.md for the exact init command).
  backend "s3" {
    key     = "prod-baseline/terraform.tfstate"
    encrypt = true
  }
}
