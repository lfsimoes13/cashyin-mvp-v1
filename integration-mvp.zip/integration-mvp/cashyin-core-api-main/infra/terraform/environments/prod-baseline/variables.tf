variable "aws_region" {
  description = "AWS region. Defaults to São Paulo so latency is bounded for Brazilian users."
  type        = string
  default     = "sa-east-1"
}

variable "project_name" {
  description = "Used as the resource name prefix and the value of the `Project` tag."
  type        = string
  default     = "cashyin-core-api"
}

variable "github_repository" {
  description = "GitHub repository in `<owner>/<repo>` form. Used to scope the OIDC trust policy."
  type        = string
  validation {
    condition     = can(regex("^[^/]+/[^/]+$", var.github_repository))
    error_message = "github_repository must be in 'owner/repo' form."
  }
}

variable "github_oidc_create_provider" {
  description = "Set to false if the AWS account already has an OIDC provider for token.actions.githubusercontent.com."
  type        = bool
  default     = true
}

variable "github_oidc_existing_provider_arn" {
  description = "Existing OIDC provider ARN when github_oidc_create_provider = false."
  type        = string
  default     = null
}

variable "extra_tags" {
  description = "Optional tags merged onto every taggable resource."
  type        = map(string)
  default     = {}
}

# ─── Public domain + TLS ──────────────────────────────────────────────────────

variable "api_public_domain" {
  description = <<-EOT
    Fully-qualified DNS name the API is exposed under (e.g. `api.cashyin.com`).
    When set, the environment provisions an ACM certificate (DNS-validated)
    for this domain, wires it into the ALB as the HTTPS:443 listener cert,
    and rewrites `API_BASE_URL` to `https://<api_public_domain>`. When null
    (default), the ALB stays HTTP/80-only and `API_BASE_URL` falls back to
    `http://<alb_dns_name>`.

    DNS validation records and the public CNAME (`<api_public_domain>` →
    `<alb_dns_name>`) must be created in the external DNS provider
    (Cloudflare) — Terraform does not own the zone.
  EOT
  type        = string
  default     = null

  validation {
    condition     = var.api_public_domain == null || can(regex("^[a-z0-9.-]+\\.[a-z]{2,}$", var.api_public_domain))
    error_message = "api_public_domain must be a lowercase FQDN like 'api.cashyin.com'."
  }
}

variable "api_tls_policy" {
  description = "ALB SSL policy applied to the HTTPS:443 listener when TLS is enabled."
  type        = string
  default     = "ELBSecurityPolicy-TLS13-1-2-2021-06"
}

variable "redirect_http_to_https" {
  description = <<-EOT
    When `true` AND `api_public_domain` is set, the ALB rewrites HTTP/80
    as a permanent 301 redirect to HTTPS/443. Set to `false` to keep both
    listeners forwarding to the API target group (useful as a short bridge
    while internal smoke tests migrate to the HTTPS URL).
  EOT
  type        = bool
  default     = true
}

# ─── Internal (BFF) endpoint via ECS Service Connect ──────────────────────────
#
# The BFF reaches the Core over the VPC (east-west) instead of the public
# api.cashyin.com. When co-located as an ECS service in this VPC, Service
# Connect gives a stable internal name (api.cashyin.internal) with managed
# mTLS, retries and telemetry — no internal ALB. Inert by default.

variable "enable_service_connect" {
  description = <<-EOT
    Master switch for the BFF east-west endpoint via ECS Service Connect. When
    `true`, the stack creates a Cloud Map HTTP namespace, registers the API
    service into it (advertised as `service_connect_dns_name`), and authorises
    the BFF SG/CIDR to reach the API container port. Read the rollout note in
    infra/README.md §10 before enabling: the running task definition must carry
    the named port first. Default `false` leaves the baseline unchanged.
  EOT
  type        = bool
  default     = false
}

variable "service_connect_namespace_name" {
  description = "Cloud Map HTTP namespace name for in-VPC service discovery (e.g. cashyin.internal)."
  type        = string
  default     = "cashyin.internal"
}

variable "service_connect_dns_name" {
  description = "Hostname the BFF uses to reach the Core over Service Connect (e.g. api.cashyin.internal)."
  type        = string
  default     = "api.cashyin.internal"
}

variable "service_connect_discovery_name" {
  description = "Service Connect discovery name for the API service (unique within the namespace)."
  type        = string
  default     = "core-api"
}

variable "service_connect_alias_port" {
  description = "Port the BFF dials on service_connect_dns_name (80 ⇒ http://api.cashyin.internal/v1/...)."
  type        = number
  default     = 80
}

variable "service_connect_allowed_security_group_ids" {
  description = "Security group IDs (e.g. the BFF ECS service SG) allowed to reach the API container port. Only used when enable_service_connect = true."
  type        = list(string)
  default     = []
}

variable "service_connect_allowed_cidr_blocks" {
  description = "CIDR blocks (e.g. BFF subnet ranges) allowed to reach the API container port. Only used when enable_service_connect = true."
  type        = list(string)
  default     = []
}

variable "bents_webhook_auth_mode" {
  description = <<-EOT
    Strategy used to authenticate inbound Bents webhooks. `"none"`
    (default) accepts unsigned bodies — appropriate today because
    Bents support confirmed (May/2026) that their portal does not
    issue webhook signing secrets. `"hmac"` requires
    `BENTS_WEBHOOK_SECRET` to be populated and validates the
    `X-Bents-Signature` header.
  EOT
  type        = string
  default     = "none"
  validation {
    condition     = contains(["none", "hmac"], var.bents_webhook_auth_mode)
    error_message = "bents_webhook_auth_mode must be one of: none, hmac."
  }
}

variable "bents_webhook_require_signature" {
  description = <<-EOT
    Strictness flag for the HMAC strategy (ignored when
    `bents_webhook_auth_mode = "none"`). When `true` (default) the
    HMAC strategy rejects requests without a verifiable signature.
    When `false`, accepts unsigned but still verifies whenever both
    secret and well-formed signature header are present.
  EOT
  type        = bool
  default     = true
}

# ─── Auth enforcement (BFF channel + api_direct) ──────────────────────────────
#
# Forwarded to the ECS API task env (src/shared/config/env.ts). Defaults are
# the safe "off" posture so a plain `apply` changes no behaviour. Recommended
# rollout: set bff_auth_mode=enforce + auth_enforcement_mode=shadow first
# (after populating the bff-shared-secret), validate, then flip to enforce.
# `BFF_SHARED_SECRET` is injected into the task ONLY when bff_auth_mode=enforce.

variable "bff_auth_mode" {
  description = "BFF_AUTH_MODE: off | enforce. `enforce` accepts/verifies X-CashYin-BFF-Token and requires the bff-shared-secret to be populated."
  type        = string
  default     = "off"
  validation {
    condition     = contains(["off", "enforce"], var.bff_auth_mode)
    error_message = "bff_auth_mode must be one of: off, enforce."
  }
}

variable "auth_enforcement_mode" {
  description = "AUTH_ENFORCEMENT_MODE: off | shadow | enforce. Scope gate on /v1/pix/*."
  type        = string
  default     = "off"
  validation {
    condition     = contains(["off", "shadow", "enforce"], var.auth_enforcement_mode)
    error_message = "auth_enforcement_mode must be one of: off, shadow, enforce."
  }
}

variable "api_hmac_mode" {
  description = "API_HMAC_MODE: off | shadow | enforce. Request signing for the api_direct channel (enforce needs keys with signing_secret)."
  type        = string
  default     = "off"
  validation {
    condition     = contains(["off", "shadow", "enforce"], var.api_hmac_mode)
    error_message = "api_hmac_mode must be one of: off, shadow, enforce."
  }
}

variable "bff_rbac_mode" {
  description = "BFF_RBAC_MODE: off | enforce. Per-user RBAC for the BFF channel (enforce requires bff_auth_mode=enforce)."
  type        = string
  default     = "off"
  validation {
    condition     = contains(["off", "enforce"], var.bff_rbac_mode)
    error_message = "bff_rbac_mode must be one of: off, enforce."
  }
}

variable "cashout_stepup_mode" {
  description = "CASHOUT_STEPUP_MODE: off | shadow | enforce. Step-up (2FA) for human-initiated cash-out."
  type        = string
  default     = "off"
  validation {
    condition     = contains(["off", "shadow", "enforce"], var.cashout_stepup_mode)
    error_message = "cashout_stepup_mode must be one of: off, shadow, enforce."
  }
}

# ─── RDS (PR #2) ──────────────────────────────────────────────────────────────

variable "db_instance_class" {
  description = "RDS instance class for the baseline database."
  type        = string
  default     = "db.t4g.micro"
}

variable "db_allocated_storage" {
  description = "Initial RDS allocated storage in GiB."
  type        = number
  default     = 20
}

variable "db_max_allocated_storage" {
  description = "RDS storage autoscaling ceiling in GiB."
  type        = number
  default     = 100
}

variable "db_multi_az" {
  description = "Enable RDS Multi-AZ. Off in baseline to control cost."
  type        = bool
  default     = false
}

variable "db_deletion_protection" {
  description = "Block accidental RDS destroy. Off in baseline; flip on for real prod."
  type        = bool
  default     = false
}

variable "db_skip_final_snapshot" {
  description = "Skip final snapshot on RDS destroy. True in baseline; flip to false for real prod."
  type        = bool
  default     = true
}

variable "secret_recovery_window_days" {
  description = "Days a deleted Secrets Manager secret stays in soft-delete before being purged. 0 = no recovery window (useful while iterating)."
  type        = number
  default     = 0
}

# ─── ECS + ALB (PR #3) ────────────────────────────────────────────────────────

variable "image_tag" {
  description = "ECR image tag the ECS service runs on first apply. The deploy workflow takes over after that."
  type        = string
}

variable "api_desired_count" {
  description = "Number of API tasks the ECS service keeps running."
  type        = number
  default     = 2
}

variable "api_cpu" {
  description = "CPU units allocated to each API task."
  type        = number
  default     = 512
}

variable "api_memory" {
  description = "Memory MiB allocated to each API task."
  type        = number
  default     = 1024
}

variable "log_retention_in_days" {
  description = "CloudWatch log retention for the API and worker log groups."
  type        = number
  default     = 7
}

# ─── Workers ──────────────────────────────────────────────────────────────────
#
# Each worker has its own ECS service with a configurable `desired_count`.
# Set to 0 to PAUSE a worker (e.g. during an emergency: a partner endpoint
# is melting and you want to stop hammering it while you ship a fix).

variable "provider_webhook_worker_desired_count" {
  description = "Number of provider-webhook-worker tasks the ECS service keeps running."
  type        = number
  default     = 1
}

variable "provider_webhook_worker_cpu" {
  description = "CPU units allocated to each provider-webhook-worker task."
  type        = number
  default     = 256
}

variable "provider_webhook_worker_memory" {
  description = "Memory MiB allocated to each provider-webhook-worker task."
  type        = number
  default     = 512
}

variable "webhook_dispatcher_worker_desired_count" {
  description = "Number of webhook-dispatcher-worker tasks the ECS service keeps running."
  type        = number
  default     = 1
}

variable "webhook_dispatcher_worker_cpu" {
  description = "CPU units allocated to each webhook-dispatcher-worker task."
  type        = number
  default     = 256
}

variable "webhook_dispatcher_worker_memory" {
  description = "Memory MiB allocated to each webhook-dispatcher-worker task."
  type        = number
  default     = 512
}

# Loop cadence — mirror the defaults in `src/shared/config/env.ts` so a
# fresh apply matches the application's own defaults.

variable "worker_busy_interval_ms" {
  description = "Sleep (ms) after a tick that processed work."
  type        = number
  default     = 50
}

variable "worker_idle_interval_ms" {
  description = "Initial sleep (ms) after the first idle tick."
  type        = number
  # Aligned with src/shared/config/env.ts default. With LISTEN/NOTIFY this is
  # only the polling fallback, so a fast value keeps queue lag low if the
  # watcher disconnects. The previous baseline value (1 000) was 5× slower.
  default = 200
}

variable "worker_max_idle_interval_ms" {
  description = "Cap (ms) for the exponential backoff applied to consecutive idle ticks."
  type        = number
  # Aligned with src/shared/config/env.ts default (was 30 000 — 6× slower).
  default = 5000
}

variable "worker_error_backoff_ms" {
  description = "Initial sleep (ms) after a tick threw."
  type        = number
  default     = 5000
}

variable "worker_max_error_backoff_ms" {
  description = "Cap (ms) for the exponential backoff applied to consecutive errored ticks."
  type        = number
  default     = 60000
}

variable "worker_shutdown_timeout_ms" {
  description = "Max time stop() waits for the in-flight tick after SIGTERM (ms)."
  type        = number
  default     = 15000
}
