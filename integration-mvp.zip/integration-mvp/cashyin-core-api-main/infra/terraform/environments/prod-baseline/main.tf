################################################################################
# prod-baseline environment
#
# Composes the foundation modules (network, ecr, github-oidc) into a single
# stack. This stack is the prerequisite for every later PR (RDS, ECS, ALB,
# CloudWatch alarms): it owns the VPC, the container registry and the IAM
# identity GitHub Actions uses to push images.
#
# It deliberately does NOT yet provision the database, the ECS service or
# the ALB; those land in PRs #2/#3/#4 (see docs/aws-deploy-plan.md).
################################################################################

provider "aws" {
  region = var.aws_region

  default_tags {
    tags = merge({
      Project     = var.project_name
      Environment = "prod-baseline"
      ManagedBy   = "terraform"
    }, var.extra_tags)
  }
}

data "aws_availability_zones" "available" {
  state = "available"
  filter {
    name   = "opt-in-status"
    values = ["opt-in-not-required"]
  }
}

locals {
  # Pick the first two AZs the account has access to. Two is the ALB
  # minimum; picking deterministically (alphabetical, from the AWS
  # response) keeps subnet CIDRs stable across plan runs.
  azs = slice(sort(data.aws_availability_zones.available.names), 0, 2)
}

module "network" {
  source = "../../modules/network"

  name       = var.project_name
  cidr_block = "10.20.0.0/16"
  azs        = local.azs

  # BFF east-west (Service Connect) SG wiring. All SGs stay owned by this
  # module to avoid inline/standalone rule conflicts; the Cloud Map namespace
  # and the service_connect_configuration live below / in the ecs module.
  enable_service_connect                     = var.enable_service_connect
  service_connect_allowed_security_group_ids = var.service_connect_allowed_security_group_ids
  service_connect_allowed_cidr_blocks        = var.service_connect_allowed_cidr_blocks
}

module "ecr" {
  source = "../../modules/ecr"

  repository_name = var.project_name
  max_image_count = 20
}

module "github_oidc" {
  source = "../../modules/github-oidc"

  github_repository          = var.github_repository
  role_name                  = "gha-${var.project_name}-deploy"
  create_oidc_provider       = var.github_oidc_create_provider
  existing_oidc_provider_arn = var.github_oidc_existing_provider_arn
  ecr_repository_arn         = module.ecr.repository_arn
}

# ─── PR #2: RDS + Secrets Manager ─────────────────────────────────────────────

locals {
  # `secret_prefix` is the namespace under which every Secrets Manager
  # secret for this environment lives. Using a `cashyin/<env>` shape lets
  # IAM policies wildcard the prefix cleanly.
  secret_prefix = "cashyin/prod-baseline"
}

module "rds" {
  source = "../../modules/rds"

  name                        = var.project_name
  subnet_ids                  = module.network.private_subnet_ids
  vpc_security_group_ids      = [module.network.rds_security_group_id]
  instance_class              = var.db_instance_class
  allocated_storage           = var.db_allocated_storage
  max_allocated_storage       = var.db_max_allocated_storage
  multi_az                    = var.db_multi_az
  deletion_protection         = var.db_deletion_protection
  skip_final_snapshot         = var.db_skip_final_snapshot
  secret_name                 = "${local.secret_prefix}/database-url"
  secret_recovery_window_days = var.secret_recovery_window_days
}

module "secrets" {
  source = "../../modules/secrets"

  name_prefix          = local.secret_prefix
  recovery_window_days = var.secret_recovery_window_days

  secrets = {
    "bents-api-key" = {
      description = "Bents API key (Bearer token used by BentsClient)"
    }
    "bents-webhook-secret" = {
      description = "HMAC SHA-256 shared secret used to verify Bents webhook signatures"
    }
    "bff-shared-secret" = {
      description = "BFF_SHARED_SECRET — shared secret the trusted BFF presents in X-CashYin-BFF-Token (>= 32 chars). Populate before setting bff_auth_mode=enforce."
    }
  }
}

# ─── PR #3: CloudWatch Logs + ALB + ECS Fargate ───────────────────────────────

module "cloudwatch_logs" {
  source = "../../modules/cloudwatch-logs"

  log_group_name    = "/cashyin/prod-baseline/api"
  retention_in_days = var.log_retention_in_days
}

# Each worker writes to its own log group so on-call can split log
# streams by concern (e.g. "show me only outbound dispatcher failures")
# without parsing the API stream prefix.

module "cloudwatch_logs_provider_webhook_worker" {
  source = "../../modules/cloudwatch-logs"

  log_group_name    = "/cashyin/prod-baseline/provider-webhook-worker"
  retention_in_days = var.log_retention_in_days
}

module "cloudwatch_logs_webhook_dispatcher_worker" {
  source = "../../modules/cloudwatch-logs"

  log_group_name    = "/cashyin/prod-baseline/webhook-dispatcher-worker"
  retention_in_days = var.log_retention_in_days
}

################################################################################
# Public domain + TLS
#
# The ACM certificate, its DNS validation, and the listener wiring are all
# guarded by `var.api_public_domain != null`. While the variable is null the
# resources collapse to count=0, so the bootstrap (HTTP-only) path is
# unchanged.
#
# Validation flow:
#   1. `aws_acm_certificate` requests the cert; status starts as
#      PENDING_VALIDATION and ACM emits the DNS validation record(s).
#   2. The `acm_validation_records` output exposes those records so an
#      operator can create the matching CNAME(s) in the external DNS
#      provider (Cloudflare in our case — Terraform does not own the zone).
#   3. `aws_acm_certificate_validation` blocks the apply until ACM has seen
#      the CNAME(s) and flipped the cert to ISSUED. Subsequent applies are
#      no-ops once the cert is validated.
#   4. The validated cert ARN is fed to the ALB module, which materialises
#      the HTTPS:443 listener and (when enabled) the HTTP→HTTPS redirect.
################################################################################

locals {
  tls_enabled = var.api_public_domain != null
}

resource "aws_acm_certificate" "api" {
  count             = local.tls_enabled ? 1 : 0
  domain_name       = var.api_public_domain
  validation_method = "DNS"
  key_algorithm     = "RSA_2048"

  lifecycle {
    create_before_destroy = true
  }

  tags = {
    Name = "${var.project_name}-${replace(var.api_public_domain, ".", "-")}"
  }
}

resource "aws_acm_certificate_validation" "api" {
  count                   = local.tls_enabled ? 1 : 0
  certificate_arn         = aws_acm_certificate.api[0].arn
  validation_record_fqdns = [for opt in aws_acm_certificate.api[0].domain_validation_options : opt.resource_record_name]

  timeouts {
    create = "45m"
  }
}

module "alb" {
  source = "../../modules/alb"

  name              = var.project_name
  vpc_id            = module.network.vpc_id
  public_subnet_ids = module.network.public_subnet_ids
  security_group_id = module.network.alb_security_group_id
  container_port    = 3000
  health_check_path = "/health"

  # `tls_enabled` is plan-known (derives from `var.api_public_domain`),
  # so the module can use it inside a `count` argument. `certificate_arn`
  # is `known after apply` on first run (it comes out of the validation
  # resource), which Terraform tolerates inside the listener body but
  # would reject inside `count`/`for_each` — hence the two-variable split.
  tls_enabled     = local.tls_enabled
  certificate_arn = local.tls_enabled ? aws_acm_certificate_validation.api[0].certificate_arn : null

  tls_policy             = var.api_tls_policy
  redirect_http_to_https = var.redirect_http_to_https
}

# ─── Internal (BFF) endpoint: ECS Service Connect ─────────────────────────────
#
# Inert unless `enable_service_connect = true`. When on, it creates a Cloud Map
# HTTP namespace (cashyin.internal) and the ecs module registers the API into it
# as `api.cashyin.internal`, so the BFF — a Service-Connect-enabled ECS service
# in this VPC/namespace — reaches the Core east-west with managed mTLS, retries
# and telemetry. No internal ALB. The API SG ingress for the BFF comes from the
# network module (single SG owner).

resource "aws_service_discovery_http_namespace" "internal" {
  count       = var.enable_service_connect ? 1 : 0
  name        = var.service_connect_namespace_name
  description = "Cloud Map namespace for in-VPC Service Connect (${var.project_name})"

  tags = {
    Name = var.service_connect_namespace_name
  }
}

module "ecs" {
  source = "../../modules/ecs"

  name               = var.project_name
  aws_region         = var.aws_region
  private_subnet_ids = module.network.private_subnet_ids
  security_group_id  = module.network.api_security_group_id
  target_group_arn   = module.alb.target_group_arn

  # Service Connect (BFF east-west), when enabled.
  enable_service_connect         = var.enable_service_connect
  service_connect_namespace_arn  = var.enable_service_connect ? aws_service_discovery_http_namespace.internal[0].arn : null
  service_connect_discovery_name = var.service_connect_discovery_name
  service_connect_dns_name       = var.service_connect_dns_name
  service_connect_alias_port     = var.service_connect_alias_port
  service_connect_log_group_name = var.enable_service_connect ? module.cloudwatch_logs.log_group_name : null

  image_repository_url = module.ecr.repository_url
  image_tag            = var.image_tag
  container_port       = 3000

  api_cpu           = var.api_cpu
  api_memory        = var.api_memory
  api_desired_count = var.api_desired_count

  log_group_name = module.cloudwatch_logs.log_group_name
  log_group_arn  = module.cloudwatch_logs.log_group_arn

  database_url_secret_arn         = module.rds.database_url_secret_arn
  bents_api_key_secret_arn        = module.secrets.secret_arns["bents-api-key"]
  bents_webhook_secret_secret_arn = module.secrets.secret_arns["bents-webhook-secret"]

  # Auth enforcement (BFF channel + api_direct). The BFF shared secret is only
  # injected into the task when enforcing, so the empty secret is never read.
  bff_auth_mode         = var.bff_auth_mode
  auth_enforcement_mode = var.auth_enforcement_mode
  api_hmac_mode         = var.api_hmac_mode
  bff_rbac_mode         = var.bff_rbac_mode
  cashout_stepup_mode   = var.cashout_stepup_mode

  bff_shared_secret_secret_arn = var.bff_auth_mode == "enforce" ? module.secrets.secret_arns["bff-shared-secret"] : ""

  # When `api_public_domain` is set, the API advertises the canonical
  # HTTPS URL. Otherwise it falls back to the raw ALB DNS over HTTP — same
  # behaviour as before the TLS work landed.
  api_base_url = local.tls_enabled ? "https://${var.api_public_domain}" : "http://${module.alb.alb_dns_name}"

  bents_webhook_auth_mode         = var.bents_webhook_auth_mode
  bents_webhook_require_signature = var.bents_webhook_require_signature

  # ─── Workers ────────────────────────────────────────────────────────────────

  provider_webhook_worker_log_group_name = module.cloudwatch_logs_provider_webhook_worker.log_group_name
  provider_webhook_worker_log_group_arn  = module.cloudwatch_logs_provider_webhook_worker.log_group_arn

  webhook_dispatcher_worker_log_group_name = module.cloudwatch_logs_webhook_dispatcher_worker.log_group_name
  webhook_dispatcher_worker_log_group_arn  = module.cloudwatch_logs_webhook_dispatcher_worker.log_group_arn

  provider_webhook_worker_desired_count = var.provider_webhook_worker_desired_count
  provider_webhook_worker_cpu           = var.provider_webhook_worker_cpu
  provider_webhook_worker_memory        = var.provider_webhook_worker_memory

  webhook_dispatcher_worker_desired_count = var.webhook_dispatcher_worker_desired_count
  webhook_dispatcher_worker_cpu           = var.webhook_dispatcher_worker_cpu
  webhook_dispatcher_worker_memory        = var.webhook_dispatcher_worker_memory

  worker_busy_interval_ms     = var.worker_busy_interval_ms
  worker_idle_interval_ms     = var.worker_idle_interval_ms
  worker_max_idle_interval_ms = var.worker_max_idle_interval_ms
  worker_error_backoff_ms     = var.worker_error_backoff_ms
  worker_max_error_backoff_ms = var.worker_max_error_backoff_ms
  worker_shutdown_timeout_ms  = var.worker_shutdown_timeout_ms
}

# ─── Extend the GHA deploy role with the ECS deploy permissions ───────────────
#
# Kept here (not in modules/github-oidc) so the OIDC module stays generic
# and decoupled from any workload-specific knowledge. The role can be
# safely re-applied to other workloads by simply not creating this policy.

data "aws_iam_policy_document" "gha_ecs_deploy" {
  statement {
    sid = "EcsDescribeAndUpdate"
    actions = [
      "ecs:DescribeServices",
      "ecs:DescribeTaskDefinition",
      "ecs:DescribeTasks",
      "ecs:ListTasks",
      "ecs:RegisterTaskDefinition",
      "ecs:UpdateService",
      "ecs:RunTask",
      "ecs:TagResource"
    ]
    resources = ["*"]
  }

  statement {
    sid       = "PassExecAndTaskRoles"
    actions   = ["iam:PassRole"]
    resources = [module.ecs.execution_role_arn, module.ecs.task_role_arn]

    # PassRole must be allowed only when the destination service is ECS.
    condition {
      test     = "StringEquals"
      variable = "iam:PassedToService"
      values   = ["ecs-tasks.amazonaws.com"]
    }
  }

  # Both worker services share the same `ecs:UpdateService` and
  # `ecs:RegisterTaskDefinition` IAM actions as the API service above
  # (both wildcarded on `*`), so no additional statement is required
  # to roll worker deploys. We only need to add the worker log groups
  # below so the deploy step can tail their streams.

  statement {
    sid     = "TailLogsDuringDeploy"
    actions = ["logs:DescribeLogStreams", "logs:GetLogEvents", "logs:FilterLogEvents"]
    resources = [
      "${module.cloudwatch_logs.log_group_arn}:*",
      "${module.cloudwatch_logs_provider_webhook_worker.log_group_arn}:*",
      "${module.cloudwatch_logs_webhook_dispatcher_worker.log_group_arn}:*"
    ]
  }
}

resource "aws_iam_role_policy" "gha_ecs_deploy" {
  name   = "${module.github_oidc.role_name}-ecs-deploy"
  role   = module.github_oidc.role_name
  policy = data.aws_iam_policy_document.gha_ecs_deploy.json
}
