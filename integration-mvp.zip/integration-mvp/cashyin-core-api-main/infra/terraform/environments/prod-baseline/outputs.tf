output "vpc_id" {
  description = "VPC ID for downstream modules (RDS subnet group, ECS service, ALB)."
  value       = module.network.vpc_id
}

output "public_subnet_ids" {
  description = "Public subnet IDs (ALB lives here)."
  value       = module.network.public_subnet_ids
}

output "private_subnet_ids" {
  description = "Private subnet IDs (ECS tasks and RDS live here)."
  value       = module.network.private_subnet_ids
}

output "alb_security_group_id" {
  description = "Security group consumed by the public ALB."
  value       = module.network.alb_security_group_id
}

output "api_security_group_id" {
  description = "Security group consumed by the API ECS service."
  value       = module.network.api_security_group_id
}

output "rds_security_group_id" {
  description = "Security group consumed by the RDS instance."
  value       = module.network.rds_security_group_id
}

output "ecr_repository_url" {
  description = "Full registry URL for the API image."
  value       = module.ecr.repository_url
}

output "ecr_repository_arn" {
  description = "ARN of the ECR repository."
  value       = module.ecr.repository_arn
}

output "github_actions_role_arn" {
  description = "Set this as the value of `role-to-assume` in .github/workflows/deploy.yml."
  value       = module.github_oidc.role_arn
}

# ─── RDS + Secrets ────────────────────────────────────────────────────────────

output "rds_endpoint" {
  description = "PostgreSQL endpoint (host:port). Private — only reachable from inside the VPC."
  value       = module.rds.endpoint
}

output "rds_instance_identifier" {
  description = "RDS instance identifier (used in the AWS console)."
  value       = module.rds.instance_identifier
}

output "database_url_secret_arn" {
  description = "ARN of the assembled DATABASE_URL secret. Consumed by the ECS task definition in PR #3."
  value       = module.rds.database_url_secret_arn
}

output "database_url_secret_name" {
  description = "Name of the DATABASE_URL secret. Use with `aws secretsmanager get-secret-value --secret-id <name>` to fetch the value."
  value       = module.rds.database_url_secret_name
}

output "bents_secret_arns" {
  description = "Map of provisioned secret ARNs (bents-api-key, bents-webhook-secret, bff-shared-secret). The ECS execution role grants GetSecretValue on the ones wired into the task."
  value       = module.secrets.secret_arns
}

output "bents_secret_names" {
  description = "Map of provisioned secret names. Use these with `aws secretsmanager put-secret-value` to populate the credentials post-apply."
  value       = module.secrets.secret_names
}

output "bff_shared_secret_name" {
  description = "Name of the BFF_SHARED_SECRET secret. Populate it BEFORE setting bff_auth_mode=enforce: `aws secretsmanager put-secret-value --secret-id <name> --secret-string <>=32 chars>`."
  value       = module.secrets.secret_names["bff-shared-secret"]
}

# ─── ECS + ALB ────────────────────────────────────────────────────────────────

output "alb_dns_name" {
  description = "Public ALB DNS name. Until the public CNAME is in place, smoke tests point at http://<dns_name>."
  value       = module.alb.alb_dns_name
}

output "alb_arn" {
  description = "ALB ARN."
  value       = module.alb.alb_arn
}

output "api_public_url" {
  description = "Canonical public URL of the API. HTTPS when `api_public_domain` is set, plain HTTP on the ALB DNS otherwise."
  value       = var.api_public_domain != null ? "https://${var.api_public_domain}" : "http://${module.alb.alb_dns_name}"
}

output "acm_certificate_arn" {
  description = "ARN of the ACM certificate used by the HTTPS listener. Null when TLS is not enabled."
  value       = length(aws_acm_certificate.api) > 0 ? aws_acm_certificate.api[0].arn : null
}

output "acm_certificate_status" {
  description = "Current status of the ACM certificate (PENDING_VALIDATION / ISSUED / FAILED / ...)."
  value       = length(aws_acm_certificate.api) > 0 ? aws_acm_certificate.api[0].status : null
}

output "acm_validation_records" {
  description = <<-EOT
    DNS records that must be created in the external DNS provider so ACM can
    validate ownership of `api_public_domain`. Each entry is `{ name, type,
    value }`; create a CNAME from `name` to `value` (proxy disabled on
    Cloudflare). Once all records resolve, ACM flips the certificate to
    ISSUED and the listener can be created.
  EOT
  value = length(aws_acm_certificate.api) > 0 ? [
    for opt in aws_acm_certificate.api[0].domain_validation_options : {
      name  = opt.resource_record_name
      type  = opt.resource_record_type
      value = opt.resource_record_value
    }
  ] : []
}

output "alb_https_listener_arn" {
  description = "HTTPS:443 listener ARN. Null when TLS is not enabled."
  value       = module.alb.https_listener_arn
}

# ─── Internal (BFF) endpoint via Service Connect ──────────────────────────────

output "service_connect_namespace_arn" {
  description = "ARN of the Cloud Map namespace the BFF joins for Service Connect. Null when disabled."
  value       = var.enable_service_connect ? aws_service_discovery_http_namespace.internal[0].arn : null
}

output "service_connect_namespace_id" {
  description = "ID of the Cloud Map namespace. Null when disabled."
  value       = var.enable_service_connect ? aws_service_discovery_http_namespace.internal[0].id : null
}

output "service_connect_namespace_name" {
  description = "Name of the Cloud Map namespace (e.g. cashyin.internal). Null when disabled."
  value       = var.enable_service_connect ? var.service_connect_namespace_name : null
}

output "bff_core_endpoint" {
  description = "Base URL the BFF uses to reach the Core over Service Connect (e.g. http://api.cashyin.internal). Null when disabled."
  value       = var.enable_service_connect ? (var.service_connect_alias_port == 80 ? "http://${var.service_connect_dns_name}" : "http://${var.service_connect_dns_name}:${var.service_connect_alias_port}") : null
}

output "ecs_cluster_name" {
  description = "ECS cluster name. Use with `aws ecs run-task --cluster <name>` and `aws ecs execute-command`."
  value       = module.ecs.cluster_name
}

output "api_service_name" {
  description = "Name of the API ECS service."
  value       = module.ecs.api_service_name
}

output "api_task_definition_family" {
  description = "Task definition family for the API task; the deploy workflow registers new revisions under this family."
  value       = module.ecs.api_task_definition_family
}

output "migrate_task_definition_family" {
  description = "Task definition family for the one-shot migration task. Pass to `aws ecs run-task --task-definition <family>`."
  value       = module.ecs.migrate_task_definition_family
}

output "log_group_name" {
  description = "CloudWatch log group the API and migration containers ship logs to."
  value       = module.cloudwatch_logs.log_group_name
}

# ─── Workers ──────────────────────────────────────────────────────────────────

output "provider_webhook_worker_service_name" {
  description = "Name of the provider-webhook-worker ECS service. Pass to `aws ecs update-service` to scale or pause."
  value       = module.ecs.provider_webhook_worker_service_name
}

output "provider_webhook_worker_task_definition_family" {
  description = "Task definition family for the provider-webhook-worker. The deploy workflow registers new revisions under this family."
  value       = module.ecs.provider_webhook_worker_task_definition_family
}

output "provider_webhook_worker_log_group_name" {
  description = "CloudWatch log group for the provider-webhook-worker. Use with `aws logs tail`."
  value       = module.cloudwatch_logs_provider_webhook_worker.log_group_name
}

output "webhook_dispatcher_worker_service_name" {
  description = "Name of the webhook-dispatcher-worker ECS service. Pass to `aws ecs update-service` to scale or pause."
  value       = module.ecs.webhook_dispatcher_worker_service_name
}

output "webhook_dispatcher_worker_task_definition_family" {
  description = "Task definition family for the webhook-dispatcher-worker. The deploy workflow registers new revisions under this family."
  value       = module.ecs.webhook_dispatcher_worker_task_definition_family
}

output "webhook_dispatcher_worker_log_group_name" {
  description = "CloudWatch log group for the webhook-dispatcher-worker. Use with `aws logs tail`."
  value       = module.cloudwatch_logs_webhook_dispatcher_worker.log_group_name
}

output "worker_service_names" {
  description = "Convenience map of every worker ECS service name. Iterate over the values in shell scripts."
  value = {
    provider_webhook_worker   = module.ecs.provider_webhook_worker_service_name
    webhook_dispatcher_worker = module.ecs.webhook_dispatcher_worker_service_name
  }
}
