output "vpc_id" {
  description = "ID of the VPC created by this module."
  value       = aws_vpc.this.id
}

output "vpc_cidr_block" {
  description = "CIDR of the VPC, useful for SG references in dependent modules."
  value       = aws_vpc.this.cidr_block
}

output "public_subnet_ids" {
  description = "Public subnet IDs, ordered by AZ index."
  value       = aws_subnet.public[*].id
}

output "private_subnet_ids" {
  description = "Private subnet IDs, ordered by AZ index."
  value       = aws_subnet.private[*].id
}

output "alb_security_group_id" {
  description = "Security group consumed by the public ALB."
  value       = aws_security_group.alb.id
}

output "api_security_group_id" {
  description = "Security group consumed by the API ECS service."
  value       = aws_security_group.api.id
}

output "rds_security_group_id" {
  description = "Security group consumed by the RDS instance."
  value       = aws_security_group.rds.id
}
