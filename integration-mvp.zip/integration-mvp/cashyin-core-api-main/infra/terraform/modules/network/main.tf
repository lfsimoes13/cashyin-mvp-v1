################################################################################
# Network module
#
# Provisions a self-contained VPC for the CashYin Core API:
#
#   * /16 VPC with two public and two private subnets across the supplied AZs.
#   * One Internet Gateway and a single NAT Gateway (baseline cost). Move to
#     per-AZ NAT in production hardening, ref docs/aws-deploy-plan.md §8.
#   * Three security groups (alb, api, rds) wired with the principle of least
#     privilege: rds only accepts ingress from api, api only from alb, alb
#     accepts public ingress on :80 and :443 (TLS is enabled in a later PR).
#
# No default route is created on the private subnets unless var.azs has at
# least one entry; the NAT is placed in the first AZ to keep cross-AZ NAT
# data transfer cost off the bill.
################################################################################

locals {
  # Subnet CIDR layout:
  #   public  → 10.20.0.0/24, 10.20.1.0/24
  #   private → 10.20.10.0/24, 10.20.11.0/24
  public_subnets  = [for i, az in var.azs : cidrsubnet(var.cidr_block, 8, i)]
  private_subnets = [for i, az in var.azs : cidrsubnet(var.cidr_block, 8, i + 10)]

  common_tags = merge(var.tags, {
    Module = "network"
  })
}

resource "aws_vpc" "this" {
  cidr_block           = var.cidr_block
  enable_dns_hostnames = true
  enable_dns_support   = true

  tags = merge(local.common_tags, {
    Name = "${var.name}-vpc"
  })
}

resource "aws_internet_gateway" "this" {
  vpc_id = aws_vpc.this.id

  tags = merge(local.common_tags, {
    Name = "${var.name}-igw"
  })
}

resource "aws_subnet" "public" {
  count                   = length(var.azs)
  vpc_id                  = aws_vpc.this.id
  cidr_block              = local.public_subnets[count.index]
  availability_zone       = var.azs[count.index]
  map_public_ip_on_launch = true

  tags = merge(local.common_tags, {
    Name = "${var.name}-public-${var.azs[count.index]}"
    Tier = "public"
  })
}

resource "aws_subnet" "private" {
  count             = length(var.azs)
  vpc_id            = aws_vpc.this.id
  cidr_block        = local.private_subnets[count.index]
  availability_zone = var.azs[count.index]

  tags = merge(local.common_tags, {
    Name = "${var.name}-private-${var.azs[count.index]}"
    Tier = "private"
  })
}

resource "aws_eip" "nat" {
  domain = "vpc"

  tags = merge(local.common_tags, {
    Name = "${var.name}-nat-eip"
  })
}

resource "aws_nat_gateway" "this" {
  allocation_id = aws_eip.nat.id
  subnet_id     = aws_subnet.public[0].id

  tags = merge(local.common_tags, {
    Name = "${var.name}-nat"
  })

  # NAT Gateway depends implicitly on the IGW being attached. The explicit
  # dependency makes that intent visible to readers.
  depends_on = [aws_internet_gateway.this]
}

# ─── Routing ──────────────────────────────────────────────────────────────────

resource "aws_route_table" "public" {
  vpc_id = aws_vpc.this.id

  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.this.id
  }

  tags = merge(local.common_tags, {
    Name = "${var.name}-public-rt"
    Tier = "public"
  })
}

resource "aws_route_table_association" "public" {
  count          = length(aws_subnet.public)
  subnet_id      = aws_subnet.public[count.index].id
  route_table_id = aws_route_table.public.id
}

resource "aws_route_table" "private" {
  vpc_id = aws_vpc.this.id

  route {
    cidr_block     = "0.0.0.0/0"
    nat_gateway_id = aws_nat_gateway.this.id
  }

  tags = merge(local.common_tags, {
    Name = "${var.name}-private-rt"
    Tier = "private"
  })
}

resource "aws_route_table_association" "private" {
  count          = length(aws_subnet.private)
  subnet_id      = aws_subnet.private[count.index].id
  route_table_id = aws_route_table.private.id
}

# ─── Security groups ──────────────────────────────────────────────────────────

resource "aws_security_group" "alb" {
  name        = "${var.name}-alb"
  description = "Public ALB ingress (80/443) for ${var.name}"
  vpc_id      = aws_vpc.this.id

  ingress {
    description = "HTTP from the Internet"
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    description = "HTTPS from the Internet (used once TLS is enabled)"
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    description = "Allow ALB to reach API targets (and anywhere else; restricted by API SG)"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = merge(local.common_tags, {
    Name = "${var.name}-alb-sg"
  })
}

resource "aws_security_group" "api" {
  name        = "${var.name}-api"
  description = "CashYin Core API task ingress; only the ALB can reach the container port"
  vpc_id      = aws_vpc.this.id

  ingress {
    description     = "API container port from the ALB"
    from_port       = var.api_container_port
    to_port         = var.api_container_port
    protocol        = "tcp"
    security_groups = [aws_security_group.alb.id]
  }

  # East-west (BFF → Core) path for ECS Service Connect. Only present when the
  # endpoint is enabled. Authorise the BFF by SG (preferred, same VPC) and/or
  # by CIDR; both blocks collapse to nothing when their lists are empty.
  dynamic "ingress" {
    for_each = var.enable_service_connect && length(var.service_connect_allowed_security_group_ids) > 0 ? [1] : []
    content {
      description     = "API container port from the BFF (Service Connect, by SG)"
      from_port       = var.api_container_port
      to_port         = var.api_container_port
      protocol        = "tcp"
      security_groups = var.service_connect_allowed_security_group_ids
    }
  }

  dynamic "ingress" {
    for_each = var.enable_service_connect && length(var.service_connect_allowed_cidr_blocks) > 0 ? [1] : []
    content {
      description = "API container port from the BFF (Service Connect, by CIDR)"
      from_port   = var.api_container_port
      to_port     = var.api_container_port
      protocol    = "tcp"
      cidr_blocks = var.service_connect_allowed_cidr_blocks
    }
  }

  egress {
    description = "Outbound to RDS, Secrets Manager, Bents and ECR"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = merge(local.common_tags, {
    Name = "${var.name}-api-sg"
  })
}

resource "aws_security_group" "rds" {
  name        = "${var.name}-rds"
  description = "PostgreSQL ingress only from API tasks"
  vpc_id      = aws_vpc.this.id

  ingress {
    description     = "PostgreSQL from API SG"
    from_port       = 5432
    to_port         = 5432
    protocol        = "tcp"
    security_groups = [aws_security_group.api.id]
  }

  # No egress is required for the database; default-deny by omitting an
  # explicit egress rule would block outbound, which RDS does not need. We
  # leave a permissive egress so future RDS extensions (e.g. logical
  # replication, RDS Proxy connections) keep working.
  egress {
    description = "Outbound (rare; e.g. internal RDS calls)"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = merge(local.common_tags, {
    Name = "${var.name}-rds-sg"
  })
}
