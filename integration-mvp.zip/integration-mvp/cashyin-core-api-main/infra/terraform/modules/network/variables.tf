variable "name" {
  description = "Project/environment name prefix applied to every resource."
  type        = string
}

variable "cidr_block" {
  description = "VPC CIDR. /16 leaves plenty of room for future subnets and peering."
  type        = string
  default     = "10.20.0.0/16"
  validation {
    condition     = can(cidrnetmask(var.cidr_block))
    error_message = "cidr_block must be a valid IPv4 CIDR."
  }
}

variable "azs" {
  description = "Availability zones to deploy public and private subnets into. Two AZs is the minimum required by ALB."
  type        = list(string)
  validation {
    condition     = length(var.azs) >= 2
    error_message = "At least two AZs are required."
  }
}

variable "api_container_port" {
  description = "Port the Fastify container listens on. Used to authorise ALB → API SG ingress."
  type        = number
  default     = 3000
}

# ─── Internal (BFF) endpoint via ECS Service Connect ──────────────────────────
#
# When the BFF talks to the Core over the VPC using ECS Service Connect, traffic
# flows directly between the BFF and Core task ENIs (no internal ALB). The Core
# API task SG must therefore allow inbound on the container port from the BFF's
# SG and/or CIDR. Keeping this rule in the network module (which owns every SG
# with inline rules) avoids the inline/standalone rule conflict.

variable "enable_service_connect" {
  description = <<-EOT
    When `true`, authorise the BFF to reach the API container port directly
    (the east-west path used by ECS Service Connect). The Cloud Map namespace
    and the service_connect_configuration live in the ecs module / environment;
    this flag only governs the API SG ingress. Default `false` keeps the API
    reachable only from the public ALB.
  EOT
  type        = bool
  default     = false
}

variable "service_connect_allowed_security_group_ids" {
  description = <<-EOT
    Security group IDs allowed to reach the API container port for the BFF
    east-west path (e.g. the BFF ECS service SG). Only consulted when
    `enable_service_connect = true`. Preferred over CIDR when the BFF runs in
    this VPC.
  EOT
  type        = list(string)
  default     = []
}

variable "service_connect_allowed_cidr_blocks" {
  description = <<-EOT
    CIDR blocks allowed to reach the API container port for the BFF east-west
    path (e.g. the BFF subnet ranges). Only consulted when
    `enable_service_connect = true`.
  EOT
  type        = list(string)
  default     = []
}

variable "tags" {
  description = "Tags merged onto every taggable resource."
  type        = map(string)
  default     = {}
}
