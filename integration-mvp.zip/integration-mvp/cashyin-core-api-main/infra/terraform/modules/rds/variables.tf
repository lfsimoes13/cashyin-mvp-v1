variable "name" {
  description = "Resource name prefix (e.g. cashyin-core-api)."
  type        = string
}

variable "subnet_ids" {
  description = "Private subnet IDs the DB subnet group spans. At least two AZs are required by RDS."
  type        = list(string)
  validation {
    condition     = length(var.subnet_ids) >= 2
    error_message = "RDS DB subnet group requires at least two subnets across distinct AZs."
  }
}

variable "vpc_security_group_ids" {
  description = "List of security group IDs to attach to the RDS instance. Pass the dedicated RDS SG from the network module."
  type        = list(string)
}

variable "engine_version" {
  description = "PostgreSQL major version. RDS auto-picks the latest minor at creation; `auto_minor_version_upgrade = true` keeps it up to date."
  type        = string
  default     = "16"
}

variable "instance_class" {
  description = "RDS instance class. db.t4g.micro is the Graviton equivalent of t3.micro and is the cheapest Postgres 16 class."
  type        = string
  default     = "db.t4g.micro"
}

variable "allocated_storage" {
  description = "Initial allocated storage in GiB."
  type        = number
  default     = 20
}

variable "max_allocated_storage" {
  description = "Storage autoscaling ceiling in GiB. RDS grows the volume up to this value automatically."
  type        = number
  default     = 100
}

variable "database_name" {
  description = "Initial database name created at instance launch."
  type        = string
  default     = "cashyin"
}

variable "master_username" {
  description = "Master DB user. Cannot be `admin`, `rdsadmin`, `postgres`, etc."
  type        = string
  default     = "cashyin_admin"
}

variable "multi_az" {
  description = "Enable Multi-AZ. Doubles the cost; off by default for baseline."
  type        = bool
  default     = false
}

variable "backup_retention_period" {
  description = "Days to retain automated backups (1-35). 7 is the default sweet spot."
  type        = number
  default     = 7
}

variable "backup_window" {
  description = "Daily UTC backup window. Defaults to 06:00-07:00 UTC (03:00-04:00 BRT)."
  type        = string
  default     = "06:00-07:00"
}

variable "maintenance_window" {
  description = "Weekly UTC maintenance window. Defaults to Sun 07:30-08:30 UTC (04:30-05:30 BRT Sunday)."
  type        = string
  default     = "sun:07:30-sun:08:30"
}

variable "deletion_protection" {
  description = "Block accidental destroy. Off for baseline so we can teardown freely; flip to true in real prod."
  type        = bool
  default     = false
}

variable "skip_final_snapshot" {
  description = "Skip the final snapshot on destroy. True for baseline; flip to false in real prod."
  type        = bool
  default     = true
}

variable "performance_insights_enabled" {
  description = "Enable Performance Insights. Free for 7-day retention; useful for load tests."
  type        = bool
  default     = true
}

variable "performance_insights_retention_period" {
  description = "Performance Insights retention in days. 7 is the free tier; longer is paid."
  type        = number
  default     = 7
}

variable "apply_immediately" {
  description = "Apply changes immediately rather than waiting for the maintenance window. True for baseline."
  type        = bool
  default     = true
}

variable "secret_name" {
  description = "Name of the Secrets Manager secret that will hold the assembled DATABASE_URL."
  type        = string
}

variable "secret_recovery_window_days" {
  description = "Days the secret stays in the soft-delete state before being permanently removed. 0 = no recovery window."
  type        = number
  default     = 7
}

variable "tags" {
  description = "Tags merged onto every taggable resource."
  type        = map(string)
  default     = {}
}
