output "endpoint" {
  description = "RDS endpoint (host:port). Use `address` if you need only the host."
  value       = aws_db_instance.this.endpoint
}

output "address" {
  description = "RDS hostname without port."
  value       = aws_db_instance.this.address
}

output "port" {
  description = "RDS port."
  value       = aws_db_instance.this.port
}

output "database_name" {
  description = "Initial database name."
  value       = aws_db_instance.this.db_name
}

output "instance_arn" {
  description = "RDS instance ARN."
  value       = aws_db_instance.this.arn
}

output "instance_identifier" {
  description = "RDS instance identifier (used for snapshots, console search)."
  value       = aws_db_instance.this.identifier
}

output "database_url_secret_arn" {
  description = "ARN of the Secrets Manager secret holding the assembled DATABASE_URL."
  value       = aws_secretsmanager_secret.database_url.arn
}

output "database_url_secret_name" {
  description = "Name of the DATABASE_URL secret."
  value       = aws_secretsmanager_secret.database_url.name
}
