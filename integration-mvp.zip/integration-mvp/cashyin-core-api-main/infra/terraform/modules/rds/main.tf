################################################################################
# RDS module
#
# Single-instance PostgreSQL 16 for the CashYin Core API baseline. Stores
# the resulting connection string in Secrets Manager so the ECS task
# definition (added in PR #3) can inject it as the `DATABASE_URL` env var
# without the value ever travelling through git or CI logs.
#
# Trade-offs documented in the README hardening checklist:
#   * Master password is generated via `random_password` and ends up in
#     Terraform state. State is SSE-S3 encrypted at rest and the bucket
#     enforces TLS-in-transit, but anyone who can read state can read the
#     password. Hardening = migrate to `manage_master_user_password = true`
#     (AWS-managed, auto-rotated) plus an init container that assembles
#     DATABASE_URL at task start.
#   * Single-AZ, deletion_protection=false, skip_final_snapshot=true so
#     baseline can be destroyed cheaply during iteration.
################################################################################

# A custom DB parameter group lets us pin connection-relevant defaults
# without flipping them in the AWS console. Family must match the engine
# major version, otherwise RDS refuses to attach it.
resource "aws_db_parameter_group" "this" {
  name        = "${var.name}-pg16"
  family      = "postgres16"
  description = "Parameter group for ${var.name} (Postgres 16)"

  # Force every new connection to use TLS so the API container (and any
  # operator psql) cannot accidentally land on a cleartext channel.
  parameter {
    name  = "rds.force_ssl"
    value = "1"
  }

  # Log every statement that runs longer than 1s. Useful while we tune
  # indexes during the load test; we can tighten or disable later.
  parameter {
    name  = "log_min_duration_statement"
    value = "1000"
  }

  tags = merge(var.tags, {
    Module = "rds"
  })
}

resource "aws_db_subnet_group" "this" {
  name        = "${var.name}-db-subnet-group"
  description = "Subnet group for ${var.name} RDS instance"
  subnet_ids  = var.subnet_ids

  tags = merge(var.tags, {
    Module = "rds"
  })
}

resource "random_password" "master" {
  length  = 32
  special = true
  # RDS Postgres disallows /, @, " and spaces in the master password.
  # Excluding `=` too because some libpq URI encoders mishandle it.
  override_special = "!#$%&*()-_+[]{}<>?"
}

resource "aws_db_instance" "this" {
  identifier     = var.name
  engine         = "postgres"
  engine_version = var.engine_version
  instance_class = var.instance_class

  allocated_storage     = var.allocated_storage
  max_allocated_storage = var.max_allocated_storage
  storage_type          = "gp3"
  storage_encrypted     = true

  db_name  = var.database_name
  username = var.master_username
  password = random_password.master.result
  port     = 5432

  db_subnet_group_name   = aws_db_subnet_group.this.name
  vpc_security_group_ids = var.vpc_security_group_ids
  parameter_group_name   = aws_db_parameter_group.this.name
  publicly_accessible    = false

  multi_az                    = var.multi_az
  backup_retention_period     = var.backup_retention_period
  backup_window               = var.backup_window
  maintenance_window          = var.maintenance_window
  auto_minor_version_upgrade  = true
  allow_major_version_upgrade = false

  performance_insights_enabled          = var.performance_insights_enabled
  performance_insights_retention_period = var.performance_insights_enabled ? var.performance_insights_retention_period : null

  deletion_protection       = var.deletion_protection
  skip_final_snapshot       = var.skip_final_snapshot
  final_snapshot_identifier = var.skip_final_snapshot ? null : "${var.name}-final-${formatdate("YYYY-MM-DD-hh-mm", timestamp())}"

  apply_immediately = var.apply_immediately

  enabled_cloudwatch_logs_exports = ["postgresql", "upgrade"]

  tags = merge(var.tags, {
    Module = "rds"
  })

  # `timestamp()` in final_snapshot_identifier changes every plan and would
  # otherwise force a perpetual diff. We only care about it at destroy
  # time, so ignore changes to the field.
  lifecycle {
    ignore_changes = [final_snapshot_identifier]
  }
}

# ─── DATABASE_URL secret ──────────────────────────────────────────────────────
#
# Store the assembled URL in Secrets Manager. The ECS task definition in
# PR #3 references `${secret_arn}:::` (full value) and maps it onto the
# `DATABASE_URL` env var. We keep `?sslmode=require` because the parameter
# group forces SSL and node-pg honours the URL query string for client
# behaviour.

resource "aws_secretsmanager_secret" "database_url" {
  name                    = var.secret_name
  description             = "PostgreSQL connection string for ${var.name}"
  recovery_window_in_days = var.secret_recovery_window_days

  tags = merge(var.tags, {
    Module = "rds"
  })
}

resource "aws_secretsmanager_secret_version" "database_url" {
  secret_id = aws_secretsmanager_secret.database_url.id

  # postgresql://user:pass@host:port/dbname?sslmode=require
  # The password may contain URL-special characters, so we urlencode it.
  secret_string = format(
    "postgresql://%s:%s@%s:%d/%s?sslmode=require",
    var.master_username,
    urlencode(random_password.master.result),
    aws_db_instance.this.address,
    aws_db_instance.this.port,
    var.database_name
  )
}
