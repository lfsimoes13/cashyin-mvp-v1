variable "name_prefix" {
  description = "Prefix for every secret name (e.g. cashyin/prod-baseline). Each secret appends a leaf identifier."
  type        = string
}

variable "recovery_window_days" {
  description = "Days a deleted secret stays in soft-delete before being purged. 0 disables the recovery window."
  type        = number
  default     = 7
}

variable "secrets" {
  description = <<EOT
Map of secrets to provision. Each key becomes part of the secret name
(`<name_prefix>/<key>`) and the value carries optional metadata.

We deliberately do NOT take an initial secret value here, so credentials
never travel through Terraform state. Populate values after apply via:

    aws secretsmanager put-secret-value \
      --secret-id "<secret_name>" \
      --secret-string "<value>"
EOT
  type = map(object({
    description = optional(string, "")
  }))
  default = {}
}

variable "tags" {
  description = "Tags merged onto every taggable resource."
  type        = map(string)
  default     = {}
}
