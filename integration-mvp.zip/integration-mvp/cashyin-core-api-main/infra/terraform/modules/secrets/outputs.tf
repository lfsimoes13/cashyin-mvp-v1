output "secret_arns" {
  description = "Map of <leaf-key> → secret ARN. Pass to the ECS task role policy and to the task definition's `secrets` block."
  value = {
    for k, s in aws_secretsmanager_secret.this : k => s.arn
  }
}

output "secret_names" {
  description = "Map of <leaf-key> → secret name. Useful for CLI operations (`aws secretsmanager get-secret-value --secret-id <name>`)."
  value = {
    for k, s in aws_secretsmanager_secret.this : k => s.name
  }
}
