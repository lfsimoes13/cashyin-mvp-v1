################################################################################
# Secrets module
#
# Creates empty Secrets Manager secrets for credentials that must never
# travel through Terraform state. The operator (or a deploy job) writes
# the actual value via `aws secretsmanager put-secret-value` after apply.
#
# The ECS task definition (PR #3) references these secrets by ARN; the
# task role gets `secretsmanager:GetSecretValue` scoped to exactly these
# ARNs so the blast radius is small.
################################################################################

resource "aws_secretsmanager_secret" "this" {
  for_each = var.secrets

  name                    = "${var.name_prefix}/${each.key}"
  description             = each.value.description
  recovery_window_in_days = var.recovery_window_days

  tags = merge(var.tags, {
    Module = "secrets"
    Leaf   = each.key
  })
}
