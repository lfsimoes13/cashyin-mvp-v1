################################################################################
# ECS module
#
# Provisions:
#   * An ECS Fargate cluster.
#   * Execution role (consumed by Fargate to pull the image, fetch
#     Secrets Manager secrets and write logs).
#   * Task role (consumed by the container at runtime; ECS Exec needs
#     the ssmmessages.* actions on the task role).
#   * Two task definitions sharing the same image:
#       - `api`: long-running Fastify server, registered with the ALB
#         target group via the service.
#       - `migrate`: one-shot CMD = `node scripts/migrate.mjs`, run via
#         `aws ecs run-task` before flipping the API service to a new
#         image tag.
#   * ECS service running the API task definition behind the ALB. The
#     service ignores task_definition diffs so subsequent deploys from
#     the GitHub Actions workflow can update the image without Terraform
#     fighting them.
################################################################################

data "aws_caller_identity" "current" {}

# Account ARN partition prefix used in IAM policy resources. AWS commercial
# regions are `aws`; GovCloud is `aws-us-gov`. We hardcode `aws` since
# sa-east-1 is commercial.
locals {
  account_id = data.aws_caller_identity.current.account_id
  partition  = "aws"
  full_image = "${var.image_repository_url}:${var.image_tag}"
  awslogs_cfg = {
    "awslogs-group"         = var.log_group_name
    "awslogs-region"        = var.aws_region
    "awslogs-stream-prefix" = "ecs"
  }
}

resource "aws_ecs_cluster" "this" {
  name = var.name

  setting {
    name  = "containerInsights"
    value = "enabled"
  }

  tags = merge(var.tags, {
    Module = "ecs"
  })
}

resource "aws_ecs_cluster_capacity_providers" "this" {
  cluster_name       = aws_ecs_cluster.this.name
  capacity_providers = ["FARGATE", "FARGATE_SPOT"]

  default_capacity_provider_strategy {
    capacity_provider = "FARGATE"
    weight            = 1
    base              = 1
  }
}

# ─── Execution role ───────────────────────────────────────────────────────────
#
# Used by the Fargate agent (not by your container). It must pull the
# image from ECR, fetch secrets from Secrets Manager and ship logs to
# CloudWatch before the container starts. The AWS-managed
# AmazonECSTaskExecutionRolePolicy covers ECR auth + logs:CreateLogStream
# + logs:PutLogEvents; we add a custom policy for Secrets Manager scoped
# to the three secret ARNs.

data "aws_iam_policy_document" "execution_assume" {
  statement {
    actions = ["sts:AssumeRoleWithWebIdentity", "sts:AssumeRole"]

    principals {
      type        = "Service"
      identifiers = ["ecs-tasks.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "execution" {
  name               = "${var.name}-ecs-execution"
  assume_role_policy = data.aws_iam_policy_document.execution_assume.json
  description        = "Fargate execution role for ${var.name}"

  tags = merge(var.tags, {
    Module = "ecs"
  })
}

resource "aws_iam_role_policy_attachment" "execution_managed" {
  role       = aws_iam_role.execution.name
  policy_arn = "arn:${local.partition}:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy"
}

data "aws_iam_policy_document" "execution_secrets" {
  statement {
    sid     = "GetSecretValueScoped"
    actions = ["secretsmanager:GetSecretValue", "secretsmanager:DescribeSecret"]
    resources = concat([
      var.database_url_secret_arn,
      var.bents_api_key_secret_arn,
      var.bents_webhook_secret_secret_arn
    ], local.bff_shared_secret_arns)
  }
}

resource "aws_iam_role_policy" "execution_secrets" {
  name   = "${var.name}-ecs-execution-secrets"
  role   = aws_iam_role.execution.id
  policy = data.aws_iam_policy_document.execution_secrets.json
}

# ─── Task role ────────────────────────────────────────────────────────────────
#
# Used by the container at runtime. The Fastify app does not need any
# AWS API call today (DATABASE_URL and Bents credentials arrive as env
# vars injected by the execution role). We still create the role so we
# can grant the SSM messages actions that ECS Exec relies on.

resource "aws_iam_role" "task" {
  name               = "${var.name}-ecs-task"
  assume_role_policy = data.aws_iam_policy_document.execution_assume.json
  description        = "Runtime task role for ${var.name}"

  tags = merge(var.tags, {
    Module = "ecs"
  })
}

data "aws_iam_policy_document" "task_runtime" {
  # ECS Exec channel. Without these, `aws ecs execute-command` fails with
  # InvalidParameterException ("the activation could not be authorised").
  statement {
    sid = "EcsExecChannel"
    actions = [
      "ssmmessages:CreateControlChannel",
      "ssmmessages:CreateDataChannel",
      "ssmmessages:OpenControlChannel",
      "ssmmessages:OpenDataChannel"
    ]
    resources = ["*"]
  }

  # Belt + braces: let the container ship its own logs even though the
  # execution role normally owns the stream. Useful when debugging
  # init-container behaviour.
  statement {
    sid = "LogsWrite"
    actions = [
      "logs:CreateLogStream",
      "logs:PutLogEvents"
    ]
    resources = [
      "${var.log_group_arn}:*"
    ]
  }
}

resource "aws_iam_role_policy" "task_runtime" {
  name   = "${var.name}-ecs-task-runtime"
  role   = aws_iam_role.task.id
  policy = data.aws_iam_policy_document.task_runtime.json
}

# ─── Container definitions ───────────────────────────────────────────────────
#
# Both task definitions share the same image; only `command`, CPU and
# memory differ between the long-running API task and the one-shot
# migration task.

locals {
  # Only wire the BFF shared secret into the task (and the execution-role
  # GetSecretValue scope) when an ARN is supplied. The caller passes "" until
  # `bff_auth_mode = "enforce"`, so the task never references an empty secret.
  bff_shared_secret_arns = var.bff_shared_secret_secret_arn != "" ? [var.bff_shared_secret_secret_arn] : []

  api_environment = [
    { name = "NODE_ENV", value = "production" },
    { name = "PORT", value = tostring(var.container_port) },
    { name = "LOG_LEVEL", value = "info" },
    { name = "API_BASE_URL", value = var.api_base_url },
    { name = "BENTS_API_BASE_URL", value = var.bents_api_base_url },
    { name = "BENTS_WEBHOOK_AUTH_MODE", value = var.bents_webhook_auth_mode },
    { name = "BENTS_WEBHOOK_REQUIRE_SIGNATURE", value = tostring(var.bents_webhook_require_signature) },
    { name = "DEFAULT_PROVIDER", value = "bents" },
    { name = "REQUEST_TIMEOUT_MS", value = tostring(var.request_timeout_ms) },
    { name = "METRICS_ENABLED", value = tostring(var.metrics_enabled) },
    { name = "METRICS_PATH", value = var.metrics_path },
    { name = "CLIENT_WEBHOOK_TIMEOUT_MS", value = tostring(var.client_webhook_timeout_ms) },
    { name = "CLIENT_WEBHOOK_CRITICAL_TIMEOUT_MS", value = tostring(var.client_webhook_critical_timeout_ms) },
    { name = "RATE_LIMIT_MAX", value = tostring(var.rate_limit_max) },
    { name = "RATE_LIMIT_WINDOW", value = var.rate_limit_window },
    { name = "BFF_AUTH_MODE", value = var.bff_auth_mode },
    { name = "AUTH_ENFORCEMENT_MODE", value = var.auth_enforcement_mode },
    { name = "API_HMAC_MODE", value = var.api_hmac_mode },
    { name = "BFF_RBAC_MODE", value = var.bff_rbac_mode },
    { name = "CASHOUT_STEPUP_MODE", value = var.cashout_stepup_mode }
  ]

  api_secrets = concat([
    { name = "DATABASE_URL", valueFrom = var.database_url_secret_arn },
    { name = "BENTS_API_KEY", valueFrom = var.bents_api_key_secret_arn },
    { name = "BENTS_WEBHOOK_SECRET", valueFrom = var.bents_webhook_secret_secret_arn }
    ], [
    for arn in local.bff_shared_secret_arns : { name = "BFF_SHARED_SECRET", valueFrom = arn }
  ])
}

resource "aws_ecs_task_definition" "api" {
  family                   = "${var.name}-api"
  network_mode             = "awsvpc"
  requires_compatibilities = ["FARGATE"]
  cpu                      = tostring(var.api_cpu)
  memory                   = tostring(var.api_memory)
  execution_role_arn       = aws_iam_role.execution.arn
  task_role_arn            = aws_iam_role.task.arn

  runtime_platform {
    cpu_architecture        = "X86_64"
    operating_system_family = "LINUX"
  }

  container_definitions = jsonencode([
    {
      name        = "api"
      image       = local.full_image
      essential   = true
      cpu         = 0
      stopTimeout = 30

      # `name` + `appProtocol` are required for ECS Service Connect to reference
      # this port. Harmless when Service Connect is disabled. Adding them
      # registers a new task-definition revision on first apply (the service
      # ignores task_definition, so it propagates on the next deploy — see the
      # Service Connect rollout note in infra/README.md).
      portMappings = [
        {
          name          = var.service_connect_port_name
          containerPort = var.container_port
          protocol      = "tcp"
          appProtocol   = "http"
        }
      ]

      environment = local.api_environment
      secrets     = local.api_secrets

      healthCheck = {
        command = [
          "CMD-SHELL",
          "node -e \"fetch('http://127.0.0.1:${var.container_port}/health').then(r=>{process.exit(r.ok?0:1)}).catch(()=>{process.exit(1)})\""
        ]
        interval    = 20
        timeout     = 5
        retries     = 3
        startPeriod = 15
      }

      logConfiguration = {
        logDriver = "awslogs"
        options = merge(local.awslogs_cfg, {
          "awslogs-stream-prefix" = "api"
        })
      }
    }
  ])

  tags = merge(var.tags, {
    Module = "ecs"
  })
}

resource "aws_ecs_task_definition" "migrate" {
  family                   = "${var.name}-migrate"
  network_mode             = "awsvpc"
  requires_compatibilities = ["FARGATE"]
  cpu                      = tostring(var.migrate_cpu)
  memory                   = tostring(var.migrate_memory)
  execution_role_arn       = aws_iam_role.execution.arn
  task_role_arn            = aws_iam_role.task.arn

  runtime_platform {
    cpu_architecture        = "X86_64"
    operating_system_family = "LINUX"
  }

  container_definitions = jsonencode([
    {
      name      = "migrate"
      image     = local.full_image
      essential = true
      cpu       = 0
      command   = ["node", "scripts/migrate.mjs"]

      environment = [
        { name = "NODE_ENV", value = "production" }
      ]

      secrets = [
        { name = "DATABASE_URL", valueFrom = var.database_url_secret_arn }
      ]

      logConfiguration = {
        logDriver = "awslogs"
        options = merge(local.awslogs_cfg, {
          "awslogs-stream-prefix" = "migrate"
        })
      }
    }
  ])

  tags = merge(var.tags, {
    Module = "ecs"
  })
}

# ─── Service ─────────────────────────────────────────────────────────────────

resource "aws_ecs_service" "api" {
  name            = "${var.name}-api"
  cluster         = aws_ecs_cluster.this.id
  task_definition = aws_ecs_task_definition.api.arn
  desired_count   = var.api_desired_count
  launch_type     = "FARGATE"

  # Lets us shell into a running container via
  #   aws ecs execute-command --cluster ... --task ... --command "/bin/sh" --interactive
  enable_execute_command = true

  network_configuration {
    subnets          = var.private_subnet_ids
    security_groups  = [var.security_group_id]
    assign_public_ip = false
  }

  load_balancer {
    target_group_arn = var.target_group_arn
    container_name   = "api"
    container_port   = var.container_port
  }

  # Service Connect: register the API into the Cloud Map namespace so the BFF
  # can reach it east-west (managed mTLS, retries, telemetry) without an extra
  # ALB. The public ALB above keeps serving api_direct/external traffic.
  dynamic "service_connect_configuration" {
    for_each = var.enable_service_connect ? [1] : []
    content {
      enabled   = true
      namespace = var.service_connect_namespace_arn

      service {
        port_name      = var.service_connect_port_name
        discovery_name = var.service_connect_discovery_name

        client_alias {
          dns_name = var.service_connect_dns_name
          port     = var.service_connect_alias_port
        }
      }

      dynamic "log_configuration" {
        for_each = var.service_connect_log_group_name != null ? [1] : []
        content {
          log_driver = "awslogs"
          options = {
            "awslogs-group"         = var.service_connect_log_group_name
            "awslogs-region"        = var.aws_region
            "awslogs-stream-prefix" = "service-connect"
          }
        }
      }
    }
  }

  deployment_minimum_healthy_percent = 100
  deployment_maximum_percent         = 200

  # Wait an extra minute for the API to boot before failing health checks.
  # Bents client warm-up + DB pool prime take ~5-10s.
  health_check_grace_period_seconds = 60

  # The deploy workflow (PR #3) registers new task definition revisions
  # and calls UpdateService; we explicitly ignore those fields so a
  # subsequent `terraform apply` does not roll back the deployed image.
  lifecycle {
    ignore_changes = [task_definition, desired_count]
  }

  depends_on = [
    aws_iam_role_policy.execution_secrets,
    aws_iam_role_policy.task_runtime
  ]

  tags = merge(var.tags, {
    Module = "ecs"
  })
}
