variable "name" {
  description = "Resource name prefix (e.g. cashyin-core-api)."
  type        = string
}

variable "aws_region" {
  description = "AWS region. Used to construct the awslogs region in the container definition."
  type        = string
}

variable "private_subnet_ids" {
  description = "Private subnet IDs the ECS service places tasks into."
  type        = list(string)
}

variable "security_group_id" {
  description = "Security group for API tasks (the api SG from the network module)."
  type        = string
}

variable "target_group_arn" {
  description = "Public ALB target group ARN the service registers with."
  type        = string
}

# ─── ECS Service Connect (BFF east-west path) ─────────────────────────────────
#
# When enabled, the API service is registered into a Cloud Map namespace via
# ECS Service Connect so the BFF (a Service-Connect-enabled ECS service in the
# same VPC/namespace) can reach it at a stable internal name with managed mTLS,
# retries and telemetry — no internal ALB. See docs/auth/bff-integration-guide.md.

variable "enable_service_connect" {
  description = <<-EOT
    Master switch for Service Connect on the API service. When `true`, the
    service joins `service_connect_namespace_arn` and advertises itself under
    `service_connect_dns_name`. Requires the running task definition to expose
    the named port `service_connect_port_name` (added to the API container
    below) — see the rollout note in infra/README.md. Default `false` leaves
    the service single-homed on the public ALB.
  EOT
  type        = bool
  default     = false
}

variable "service_connect_namespace_arn" {
  description = "ARN of the Cloud Map (HTTP) namespace the API service joins. Required when enable_service_connect = true."
  type        = string
  default     = null
}

variable "service_connect_port_name" {
  description = "Name assigned to the API container's port mapping; referenced by the Service Connect service block."
  type        = string
  default     = "api"
}

variable "service_connect_discovery_name" {
  description = "Service Connect discovery name (must be unique within the namespace)."
  type        = string
  default     = "core-api"
}

variable "service_connect_dns_name" {
  description = "Hostname client services (the BFF) use to reach the API over Service Connect (e.g. api.cashyin.internal)."
  type        = string
  default     = "api.cashyin.internal"
}

variable "service_connect_alias_port" {
  description = "Port clients dial on service_connect_dns_name (e.g. 80 so the BFF calls http://api.cashyin.internal/v1/...)."
  type        = number
  default     = 80
}

variable "service_connect_log_group_name" {
  description = "Optional CloudWatch log group name for the Service Connect proxy access logs. Null disables proxy logging."
  type        = string
  default     = null
}

variable "image_repository_url" {
  description = "Full ECR registry URL (acct.dkr.ecr.region.amazonaws.com/repo)."
  type        = string
}

variable "image_tag" {
  description = "Image tag to run on first apply. Subsequent updates come from the deploy workflow."
  type        = string
}

variable "container_port" {
  description = "Container port the API listens on."
  type        = number
  default     = 3000
}

variable "api_cpu" {
  description = "CPU units allocated to the API task (256, 512, 1024, ...)."
  type        = number
  default     = 512
}

variable "api_memory" {
  description = "Memory MiB allocated to the API task."
  type        = number
  default     = 1024
}

variable "api_desired_count" {
  description = "Number of API tasks the service keeps running."
  type        = number
  default     = 2
}

variable "migrate_cpu" {
  description = "CPU units allocated to the one-shot migration task."
  type        = number
  default     = 256
}

variable "migrate_memory" {
  description = "Memory MiB allocated to the migration task."
  type        = number
  default     = 512
}

variable "log_group_name" {
  description = "CloudWatch log group name the containers ship logs to."
  type        = string
}

variable "log_group_arn" {
  description = "CloudWatch log group ARN, used to scope the task role's logs:PutLogEvents permission."
  type        = string
}

variable "database_url_secret_arn" {
  description = "Secrets Manager ARN for the assembled DATABASE_URL."
  type        = string
}

variable "bents_api_key_secret_arn" {
  description = "Secrets Manager ARN for the Bents API key."
  type        = string
}

variable "bents_webhook_secret_secret_arn" {
  description = "Secrets Manager ARN for the Bents webhook signing secret."
  type        = string
}

variable "bff_shared_secret_secret_arn" {
  description = <<-EOT
    Secrets Manager ARN for `BFF_SHARED_SECRET` (the secret the trusted BFF
    presents in `X-CashYin-BFF-Token`). Injected into the API task **only**
    when non-empty — the caller gates this on `bff_auth_mode = "enforce"` so
    the task never references an unpopulated secret. The execution role is
    granted `GetSecretValue` on this ARN only when it is set.
  EOT
  type        = string
  default     = ""
}

variable "api_base_url" {
  description = "Public base URL the API advertises. Defaults to the ALB DNS name (no TLS yet)."
  type        = string
}

variable "bents_api_base_url" {
  description = "Upstream Bents API base URL."
  type        = string
  default     = "https://finance.bents.com.br/api/v2/public"
}

variable "bents_webhook_auth_mode" {
  description = <<-EOT
    Webhook authentication strategy applied to inbound Bents callbacks.
    `'none'` (default) wires `NoVerificationWebhookAuthStrategy` —
    appropriate when the upstream portal doesn't issue a signing
    secret. `'hmac'` wires `Sha256HmacWebhookAuthStrategy`, which
    requires `BENTS_WEBHOOK_SECRET` and validates `X-Bents-Signature`.
  EOT
  type        = string
  default     = "none"
  validation {
    condition     = contains(["none", "hmac"], var.bents_webhook_auth_mode)
    error_message = "bents_webhook_auth_mode must be one of: none, hmac."
  }
}

variable "bents_webhook_require_signature" {
  description = <<-EOT
    Only consulted when `bents_webhook_auth_mode = "hmac"`. When `true`
    (default) the HMAC strategy rejects requests without a verifiable
    signature. When `false`, accepts unsigned but still verifies the
    HMAC whenever both the secret and a well-formed signature header
    are present.
  EOT
  type        = bool
  default     = true
}

# ─── Auth enforcement (BFF channel + api_direct scopes/HMAC) ──────────────────
#
# These map 1:1 onto the Zod-validated env in src/shared/config/env.ts. All
# default to the safe "off"/"shadow"-capable posture; the environment sets the
# real values via tfvars. `BFF_SHARED_SECRET` is required by the app (boot-time
# Zod refine) whenever `bff_auth_mode = "enforce"`, so populate the secret
# before flipping enforce.

variable "bff_auth_mode" {
  description = "BFF_AUTH_MODE. `enforce` accepts/verifies X-CashYin-BFF-Token (frontend_bff channel); `off` ignores it. Requires the BFF shared secret populated."
  type        = string
  default     = "off"
  validation {
    condition     = contains(["off", "enforce"], var.bff_auth_mode)
    error_message = "bff_auth_mode must be one of: off, enforce."
  }
}

variable "auth_enforcement_mode" {
  description = "AUTH_ENFORCEMENT_MODE — scope gate on /v1/pix/*. `shadow` measures without denying; `enforce` denies missing scopes."
  type        = string
  default     = "off"
  validation {
    condition     = contains(["off", "shadow", "enforce"], var.auth_enforcement_mode)
    error_message = "auth_enforcement_mode must be one of: off, shadow, enforce."
  }
}

variable "api_hmac_mode" {
  description = "API_HMAC_MODE — request signing for the api_direct channel. `off` ignores signatures; `shadow` verifies+logs; `enforce` requires a valid signature (keys need signing_secret)."
  type        = string
  default     = "off"
  validation {
    condition     = contains(["off", "shadow", "enforce"], var.api_hmac_mode)
    error_message = "api_hmac_mode must be one of: off, shadow, enforce."
  }
}

variable "bff_rbac_mode" {
  description = "BFF_RBAC_MODE — per-user RBAC for the BFF channel. `enforce` requires bff_auth_mode=enforce and provisioned user_client_grants."
  type        = string
  default     = "off"
  validation {
    condition     = contains(["off", "enforce"], var.bff_rbac_mode)
    error_message = "bff_rbac_mode must be one of: off, enforce."
  }
}

variable "cashout_stepup_mode" {
  description = "CASHOUT_STEPUP_MODE — step-up (2FA) for human-initiated cash-out. `shadow` logs would-be denials; `enforce` requires a valid proof."
  type        = string
  default     = "off"
  validation {
    condition     = contains(["off", "shadow", "enforce"], var.cashout_stepup_mode)
    error_message = "cashout_stepup_mode must be one of: off, shadow, enforce."
  }
}

variable "rate_limit_max" {
  description = "Fastify @fastify/rate-limit max requests per window."
  type        = number
  default     = 600
}

variable "rate_limit_window" {
  description = "Fastify @fastify/rate-limit time window (Fastify accepts strings like \"1 minute\")."
  type        = string
  default     = "1 minute"
}

variable "request_timeout_ms" {
  description = "Outbound provider request timeout in milliseconds."
  type        = number
  default     = 5000
}

variable "metrics_enabled" {
  description = "Enable the internal Prometheus-format metrics endpoint."
  type        = bool
  default     = true
}

variable "metrics_path" {
  description = "Path exposed by the API for Prometheus-format metrics."
  type        = string
  default     = "/internal/metrics"
}

variable "client_webhook_timeout_ms" {
  description = "Default outbound client webhook timeout in milliseconds."
  type        = number
  default     = 5000
}

variable "client_webhook_critical_timeout_ms" {
  description = "Outbound client webhook timeout in milliseconds for critical cash-in paid events."
  type        = number
  default     = 2500
}

# ─── Workers (provider-webhook + webhook-dispatcher) ──────────────────────────
#
# Both workers run as separate ECS services off the same Docker image
# as the API. They share the cluster, execution role and task role with
# the API but write to dedicated CloudWatch log groups (passed in by the
# environment) so on-call can split log streams by concern.

variable "provider_webhook_worker_log_group_name" {
  description = "CloudWatch log group name for the provider webhook processor worker."
  type        = string
}

variable "provider_webhook_worker_log_group_arn" {
  description = "CloudWatch log group ARN for the provider webhook processor worker."
  type        = string
}

variable "webhook_dispatcher_worker_log_group_name" {
  description = "CloudWatch log group name for the public webhook dispatcher worker."
  type        = string
}

variable "webhook_dispatcher_worker_log_group_arn" {
  description = "CloudWatch log group ARN for the public webhook dispatcher worker."
  type        = string
}

variable "provider_webhook_worker_desired_count" {
  description = "Number of provider-webhook-worker tasks the service keeps running. Set to 0 to pause the worker in an emergency."
  type        = number
  default     = 1
  validation {
    condition     = var.provider_webhook_worker_desired_count >= 0
    error_message = "provider_webhook_worker_desired_count must be >= 0."
  }
}

variable "provider_webhook_worker_cpu" {
  description = "CPU units allocated to each provider-webhook-worker task."
  type        = number
  default     = 256
}

variable "provider_webhook_worker_memory" {
  description = "Memory MiB allocated to each provider-webhook-worker task."
  type        = number
  default     = 512
}

variable "webhook_dispatcher_worker_desired_count" {
  description = "Number of webhook-dispatcher-worker tasks the service keeps running. Set to 0 to pause outbound webhook deliveries in an emergency."
  type        = number
  default     = 1
  validation {
    condition     = var.webhook_dispatcher_worker_desired_count >= 0
    error_message = "webhook_dispatcher_worker_desired_count must be >= 0."
  }
}

variable "webhook_dispatcher_worker_cpu" {
  description = "CPU units allocated to each webhook-dispatcher-worker task."
  type        = number
  default     = 256
}

variable "webhook_dispatcher_worker_memory" {
  description = "Memory MiB allocated to each webhook-dispatcher-worker task."
  type        = number
  default     = 512
}

variable "worker_busy_interval_ms" {
  description = "WORKER_BUSY_INTERVAL_MS — sleep between ticks that processed work."
  type        = number
  default     = 50
}

variable "worker_idle_interval_ms" {
  description = "WORKER_IDLE_INTERVAL_MS — initial sleep after the first idle tick. Keep low because LISTEN/NOTIFY is additive and polling is the fallback."
  type        = number
  default     = 200
}

variable "worker_max_idle_interval_ms" {
  description = "WORKER_MAX_IDLE_INTERVAL_MS — cap for the exponential backoff applied to consecutive idle ticks."
  type        = number
  default     = 5000
}

variable "worker_error_backoff_ms" {
  description = "WORKER_ERROR_BACKOFF_MS — initial sleep after a tick threw."
  type        = number
  default     = 5000
}

variable "worker_max_error_backoff_ms" {
  description = "WORKER_MAX_ERROR_BACKOFF_MS — cap for the exponential backoff applied to consecutive errored ticks."
  type        = number
  default     = 60000
}

variable "worker_shutdown_timeout_ms" {
  description = "WORKER_SHUTDOWN_TIMEOUT_MS — max time stop() waits for the in-flight tick after SIGTERM. Must be < ECS stopTimeout."
  type        = number
  default     = 15000
  validation {
    condition     = var.worker_shutdown_timeout_ms < 30000
    error_message = "worker_shutdown_timeout_ms must be < 30000 so the worker exits cleanly before ECS stopTimeout=30s SIGKILLs it."
  }
}

variable "tags" {
  description = "Tags merged onto every taggable resource."
  type        = map(string)
  default     = {}
}
