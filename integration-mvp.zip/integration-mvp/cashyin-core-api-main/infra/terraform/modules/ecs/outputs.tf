output "cluster_arn" {
  description = "ECS cluster ARN."
  value       = aws_ecs_cluster.this.arn
}

output "cluster_name" {
  description = "ECS cluster name. Use with `aws ecs run-task --cluster <name>`."
  value       = aws_ecs_cluster.this.name
}

output "api_service_arn" {
  description = "ECS service ARN consumed by the deploy workflow's `aws ecs update-service` call."
  value       = aws_ecs_service.api.id
}

output "api_service_name" {
  description = "ECS service name."
  value       = aws_ecs_service.api.name
}

output "api_task_definition_family" {
  description = "Task definition family for the API task. Used by `aws ecs register-task-definition` in the deploy workflow."
  value       = aws_ecs_task_definition.api.family
}

output "api_task_definition_arn" {
  description = "Initial task definition ARN created by Terraform."
  value       = aws_ecs_task_definition.api.arn
}

output "migrate_task_definition_family" {
  description = "Task definition family for the one-shot migration task."
  value       = aws_ecs_task_definition.migrate.family
}

output "migrate_task_definition_arn" {
  description = "Migration task definition ARN. Pass to `aws ecs run-task --task-definition <arn>`."
  value       = aws_ecs_task_definition.migrate.arn
}

output "execution_role_arn" {
  description = "ARN of the Fargate execution role."
  value       = aws_iam_role.execution.arn
}

output "task_role_arn" {
  description = "ARN of the task role assumed by the container at runtime."
  value       = aws_iam_role.task.arn
}

# ─── Workers ─────────────────────────────────────────────────────────────────

output "provider_webhook_worker_service_name" {
  description = "Name of the provider-webhook-worker ECS service."
  value       = aws_ecs_service.provider_webhook_worker.name
}

output "provider_webhook_worker_service_arn" {
  description = "ARN of the provider-webhook-worker ECS service."
  value       = aws_ecs_service.provider_webhook_worker.id
}

output "provider_webhook_worker_task_definition_family" {
  description = "Task definition family for the provider-webhook-worker. The deploy workflow registers new revisions under this family."
  value       = aws_ecs_task_definition.provider_webhook_worker.family
}

output "provider_webhook_worker_task_definition_arn" {
  description = "Initial provider-webhook-worker task definition ARN created by Terraform."
  value       = aws_ecs_task_definition.provider_webhook_worker.arn
}

output "webhook_dispatcher_worker_service_name" {
  description = "Name of the webhook-dispatcher-worker ECS service."
  value       = aws_ecs_service.webhook_dispatcher_worker.name
}

output "webhook_dispatcher_worker_service_arn" {
  description = "ARN of the webhook-dispatcher-worker ECS service."
  value       = aws_ecs_service.webhook_dispatcher_worker.id
}

output "webhook_dispatcher_worker_task_definition_family" {
  description = "Task definition family for the webhook-dispatcher-worker."
  value       = aws_ecs_task_definition.webhook_dispatcher_worker.family
}

output "webhook_dispatcher_worker_task_definition_arn" {
  description = "Initial webhook-dispatcher-worker task definition ARN created by Terraform."
  value       = aws_ecs_task_definition.webhook_dispatcher_worker.arn
}
