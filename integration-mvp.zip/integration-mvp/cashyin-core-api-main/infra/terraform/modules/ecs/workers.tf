################################################################################
# Worker task definitions + services
#
# Two long-running background workers run alongside the API:
#
#   1. provider-webhook-worker   →  drains `webhook_events` and applies
#                                   domain handlers (PaymentService /
#                                   CashoutService). Without this process
#                                   inbound provider webhooks stay
#                                   `pending` forever.
#   2. webhook-dispatcher-worker →  drains `outbox_events` and POSTs the
#                                   signed envelope to each client
#                                   endpoint. Without this process
#                                   outbound public webhooks never reach
#                                   clients.
#
# Each worker:
#   * runs the SAME Docker image as the API, with a different `command`
#     so a single build promotes all three processes atomically;
#   * shares the cluster, execution role and task role with the API —
#     the AWS-managed AmazonECSTaskExecutionRolePolicy already grants
#     ECR pull + logs:CreateLogStream + logs:PutLogEvents on `*`, and
#     the secret access policy is scoped to the same three ARNs the
#     workers need (DATABASE_URL, BENTS_API_KEY, BENTS_WEBHOOK_SECRET);
#   * writes to a DEDICATED CloudWatch log group provisioned by the
#     environment, so on-call can split streams by concern;
#   * has NO load balancer attachment, NO portMappings, NO container
#     healthCheck (ECS treats the task as healthy while the process is
#     alive — the WorkerLoop never exits unless SIGINT/SIGTERM is
#     received or the container.close() throws);
#   * has `stopTimeout = 30` (the awslogs hard cap) and the application
#     respects WORKER_SHUTDOWN_TIMEOUT_MS < 30s before the agent
#     SIGKILLs the process.
#
# The services pin `desired_count` via a variable so an operator can
# pause a worker in an emergency by setting it to 0 and re-applying
# Terraform (or by calling `aws ecs update-service --desired-count 0`).
# The `ignore_changes = [task_definition, desired_count]` lifecycle
# mirrors the API service so the deploy workflow can roll new images
# without Terraform fighting it.
################################################################################

locals {
  # Worker-only env vars. Most knobs sit in src/shared/config/env.ts
  # with sensible defaults, but we still pin them here so a tfvars
  # tweak survives container restarts without code changes.
  worker_only_environment = [
    { name = "WORKER_BUSY_INTERVAL_MS", value = tostring(var.worker_busy_interval_ms) },
    { name = "WORKER_IDLE_INTERVAL_MS", value = tostring(var.worker_idle_interval_ms) },
    { name = "WORKER_MAX_IDLE_INTERVAL_MS", value = tostring(var.worker_max_idle_interval_ms) },
    { name = "WORKER_ERROR_BACKOFF_MS", value = tostring(var.worker_error_backoff_ms) },
    { name = "WORKER_MAX_ERROR_BACKOFF_MS", value = tostring(var.worker_max_error_backoff_ms) },
    { name = "WORKER_SHUTDOWN_TIMEOUT_MS", value = tostring(var.worker_shutdown_timeout_ms) }
  ]

  # Strip API-only env vars (PORT, RATE_LIMIT_*) from the shared block.
  # The workers never bind a port nor invoke the rate limiter, so
  # carrying those env vars is harmless but noisy.
  worker_shared_environment = [
    for entry in local.api_environment :
    entry if !contains(["PORT", "RATE_LIMIT_MAX", "RATE_LIMIT_WINDOW"], entry.name)
  ]

  worker_environment = concat(local.worker_shared_environment, local.worker_only_environment)

  # Same secrets block as the API: workers need DATABASE_URL for every
  # tick, BENTS_API_KEY for any reconciliation/refetch the cashout
  # handler may need, and BENTS_WEBHOOK_SECRET in case future inbound
  # processors call back into the verifier.
  worker_secrets = local.api_secrets
}

# ─── Extend the task role with write access to the worker log groups ─────────
#
# The AWS-managed AmazonECSTaskExecutionRolePolicy on the execution
# role already covers awslogs delivery on `*`. The task role's
# "LogsWrite" statement was scoped to the API log group only — extend
# it to the worker log groups so anything the container itself logs
# (e.g. via aws-sdk inside the runtime, future code paths) is also
# allowed. Defence-in-depth, not strictly required for awslogs.

data "aws_iam_policy_document" "task_runtime_workers" {
  source_policy_documents = [data.aws_iam_policy_document.task_runtime.json]

  statement {
    sid = "WorkerLogsWrite"
    actions = [
      "logs:CreateLogStream",
      "logs:PutLogEvents"
    ]
    resources = [
      "${var.provider_webhook_worker_log_group_arn}:*",
      "${var.webhook_dispatcher_worker_log_group_arn}:*"
    ]
  }
}

resource "aws_iam_role_policy" "task_runtime_workers" {
  name   = "${var.name}-ecs-task-runtime-workers"
  role   = aws_iam_role.task.id
  policy = data.aws_iam_policy_document.task_runtime_workers.json
}

# ─── provider-webhook-worker ─────────────────────────────────────────────────

resource "aws_ecs_task_definition" "provider_webhook_worker" {
  family                   = "${var.name}-provider-webhook-worker"
  network_mode             = "awsvpc"
  requires_compatibilities = ["FARGATE"]
  cpu                      = tostring(var.provider_webhook_worker_cpu)
  memory                   = tostring(var.provider_webhook_worker_memory)
  execution_role_arn       = aws_iam_role.execution.arn
  task_role_arn            = aws_iam_role.task.arn

  runtime_platform {
    cpu_architecture        = "X86_64"
    operating_system_family = "LINUX"
  }

  container_definitions = jsonencode([
    {
      name        = "provider-webhook-worker"
      image       = local.full_image
      essential   = true
      cpu         = 0
      stopTimeout = 30
      command     = ["node", "dist/src/main-provider-webhook-worker.js"]

      environment = local.worker_environment
      secrets     = local.worker_secrets

      logConfiguration = {
        logDriver = "awslogs"
        options = {
          "awslogs-group"         = var.provider_webhook_worker_log_group_name
          "awslogs-region"        = var.aws_region
          "awslogs-stream-prefix" = "provider-webhook-worker"
        }
      }
    }
  ])

  tags = merge(var.tags, {
    Module = "ecs"
    Role   = "provider-webhook-worker"
  })
}

resource "aws_ecs_service" "provider_webhook_worker" {
  name            = "${var.name}-provider-webhook-worker"
  cluster         = aws_ecs_cluster.this.id
  task_definition = aws_ecs_task_definition.provider_webhook_worker.arn
  desired_count   = var.provider_webhook_worker_desired_count
  launch_type     = "FARGATE"

  enable_execute_command = true

  network_configuration {
    subnets          = var.private_subnet_ids
    security_groups  = [var.security_group_id]
    assign_public_ip = false
  }

  # Workers can be rolled aggressively — there is no LB draining and
  # the work queue claims survive a restart (FOR UPDATE SKIP LOCKED).
  # A maximum_percent = 200 lets the deploy spin up the new task
  # before the old one stops, minimising queue lag during deploys.
  deployment_minimum_healthy_percent = 100
  deployment_maximum_percent         = 200

  lifecycle {
    ignore_changes = [task_definition, desired_count]
  }

  depends_on = [
    aws_iam_role_policy.execution_secrets,
    aws_iam_role_policy.task_runtime,
    aws_iam_role_policy.task_runtime_workers
  ]

  tags = merge(var.tags, {
    Module = "ecs"
    Role   = "provider-webhook-worker"
  })
}

# ─── webhook-dispatcher-worker ───────────────────────────────────────────────

resource "aws_ecs_task_definition" "webhook_dispatcher_worker" {
  family                   = "${var.name}-webhook-dispatcher-worker"
  network_mode             = "awsvpc"
  requires_compatibilities = ["FARGATE"]
  cpu                      = tostring(var.webhook_dispatcher_worker_cpu)
  memory                   = tostring(var.webhook_dispatcher_worker_memory)
  execution_role_arn       = aws_iam_role.execution.arn
  task_role_arn            = aws_iam_role.task.arn

  runtime_platform {
    cpu_architecture        = "X86_64"
    operating_system_family = "LINUX"
  }

  container_definitions = jsonencode([
    {
      name        = "webhook-dispatcher-worker"
      image       = local.full_image
      essential   = true
      cpu         = 0
      stopTimeout = 30
      command     = ["node", "dist/src/main-webhook-dispatcher-worker.js"]

      environment = local.worker_environment
      secrets     = local.worker_secrets

      logConfiguration = {
        logDriver = "awslogs"
        options = {
          "awslogs-group"         = var.webhook_dispatcher_worker_log_group_name
          "awslogs-region"        = var.aws_region
          "awslogs-stream-prefix" = "webhook-dispatcher-worker"
        }
      }
    }
  ])

  tags = merge(var.tags, {
    Module = "ecs"
    Role   = "webhook-dispatcher-worker"
  })
}

resource "aws_ecs_service" "webhook_dispatcher_worker" {
  name            = "${var.name}-webhook-dispatcher-worker"
  cluster         = aws_ecs_cluster.this.id
  task_definition = aws_ecs_task_definition.webhook_dispatcher_worker.arn
  desired_count   = var.webhook_dispatcher_worker_desired_count
  launch_type     = "FARGATE"

  enable_execute_command = true

  network_configuration {
    subnets          = var.private_subnet_ids
    security_groups  = [var.security_group_id]
    assign_public_ip = false
  }

  deployment_minimum_healthy_percent = 100
  deployment_maximum_percent         = 200

  lifecycle {
    ignore_changes = [task_definition, desired_count]
  }

  depends_on = [
    aws_iam_role_policy.execution_secrets,
    aws_iam_role_policy.task_runtime,
    aws_iam_role_policy.task_runtime_workers
  ]

  tags = merge(var.tags, {
    Module = "ecs"
    Role   = "webhook-dispatcher-worker"
  })
}
