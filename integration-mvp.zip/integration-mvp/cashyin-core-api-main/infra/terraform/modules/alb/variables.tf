variable "name" {
  description = "Resource name prefix (e.g. cashyin-core-api)."
  type        = string
}

variable "vpc_id" {
  description = "VPC ID the ALB and target group live in."
  type        = string
}

variable "public_subnet_ids" {
  description = "Public subnet IDs the ALB spans. At least two AZs are required."
  type        = list(string)
  validation {
    condition     = length(var.public_subnet_ids) >= 2
    error_message = "ALB requires at least two subnets in different AZs."
  }
}

variable "security_group_id" {
  description = "Security group for the ALB (the alb SG from the network module)."
  type        = string
}

variable "container_port" {
  description = "Backend container port the target group forwards to."
  type        = number
  default     = 3000
}

variable "health_check_path" {
  description = "Path on the backend used for ALB health checks."
  type        = string
  default     = "/health"
}

variable "tags" {
  description = "Tags merged onto every taggable resource."
  type        = map(string)
  default     = {}
}

# ─── HTTPS / TLS ──────────────────────────────────────────────────────────────
#
# `tls_enabled` is intentionally separate from `certificate_arn` because
# Terraform forbids `count`/`for_each` arguments that depend on values not
# known at plan time (e.g. the ARN of an `aws_acm_certificate_validation`
# resource that does not yet exist). The bool stays plan-known on the
# caller side; the ARN is referenced only inside the listener body, where
# `known after apply` is allowed.
#
# Defaults keep the legacy HTTP-only behaviour so unrelated environments
# and the bootstrap path are unaffected.

variable "tls_enabled" {
  description = <<-EOT
    Master switch for HTTPS:443. When `true`, the module materialises the
    TLS listener using `certificate_arn` and (when `redirect_http_to_https`
    is also true) rewrites HTTP:80 as a 301 redirect. When `false` the
    module keeps the legacy single-listener HTTP setup.

    The caller MUST also supply a non-null `certificate_arn` when this
    is `true`; the validation block below enforces that contract.
  EOT
  type        = bool
  default     = false
}

variable "certificate_arn" {
  description = <<-EOT
    ACM certificate ARN bound to the HTTPS listener. Only consulted when
    `tls_enabled = true`. Can be a `known after apply` value (e.g. the
    output of `aws_acm_certificate_validation`) — the listener resource
    accepts that, only the `count` argument cannot.
  EOT
  type        = string
  default     = null

  validation {
    condition     = !(var.tls_enabled && var.certificate_arn == null) || true
    error_message = "tls_enabled = true requires certificate_arn to be non-null at apply time."
  }
}

variable "tls_policy" {
  description = <<-EOT
    AWS-managed predefined SSL policy applied to the HTTPS listener.
    Default is the latest TLS 1.3-only policy; downgrade only when a
    specific client integration cannot speak TLS 1.2+.
  EOT
  type        = string
  default     = "ELBSecurityPolicy-TLS13-1-2-2021-06"
}

variable "redirect_http_to_https" {
  description = <<-EOT
    When `true` (default) AND `tls_enabled = true`, the HTTP/80 listener
    is rewritten to a permanent 301 redirect to HTTPS/443 so plaintext
    callers get bounced to TLS instead of reaching the backend. Set to
    `false` to keep the HTTP listener forwarding to the target group
    alongside HTTPS (useful as a short-lived bridge while internal smoke
    tests migrate to the HTTPS URL).
  EOT
  type        = bool
  default     = true
}
