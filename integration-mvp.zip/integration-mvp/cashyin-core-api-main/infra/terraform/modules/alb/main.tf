################################################################################
# ALB module
#
# Public Application Load Balancer fronting the ECS Fargate service.
#
# Listener topology is driven by `var.tls_enabled`:
#
#   * `tls_enabled = false` (default / bootstrap path):
#       - Listener 80 forwards to the target group.
#       - No 443 listener.
#       - Used during initial bring-up before a domain / ACM cert exists.
#
#   * `tls_enabled = true` (caller must also pass `certificate_arn`):
#       - Listener 443 forwards to the target group over TLS using
#         `var.tls_policy`.
#       - Listener 80 either redirects to HTTPS (default, controlled by
#         `var.redirect_http_to_https`) or keeps forwarding to the
#         target group alongside HTTPS.
#
# Target group is `target_type = "ip"` because Fargate awsvpc tasks
# register their ENI IPs, not EC2 instances.
################################################################################

locals {
  http_redirects    = var.tls_enabled && var.redirect_http_to_https
  http_listener_tag = local.http_redirects ? "redirect" : "forward"
}

resource "aws_lb" "this" {
  name               = "${var.name}-alb"
  load_balancer_type = "application"
  internal           = false
  subnets            = var.public_subnet_ids
  security_groups    = [var.security_group_id]

  # Strip headers that smuggle CRLFs or otherwise violate HTTP/1.1. Cheap,
  # safe, on by default in newer ALB versions but pinned here for clarity.
  drop_invalid_header_fields = true

  enable_http2               = true
  enable_deletion_protection = false # baseline; flip to true for real prod
  idle_timeout               = 60

  tags = merge(var.tags, {
    Module = "alb"
    Name   = "${var.name}-alb"
  })
}

resource "aws_lb_target_group" "api" {
  name        = "${var.name}-api"
  port        = var.container_port
  protocol    = "HTTP"
  vpc_id      = var.vpc_id
  target_type = "ip"

  health_check {
    enabled             = true
    path                = var.health_check_path
    matcher             = "200"
    protocol            = "HTTP"
    port                = "traffic-port"
    interval            = 15
    timeout             = 5
    healthy_threshold   = 2
    unhealthy_threshold = 3
  }

  # 30s is enough for the API to drain in-flight requests on rolling
  # deploys without holding the deploy hostage for the default 300s.
  deregistration_delay = 30

  tags = merge(var.tags, {
    Module = "alb"
  })
}

resource "aws_lb_listener" "http" {
  load_balancer_arn = aws_lb.this.arn
  port              = 80
  protocol          = "HTTP"

  # `dynamic` blocks let us swap the default action between forward and
  # redirect without recreating the listener: when TLS is enabled and
  # `redirect_http_to_https=true` the listener becomes a permanent 301 to
  # HTTPS:443; otherwise it keeps forwarding to the target group.
  dynamic "default_action" {
    for_each = local.http_redirects ? [1] : []
    content {
      type = "redirect"
      redirect {
        protocol    = "HTTPS"
        port        = "443"
        status_code = "HTTP_301"
        # host/path/query default to "#{host}", "/#{path}" and "#{query}"
        # so the redirect preserves the original URL.
      }
    }
  }

  dynamic "default_action" {
    for_each = local.http_redirects ? [] : [1]
    content {
      type             = "forward"
      target_group_arn = aws_lb_target_group.api.arn
    }
  }

  tags = merge(var.tags, {
    Module     = "alb"
    HttpAction = local.http_listener_tag
  })
}

resource "aws_lb_listener" "https" {
  count             = var.tls_enabled ? 1 : 0
  load_balancer_arn = aws_lb.this.arn
  port              = 443
  protocol          = "HTTPS"
  ssl_policy        = var.tls_policy
  certificate_arn   = var.certificate_arn

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.api.arn
  }

  tags = merge(var.tags, {
    Module = "alb"
  })
}
