output "alb_arn" {
  description = "ALB ARN."
  value       = aws_lb.this.arn
}

output "alb_dns_name" {
  description = "Public DNS name. Until TLS is enabled, point smoke tests at http://<dns_name>."
  value       = aws_lb.this.dns_name
}

output "alb_zone_id" {
  description = "Route 53 zone ID for the ALB (used by alias records once a domain is registered)."
  value       = aws_lb.this.zone_id
}

output "target_group_arn" {
  description = "Target group ARN. Pass to the ECS service load_balancer block."
  value       = aws_lb_target_group.api.arn
}

output "target_group_name" {
  description = "Target group name."
  value       = aws_lb_target_group.api.name
}

output "https_listener_arn" {
  description = "HTTPS:443 listener ARN. Null when TLS is not enabled."
  value       = length(aws_lb_listener.https) > 0 ? aws_lb_listener.https[0].arn : null
}

output "tls_enabled" {
  description = "True when the ALB is fronting HTTPS:443; false on the bootstrap HTTP-only path."
  value       = length(aws_lb_listener.https) > 0
}
