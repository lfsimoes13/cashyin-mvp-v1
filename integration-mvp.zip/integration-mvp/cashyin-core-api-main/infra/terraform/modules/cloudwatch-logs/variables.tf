variable "log_group_name" {
  description = "CloudWatch log group name. Convention: /<project>/<env>/<workload>."
  type        = string
}

variable "retention_in_days" {
  description = "Log retention. 7 days is the cheap baseline; bump for incident forensics."
  type        = number
  default     = 7
  validation {
    condition = contains(
      [0, 1, 3, 5, 7, 14, 30, 60, 90, 120, 150, 180, 365, 400, 545, 731, 1827, 2192, 2557, 2922, 3288, 3653],
      var.retention_in_days
    )
    error_message = "retention_in_days must be one of the AWS-permitted values."
  }
}

variable "tags" {
  description = "Tags merged onto every taggable resource."
  type        = map(string)
  default     = {}
}
