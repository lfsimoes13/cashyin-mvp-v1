output "log_group_name" {
  description = "Log group name. Pass to the ECS task definition's logConfiguration.awslogs-group."
  value       = aws_cloudwatch_log_group.this.name
}

output "log_group_arn" {
  description = "Log group ARN. Use it to scope IAM policies granting PutLogEvents."
  value       = aws_cloudwatch_log_group.this.arn
}
