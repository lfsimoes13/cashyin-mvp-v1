################################################################################
# CloudWatch Logs module
#
# Plain log group consumed by ECS Fargate tasks. AWS-managed encryption,
# bounded retention. Hardening = customer-managed KMS key per log group.
################################################################################

resource "aws_cloudwatch_log_group" "this" {
  name              = var.log_group_name
  retention_in_days = var.retention_in_days

  tags = merge(var.tags, {
    Module = "cloudwatch-logs"
  })
}
