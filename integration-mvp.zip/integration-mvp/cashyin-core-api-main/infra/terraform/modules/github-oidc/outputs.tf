output "role_arn" {
  description = "ARN of the deploy role; configure GitHub Actions with role-to-assume = this value."
  value       = aws_iam_role.deploy.arn
}

output "role_name" {
  description = "Name of the deploy role."
  value       = aws_iam_role.deploy.name
}

output "oidc_provider_arn" {
  description = "ARN of the OIDC provider the role trusts."
  value       = local.oidc_provider_arn
}
