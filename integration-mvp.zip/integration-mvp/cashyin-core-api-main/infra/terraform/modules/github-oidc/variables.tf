variable "github_repository" {
  description = "Repository in `<owner>/<repo>` form (e.g. area-bank/cashyin-core-api)."
  type        = string
  validation {
    condition     = can(regex("^[^/]+/[^/]+$", var.github_repository))
    error_message = "github_repository must be in 'owner/repo' form."
  }
}

variable "role_name" {
  description = "Name of the IAM role GitHub Actions assumes via OIDC."
  type        = string
}

variable "allowed_subjects" {
  description = <<EOT
Patterns for the `token.actions.githubusercontent.com:sub` claim. Default
allows `refs/heads/main` and any tag from the configured repository.
EOT
  type        = list(string)
  default     = null
}

variable "create_oidc_provider" {
  description = "Whether to create the AWS IAM OIDC provider. Set to false if the account already trusts token.actions.githubusercontent.com from another stack."
  type        = bool
  default     = true
}

variable "existing_oidc_provider_arn" {
  description = "ARN of an existing OIDC provider to reuse when create_oidc_provider = false."
  type        = string
  default     = null
}

variable "ecr_repository_arn" {
  description = "ARN of the ECR repository the role is allowed to push and pull."
  type        = string
}

variable "tags" {
  description = "Tags merged onto every taggable resource."
  type        = map(string)
  default     = {}
}

