################################################################################
# GitHub Actions OIDC role
#
# Lets a GitHub Actions workflow assume an IAM role in this AWS account
# without any static credentials. The trust is scoped to a specific repo and
# branch (typically area-bank/cashyin-core-api on refs/heads/main) so a fork
# or feature branch cannot impersonate the deploy role.
#
# Permissions attached here are deliberately the minimum required to:
#   * Authenticate to ECR.
#   * Push and pull images on the CashYin Core API repository.
#
# Every subsequent module (ECS, RDS, etc.) extends this role explicitly via
# additional aws_iam_role_policy resources, so the blast radius of a leaked
# OIDC token is auditable in Terraform diff.
################################################################################

# The OIDC provider is created once per AWS account. If you have already
# wired GitHub Actions to this account via another stack, set
# var.create_oidc_provider = false and pass in the existing provider's ARN
# via var.existing_oidc_provider_arn so we reuse it instead of failing the
# apply with EntityAlreadyExists.
locals {
  oidc_provider_arn = var.create_oidc_provider ? aws_iam_openid_connect_provider.github[0].arn : var.existing_oidc_provider_arn

  default_allowed_subjects = [
    "repo:${var.github_repository}:ref:refs/heads/main",
    "repo:${var.github_repository}:ref:refs/tags/*"
  ]

  resolved_allowed_subjects = coalesce(var.allowed_subjects, local.default_allowed_subjects)
}

resource "aws_iam_openid_connect_provider" "github" {
  count = var.create_oidc_provider ? 1 : 0

  url            = "https://token.actions.githubusercontent.com"
  client_id_list = ["sts.amazonaws.com"]
  # AWS no longer enforces thumbprint validation for the GitHub OIDC
  # endpoint, but the field is still required by the API. The value is the
  # documented well-known thumbprint of the root CA used by GitHub Actions.
  thumbprint_list = ["6938fd4d98bab03faadb97b34396831e3780aea1"]

  tags = merge(var.tags, {
    Module = "github-oidc"
  })
}

data "aws_iam_policy_document" "trust" {
  statement {
    actions = ["sts:AssumeRoleWithWebIdentity"]

    principals {
      type        = "Federated"
      identifiers = [local.oidc_provider_arn]
    }

    condition {
      test     = "StringEquals"
      variable = "token.actions.githubusercontent.com:aud"
      values   = ["sts.amazonaws.com"]
    }

    # Restrict to the configured repo + ref pattern. Default pattern below
    # matches main and any tags so a `git push --tags` from the release job
    # can also assume the role; tighten further if you adopt a different
    # release workflow.
    condition {
      test     = "StringLike"
      variable = "token.actions.githubusercontent.com:sub"
      values   = local.resolved_allowed_subjects
    }
  }
}

resource "aws_iam_role" "deploy" {
  name               = var.role_name
  assume_role_policy = data.aws_iam_policy_document.trust.json
  description        = "GitHub Actions deploy role for ${var.github_repository}"

  tags = merge(var.tags, {
    Module = "github-oidc"
  })
}

# ─── Minimum policy: ECR auth + push/pull on the project repo ─────────────────

data "aws_iam_policy_document" "ecr_push" {
  statement {
    sid       = "EcrAuthToken"
    actions   = ["ecr:GetAuthorizationToken"]
    resources = ["*"]
  }

  statement {
    sid = "EcrPushPull"
    actions = [
      "ecr:BatchCheckLayerAvailability",
      "ecr:BatchGetImage",
      "ecr:CompleteLayerUpload",
      "ecr:DescribeImages",
      "ecr:DescribeRepositories",
      "ecr:GetDownloadUrlForLayer",
      "ecr:InitiateLayerUpload",
      "ecr:PutImage",
      "ecr:UploadLayerPart",
      "ecr:ListImages"
    ]
    resources = [var.ecr_repository_arn]
  }
}

resource "aws_iam_role_policy" "ecr_push" {
  name   = "${var.role_name}-ecr-push"
  role   = aws_iam_role.deploy.id
  policy = data.aws_iam_policy_document.ecr_push.json
}
