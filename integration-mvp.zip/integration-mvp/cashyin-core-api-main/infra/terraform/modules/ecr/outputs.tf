output "repository_url" {
  description = "Full repository URL (acct.dkr.ecr.region.amazonaws.com/repo). The deploy pipeline appends :<sha>."
  value       = aws_ecr_repository.this.repository_url
}

output "repository_arn" {
  description = "Repository ARN, consumed by IAM policies that grant ECR push to the deploy role."
  value       = aws_ecr_repository.this.arn
}

output "repository_name" {
  description = "Repository name (without the registry prefix)."
  value       = aws_ecr_repository.this.name
}
