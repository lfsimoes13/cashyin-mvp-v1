################################################################################
# ECR module
#
# Private ECR repository for the CashYin Core API container.
#
#   * Image tag immutability ON. We never overwrite a tag; the deploy
#     pipeline pushes images named after the commit SHA.
#   * Image scanning ON push (cheap; AWS-managed scanner).
#   * Encryption AES-256 (KMS CMK is left for production hardening).
#   * Lifecycle policy keeps the latest var.max_image_count images and
#     deletes anything untagged that is older than 7 days, so an aborted
#     build cannot accumulate orphaned layers.
################################################################################

resource "aws_ecr_repository" "this" {
  name                 = var.repository_name
  image_tag_mutability = "IMMUTABLE"

  image_scanning_configuration {
    scan_on_push = true
  }

  encryption_configuration {
    encryption_type = "AES256"
  }

  tags = merge(var.tags, {
    Module = "ecr"
  })
}

resource "aws_ecr_lifecycle_policy" "this" {
  repository = aws_ecr_repository.this.name

  policy = jsonencode({
    rules = [
      {
        rulePriority = 1
        description  = "Expire untagged images after 7 days"
        selection = {
          tagStatus   = "untagged"
          countType   = "sinceImagePushed"
          countUnit   = "days"
          countNumber = 7
        }
        action = {
          type = "expire"
        }
      },
      {
        rulePriority = 2
        description  = "Keep at most ${var.max_image_count} tagged images"
        selection = {
          tagStatus      = "tagged"
          tagPatternList = ["*"]
          countType      = "imageCountMoreThan"
          countNumber    = var.max_image_count
        }
        action = {
          type = "expire"
        }
      }
    ]
  })
}
