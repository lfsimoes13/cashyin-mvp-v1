variable "repository_name" {
  description = "ECR repository name; the deploy pipeline pushes <repo>:<sha>."
  type        = string
}

variable "max_image_count" {
  description = "Number of tagged images to retain before the lifecycle policy expires the oldest."
  type        = number
  default     = 20
}

variable "tags" {
  description = "Tags merged onto every taggable resource."
  type        = map(string)
  default     = {}
}
