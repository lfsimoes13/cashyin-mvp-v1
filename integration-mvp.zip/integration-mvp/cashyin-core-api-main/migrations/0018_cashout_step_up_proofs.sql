-- ============================================================================
-- 0018 — cashout_step_up_proofs
-- ============================================================================
--
-- Persists per-operation step-up (second-factor) proofs for human-initiated
-- cash-outs (see docs/adr/auth-authorization-boundary.md). The trusted BFF
-- performs the MFA challenge with the human, mints a proof bound to the exact
-- cash-out via `transaction_hash`, then presents the proof id on the cash-out
-- request. The Core consumes the proof atomically (single-use) when the hash,
-- tenant, status and expiry all match.
--
--   * `transaction_hash` — SHA-256 over the canonical cash-out parameters
--                          (client + amount + destination + external_ref).
--                          Binds the proof to one operation so it cannot be
--                          replayed against a different transfer.
--   * `status`           — 'issued' → 'consumed'. The consume UPDATE only
--                          matches 'issued' rows, giving single-use semantics
--                          without an explicit lock.
--   * `expires_at`       — short TTL (CASHOUT_STEPUP_TTL_MS). Expired proofs
--                          are treated as missing.
--
-- No data-path behaviour changes until CASHOUT_STEPUP_MODE is switched on.
-- ============================================================================

CREATE TABLE IF NOT EXISTS cashout_step_up_proofs (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id        UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  actor_user_id    TEXT,
  transaction_hash TEXT NOT NULL,
  amr              TEXT[] NOT NULL DEFAULT '{}',
  status           TEXT NOT NULL DEFAULT 'issued'
    CHECK (status IN ('issued', 'consumed')),
  issued_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at       TIMESTAMPTZ NOT NULL,
  consumed_at      TIMESTAMPTZ
);

-- Consume/peek lookups are by (id, client_id) filtered on status; the partial
-- index keeps the hot set (still-issued proofs) small.
CREATE INDEX IF NOT EXISTS idx_cashout_step_up_proofs_issued
  ON cashout_step_up_proofs (client_id, id)
  WHERE status = 'issued';
