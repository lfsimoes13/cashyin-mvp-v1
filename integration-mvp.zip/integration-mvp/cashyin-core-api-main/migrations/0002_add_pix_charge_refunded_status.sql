-- Add the `refunded` value to the `pix_charge_status` enum.
--
-- A refunded cash-in represents a payment that was received and then
-- reversed by the originating bank or CashYin's operations team.
-- It can only be reached from `paid` (state machine: paid → refunded).
--
-- `IF NOT EXISTS` makes the migration safe to re-apply or to run
-- against a schema that already has the value (e.g. a test database
-- seeded from the next consolidated migration).

ALTER TYPE pix_charge_status ADD VALUE IF NOT EXISTS 'refunded';
