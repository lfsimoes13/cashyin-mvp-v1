-- ─────────────────────────────────────────────────────────────────────────────
-- 0011 — Cash-out public request contract
--
-- Aligns the `cashouts` table with the public `POST /v1/pix/cash-out` request:
--   - `external_ref` is now optional: relax `external_id` NOT NULL. The
--     UNIQUE (client_id, external_id) constraint still holds; Postgres treats
--     NULLs as distinct, so multiple cash-outs without a reference coexist.
--   - `pix_key_type` captures the client-supplied Pix key classification,
--     stored verbatim in uppercase and echoed on responses/webhooks.
--   - `receiver_name` / `receiver_document` capture the optional payee
--     identity, echoed on responses/webhooks and forwarded to the provider.
-- ─────────────────────────────────────────────────────────────────────────────

ALTER TABLE cashouts
  ALTER COLUMN external_id DROP NOT NULL;

ALTER TABLE cashouts
  ADD COLUMN pix_key_type      TEXT,
  ADD COLUMN receiver_name     TEXT,
  ADD COLUMN receiver_document TEXT;

ALTER TABLE cashouts
  ADD CONSTRAINT cashouts_pix_key_type_check
    CHECK (pix_key_type IS NULL OR pix_key_type IN ('CPF', 'CNPJ', 'EMAIL', 'PHONE', 'EVP'));
