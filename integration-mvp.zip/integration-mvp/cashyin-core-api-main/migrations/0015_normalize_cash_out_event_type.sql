-- 0015 — Normalize cash-out outbox event_type tokens
--
-- Rationale: cash-out rows in `outbox_events` used the legacy internal token
-- `cashout.<status>` (cashout.initiated / cashout.processing / cashout.completed
-- / cashout.failed / cashout.returned). All new code now writes the canonical
-- `pix.cash_out.<status>` token, aligned with the public CashYin contract and
-- the cash-in normalization in migration 0013 (`pix.cash_in.*`).
--
-- This is an INTERNAL token rename only:
--   * The PUBLIC webhook envelope already emits `pix.cash_out.completed` /
--     `pix.cash_out.failed` / `pix.cash_out.returned` (derived from the cash-out
--     status, not from the raw event_type), so the client-facing contract,
--     payload shape and field names (`amount`, `e2e_id`) are UNCHANGED.
--   * `aggregate_type` stays 'cashout' (out of scope; the dispatcher still
--     claims it). No CHECK constraint exists on outbox_events.event_type, so the
--     UPDATE is safe.
--
-- Backward compatibility: the dispatcher and the priority/metrics resolvers
-- accept BOTH legacy `cashout.*` and new `pix.cash_out.*` tokens, so in-flight
-- rows drain correctly regardless of whether this migration has run yet.
--
-- Forward-only and idempotent: re-running matches no rows once renamed.
-- Priority is re-asserted to the cash-out lane (60) to mirror 0013's pattern
-- and guarantee code/SQL never drift (resolveOutboxPriority -> CASH_OUT = 60).

BEGIN;

UPDATE outbox_events
   SET event_type = regexp_replace(event_type, '^cashout\.', 'pix.cash_out.'),
       priority   = 60
 WHERE aggregate_type = 'cashout'
   AND event_type LIKE 'cashout.%';

COMMIT;

-- ─── Rollback (manual) ───────────────────────────────────────────────────────
-- BEGIN;
-- UPDATE outbox_events
--    SET event_type = regexp_replace(event_type, '^pix\.cash_out\.', 'cashout.')
--  WHERE aggregate_type = 'cashout'
--    AND event_type LIKE 'pix.cash_out.%';
-- COMMIT;
