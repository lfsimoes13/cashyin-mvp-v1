-- ─────────────────────────────────────────────────────────────────────────────
-- 0010 — Capture cash-out failure reason
--
-- Adds a nullable `failure_reason` column to `cashouts`. It is populated on
-- `failed`/`returned` transitions (driven by the provider webhook) and cleared
-- to NULL on success. The value is surfaced on the public cash-out webhook for
-- non-success terminal events as `failure_reason`; it never appears on the
-- synchronous cash-out HTTP response.
-- ─────────────────────────────────────────────────────────────────────────────

ALTER TABLE cashouts
  ADD COLUMN failure_reason TEXT;
