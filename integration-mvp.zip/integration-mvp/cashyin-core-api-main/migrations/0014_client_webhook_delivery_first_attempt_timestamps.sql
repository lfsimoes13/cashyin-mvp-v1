-- 0014 — First-attempt delivery latency timestamps (Part 1: latency metrics)
--
-- Adds two nullable, internal-only timestamps to client_webhook_deliveries so
-- the dispatcher can persist and audit the first-attempt latency of an outbound
-- webhook, most importantly the critical pix.cash_in.paid path:
--
--   first_attempt_started_at   → wall-clock just before the FIRST HTTP POST
--   first_attempt_finished_at  → wall-clock when that first attempt returns
--                                (HTTP response received OR timeout)
--
-- Together with the already-present outbox_events.created_at (outbox_created_at)
-- and client_webhook_deliveries.delivered_at (delivery_success_at) these let us
-- compute, off the request path, the Part 1 latencies:
--
--   first_attempt_start_latency_ms = first_attempt_started_at  - outbox_created_at
--   first_attempt_total_latency_ms = first_attempt_finished_at - outbox_created_at
--   success_latency_ms             = delivered_at              - outbox_created_at
--
-- Notes:
--   * Columns are NULLABLE: existing rows keep NULL, no backfill (there is no
--     safe historical value for a first-attempt instant we never recorded).
--   * These are INTERNAL observability fields. They are NEVER added to the
--     public webhook payload/envelope.
--   * Forward-only and idempotent (ADD COLUMN IF NOT EXISTS), matching the
--     established migration style. Backward-compatible: the dispatcher only
--     writes them; nothing reads them on the delivery path.

BEGIN;

ALTER TABLE client_webhook_deliveries
  ADD COLUMN IF NOT EXISTS first_attempt_started_at  TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS first_attempt_finished_at TIMESTAMPTZ;

COMMIT;

-- ─── Rollback ────────────────────────────────────────────────────────────────
-- ALTER TABLE client_webhook_deliveries
--   DROP COLUMN IF EXISTS first_attempt_finished_at,
--   DROP COLUMN IF EXISTS first_attempt_started_at;
