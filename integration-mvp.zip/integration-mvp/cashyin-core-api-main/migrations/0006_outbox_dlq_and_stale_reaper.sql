-- Fix 1: add 'dlq' to outbox_status enum
--
-- The outbox dispatcher calls markFailed() after exhausting retry budget.
-- Previously markFailed set status = 'failed', but claimNextPending picks
-- up status IN ('pending', 'failed') with available_at <= now — so a
-- dead-letter row was retried forever (no future available_at set).
--
-- Fix: add 'dlq' as a terminal status excluded from claimNextPending.
-- markFailed will now set status = 'dlq' instead of 'failed'.

ALTER TYPE outbox_status ADD VALUE IF NOT EXISTS 'dlq';

-- Fix 2: add updated_at to outbox_events for stale-processing detection
--
-- When a worker crashes between claim (status → 'processing') and finalise,
-- the row is stuck in 'processing' forever. There was no timestamp to detect
-- staleness. The reaper query needs updated_at < now() - interval '5 min'.

ALTER TABLE outbox_events
  ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ NOT NULL DEFAULT now();

-- Backfill existing rows: use created_at as the starting point.
UPDATE outbox_events
   SET updated_at = created_at
 WHERE updated_at = '1970-01-01T00:00:00Z'  -- only if DEFAULT epoch was used
    OR true;  -- backfill all rows safely

-- Trigger: stamp updated_at on every row update.
CREATE OR REPLACE FUNCTION outbox_events_set_updated_at()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS outbox_events_updated_at ON outbox_events;
CREATE TRIGGER outbox_events_updated_at
  BEFORE UPDATE ON outbox_events
  FOR EACH ROW
  EXECUTE FUNCTION outbox_events_set_updated_at();

-- Index for stale-processing reaper: only rows currently stuck in 'processing'
-- are queried, so a partial index is efficient.
CREATE INDEX IF NOT EXISTS idx_outbox_stale_processing
  ON outbox_events (updated_at)
  WHERE status = 'processing';
