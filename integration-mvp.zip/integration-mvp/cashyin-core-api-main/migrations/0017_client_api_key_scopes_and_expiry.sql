-- ============================================================================
-- 0017 — client_api_keys: scopes + expiry
-- ============================================================================
--
-- Prepares CashYin-issued client API keys for the normalised AuthContext
-- (see docs/adr/auth-authorization-boundary.md). Two additive columns:
--
--   * `scopes`      — the coarse capability grants the key carries. Stored
--                     as TEXT[] of canonical `<domain>:<resource>:<action>`
--                     strings (see src/shared/auth/auth-scopes.ts). The
--                     resolver maps these onto AuthContext.scopes and the
--                     route guards authorise on them.
--
--   * `expires_at`  — optional hard expiry. NULL means "never expires"
--                     (current behaviour for every existing key). verify()
--                     rejects a key whose expiry is in the past, uniform
--                     with an unknown/revoked key (401).
--
-- Back-compat: every existing key is backfilled with the default standard
-- client scope set so nothing an integrator does today breaks once scope
-- enforcement is switched on (AUTH_ENFORCEMENT_MODE). The literal below MUST
-- stay in sync with DEFAULT_CLIENT_API_SCOPES in src/shared/auth/auth-scopes.ts.
--
-- No data-path behaviour changes here: PR 1 only persists the columns and
-- teaches the service to read them. Resolution + enforcement land in a later
-- PR behind the feature flag.
-- ============================================================================

ALTER TABLE client_api_keys
  ADD COLUMN IF NOT EXISTS scopes      TEXT[]      NOT NULL DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS expires_at  TIMESTAMPTZ;

-- Backfill existing keys with the default standard client capability set.
-- New keys get their scopes explicitly at issuance time, so this only
-- touches rows created before this migration (which had no scopes column).
UPDATE client_api_keys
   SET scopes = ARRAY[
         'pix:cash_in:create',
         'pix:cash_in:read',
         'pix:cash_out:create',
         'pix:cash_out:read'
       ]::TEXT[]
 WHERE scopes = '{}'::TEXT[];

-- Lets verify() exclude expired keys from the candidate set efficiently and
-- supports an operational sweep of soon-to-expire credentials. Partial: only
-- active keys with an expiry are interesting.
CREATE INDEX IF NOT EXISTS idx_client_api_keys_active_expiry
  ON client_api_keys (expires_at)
  WHERE status = 'active' AND expires_at IS NOT NULL;
