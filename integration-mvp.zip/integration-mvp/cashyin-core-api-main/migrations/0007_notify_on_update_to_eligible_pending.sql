-- Migration 0007: NOTIFY on UPDATE → eligible 'pending'
--
-- Context: migration 0005 already fires pg_notify on INSERT into webhook_events
-- and outbox_events. However two UPDATE paths exist that produce new, immediately
-- claimable rows that are NOT covered by the INSERT trigger:
--
--   1. Stale-processing reaper (migration 0006):
--      reclaimStaleProcessing() UPDATEs processing → pending with available_at = now().
--      In a multi-replica ECS deployment the sibling worker holding no in-flight
--      tick would not learn about the reclaimed row until the polling-fallback
--      interval (up to WORKER_MAX_IDLE_INTERVAL_MS = 5 s).
--
--   2. Any future admin / reconciliation tool that resets rows to pending.
--
-- Fix: add AFTER UPDATE triggers that fire pg_notify only when the row becomes
-- *immediately* eligible after the UPDATE:
--   - webhook_events: NEW.processing_status = 'pending'
--                     AND (next_attempt_at IS NULL OR next_attempt_at <= NOW())
--   - outbox_events:  NEW.status = 'pending'
--                     AND available_at <= NOW()
--
-- This intentionally does NOT fire for scheduled retries (future next_attempt_at /
-- available_at) to avoid spurious wake-ups that would trigger a claim with no
-- eligible rows. Those retries are handled by the polling-fallback interval.
--
-- Both trigger functions are idempotent (CREATE OR REPLACE) and both triggers
-- use DROP ... IF EXISTS before CREATE, so re-running the migration is safe.

-- ─── webhook_events ─────────────────────────────────────────────────────────

CREATE OR REPLACE FUNCTION cashyin_notify_webhook_events_eligible_update()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.processing_status = 'pending'
     AND (NEW.next_attempt_at IS NULL OR NEW.next_attempt_at <= NOW())
  THEN
    PERFORM pg_notify('cashyin_webhook_events_ready', NEW.id::text);
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS webhook_events_eligible_update_notify ON webhook_events;
CREATE TRIGGER webhook_events_eligible_update_notify
  AFTER UPDATE ON webhook_events
  FOR EACH ROW
  EXECUTE FUNCTION cashyin_notify_webhook_events_eligible_update();

-- ─── outbox_events ──────────────────────────────────────────────────────────

CREATE OR REPLACE FUNCTION cashyin_notify_outbox_events_eligible_update()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.status = 'pending'
     AND NEW.available_at <= NOW()
  THEN
    PERFORM pg_notify('cashyin_outbox_events_ready', NEW.id::text);
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS outbox_events_eligible_update_notify ON outbox_events;
CREATE TRIGGER outbox_events_eligible_update_notify
  AFTER UPDATE ON outbox_events
  FOR EACH ROW
  EXECUTE FUNCTION cashyin_notify_outbox_events_eligible_update();
