-- ============================================================================
-- 0022 — client_api_keys: grant `balance:read` to standard keys (D5)
-- ============================================================================
--
-- Introduces a dedicated `balance:read` scope so `GET /v1/balance` can be
-- guarded like the other `/v1/*` routes (see src/shared/auth/auth-scopes.ts;
-- the route previously carried no scope guard — deviation D5).
--
-- `balance:read` is now part of DEFAULT_CLIENT_API_SCOPES and DEFAULT_BFF_SCOPES.
-- New keys get it at issuance. This migration backfills the scope onto existing
-- *standard* keys — those already carrying the full default Pix capability set —
-- so they keep working once AUTH_ENFORCEMENT_MODE flips to `enforce`. Narrowly
-- scoped keys are intentionally NOT escalated.
--
-- The literal below MUST stay in sync with DEFAULT_CLIENT_API_SCOPES in
-- src/shared/auth/auth-scopes.ts.
-- ============================================================================

UPDATE client_api_keys
   SET scopes = array_append(scopes, 'balance:read')
 WHERE scopes @> ARRAY[
         'pix:cash_in:create',
         'pix:cash_in:read',
         'pix:cash_out:create',
         'pix:cash_out:read'
       ]::TEXT[]
   AND NOT ('balance:read' = ANY(scopes));
