-- ────────────────────────────────────────────────────────────────────────────
-- Ledger idempotency guard
--
-- `ledger_entries` is partitioned by RANGE (created_at), and PostgreSQL
-- requires that any UNIQUE index on a partitioned table include the full
-- partition key. A unique on `(idempotency_key, created_at)` therefore
-- would NOT prevent the same logical batch from being re-posted in a
-- different month (e.g. a webhook re-delivery that lands after a
-- partition rotation). We need a *global* idempotency check.
--
-- Solution: a small unpartitioned guard table that records the key of
-- every posted batch. Callers (e.g. LedgerService.postFeeAssessment) try
-- an INSERT ... ON CONFLICT DO NOTHING first; if the row already exists,
-- the batch is treated as a no-op and the ledger insert is skipped.
--
-- Idempotency-key format conventions (enforced by application code):
--   cash_in_paid:<pix_charge_id>         — entire cash-in paid batch
--   cash_out_confirmed:<cashout_id>      — entire cash-out confirmed batch
--   cash_out_returned:<cashout_id>       — chargeback/return reversal batch
--
-- Operators querying for "all entries of a given batch" can still join on
-- `ledger_entries.metadata->>'idempotencyKey'` since LedgerService stamps
-- the same value into every entry's metadata for traceability.
-- ────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS ledger_idempotency_keys (
  key         TEXT PRIMARY KEY,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE ledger_idempotency_keys IS
  'Append-only guard preventing duplicate ledger batch postings. One row per logical batch (e.g. cash_in_paid:<charge_id>). See migration 0007 for rationale.';
