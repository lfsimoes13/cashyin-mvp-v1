-- ============================================================================
-- 0003 — Narrow pix_charges.txid uniqueness + add format CHECK
-- ============================================================================
--
-- Problem fixed
-- -------------
-- The initial schema defined `UNIQUE (txid)` as a **global** constraint.
-- In a multi-provider (or multi-account) world, two different provider
-- accounts could legally reuse the same txid string (their BACEN namespace
-- is scoped to their Pix key / ISPB, not to CashYin). A global constraint
-- would cause a false-unique-violation and reject a legitimate charge.
--
-- The correct uniqueness scope is `(provider_account_id, txid)`: within the
-- same provider account a txid is guaranteed unique by BACEN; across
-- accounts it is not.
--
-- BACEN format reference
-- ----------------------
-- Pix txid: ^[a-zA-Z0-9]{26,35}$
-- Source: Manual de Padrões para Iniciação do Pix, BACEN, §3.3.2
--
-- Migration safety
-- ----------------
-- Pre-checks (run before applying):
--   SELECT COUNT(*) FROM pix_charges WHERE txid !~ '^[a-zA-Z0-9]{26,35}$';    → 0
--   SELECT COUNT(*) FROM pix_charges WHERE provider_account_id IS NULL;         → 0
--   SELECT COUNT(*) FROM (
--     SELECT provider_account_id, txid FROM pix_charges
--     GROUP BY provider_account_id, txid HAVING COUNT(*) > 1
--   ) x;                                                                         → 0
-- All three returned 0 on 2026-05-27 before this migration was applied.
--
-- The existing index on `txid` must be dropped first because PostgreSQL does
-- not allow renaming or narrowing a constraint in-place; we add the new one
-- immediately after, so the uniqueness guarantee is never absent.
--
-- The e2e_id index rationale
-- ----------------------------
-- A unique partial index on `e2e_id` within cash-in is intentionally
-- NOT added in this migration:
--   * `e2e_id` is set only on `paid` webhooks; a unique constraint
--     would conflict if a provider sends duplicate paid webhooks before the
--     idempotency guard in markPaid fires (both arrive before the first
--     transaction commits). The COALESCE guard is the correct mechanism here.
--   * The field is used for audit/reconciliation lookups, not as a public
--     lookup key; a non-unique index is sufficient and is added here for
--     query support.
-- ============================================================================

BEGIN;

-- 1. Drop the global unique constraint and its backing index.
ALTER TABLE pix_charges DROP CONSTRAINT IF EXISTS pix_charges_txid_key;

-- 2. Add BACEN format CHECK on txid.
ALTER TABLE pix_charges
  ADD CONSTRAINT pix_charges_txid_format
  CHECK (txid ~ '^[a-zA-Z0-9]{26,35}$');

-- 3. Add the correctly-scoped unique constraint.
ALTER TABLE pix_charges
  ADD CONSTRAINT pix_charges_provider_account_txid_unique
  UNIQUE (provider_account_id, txid);

-- 4. Non-unique index on e2e_id for reconciliation queries.
CREATE INDEX IF NOT EXISTS idx_pix_charges_e2e_id
  ON pix_charges (e2e_id)
  WHERE e2e_id IS NOT NULL;

COMMIT;
