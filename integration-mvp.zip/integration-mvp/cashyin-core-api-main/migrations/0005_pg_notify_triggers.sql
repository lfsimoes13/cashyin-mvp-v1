-- Triggers NOTIFY para acordar os workers imediatamente quando novos itens chegam nas filas.
--
-- Sem isso os workers dependem de polling com WORKER_IDLE_INTERVAL_MS (padrão: 200 ms,
-- backoff até WORKER_MAX_IDLE_INTERVAL_MS). Com os triggers o worker acorda em microssegundos
-- via pg_notify → client.on('notification') → WorkerLoop.nudge(), eliminando o idle wait no
-- caminho crítico.
--
-- Canais:
--   cashyin_webhook_events_ready   → provider-webhook-processor worker
--   cashyin_outbox_events_ready    → outbox-dispatcher worker
--
-- Prefixo 'cashyin_' evita colisão com canais de outras aplicações no mesmo banco.

-- ─── 1. webhook_events (alimenta provider-webhook-processor) ──────────────────

CREATE OR REPLACE FUNCTION cashyin_notify_webhook_events_insert()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  PERFORM pg_notify('cashyin_webhook_events_ready', NEW.id::text);
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS webhook_events_insert_notify ON webhook_events;
CREATE TRIGGER webhook_events_insert_notify
  AFTER INSERT ON webhook_events
  FOR EACH ROW
  EXECUTE FUNCTION cashyin_notify_webhook_events_insert();

-- ─── 2. outbox_events (alimenta outbox-dispatcher) ────────────────────────────

CREATE OR REPLACE FUNCTION cashyin_notify_outbox_events_insert()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  PERFORM pg_notify('cashyin_outbox_events_ready', NEW.id::text);
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS outbox_events_insert_notify ON outbox_events;
CREATE TRIGGER outbox_events_insert_notify
  AFTER INSERT ON outbox_events
  FOR EACH ROW
  EXECUTE FUNCTION cashyin_notify_outbox_events_insert();
