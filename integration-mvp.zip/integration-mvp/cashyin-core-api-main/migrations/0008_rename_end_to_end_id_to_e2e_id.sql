-- ─────────────────────────────────────────────────────────────────────────────
-- 0008 — Standardise end-to-end identifier to `e2e_id`
--
-- Renames `end_to_end_id` → `e2e_id` in `pix_charges` and `cashouts`.
-- The public name is now `e2e_id` everywhere: API responses, client webhook
-- envelopes, outbox event payloads, documentation and migrations.
--
-- The only place `end_to_end_id` still appears is inside the raw provider
-- payload stored verbatim in `webhook_events.payload` (immutable audit trail).
-- The adapter still picks both keys during ingress for backward-compat replay.
-- ─────────────────────────────────────────────────────────────────────────────

-- pix_charges
ALTER TABLE pix_charges
  RENAME COLUMN end_to_end_id TO e2e_id;

DROP INDEX IF EXISTS idx_pix_charges_end_to_end_id;

CREATE INDEX IF NOT EXISTS idx_pix_charges_e2e_id
  ON pix_charges (e2e_id)
  WHERE e2e_id IS NOT NULL;

-- cashouts
ALTER TABLE cashouts
  RENAME COLUMN end_to_end_id TO e2e_id;
