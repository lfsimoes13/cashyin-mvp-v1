-- ============================================================================
-- 0023 — user_client_grants: per-user RBAC for the trusted BFF channel (D7)
-- ============================================================================
--
-- Maps a human actor (as identified by the BFF, e.g. a Cognito sub) to the
-- scopes it may exercise on a given tenant via the `frontend_bff` channel.
-- When `BFF_RBAC_MODE='enforce'`, the authenticator resolves the active grant
-- and intersects its scopes with DEFAULT_BFF_SCOPES (the channel ceiling).
--
-- `actor_user_id` is an opaque external identity (no FK — the IdP owns it).
-- `client_id` is the tenant the actor operates. One grant per (actor, tenant).
-- Scopes are validated against the canonical scope set in the service layer
-- (src/modules/auth/user-client-grant.ts) before being written.
-- ============================================================================

CREATE TABLE IF NOT EXISTS user_client_grants (
  actor_user_id  TEXT        NOT NULL,
  client_id      UUID        NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  scopes         TEXT[]      NOT NULL DEFAULT '{}',
  status         TEXT        NOT NULL DEFAULT 'active'
    CHECK (status IN ('active', 'revoked')),
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (actor_user_id, client_id)
);

-- The authenticator looks up the *active* grant for (actor, tenant) on every
-- BFF request; this partial index keeps that point lookup cheap.
CREATE INDEX IF NOT EXISTS idx_user_client_grants_active
  ON user_client_grants (actor_user_id, client_id)
  WHERE status = 'active';
