-- ============================================================================
-- 0001 — Initial schema (consolidated, snake_case canonical contract)
-- ============================================================================
--
-- This migration replaces the previous 0001..0009 chain. The project is still
-- pre-production, so we collapsed the iterative history into a single
-- authoritative schema that already reflects the cash-in contract refactor:
--
--   * `pix_charges`:
--     - `external_ref` (was `external_id`)
--     - `amount` BIGINT cents (was `amount_cents`) — every monetary column
--       in the system stores cents, so the `_cents` suffix carries no
--       additional information; we drop it from the public contract.
--     - `qr_code` (was `qr_code_text`), plus a persisted `qr_code_image`
--       column so a GET after the initial POST can still return the PNG
--       payload to the client.
--     - `description` is now persisted (it was previously only forwarded
--       to the provider and discarded).
--     - Seven new `payer_*` columns capture the payer block returned by
--       the provider on `pix.cash_in.paid` webhooks. Storing them as
--       dedicated columns (rather than a single JSONB) is intentional:
--       providers vary on which fields they emit, and SQL indexing on
--       document/ispb is a common reporting need.
--     - `metadata` is removed. It was accepted in the API and persisted
--       but never read back; reintroduce when a real use case lands.
--
--   * `provider_transaction_references` is removed. It was created for the
--     orphan-event reconciliation path but no production code path writes
--     to it; webhook lookup uses `(provider_name, provider_charge_id)`
--     directly on `pix_charges`.
--
--   * Money columns elsewhere keep the `_cents` suffix because they are
--     internal accounting fields (ledger entries, fee assessments,
--     liquidity reservations) that never surface in the public API. The
--     drop is a contract concern, not a storage concern.
--
-- The remaining structure (clients, providers, ledger, pricing, liquidity,
-- webhook ingress/outbox, API keys) is functionally identical to the
-- pre-collapse schema. Comments from the original migrations have been
-- preserved verbatim wherever the design intent is non-obvious.
-- ============================================================================

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ---------------------------------------------------------------------------
-- Enums
-- ---------------------------------------------------------------------------

CREATE TYPE provider_name AS ENUM ('bents');
CREATE TYPE operation_type AS ENUM ('cash_in', 'cash_out');
CREATE TYPE provider_assignment_status AS ENUM ('active', 'planned', 'disabled');
CREATE TYPE ledger_direction AS ENUM ('debit', 'credit');
CREATE TYPE outbox_status AS ENUM ('pending', 'processing', 'published', 'failed');
CREATE TYPE migration_status AS ENUM (
  'planned', 'dual_write', 'cashin_cutover', 'cashout_cutover',
  'draining', 'completed', 'rolled_back'
);

-- Flow-specific transaction status enums. The shared `transaction_status`
-- enum from the legacy schema is gone: cash-in and cash-out can never
-- accidentally surface a status that does not belong to their flow.
CREATE TYPE pix_charge_status AS ENUM (
  'pending', 'paid', 'expired', 'cancelled', 'failed'
);

CREATE TYPE cashout_status AS ENUM (
  'processing', 'completed', 'failed', 'returned'
);

CREATE TYPE pricing_plan_status AS ENUM ('active', 'inactive', 'draft');
CREATE TYPE pricing_plan_version_status AS ENUM ('draft', 'active', 'superseded');
CREATE TYPE pricing_assignment_status AS ENUM ('active', 'disabled');
CREATE TYPE billing_mode AS ENUM (
  'deduct_from_settlement',
  'add_to_debit',
  'postpaid_invoice',
  'waived',
  'separate_balance_debit'
);
CREATE TYPE rounding_mode AS ENUM ('floor', 'ceil', 'round_half_up');
CREATE TYPE provider_cost_rule_status AS ENUM ('active', 'disabled');
CREATE TYPE fee_assessment_status AS ENUM ('estimated', 'posted', 'cancelled', 'reconciled');
CREATE TYPE subsidy_event_status AS ENUM ('approved', 'rejected', 'reversed');

CREATE TYPE webhook_event_processing_status AS ENUM (
  'pending', 'processing', 'processed', 'failed', 'skipped', 'dlq'
);

CREATE TYPE client_webhook_delivery_status AS ENUM (
  'pending', 'in_progress', 'delivered', 'failed', 'dead_letter'
);

-- ---------------------------------------------------------------------------
-- Core directory: clients, providers, accounts, routing assignments
-- ---------------------------------------------------------------------------

CREATE TABLE clients (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  legal_name  TEXT NOT NULL,
  trade_name  TEXT,
  status      TEXT NOT NULL DEFAULT 'active',
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE providers (
  name          provider_name PRIMARY KEY,
  display_name  TEXT NOT NULL,
  status        TEXT NOT NULL DEFAULT 'active',
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

INSERT INTO providers (name, display_name)
VALUES ('bents', 'Bents')
ON CONFLICT (name) DO NOTHING;

CREATE TABLE provider_accounts (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  provider_name  provider_name NOT NULL REFERENCES providers(name),
  alias          TEXT NOT NULL,
  currency       CHAR(3) NOT NULL DEFAULT 'BRL',
  status         TEXT NOT NULL DEFAULT 'active',
  metadata       JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (provider_name, alias)
);

CREATE TABLE client_provider_assignments (
  id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id            UUID NOT NULL REFERENCES clients(id),
  operation_type       operation_type NOT NULL,
  provider_name        provider_name NOT NULL REFERENCES providers(name),
  provider_account_id  UUID NOT NULL REFERENCES provider_accounts(id),
  status               provider_assignment_status NOT NULL DEFAULT 'active',
  weight               INTEGER NOT NULL DEFAULT 100
    CHECK (weight > 0 AND weight <= 100),
  valid_from           TIMESTAMPTZ NOT NULL DEFAULT now(),
  valid_to             TIMESTAMPTZ,
  version              INTEGER NOT NULL DEFAULT 1,
  metadata             JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_assignments_lookup
  ON client_provider_assignments (client_id, operation_type, status, valid_from DESC);

-- ---------------------------------------------------------------------------
-- Idempotency
-- ---------------------------------------------------------------------------

CREATE TABLE idempotency_keys (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id       UUID NOT NULL REFERENCES clients(id),
  key             TEXT NOT NULL,
  operation_type  operation_type NOT NULL,
  request_hash    TEXT NOT NULL,
  response_body   JSONB,
  locked_until    TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  completed_at    TIMESTAMPTZ,
  UNIQUE (client_id, key, operation_type)
);

-- ---------------------------------------------------------------------------
-- Transactions: pix_charges (cash-in) and cashouts (cash-out)
-- ---------------------------------------------------------------------------
--
-- `pix_charges` is the central row representing a Pix QR code generated by
-- a CashYin client. The columns split into three groups:
--
--   * Tenancy + routing: client_id, provider_name, provider_account_id.
--   * Public contract: external_ref, txid, amount, status, qr_code,
--     qr_code_image, description, expires_at, paid_at, e2e_id,
--     payer_*.
--   * Internal correlation: provider_charge_id is the UUID Bents (or
--     any other provider) returned at creation time. Not exposed in the
--     public API/contract but used by webhook ingress to resolve which
--     local row owns an incoming event.
--
-- The seven payer_* columns mirror the block providers populate at
-- payment time. They are nullable because the data only arrives via the
-- `pix.cash_in.paid` webhook (not at charge creation). `payer_document_type`
-- is constrained to the BACEN-standard taxonomy plus a NULL state.
CREATE TABLE pix_charges (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id             UUID NOT NULL REFERENCES clients(id),
  provider_name         provider_name NOT NULL REFERENCES providers(name),
  provider_account_id   UUID NOT NULL REFERENCES provider_accounts(id),
  external_ref          TEXT NOT NULL,
  provider_charge_id    TEXT,
  txid                  TEXT NOT NULL,
  amount                BIGINT NOT NULL CHECK (amount > 0),
  currency              CHAR(3) NOT NULL DEFAULT 'BRL',
  status                pix_charge_status NOT NULL DEFAULT 'pending',
  qr_code               TEXT,
  qr_code_image         TEXT,
  description           TEXT,
  expires_at            TIMESTAMPTZ,
  paid_at               TIMESTAMPTZ,
  e2e_id                TEXT,
  payer_name            TEXT,
  payer_document        TEXT,
  payer_document_type   TEXT
    CHECK (payer_document_type IS NULL OR payer_document_type IN ('cpf', 'cnpj')),
  payer_bank_name       TEXT,
  payer_bank_ispb       TEXT,
  payer_bank_branch     TEXT,
  payer_bank_account    TEXT,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (client_id, external_ref),
  UNIQUE (provider_name, provider_charge_id),
  UNIQUE (txid)
);

CREATE INDEX idx_pix_charges_client_created ON pix_charges (client_id, created_at DESC);
CREATE INDEX idx_pix_charges_status_created  ON pix_charges (status, created_at DESC);

CREATE TABLE cashouts (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id             UUID NOT NULL REFERENCES clients(id),
  provider_name         provider_name NOT NULL REFERENCES providers(name),
  provider_account_id   UUID NOT NULL REFERENCES provider_accounts(id),
  external_id           TEXT NOT NULL,
  provider_payment_id   TEXT,
  amount_cents          BIGINT NOT NULL CHECK (amount_cents > 0),
  currency              CHAR(3) NOT NULL DEFAULT 'BRL',
  pix_key               TEXT NOT NULL,
  status                cashout_status NOT NULL DEFAULT 'processing',
  e2e_id                TEXT,
  fee_amount_cents      BIGINT NOT NULL DEFAULT 0,
  metadata              JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (client_id, external_id),
  UNIQUE (provider_name, provider_payment_id)
);

CREATE INDEX idx_cashouts_client_created ON cashouts (client_id, created_at DESC);
CREATE INDEX idx_cashouts_status_created  ON cashouts (status, created_at DESC);

-- ---------------------------------------------------------------------------
-- Ledger (partitioned by month)
-- ---------------------------------------------------------------------------

CREATE TABLE ledger_accounts (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id           UUID REFERENCES clients(id),
  provider_account_id UUID REFERENCES provider_accounts(id),
  account_type        TEXT NOT NULL,
  currency            CHAR(3) NOT NULL DEFAULT 'BRL',
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (client_id, provider_account_id, account_type, currency)
);

CREATE TABLE ledger_entries (
  id                      UUID NOT NULL DEFAULT gen_random_uuid(),
  transaction_id          UUID NOT NULL,
  account_id              UUID NOT NULL REFERENCES ledger_accounts(id),
  client_id               UUID REFERENCES clients(id),
  provider_name           provider_name,
  provider_reference_id   TEXT,
  direction               ledger_direction NOT NULL,
  amount_cents            BIGINT NOT NULL CHECK (amount_cents > 0),
  currency                CHAR(3) NOT NULL DEFAULT 'BRL',
  reason                  TEXT NOT NULL,
  metadata                JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (id, created_at)
) PARTITION BY RANGE (created_at);

-- Twelve explicit monthly partitions covering 2026-05 through 2027-05, plus
-- a DEFAULT partition that catches anything outside that window so writes
-- never fail. Operators must alert on any non-zero row count in
-- `ledger_entries_default` (indicates a bug or a missed rotation).
CREATE TABLE ledger_entries_default      PARTITION OF ledger_entries DEFAULT;
CREATE TABLE ledger_entries_2026_05      PARTITION OF ledger_entries FOR VALUES FROM ('2026-05-01') TO ('2026-06-01');
CREATE TABLE ledger_entries_2026_06      PARTITION OF ledger_entries FOR VALUES FROM ('2026-06-01') TO ('2026-07-01');
CREATE TABLE ledger_entries_2026_07      PARTITION OF ledger_entries FOR VALUES FROM ('2026-07-01') TO ('2026-08-01');
CREATE TABLE ledger_entries_2026_08      PARTITION OF ledger_entries FOR VALUES FROM ('2026-08-01') TO ('2026-09-01');
CREATE TABLE ledger_entries_2026_09      PARTITION OF ledger_entries FOR VALUES FROM ('2026-09-01') TO ('2026-10-01');
CREATE TABLE ledger_entries_2026_10      PARTITION OF ledger_entries FOR VALUES FROM ('2026-10-01') TO ('2026-11-01');
CREATE TABLE ledger_entries_2026_11      PARTITION OF ledger_entries FOR VALUES FROM ('2026-11-01') TO ('2026-12-01');
CREATE TABLE ledger_entries_2026_12      PARTITION OF ledger_entries FOR VALUES FROM ('2026-12-01') TO ('2027-01-01');
CREATE TABLE ledger_entries_2027_01      PARTITION OF ledger_entries FOR VALUES FROM ('2027-01-01') TO ('2027-02-01');
CREATE TABLE ledger_entries_2027_02      PARTITION OF ledger_entries FOR VALUES FROM ('2027-02-01') TO ('2027-03-01');
CREATE TABLE ledger_entries_2027_03      PARTITION OF ledger_entries FOR VALUES FROM ('2027-03-01') TO ('2027-04-01');
CREATE TABLE ledger_entries_2027_04      PARTITION OF ledger_entries FOR VALUES FROM ('2027-04-01') TO ('2027-05-01');
CREATE TABLE ledger_entries_2027_05      PARTITION OF ledger_entries FOR VALUES FROM ('2027-05-01') TO ('2027-06-01');

CREATE INDEX idx_ledger_client_created ON ledger_entries (client_id, created_at DESC);
CREATE INDEX idx_ledger_transaction    ON ledger_entries (transaction_id);

-- Seed canonical system ledger accounts so reporting/reconciliation queries
-- can reference them by `account_type` from day 1 of the deployment without
-- waiting for a first write.
INSERT INTO ledger_accounts (client_id, provider_account_id, account_type, currency)
VALUES
  (NULL, NULL, 'system:cashyin_fee_revenue',  'BRL'),
  (NULL, NULL, 'system:provider_fee_expense', 'BRL'),
  (NULL, NULL, 'system:subsidy_expense',      'BRL')
ON CONFLICT (client_id, provider_account_id, account_type, currency) DO NOTHING;

-- ---------------------------------------------------------------------------
-- Liquidity reservations
-- ---------------------------------------------------------------------------

CREATE TABLE liquidity_reservations (
  id                            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id                     UUID NOT NULL REFERENCES clients(id),
  provider_account_id           UUID NOT NULL REFERENCES provider_accounts(id),
  cashout_id                    UUID REFERENCES cashouts(id),
  amount_cents                  BIGINT NOT NULL CHECK (amount_cents > 0),
  principal_amount_cents        BIGINT NOT NULL CHECK (principal_amount_cents >= 0),
  expected_provider_cost_cents  BIGINT NOT NULL DEFAULT 0
    CHECK (expected_provider_cost_cents >= 0),
  fee_assessment_id             UUID,
  release_reason                TEXT,
  status                        TEXT NOT NULL DEFAULT 'reserved',
  expires_at                    TIMESTAMPTZ NOT NULL,
  created_at                    TIMESTAMPTZ NOT NULL DEFAULT now(),
  released_at                   TIMESTAMPTZ,
  CHECK (amount_cents = principal_amount_cents + expected_provider_cost_cents)
);

CREATE INDEX idx_liquidity_active
  ON liquidity_reservations (provider_account_id, status, expires_at);
CREATE INDEX idx_liquidity_reservations_fee_assessment
  ON liquidity_reservations (fee_assessment_id)
  WHERE fee_assessment_id IS NOT NULL;

CREATE TABLE provider_liquidity_snapshots (
  id                     UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  provider_account_id    UUID NOT NULL REFERENCES provider_accounts(id),
  available_amount_cents BIGINT NOT NULL,
  reserved_amount_cents  BIGINT NOT NULL DEFAULT 0,
  currency               CHAR(3) NOT NULL DEFAULT 'BRL',
  captured_at            TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------------
-- Pricing engine: plans, versions, rules, fee assessments, subsidy audit
-- ---------------------------------------------------------------------------

CREATE TABLE pricing_plans (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name        TEXT NOT NULL UNIQUE,
  description TEXT,
  status      pricing_plan_status NOT NULL DEFAULT 'draft',
  metadata    JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE pricing_plan_versions (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_id     UUID NOT NULL REFERENCES pricing_plans(id),
  version     INTEGER NOT NULL CHECK (version >= 1),
  status      pricing_plan_version_status NOT NULL DEFAULT 'draft',
  valid_from  TIMESTAMPTZ NOT NULL DEFAULT now(),
  valid_to    TIMESTAMPTZ,
  metadata    JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (plan_id, version),
  CHECK (valid_to IS NULL OR valid_to > valid_from)
);

CREATE INDEX idx_pricing_plan_versions_lookup
  ON pricing_plan_versions (plan_id, status, valid_from DESC);

CREATE TABLE client_pricing_assignments (
  id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id                UUID NOT NULL REFERENCES clients(id),
  operation_type           operation_type NOT NULL,
  pricing_plan_version_id  UUID NOT NULL REFERENCES pricing_plan_versions(id),
  status                   pricing_assignment_status NOT NULL DEFAULT 'active',
  valid_from               TIMESTAMPTZ NOT NULL DEFAULT now(),
  valid_to                 TIMESTAMPTZ,
  metadata                 JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at               TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (valid_to IS NULL OR valid_to > valid_from)
);

CREATE UNIQUE INDEX idx_client_pricing_assignments_unique_active
  ON client_pricing_assignments (client_id, operation_type)
  WHERE status = 'active' AND valid_to IS NULL;

CREATE INDEX idx_client_pricing_assignments_lookup
  ON client_pricing_assignments (client_id, operation_type, status, valid_from DESC);

CREATE TABLE pricing_rules (
  id                                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  pricing_plan_version_id           UUID NOT NULL REFERENCES pricing_plan_versions(id),
  operation_type                    operation_type NOT NULL,
  trigger_event                     TEXT NOT NULL,
  fixed_fee_cents                   BIGINT NOT NULL DEFAULT 0 CHECK (fixed_fee_cents >= 0),
  variable_fee_bps                  INTEGER NOT NULL DEFAULT 0 CHECK (variable_fee_bps >= 0),
  min_fee_cents                     BIGINT CHECK (min_fee_cents IS NULL OR min_fee_cents >= 0),
  max_fee_cents                     BIGINT CHECK (max_fee_cents IS NULL OR max_fee_cents >= 0),
  billing_mode                      billing_mode NOT NULL,
  rounding_mode                     rounding_mode NOT NULL DEFAULT 'round_half_up',
  allow_negative_margin             BOOLEAN NOT NULL DEFAULT false,
  max_negative_margin_cents_per_txn BIGINT
    CHECK (max_negative_margin_cents_per_txn IS NULL OR max_negative_margin_cents_per_txn >= 0),
  daily_subsidy_limit_cents         BIGINT
    CHECK (daily_subsidy_limit_cents IS NULL OR daily_subsidy_limit_cents >= 0),
  monthly_subsidy_limit_cents       BIGINT
    CHECK (monthly_subsidy_limit_cents IS NULL OR monthly_subsidy_limit_cents >= 0),
  metadata                          JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at                        TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (max_fee_cents IS NULL OR min_fee_cents IS NULL OR max_fee_cents >= min_fee_cents)
);

CREATE INDEX idx_pricing_rules_lookup
  ON pricing_rules (pricing_plan_version_id, operation_type, trigger_event);

CREATE TABLE provider_cost_rules (
  id                            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  provider_account_id           UUID NOT NULL REFERENCES provider_accounts(id),
  operation_type                operation_type NOT NULL,
  trigger_event                 TEXT NOT NULL,
  fixed_cost_cents              BIGINT NOT NULL DEFAULT 0 CHECK (fixed_cost_cents >= 0),
  variable_cost_bps             INTEGER NOT NULL DEFAULT 0 CHECK (variable_cost_bps >= 0),
  min_cost_cents                BIGINT CHECK (min_cost_cents IS NULL OR min_cost_cents >= 0),
  max_cost_cents                BIGINT CHECK (max_cost_cents IS NULL OR max_cost_cents >= 0),
  charged_from_provider_balance BOOLEAN NOT NULL DEFAULT true,
  rounding_mode                 rounding_mode NOT NULL DEFAULT 'round_half_up',
  status                        provider_cost_rule_status NOT NULL DEFAULT 'active',
  valid_from                    TIMESTAMPTZ NOT NULL DEFAULT now(),
  valid_to                      TIMESTAMPTZ,
  metadata                      JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at                    TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (valid_to IS NULL OR valid_to > valid_from),
  CHECK (max_cost_cents IS NULL OR min_cost_cents IS NULL OR max_cost_cents >= min_cost_cents)
);

CREATE INDEX idx_provider_cost_rules_lookup
  ON provider_cost_rules (provider_account_id, operation_type, trigger_event, status, valid_from DESC);

-- `transaction_id` is intentionally NOT a foreign key: it polymorphically
-- points at `pix_charges` or `cashouts` (discriminated by `transaction_type`).
-- The CHECKs at the bottom of this table encode the canonical pricing
-- formulas at the storage layer.
CREATE TABLE fee_assessments (
  id                     UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_type       TEXT NOT NULL CHECK (transaction_type IN ('pix_charge', 'cashout')),
  transaction_id         UUID NOT NULL,
  client_id              UUID NOT NULL REFERENCES clients(id),
  provider_account_id    UUID NOT NULL REFERENCES provider_accounts(id),
  operation_type         operation_type NOT NULL,
  trigger_event          TEXT NOT NULL,
  principal_amount_cents BIGINT NOT NULL CHECK (principal_amount_cents >= 0),
  client_fee_cents       BIGINT NOT NULL CHECK (client_fee_cents >= 0),
  provider_cost_cents    BIGINT NOT NULL CHECK (provider_cost_cents >= 0),
  margin_cents           BIGINT NOT NULL,
  subsidy_cents          BIGINT NOT NULL CHECK (subsidy_cents >= 0),
  pricing_rule_id        UUID REFERENCES pricing_rules(id),
  provider_cost_rule_id  UUID REFERENCES provider_cost_rules(id),
  billing_mode           billing_mode NOT NULL,
  rounding_mode          rounding_mode NOT NULL,
  status                 fee_assessment_status NOT NULL DEFAULT 'estimated',
  metadata               JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at             TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at             TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (transaction_type, transaction_id, trigger_event),
  CHECK (margin_cents  = client_fee_cents - provider_cost_cents),
  CHECK (subsidy_cents = GREATEST(0, provider_cost_cents - client_fee_cents))
);

CREATE INDEX idx_fee_assessments_client_created
  ON fee_assessments (client_id, created_at DESC);
CREATE INDEX idx_fee_assessments_status_created
  ON fee_assessments (status, created_at DESC);

-- Wire the FK from liquidity_reservations.fee_assessment_id now that
-- fee_assessments exists. Kept outside the original table block so the
-- table-creation order remains schema-linear without forward references.
ALTER TABLE liquidity_reservations
  ADD CONSTRAINT fk_liquidity_fee_assessment
  FOREIGN KEY (fee_assessment_id) REFERENCES fee_assessments(id);

CREATE TABLE subsidy_events (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  fee_assessment_id UUID NOT NULL REFERENCES fee_assessments(id),
  client_id         UUID NOT NULL REFERENCES clients(id),
  transaction_type  TEXT NOT NULL CHECK (transaction_type IN ('pix_charge', 'cashout')),
  transaction_id    UUID NOT NULL,
  subsidy_cents     BIGINT NOT NULL CHECK (subsidy_cents > 0),
  policy_snapshot   JSONB NOT NULL,
  status            subsidy_event_status NOT NULL DEFAULT 'approved',
  reason            TEXT,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_subsidy_events_client_created  ON subsidy_events (client_id, created_at DESC);
CREATE INDEX idx_subsidy_events_status_created  ON subsidy_events (status, created_at DESC);

-- ---------------------------------------------------------------------------
-- Webhook ingress (provider → CashYin)
-- ---------------------------------------------------------------------------

CREATE TABLE webhook_events (
  id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  provider_name            provider_name NOT NULL REFERENCES providers(name),
  event_type               TEXT NOT NULL,
  provider_event_id        TEXT,
  signature_valid          BOOLEAN NOT NULL DEFAULT false,
  payload                  JSONB NOT NULL,
  received_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
  raw_payload_hash         TEXT,
  headers_redacted         JSONB NOT NULL DEFAULT '{}'::jsonb,
  dedupe_key               TEXT,
  processing_status        webhook_event_processing_status NOT NULL DEFAULT 'pending',
  processing_error         TEXT,
  attempt_count            INTEGER NOT NULL DEFAULT 0 CHECK (attempt_count >= 0),
  last_attempt_at          TIMESTAMPTZ,
  next_attempt_at          TIMESTAMPTZ,
  provider_transaction_id  TEXT,
  provider_status          TEXT,
  operation_type           operation_type,
  occurred_at              TIMESTAMPTZ,
  normalized_status_kind   TEXT NOT NULL DEFAULT 'unknown'
    CHECK (normalized_status_kind IN ('cash_in', 'cash_out', 'unknown')),
  normalized_status        TEXT
    CHECK (
      normalized_status IS NULL
      OR normalized_status IN (
        'pending', 'paid', 'expired', 'cancelled', 'failed',
        'processing', 'completed', 'returned'
      )
    ),
  unknown_reason           TEXT
    CHECK (
      unknown_reason IS NULL
      OR unknown_reason IN (
        'unknown_event_type', 'unknown_status',
        'missing_status', 'missing_operation_type'
      )
    ),
  processed_at             TIMESTAMPTZ,
  created_at               TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (provider_name, provider_event_id),
  CONSTRAINT webhook_events_normalized_status_shape CHECK (
    (normalized_status_kind = 'unknown' AND normalized_status IS NULL)
    OR (normalized_status_kind IN ('cash_in', 'cash_out')
        AND normalized_status IS NOT NULL
        AND unknown_reason IS NULL)
  )
);

CREATE INDEX idx_webhook_events_created
  ON webhook_events (created_at DESC);
CREATE UNIQUE INDEX idx_webhook_events_dedupe_key
  ON webhook_events (provider_name, dedupe_key)
  WHERE dedupe_key IS NOT NULL;
CREATE INDEX idx_webhook_events_processing
  ON webhook_events (processing_status, next_attempt_at, received_at)
  WHERE processing_status IN ('pending', 'processing', 'failed');
CREATE INDEX idx_webhook_events_provider_tx
  ON webhook_events (provider_name, provider_transaction_id)
  WHERE provider_transaction_id IS NOT NULL;
CREATE INDEX idx_webhook_events_normalized
  ON webhook_events (normalized_status_kind, normalized_status, received_at DESC);

CREATE TABLE provider_webhook_processing_attempts (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  webhook_event_id  UUID NOT NULL REFERENCES webhook_events(id) ON DELETE CASCADE,
  attempt_number    INTEGER NOT NULL CHECK (attempt_number > 0),
  worker_id         TEXT,
  started_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  finished_at       TIMESTAMPTZ,
  outcome           TEXT NOT NULL
    CHECK (outcome IN ('in_progress', 'success', 'retryable_failure', 'permanent_failure')),
  error_code        TEXT,
  error_message     TEXT,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (webhook_event_id, attempt_number)
);

CREATE INDEX idx_webhook_attempts_event
  ON provider_webhook_processing_attempts (webhook_event_id, attempt_number DESC);

-- ---------------------------------------------------------------------------
-- Outbox + outbound dispatcher
-- ---------------------------------------------------------------------------

CREATE TABLE outbox_events (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  aggregate_type  TEXT NOT NULL,
  aggregate_id    UUID NOT NULL,
  event_type      TEXT NOT NULL,
  payload         JSONB NOT NULL,
  status          outbox_status NOT NULL DEFAULT 'pending',
  attempts        INTEGER NOT NULL DEFAULT 0,
  available_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  published_at    TIMESTAMPTZ
);

CREATE INDEX idx_outbox_pending ON outbox_events (status, available_at, created_at);

CREATE TABLE client_webhook_endpoints (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id          UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  event_pattern      TEXT NOT NULL DEFAULT '*',
  target_url         TEXT NOT NULL,
  signing_secret     TEXT NOT NULL,
  status             TEXT NOT NULL DEFAULT 'active'
    CHECK (status IN ('active', 'disabled')),
  description        TEXT,
  last_delivered_at  TIMESTAMPTZ,
  last_failure_at    TIMESTAMPTZ,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (client_id, event_pattern)
);

CREATE INDEX idx_client_webhook_endpoints_lookup
  ON client_webhook_endpoints (client_id, status)
  WHERE status = 'active';

CREATE TABLE client_webhook_deliveries (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  outbox_event_id       UUID NOT NULL UNIQUE REFERENCES outbox_events(id) ON DELETE CASCADE,
  client_id             UUID NOT NULL REFERENCES clients(id),
  event_id              TEXT NOT NULL,
  event_type            TEXT NOT NULL,
  target_url            TEXT NOT NULL,
  payload               JSONB NOT NULL,
  signature             TEXT,
  status                client_webhook_delivery_status NOT NULL DEFAULT 'pending',
  attempt_count         INTEGER NOT NULL DEFAULT 0 CHECK (attempt_count >= 0),
  last_http_status      INTEGER,
  last_response_snippet TEXT,
  last_error            TEXT,
  next_attempt_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  delivered_at          TIMESTAMPTZ,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (client_id, event_id)
);

CREATE INDEX idx_client_deliveries_due
  ON client_webhook_deliveries (status, next_attempt_at)
  WHERE status IN ('pending', 'in_progress', 'failed');
CREATE INDEX idx_client_deliveries_client_event
  ON client_webhook_deliveries (client_id, event_type, created_at DESC);

-- ---------------------------------------------------------------------------
-- Inbound API authentication: client API keys
-- ---------------------------------------------------------------------------
--
-- Key format: `ck_<64 hex chars>` (256 bits CSPRNG entropy). Only the
-- SHA-256 of the raw key is stored. `key_prefix` (first 8 chars after
-- `ck_`) is indexed so verify() can short-circuit to a small candidate
-- set instead of hashing every row.
CREATE TABLE client_api_keys (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id     UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  key_prefix    TEXT NOT NULL,
  key_hash      TEXT NOT NULL,
  status        TEXT NOT NULL DEFAULT 'active'
    CHECK (status IN ('active', 'revoked')),
  label         TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_used_at  TIMESTAMPTZ,
  revoked_at    TIMESTAMPTZ,
  UNIQUE (key_hash)
);

CREATE INDEX idx_client_api_keys_prefix_active
  ON client_api_keys (key_prefix)
  WHERE status = 'active';
CREATE INDEX idx_client_api_keys_client
  ON client_api_keys (client_id);

-- ---------------------------------------------------------------------------
-- Provider migration plan (operational, not data-path)
-- ---------------------------------------------------------------------------

CREATE TABLE provider_migrations (
  id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id                UUID NOT NULL REFERENCES clients(id),
  from_provider_account_id UUID NOT NULL REFERENCES provider_accounts(id),
  to_provider_account_id   UUID NOT NULL REFERENCES provider_accounts(id),
  status                   migration_status NOT NULL DEFAULT 'planned',
  planned_at               TIMESTAMPTZ NOT NULL DEFAULT now(),
  started_at               TIMESTAMPTZ,
  completed_at             TIMESTAMPTZ,
  rollback_reason          TEXT,
  metadata                 JSONB NOT NULL DEFAULT '{}'::jsonb
);
