-- ─────────────────────────────────────────────────────────────────────────────
-- 0016 — Cash-out receiver detail + lifecycle timestamps
--
-- Two additive, forward-only concerns for the sync/async cash-out contract:
--
-- 1. Receiver detail. `cashouts` only stored `receiver_name` / `receiver_document`
--    (migration 0011). Providers (e.g. Bents `pix.payment.sent`) return a richer
--    receiver block (`bank`, `ispb`, `branch`, `account`, `account_type`). These
--    columns let us persist the full payee identity — populated either from a
--    synchronous provider response during POST or from a later provider webhook
--    in the asynchronous flow. They surface publicly ONLY inside the nested
--    `receiver` object (the flat `receiver_name` / `receiver_document` stay for
--    backward compatibility; no flat columns are added for the new fields).
--
-- 2. Lifecycle timestamps. The public contract now exposes `completed_at` /
--    `failed_at` (and `returned_at` for parity with the webhook envelope) on
--    GET/POST. They were previously derived only on the webhook envelope from
--    the outbox `occurredAt`; persisting them makes GET the canonical source of
--    the current cash-out state, including WHEN it reached a terminal status.
--
-- Production safety:
--   * Nullable columns only — no NOT NULL, no defaults, no table rewrite.
--   * No historical backfill: pre-existing rows keep NULL for the new columns
--     and serialize safely (the public mapper treats NULL as `null`).
--   * Idempotent: `ADD COLUMN IF NOT EXISTS` so a re-run is a no-op.
-- ─────────────────────────────────────────────────────────────────────────────

BEGIN;

ALTER TABLE cashouts
  ADD COLUMN IF NOT EXISTS receiver_bank         TEXT,
  ADD COLUMN IF NOT EXISTS receiver_ispb         TEXT,
  ADD COLUMN IF NOT EXISTS receiver_branch       TEXT,
  ADD COLUMN IF NOT EXISTS receiver_account      TEXT,
  ADD COLUMN IF NOT EXISTS receiver_account_type TEXT;

ALTER TABLE cashouts
  ADD COLUMN IF NOT EXISTS completed_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS failed_at    TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS returned_at  TIMESTAMPTZ;

COMMIT;
