-- ============================================================================
-- 0020 — api_hmac_nonces (shared request-signature replay protection)
-- ============================================================================
--
-- Shared, cross-instance nonce store for the `api_direct` HMAC channel
-- (mitigates deviation D16: the per-process in-memory cache could let a nonce
-- be replayed on a different instance within the clock-skew window).
--
-- A nonce is "spent" exactly once per key within its validity window. The
-- verifier inserts `(api_key_id, nonce)`; an unexpired duplicate is a replay.
-- Expired rows are revived by a new request with the same nonce (rare) and are
-- otherwise reclaimed by opportunistic/scheduled pruning on `expires_at`.
--
--   * PRIMARY KEY (api_key_id, nonce) — enforces single-use atomically.
--   * expires_at — end of the validity window (= timestamp + 2× clock skew).
--   * FK ON DELETE CASCADE — drop a key's nonces when the key is removed.
--
-- No data-path behaviour changes until API_HMAC_MODE is switched on AND the
-- verifier is wired to this store.
-- ============================================================================

CREATE TABLE IF NOT EXISTS api_hmac_nonces (
  api_key_id UUID        NOT NULL REFERENCES client_api_keys(id) ON DELETE CASCADE,
  nonce      TEXT        NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  PRIMARY KEY (api_key_id, nonce)
);

CREATE INDEX IF NOT EXISTS idx_api_hmac_nonces_expires
  ON api_hmac_nonces (expires_at);
