-- ============================================================================
-- 0019 — client_api_keys: signing_secret (request HMAC)
-- ============================================================================
--
-- Adds a per-key signing secret used to verify request signatures on the
-- `api_direct` channel (see docs/adr/auth-authorization-boundary.md). The
-- client signs a canonical request string with this secret; the Core verifies
-- it (timing-safe) when API_HMAC_MODE is shadow/enforce.
--
--   * `signing_secret` — high-entropy hex secret, returned ONCE at issuance
--                        (mint/rotate). NULL for keys created before this
--                        migration: such keys cannot produce a valid
--                        signature, so they must be rotated before
--                        API_HMAC_MODE='enforce' is switched on. Stored in
--                        plaintext like client_webhook_endpoints.signing_secret
--                        (it is a shared HMAC secret, not a password).
--
-- No data-path behaviour changes until API_HMAC_MODE is switched on.
-- ============================================================================

ALTER TABLE client_api_keys
  ADD COLUMN IF NOT EXISTS signing_secret TEXT;
