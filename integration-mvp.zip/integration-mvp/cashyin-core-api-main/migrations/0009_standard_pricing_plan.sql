-- migrations/0009_standard_pricing_plan.sql
--
-- Bootstraps the standard CashYin Pix pricing plan so that PricingService
-- produces fee_assessments from day one.
--
-- This is a DATA migration (no schema changes). It inserts:
--   1. pricing_plans          — one "standard" plan (active)
--   2. pricing_plan_versions  — version 1 of that plan (active)
--   3. pricing_rules          — cash-in (15 ¢) and cash-out (15 ¢) rules
--   4. client_pricing_assignments — assigns the demo client (if present)
--
-- Values match src/config/pricing.config.ts:
--   cash_in:  customer_fee_amount_cents = 15  billing_mode = deduct_from_settlement
--   cash_out: customer_fee_amount_cents = 15  billing_mode = add_to_debit
--
-- Fixed UUIDs for deterministic idempotency:
--   plan:         00000000-0000-0000-0010-000000000001
--   plan_version: 00000000-0000-0000-0011-000000000001
--
-- Every statement is idempotent: safe to re-run after partial failures.

-- ──────────────────────────────────────────────────────────────────────────────
-- 1. Standard pricing plan
-- ──────────────────────────────────────────────────────────────────────────────

INSERT INTO pricing_plans (id, name, description, status)
VALUES (
  '00000000-0000-0000-0010-000000000001',
  'standard',
  'Standard CashYin Pix pricing — R$ 0,15 per transaction (cash-in and cash-out).',
  'active'
)
ON CONFLICT (name) DO NOTHING;

-- ──────────────────────────────────────────────────────────────────────────────
-- 2. Version 1 of the standard plan
-- ──────────────────────────────────────────────────────────────────────────────

INSERT INTO pricing_plan_versions (id, plan_id, version, status, valid_from)
SELECT
  '00000000-0000-0000-0011-000000000001',
  p.id,
  1,
  'active',
  now()
FROM pricing_plans p
WHERE p.id = '00000000-0000-0000-0010-000000000001'
ON CONFLICT (plan_id, version) DO NOTHING;

-- ──────────────────────────────────────────────────────────────────────────────
-- 3a. Cash-in pricing rule
--
--   trigger_event: cash_in_paid
--   billing_mode:  deduct_from_settlement
--   => fee is subtracted from the incoming Pix amount before crediting the
--      client balance.  net_amount = gross - 15 ¢.
-- ──────────────────────────────────────────────────────────────────────────────

INSERT INTO pricing_rules
  (pricing_plan_version_id, operation_type, trigger_event,
   fixed_fee_cents, variable_fee_bps,
   billing_mode, rounding_mode,
   allow_negative_margin)
SELECT
  '00000000-0000-0000-0011-000000000001',
  'cash_in',
  'cash_in_paid',
  15,   -- customer_fee_amount_cents (R$ 0,15)
  0,    -- no variable component
  'deduct_from_settlement',
  'round_half_up',
  false -- negative margin not allowed; cashyin_margin = 15 - 10 = 5 ¢
WHERE NOT EXISTS (
  SELECT 1 FROM pricing_rules
   WHERE pricing_plan_version_id = '00000000-0000-0000-0011-000000000001'
     AND operation_type = 'cash_in'
     AND trigger_event = 'cash_in_paid'
);

-- ──────────────────────────────────────────────────────────────────────────────
-- 3b. Cash-out pricing rule
--
--   trigger_event: cash_out_created
--   billing_mode:  add_to_debit
--   => client balance is debited by principal + 15 ¢.
--      totalDebitAmountCents = gross + 15.
-- ──────────────────────────────────────────────────────────────────────────────

INSERT INTO pricing_rules
  (pricing_plan_version_id, operation_type, trigger_event,
   fixed_fee_cents, variable_fee_bps,
   billing_mode, rounding_mode,
   allow_negative_margin)
SELECT
  '00000000-0000-0000-0011-000000000001',
  'cash_out',
  'cash_out_created',
  15,   -- customer_fee_amount_cents (R$ 0,15)
  0,    -- no variable component
  'add_to_debit',
  'round_half_up',
  false -- negative margin not allowed; cashyin_margin = 15 - 10 = 5 ¢
WHERE NOT EXISTS (
  SELECT 1 FROM pricing_rules
   WHERE pricing_plan_version_id = '00000000-0000-0000-0011-000000000001'
     AND operation_type = 'cash_out'
     AND trigger_event = 'cash_out_created'
);

-- ──────────────────────────────────────────────────────────────────────────────
-- 4. Demo-client assignments (no-op in production where this client is absent)
--
-- Assigns the standard plan version to the seeded demo client
-- (id = 00000000-0000-0000-0000-000000000001) for both operation types.
-- The WHERE EXISTS guard makes this a no-op in environments where the demo
-- client has not been inserted (e.g. production).
-- ──────────────────────────────────────────────────────────────────────────────

INSERT INTO client_pricing_assignments
  (client_id, operation_type, pricing_plan_version_id, status)
SELECT
  '00000000-0000-0000-0000-000000000001',
  'cash_in',
  '00000000-0000-0000-0011-000000000001',
  'active'
WHERE
  EXISTS (
    SELECT 1 FROM clients WHERE id = '00000000-0000-0000-0000-000000000001'
  )
  AND NOT EXISTS (
    SELECT 1 FROM client_pricing_assignments
     WHERE client_id = '00000000-0000-0000-0000-000000000001'
       AND operation_type = 'cash_in'
       AND status = 'active'
       AND valid_to IS NULL
  );

INSERT INTO client_pricing_assignments
  (client_id, operation_type, pricing_plan_version_id, status)
SELECT
  '00000000-0000-0000-0000-000000000001',
  'cash_out',
  '00000000-0000-0000-0011-000000000001',
  'active'
WHERE
  EXISTS (
    SELECT 1 FROM clients WHERE id = '00000000-0000-0000-0000-000000000001'
  )
  AND NOT EXISTS (
    SELECT 1 FROM client_pricing_assignments
     WHERE client_id = '00000000-0000-0000-0000-000000000001'
       AND operation_type = 'cash_out'
       AND status = 'active'
       AND valid_to IS NULL
  );
