-- ============================================================================
-- 0021 — pix_charges: rename qr_code -> pix_emv, drop qr_code_image, add
--        payer_account_type
-- ============================================================================
--
-- Public Pix cash-in contract standardization (nested `pix` object):
--   * `qr_code`  -> `pix_emv`  — the EMV "copia e cola" payment string. The
--                               renamed column matches the public `pix.emv`
--                               field and the internal `emv` record field.
--   * `qr_code_image`          — dropped. The base64 PNG was never used by the
--                               public contract and is no longer stored.
--   * `payer_account_type`     — added so the cash-in `payer` block matches the
--                               cash-out `receiver` shape
--                               ({name, document_number, bank, ispb, branch,
--                                account, account_type}). Nullable; populated
--                               when the provider reports it.
-- ============================================================================

ALTER TABLE pix_charges RENAME COLUMN qr_code TO pix_emv;

ALTER TABLE pix_charges DROP COLUMN IF EXISTS qr_code_image;

ALTER TABLE pix_charges ADD COLUMN IF NOT EXISTS payer_account_type TEXT;
