-- Fase 2: prioritise pix.cash_in.paid in the public webhook outbox.
--
-- Today the dispatcher claim orders strictly by (available_at, created_at),
-- so a burst of cash-out or non-critical cash-in events can sit ahead of a
-- payment-confirmed event and delay the most latency-sensitive webhook.
--
-- We add an explicit `priority` column (lower = more urgent) and switch the
-- claim ordering to `priority ASC, available_at ASC, created_at ASC`. The
-- application sets the priority on enqueue from the internal event_type:
--
--   pix_charge.paid         → 10  (critical cash-in paid)
--   pix_charge.<terminal>   → 30  (expired / cancelled / failed / refunded)
--   cashout.<status>        → 60  (cash-out can tolerate queueing)
--   everything else         → 100 (informational; column DEFAULT)
--
-- Forward-only + idempotent, matching the existing migration style. The
-- DEFAULT 100 keeps any in-flight INSERT that predates the code change valid.

ALTER TABLE outbox_events
  ADD COLUMN IF NOT EXISTS priority SMALLINT NOT NULL DEFAULT 100;

-- Backfill currently-undelivered rows so events already sitting in the queue
-- when this migration runs are reordered by the new priority too. Terminal
-- rows (published/dlq) are left untouched.
UPDATE outbox_events
   SET priority = CASE
                    WHEN event_type = 'pix_charge.paid' THEN 10
                    WHEN event_type LIKE 'pix_charge.%' THEN 30
                    WHEN event_type LIKE 'cashout.%'    THEN 60
                    ELSE 100
                  END
 WHERE status IN ('pending', 'failed', 'processing');

-- Partial index backing the new claim ORDER BY for due, undelivered rows.
CREATE INDEX IF NOT EXISTS idx_outbox_pending_priority
  ON outbox_events (priority, available_at, created_at)
  WHERE status IN ('pending', 'failed');

-- ─── Rollback ────────────────────────────────────────────────────────────────
-- DROP INDEX IF EXISTS idx_outbox_pending_priority;
-- ALTER TABLE outbox_events DROP COLUMN IF EXISTS priority;
