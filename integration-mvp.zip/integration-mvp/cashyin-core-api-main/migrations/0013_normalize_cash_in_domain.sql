-- 0013 — Normalize cash-in domain identifiers
--
-- Rationale: the original schema used the legacy token 'pix_charge' as the
-- transaction_type discriminator in fee_assessments and subsidy_events, and as
-- the aggregate_type / event_type prefix in outbox_events. All new code now
-- uses 'cash_in' (aggregate_type) and 'pix.cash_in.*' (event_type) to align
-- with the canonical CashYin public contract.
--
-- Order of operations for fee_assessments and subsidy_events:
--   1. DROP the old CHECK constraint first — it only allows 'pix_charge' and
--      'cashout', so any UPDATE setting 'cash_in' would be rejected while
--      the old constraint is in place.
--   2. UPDATE the data from 'pix_charge' → 'cash_in' (no constraint, safe).
--   3. ADD the new CHECK constraint — now all rows carry 'cash_in' or
--      'cashout', so the validation passes immediately.

BEGIN;

-- ── 1. outbox_events ─────────────────────────────────────────────────────────

UPDATE outbox_events
   SET aggregate_type = 'cash_in',
       event_type     = 'pix.' || event_type,
       priority       = CASE
                          WHEN event_type = 'pix_charge.paid' THEN 10
                          ELSE 30
                        END
 WHERE aggregate_type = 'pix_charge'
   AND event_type LIKE 'pix_charge.%';

-- ── 2. fee_assessments ───────────────────────────────────────────────────────
-- DROP old constraint first (it blocks 'cash_in'), then migrate, then add new.

ALTER TABLE fee_assessments
  DROP CONSTRAINT IF EXISTS fee_assessments_transaction_type_check;

UPDATE fee_assessments
   SET transaction_type = 'cash_in'
 WHERE transaction_type = 'pix_charge';

ALTER TABLE fee_assessments
  ADD CONSTRAINT fee_assessments_transaction_type_check
  CHECK (transaction_type IN ('cash_in', 'cashout'));

-- ── 3. subsidy_events ────────────────────────────────────────────────────────
-- Same pattern: DROP → UPDATE → ADD.

ALTER TABLE subsidy_events
  DROP CONSTRAINT IF EXISTS subsidy_events_transaction_type_check;

UPDATE subsidy_events
   SET transaction_type = 'cash_in'
 WHERE transaction_type = 'pix_charge';

ALTER TABLE subsidy_events
  ADD CONSTRAINT subsidy_events_transaction_type_check
  CHECK (transaction_type IN ('cash_in', 'cashout'));

COMMIT;
