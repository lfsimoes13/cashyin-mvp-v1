# Runbook: Provider Incident

**Author:** Manus AI  
**Status:** Initial operational runbook

This runbook describes the first response when a provider has degraded availability, incorrect balances, delayed webhooks, elevated failure rates, or suspected reconciliation divergence.

| Step | Action | Expected Outcome |
|---|---|---|
| 1 | Confirm whether the incident affects cash-in, cash-out, balance lookup, or webhooks | Scope is narrowed before routing changes |
| 2 | Check recent provider errors, latency, and timeout rates | Determine whether failures are transient or systemic |
| 3 | Pause new cash-out routing if provider liquidity or confirmation is unreliable | Prevents financial exposure |
| 4 | Keep webhook ingestion active for historical operations | Late confirmations and reversals are still captured |
| 5 | Move new traffic through provider assignment versioning if an alternative is ready | Migration is auditable and reversible |
| 6 | Reconcile pending operations against provider status endpoints | Internal state converges with provider reality |
| 7 | Record timeline, affected clients, financial exposure, and remediation | Audit trail is preserved |

## Do Not Do

Do not manually edit balances, delete webhook events, delete ledger entries, or overwrite provider references. Do not move cash-out traffic to a provider account without liquidity validation. Do not disable the old provider account until pending historical operations are fully drained.

## Recovery Criteria

A provider incident is considered recovered when new operation error rates return to baseline, provider balance and CashYin liquidity snapshots are consistent, pending operations have been reconciled, and client webhook delivery has caught up.

## References

[1]: https://sre.google/sre-book/incident-response/ "Google SRE Book: Emergency Response"  
[2]: https://opentelemetry.io/docs/concepts/signals/metrics/ "OpenTelemetry Metrics"

