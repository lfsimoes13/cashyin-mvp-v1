# Conectando ao banco de produção localmente

O banco RDS de produção fica em sub-rede privada (sem IP público).  
A conexão local é feita via **SSM Session Manager Port-Forwarding** — sem SSH, sem chave, sem regra de firewall expondo o RDS.

```
Local  :15432  ──SSM tunnel──►  EC2 bastion  ──VPC internal──►  RDS :5432
```

---

## Pré-requisitos (instalar uma vez)

```bash
# 1. AWS CLI v2
brew install awscli              # macOS
# verificar
aws --version                    # aws-cli/2.x.x

# 2. Session Manager plugin para AWS CLI
brew install --cask session-manager-plugin
# verificar
session-manager-plugin --version

# 3. psql (opcional, para usar o terminal interativo)
brew install libpq
echo 'export PATH="/opt/homebrew/opt/libpq/bin:$PATH"' >> ~/.zshrc
source ~/.zshrc
```

---

## Credenciais AWS

Você precisa ter credenciais com permissão `ssm:StartSession` na conta.

```bash
# Opção A — perfil dedicado
aws configure --profile cashyin-prod
# Insira: Access Key ID, Secret Access Key, Region: sa-east-1, Output: json

# Opção B — se já tiver um perfil padrão configurado
aws sts get-caller-identity   # confirma que está na conta certa (960833581173)
```

---

## Passo a passo para conectar

### 1. Abrir o túnel SSM (terminal separado — fica rodando)

```bash
aws ssm start-session \
  --target i-08d14a87a0a64458e \
  --document-name AWS-StartPortForwardingSessionToRemoteHost \
  --parameters '{
    "host":       ["cashyin-core-api.clyii6mwcu5z.sa-east-1.rds.amazonaws.com"],
    "portNumber": ["5432"],
    "localPortNumber": ["15432"]
  }' \
  --region sa-east-1
```

Você verá:
```
Starting session with SessionId: ...
Port 15432 opened for sessionId ...
Waiting for connections...
```

> Mantenha este terminal aberto enquanto usa o banco.

### 2. Obter a senha do banco (em outro terminal)

O secret é uma `DATABASE_URL` completa. Use o comando abaixo para extrair a senha:

```bash
export PGPASSWORD=$(aws secretsmanager get-secret-value \
  --secret-id cashyin/prod-baseline/database-url \
  --region sa-east-1 \
  --query SecretString \
  --output text \
  | python3 -c "import sys; from urllib.parse import urlparse, unquote; print(unquote(urlparse(sys.stdin.read().strip()).password))")

echo "Senha obtida: OK"
```

Para inspecionar a URL completa (sem expor no terminal):

```bash
aws secretsmanager get-secret-value \
  --secret-id cashyin/prod-baseline/database-url \
  --region sa-east-1 \
  --query SecretString \
  --output text \
  | python3 -c "
import sys
from urllib.parse import urlparse, unquote
url = sys.stdin.read().strip()
p = urlparse(url)
print('user:    ', p.username)
print('host:    ', p.hostname)
print('db:      ', p.path.lstrip('/').split('?')[0])
print('password:', unquote(p.password))
"
```

### 3. Conectar com psql

```bash
psql \
  --host 127.0.0.1 \
  --port 15432 \
  --dbname cashyin \
  --username cashyin_admin
```

Ou com a URL completa (substitua `<SENHA>` pela saída do passo 2):

```bash
psql "postgres://cashyin_admin:<SENHA>@127.0.0.1:15432/cashyin"
```

### 4. Conectar com TablePlus / DBeaver / DataGrip

| Campo    | Valor                  |
|----------|------------------------|
| Host     | `127.0.0.1`            |
| Port     | `15432`                |
| Database | `cashyin`              |
| User     | `cashyin_admin`        |
| Password | *(obtida no passo 2)*  |
| SSL      | desligado (é tunnel local) |

---

## Script de atalho (opcional)

Salve como `~/bin/cashyin-db`:

```bash
#!/bin/bash
set -e

echo "► Abrindo túnel SSM para o RDS de produção..."
aws ssm start-session \
  --target i-08d14a87a0a64458e \
  --document-name AWS-StartPortForwardingSessionToRemoteHost \
  --parameters '{"host":["cashyin-core-api.clyii6mwcu5z.sa-east-1.rds.amazonaws.com"],"portNumber":["5432"],"localPortNumber":["15432"]}' \
  --region sa-east-1 &
SSM_PID=$!

echo "► Aguardando túnel ficar pronto..."
sleep 3

echo "► Obtendo senha..."
export PGPASSWORD=$(aws secretsmanager get-secret-value \
  --secret-id cashyin/prod-baseline/database-url \
  --region sa-east-1 \
  --query SecretString --output text \
  | python3 -c "import sys; from urllib.parse import urlparse, unquote; print(unquote(urlparse(sys.stdin.read().strip()).password))")

echo "► Conectando ao banco (psql)..."
psql --host 127.0.0.1 --port 15432 --dbname cashyin --username cashyin_admin

echo "► Encerrando túnel..."
kill $SSM_PID 2>/dev/null || true
```

```bash
chmod +x ~/bin/cashyin-db
cashyin-db
```

---

## Referências de infraestrutura

| Recurso           | Valor                                                                 |
|-------------------|-----------------------------------------------------------------------|
| Bastion EC2       | `i-08d14a87a0a64458e` (t3.micro, sa-east-1a)                        |
| Bastion EIP       | `56.126.112.147` (não necessário para conexão, só para o SSM agent)  |
| RDS endpoint      | `cashyin-core-api.clyii6mwcu5z.sa-east-1.rds.amazonaws.com:5432`    |
| RDS database      | `cashyin`                                                             |
| RDS user          | `cashyin_admin`                                                       |
| Secrets Manager   | `cashyin-core-api/rds`                                               |
| VPC               | `vpc-0eedd485dcc4bdfcb`                                              |
| Bastion SG        | `sg-0258275b85531d3df`                                               |
| RDS SG            | `sg-04ec12a2ebda821c0`                                               |

---

## Sobre o VPN (NordVPN)

O túnel SSM **não depende do VPN**. A conexão parte do seu IP atual (VPN ou não) para o endpoint da AWS SSM via HTTPS. O RDS não fica exposto na internet em nenhum momento.

Se quiser garantir que apenas o IP `146.70.163.123` (NordVPN) possa usar o bastion via SSH, isso seria feito no SG do bastion — mas como o acesso é 100% via SSM (sem SSH), não há porta aberta no SG, então não é necessário restringir por IP de origem.

---

## Reset do banco de produção (quando necessário)

> Use apenas em ambientes de teste/staging — destrói todos os dados.

```bash
# 1. Abrir túnel (passo 1 acima)

# 2. Exportar senha
export PGPASSWORD=$(aws secretsmanager get-secret-value \
  --secret-id cashyin/prod-baseline/database-url --region sa-east-1 \
  --query SecretString --output text \
  | python3 -c "import sys; from urllib.parse import urlparse, unquote; print(unquote(urlparse(sys.stdin.read().strip()).password))")

# 3. Drop + recreate schema
psql "postgres://cashyin_admin@127.0.0.1:15432/cashyin" \
  -c "DROP SCHEMA public CASCADE; CREATE SCHEMA public;"

echo "Schema resetado. O próximo deploy vai aplicar as migrations do zero."
```

Depois do reset, faça deploy para reaplicar as migrations e provisione o cliente de teste:

```bash
# Provision via ECS exec (não precisa do túnel)
aws ecs execute-command \
  --cluster cashyin-core-api \
  --task <TASK_ID> \
  --container api \
  --command "node scripts/provision-test-client.mjs" \
  --interactive \
  --region sa-east-1
```
