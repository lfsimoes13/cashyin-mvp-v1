# CashYin Architecture

**Author:** Manus AI  
**Status:** Initial implementation guidance  
**System:** CashYin Core API

CashYin is a new, independent PIX processing platform. Its first milestone is the transactional core: cash-in charge creation, cash-out payment initiation, native Bents integration, provider abstraction, idempotency, append-only ledger design, webhook ingestion, and an outbox boundary for asynchronous delivery. The system intentionally avoids coupling to JadeLink v1 contracts, naming, provider assumptions, and infrastructure decisions.

> CashYin must be treated as a financial source-of-truth system. Every state transition that affects money must be idempotent, auditable, replay-safe, and tied to a durable ledger record.

| Layer | Responsibility | Initial Technology |
|---|---|---|
| Public API | Synchronous request validation, authentication boundary, idempotency enforcement, fast response | Fastify and TypeScript |
| Domain modules | Payments, cash-outs, ledger, liquidity, clients, providers, webhooks | Modular TypeScript services |
| Provider adapters | External API communication and payload mapping | `PaymentProvider` interface with Bents adapter |
| Transactional storage | Financial state, ledger, idempotency, assignments, outbox | PostgreSQL or Aurora PostgreSQL |
| Operational cache | Rate limits, short-lived locks, hot assignment cache | Redis |
| Async execution | Webhook delivery, outbox dispatch, reconciliation jobs | Queue workers, SQS planned for AWS |
| Observability | Structured logs, metrics, traces, audit correlation | Pino and OpenTelemetry-ready boundaries |

## Core Invariants

The first invariant is **provider isolation**. Domain services must not know Bents payloads, endpoint paths, status names, or authentication details. The Bents adapter maps Bents-specific requests and responses into CashYin provider contracts.

The second invariant is **ledger-first accounting**. Client balances are not derived from provider balances. Provider liquidity represents operational money available in a provider account. Client accounting balance represents what CashYin owes or can debit from the client. These two concepts must never be collapsed into a single “pool” field.

The third invariant is **retry-safety for every public write**, achieved differently per flow:

- **Cash-out** creation **requires** `Idempotency-Key`, scoped by client. Replaying the same key with a different request hash is rejected (`409 idempotency_key_conflict`) rather than creating an ambiguous financial operation.
- **Cash-in** creation does **not** use `Idempotency-Key`. It is deduplicated by the `(client_id, external_ref)` business rule — repeating the same `external_ref` returns the original charge — enforced by a `UNIQUE (client_id, external_ref)` constraint. Any `Idempotency-Key` sent on cash-in is silently ignored.

The fourth invariant is **append-only auditability**. Ledger records, webhook events, and outbox events must be appended. Corrections happen through compensating entries and state transitions, not destructive updates.

## Request Flow

| Flow | Synchronous Path | Asynchronous Path |
|---|---|---|
| Cash-in charge | Validate request, dedup by `(client_id, external_ref)`, resolve provider assignment, create provider charge, persist charge and outbox event | Deliver client notification after payment webhook |
| Cash-out payment | Validate request, lock idempotency key, reserve accounting balance, reserve provider liquidity, initiate provider payment, persist cash-out and outbox event | Confirm/reverse after provider webhook or reconciliation |
| Provider webhook | Verify signature, persist raw event, deduplicate, map provider status, update transaction state | Dispatch client webhook and reconciliation events |
| Provider migration | Create new assignment version, move cash-in first, move cash-out only after liquidity readiness, drain old provider | Reconcile old provider until no pending operations remain |

## Performance Direction

The transactional API should only perform work needed to accept or reject an operation safely. Heavy reports, dashboards, and BI queries should be served by read models, replicas, or a data lake. This keeps the write path predictable under high volume.

## References

[1]: https://www.fastify.io/docs/latest/ "Fastify Documentation"  
[2]: https://www.postgresql.org/docs/current/ddl-partitioning.html "PostgreSQL Declarative Partitioning"  
[3]: https://opentelemetry.io/docs/ "OpenTelemetry Documentation"

