# Multi-Provider Implementation Guide

**Author:** Manus AI  
**Status:** Initial implementation guidance

CashYin is provider-agnostic by design. Bents is the initial native provider, but the core API must not be rewritten when a second provider is introduced. New providers should be added by implementing the `PaymentProvider` contract and registering the adapter in the provider registry.

| Requirement | Implementation Rule |
|---|---|
| Provider-specific authentication | Keep inside `src/providers/<provider>/` |
| Provider-specific status mapping | Convert to CashYin canonical statuses in mapper files |
| Provider-specific payload fields | Preserve raw payload in `raw`, expose only canonical DTOs to domain modules |
| Provider selection | Use versioned `client_provider_assignments` records |
| Operation support differences | Represent as adapter capabilities, not `if provider === ...` in domain code |

## Provider Contract

The initial provider contract lives in `src/providers/contracts/payment-provider.ts`. A provider must support cash-in creation, cash-in status lookup, cash-out initiation, balance lookup, and webhook signature verification. If a provider lacks a capability, the adapter must fail explicitly with a typed error rather than silently degrading behavior.

## Adding a New Provider

A new provider should use the following structure.

| File | Purpose |
|---|---|
| `src/providers/<provider>/<provider>.client.ts` | HTTP client, authentication, retry-safe error handling |
| `src/providers/<provider>/<provider>.provider.ts` | Implements `PaymentProvider` |
| `src/providers/<provider>/<provider>.mapper.ts` | Maps provider statuses and payloads into CashYin canonical types |
| `src/providers/<provider>/<provider>.types.ts` | Provider-specific API response/request types |
| `tests/contract/<provider>.spec.ts` | Contract tests with mocked provider responses |

The provider adapter should not write directly to the database. Persistence belongs to domain services and repositories so that provider behavior remains replaceable.

## Bents Initial Mapping

The Bents public API uses Bearer token authentication and exposes endpoints for balance, PIX charge creation, charge status, PIX payment, DICT lookup, and batch charge creation. CashYin starts with the synchronous endpoints needed for charge creation, charge status, payment initiation, and balance checks.

| CashYin Capability | Bents Endpoint |
|---|---|
| Provider balance | `GET /balance` |
| Create PIX charge | `POST /pix/charge` |
| Get PIX charge | `GET /pix/charge/{uuid}` |
| Send PIX payment | `POST /pix/payment` |

## References

[1]: https://finance.bents.com.br/docs "Bents Finance API Documentation"  
[2]: https://www.fastify.io/docs/latest/ "Fastify Documentation"

