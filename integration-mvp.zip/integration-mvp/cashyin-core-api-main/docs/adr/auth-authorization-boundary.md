# ADR: Fronteira de Autenticação e Autorização do Chamador na Core API

**Data:** 2026-05-31
**Status:** Aceito (somente a fundação — ver "Escopo do PR 1")

## Contexto

A CashYin Core API expõe rotas críticas de cobrança Pix
(`POST /v1/pix/cash-in/qrcode`) e de cash-out (`POST /v1/pix/cash-out`). Hoje
essas rotas são protegidas por um único preHandler de bearer token
(`requireClientAuth`) que resolve uma linha de `client_api_keys` em
`request.client`, e os schemas públicos de requisição ainda aceitam um
equivalente a `clientId` no corpo, que flui para idempotência, atribuição de
provedor, precificação, liquidez, persistência, ledger e semântica de outbox.

Estamos caminhando para um modelo em camadas:

- **Usuários humanos** autenticam por meio de um futuro
  **Backend-for-Frontend (BFF)** usando e-mail/senha, de preferência apoiado pelo
  **Cognito**.
- O **BFF** chama a Core API com um contexto de identidade interno confiável.
- **Clientes de API direta** autenticam com credenciais emitidas pela CashYin
  usando **assinatura HMAC de requisição** (em um PR posterior) e possivelmente
  **mTLS**.
- O **cash-out** exige autorização de **step-up / dois fatores** (em um PR
  posterior).

A Core API fica em um caminho crítico financeiro de alto volume. Ela não deve
chamar o Cognito, introspecção OAuth ou qualquer serviço de autenticação remoto
de forma síncrona a partir do caminho de requisição de cobrança Pix ou de
cash-out.

## Decisão

1. **Introduzir uma única fronteira `AuthContext` normalizada.** Todo mecanismo
   de autenticação (sessão de BFF, credencial HMAC direta, identidade de serviço
   interno, webhook de provedor) é reduzido a um único formato `AuthContext`
   agnóstico de transporte (`channel`, `principalType`, `principalId`, `scopes`,
   `clientId` opcional, `roles`, `amr`, `stepUp`, `credentialId`, timestamps).
   Guards e serviços a jusante autorizam sobre esse formato e nunca ramificam com
   base em *como* o chamador provou a identidade.

2. **Recomendar BFF + Cognito para login humano, mas nunca uma chamada remota ao
   Cognito por requisição na Core.** A verificação de credenciais humanas, MFA e
   emissão de sessão pertencem ao BFF / Cognito. A Core confia em um contexto de
   identidade interno verificado vindo do BFF (canal `frontend_bff`). Fazer
   chamadas remotas ao IdP no caminho crítico do Pix adicionaria latência e uma
   dependência externa rígida às rotas mais sensíveis a latência e
   disponibilidade do sistema.

3. **Clientes de API direta usam HMAC (e opcionalmente mTLS) em PRs
   posteriores.** Chamadores de máquina recebem credenciais emitidas pela CashYin
   e assinam requisições (HMAC sobre uma representação canônica da requisição),
   de modo que a verificação seja local, rápida e resistente a replay —
   novamente sem dependência de autenticação remota no caminho crítico.

4. **O `clientId` do corpo da requisição é transitório.** Hoje ele dirige o
   escopo de tenant, mas é controlável pelo atacante, o que é um risco de
   autorização quebrada de objeto/tenant. O alvo é derivar o tenant do
   `AuthContext.clientId` autenticado e impor que qualquer `clientId` fornecido no
   corpo coincida (ou removê-lo do contrato). Este ADR registra a intenção; a
   derivação/imposição efetiva é um PR posterior, para preservar
   retrocompatibilidade.

5. **Guards são funções puras, sem efeitos colaterais.** `requireAuth`,
   `requireScope`, `requireClientAccess`, `requireAnyAmr` e
   `requireCashoutStepUp` operam puramente sobre um `AuthContext` e lançam o
   `AppError` do projeto. Não realizam I/O de banco/cache/rede, portanto não
   adicionam latência aos caminhos críticos e são trivialmente testáveis em
   unidade.

6. **A imposição é controlada por feature flag via `AUTH_ENFORCEMENT_MODE`**
   (`off` | `shadow` | `enforce`), com padrão `off`.

## Escopo do PR 1 (por que ainda *não* impomos autenticação)

O PR 1 entrega apenas a fundação: o tipo `AuthContext`, as constantes de escopo,
a tipagem da request do Fastify, os erros de autenticação não vazantes, os guards
puros, a flag `AUTH_ENFORCEMENT_MODE` (padrão `off`), testes e documentação.

Ele intencionalmente **não**:

- impõe autenticação em nenhuma rota existente,
- altera o comportamento em runtime de cobrança Pix ou cash-out,
- adiciona qualquer chamada de banco/cache/rede a essas rotas,
- implementa Cognito, o BFF, verificação HMAC, mTLS ou persistência de step-up,
- altera os schemas públicos (incluindo o `clientId` do corpo).

Dividir o trabalho dessa forma mantém cada mudança pequena e revisável, permite
que a fundação de tipos/guards entre e amadureça com risco zero em runtime, e
garante que a latência e o comportamento dos caminhos críticos financeiros
permaneçam intocados até um PR dedicado e revisado separadamente que conecte a
resolução e a imposição por trás da flag.

## Atualização — PR 2: resolução e imposição por escopo (canal `api_direct`)

O PR 2 conecta a fundação ao runtime para o canal de API direta, **sem alterar o
contrato de autenticação** existente:

- Um preHandler `resolveAuthContext` projeta o `ClientPrincipal` já resolvido por
  `requireClientAuth` em um `AuthContext` (`channel='api_direct'`,
  `principalType='api_client'`, `principalId=clientId`, `clientId`,
  `credentialId=apiKeyId`, `scopes` da credencial). A autenticação Bearer
  continua sempre imposta; o `AuthContext` é uma camada aditiva. **O contexto é
  resolvido incondicionalmente** quando há principal (independente de
  `AUTH_ENFORCEMENT_MODE`), para que tenant e ator de auditoria estejam sempre
  disponíveis — desvio D8 resolvido (ver `implementation-plan.md` §9).
- Guards de escopo por rota (`requireScope`) são aplicados às quatro rotas Pix
  críticas (`pix:cash_in:create/read`, `pix:cash_out:create/read`), encenados por
  `AUTH_ENFORCEMENT_MODE` (apenas a **autorização por escopo** é encenada; a
  resolução do contexto não):
  - `off` (padrão): nenhuma checagem de escopo — o contexto ainda é resolvido,
    mas a camada de escopo fica inerte.
  - `shadow`: resolve o contexto e avalia o escopo, mas **não nega** — negações
    potenciais são logadas (sem segredos) e contadas em
    `cashyin_auth_scope_decisions_total` para dimensionar o raio antes do
    `enforce`.
  - `enforce`: nega requisições sem o escopo com o `AppError` estável
    (`auth_insufficient_scope`, 403).
- `GET /v1/balance` permanece apenas com autenticação Bearer (sem guard de
  escopo) porque o conjunto padrão `DEFAULT_CLIENT_API_SCOPES` não inclui uma
  capacidade de balance; impor uma aqui negaria clientes existentes no `enforce`.
  Um escopo dedicado de leitura é trabalho de um PR posterior (administração).
- **Derivação de tenant:** o `clientId` canônico passa a vir do principal
  autenticado (`AuthContext.clientId`), que é a mesma origem do
  `request.client.clientId` já injetado nos handlers. Como os schemas públicos
  não aceitam `client_id` no corpo, não há divergência a rejeitar hoje; o guard
  `requireClientAccess` permanece disponível caso um campo legado de
  compatibilidade seja reintroduzido.

## Atualização — PR 3: canal BFF confiável (`frontend_bff`)

- **Decisão de confiança:** o BFF prova-se com um **segredo compartilhado**
  (`X-CashYin-BFF-Token`, comparado timing-safe), não com JWT interno — evita
  nova dependência e mantém a verificação local (sem IdP no caminho crítico).
  Acompanha `X-CashYin-Actor-User-Id` e `X-CashYin-Client-Id` (confiáveis porque
  o BFF é confiável). Gated por `BFF_AUTH_MODE` (`off`/`enforce`) +
  `BFF_SHARED_SECRET`.
- **Autenticador unificado** (`src/modules/auth/authenticate.ts`): produz um
  `ResolvedPrincipal` (canal-agnóstico) a partir de qualquer credencial — BFF ou
  Bearer `api_direct`. `resolveAuthContext` projeta-o no `AuthContext`. Um token
  BFF inválido retorna 401 **sem** cair para o Bearer (semântica de negação
  inequívoca).
- **Autoridade de escopos:** o canal BFF tem como **teto** o conjunto
  `DEFAULT_BFF_SCOPES` — o BFF não pode escalar além disso. RBAC por usuário
  (D7) foi implementado: com `BFF_RBAC_MODE=enforce`, o autenticador resolve o
  grant `(ator, tenant)` em `user_client_grants` e interseciona com o teto;
  ator sem grant ativo → 403. Grants são geridos via `/v1/admin/bff-grants`
  (escopo `clients:manage`).

## Atualização — PR 4: endpoints de administração (`/v1/admin/*`)

- `clientId` é derivado do principal autenticado (sem `:clientId` no path):
  remove a superfície de cross-tenant. Gestão de chaves (`api_keys:manage`) e de
  webhook endpoints (`webhooks:manage`) ficam restritas ao próprio tenant.
- Rotas administrativas **sempre impõem** o escopo (modo `enforce` fixo),
  independente de `AUTH_ENFORCEMENT_MODE` — são rotas novas, sem cliente legado a
  proteger. Segredos (raw key, `signing_secret`, webhook `signing_secret`) são
  exibidos **uma única vez** na criação/rotação e nunca em GET.

## Atualização — PR 5: step-up de cash-out

- Provas persistidas em `cashout_step_up_proofs`, vinculadas ao
  `canonicalCashoutHash` (cliente + valor + destino + ref). Consumo é **atômico e
  de uso único** (UPDATE `issued→consumed` com hash/expiry no WHERE), subsumindo
  o guard puro. Gated por `CASHOUT_STEPUP_MODE`.
- Imposição limitada ao canal `frontend_bff` (humano); cash-outs `api_direct`
  (máquina) são isentos, pois a API key já é a credencial. O BFF emite a prova em
  `POST /v1/pix/cash-out/step-up` após o MFA do humano.

## Atualização — PR 6: assinatura HMAC para `api_direct`

- Cada chave ganha um `signing_secret` (migration `0019`, exibido uma vez). O
  cliente assina uma string canônica (método, url, timestamp, nonce, digest do
  body canônico JSON de chaves ordenadas). Gated por `API_HMAC_MODE`; camada
  **aditiva** sobre o Bearer (coexistência durante a transição).
- Anti-replay por timestamp (`API_HMAC_CLOCK_SKEW_MS`) + **nonce store
  compartilhado em Postgres** (`api_hmac_nonces`, migration `0020`): o nonce é
  "gasto" uma única vez por chave dentro da janela, via upsert atômico que
  distingue primeiro uso (insere → `fresh`), replay não-expirado (conflito sem
  update → replay) e revive de nonce expirado (conflito com update → `fresh`). O
  `ApiHmacVerifier` recebe um `ApiHmacNonceStore` injetável (`InMemory...` para
  testes/single-instance; `PgApiHmacNonceStore` no runtime). Chaves anteriores à
  `0019` (`signing_secret` NULL) não assinam e devem ser rotacionadas antes do
  `enforce`.

## Atualização — item 4.4: leitura administrativa de configuração (`/v1/admin/config/*`)

- `GET /v1/admin/config/fees` e `GET /v1/admin/config/routing`, somente leitura,
  tenant derivado do `AuthContext`, sob `clients:read` (parte do conjunto default
  do BFF). `ClientConfigService` compõe a regra de tarifa ativa e o assignment
  ativo do provedor e os reprojeta por uma **allow-list estrita**: expõe apenas a
  fórmula de tarifa do cliente e o `provider_name`. Nunca expõe custo de provedor,
  margem, política de subsídio, `provider_account_id`, `metadata` ou segredos.

## Consequências

- Existe uma costura estável e bem tipada para futuros canais de autenticação,
  sem mais churn nas assinaturas das rotas.
- Revisores podem raciocinar sobre a lógica de autorização isoladamente (guards
  puros + testes de unidade) antes que exista qualquer ligação em runtime.
- O `clientId` do corpo permanece um risco conhecido e documentado até o PR de
  acompanhamento; o modelo de ameaças (`docs/security/auth-threat-model.md`) o
  acompanha.
- Adicionar um novo canal depois significa produzir um `AuthContext`, não tocar
  em todo guard ou rota.

## Referências

- `src/shared/auth/auth-context.ts`, `auth-scopes.ts`, `auth-errors.ts`,
  `guards.ts`, `fastify-auth-context.ts`
- `docs/security/auth-threat-model.md`
- OWASP API Security Top 10 — API1:2023 Broken Object Level Authorization,
  API2:2023 Broken Authentication
