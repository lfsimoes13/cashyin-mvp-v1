# ADR 0001: CashYin Core Architecture

**Date:** 2026-05-22  
**Status:** Accepted  
**Author:** Manus AI

## Context

CashYin is a new product and not a JadeLink v1 refactor. It needs a high-performance PIX processing API, native Bents integration, multi-provider extensibility, safe provider migration, and a financial model that separates client accounting balance from provider operational liquidity.

## Decision

CashYin will use a modular TypeScript and Fastify API, PostgreSQL as the financial source of truth, Redis for operational cache and locks, provider adapters behind a `PaymentProvider` interface, append-only ledger entries, versioned provider assignments, and an outbox pattern for asynchronous side effects.

## Consequences

This decision prioritizes clear financial boundaries, auditability, and provider independence. It requires disciplined schema migrations, repository boundaries, and contract tests. It also intentionally defers advanced BI and Grafana dashboards so that the first milestone remains focused on the transactional core.

## References

[1]: https://www.fastify.io/docs/latest/ "Fastify Documentation"  
[2]: https://www.postgresql.org/docs/current/ "PostgreSQL Documentation"  
[3]: https://opentelemetry.io/docs/ "OpenTelemetry Documentation"

