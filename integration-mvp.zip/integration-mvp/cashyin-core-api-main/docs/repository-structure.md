# Repository Structure

**Author:** Manus AI  
**Status:** Initial implementation guidance

The `cashyin-core-api` repository uses lowercase kebab-case for the repository name and domain-oriented folders inside `src/`. The goal is to keep financial domain rules isolated from provider-specific integrations, HTTP framework details, and worker execution concerns.

| Path | Responsibility |
|---|---|
| `src/app/` | Fastify application assembly, route registration, server bootstrap boundaries |
| `src/modules/payments/` | Cash-in use cases, request validation, application service orchestration |
| `src/modules/cashouts/` | Cash-out use cases, liquidity-aware orchestration, provider payment initiation |
| `src/modules/ledger/` | Double-entry ledger types and posting rules |
| `src/modules/liquidity/` | Provider liquidity reservations and operational liquidity controls |
| `src/modules/idempotency/` | Idempotency records, request hashes, write deduplication |
| `src/modules/outbox/` | Transactional outbox event creation |
| `src/modules/providers/` | Provider registry and provider assignment orchestration |
| `src/modules/webhooks/` | Provider webhook ingestion and event processing boundary |
| `src/providers/contracts/` | Provider interfaces and canonical provider DTOs |
| `src/providers/bents/` | Native Bents adapter, client, mappers, and provider-specific types |
| `src/shared/` | Cross-cutting utilities such as config, errors, security, validation, observability |
| `src/workers/` | Long-running or queue-triggered asynchronous workers |
| `migrations/` | PostgreSQL schema migrations, written before repository code depends on them |
| `docs/` | Source-controlled architecture, operations, Cursor guidance, and decision records |
| `docs/webhooks/` | Transactional status normalization, public client webhook contracts, outbox behavior, and webhook refactor research |
| `docs/provider-integration/` | Provider-facing infrastructure architecture, fixed egress IP, DNS/domain strategy, provider webhook ingress, and provider adapter boundaries |
| `docs/cursor/prompts/` | Task-specific prompts for Cursor/Opus implementation work |
| `infra/` | Future infrastructure-as-code definitions |
| `tests/` | Unit, integration, and provider contract tests |

## Naming Rules

Domain folders should use plural nouns when they represent modules, such as `payments`, `cashouts`, and `providers`. Provider folders should use the provider slug, such as `bents`. File names should use kebab-case and describe the role, for example `bents.provider.ts`, `payment.service.ts`, and `cashout.routes.ts`.

## Boundary Rules

Framework code should not leak into domain rules. Provider DTOs should not leak into public API responses unless explicitly mapped. Database code should live behind repositories that are introduced into modules, not inside route handlers.

## References

[1]: https://www.typescriptlang.org/docs/ "TypeScript Documentation"  
[2]: https://www.fastify.io/docs/latest/ "Fastify Documentation"

