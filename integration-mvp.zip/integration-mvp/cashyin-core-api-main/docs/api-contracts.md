# Public API Contract Draft

**Author:** Manus AI  
**Status:** Initial draft for technical review

This document describes the first public-facing CashYin API draft. The routes are intentionally redesigned for CashYin and do not need to preserve JadeLink v1 payload compatibility.

## Conventions

Amounts are represented in cents as integers. Dates use ISO 8601 strings. The API returns a stable `request_id` in error responses. Public contracts (request bodies, responses, webhooks, DB columns) use `snake_case`. `client_id` is never accepted in a body — it is resolved from the `Authorization` credential.

| Header | Required | Description |
|---|---:|---|
| `Authorization` | Yes | `Bearer <client API key>` |
| `Idempotency-Key` | **Cash-out only** | Unique client operation key for `POST /v1/pix/cash-out` |
| `Content-Type` | For writes | `application/json` |

### Idempotency model

The two write endpoints use **different** retry-safety mechanisms:

- **Cash-in (`POST /v1/pix/cash-in/qrcode`)** does **not** use the `Idempotency-Key` header. Retry-safety is a business rule keyed on `(client_id, external_ref)`: repeating the same `external_ref` returns the **original** charge instead of creating a duplicate Pix charge (enforced by `UNIQUE (client_id, external_ref)`). Any `Idempotency-Key` header a client happens to send is **silently ignored** — it is never read, validated, persisted, or forwarded.
- **Cash-out (`POST /v1/pix/cash-out`)** **requires** the `Idempotency-Key` header. The key is scoped per `(client_id, key)`. Replaying the same key with the **same** payload returns the original operation; replaying with a **different** payload fails with `409 idempotency_key_conflict`.

## Create PIX Charge (cash-in)

`POST /v1/pix/cash-in/qrcode` — **no `Idempotency-Key` header**

```json
{
  "external_ref": "order-123",
  "amount": 15000,
  "description": "Order 123"
}
```

Returns `201`. The public `txid` (CashYin-generated, 32 lowercase hex chars) is the canonical identifier. The response never exposes internal identifiers (`id`, `client_id`, `provider_charge_id`, `provider_tx_id`) or pricing fields. Repeating the same `external_ref` returns the existing charge.

## Get PIX Charge (cash-in)

`GET /v1/pix/cash-in/{txid}`

Looks up a charge by its public `txid`, scoped to the authenticated client.

## Create PIX Payment (cash-out)

`POST /v1/pix/cash-out` — **requires `Idempotency-Key` header**

```json
{
  "externalId": "withdrawal-123",
  "amountCents": 10000,
  "pixKey": "merchant@example.com",
  "description": "Withdrawal 123"
}
```

Returns `202` because provider confirmation is asynchronous. Before provider execution, the implementation reserves both accounting balance and provider liquidity. The ledger debit happens only on the completion webhook, guarded against double-debit by `ledger_idempotency_keys`.

## Error Shape

```json
{
  "error": {
    "code": "validation_error",
    "message": "Invalid PIX charge payload",
    "request_id": "req-123"
  }
}
```

## References

[1]: https://www.rfc-editor.org/rfc/rfc9110 "HTTP Semantics"  
[2]: https://www.rfc-editor.org/rfc/rfc9457 "Problem Details for HTTP APIs"

