# Core API — Client Identity & Tenant Authorization Ownership

**Status:** Accepted
**Scope:** How the Core API establishes the effective tenant (`clientId`) for
critical transactional Pix routes, and who owns financial clients and
credentials.

## Decisions

1. **Body `clientId` is legacy and non-authoritative.** The public request
   bodies for the critical transactional routes do **not** accept a
   `clientId`/`client_id` field. Should any caller smuggle one, it is dropped at
   the schema boundary (Zod strips unknown keys) and can never reach idempotency,
   provider assignment, pricing, liquidity reservation, persistence, the outbox,
   or any provider call.

2. **Core API owns the canonical financial clients and direct API credentials.**
   `clients.id` is already the authority used across idempotency, provider
   assignment, pricing, liquidity, ledger, webhook dispatch, and persistence.
   Direct API credentials (`client_api_keys`) are minted, hashed (SHA-256), and
   verified inside the Core API.

3. **The BFF owns human login/session UX (preferably via Cognito) but not the
   financial records.** The BFF authenticates humans and manages sessions; it
   does not own the canonical `clients` rows or direct API credential material.
   It will later call a protected Core admin/provisioning surface to create
   clients and credentials. The BFF is not implemented in this repository.

4. **Direct API clients authenticate with an API key.** Requests carry
   `Authorization: Bearer ck_...`; the `requireClientAuth` preHandler resolves the
   key to a single-tenant principal on `request.client`. Verification is a local,
   prefix-indexed DB read with constant-time hash comparison — no remote IdP call
   on the hot path.

5. **Transactional routes derive the tenant from the authenticated context.**
   The route handlers build the service input from `request.client.clientId`
   (cash-in: `{ ...body, client_id: client.clientId }`; cash-out:
   `toCreateCashoutInput(body, client.clientId)`), never from the body.

6. **Follow-ups (not in scope here):** HMAC request signing for direct clients,
   mTLS, and cash-out step-up / 2FA are future hardening items. The Core API must
   never call Cognito, OAuth introspection, or any remote IdP synchronously from
   the Pix charge or cash-out hot paths.

## Regression coverage

`tests/unit/tenant-clientid-boundary.spec.ts` locks the boundary in place:
schema-strip tests, the `toCreateCashoutInput` mapper, and route-wiring tests
proving (a) missing auth → 401 on both protected POST routes and (b) a body that
smuggles another tenant's id still results in the service being invoked with the
authenticated client id.
