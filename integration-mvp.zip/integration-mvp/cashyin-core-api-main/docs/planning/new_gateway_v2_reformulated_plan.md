# Plano Reformulado — Nova API v2, nova marca, novo domínio e Bents nativo

Autor: **Manus AI**  
Data: **2026-05-22**

## 1. Direção recomendada

A decisão mais segura agora é tratar a v2 como um **produto novo**, com **novo repositório, nova marca, novo domínio, novo gateway, novos contratos de API e integração nativa com a Bents**. A JadeLink v1 deve permanecer como sistema legado estável, servindo apenas como fonte de aprendizado: regras de negócio, casos de borda, estados financeiros, erros operacionais, reconciliação, idempotência, padrões de fraude, integração com clientes e comportamento de providers.

A v2 não deve ser uma cópia da v1. O caminho ideal é construir um **core financeiro novo**, desenhado desde o início para baixa latência, consistência transacional, rastreabilidade, auditoria e operação em produção. O ganho principal desse caminho é eliminar o risco de afetar usuários da v1 e, ao mesmo tempo, permitir contratos melhores, um modelo de dados mais correto e uma arquitetura mais preparada para escala.

| Decisão | Recomendação |
|---|---|
| Repositório | **Novo repositório**, sem dependência direta da v1. |
| Marca/domínio | **Novo domínio e identidade operacional**, por exemplo `api.nova-marca.com.br`. |
| Provider inicial | **Bents nativo**, não adaptado como legado. |
| Contratos API | **Novos contratos v2**, com idempotência, correlation id, erros padronizados e eventos claros. |
| Banco principal | **Aurora PostgreSQL/PostgreSQL** como fonte de verdade financeira. |
| Processamento | API rápida + workers assíncronos + filas + outbox transacional. |
| Monitoramento | OpenTelemetry + Grafana/Prometheus/Loki/Tempo ou CloudWatch, com métricas de negócio e técnicas. |

## 2. Arquitetura técnica recomendada

A arquitetura deve separar a **rota crítica de resposta da API** do **processamento financeiro assíncrono**. A API deve validar, autenticar, aplicar idempotência, persistir intenção transacional e responder rapidamente. Chamadas demoradas, retentativas, postbacks para clientes, conciliação e rotinas de auditoria devem rodar fora da rota crítica.

![Arquitetura proposta da nova API v2](./new_gateway_v2_architecture.png)

A base recomendada é uma arquitetura AWS pragmática, com containers sempre quentes em ECS/Fargate ou EKS leve, Aurora PostgreSQL como banco financeiro, Redis para cache/locks curtos, SQS para filas de trabalho e EventBridge para roteamento de eventos. O Aurora é compatível com PostgreSQL e oferece armazenamento distribuído gerenciado e replicação/clustering operacionalmente simplificados, o que combina melhor com ledger, saldos, idempotência e auditoria do que um modelo puramente chave-valor.[1] O SQS é adequado para desacoplar componentes, armazenar mensagens de forma durável e escalar processamento assíncrono.[2] O EventBridge é útil para conectar componentes por eventos e rotear eventos para múltiplos consumidores de forma desacoplada.[3]

| Camada | Tecnologia recomendada | Responsabilidade |
|---|---|---|
| Edge | DNS novo, TLS, WAF, rate limit, proteção DDoS | Segurança e entrada da nova marca. |
| Gateway | ALB ou API Gateway HTTP | Roteamento, throttling, logs de borda e versionamento. |
| API v2 | Node.js Fastify/NestJS ou Go em containers sempre quentes | Endpoints rápidos, contratos v2, auth, idempotência e persistência inicial. |
| Banco financeiro | **Aurora PostgreSQL** | Ledger, transações, saldos, idempotência, webhook events e outbox. |
| Cache | Redis/ElastiCache | Cache de autenticação, rate limit, locks curtos e proteção contra repetição. |
| Filas | SQS Standard/FIFO conforme fluxo | Provider calls, webhooks, conciliação, retentativas e DLQ. |
| Eventos | EventBridge | Distribuição de eventos internos para consumers independentes. |
| Observabilidade | OpenTelemetry + Grafana stack ou CloudWatch | Traces, métricas, logs, alertas e painéis. |
| Analytics | S3/Data Lake + Athena/BI | Dashboards históricos sem impactar a API principal. |

> **Princípio central:** a API transacional deve ser otimizada para baixa latência; relatórios pesados, dashboards históricos e consultas analíticas devem ser projetados fora da rota crítica.

## 3. Banco: por que PostgreSQL/Aurora como core, e não DynamoDB como principal

DynamoDB continua sendo excelente para workloads serverless, altíssimo volume e acessos por chave muito previsíveis. Porém, para uma nova API financeira que precisa de **ledger contábil, saldos consistentes, reconciliação, auditoria, busca operacional, disputas/MED, relatórios e transações multi-entidade**, PostgreSQL/Aurora é a escolha mais segura como fonte de verdade.

| Critério | PostgreSQL/Aurora | DynamoDB |
|---|---|---|
| Ledger financeiro | **Muito forte**, com transações, constraints e SQL. | Possível, mas exige modelagem cuidadosa e mais disciplina operacional. |
| Idempotência + saldo + transação | **Natural com transações ACID**. | Possível com conditional writes, mas mais complexo. |
| Auditoria e reconciliação | **Excelente para consultas e joins operacionais**. | Exige índices e duplicação orientada a access patterns. |
| Relatórios operacionais | **Mais simples**. | Pode exigir pipeline analítico adicional desde o início. |
| Latência | Muito boa com pool, índices e queries bem modeladas. | Excelente por chave, mas menos flexível. |
| Evolução do produto | **Mais flexível** para v2 em descoberta. | Menos flexível se novos access patterns surgirem. |

Minha recomendação é usar **Aurora PostgreSQL como core financeiro** e reservar DynamoDB apenas para casos específicos futuros, como cache persistente, deduplicação extrema, lookup de altíssimo volume por chave ou ingestão de eventos brutos, se houver necessidade comprovada.

## 4. Modelo de domínio da nova API

A v2 deve nascer com uma linguagem de domínio mais clara do que a v1. O cliente não deveria depender de nomes internos de provider. A Bents é o provider inicial, mas os contratos devem permitir adicionar outros providers futuramente sem quebrar clientes.

| Domínio | Entidades principais |
|---|---|
| Contas e autenticação | `accounts`, `api_keys`, `api_key_scopes`, `account_limits`, `account_provider_configs`. |
| Transações | `payments`, `payment_attempts`, `provider_operations`, `payment_events`. |
| Ledger | `ledger_accounts`, `ledger_entries`, `balance_snapshots`. |
| Idempotência | `idempotency_keys`, com hash do payload, status e resposta cacheada. |
| Webhooks recebidos | `provider_webhook_events`, raw payload, assinatura, status de processamento. |
| Webhooks enviados | `customer_webhook_deliveries`, tentativas, resposta HTTP, DLQ lógica. |
| Outbox | `outbox_events`, publicado por worker após commit transacional. |
| Auditoria | `audit_log`, com ator, ação, entidade, antes/depois quando aplicável. |

O **ledger** deve ser append-only. Nenhuma atualização de saldo deve acontecer sem entrada correspondente no ledger. O saldo atual pode ser materializado em uma tabela de saldos para resposta rápida, mas a origem auditável deve ser o conjunto de lançamentos.

## 5. Contratos de API v2

Como será um produto novo, vale redesenhar payloads. A API deve ser consistente em todos os endpoints: idempotência obrigatória para operações financeiras, erro padronizado, `correlationId` em todas as respostas, `externalReference` para conciliação do cliente e status interno estável.

| Endpoint sugerido | Comportamento recomendado |
|---|---|
| `POST /v2/pix/charges` | Cria uma cobrança PIX IN. Pode chamar Bents síncrono para retornar QR code rapidamente. |
| `GET /v2/pix/charges/{id}` | Consulta status normalizado da cobrança. |
| `POST /v2/pix/payouts` | Cria uma intenção de Cash Out e responde `accepted` após validação/idempotência. Worker executa provider. |
| `GET /v2/pix/payouts/{id}` | Consulta status normalizado do Cash Out. |
| `GET /v2/balances` | Retorna saldo disponível, reservado e total. |
| `GET /v2/events/{id}` | Permite auditoria operacional de evento/correlação. |
| `POST /v2/webhooks/provider/bents` | Endpoint interno/público técnico para webhooks Bents, isolado por assinatura. |

Para baixa latência, há uma diferença importante entre PIX IN e Cash Out. Em PIX IN, o cliente normalmente espera receber o código copia-e-cola; portanto, a API pode chamar a Bents de forma síncrona com timeout curto e fallback controlado. Em Cash Out, a melhor experiência operacional é responder rapidamente com `accepted` após persistência e reserva de saldo, deixando a execução no provider para worker assíncrono. Isso reduz latência percebida e melhora resiliência contra indisponibilidade do provider.

## 6. Fluxos críticos

O fluxo PIX IN deve registrar a intenção no banco, chamar Bents com timeout curto, persistir o `providerTransactionId`, retornar QR code e processar confirmação por webhook. O fluxo de Cash Out deve validar saldo e idempotência, reservar saldo, registrar ledger de reserva, enfileirar execução na Bents, retornar rapidamente e finalizar por webhook ou conciliação.

| Fluxo | Rota crítica | Assíncrono |
|---|---|---|
| PIX IN | Auth, idempotência, cria intenção, chama Bents para gerar QR, responde. | Webhook pago, ledger de crédito, postback cliente, conciliação. |
| Cash Out | Auth, idempotência, valida saldo, reserva saldo, enfileira, responde `accepted`. | Chama Bents, confirma/falha, ledger de débito, postback cliente, conciliação. |
| Webhook Bents | Valida assinatura, persiste evento bruto, responde rápido. | Processa estado, ledger, postback cliente e alertas. |
| Postback cliente | Nunca na rota do provider. | Retentativas, backoff, DLQ e painel de entregas. |

## 7. Metas de performance e confiabilidade

As metas devem separar latência interna da latência dependente da Bents. A API pode controlar autenticação, banco, filas e resposta; a latência de provider deve ser medida separadamente.

| Métrica | Meta inicial recomendada |
|---|---:|
| API health/readiness | p95 < 50 ms |
| Auth com cache | p95 < 30 ms |
| `POST /v2/pix/payouts` em modo accepted | p95 < 250 ms |
| Webhook receiver Bents | p95 < 200 ms para validar, persistir e ACK. |
| PIX IN com QR síncrono Bents | p95 < 1.500 ms, separando tempo interno e tempo provider. |
| Publicação outbox | p95 < 5 s após commit. |
| Postback cliente | Primeira tentativa p95 < 10 s após evento final. |
| Disponibilidade API | alvo inicial 99,9%; evoluir para 99,95% com maturidade operacional. |

A instrumentação deve usar OpenTelemetry para traces, métricas e logs, pois ele é um framework aberto e agnóstico de fornecedor para geração, coleta e exportação de telemetria.[4] Isso permitirá migrar entre Grafana, CloudWatch, Datadog ou outro backend sem reescrever a aplicação.

## 8. Estrutura recomendada do novo repositório

A estrutura deve ser modular, mas não excessivamente distribuída no início. Eu recomendo começar como um **modular monolith com workers separados**, e não como microserviços pequenos demais. Isso reduz complexidade operacional e mantém consistência de domínio.

```text
new-gateway-api/
  apps/
    api/                    # HTTP API v2
    worker-provider/         # execução Bents e futuros providers
    worker-webhooks/         # envio de webhooks aos clientes
    worker-reconciliation/   # conciliação e rotinas agendadas
    worker-outbox/           # publica eventos pós-commit
  packages/
    domain/                  # entidades, estados, regras financeiras
    database/                # migrations, repositories, transactions
    providers/bents/         # client, mapper, assinatura e erros Bents
    observability/           # OpenTelemetry, logs, métricas
    contracts/               # schemas OpenAPI/Zod/JSON Schema
    security/                # auth, scopes, HMAC, encryption helpers
  infra/
    terraform/               # AWS infra
    dashboards/              # Grafana dashboards-as-code
  docs/
    architecture/
    api/
    runbooks/
```

## 9. Bents como provider nativo

A Bents deve ser implementada como o primeiro provider, mas através de uma interface interna que já permita múltiplos providers no futuro. O sistema não deve vazar status bruto da Bents para clientes. Ele deve traduzir tudo para estados internos.

| Área | Recomendação |
|---|---|
| Client HTTP | Timeout curto, retry apenas para erros seguros, circuit breaker e métricas por endpoint. |
| Assinatura webhook | Validar HMAC com raw body antes de processar eventos. |
| Idempotência provider | Persistir `providerOperationId`, request hash e resposta bruta sanitizada. |
| Status | Mapear Bents para estados internos: `created`, `pending`, `processing`, `paid`, `confirmed`, `failed`, `expired`, `refunded`, `disputed`. |
| Raw payload | Armazenar criptografado ou sanitizado para auditoria, sem expor em respostas públicas. |
| Conciliação | Worker consulta provider e compara com ledger/eventos internos. |

## 10. Cronograma sugerido

Um MVP robusto pode ser implementado em cerca de **8 a 10 semanas**, desde que o escopo seja controlado e a primeira versão foque em Bents, PIX IN, Cash Out, webhooks, ledger e painel operacional mínimo.

| Fase | Duração | Entregáveis |
|---|---:|---|
| 0. Fundação | 1 semana | Repo, CI/CD, infraestrutura base, padrões de código, OpenAPI inicial. |
| 1. Core financeiro | 2 semanas | Banco, migrations, ledger, idempotência, auth, errors, audit log. |
| 2. Bents PIX IN | 1 a 2 semanas | Charges, QR code, webhook pago, postback cliente. |
| 3. Bents Cash Out | 2 semanas | Reserva de saldo, payout accepted, worker provider, confirmação/falha. |
| 4. Observabilidade | 1 semana | Traces, logs, métricas, dashboard Grafana, alertas. |
| 5. Conciliação e hardening | 1 a 2 semanas | Reconciliation worker, DLQ, runbooks, testes de carga e rollback. |
| 6. Piloto controlado | Contínuo | Conta interna, transações de baixo valor, acompanhamento em tempo real. |

## 11. Primeiros documentos que eu criaria para implementação com IA/Cursor

Para iniciar com segurança, eu criaria um pacote de docs pequeno no novo repo. Cada documento deve ser curto para não consumir contexto desnecessário do agente.

| Documento | Objetivo |
|---|---|
| `docs/architecture/00-product-boundaries.md` | Define que é novo produto, não v1, e quais aprendizados da v1 serão reaproveitados. |
| `docs/architecture/01-system-architecture.md` | Arquitetura, componentes, filas, banco e fluxo de eventos. |
| `docs/architecture/02-financial-ledger.md` | Modelo de ledger, saldos, reservas, débito/crédito e invariantes. |
| `docs/api/01-contracts-v2.md` | Contratos públicos, erros, idempotência e status. |
| `docs/providers/bents.md` | Integração Bents nativa, mappers, webhooks e reconciliação. |
| `docs/runbooks/incident-response.md` | Provider down, webhook duplicado, atraso de fila, divergência de saldo. |
| `.cursor/rules/financial-safety.mdc` | Regras obrigatórias para IA não quebrar invariantes financeiras. |

## 12. Recomendação final

A melhor abordagem é construir a v2 como um **novo gateway financeiro independente**, com **Aurora PostgreSQL como core financeiro**, **Bents nativo desde o primeiro dia**, **fila e outbox para confiabilidade**, **contratos API redesenhados** e **observabilidade desde o início**. Essa abordagem maximiza velocidade de resposta sem sacrificar auditabilidade.

O ponto mais importante é não tentar resolver tudo no endpoint. A API deve ser rápida e previsível; o processamento pesado deve ser confiável, rastreável e assíncrono. Essa separação é o que permitirá criar um produto novo, com outra marca e domínio, sem os limites estruturais da JadeLink v1.

## References

[1]: https://docs.aws.amazon.com/AmazonRDS/latest/AuroraUserGuide/CHAP_AuroraOverview.html "What is Amazon Aurora?"
[2]: https://docs.aws.amazon.com/AWSSimpleQueueService/latest/SQSDeveloperGuide/welcome.html "What is Amazon Simple Queue Service?"
[3]: https://docs.aws.amazon.com/eventbridge/latest/userguide/eb-what-is.html "What Is Amazon EventBridge?"
[4]: https://opentelemetry.io/docs/what-is-opentelemetry/ "What is OpenTelemetry?"
[5]: https://finance.bents.com.br/docs "Bents Finance API Documentation"
