# Revisão técnica do `jadelink-core-api` e proposta de arquitetura v2 para processamento PIX

**Autor:** Manus AI  
**Data:** 19 de maio de 2026  
**Repositório revisado:** `area-bank/jadelink-core-api`  
**Escopo:** revisão de código, arquitetura de processamento PIX, baixa latência, confiabilidade, auditabilidade e monitoramento operacional.

![Arquitetura v2 proposta](./jadelink_v2_architecture.png)

## 1. Sumário executivo

A base atual do `jadelink-core-api` já possui fundamentos relevantes para uma operação financeira serverless: uso de AWS SAM, API Gateway, Lambda em Node.js, DynamoDB, SQS, WAF, alarmes, tracing, filas com DLQ, repositórios de transações, logs de requests, auditoria administrativa, reconciliadores e uma suíte de testes significativa. A execução local confirmou **48 suítes de teste aprovadas**, **902 testes aprovados** e tempo total de teste de aproximadamente **10,4 segundos**. Ao mesmo tempo, a cobertura geral ainda está baixa para um sistema financeiro, com **29,31% de statements**, e os handlers mais críticos de negócio apresentam cobertura insuficiente: `src/transactions/create-pix.js` aparece com **0%** e `src/withdrawals/create-cashout.js` com **8,54%**. O lint também falhou com um erro isolado em `src/shared/providers/owem/owem-provider.js:917`, por ternário aninhado.

A recomendação principal é construir uma **v2 orientada a plano crítico enxuto**, na qual os endpoints de criação de PIX IN e Cash Out façam apenas validação, autenticação rápida, idempotência, reserva transacional, chamada externa necessária ao provedor e resposta. Todo o restante — métricas analíticas, painéis, webhooks, reconciliação, enriquecimento, relatórios e auditoria profunda — deve ser desacoplado por eventos, DynamoDB Streams, SQS, outbox e data lake. Esse desenho reduz latência, evita acoplamento entre API e analytics, melhora tolerância a falhas e torna a operação auditável sem sacrificar velocidade.

A plataforma dos exemplos anexados é **muito provavelmente o Grafana**. Os cards exibem um painel de gauge em tema escuro, com arco verde e valor central em percentual, compatível com o tipo de visualização Gauge documentado pelo Grafana para exibir métricas individuais com thresholds e faixas visuais.[1] Para uma operação PIX, recomendo usar Grafana como painel principal, alimentado por CloudWatch Metrics/Embedded Metric Format, Prometheus ou Amazon Managed Service for Prometheus, e Athena para consultas analíticas históricas fora da rota crítica.

## 2. Evidências objetivas da revisão do código atual

A aplicação atual é um backend serverless em Node.js com módulos ES, usando `@aws-sdk/client-dynamodb`, `@aws-sdk/lib-dynamodb`, `@aws-sdk/client-sqs`, `axios`, `jose`, `zod`, `uuid` e bibliotecas de apoio. A infraestrutura está declarada em `template.yaml`, com funções Lambda, tabelas DynamoDB, filas SQS, políticas, alarmes e dashboard CloudWatch. O template já habilita `Tracing: Active`, `AWS_NODEJS_CONNECTION_REUSE_ENABLED`, `ReservedConcurrentExecutions` em funções críticas como `create-pix-in` e `create-cashout`, e alarmes para erros, throttles e duração p95.

| Área revisada | Estado atual observado | Impacto para a v2 |
|---|---:|---|
| Testes automatizados | 902 testes aprovados em 48 suítes | Boa base para evoluir sem regressão, mas os testes estão concentrados em parsers, validators e processadores. |
| Cobertura geral | 29,31% statements, 33,03% branches | Baixa para componentes financeiros; a v2 deve exigir gates por domínio crítico. |
| `create-pix.js` | 0% de cobertura | Alto risco porque é rota crítica de criação de cobrança PIX. |
| `create-cashout.js` | 8,54% de cobertura | Alto risco porque envolve saída de dinheiro, saldo, provedor e rollback. |
| Lint | 1 erro em `owem-provider.js:917` | Correção simples, mas CI deveria bloquear merge em qualquer erro. |
| Infraestrutura | API Gateway, Lambda, DynamoDB, SQS, WAF, alarmes, tracing | Boa base serverless; precisa evoluir para outbox, métricas padronizadas e dashboards orientados a negócio. |
| Observabilidade | `metrics.js`, request logs, CloudWatch dashboard e logs estruturados | Há estrutura, mas falta cobertura consistente nos fluxos críticos e cuidado com cardinalidade de métricas. |
| Auditabilidade | `audit-log-repository.js`, request logs, ledger e reconciliadores | Boa semente; precisa de trilha imutável orientada a eventos financeiros e correlação ponta a ponta. |

A leitura do código mostra bons componentes já existentes: `auth-cache.js`, `circuit-breaker.js`, `limits.js`, `request-log-repository.js`, `audit-log-repository.js`, repositórios de transação e usuário, parsers por provider, processadores de webhook, reconciliação e filas de webhook. A melhor v2 não deve descartar essa base. Ela deve **isolar o plano crítico**, padronizar estado financeiro e transformar logs/métricas em um produto operacional confiável.

## 3. Plataforma dos exemplos de monitoramento

Os anexos mostram gauges com título “Taxa de sucesso Cash In” e “Taxa de sucesso Cash Out”, valores centrais grandes, tema escuro, moldura de painel e arco verde com threshold visual. Essa composição é fortemente compatível com **Grafana Gauge Panel**. A documentação do Grafana descreve a visualização Gauge como adequada para exibir uma métrica individual em uma escala, com thresholds e orientação visual.[1]

> **Conclusão:** a plataforma mais provável é **Grafana**. Alternativas como Kibana/OpenSearch Dashboards e Datadog também possuem gauges, mas o estilo visual dos anexos, especialmente o gauge semicircular em painel escuro, se alinha muito bem ao Grafana.

Para a Jadelink, eu recomendo **Grafana como painel executivo e NOC**, usando métricas em tempo quase real para operação e consultas Athena apenas para análises históricas. O painel não deve consultar tabelas operacionais transacionais diretamente, pois isso introduz custo, latência e risco de impacto na API.

## 4. Problemas arquiteturais prioritários encontrados

O principal desafio da versão atual é que parte relevante da lógica financeira e de integração externa acontece na rota síncrona dos endpoints. Isso é natural em uma primeira versão, mas limita baixa latência e confiabilidade quando o volume aumenta. A chamada ao provedor, consulta de chave PIX, débito ou reserva de saldo, persistência de transação, limite transacional, request log, métricas e tratamento de rollback precisam ser cuidadosamente separados em operações obrigatórias da rota crítica e operações assíncronas.

| Prioridade | Problema | Evidência no código | Risco | Direção recomendada |
|---:|---|---|---|---|
| P0 | Cobertura baixa nos endpoints financeiros | `create-pix.js` 0%, `create-cashout.js` 8,54% | Regressões em produção, falhas em dinheiro real | Testes unitários, integração com DynamoDB local/mocks e contract tests por provider. |
| P0 | Idempotência precisa ser obrigatória em mutações | Cashout possui caminho de geração automática quando ausente | Retry após timeout pode duplicar operação financeira | Exigir `Idempotency-Key` em toda mutação v2 e persistir resposta por hash de payload. |
| P0 | Cashout mistura saldo, provider e rollback | Fluxo debita/cria transação/chama provider/credita em falha | Race conditions, rollback parcial, divergências | Implementar ledger com reserva/hold, state machine e liquidação por evento final. |
| P0 | Métricas de negócio ainda não cobrem toda a operação | `metrics.js` com baixa cobertura e uso parcial | Painel mostra dados incompletos ou inconsistentes | Padronizar EMF/eventos e derivar métricas de transições de estado. |
| P1 | Circuit breaker é local em memória | `circuit-breaker.js` usa `Map` local por instância Lambda | Estado é perdido em cold start e não é global | Adicionar breaker distribuído leve por provider/account, com cache local e TTL curto. |
| P1 | Auditoria administrativa existe, mas não é trilha financeira completa | `audit-log-repository.js` e request logs assíncronos | Baixa capacidade de reconstrução de evento financeiro | Criar `FinancialEvents`/outbox imutável com correlação e hash encadeado opcional. |
| P1 | Reconciliadores usam scans em alguns fluxos | `reconcile-transactions.js` busca stale transactions | Custo e lentidão sob alto volume | GSIs por status/tipo/vencimento e jobs particionados por provider/account. |
| P2 | Painel atual no CloudWatch é técnico | Dashboard foca Lambda duration/errors/throttles | Operação não vê taxa de aprovação, ticket médio, volume pago | Grafana com KPIs financeiros e operacionais por tipo, provider, account e janela. |

## 5. Arquitetura v2 proposta

A v2 deve ser desenhada como uma arquitetura de **baixa latência no caminho síncrono** e **alta confiabilidade no caminho assíncrono**. Em termos práticos, isso significa que a resposta do endpoint não deve depender de relatórios, painéis, webhooks de cliente, enriquecimentos, reconciliações ou agregações. Ela deve depender apenas do mínimo necessário para aceitar ou rejeitar com segurança uma operação financeira.

A API deve separar os domínios em três planos. O **plano crítico** responde requests de clientes. O **plano de eventos** processa webhooks, outbox, notificações e métricas. O **plano analítico/auditoria** alimenta Grafana, data lake, Athena, reconciliação e investigação.

| Plano | Responsabilidade | Tecnologias recomendadas | Critério de sucesso |
|---|---|---|---|
| Plano crítico | Autenticar, validar, idempotência, reservar saldo/limite, chamar provider quando necessário e responder | API Gateway, Lambda Node.js, DynamoDB `TransactWriteItems`, provider router, cache local | p95 baixo, zero duplicidade financeira, resposta previsível. |
| Plano de eventos | Publicar transições, processar webhooks, enviar notificações e emitir métricas | DynamoDB Streams, SQS, DLQ, Lambda consumers, CloudWatch EMF | Retries controlados, sem perda de eventos, backpressure visível. |
| Plano analítico | KPIs, dashboards, auditoria histórica, reconciliação e relatórios | S3, Glue, Athena, Grafana, CloudWatch/Prometheus | Consultas não impactam a API e dados são reconciliáveis. |

O DynamoDB deve continuar sendo o banco operacional principal, mas com uso mais explícito de transações para invariantes financeiras. A documentação oficial da AWS define `TransactWriteItems` como uma operação síncrona e idempotente capaz de agrupar até 100 ações em uma operação “all-or-nothing”, com atomicidade entre itens e tabelas da mesma região/conta.[2] Isso é particularmente adequado para gravar, em uma única operação, a idempotência, a transação, a reserva de saldo/limite, o ledger e o evento outbox.

> A documentação da AWS afirma que `TransactWriteItems` agrupa ações em uma operação “all-or-nothing” e que as mudanças são concluídas atomicamente, ou todas têm sucesso ou nenhuma tem sucesso.[2]

### 5.1 Modelo de endpoints v2

A v2 deve tornar explícitos os contratos de idempotência, status e correlação. Toda mutação financeira deve exigir `Idempotency-Key` fornecida pelo cliente, além de `X-Request-Id` opcional. Quando ausente, a API deve retornar `400` com erro claro. A geração automática de chave deve ser removida das mutações financeiras públicas, pois ela protege o servidor de exceptions, mas não protege o cliente contra duplicidade após retries.

| Endpoint v2 | Comportamento recomendado | Resposta ideal |
|---|---|---|
| `POST /v2/pix-in` | Valida, autentica, checa idempotência, reserva limite, chama provider para gerar QR e grava transação + outbox | `201 Created` com `transactionId`, `status`, `brCode`, `qrCode`, `expiresAt`, `idempotencyKey`. |
| `GET /v2/pix-in/{id}` | Consulta por chave primária ou GSI por owner | `200 OK` com status normalizado e eventos relevantes. |
| `POST /v2/cashout` | Valida, autentica, exige idempotência, reserva saldo, cria ordem, chama provider ou enfileira conforme modo | `202 Accepted` ou `201 Created` com `status=processing`, nunca “paid” sem confirmação confiável. |
| `GET /v2/cashout/{id}` | Consulta status e última atualização | `200 OK` com status, provider, E2E quando disponível e erro normalizado. |
| `GET /v2/health/provider` | Status agregado de providers para operação interna | Apenas interno/autorizado, usado por NOC e autoswitch. |

A resposta de Cash Out deve evitar prometer liquidação final antes de confirmação robusta do provider, webhook ou reconciliação. Para usuários que precisam de resposta “rápida”, o contrato correto é **aceitar rapidamente e expor status `processing`**, e não bloquear o endpoint até toda a cadeia externa terminar. Para clientes que exigem modo síncrono, a API pode oferecer `processingMode=sync` com deadline curto, mas deve manter a semântica financeira: saldo reservado até liquidação, não debitado definitivamente sem evento final.

### 5.2 State machine financeira

A v2 deve formalizar uma máquina de estados única para PIX IN e Cash Out. Hoje já existem status normalizados e processadores de webhook, mas o fluxo deve ficar mais rígido e auditável. O estado não pode regredir sem uma regra explícita, e qualquer transição financeira deve gerar um evento imutável.

| Tipo | Estados principais | Evento financeiro | Efeito em saldo |
|---|---|---|---|
| PIX IN | `created`, `waiting_payment`, `paid`, `expired`, `refunded`, `chargedback`, `failed` | `pix_in.created`, `pix_in.paid`, `pix_in.refunded` | Crédito apenas em `paid`; reversão apenas por refund/chargeback autorizado. |
| Cash Out | `created`, `reserved`, `processing`, `completed`, `failed`, `returned`, `canceled`, `manual_review` | `cashout.reserved`, `cashout.sent`, `cashout.completed`, `cashout.failed` | Reserva no aceite; débito final em `completed`; liberação em falha/cancelamento. |
| Ledger | `hold`, `debit`, `credit`, `release`, `fee`, `adjustment` | Evento de ledger por transição | Saldo disponível = saldo contábil menos reservas ativas. |

O fluxo de Cash Out recomendado é reserva primeiro, liquidação depois. A reserva reduz saldo disponível, mas preserva rastreabilidade e evita rollback financeiro manual em caso de falha no provider. Quando o provider confirma, a reserva vira débito final. Quando falha, a reserva é liberada. Esse desenho reduz inconsistência e torna reconciliação mais simples.

## 6. Baixa latência e alta velocidade nos endpoints

A AWS recomenda provisioned concurrency para reduzir cold starts em workloads interativos sensíveis a latência; a documentação afirma que ambientes pré-inicializados ficam prontos para responder imediatamente e são desenhados para tempos de resposta em dezenas de milissegundos.[3] Como os endpoints `create-pix-in` e `create-cashout` são interativos e críticos, recomendo habilitar **Provisioned Concurrency com aliases versionados** nesses dois handlers em produção, além do `ReservedConcurrentExecutions` já presente.

| Técnica | Aplicação na v2 | Benefício esperado | Observação |
|---|---|---|---|
| Provisioned Concurrency | `create-pix-in`, `create-cashout`, webhook receiver | Reduz cold start | Deve usar alias/version, não `$LATEST`.[3] |
| Inicialização fora do handler | SDK clients, provider registry, schemas Zod, HTTP agents | Menos custo por request | O template já usa connection reuse; reforçar agentes keep-alive. |
| Cache local com TTL | usuário, account, provider config, secrets versionados | Menos leituras DynamoDB/Secrets | Invalidar por `secretVersion`/`updatedAt`. |
| Deadline por provider | timeout curto e orçamento total por request | Evita Lambda de 29s presa | Exemplo: 800–1500 ms por provider na rota crítica. |
| Provider router | escolher provider saudável por taxa, latência e saldo | Mais aprovação e menor latência | Usar circuit breaker + health score. |
| Escrita transacional única | idempotência + transação + ledger + outbox | Menos round-trips e maior consistência | Usar `TransactWriteItems`. |
| Métricas assíncronas | emitir EMF e outbox, não consultar analytics | Painel sem impactar API | CloudWatch/Grafana consomem fora da rota. |

A meta prática deve ser separar latência controlável de latência do provedor. Para o que depende somente do sistema interno, mirar p95 abaixo de 100–200 ms é realista com cache quente, DynamoDB bem modelado e Lambda provisionada. Para fluxos que precisam chamar provider síncrono, a latência final será dominada pelo provider; por isso o desenho deve ter **deadlines**, **fallback** e **modo assíncrono** quando o SLA externo não for confiável.

## 7. Auditabilidade e reconciliação

A trilha de auditoria v2 deve responder a quatro perguntas em qualquer incidente: quem pediu, o que foi pedido, qual idempotência foi usada, quais transições ocorreram e quais efeitos financeiros foram aplicados. A melhor forma de garantir isso é gravar eventos financeiros imutáveis em conjunto com a operação transacional.

| Registro | Conteúdo mínimo | Retenção | Uso |
|---|---|---:|---|
| `IdempotencyRecords` | chave, cliente, hash do payload, status, resposta serializada | 30–90 dias | Repetir resposta sem duplicar efeito. |
| `Transactions` | estado atual, tipo, valor, provider, owner, datas | conforme compliance | Consulta operacional rápida. |
| `LedgerEntries` | débito/crédito/reserva/liberação, saldo antes/depois, versão | longa | Auditoria contábil e reconstrução. |
| `FinancialEvents` | evento imutável, correlação, causa, actor, provider payload hash | longa | Investigação, replay e data lake. |
| `OutboxEvents` | evento pendente de publicação, destino, attempts | curta/média | Garantir publicação sem perda. |
| `ProviderRequests` | request/response sanitizados, status, tempo, erro normalizado | curta/média | Debug e SLA de provider. |

Um aprimoramento importante é não depender de `putItemAsync` fire-and-forget para eventos essenciais de auditoria. Logs auxiliares podem ser assíncronos, mas **eventos financeiros e outbox precisam estar na mesma transação da mudança de estado**. Assim, se a transação existe, o evento que explica sua criação também existe.

## 8. Painel de monitoramento recomendado no Grafana

O painel deve separar visão executiva, visão operacional e visão de incidentes. A visão executiva mostra saúde do negócio; a operacional mostra latência, filas e providers; a de incidentes mostra erros, DLQs, divergências e circuit breakers.

| Painel | Métrica | Fórmula recomendada | Dimensões |
|---|---|---|---|
| Taxa de sucesso Cash In | Percentual pago | `paid_count / created_count` por janela | provider, account, ambiente |
| Taxa de sucesso Cash Out | Percentual completado | `completed_count / submitted_count` por janela | provider, account, ambiente |
| Transações | Contagem total | `count(transaction.created)` | tipo, status, provider |
| Erros | Falhas técnicas e financeiras | `count(error)` por categoria | endpoint, provider, error_code |
| Tempo médio de resposta | Latência média e p95/p99 | API Gateway + Lambda + provider duration | endpoint, provider |
| Ticket médio | Valor médio pago | `sum(amount_paid) / count(paid)` | tipo, provider, account |
| Valor total transacionado | TPV pago/completado | `sum(amount)` em status final positivo | tipo, provider, account |
| Pendências | Transações em processamento | `count(status in pending/processing)` | idade, provider |
| Webhook backlog | Profundidade de fila | `ApproximateNumberOfMessagesVisible` | queue, DLQ |
| Divergência financeira | Diferença local vs provider | `abs(local_balance - provider_balance)` | account, provider |
| Circuit breaker | Providers abertos/degradados | estado do breaker e taxa de falha | provider, account |

A métrica de “taxa de aprovação” deve ser definida com rigor. Para Cash In, recomendo `paid / created` para a janela de criação, mas com uma janela de maturação, porque cobranças recém-criadas ainda não tiveram tempo de serem pagas. Para Cash Out, recomendo `completed / submitted`, distinguindo falhas de validação do cliente, falhas do provider e falhas por saldo/limite. Sem essa separação, o painel pode culpar a infraestrutura por recusas esperadas de negócio.

| Linha do dashboard | Visualização | Objetivo |
|---|---|---|
| Visão geral | Gauges: sucesso Cash In, sucesso Cash Out, disponibilidade API, provider health | Mostrar saúde em 10 segundos. |
| Volume financeiro | Stat panels: TPV pago, ticket médio, número de transações, fee total | Acompanhar operação e receita. |
| Latência | Time series p50/p95/p99 por endpoint e provider | Detectar degradação antes de falha. |
| Erros | Barras por `error_code`, `provider`, `endpoint` | Priorizar incidentes. |
| Filas | SQS backlog, age of oldest message, DLQ count | Controlar processamento assíncrono. |
| Reconciliação | Divergências abertas, idade, valor, provider | Gestão de risco financeiro. |
| Providers | Taxa de sucesso, latência, circuit state, saldo provider | Decidir roteamento/fallback. |

## 9. Roadmap de implementação

A implementação deve ser incremental para reduzir risco. A primeira etapa é fortalecer a base existente; a segunda cria contratos v2 e state machine; a terceira introduz o painel Grafana e o pipeline analítico; a quarta ativa otimizações de performance em produção.

| Fase | Entregas | Critério de pronto |
|---:|---|---|
| 1 | Corrigir lint, adicionar gates CI, testes dos handlers críticos, testes de idempotência | Lint 0 erros, cobertura mínima nos fluxos críticos, regressão bloqueada. |
| 2 | Criar `IdempotencyRecords`, outbox transacional, ledger reserva/liquidação, state machine formal | Mutação financeira sempre idempotente e auditável. |
| 3 | Criar `/v2/pix-in` e `/v2/cashout` mantendo `/v1` compatível | Clientes piloto operando na v2 sem quebrar v1. |
| 4 | Padronizar métricas EMF/eventos, criar dashboards Grafana e alertas | KPIs de negócio visíveis em tempo quase real. |
| 5 | Provisioned Concurrency, provider router, breaker distribuído, tuning de DynamoDB GSIs | p95 estável e degradação controlada em falhas externas. |
| 6 | Data lake, Athena, reconciliação particionada e relatórios de auditoria | Operação consegue explicar qualquer transação ponta a ponta. |

## 10. Recomendações imediatas

A primeira ação deve ser aumentar a segurança de mudança nos pontos críticos. O projeto tem muitos testes, mas ainda não protege suficientemente as rotas que movimentam dinheiro. Eu priorizaria testes de `create-pix.js`, `create-cashout.js`, `transaction-repository.js`, `user-repository.js`, `limits.js` e processadores de webhook com cenários de concorrência, retry e falha parcial.

Em seguida, eu implementaria idempotência obrigatória em toda mutação financeira da v2. O registro de idempotência deve guardar hash do payload e a resposta final; se o cliente repetir a mesma chave com o mesmo payload, a API retorna a resposta anterior; se repetir com payload diferente, retorna conflito. Esse é o comportamento esperado para clientes que fazem retry após timeout.

A terceira ação deve ser transformar o Cash Out em fluxo de reserva e liquidação. Essa mudança reduz o risco de rollback manual e torna a operação mais explicável. A quarta é criar o pipeline de métricas para Grafana com dados derivados de transições de estado e não de consultas pesadas em tabelas operacionais.

## 11. Conclusão

A arquitetura “perfeita” para a Jadelink não é a mais complexa; é a que mantém o endpoint rápido e pequeno, enquanto desloca observabilidade, auditoria, reconciliação e relatórios para um plano assíncrono confiável. O repositório atual já tem bons blocos: DynamoDB, SQS, WAF, tracing, reconciliadores, logs estruturados, circuit breaker e testes extensos de parsers/providers. A v2 deve transformar esses blocos em uma plataforma financeira orientada a **idempotência obrigatória**, **ledger auditável**, **outbox transacional**, **state machine explícita**, **provider router resiliente** e **Grafana com KPIs de negócio**.

Com esse desenho, a API pode responder mais rápido, lidar melhor com falhas de provider, reduzir duplicidade financeira, oferecer auditoria forte e dar à operação uma visão clara de aprovação, volume, erros, latência, ticket médio e valor total transacionado.

## Referências

[1]: https://grafana.com/docs/grafana/latest/panels-visualizations/visualizations/gauge/ "Grafana documentation — Gauge visualization"  
[2]: https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/transaction-apis.html "Amazon DynamoDB Transactions: How it works"  
[3]: https://docs.aws.amazon.com/lambda/latest/dg/provisioned-concurrency.html "AWS Lambda documentation — Configuring provisioned concurrency"  
[4]: https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/CloudWatch_Embedded_Metric_Format.html "Amazon CloudWatch documentation — Embedded metric format"
