# Prompt para Cursor — iniciar nova API v2 com Bents nativo

Você é um agente sênior de engenharia responsável por iniciar uma nova API financeira v2, independente da JadeLink v1. Esta v2 é um novo produto, com nova marca, novo domínio, novo gateway e novos contratos públicos. A v1 deve ser usada apenas como referência conceitual de regras de negócio e aprendizados; não copie código legado sem revisão explícita.

## Objetivo

Crie a base técnica de uma nova API de processamento PIX com integração nativa ao provider Bents, alta confiabilidade, baixa latência, auditoria financeira e observabilidade desde o início.

## Restrições obrigatórias

1. Não alterar nenhum arquivo, contrato ou infraestrutura da JadeLink v1.
2. Não hardcodar credenciais, tokens, secrets, chaves HMAC ou URLs sensíveis.
3. Toda operação financeira deve ter idempotência obrigatória.
4. Toda mudança de saldo deve gerar entrada append-only no ledger.
5. Toda resposta HTTP deve incluir `correlationId`.
6. Nunca vazar payload bruto ou erro sensível da Bents para cliente final.
7. Webhook recebido deve validar assinatura, persistir evento bruto/sanitizado e responder rápido.
8. Postback para cliente nunca deve rodar na rota crítica de webhook do provider.
9. Analytics e dashboards não devem impactar a latência da API transacional.

## Arquitetura alvo

Use um modular monolith com workers separados:

```text
apps/api
apps/worker-provider
apps/worker-webhooks
apps/worker-reconciliation
apps/worker-outbox
packages/domain
packages/database
packages/providers/bents
packages/contracts
packages/security
packages/observability
infra
```

Banco principal: PostgreSQL/Aurora.  
Filas: SQS ou abstração equivalente.  
Eventos: outbox transacional e EventBridge/SNS/SQS.  
Observabilidade: OpenTelemetry com logs estruturados, métricas e traces.

## Primeira tarefa

Antes de escrever código, produza um plano de implementação em pequenos passos e confirme os arquivos que serão criados. Depois implemente somente a fundação:

1. Estrutura do monorepo.
2. Configuração TypeScript/Node ou Go, escolhendo stack justificada.
3. Healthcheck e readiness.
4. Padrão de erro HTTP.
5. Middleware de `correlationId`.
6. Schemas iniciais de contratos v2.
7. Migrations iniciais: `accounts`, `api_keys`, `idempotency_keys`, `payments`, `provider_operations`, `ledger_entries`, `outbox_events`, `provider_webhook_events`, `customer_webhook_deliveries`, `audit_log`.
8. Interface `PaymentProvider` e pacote `providers/bents` ainda sem credenciais reais.
9. Testes unitários dos invariantes principais.

## Critérios de aceite da primeira entrega

A primeira entrega só será aceita se:

| Critério | Exigência |
|---|---|
| Build | O projeto compila sem erros. |
| Testes | Testes básicos rodam em CI local. |
| Segurança | Nenhum secret aparece no código ou nos testes. |
| Contratos | OpenAPI/JSON schema inicial existe. |
| Observabilidade | Logs estruturados e `correlationId` estão presentes. |
| Banco | Migrations são versionadas e reversíveis quando possível. |
| Financeiro | Ledger é append-only por desenho. |

## Próximas fases depois da fundação

Após a fundação, implemente nesta ordem: Bents PIX IN, webhook Bents, Cash Out assíncrono, customer webhooks, reconciliação, dashboards, testes de carga e piloto controlado.
