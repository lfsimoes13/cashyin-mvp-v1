# Bents Finance API — Findings for JadeLink v1 Integration

Source: https://finance.bents.com.br/docs

## Base URL and environments

The public API base URL is `https://finance.bents.com.br/api/v2/public` for both sandbox and production. The environment is determined by the API key created in the Bents platform. Sandbox keys process simulated charges without real movement.

## Authentication

Public API calls use `Authorization: Bearer dk_...`. API key generation/management uses a separate Sanctum token flow: login, request OTP, then create API key. The API key is shown only once.

## Public endpoints relevant to v1

| Capability | Method | Path | Notes |
|---|---:|---|---|
| Balance | GET | `/balance` | Returns `balance`, `balance_cents`, `currency`, `status`. |
| Create PIX charge | POST | `/pix/charge` | Required `amount_cents`; optional `description`; creates `PENDING` charge and QR data. |
| Batch PIX charge | POST | `/pix/charges/batch` | Up to 100 items; partial failures. Probably not required for JadeLink v1 public contract unless internal optimization later. |
| Charge status | GET | `/pix/charge/{uuid}` | Returns status such as `PENDING`, `PAID`, `EXPIRED`, `CANCELLED`. |
| Send PIX payment | POST | `/pix/payment` | Synchronous and moves real balance. Requires `amount_cents`, `pix_key`; optional `description`, `callback_url`, `end_to_end_id`. |
| DICT lookup | POST | `/dict` | Resolves PIX key and returns masked receiver data plus `endToEndId` for payment reuse. |

## Webhook events

Relevant events include `pix.charge.paid`, `pix.charge.expired`, `pix.charge.cancelled`, `pix.payment.sent`, `transfer.refunded`, `med.opened`, and `med.resolved`. Webhooks include `X-Bents-Signature`, computed as `sha256=` plus HMAC-SHA256 over the raw body with `BENTS_WEBHOOK_SECRET`. The endpoint must respond HTTP 200 within 10 seconds. Retries use exponential backoff: 1 min, 5 min, 30 min, 2 h.

## Important payload mappings

Create charge response includes `charge_uuid`, `status`, `amount_cents`, `pix_copia_e_cola`, `txid`, `expires_at`, `qr_code.png_base64`, `qr_code.png_image`, and `sandbox`.

Payment response includes `transaction_id`, `status`, `e2e_id`, `e2e_id_dict`, `fee_amount_cents`, and `receiver` fields. For tracking, `e2e_id` is definitive BACEN end-to-end identifier. `e2e_id_dict` only echoes the previous DICT lookup reservation.

Webhook `pix.charge.paid` includes `charge_uuid`, `status`, `amount_cents`, `txid`, `e2e_id`, `paid_at`, and optionally `payer` with masked document and `bank_ispb`.

## Error and rate limits

Errors use standard status codes: 401, 422, 404, 500, plus 429 on rate limit. Sandbox limit: 60 req/min and 1,000 req/day. Production: 120 req/min and unlimited daily according to the documentation. Respect `Retry-After` on 429.
