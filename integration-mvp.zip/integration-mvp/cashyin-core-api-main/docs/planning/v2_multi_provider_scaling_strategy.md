# Estratégia v2 — Multi-provider, migração segura e escala de processamento

Autor: **Manus AI**  
Contexto: nova API v2, nova marca, novo domínio, novo gateway, integração inicial nativa com **Bents**, preparada para novos providers sem reescrever o core.

## 1. Direção recomendada

A v2 deve nascer como uma plataforma **multi-provider por desenho**, mas iniciar operacionalmente com apenas um provider ativo, a **Bents**. Isso evita criar uma estrutura acoplada ao primeiro parceiro e reduz o esforço futuro para integrar novos providers. A API pública não deve conhecer detalhes do provider. O cliente chama endpoints estáveis da nova marca, enquanto o roteador interno decide qual provider e qual conta operacional serão usados.

A decisão mais importante é separar três conceitos que hoje tendem a se misturar em sistemas de bolsão: **saldo do cliente**, **conta operacional no provider** e **liquidez disponível para saque**. O saldo do cliente deve existir no ledger interno da plataforma. A conta do provider deve ser apenas o trilho operacional por onde o dinheiro entra e sai. A liquidez deve ser controlada por reservas, limites e reconciliação, nunca presumida apenas pelo saldo agregado do bolsão.

> Regra central: **nenhum saque deve ser aprovado apenas porque o cliente tem saldo contábil interno; ele também precisa passar por uma verificação de liquidez, reservas, limites e conta operacional elegível**.

| Conceito | Onde deve viver | Finalidade |
|---|---|---|
| Saldo contábil do cliente | Ledger interno no PostgreSQL/Aurora | Fonte de verdade para quanto cada cliente tem direito a movimentar. |
| Conta operacional do provider | Tabela de provider accounts | Representa a conta Bents ou de outro provider usada para processar cash in/cash out. |
| Saldo real no provider | Consulta/reconciliação do provider | Usado para validar liquidez e detectar divergências. |
| Reserva de saque | Tabela de holds/reservations | Impede que dois saques consumam o mesmo saldo ou liquidez. |
| Roteamento | Provider routing rules | Decide provider/conta por cliente, produto, volume, risco, health e liquidez. |

## 2. Arquitetura multi-provider

A v2 deve usar uma camada `PaymentProvider` comum. Cada provider implementa apenas o adaptador: autenticação, criação de pagamento, criação de cash out, consulta de status, parser de webhook, normalização de erros e healthcheck. O core não muda quando um provider novo entra.

```text
Cliente
  ↓
API pública v2
  ↓
Application services: payments, cashout, ledger, idempotency
  ↓
Provider router
  ↓
Provider adapter: Bents, Provider B, Provider C
  ↓
Provider accounts: conta A, conta B, conta C
```

A interface mínima do provider deve ser pequena e estável. O esforço de integrar um novo provider deve estar concentrado em um novo pacote, por exemplo `packages/providers/acme`, sem alterar regras financeiras centrais.

| Método | Responsabilidade | Observação |
|---|---|---|
| `createPixIn(input)` | Criar cobrança/QR Code/depósito | Retorna payload normalizado, nunca o bruto como contrato público. |
| `createCashOut(input)` | Solicitar pagamento de saída | Deve suportar idempotência e correlação interna. |
| `getOperationStatus(input)` | Consultar status no provider | Usado por reconciliação e retentativas. |
| `parseWebhook(raw)` | Normalizar webhook recebido | Converte evento externo para evento interno canônico. |
| `verifyWebhook(raw, headers)` | Validar assinatura/autenticidade | Obrigatório antes de processar evento. |
| `mapError(error)` | Converter erro externo em erro interno | Evita vazar detalhes sensíveis ao cliente. |
| `healthcheck()` | Medir disponibilidade/latência do provider | Alimenta roteamento e circuit breaker. |

## 3. Como adicionar um novo provider com esforço mínimo

O fluxo de adição deve ser padronizado por checklist. O novo provider não deve exigir mudança nos contratos públicos da API. A plataforma continua recebendo os mesmos payloads v2 e o roteador passa a enxergar uma nova opção operacional.

| Etapa | Entrega | Onde mexe |
|---|---|---|
| 1. Cadastro técnico | Registro em `providers` e `provider_accounts` | Banco/configuração. |
| 2. Adapter | Implementação da interface `PaymentProvider` | `packages/providers/{provider}`. |
| 3. Credenciais | Secrets por ambiente e por conta operacional | Secret Manager/Parameter Store. |
| 4. Webhook | Endpoint interno ou rota multiplexada com parser específico | `apps/api/provider-webhooks`. |
| 5. Normalização | Mapeamento para status/eventos internos | Pacote do provider. |
| 6. Testes | Contract tests, webhook tests, idempotência e erros | Testes automatizados. |
| 7. Roteamento controlado | Regra desativada por padrão | Admin/internal config. |
| 8. Piloto | Habilitar para 1 cliente/baixo volume | Feature flag por cliente. |

O ponto essencial é ter **contract tests de provider**. Cada provider novo deve passar pelos mesmos cenários: criação de PIX IN, recebimento de webhook pago, cash out aprovado, cash out rejeitado, timeout, erro 4xx, erro 5xx, webhook duplicado, webhook fora de ordem e consulta de status divergente.

## 4. Modelo de contas: fim do bolsão sem controle

O problema do bolsão não é necessariamente existir uma conta agregadora. O risco está em **não separar contabilmente quem é dono de cada valor**, nem controlar liquidez por conta operacional. Na v2, uma conta operacional pode atender N clientes, mas o saldo de cada cliente deve ser segregado internamente por ledger e o uso de liquidez deve ser reservado de forma transacional.

| Problema atual | Mitigação na v2 |
|---|---|
| Cliente migra para nova conta, mas dinheiro permanece na conta antiga. | Separar saldo contábil do cliente de conta operacional e criar plano de drenagem/transferência de liquidez. |
| Cliente não consegue sacar saldo que entrou antes da migração. | Manter origem de liquidez por lote/conta e permitir saque pela conta antiga até drenagem, ou transferir liquidez antes do corte. |
| Um cliente saca dinheiro que entrou por outro cliente. | Criar ledger por cliente, reservas por cliente e controle de liquidez por provider account. |
| Nova conta tem menos saldo que obrigações dos clientes migrados. | Bloquear migração de cash out até liquidez mínima estar provisionada. |
| Saldo agregado parece suficiente, mas não está disponível no provider correto. | Usar `available_liquidity` por provider account e não apenas saldo interno global. |

## 5. Migração segura de cliente entre providers ou contas

A troca de provider de um cliente deve ser um processo com estados, não uma edição direta de configuração. O cliente pode ter operações antigas pendentes, saldo contábil acumulado, chargebacks/MED, cashouts em andamento e webhooks atrasados.

O modelo recomendado é ter uma tabela `client_provider_assignments` com vigência temporal e uma tabela `migration_plans`. O roteamento deve respeitar `effective_from`, `mode` e `product_scope`.

```text
Estado 1: PLANNED
  ↓ valida liquidez, pendências, limites, webhooks e reconciliação
Estado 2: DUAL_WRITE_MONITORING ou SHADOW_ROUTING
  ↓ novos cash ins podem ir para nova conta, saques ainda controlados
Estado 3: CASHIN_CUTOVER
  ↓ novas entradas entram no novo provider/account
Estado 4: CASHOUT_CUTOVER
  ↓ saques usam nova conta apenas se houver liquidez provisionada
Estado 5: DRAINING_OLD_ACCOUNT
  ↓ operações antigas liquidadas, saldo antigo drenado ou transferido
Estado 6: COMPLETED
```

| Fase | Regra de segurança |
|---|---|
| Planejamento | Calcular obrigações do cliente, saldo contábil, saldo no provider antigo e liquidez no novo provider. |
| Corte de cash in | Novas entradas podem ir para nova conta, mas entradas antigas continuam conciliáveis pela conta antiga. |
| Corte de cash out | Só liberar se a nova conta tiver liquidez suficiente ou se houver fallback explícito para conta antiga. |
| Drenagem | Saldos antigos devem ser consumidos, transferidos ou mantidos elegíveis para saque conforme política definida. |
| Encerramento | Só concluir após reconciliação sem divergências pendentes. |

## 6. Regra de ouro para evitar prejuízo financeiro

A v2 deve trabalhar com dois saldos distintos: **saldo contábil do cliente** e **liquidez operacional da conta provider**. O saldo contábil responde “quanto o cliente tem direito?”. A liquidez operacional responde “por qual conta e provider eu consigo pagar isso agora sem usar dinheiro de outro cliente indevidamente?”.

Antes de aprovar um cash out, o sistema deve executar uma reserva transacional:

```text
1. Validar idempotência.
2. Validar saldo contábil disponível do cliente.
3. Escolher provider account elegível.
4. Validar liquidez disponível na provider account.
5. Criar hold/reserva no ledger do cliente.
6. Criar reserva de liquidez na provider account.
7. Criar provider operation.
8. Publicar evento outbox para worker chamar provider.
```

Se o provider falhar de forma definitiva, a reserva deve ser liberada por evento compensatório. Se houver timeout, a operação fica em estado intermediário e é reconciliada antes de liberar ou reprocessar.

## 7. Banco preparado para grande volume de requests e consultas

Para o core financeiro, recomendo **PostgreSQL/Aurora PostgreSQL** como fonte de verdade, com desenho transacional forte, particionamento e separação de leitura. Aurora possui arquitetura gerenciada compatível com PostgreSQL/MySQL e foi criada para workloads relacionais escaláveis na AWS.[1] Para reduzir overhead de conexões em ambientes serverless ou com muitos workers, pode-se usar pool de conexões, RDS Proxy ou PgBouncer conforme o modelo de deploy.[2]

A regra mais importante é não deixar consultas analíticas ou dashboards competirem com o banco transacional. A API de processamento deve escrever e consultar apenas o necessário para aprovar, registrar e rastrear operações. Listagens pesadas, relatórios e dashboards devem ler de réplicas, views materializadas, OpenSearch, ClickHouse ou data lake.

| Tipo de carga | Solução recomendada | Motivo |
|---|---|---|
| Escrita transacional crítica | Writer PostgreSQL/Aurora | Consistência, transações, ledger e idempotência. |
| Consulta operacional recente | Read replicas + índices específicos | Evita sobrecarregar writer. |
| Busca por filtros flexíveis | OpenSearch ou índice dedicado | Evita queries amplas no core. |
| Dashboard e BI | Data lake/ClickHouse/Athena | Não impacta rota transacional. |
| Métricas em tempo real | Prometheus/CloudWatch/Grafana | Métricas agregadas sem varrer banco. |
| Webhooks/eventos | Outbox + fila | Desacopla processamento e retentativas. |

## 8. Modelo de dados recomendado

O schema deve favorecer consistência financeira e consultas por chaves previsíveis. As tabelas grandes devem ser particionadas por data, especialmente `ledger_entries`, `provider_webhook_events`, `provider_operations`, `customer_webhook_deliveries` e `audit_log`.

| Tabela | Função | Índices principais |
|---|---|---|
| `clients` | Cadastro do cliente da plataforma | `status`, `created_at`. |
| `client_accounts` | Conta lógica do cliente | `client_id`, `status`. |
| `providers` | Providers disponíveis | `code`, `status`. |
| `provider_accounts` | Contas operacionais por provider | `provider_id`, `status`, `currency`, `capability`. |
| `client_provider_assignments` | Roteamento vigente por cliente | `client_id`, `product`, `effective_from`, `status`. |
| `provider_routing_rules` | Regras de roteamento e fallback | `priority`, `status`, `scope`. |
| `payments` | Operações PIX IN/entrada | `client_id`, `status`, `external_reference`, `created_at`. |
| `cashouts` | Operações PIX OUT/saída | `client_id`, `status`, `external_reference`, `created_at`. |
| `provider_operations` | Operações enviadas ao provider | `provider_id`, `provider_account_id`, `provider_operation_id`, `status`. |
| `ledger_accounts` | Contas contábeis internas | `owner_type`, `owner_id`. |
| `ledger_entries` | Lançamentos append-only | `transaction_id`, `ledger_account_id`, `created_at`. |
| `balance_snapshots` | Saldos materializados | `ledger_account_id`, `as_of`. |
| `liquidity_positions` | Liquidez por provider account | `provider_account_id`, `available_amount`, `reserved_amount`. |
| `liquidity_reservations` | Reservas por cash out | `provider_account_id`, `cashout_id`, `status`. |
| `idempotency_keys` | Controle de repetição | `client_id`, `key`, `operation_type`. |
| `outbox_events` | Eventos transacionais pendentes | `status`, `event_type`, `created_at`. |
| `provider_webhook_events` | Eventos recebidos de providers | `provider_id`, `event_id`, `received_at`. |
| `customer_webhook_deliveries` | Entregas para clientes | `client_id`, `status`, `next_attempt_at`. |
| `audit_log` | Trilha administrativa e financeira | `actor_id`, `entity_type`, `entity_id`, `created_at`. |

## 9. Estratégia para suportar muitas consultas

A v2 deve separar APIs transacionais de APIs de consulta. Endpoints como criar pagamento, criar saque e receber webhook precisam ser otimizados para p95/p99 baixo. Já endpoints de listagem, dashboard, extrato e relatórios devem ter paginação obrigatória, filtros limitados, índices planejados e, se necessário, leitura em réplica.

| Endpoint | Estratégia |
|---|---|
| `POST /payments` | Writer, validação rápida, idempotência, transação curta e outbox. |
| `POST /cashouts` | Writer, reserva transacional, resposta rápida com status inicial. |
| `POST /providers/{provider}/webhooks` | Persistir evento e responder rápido; processamento assíncrono. |
| `GET /payments/{id}` | Read replica ou cache curto, chave direta. |
| `GET /cashouts/{id}` | Read replica ou cache curto, chave direta. |
| `GET /transactions` | Read model paginado, nunca query livre no ledger bruto. |
| `GET /balance` | Snapshot/cache derivado do ledger, com consistência definida. |
| `GET /reports/*` | Banco analítico, não banco transacional. |

A melhor prática é criar **read models** específicos. O ledger é a fonte de verdade, mas não deve ser usado diretamente para todas as listagens. Para consulta rápida, use tabelas de projeção como `client_transaction_views`, `client_balance_views` e `provider_operation_views`, atualizadas por eventos/outbox.

## 10. Escala da API e baixa latência

Para aguentar grande volume de requests, a API precisa ser horizontalmente escalável e stateless. O estado deve ficar no banco, cache e filas. O processamento lento deve ir para workers. Chamadas externas ao provider não devem bloquear a rota crítica quando puderem ser assíncronas.

| Camada | Recomendação |
|---|---|
| API runtime | Node.js Fastify/NestJS ou Go, stateless, autoscaling. |
| Gateway | API Gateway/ALB com rate limit, WAF e autenticação por chave/assinatura. |
| Banco | Aurora PostgreSQL com writer, read replicas, particionamento e pool. |
| Cache | Redis para rate limit, tokens, configurações de roteamento e locks curtos. |
| Filas | SQS para provider calls, webhooks, conciliação e retentativas. |
| Eventos | Outbox no banco e publicador assíncrono. |
| Observabilidade | OpenTelemetry, logs estruturados, traces e métricas p95/p99. |

## 11. Roteamento e troca de provider sem impacto na experiência

A troca de provider deve ser invisível para o cliente. O contrato público não muda. O cliente continua usando o mesmo `clientId`, `apiKey`, endpoint, webhook e payloads. Internamente, a regra de roteamento muda apenas para novas operações, e operações antigas continuam vinculadas ao provider/account de origem até o estado final.

> Princípio: **operação criada em um provider deve morrer no mesmo provider**, salvo fluxo explícito de compensação. Não se deve tentar concluir no provider novo uma operação que nasceu no provider antigo.

| Situação | Conduta segura |
|---|---|
| Novo PIX IN após migração | Criar no novo provider/account. |
| PIX IN antigo pendente | Continuar aguardando webhook/reconciliação no provider antigo. |
| Cash out de saldo antigo | Permitir pela conta antiga ou exigir liquidez provisionada na nova. |
| Provider antigo instável | Usar reconciliação e fallback apenas para novas operações, não para duplicar operação pendente. |
| Cliente com saldo alto | Migrar em janela planejada, com liquidez pré-alocada. |

## 12. Controles obrigatórios para evitar perdas

A plataforma deve ter travas de risco antes de liberar roteamento ou migração. Essas travas reduzem prejuízo por saldo misturado, provider sem liquidez, duplicidade, falhas de webhook e inconsistência entre bancos.

| Controle | Por que é obrigatório |
|---|---|
| Idempotência por cliente/operação | Evita duplicidade por retry do cliente. |
| Ledger append-only | Permite auditoria e correção por lançamento reverso. |
| Reserva de saldo | Evita duplo saque do mesmo saldo. |
| Reserva de liquidez | Evita usar liquidez de outra obrigação sem controle. |
| Assignment com vigência | Evita troca abrupta que quebra operações pendentes. |
| Estado por operação | Evita tratar timeout como falha definitiva. |
| Reconciliação por provider account | Detecta diferença entre saldo interno e real. |
| Circuit breaker por provider | Evita mandar volume para provider degradado. |
| Limites por cliente/provider/account | Evita concentração de risco. |
| Aprovação manual para migração sensível | Evita migração com pendências financeiras. |

## 13. Roadmap recomendado por escopo

A decisão de separar processamento, Grafana e conciliação continua correta. Porém, a fundação multi-provider e o modelo de liquidez devem entrar desde o MVP, mesmo que apenas a Bents esteja ativa.

| Fase | Escopo | Resultado |
|---|---|---|
| 1 | Fundação transacional | API, auth, idempotência, ledger, outbox, provider interface, Bents. |
| 2 | PIX IN e webhook Bents | Entrada funcional, webhook seguro, status normalizado. |
| 3 | Cash Out com reservas | Saldo, liquidez, reservas, provider operation e retentativas. |
| 4 | Multi-provider readiness | Router, provider accounts, assignments e contract tests. |
| 5 | Migração segura | Fluxo de troca por cliente, draining e liquidez pré-alocada. |
| 6 | Consultas em escala | Read replicas, read models, cache e paginação forte. |
| 7 | Conciliação | Jobs por provider/account, divergências e ajustes. |
| 8 | Grafana completo | Painéis técnicos, financeiros e executivos. |

## 14. Recomendação final

A v2 deve evitar repetir o modelo de bolsão como uma única massa indistinta de dinheiro. O desenho correto é permitir contas agregadoras no provider, mas com **segregação contábil interna**, **liquidez operacional controlada**, **roteamento versionado por cliente**, **migração com estados** e **projeções de leitura separadas do core transacional**.

Para alto volume, o banco deve ser desenhado com escrita curta, índices previsíveis, particionamento, read replicas e read models. A API deve ser stateless e escalar horizontalmente. Consultas pesadas, dashboard e relatórios não devem competir com a rota de pagamento.

## References

[1]: https://docs.aws.amazon.com/AmazonRDS/latest/AuroraUserGuide/CHAP_AuroraOverview.html "Amazon Aurora overview — AWS Documentation"  
[2]: https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/rds-proxy.html "Using Amazon RDS Proxy — AWS Documentation"  
[3]: https://docs.aws.amazon.com/AWSSimpleQueueService/latest/SQSDeveloperGuide/welcome.html "Amazon SQS Developer Guide — AWS Documentation"  
[4]: https://opentelemetry.io/docs/ "OpenTelemetry Documentation"
