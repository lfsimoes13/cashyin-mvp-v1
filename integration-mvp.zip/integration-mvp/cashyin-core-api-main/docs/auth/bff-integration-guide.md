# Guia de Integração BFF → Core API (autenticação e endpoints)

**Público-alvo:** time que implementa o BFF (Backend-for-Frontend) do Dashboard.
**Objetivo:** descrever, de forma autossuficiente, como o BFF autentica-se na
Core API, quais endpoints pode consumir, e os fluxos sensíveis (step-up de
cash-out, administração, webhooks).

**Premissa de projeto:** ainda **não há clientes reais conectados**. Por isso o
contrato descrito aqui é o contrato-alvo (sem necessidade de retrocompatibilidade)
e a Core deve subir já com a autenticação **imposta** (ver
[Configuração](#2-configuração-da-core-env)).

**Documentos relacionados:**
- ADR de fronteira de auth: `docs/adr/auth-authorization-boundary.md`
- Modelo de ameaças: `docs/security/auth-threat-model.md`
- Plano de implementação: `docs/auth/implementation-plan.md`
- Contratos públicos Pix: `docs/readme-pages/pix-cash-in.md`, `docs/readme-pages/pix-cash-out.md`
- Webhooks: `docs/readme-pages/webhooks-integration.md`
- Erros: `docs/readme-pages/errors.md`

---

## 1. Modelo de confiança

```
┌───────────┐   login + MFA    ┌──────────┐   token confiável + headers   ┌──────────┐
│ Navegador │ ───────────────▶ │   BFF    │ ────────────────────────────▶ │   Core   │
│ (usuário) │                  │ (trusted)│   X-CashYin-BFF-Token         │   API    │
└───────────┘                  └──────────┘   X-CashYin-Actor-User-Id     └──────────┘
                                               X-CashYin-Client-Id
```

Princípios:

1. **O BFF é um backend confiável.** Ele autentica o usuário humano (Cognito,
   sessão de browser, MFA) e **representa** esse usuário perante a Core. A Core
   **não** chama IdP nem valida sessão de browser no caminho quente — confia no
   BFF mediante um **segredo compartilhado**.
2. **A Core é a autoridade de tenant e de escopos.** O `clientId` (tenant) e o
   ator (`actorUserId`) vêm de headers confiáveis enviados pelo BFF; os escopos
   do canal são um conjunto fixo definido pela Core (`DEFAULT_BFF_SCOPES`). O BFF
   **não pode** escalar além desse conjunto.
3. **O BFF não escreve direto no banco.** Toda mutação passa pelos endpoints
   `/v1/*` da Core (incluindo administração sob `/v1/admin/*`).
4. **Segurança de rede é pré-requisito.** O segredo compartilhado autentica o
   canal, mas a comunicação BFF→Core **deve** trafegar em rede privada
   (VPC/peering, mTLS ou IP allow-list). O segredo sozinho não substitui o
   isolamento de rede: quem conseguir falar com a Core e tiver o segredo pode se
   passar por qualquer usuário/tenant via os headers de ator/tenant.

---

## 2. Configuração da Core (env)

Variáveis relevantes ao canal BFF (validadas por Zod em `src/shared/config/env.ts`):

| Variável | Valores | Default | Descrição |
|---|---|---|---|
| `BFF_AUTH_MODE` | `off` \| `enforce` | `off` | Ativa o canal BFF. Em `enforce`, requisições com `X-CashYin-BFF-Token` são aceitas e verificadas. |
| `BFF_SHARED_SECRET` | string ≥ 32 chars | — | Segredo compartilhado BFF↔Core. **Obrigatório** quando `BFF_AUTH_MODE=enforce`. Guardar no Secrets Manager. |
| `AUTH_ENFORCEMENT_MODE` | `off` \| `shadow` \| `enforce` | `off` | Camada de **autorização por escopo** nas rotas `/v1/pix/*`. |
| `BFF_RBAC_MODE` | `off` \| `enforce` | `off` | RBAC por usuário no canal BFF (Seção 4.1). `enforce` exige `BFF_AUTH_MODE=enforce`. |
| `CASHOUT_STEPUP_MODE` | `off` \| `shadow` \| `enforce` | `off` | Step-up (2FA) para cash-out iniciado por humano (canal BFF). |
| `CASHOUT_STEPUP_TTL_MS` | inteiro > 0 | `300000` (5 min) | Validade do proof de step-up. |

**Configuração-alvo recomendada para o ambiente do BFF (sem usuários reais):**

```bash
BFF_AUTH_MODE=enforce
BFF_SHARED_SECRET=<segredo aleatório ≥ 32 chars, via Secrets Manager>
AUTH_ENFORCEMENT_MODE=enforce        # impõe escopos nas rotas /v1/pix/*
BFF_RBAC_MODE=enforce                # opcional: RBAC por usuário (requer grants — Seção 4.1)
CASHOUT_STEPUP_MODE=enforce          # opcional: exigir 2FA em cash-out humano
CASHOUT_STEPUP_TTL_MS=300000
```

> Ao ligar `BFF_RBAC_MODE=enforce`, **provisione os grants antes** (Seção 4.1):
> um ator sem grant ativo no tenant recebe **403** em todas as rotas.

> **Interação `BFF_AUTH_MODE` × `AUTH_ENFORCEMENT_MODE`:** o `AuthContext` (com
> tenant e ator) é resolvido **sempre** que há principal autenticado, independente
> de `AUTH_ENFORCEMENT_MODE` — auditoria e tenant ficam disponíveis em qualquer
> modo. `AUTH_ENFORCEMENT_MODE` governa **apenas** o gate de escopo nas rotas
> `/v1/pix/*`: em `off` não há checagem de escopo; em `enforce` requisições sem o
> escopo são negadas (403). Para autorização completa do canal BFF, rode
> **`AUTH_ENFORCEMENT_MODE=enforce`**.

---

## 2.1 Endpoint privado da Core (`api.cashyin.internal` via ECS Service Connect)

O BFF chama a Core por um **endpoint privado dentro da VPC** (leste-oeste),
nunca pelo domínio público `api.cashyin.com`. A topologia escolhida é **ECS
Service Connect** (o BFF roda como serviço ECS na VPC da Core):

| Item | Valor |
|---|---|
| **Base URL** | `http://api.cashyin.internal/v1/...` |
| **Descoberta** | Cloud Map **namespace** `cashyin.internal` (Service Connect); o proxy do BFF resolve o nome localmente — sem Route 53 público. |
| **Transporte** | **mTLS gerenciado** pelo Service Connect (criptografia em trânsito dentro da VPC, sem ALB interno). |
| **Ingress** | Conexão direta entre as ENIs das tasks; o SG da API libera a porta do container apenas para o SG/CIDR do BFF. |
| **Provisionamento (lado Core)** | Terraform `enable_service_connect = true` (ver `infra/README.md` §10). |
| **Lado BFF** | Rodar como serviço ECS **Service-Connect-enabled** no mesmo namespace (mesmo cluster ou cluster irmão na mesma VPC). |

> **Contrato é endpoint-agnóstico:** headers, escopos, idempotência, step-up e
> códigos de erro são idênticos independentemente do host. Só a base URL muda em
> relação ao canal `api_direct` público. Os exemplos `curl` deste guia usam
> `https://core.cashyin.internal` por convenção histórica; o host/esquema efetivo
> do canal BFF é **`http://api.cashyin.internal`** (mTLS é provido pela camada
> Service Connect, transparente para a aplicação).

> **Defesa em profundidade (Seção 1) continua valendo:** o segredo
> `X-CashYin-BFF-Token` autentica o canal; o isolamento de rede (namespace
> Service Connect + SG restrito ao BFF) garante que só o BFF, de dentro da VPC,
> alcança a Core. O BFF **não** tem acesso ao banco (o SG do RDS só aceita o SG
> da API).

---

## 3. Autenticação das requisições BFF → Core

Toda requisição do BFF para `/v1/*` (públicas e admin) deve enviar **três
headers**:

| Header | Conteúdo | Obrigatório |
|---|---|---|
| `X-CashYin-BFF-Token` | O valor de `BFF_SHARED_SECRET`. Comparado de forma timing-safe. | Sim |
| `X-CashYin-Actor-User-Id` | Id estável do usuário autenticado no BFF (para auditoria). | Sim |
| `X-CashYin-Client-Id` | Id do cliente/tenant (UUID de `clients.id`) que o usuário opera. | Sim |

Regras de decisão (em `src/modules/auth/authenticate.ts`):

- Se `X-CashYin-BFF-Token` **estiver presente** e `BFF_AUTH_MODE=enforce`:
  - token inválido → **401 `auth_invalid`** (nunca cai para Bearer);
  - faltando `X-CashYin-Actor-User-Id` ou `X-CashYin-Client-Id` → **401 `auth_invalid`**;
  - tudo válido → canal `frontend_bff`, escopos = `DEFAULT_BFF_SCOPES`.
- Se o token **não** estiver presente, a requisição segue o caminho `api_direct`
  (Bearer `ck_…`). Ou seja: o mesmo deploy aceita BFF e API direta; o canal é
  escolhido pela presença do header de token.

> **Não** envie `Authorization: Bearer ck_…` junto do token BFF: o canal é
> determinado pela presença do `X-CashYin-BFF-Token`. Escolha **um** canal por
> requisição.

### Exemplo (cash-in via BFF)

```bash
curl -X POST https://core.cashyin.internal/v1/pix/cash-in/qrcode \
  -H "X-CashYin-BFF-Token: $BFF_SHARED_SECRET" \
  -H "X-CashYin-Actor-User-Id: user_01HZ..." \
  -H "X-CashYin-Client-Id: 7c3e...-uuid" \
  -H "Idempotency-Key: $(uuidgen)" \
  -H "Content-Type: application/json" \
  -d '{ "amount": 100, "external_ref": "order-123", "description": "Pedido 123" }'
```

---

## 4. Escopos do canal BFF

O canal `frontend_bff` tem como **teto** o conjunto `DEFAULT_BFF_SCOPES`
(`src/modules/auth/authenticate.ts`):

| Escopo | Permite |
|---|---|
| `pix:cash_in:create` | Criar cobranças Pix (cash-in). |
| `pix:cash_in:read` | Consultar cash-in. |
| `pix:cash_out:create` | Criar pagamentos Pix (cash-out) e emitir step-up. |
| `pix:cash_out:read` | Consultar cash-out. |
| `balance:read` | Consultar o saldo do cliente (`GET /v1/balance`). |
| `webhooks:manage` | Gerenciar endpoints de webhook do cliente. |
| `clients:read` | Ler configuração comercial (tarifas/roteamento). |

Com `BFF_RBAC_MODE=off` (default), **todo** ator autenticado recebe esse
conjunto inteiro. Com `BFF_RBAC_MODE=enforce`, cada ator recebe apenas a
**interseção** entre seu grant e esse teto (Seção 4.1).

**Não incluídos no canal BFF (por design):**

- `api_keys:manage` — gestão de **chaves de API** (`POST /v1/admin/api-keys` etc.)
  exige uma credencial dedicada com esse escopo. **O BFF não pode** criar/rotacionar/
  revogar chaves de API. Se o Dashboard precisar dessa função, emita uma chave
  `api_direct` específica com `api_keys:manage` e use o canal direto para essas
  rotas (não o canal BFF).
- `clients:manage` — gestão dos **grants por usuário** (Seção 4.1) e administração
  de plataforma. Exige credencial dedicada; **não** é concedido ao canal BFF.

Requisição com escopo insuficiente → **403 `auth_insufficient_scope`** (com
`{ requiredScope }` no corpo).

### 4.1 RBAC por usuário (`BFF_RBAC_MODE=enforce`)

Para granularidade por usuário, a Core mantém `user_client_grants`: para cada
par `(actorUserId, clientId)`, os escopos que aquele ator pode exercer naquele
tenant. Quando `BFF_RBAC_MODE=enforce`, o autenticador:

1. resolve o grant **ativo** do ator no tenant;
2. **interseciona** os escopos do grant com `DEFAULT_BFF_SCOPES` (o teto — o BFF
   nunca escala além disso, mesmo que o grant liste algo a mais);
3. se **não houver grant ativo**, rejeita com **403 `auth_client_mismatch`**.

**Provisionamento dos grants** (por uma credencial `api_direct` com
`clients:manage` — **não** pelo canal BFF):

| Método | Rota | Corpo / efeito |
|---|---|---|
| `GET` | `/v1/admin/bff-grants` | Lista os grants do tenant. |
| `PUT` | `/v1/admin/bff-grants/:actorUserId` | Cria/atualiza o grant. Corpo: `{ "scopes": ["pix:cash_in:read", ...] }`. Escopos devem ser subconjunto de `DEFAULT_BFF_SCOPES` (senão **422**). |
| `DELETE` | `/v1/admin/bff-grants/:actorUserId` | Revoga o grant (**204**; **404** se não havia grant ativo). |

O tenant é derivado do principal autenticado (a credencial operadora gerencia
apenas os atores do próprio cliente).

---

## 5. Endpoints disponíveis ao BFF

Todos sob `https://<core-host>/v1/...`, todos exigem os 3 headers do canal BFF
(Seção 3). Contratos de corpo/resposta detalhados nos docs de readme-pages
referenciados.

### 5.1 Pix — cash-in (cobrança)

| Método | Rota | Escopo | Notas |
|---|---|---|---|
| `POST` | `/v1/pix/cash-in/qrcode` | `pix:cash_in:create` | Exige `Idempotency-Key`. Cria cobrança e retorna `pix.emv` (copia-e-cola). |
| `GET` | `/v1/pix/cash-in/:txid` | `pix:cash_in:read` | Consulta por `txid`. |

Contrato completo: `docs/readme-pages/pix-cash-in.md`.

### 5.2 Pix — cash-out (pagamento)

| Método | Rota | Escopo | Notas |
|---|---|---|---|
| `POST` | `/v1/pix/cash-out` | `pix:cash_out:create` | Exige `Idempotency-Key`. Sob `CASHOUT_STEPUP_MODE=enforce`, exige header de step-up (Seção 6). |
| `POST` | `/v1/pix/cash-out/step-up` | `pix:cash_out:create` | Emite o proof de step-up (Seção 6). |
| `GET` | `/v1/pix/cash-out/:id` | `pix:cash_out:read` | Consulta por `id` (UUID). |

Contrato completo: `docs/readme-pages/pix-cash-out.md`.
Validação de `pix.key` por `pix.key_type` (CPF/CNPJ/PHONE/EMAIL/EVP): chave
malformada → **422 `validation_error`**.

### 5.3 Saldo

| Método | Rota | Escopo | Notas |
|---|---|---|---|
| `GET` | `/v1/balance` | `balance:read` | Saldo do cliente (incluído no conjunto default do BFF). |

### 5.4 Administração de endpoints de webhook (`webhooks:manage`)

| Método | Rota | Corpo / efeito |
|---|---|---|
| `GET` | `/v1/admin/webhook-endpoints` | Lista endpoints do cliente. |
| `POST` | `/v1/admin/webhook-endpoints` | Cria endpoint. Corpo: `{ eventPattern, targetUrl, description? }`. **`signingSecret` retornado só aqui** (uma vez). |
| `PATCH` | `/v1/admin/webhook-endpoints/:id` | Atualiza (`targetUrl?`, `status?` `active`\|`disabled`, `description?`, `eventPattern?`). |
| `POST` | `/v1/admin/webhook-endpoints/:id/disable` | Desabilita o endpoint. |

Tenant derivado do principal autenticado; recurso de outro tenant → **404**.

### 5.5 Configuração comercial (read-only, `clients:read`)

| Método | Rota | Retorno |
|---|---|---|
| `GET` | `/v1/admin/config/fees` | `{ data: [...] }` — regra de tarifa ativa por operação (cash-in/cash-out). |
| `GET` | `/v1/admin/config/routing` | `{ data: [...] }` — provedor ativo por operação (**apenas** `provider_name`). |

> A Core aplica uma **allow-list** estrita: custo de provedor, margem, subsídio,
> `metadata`, ids de conta de provedor e segredos **nunca** são expostos.

---

## 6. Fluxo de step-up (2FA) no cash-out

Aplica-se **apenas** ao canal `frontend_bff` (humano). Cash-outs `api_direct`
(máquina) são isentos. Inerte quando `CASHOUT_STEPUP_MODE=off`.

Sequência quando `CASHOUT_STEPUP_MODE=enforce`:

```
1. BFF executa desafio MFA com o usuário (fora da Core).
2. BFF → POST /v1/pix/cash-out/step-up          (corpo = parâmetros do cash-out pretendido)
   Core ← 201 { proof_id, transaction_hash, expires_at }
3. BFF → POST /v1/pix/cash-out
        header X-CashYin-Step-Up-Proof: <proof_id>
        header Idempotency-Key: <uuid>
        corpo  = MESMOS parâmetros de binding usados no passo 2
   Core recomputa o hash canônico e consome o proof (single-use).
```

### Binding do proof

O proof é amarrado a um **hash canônico** dos campos que importam
(`src/modules/cashouts/cashout-step-up.ts`):

- `clientId` (tenant)
- `amount`
- `pix.key` e `pix.key_type`
- `external_ref`
- `receiver.document_number`

Campos **cosméticos** (`description`, `receiver.name`) **não** entram no hash —
podem variar entre o step-up e o cash-out. Qualquer divergência nos campos de
binding invalida o proof.

### Regras

- O `proof_id` é **uso único**. Reuso, expiração (após `CASHOUT_STEPUP_TTL_MS`) e
  binding divergente são todos indistinguíveis: retornam **403 `auth_step_up_required`**
  (com `{ reason }` coarse).
- Sem header de proof em `enforce` → **403 `auth_step_up_required`** (`reason: "missing"`).
- Header do proof no cash-out: `X-CashYin-Step-Up-Proof: <proof_id>`.

### Exemplo

```bash
# Passo 2 — emitir proof (após MFA no BFF)
curl -X POST https://core.cashyin.internal/v1/pix/cash-out/step-up \
  -H "X-CashYin-BFF-Token: $BFF_SHARED_SECRET" \
  -H "X-CashYin-Actor-User-Id: user_01HZ..." \
  -H "X-CashYin-Client-Id: 7c3e...-uuid" \
  -H "Content-Type: application/json" \
  -d '{
        "external_ref": "payout-9876",
        "amount": 7500,
        "pix": { "key_type": "CNPJ", "key": "60311124000110" },
        "receiver": { "name": "Alice Souza", "document_number": "60311124000110" }
      }'
# → 201 { "proof_id": "…", "transaction_hash": "…", "expires_at": "…" }

# Passo 3 — submeter cash-out com o proof
curl -X POST https://core.cashyin.internal/v1/pix/cash-out \
  -H "X-CashYin-BFF-Token: $BFF_SHARED_SECRET" \
  -H "X-CashYin-Actor-User-Id: user_01HZ..." \
  -H "X-CashYin-Client-Id: 7c3e...-uuid" \
  -H "X-CashYin-Step-Up-Proof: <proof_id>" \
  -H "Idempotency-Key: $(uuidgen)" \
  -H "Content-Type: application/json" \
  -d '{
        "external_ref": "payout-9876",
        "amount": 7500,
        "pix": { "key_type": "CNPJ", "key": "60311124000110" },
        "receiver": { "name": "Alice Souza", "document_number": "60311124000110" }
      }'
```

---

## 7. Idempotência

`POST /v1/pix/cash-in/qrcode` e `POST /v1/pix/cash-out` exigem o header
`Idempotency-Key` (UUID por intenção de operação).

- Reenvio com a **mesma** chave e mesmo corpo → **200** com o recurso original
  (replay), em vez de criar duplicata.
- Ausência do header → **400 `idempotency_key_required`**.

O BFF deve gerar a `Idempotency-Key` no início da intenção do usuário e
reutilizá-la em retries, garantindo exatamente-uma-vez do ponto de vista do
usuário.

---

## 8. Webhooks de saída (Core → cliente)

A Core entrega eventos (cash-in pago, cash-out concluído/falho etc.) aos
endpoints registrados via Seção 5.4. O envelope inclui assinatura HMAC com o
`signingSecret` retornado **na criação** do endpoint.

Detalhes de envelope, `schema_version`, verificação de assinatura e retries:
`docs/readme-pages/webhooks-integration.md`.

O BFF pode usar webhooks para atualizar o Dashboard de forma assíncrona, em vez
de fazer polling em `GET /v1/pix/...`.

---

## 9. Modelo de erros

Formato uniforme (`AppError` → `toHttpError`):

```json
{ "error": { "code": "auth_insufficient_scope", "message": "...", "request_id": "..." } }
```

| HTTP | `code` | Quando |
|---|---|---|
| 400 | `idempotency_key_required` | Falta `Idempotency-Key` em cash-in/cash-out. |
| 401 | `auth_required` / `auth_invalid` | Sem credencial / token BFF inválido / faltam headers de ator/tenant. |
| 403 | `auth_insufficient_scope` | Escopo ausente (corpo traz `requiredScope`). |
| 403 | `auth_client_mismatch` | RBAC (`BFF_RBAC_MODE=enforce`): ator sem grant ativo no tenant. |
| 403 | `auth_step_up_required` | Step-up ausente/expirado/divergente (corpo traz `reason`). |
| 404 | `*_not_found` | Recurso inexistente ou de outro tenant (uniforme, não vaza posse). |
| 422 | `validation_error` | Corpo inválido (inclui `pix.key` que não casa com `pix.key_type`). |

As mensagens de auth são **genéricas e estáveis** por design (não distinguem
"ausente" de "malformado") — não tente parsear a mensagem; use o `code`.

---

## 10. Canal `api_direct` (não-BFF) — referência rápida

Para serviços de máquina (não o BFF), a Core aceita **Bearer API key** (`ck_…`),
opcionalmente com assinatura HMAC por requisição (`API_HMAC_MODE`). O BFF
**não** usa este canal; documentado aqui apenas para contexto.

- Header: `Authorization: Bearer ck_<64 hex>`.
- HMAC (quando habilitado): `X-CashYin-Timestamp`, `X-CashYin-Nonce`,
  `X-CashYin-Signature: sha256=<hex>` sobre a string canônica
  `METHOD\nURL\nTIMESTAMP\nNONCE\nSHA256(json-canônico-do-body)`.

Contrato completo de assinatura (regras de canonicalização, implementações
Node/Python, limitações): `docs/auth/api-direct-hmac-signing.md`.

---

## 11. Checklist de integração (BFF)

- [ ] Obter `BFF_SHARED_SECRET` do Secrets Manager (mesmo valor na Core).
- [ ] Garantir rede privada BFF→Core (VPC/mTLS/allow-list).
- [ ] Em toda chamada `/v1/*`, enviar `X-CashYin-BFF-Token`, `X-CashYin-Actor-User-Id`,
      `X-CashYin-Client-Id`.
- [ ] Nunca enviar `Authorization: Bearer` junto do token BFF.
- [ ] Gerar e reutilizar `Idempotency-Key` em cash-in/cash-out.
- [ ] Implementar o fluxo de step-up (Seção 6) se `CASHOUT_STEPUP_MODE=enforce`:
      emitir proof com os mesmos parâmetros de binding e repassar o `proof_id`.
- [ ] Tratar erros pelo `code` (não pela mensagem); 401/403/404/422.
- [ ] Registrar endpoint(s) de webhook via `/v1/admin/webhook-endpoints` e
      guardar o `signingSecret` retornado na criação.
- [ ] Para gestão de **chaves de API**, usar credencial dedicada `api_keys:manage`
      (fora do canal BFF).
- [ ] Se for usar RBAC por usuário (`BFF_RBAC_MODE=enforce`), provisionar os
      grants via `/v1/admin/bff-grants` (credencial `clients:manage`) **antes** de
      ligar a flag; tratar `403 auth_client_mismatch` para ator sem grant.
