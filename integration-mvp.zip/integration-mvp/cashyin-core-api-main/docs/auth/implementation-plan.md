# Plano de Implementação — Autenticação e Administração da Core API

**Data:** 2026-05-31
**Branch de origem:** `feat/core-api-auth-foundation`
**Status global:** PR 0 (fundação) + PR 1 (escopos/ciclo de vida) + PR 2
(resolução de `AuthContext` + imposição por escopo, canal `api_direct`) + PR 3
(canal BFF confiável) + PR 4 (endpoints de administração) + PR 5 (step-up de
cash-out) + PR 6 (HMAC para `api_direct`) implementados na branch atual. Todas
as novas camadas ficam atrás de flags com default `off` (nenhuma mudança de
runtime até serem ligadas). `lint`/`test`/`build` verdes (852 testes).
**Documentos relacionados:**
- ADR: `docs/adr/auth-authorization-boundary.md`
- Modelo de ameaças: `docs/security/auth-threat-model.md`
- **Guia de integração do BFF:** `docs/auth/bff-integration-guide.md`
- **Guia de assinatura `api_direct` (HMAC):** `docs/auth/api-direct-hmac-signing.md`

> Este é o documento de controle. Cada fatia/PR tem tarefas com status. Atualize
> a coluna **Status** conforme o trabalho avança. Uma branch por fatia (ver regra
> de fluxo Git do projeto).

> **⚠️ Premissa de projeto (revisão 2026-06-01):** ainda **não há clientes reais
> conectados**. Decisões conservadoras tomadas para preservar retrocompatibilidade
> de tráfego real **não se aplicam mais**: podemos impor autenticação/escopo
> direto (sem longos períodos de `shadow` para proteger clientes), fechar desvios
> que existiam só por compatibilidade e simplificar contratos. Ver **Seção 9**
> para a releitura de cada desvio e o alvo simplificado, e a **Seção 6** para o
> rollout revisado. O guia de integração do BFF (`docs/auth/bff-integration-guide.md`)
> é o contrato-alvo a ser entregue ao time do BFF.

---

## 1. Estado atual do repositório (descoberta)

Resumo do que foi inspecionado antes de planejar, para seguir os padrões existentes.

| Área | Achado relevante |
|---|---|
| Registro de rotas | `src/app/routes.ts` registra rotas por módulo e injeta o preHandler `requireClientAuth` por rota (`/v1/*`). `/health`, `/ready`, `/internal/webhooks/*` ficam sem auth. |
| App | `src/app/create-app.ts` cria o Fastify, helmet/cors/rate-limit, redaction de logs e error handler que serializa `AppError` via `toHttpError`. |
| Composição | `src/app/container.ts` é a composition root; serviços recebem repositórios e são injetados nas rotas. |
| Config | `src/shared/config/env.ts` (Zod). **Já existe** `AUTH_ENFORCEMENT_MODE` (`off`\|`shadow`\|`enforce`, default `off`). |
| Migrations | `migrations/NNNN_descricao.sql`, ordem lexicográfica, runner idempotente (`scripts/migrate.mjs`), snake_case, `TIMESTAMPTZ`, enums, índices. Próxima = `0017_`. |
| Tabela `clients` | `id, legal_name, trade_name, status, created_at, updated_at`. |
| Credenciais de API | Tabela `client_api_keys` (`id, client_id, key_prefix, key_hash, status active\|revoked, label, created_at, last_used_at, revoked_at`). Serviço em `src/modules/auth/client-api-key.service.ts` (chave `ck_<64 hex>`, SHA-256, comparação timing-safe). PreHandler `requireClientAuth` resolve `request.client`. **Não há** escopos, expiração, rotação nem endpoint de administração. |
| Webhooks de cliente | `client_webhook_endpoints` / `client_webhook_deliveries` + dispatcher. Sem rotas de administração. |
| Rotas Pix críticas | **Reais:** `POST /v1/pix/cash-in/qrcode`, `GET /v1/pix/cash-in/:txid`, `POST /v1/pix/cash-out`, `GET /v1/pix/cash-out/:id`. |
| Idempotência/ledger | `idempotency_keys` por `(client_id, key, operation_type)`; cash-in deduplica por `(client_id, external_ref)`. Tenant entra nos serviços via `client.clientId`. |
| Testes | Vitest unitário em `tests/unit/**`, Fastify `inject`, repositórios fakes, sem banco. |
| Fundação de auth (já na branch) | `src/shared/auth/{auth-context,auth-scopes,auth-errors,guards,fastify-auth-context}.ts` + `tests/unit/auth-guards.spec.ts` + ADR + modelo de ameaças. |

---

## 2. Revisão crítica do prompt

### 2.1 O que faz sentido (manter)

- **Fronteira `AuthContext` normalizada** como única dependência da aplicação:
  já implementada em `src/shared/auth/auth-context.ts`. Excelente decisão e
  alinhada ao código.
- **Guards puros, sem I/O** (`requireAuth`, `requireScope`, `requireClientAccess`,
  `requireAnyAmr`, `requireCashoutStepUp`): já implementados e testados.
- **`AUTH_ENFORCEMENT_MODE` (`off`/`shadow`/`enforce`)** para rollout em estágios:
  já existe no `env.ts`. Mantém o caminho financeiro intocado até o `enforce`.
- **Dois canais (BFF e API direta) + tenant derivado do principal**: correto e é
  o eixo do trabalho restante.
- **BFF não escreve direto no banco**: correto; a Core expõe endpoints de
  administração consumidos pelo BFF.

### 2.2 O que NÃO faz sentido / está desatualizado para este repo

1. **Endpoints errados no contexto do prompt.** O prompt cita
   `POST /v1/pix/charges` e `POST /v1/pix/payments`. **Não existem.** Os reais são
   `POST /v1/pix/cash-in/qrcode` e `POST /v1/pix/cash-out`. Todo o plano usa os
   nomes reais.
2. **`clientId` no corpo já foi eliminado.** Os schemas
   (`payment.schemas.ts`, `cashout.schemas.ts`) **não aceitam** `client_id` no
   corpo — o tenant é resolvido do Bearer e injetado pelo handler. A "regra mais
   importante" do prompt (rejeitar mismatch de `clientId` do corpo) já está, na
   prática, satisfeita. Resta apenas: (a) tornar o `AuthContext.clientId` a fonte
   canônica formal e (b) manter um guard defensivo caso um campo legado de
   compatibilidade seja reintroduzido. Risco atual: baixo.
3. **Formato do `AuthContext` do prompt é mais rígido que o implementado.** O
   prompt define `clientId: string` e `amr: readonly string[]` como obrigatórios.
   A implementação atual os torna **opcionais** (transição correta: nem todo
   principal de máquina carrega `amr`; `clientId` só é garantido após `enforce`).
   **Recomendação:** manter opcional agora; tornar `clientId` efetivamente
   obrigatório no ponto de derivação por canal, não no tipo.
4. **`StepUpProof` diverge do prompt.** Prompt:
   `{ kind, proofId, transactionHash, expiresAt }`. Implementado:
   `{ amr, transactionHash, issuedAt, expiresAt }` (já testado). **Recomendação:**
   manter o implementado e adicionar `proofId`/`kind` apenas quando a persistência
   de step-up entrar (PR 5), evitando churn no PR já pronto.

### 2.3 Revisão de endpoints e variáveis

- **Vocabulário de escopos x domínio.** ✅ **Decidido (T1.1):** os escopos foram
  renomeados para `pix:cash_in:*` / `pix:cash_out:*`, alinhados ao domínio
  (`operation_type`, rotas, webhooks). Adicionou-se `pix:cash_out:read` para
  simetria com `pix:cash_in:read` (a rota `GET /v1/pix/cash-out/:id` precisa de
  gate de leitura). Conjunto final: `pix:cash_in:create`, `pix:cash_in:read`,
  `pix:cash_out:create`, `pix:cash_out:read`, `pix:cash_out:approve`,
  `webhooks:manage`, `clients:read`.
- **`AUTH_ENFORCEMENT_MODE`**: nome e valores adequados. Manter.
- **Novas variáveis sugeridas** (introduzidas só na fatia que as usa):
  `BFF_AUTH_MODE`, `BFF_SHARED_SECRET` (ou par de chaves para JWT interno),
  `STEP_UP_*`. Detalhe em cada PR.
- **Rota de administração**: padronizar sob `/v1/admin/*`, protegida por escopos
  de administração e/ou canal `frontend_bff`. Coerente com "BFF não escreve no
  banco".

---

## 3. Modelo de autenticação alvo (ajustado ao repo)

`AuthContext` (já existente) é a única fronteira. Cada canal produz um
`AuthContext`; guards e serviços nunca ramificam por "como" o chamador se
autenticou.

| Canal | `channel` | `principalType` | Origem da credencial | `clientId` |
|---|---|---|---|---|
| API direta | `api_direct` | `api_client` | Bearer `ck_*` (hoje) / HMAC (PR 6) | da `client_api_keys` |
| BFF | `frontend_bff` | `user` | segredo/JWT interno confiável + header de ator | do contexto confiável |
| Interno/worker | `internal` | `service` | identidade de processo | n/a ou fixo |
| Webhook provedor | `webhook_provider` | `provider` | `WebhookAuthStrategy` (já existe) | n/a |

`AUTH_ENFORCEMENT_MODE`:
- `off`: nenhuma resolução/imposição (comportamento atual).
- `shadow`: resolve `AuthContext`, registra/mede decisões, **não** nega.
- `enforce`: nega não autenticados/não autorizados.

---

## 4. Plano em fatias (uma branch por PR)

Legenda de status: ✅ concluído · 🚧 em andamento · ⬜ a fazer · 🔎 a revisar · ⛔ bloqueado

### PR 0 — Fundação tipada de auth `feat/core-api-auth-foundation` (branch atual)

| ID | Tarefa | Status |
|---|---|---|
| 0.1 | Tipo `AuthContext` + `StepUpProof` (`auth-context.ts`) | ✅ |
| 0.2 | Constantes de escopo (`auth-scopes.ts`) | ✅ |
| 0.3 | Erros não vazantes (`auth-errors.ts`) | ✅ |
| 0.4 | Guards puros (`guards.ts`) | ✅ |
| 0.5 | Augmentation `request.authContext` (`fastify-auth-context.ts`) | ✅ |
| 0.6 | Flag `AUTH_ENFORCEMENT_MODE` no `env.ts` | ✅ |
| 0.7 | Testes de guards (`tests/unit/auth-guards.spec.ts`) | ✅ |
| 0.8 | ADR + modelo de ameaças | ✅ |
| 0.9 | `pnpm lint && pnpm test && pnpm build` verdes, revisar e commitar | 🔎 |

### PR 1 — Escopos e ciclo de vida das credenciais de API (na branch `feat/core-api-auth-foundation`)

Objetivo: `client_api_keys` ganha escopos, expiração e rotação; serviço passa a
verificar expiração e a expor rotação/revogação. Sem mexer no caminho crítico.

> **Decisão de branch:** por opção do time, PR 0 (fundação) e PR 1 seguem juntos
> na branch `feat/core-api-auth-foundation` (não foi criada `feat/api-credential-lifecycle`).

| ID | Tarefa | Status |
|---|---|---|
| 1.1 | Renomear escopos para `pix:cash_in:*` / `pix:cash_out:*` + `DEFAULT_CLIENT_API_SCOPES` (`auth-scopes.ts`) | ✅ |
| 1.2 | Migration `0017_client_api_key_scopes_and_expiry.sql`: `scopes TEXT[] NOT NULL DEFAULT '{}'`, `expires_at TIMESTAMPTZ`, índice parcial de expiração | ✅ |
| 1.3 | Backfill: chaves existentes recebem o conjunto padrão de escopos (na própria migration) | ✅ |
| 1.4 | `ClientApiKeyService`: carregar `scopes`/`expires_at`; rejeitar chave expirada em `verify()`; filtrar escopos desconhecidos via `isAuthScope` | ✅ |
| 1.5 | `ClientApiKeyService.rotate(apiKeyId)` (gera nova + revoga antiga atomicamente, via `withTransaction`) e `revoke(apiKeyId)` por id | ✅ |
| 1.6 | `ClientPrincipal`/`GeneratedApiKey` carregam `scopes`; container injeta `withTransaction` | ✅ |
| 1.7 | Atualizar `provision-test-client.mjs` para semear escopos padrão | ✅ |
| 1.8 | Testes: expiração, escopos desconhecidos, rotação (sucesso/inexistente/revogada/atomicidade), revogação | ✅ |
| 1.9 | `lint`/`test`/`build` verdes (777 testes) | ✅ |

**Desvios em relação ao plano original (intencionais):**
- `last_rotated_at` **não** foi adicionada: a rotação já fica auditável por
  `old.revoked_at` + `new.created_at`; coluna extra seria redundante.
- Adicionado o escopo `pix:cash_out:read` (não previsto), para simetria de leitura.
- Atomicidade do `rotate` via callback `withTransaction` injetado (default sem
  transação para testes; container injeta `Database.withTransaction`), mantendo o
  serviço desacoplado da classe `Database` e testável sem banco.

### PR 2 — Resolução do `AuthContext` (canal api_direct) + wiring do enforcement (na branch `feat/core-api-auth-foundation`)

Objetivo: preHandler que constrói `AuthContext` a partir do principal Bearer e
respeita `AUTH_ENFORCEMENT_MODE`. Guards de escopo aplicados às rotas `/v1`,
ativos apenas em `enforce` (em `shadow` só logam/medem).

Entregue em `src/modules/auth/auth-enforcement.ts` (resolução + guards encenados
+ bundle `AuthPreHandlers`), com wiring em `src/app/routes.ts` e nos registrars.

| ID | Tarefa | Status |
|---|---|---|
| 2.1 | `mapClientPrincipalToAuthContext` + `buildResolveAuthContext` (`channel='api_direct'`, `principalId=clientId`, `credentialId=apiKeyId`, `scopes`) | ✅ |
| 2.2 | `AUTH_ENFORCEMENT_MODE`: `off` no-op, `shadow` resolve+loga/mede sem negar, `enforce` nega | ✅ |
| 2.3 | Popular `request.authContext` nas rotas `/v1/*` (mantendo `request.client`) | ✅ |
| 2.4 | `requireScope` por rota nas 4 rotas Pix (`cash_in:create/read`, `cash_out:create/read`); `GET /v1/balance` só Bearer | ✅ |
| 2.5 | Tenant derivado do `AuthContext` (mesma origem do `request.client`); sem `client_id` no corpo, `requireClientAccess` fica disponível para campo legado | ✅ (por design) |
| 2.6 | Métrica `cashyin_auth_scope_decisions_total` (mode/decision/scope/route) + log de would-deny em `shadow` (sem segredos) | ✅ |
| 2.7 | Testes: unit dos preHandlers + matriz `off`/`shadow`/`enforce` × escopo presente/ausente via `inject` (15 testes) | ✅ |
| 2.8 | ADR (seção PR 2) + modelo de ameaças (T1) atualizados | ✅ |
| 2.9 | `lint`/`test`/`build` verdes (792 testes) | ✅ |

**Notas de design:**
- Autenticação Bearer continua **sempre** imposta (via `requireClientAuth`); a flag
  governa apenas a camada aditiva de escopo. Padrão `off` ⇒ zero mudança de runtime.
- `GET /v1/balance` ficou intencionalmente sem guard de escopo para não negar
  chaves existentes (o conjunto padrão não tem escopo de balance) — escopo de
  leitura dedicado fica para o PR de administração.

### PR 3 — Canal BFF confiável + ator de auditoria `feat/bff-trusted-channel`

Objetivo: a Core verifica chamadas confiáveis do BFF e representa o usuário-ator,
sem implementar login no browser nem chamar Cognito por requisição.

| ID | Tarefa | Status |
|---|---|---|
| 3.1 | **Decisão:** mecanismo de confiança BFF→Core — **segredo compartilhado** (`X-CashYin-BFF-Token`, comparação timing-safe) em vez de JWT interno, evitando nova dependência. Registrado no ADR | ✅ |
| 3.2 | Variáveis `env.ts`: `BFF_AUTH_MODE` (`off`/`enforce`), `BFF_SHARED_SECRET` (≥32, obrigatório quando `enforce` via `superRefine`) | ✅ |
| 3.3 | Autenticador unificado (`authenticate.ts`) + `ResolvedPrincipal`: canal BFF resolve `channel='frontend_bff'`, `principalType='user'`, `actorUserId`/`clientId` confiáveis dos headers, `scopes`=`DEFAULT_BFF_SCOPES` | ✅ |
| 3.4 | Verificação local (sem IdP no caminho crítico); token inválido → 401 sem fallback para Bearer | ✅ |
| 3.5 | Auditoria: `actorUserId` + `credentialId` propagados ao `AuthContext` | ✅ |
| 3.6 | Testes: `tests/unit/bff-auth.spec.ts` (válido/token errado/sem ator/sem client/fallback Bearer/`off`) | ✅ |
| 3.7 | `lint`/`test`/`build` verdes | ✅ |

> **Desvios PR 3:** (a) `BFF_AUTH_MODE` é `off`/`enforce` (sem `shadow` — um canal
> ou é aceito ou não). (b) Escopos do BFF vêm de um conjunto fixo da Core
> (`DEFAULT_BFF_SCOPES`: cash_in/cash_out create+read, `webhooks:manage`,
> `clients:read`) — a Core continua sendo a autoridade; RBAC por usuário fica
> para depois. (c) O canal BFF resolve `AuthContext` (com ator) apenas quando
> `AUTH_ENFORCEMENT_MODE != off`, conforme contrato documentado de `off`.

### PR 4 — Endpoints de administração (consumidos pelo BFF) `feat/admin-management-endpoints`

Objetivo: substituir o provisionamento manual por API administrativa governada,
sob `/v1/admin/*`, protegida por escopos de administração / canal BFF.

| ID | Tarefa | Status |
|---|---|---|
| 4.1 | Escopo de administração `api_keys:manage` adicionado (`webhooks:manage`/`clients:read` já existiam) | ✅ |
| 4.2 | `POST /v1/admin/api-keys`, `GET /v1/admin/api-keys` (sem segredo), `POST .../:id/rotate`, `POST .../:id/revoke` | ✅ |
| 4.3 | CRUD de `client_webhook_endpoints` sob `/v1/admin/webhook-endpoints` (GET/POST/PATCH/disable; `signing_secret` retornado só na criação) | ✅ |
| 4.4 | Leitura de configuração do cliente (planos/tarifas) — **adiada** (fora do escopo mínimo desta fatia) | ⬜ |
| 4.5 | Rotas registradas em `routes.ts`; serviço admin de webhook no `container.ts` | ✅ |
| 4.6 | Testes de autorização (`tests/unit/admin-routes.spec.ts`, `client-webhook-endpoint-admin.spec.ts`): escopo insuficiente → 403; tenant cruzado → 404 | ✅ |
| 4.7 | `lint`/`test`/`build` verdes | ✅ |

> **Desvios PR 4:** (a) `clientId` é derivado do principal autenticado
> (`authContext.clientId`), **sem** `:clientId` no path — elimina risco de
> cross-tenant; um admin de plataforma multi-tenant fica para outra fatia.
> (b) Admin **sempre** impõe escopo (modo `enforce` fixo), independente de
> `AUTH_ENFORCEMENT_MODE`, pois são rotas novas sem legado a proteger. (c) 4.4
> (leitura de planos/tarifas) adiada.

### PR 5 — Step-up / 2FA no cash-out (imposição) `feat/cashout-step-up-enforcement`

| ID | Tarefa | Status |
|---|---|---|
| 5.1 | Tabela `cashout_step_up_proofs` (uso único via `status='issued'→'consumed'`, vínculo por `transaction_hash`) — migration `0018` | ✅ |
| 5.2 | Emissão/consumo no servidor (`cashout-step-up.ts`): `canonicalCashoutHash`, `issue`, `consume` (atômico/single-use), `peek` (shadow) | ✅ |
| 5.3 | Variáveis `CASHOUT_STEPUP_MODE` (`off`/`shadow`/`enforce`), `CASHOUT_STEPUP_TTL_MS` (default 5 min) | ✅ |
| 5.4 | Endpoint `POST /v1/pix/cash-out/step-up` (emissão) + imposição no `POST /v1/pix/cash-out` sob `enforce` (consome antes de criar) | ✅ |
| 5.5 | Testes: `tests/unit/cashout-step-up.spec.ts` (hash determinístico, serviço, e2e ausente/inválido/válido/`api_direct` isento/`off`/`shadow`) | ✅ |
| 5.6 | `lint`/`test`/`build` verdes | ✅ |

> **Desvios PR 5:** (a) Imposição limitada ao canal `frontend_bff` (humano); cash-outs
> `api_direct` (máquina) são isentos — a API key é a credencial. (b) Em vez de
> popular `context.stepUp` + `requireCashoutStepUp`, a verificação usa
> `consume` no SQL (hash + expiry + single-use atômico), que subsume o guard; o
> guard puro permanece disponível para o modelo em-contexto. (c) `StepUpProof`
> não foi estendido com `proofId`/`kind` (desnecessário para esta fatia).

### PR 6 — HMAC para API direta (hardening anti-replay) `feat/api-direct-hmac-signing`

| ID | Tarefa | Status |
|---|---|---|
| 6.1 | Assinatura HMAC sobre string canônica (método, url, timestamp, nonce, digest do body canônico) — `api-hmac.ts` | ✅ |
| 6.2 | Janela de desvio de relógio (`API_HMAC_CLOCK_SKEW_MS`) + cache de nonce em processo (TTL) | ✅ |
| 6.3 | `signing_secret` por chave (migration `0019`, retornado uma vez em criar/rotacionar); `credentialId` já no `AuthContext`; HMAC coexiste com Bearer (camada aditiva) | ✅ |
| 6.4 | Testes: `tests/unit/api-hmac.spec.ts` (válida/sem headers/stale/sem segredo/body adulterado/replay/`shadow` + wiring e2e pelo autenticador) | ✅ |
| 6.5 | `lint`/`test`/`build` verdes | ✅ |

> **Desvios/limitações PR 6:** (a) O digest do body é sobre um JSON canônico
> (chaves ordenadas) — não sobre os bytes crus — evitando captura de raw body no
> Fastify; o cliente replica o mesmo encoding. (b) Cache de nonce é **por
> instância**; replay entre instâncias dentro da janela é mitigado pelo
> timestamp + idempotência de negócio. Antes de `enforce` em produção,
> recomenda-se nonce store compartilhado (DB/Redis) — ver modelo de ameaças.
> (c) Chaves anteriores à `0019` têm `signing_secret` NULL e **não** assinam:
> rotacioná-las antes de `API_HMAC_MODE='enforce'`.

---

## 5. Convenções seguidas

- **Migrations:** próximo número `0020_` (já criadas `0017`–`0019`), snake_case,
  `TIMESTAMPTZ`, enums quando fechado, índices nomeados `idx_*`, FKs explícitas,
  runner idempotente.
- **Serviços/repositórios:** repositório como adapter puro sobre `Sql`/`Database`;
  serviço detém regra de domínio; injeção via `container.ts`.
- **Rotas:** registradas em `src/app/routes.ts`, preHandlers por rota/prefixo;
  validação Zod no handler com `AppError('validation_error', …, 422, flatten)`.
- **Erros:** `AppError` + `toHttpError`; mensagens de auth genéricas e estáveis.
- **Segredos:** nunca persistir/loggar material cru; reaproveitar redaction do
  logger e os helpers de hash/timing-safe existentes.
- **Testes:** Vitest unitário, Fastify `inject`, fakes de repositório, sem banco.
- **Git:** uma branch por fatia; sem commit com lint/build/test vermelhos.

---

## 6. Próxima ação recomendada (rollout revisado — sem usuários reais)

PR 0–6 implementados na branch atual (flags com default `off`). **Como não há
clientes reais**, o estágio `shadow` deixa de ser necessário para *proteger
tráfego*; ele continua útil apenas como ferramenta de validação interna (medir
`would_deny` enquanto seedamos chaves/contratos). O caminho recomendado é ir
direto a `enforce` em staging:

1. Revisar e commitar o trabalho (idealmente em commits lógicos por PR — o histórico
   está numa única branch por decisão do usuário).
2. Aplicar migrations `0017`–`0020` em staging (`pnpm db:migrate`); validar backfill
   de escopos (`0017`) e colunas novas (`0018`/`0019`/`0020`).
3. **Autorização por escopo:** `AUTH_ENFORCEMENT_MODE=enforce` direto. Re-seedar as
   chaves de teste com o conjunto de escopos correto (não há chaves de produção a
   preservar). Opcional: passar por `shadow` por algumas horas só para conferir
   `cashyin_auth_scope_decisions_total` antes de fixar `enforce`.
4. **Canal BFF:** configurar `BFF_SHARED_SECRET` (Secrets Manager) e
   `BFF_AUTH_MODE=enforce`. Rodar com `AUTH_ENFORCEMENT_MODE=enforce` para que o
   ator entre no `AuthContext` (ver D8). Entregar `docs/auth/bff-integration-guide.md`
   ao time do BFF.
5. **Step-up:** `CASHOUT_STEPUP_MODE=enforce` (afeta apenas cash-outs
   `frontend_bff`; `api_direct` é isento). `shadow` opcional para validar o fluxo
   ponta-a-ponta antes.
6. **HMAC (api_direct):** re-seedar/rotacionar as chaves de teste (ganham
   `signing_secret`) e `API_HMAC_MODE=enforce`. O nonce store compartilhado
   (`0020` + `PgApiHmacNonceStore`) já cobre frota multi-instância (D16 resolvido).
   Sem chaves legadas a migrar (D17 deixa de ser problema operacional).
7. **Desvios fechados** (ver Seção 9): D8 (resolução de `AuthContext`
   desacoplada da flag), D5 (`balance:read` dedicado), D7 (RBAC por usuário no
   canal BFF) e D15 (contrato de assinatura `api_direct` documentado) resolvidos.
   **Não há desvios abertos remanescentes.** Leitura admin de tarifas/roteamento
   (4.4) já entregue. Rollout do RBAC: `BFF_RBAC_MODE=enforce` após semear grants
   via `/v1/admin/bff-grants`.

---

## 7. Revisão dos desvios — status e soluções

Revisão de todos os desvios registrados nos PRs 0–6. Classificação:
**Aceito** (decisão de design, sem ação) · **Aberto não-crítico** (não bloqueia, ação futura) ·
**Crítico p/ enforce** (precisa de ação antes de ligar o `enforce` correspondente).

| # | PR | Desvio | Classificação | Avaliação | Solução proposta |
|---|----|--------|---------------|-----------|------------------|
| D1 | 1 | `last_rotated_at` não adicionada | Aceito | Rotação já auditável por `old.revoked_at` + `new.created_at` | Nenhuma |
| D2 | 1 | Escopo extra `pix:cash_out:read` | Aceito | Simetria de leitura; sem impacto | Nenhuma |
| D3 | 1 | `rotate` atômico via `withTransaction` injetado | Aceito | Desacopla de `Database`, testável sem banco | Nenhuma |
| D4 | 2 | Bearer **sempre** imposto; flag só governa escopo | Aceito | `off` = zero mudança de runtime | Nenhuma |
| D5 | 2 | `GET /v1/balance` sem guard de escopo | ✅ **Resolvido** | Escopo `balance:read` criado e imposto na rota | `balance:read` em `AUTH_SCOPES`, incluído em `DEFAULT_CLIENT_API_SCOPES`/`DEFAULT_BFF_SCOPES`, backfill `migrations/0022_*`, guard em `GET /v1/balance` encenado por `AUTH_ENFORCEMENT_MODE`. Branch `feat/balance-read-scope` |
| D6 | 3 | `BFF_AUTH_MODE` sem `shadow` (só `off`/`enforce`) | Aceito | Canal é binário (aceito ou não) | Opcional: adicionar `shadow` se quisermos medir tráfego BFF antes de impor |
| D7 | 3 | Escopos BFF fixos (`DEFAULT_BFF_SCOPES`), sem RBAC por usuário | ✅ **Resolvido** | RBAC por usuário implementado, encenado por flag | Tabela `user_client_grants` (`migrations/0023`), `UserClientGrantService` + `PgUserClientGrantRepository`. Autenticador resolve o grant do ator e **interseciona** com `DEFAULT_BFF_SCOPES` quando `BFF_RBAC_MODE=enforce` (ator sem grant → 403). Admin `/v1/admin/bff-grants` (escopo `clients:manage`). Branch `feat/bff-user-rbac` |
| D8 | 3 | `AuthContext` (com ator) só resolve quando `AUTH_ENFORCEMENT_MODE != off` | ✅ **Resolvido** | Aresta removida: a resolução do contexto foi desacoplada da flag | `buildResolveAuthContext()` agora popula `request.authContext` sempre que há `authPrincipal`; apenas os **guards** de escopo (`buildRequireScope`) seguem sob `AUTH_ENFORCEMENT_MODE`. Branch `feat/auth-context-decouple-resolution` |
| D9 | 4 | Admin deriva `clientId` do principal; sem `:clientId` no path | Aceito | Isolamento forte de tenant | Admin de plataforma (multi-tenant) futuro: escopo `clients:manage` + `clientId` explícito, auditado |
| D10 | 4 | Rotas admin sempre `enforce` | Aceito | Rotas novas, sem contrato legado | Nenhuma |
| D11 | 4 | Leitura admin de planos/tarifas (4.4) adiada | Aberto → planejado | — | Ver **Seção 8** |
| D12 | 5 | Step-up só p/ `frontend_bff`; `api_direct` isento | Aceito | A própria API key já é a credencial forte do canal máquina | Documentado. Opcional: exigir step-up p/ `api_direct` de alto valor (limite configurável) |
| D13 | 5 | Consumo via SQL atômico (não via `context.stepUp` + guard puro) | Aceito | Garante uso único no handler antes do side effect | Nenhuma. Nota: `requireCashoutStepUp`/`requireAnyAmr` permanecem como guards puros (cobertos por teste), sem uso em runtime ainda |
| D14 | 5 | `StepUpProof` não estendido com `proofId`/`kind` extras | Aceito | Campos atuais bastam ao fluxo | Nenhuma |
| D15 | 6 | Digest HMAC sobre JSON canônico (`stableStringify`), não bytes crus | ✅ **Resolvido (documentado)** | Contrato de canonicalização especificado + vetor de teste fixado | Guia do cliente `api_direct` em `docs/auth/api-direct-hmac-signing.md` (headers, string canônica, regras de `stableStringify`, implementações Node/Python, limitações). Vetor travado em `tests/unit/api-hmac.spec.ts`. Raw body por rota (`@fastify/raw-body`) permanece como evolução futura para fidelidade de bytes/corpos não-JSON. Branch `docs/api-direct-hmac-signing` |
| D16 | 6 | Cache de nonce **em memória por instância** | ✅ **Resolvido** | Implementado nonce store compartilhado em Postgres | `migrations/0020_api_hmac_nonces.sql` (`PRIMARY KEY (api_key_id, nonce)` + FK + índice de expiração) + `PgApiHmacNonceStore` (upsert atômico: insere=fresh, conflito não-expirado=replay, conflito expirado=revive). `ApiHmacVerifier` recebe `nonceStore` injetável; `routes.ts` injeta o store Postgres. SQL validado contra Postgres real |
| D17 | 6 | Chaves criadas antes de `0019` têm `signing_secret = NULL` | Operacional | Não conseguem assinar | Rotacionar todas as chaves antes de `enforce` |

**Resumo executivo:** nenhum desvio é crítico com os defaults atuais (todas as flags `off`).
**D16 foi resolvido** (nonce store compartilhado em Postgres), **D11/4.4 foi implementado**
(Seção 8), **D8 foi resolvido** (resolução de `AuthContext` desacoplada da flag, branch
`feat/auth-context-decouple-resolution`) e **D5 foi resolvido** (escopo `balance:read`,
branch `feat/balance-read-scope`), **D7 foi resolvido** (RBAC por usuário no canal BFF,
branch `feat/bff-user-rbac`) e **D15 foi resolvido por documentação** (guia de assinatura
`api_direct` + vetor travado, branch `docs/api-direct-hmac-signing`). **Todos os desvios
D1–D17 estão resolvidos ou aceitos por design** — nenhum item aberto remanescente.

---

## 8. Plano detalhado — item 4.4 (leitura admin da configuração do cliente)

Objetivo: expor, **somente leitura** e **tenant-scoped**, a configuração comercial efetiva
do cliente (tarifas/plano e roteamento de provedor) para consumo pelo Dashboard/BFF, sem
nunca vazar margem, custo de provedor, segredos ou credenciais.

### 8.1 Descobertas (modelo atual)

- **Tarifas (fees do cliente):** `pricing_plans` → `pricing_plan_versions` →
  `client_pricing_assignments` → `pricing_rules`. Regra ativa por
  `(client_id, operation_type, trigger_event)` via
  `PgPricingRuleRepository.findActiveForClient` (`src/modules/pricing/pricing-rule.repository.ts`).
  Triggers padrão: cash-in `cash_in_paid`, cash-out `cash_out_created`.
- **Roteamento:** `client_provider_assignments` via
  `PgProviderAssignmentRepository.findActive` (`src/modules/providers/provider-assignment.repository.ts`)
  — expõe `provider_name`/`operation_type`, **não** expõe `metadata`.
- **Padrão admin a espelhar:** `src/modules/admin/admin.routes.ts` (tenant de
  `request.authContext.clientId`, escopo imposto).

### 8.2 Decisões de design

- **Escopo:** reutilizar `clients:read` (já existe e já está em `DEFAULT_BFF_SCOPES`),
  portanto o Dashboard/BFF já pode ler sem nova concessão.
- **Rotas (sob `/v1/admin`, sempre `enforce`, igual ao PR 4):**
  - `GET /v1/admin/config/fees` → regra de tarifa ativa do **cliente** por operação.
  - `GET /v1/admin/config/routing` → provedor ativo por operação (apenas `provider_name`).
- **NUNCA expor (regra dura):** `provider_cost_rules` (custo/margem da CashYin),
  `fee_assessments`/`subsidy_events` (política interna de subsídio/margem),
  `provider_accounts.metadata`, `client_provider_assignments.metadata`,
  credenciais de provedor (vivem em env), `key_hash`/`signing_secret`.
- **Expor apenas (fee):** `operation_type`, `trigger_event`, `fixed_fee_cents`,
  `variable_fee_bps`, `min_fee_cents`, `max_fee_cents`, `billing_mode`, `rounding_mode`,
  `valid_from`/`valid_to` e (opcional) `plan_name`/`plan_version`.

### 8.3 Tarefas

| ID | Tarefa | Status |
|----|--------|--------|
| 4.4.1 | `ClientConfigService` (read-only) compondo `findActiveForClient` p/ `cash_in`/`cash_out` e `findActive` (routing) | ✅ |
| 4.4.2 | DTO seguro (`ClientFeeConfig`, `ClientRoutingConfig`) com **allow-list** de campos; teste garante ausência de custo/margem/segredo | ✅ |
| 4.4.3 | (Opcional) `PgPricingPlanRepository.findVersionMeta(versionId)` p/ `plan_name`/`version` | ⬜ (não implementado — não necessário p/ a fatia atual) |
| 4.4.4 | Rotas `GET /v1/admin/config/fees` e `/routing` sob `clients:read`, tenant do `authContext` | ✅ |
| 4.4.5 | Wiring em `container.ts` + `registerAdminRoutes` (`admin.routes.ts`) | ✅ |
| 4.4.6 | Testes: retorna fees das 2 operações; 403 sem `clients:read`; isolamento de tenant; **nunca** vaza custo/margem/metadata/segredo | ✅ |
| 4.4.7 | `lint`/`test`/`build` verdes | ✅ |

### 8.4 Riscos / observações

- **Sem migration nova**: ficamos nas leituras ativas (regra de tarifa ativa + assignment
  ativo). Histórico de planos/versões e regras inativas ficam fora do escopo de 4.4
  (4.4.3 fica como melhoria futura, caso o dashboard precise de `plan_name`/`version`).
- **Decisão tomada:** a rota `/v1/admin/config/routing` expõe **apenas** `provider_name`
  por operação (sem `provider_account_id`, `weight`, `version` ou `metadata`), sob
  `clients:read`. `provider_name` (ex.: `bents`) é de baixa sensibilidade e útil ao
  dashboard. Caso o negócio considere o roteamento sensível, mover para `clients:manage`
  (a criar) ou remover a rota — mudança localizada.

**Implementado em:** `src/modules/admin/client-config.service.ts`,
`src/modules/admin/admin.routes.ts` (rotas + guard `clients:read`),
`src/app/container.ts`/`routes.ts` (wiring). Testes:
`tests/unit/client-config-service.spec.ts` + casos em `tests/unit/admin-routes.spec.ts`.

---

## 9. Revisão sob premissa de ausência de usuários reais (sem retrocompatibilidade)

Releitura das decisões conservadoras dos PRs 0–6 à luz de **não haver clientes
reais conectados**. Várias escolhas existiam apenas para preservar
retrocompatibilidade de tráfego de produção; sem esse tráfego, podemos
simplificar. Classificação:
**Manter** (boa prática independente da premissa) · **Simplificar agora**
(ação recomendada nesta fase) · **Dispensável** (deixou de ser problema).

### 9.1 Defaults de flags e estágio `shadow`

- **Antes:** todas as flags com default `off` e rollout `off → shadow → enforce`
  para não negar tráfego legado.
- **Agora (Simplificar):** o default de código permanece `off` (seguro para
  testes/CI), mas o **ambiente de staging/integração sobe direto em `enforce`**
  (`AUTH_ENFORCEMENT_MODE`, `BFF_AUTH_MODE`, `CASHOUT_STEPUP_MODE`,
  `API_HMAC_MODE`). O `shadow` vira ferramenta opcional de validação interna,
  não etapa obrigatória de proteção. Ver **Seção 6**.

### 9.2 Releitura dos desvios da Seção 7

| # | Desvio (resumo) | Sob a nova premissa | Ação |
|---|---|---|---|
| D1 | `last_rotated_at` não adicionada | Manter — auditável por `revoked_at`/`created_at` | Nenhuma |
| D2 | Escopo extra `pix:cash_out:read` | Manter | Nenhuma |
| D3 | `rotate` atômico via `withTransaction` | Manter | Nenhuma |
| D4 | Bearer sempre imposto; flag só governa escopo | Manter (autenticação sempre on é desejável) | Nenhuma |
| D5 | `GET /v1/balance` sem guard de escopo | ✅ **Resolvido** — `balance:read` criado, incluído nos conjuntos default, backfill (`0022`) e guard na rota | Concluído (`feat/balance-read-scope`) |
| D6 | `BFF_AUTH_MODE` sem `shadow` | Manter — canal é binário | Nenhuma |
| D7 | Escopos BFF fixos, sem RBAC por usuário | ✅ **Resolvido** — RBAC por `(ator, tenant)` via `user_client_grants`, interseção com o teto `DEFAULT_BFF_SCOPES`, encenado por `BFF_RBAC_MODE` | Concluído (`feat/bff-user-rbac`) |
| D8 | `AuthContext` só resolve quando `AUTH_ENFORCEMENT_MODE != off` | ✅ **Resolvido** — `resolveAuthContext` agora popula `AuthContext` sempre que há `authPrincipal`; **apenas os guards de escopo** ficam sob a flag. Aresta do BFF removida | Concluído (`feat/auth-context-decouple-resolution`) |
| D9 | Admin deriva `clientId` do principal | Manter — isolamento forte | Admin de plataforma fica para depois |
| D10 | Rotas admin sempre `enforce` | Manter | Nenhuma |
| D11 | 4.4 (leitura admin de tarifas) | Entregue | Nenhuma |
| D12 | Step-up só p/ `frontend_bff` | Manter | Documentado no guia do BFF |
| D13 | Consumo de step-up via SQL atômico | Manter | Nenhuma |
| D14 | `StepUpProof` sem `proofId`/`kind` extras | Manter | Nenhuma |
| D15 | Digest HMAC sobre JSON canônico (não bytes crus) | ✅ **Resolvido (documentado)** — guia `api_direct` + vetor travado; raw body por rota fica como opção futura | Concluído (`docs/api-direct-hmac-signing`) |
| D16 | Nonce store em memória | Resolvido (Postgres) | Nenhuma |
| D17 | Chaves pré-`0019` com `signing_secret` NULL | **Dispensável** — sem chaves reais; basta re-seedar/rotacionar as de teste | Nenhuma (operacional) |

### 9.3 Itens de ação resultantes (fatias propostas)

1. ✅ **`feat/auth-context-decouple-resolution`** — desacoplar resolução de
   `AuthContext` da flag (D8). `buildResolveAuthContext()` perde o parâmetro de
   modo e passa a resolver sempre que há principal; só os guards de escopo
   seguem sob `AUTH_ENFORCEMENT_MODE`. Testes da matriz atualizados. **(Feito.)**
2. ✅ **`feat/balance-read-scope`** (D5) — escopo `balance:read`, inclusão nos
   conjuntos default, guard em `GET /v1/balance`, backfill `migrations/0022_*`.
   **(Feito.)**
3. ✅ **`feat/bff-user-rbac`** (D7) — RBAC por usuário no canal BFF: tabela
   `user_client_grants` (`migrations/0023`), serviço/repos, integração no
   autenticador (`BFF_RBAC_MODE`, interseção com `DEFAULT_BFF_SCOPES`) e admin
   `/v1/admin/bff-grants` sob `clients:manage`. **(Feito.)**

> Estas fatias são **mudanças de comportamento de auth** e devem ir em branches
> próprias (uma por fluxo), separadas da documentação. Este documento e o guia do
> BFF não alteram runtime.
