# Guia de Assinatura de Requisições — canal `api_direct` (HMAC)

**Público-alvo:** integradores de **máquina** (server-to-server) que usam uma
chave de API CashYin (`ck_…`) e precisam assinar as requisições.
**Não se aplica ao BFF** — o canal `frontend_bff` usa o token confiável
(ver `docs/auth/bff-integration-guide.md`), não HMAC.

A assinatura HMAC é uma camada **aditiva** sobre a autenticação Bearer,
governada por `API_HMAC_MODE` (`off` | `shadow` | `enforce`). Em `off` os
headers são ignorados; em `enforce` toda requisição precisa de uma assinatura
válida, fresca e não-replayada.

> **Pré-requisito:** a chave precisa de um `signing_secret`. Ele é retornado
> **uma única vez** ao criar (`POST /v1/admin/api-keys`) ou rotacionar
> (`POST /v1/admin/api-keys/:id/rotate`). Chaves sem `signing_secret` não
> conseguem assinar — rotacione-as antes de habilitar `API_HMAC_MODE=enforce`.

---

## 1. Headers

| Header | Conteúdo |
|---|---|
| `Authorization` | `Bearer ck_<…>` — a chave de API (autenticação). |
| `X-CashYin-Timestamp` | Epoch em **milissegundos** no momento da assinatura. |
| `X-CashYin-Nonce` | Valor único por requisição (proteção contra replay). |
| `X-CashYin-Signature` | `sha256=<hex>` — HMAC-SHA256 da string canônica (Seção 3). |

A janela de validade do timestamp é `API_HMAC_CLOCK_SKEW_MS` (default 300000 ms
= 5 min) para cada lado. Requisições fora da janela são rejeitadas
(`stale_timestamp`). O nonce é "gasto" uma vez dentro da janela `2 × skew`;
reuso → `replayed_nonce`.

---

## 2. Digest canônico do corpo

O corpo é reduzido a um **digest determinístico** para que cliente e servidor
concordem **sem** depender dos bytes crus:

```
bodyDigest = SHA256_hex( canonicalJSON(body) )
```

- Corpo **ausente** (ex.: GET) ⇒ `canonicalJSON` é a **string vazia** `""`, e o
  digest é o SHA-256 da string vazia.
- `canonicalJSON` é um JSON **determinístico** (`stableStringify` em
  `src/modules/auth/api-hmac.ts`):
  - **chaves de objeto ordenadas** recursivamente, em ordem crescente de
    code unit UTF-16 (a ordenação padrão de `Array.prototype.sort` em JS);
  - **sem espaços** insignificantes (sem espaços entre tokens);
  - **strings, números, booleanos e `null`** serializados exatamente como
    `JSON.stringify` do ECMAScript (escapes de string, notação de número);
  - arrays preservam a ordem dos elementos (não são reordenados);
  - cada elemento de array/valor de objeto é canonicalizado recursivamente.

> **Importante:** o servidor canonicaliza o **corpo JSON já parseado** — não os
> bytes crus. Portanto o cliente deve produzir exatamente o mesmo
> `canonicalJSON`. Use a implementação de referência (Seção 5). Corpos
> **não-JSON** não são suportados por este esquema (ver Seção 6).

---

## 3. String canônica e assinatura

A string canônica é a junção por **`\n`** (newline, `U+000A`) de cinco campos,
nesta ordem:

```
METHOD            (maiúsculo, ex.: POST)
URL               (a URL da requisição, ex.: /v1/pix/cash-out)
TIMESTAMP         (mesmo valor de X-CashYin-Timestamp)
NONCE             (mesmo valor de X-CashYin-Nonce)
SHA256(canonicalJSON(body))   (o bodyDigest da Seção 2)
```

A assinatura é:

```
X-CashYin-Signature = "sha256=" + HMAC_SHA256_hex(signing_secret, canonicalString)
```

A comparação no servidor é timing-safe.

### Vetor de exemplo

Para `signing_secret = "signing-secret-value"`, `METHOD=POST`,
`URL=/v1/pix/cash-out`, `TIMESTAMP=1000000`, `NONCE=nonce-1` e corpo:

```json
{ "amount": 7500, "external_ref": "payout-1", "pix": { "key_type": "CNPJ", "key": "60311124000110" } }
```

o `canonicalJSON` é (chaves ordenadas, sem espaços):

```
{"amount":7500,"external_ref":"payout-1","pix":{"key":"60311124000110","key_type":"CNPJ"}}
```

e a string canônica (com `\n` literais) é:

```
POST
/v1/pix/cash-out
1000000
nonce-1
<sha256 do canonicalJSON acima>
```

---

## 4. Modos (`API_HMAC_MODE`)

| Modo | Comportamento |
|---|---|
| `off` | Headers de assinatura ignorados (apenas Bearer autentica). |
| `shadow` | Verifica quando presente; **loga** divergências/ausências; nunca bloqueia. Útil para validar o cliente antes de impor. |
| `enforce` | Exige assinatura válida, fresca e não-replayada; falha → **401 `auth_invalid`** (uniforme, não distingue a causa). |

As razões internas (`missing_headers`, `bad_timestamp`, `stale_timestamp`,
`no_signing_secret`, `bad_signature`, `replayed_nonce`) aparecem apenas em
métrica/log do servidor (`cashyin_api_hmac_decisions_total`), **nunca** no corpo
da resposta.

---

## 5. Implementações de referência

### Node.js

```js
import { createHash, createHmac } from 'node:crypto';

function stableStringify(value) {
  if (value === null || typeof value !== 'object') return JSON.stringify(value) ?? 'null';
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(',')}]`;
  const entries = Object.keys(value)
    .sort()
    .map((k) => `${JSON.stringify(k)}:${stableStringify(value[k])}`);
  return `{${entries.join(',')}}`;
}

function signRequest({ method, url, body, secret }) {
  const timestamp = String(Date.now());
  const nonce = crypto.randomUUID();
  const canonicalJson = body === undefined ? '' : stableStringify(body);
  const bodyDigest = createHash('sha256').update(canonicalJson).digest('hex');
  const canonical = [method.toUpperCase(), url, timestamp, nonce, bodyDigest].join('\n');
  const signature = 'sha256=' + createHmac('sha256', secret).update(canonical).digest('hex');
  return {
    'X-CashYin-Timestamp': timestamp,
    'X-CashYin-Nonce': nonce,
    'X-CashYin-Signature': signature
  };
}
```

### Python

```python
import hashlib, hmac, json, time, uuid

def stable_stringify(value) -> str:
    # separators sem espaços + chaves ordenadas; ensure_ascii=False para UTF-8.
    # NB: replica JSON.stringify do JS para tipos primitivos comuns.
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)

def sign_request(method: str, url: str, body, secret: str) -> dict:
    timestamp = str(int(time.time() * 1000))
    nonce = str(uuid.uuid4())
    canonical_json = "" if body is None else stable_stringify(body)
    body_digest = hashlib.sha256(canonical_json.encode("utf-8")).hexdigest()
    canonical = "\n".join([method.upper(), url, timestamp, nonce, body_digest])
    signature = "sha256=" + hmac.new(secret.encode("utf-8"), canonical.encode("utf-8"), hashlib.sha256).hexdigest()
    return {
        "X-CashYin-Timestamp": timestamp,
        "X-CashYin-Nonce": nonce,
        "X-CashYin-Signature": signature,
    }
```

> **Atenção à paridade de encoding entre linguagens.** A ordenação de chaves e o
> escaping/numeração de `JSON.stringify` (JS) e `json.dumps` (Python) coincidem
> para os payloads desta API (ASCII, números inteiros em centavos, strings
> simples). Se o seu payload usar números de ponto flutuante, unicode fora de
> ASCII ou inteiros muito grandes, **valide o `canonicalJSON` byte-a-byte**
> contra a referência Node antes de ir para produção.

---

## 6. Limitações e alternativa (raw body)

- O digest é sobre o **JSON canônico**, não sobre os bytes crus do corpo. Isso
  evita acoplar o servidor à captura de raw body (e preserva o parser JSON
  seguro do Fastify nas rotas financeiras), mas exige que o cliente replique a
  canonicalização. **Corpos não-JSON não são suportados.**
- Se no futuro for necessária **fidelidade de bytes** (ou suporte a corpos
  não-JSON), a evolução prevista é capturar o raw body por rota (ex.:
  `@fastify/raw-body` com `config: { rawBody: true }`) e assinar sobre os bytes
  crus — uma mudança localizada no `ApiHmacVerifier` e no parser, sem afetar o
  canal BFF. Ver desvio **D15** em `docs/auth/implementation-plan.md`.

---

## 7. Checklist do integrador `api_direct`

- [ ] Guardar o `signing_secret` retornado na criação/rotação da chave.
- [ ] Para cada requisição, gerar `X-CashYin-Timestamp` (ms), `X-CashYin-Nonce`
      (único) e `X-CashYin-Signature` (Seção 3).
- [ ] Garantir relógio sincronizado (NTP) dentro de `API_HMAC_CLOCK_SKEW_MS`.
- [ ] Não reutilizar nonce; usar um valor aleatório/sequencial único por request.
- [ ] Validar o `canonicalJSON` contra a referência Node se usar outra linguagem.
- [ ] Tratar `401 auth_invalid` como falha de autenticação genérica (não parsear
      a mensagem; a causa fica só nos logs do servidor).
