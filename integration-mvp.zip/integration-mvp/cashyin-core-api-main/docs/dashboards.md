# Dashboards de Observabilidade — CashYin Core API

> Consulte [`docs/observability.md`](./observability.md) para o catálogo completo de métricas, configuração de ambiente e alertas.

---

## Índice de painéis

1. [API — visão geral por rota](#1-api--visão-geral-por-rota)
2. [Cash-in — QR Code (fluxo crítico)](#2-cash-in--qr-code-fluxo-crítico)
3. [Provider Bents — HTTP outbound](#3-provider-bents--http-outbound)
4. [Worker — processamento de webhook de provider](#4-worker--processamento-de-webhook-de-provider)
5. [Filas internas — webhook\_events e outbox\_events](#5-filas-internas--webhook_events-e-outbox_events)
6. [Dispatcher — webhook ao cliente](#6-dispatcher--webhook-ao-cliente)
7. [pix\_charge.paid — latência ponta a ponta](#7-pix_chargepaid--latência-ponta-a-ponta)

---

## 1. API — visão geral por rota

**Objetivo:** monitorar saúde geral da API — RPS, latência e taxa de erro por rota.

### Painéis sugeridos

#### RPS por rota
```promql
sum by (route, method)(
  rate(cashyin_http_requests_total[1m])
)
```

#### Taxa de erro HTTP 5xx (global)
```promql
sum(rate(cashyin_http_requests_total{status_code=~"5.."}[5m]))
/
sum(rate(cashyin_http_requests_total[5m]))
```

#### P95 de latência por rota
```promql
histogram_quantile(0.95,
  sum by (route, le)(
    rate(cashyin_http_request_duration_seconds_bucket[5m])
  )
)
```

#### P99 de latência por rota
```promql
histogram_quantile(0.99,
  sum by (route, le)(
    rate(cashyin_http_request_duration_seconds_bucket[5m])
  )
)
```

#### Distribuição de status codes (heatmap ou pie chart)
```promql
sum by (status_code)(
  rate(cashyin_http_requests_total[5m])
)
```

### Sinais de alerta

| Sinal | Threshold | Severidade |
|---|---|---|
| P99 de qualquer rota > 3s | 3s | warning |
| Taxa 5xx global > 1% | 1% | critical |
| P95 de `/health` ou `/ready` > 100ms | 100ms | warning |

### Interpretação

- **RPS baixo + latência alta**: provável problema de cold start ou pool de DB esgotado
- **Alta taxa 5xx sem aumento de RPS**: possível erro de configuração recém-deployada
- **Latência alta apenas em rotas autenticadas (`/v1/*`)**: verificar tempo de validação do API key no banco

---

## 2. Cash-in — QR Code (fluxo crítico)

**Objetivo:** monitorar o endpoint mais crítico do sistema — `POST /v1/pix/cash-in/qrcode`.

### Painéis sugeridos

#### RPS do QR Code
```promql
rate(cashyin_http_requests_total{route="/v1/pix/cash-in/qrcode",method="POST"}[1m])
```

#### P95 de latência do QR Code
```promql
histogram_quantile(0.95,
  rate(cashyin_http_request_duration_seconds_bucket{
    route="/v1/pix/cash-in/qrcode",
    method="POST"
  }[5m])
)
```

#### P99 de latência do QR Code
```promql
histogram_quantile(0.99,
  rate(cashyin_http_request_duration_seconds_bucket{
    route="/v1/pix/cash-in/qrcode",
    method="POST"
  }[5m])
)
```

#### Taxa de sucesso vs. erro (por result)
```promql
sum by (result)(
  rate(cashyin_qrcode_create_total[5m])
)
```

#### P95 de duração interna do QR Code (inclui chamada ao provider)
```promql
histogram_quantile(0.95,
  rate(cashyin_qrcode_create_duration_seconds_bucket[5m])
)
```

#### Taxa de dedup hit (retentativas com mesmo external_ref)
```promql
rate(cashyin_qrcode_create_total{result="dedup_hit"}[5m])
/
rate(cashyin_qrcode_create_total[5m])
```

### Sinais de alerta

| Sinal | Threshold | Severidade |
|---|---|---|
| P95 > 1s | 1s | warning |
| P99 > 3s | 3s | critical |
| Taxa de erro > 1% | 1% | critical |
| Taxa de dedup_hit > 20% | 20% | warning (clientes com retry agressivo) |

### Interpretação

- **P95 subindo com provider latência estável**: problema no DB ou no pool de conexões
- **P95 acompanhando a latência do provider**: gargalo na Bents — verificar painel 3
- **Alto dedup_hit**: clientes com timeout muito curto estão retentando antes de receber resposta — investigar latência de rede do cliente

---

## 3. Provider Bents — HTTP outbound

**Objetivo:** monitorar chamadas HTTP da CashYin para a API da Bents.

### Painéis sugeridos

#### RPS de chamadas ao provider
```promql
sum by (path, method)(
  rate(cashyin_provider_http_requests_total{provider="bents"}[1m])
)
```

#### Taxa de erro por path
```promql
sum by (path)(
  rate(cashyin_provider_http_requests_total{provider="bents",result="failure"}[5m])
)
/
sum by (path)(
  rate(cashyin_provider_http_requests_total{provider="bents"}[5m])
)
```

#### P95 de latência por path
```promql
histogram_quantile(0.95,
  sum by (path, le)(
    rate(cashyin_provider_http_request_duration_seconds_bucket{provider="bents"}[5m])
  )
)
```

#### Distribuição de status codes do provider
```promql
sum by (response_status)(
  rate(cashyin_provider_http_requests_total{provider="bents"}[5m])
)
```

#### Distribuição de categorias de erro
```promql
sum by (error_category)(
  rate(cashyin_provider_http_requests_total{provider="bents",result="failure"}[5m])
)
```

#### Timeout configurado (gauge de referência)
```promql
cashyin_provider_http_timeout_ms{provider="bents"}
```

### Sinais de alerta

| Sinal | Threshold | Severidade |
|---|---|---|
| P95 > 800ms | 800ms | warning |
| P99 > 2s | 2s | critical |
| Taxa de erro > 5% | 5% | critical |
| `response_status` = `not_received` frequente | > 1% | critical (timeout/rede) |

### Interpretação

- **`error_category="timeout"` crescendo**: Bents lenta ou limite de conexões da CashYin esgotado
- **`error_category="client_error"` crescendo**: possível mudança de API da Bents ou bug no payload enviado
- **`error_category="server_error"` da Bents**: incidente no provider externo — acionar SLA

---

## 4. Worker — processamento de webhook de provider

**Objetivo:** monitorar o Worker-1 (processador de `webhook_events`).

### Painéis sugeridos

#### Throughput do worker (ticks processados por segundo)
```promql
sum by (outcome)(
  rate(cashyin_provider_webhook_processing_total[1m])
)
```

#### Taxa de DLQ
```promql
rate(cashyin_provider_webhook_processing_total{outcome="dlq"}[5m])
```

#### P95 de duração de cada tick do worker
```promql
histogram_quantile(0.95,
  rate(cashyin_provider_webhook_processing_duration_seconds_bucket[5m])
)
```

#### P95 de latência de claim (delay entre webhook recebido e processado)
```promql
histogram_quantile(0.95,
  rate(cashyin_provider_webhook_claim_latency_seconds_bucket[5m])
)
```

#### P99 de latência de claim
```promql
histogram_quantile(0.99,
  rate(cashyin_provider_webhook_claim_latency_seconds_bucket[5m])
)
```

### Sinais de alerta

| Sinal | Threshold | Severidade |
|---|---|---|
| P95 de claim latency > 5s | 5s | warning |
| P99 de claim latency > 30s | 30s | critical |
| `outcome="dlq"` rate > 0 | qualquer | critical |
| `outcome="retry"` rate persistentemente alto | > 10% dos ticks | warning |

### Interpretação

- **Alta claim latency com worker ativo**: workers insuficientes para o volume — escalar réplicas ECS
- **Alta claim latency com worker inativo**: verificar se o worker crashed (CloudWatch logs)
- **Alto retry sem DLQ**: erros transientes de DB — verificar pool de conexões e CPU do RDS
- **DLQ crescendo**: bug sistêmico no processamento — inspecionar os eventos na DLQ manualmente

---

## 5. Filas internas — webhook\_events e outbox\_events

**Objetivo:** monitorar a saúde das filas de processamento assíncrono.

### Painéis sugeridos

#### Profundidade da fila de webhook_events por status
```promql
sum by (provider, operation_type, processing_status)(
  cashyin_provider_webhook_queue_events
)
```

#### Idade do evento mais antigo na fila de webhook_events
```promql
max by (provider, operation_type, processing_status)(
  cashyin_provider_webhook_queue_oldest_age_seconds
)
```

#### Profundidade da fila de outbox_events por event_type e status
```promql
sum by (event_type, status)(
  cashyin_outbox_queue_events
)
```

#### Idade do evento mais antigo na fila de outbox (por event_type)
```promql
max by (event_type, status)(
  cashyin_outbox_queue_oldest_age_seconds
)
```

#### Focado em pix.cash_in.paid no outbox
```promql
cashyin_outbox_queue_oldest_age_seconds{event_type="pix.cash_in.paid"}
```

### Sinais de alerta

| Sinal | Threshold | Severidade |
|---|---|---|
| `webhook_events` pending > 100 por 5m | 100 | warning |
| `webhook_events` oldest age > 60s | 60s | critical |
| `outbox_events` pending > 200 por 5m | 200 | warning |
| `outbox_events{event_type="pix.cash_in.paid"}` oldest age > 30s | 30s | critical |
| `outbox_events{status="dlq"}` > 0 | qualquer | critical |

### Interpretação

- **Fila crescendo, oldest age crescendo**: workers parados ou sobrecarregados
- **Fila crescendo, oldest age estável**: throughput do worker abaixo da taxa de ingresso — escalar
- **Fila zerada, mas sem deliveries de cliente**: problema no endpoint do cliente (timeout/5xx)

---

## 6. Dispatcher — webhook ao cliente

**Objetivo:** monitorar o Worker-2 (dispatcher de `outbox_events` para o endpoint HTTP do cliente).

### Painéis sugeridos

#### Throughput de entregas (por result e event_type)
```promql
sum by (event_type, result)(
  rate(cashyin_client_webhook_delivery_total[1m])
)
```

#### Taxa de falha de entrega por event_type
```promql
rate(cashyin_client_webhook_delivery_total{result="failure"}[5m])
/
rate(cashyin_client_webhook_delivery_total[5m])
```

#### P95 de latência de entrega HTTP ao cliente
```promql
histogram_quantile(0.95,
  sum by (event_type, le)(
    rate(cashyin_client_webhook_delivery_duration_seconds_bucket[5m])
  )
)
```

#### Timeout configurado por event_type
```promql
cashyin_client_webhook_timeout_ms
```

#### Proporção de timeouts (latência >= timeout configurado)
```promql
# Proxy: deliveries com latência no bucket [2.5, +Inf] para pix.cash_in.paid
histogram_quantile(0.99,
  rate(cashyin_client_webhook_delivery_duration_seconds_bucket{
    event_type="pix.cash_in.paid"
  }[5m])
)
```

### Sinais de alerta

| Sinal | Threshold | Severidade |
|---|---|---|
| Taxa de falha > 10% | 10% | warning |
| P95 `pix.cash_in.paid` > `CLIENT_WEBHOOK_CRITICAL_TIMEOUT_MS` | > 2.5s | warning |
| P99 de qualquer event_type > `CLIENT_WEBHOOK_TIMEOUT_MS` | > 5s | critical |
| `cashyin_outbox_queue_events{status="dlq"}` > 0 | qualquer | critical |

### Interpretação

- **Alta taxa de falha em `pix.cash_in.paid`**: endpoint do cliente lento ou com timeout muito baixo — contatar o cliente
- **Alta taxa de falha geral**: problema de rede entre CashYin e o cliente, ou mudança de URL/autenticação do endpoint do cliente
- **P95 de entrega próximo ao timeout**: cliente no limite — renegociar timeout ou investigar infraestrutura do cliente

---

## 7. pix\_charge.paid — latência ponta a ponta

**Objetivo:** medir o tempo total entre o pagamento Pix ser confirmado pela Bents e o cliente receber o evento `pix.cash_in.paid`.

Este é o SLA mais crítico do produto. A latência total é composta por:

```
T_total = T_ingresso + T_claim_worker1 + T_processamento + T_claim_worker2 + T_entrega_cliente
```

### Composição aproximada com as métricas disponíveis

| Segmento | Métrica proxy |
|---|---|
| T_ingresso | `webhook_events` oldest age quando status=pending |
| T_claim_worker1 | `cashyin_provider_webhook_claim_latency_seconds` |
| T_processamento | `cashyin_cashin_paid_processing_duration_seconds` |
| T_claim_worker2 | `outbox_events` oldest age quando event_type=pix.cash_in.paid |
| T_entrega_cliente | `cashyin_client_webhook_delivery_duration_seconds{event_type="pix.cash_in.paid"}` |

### Queries para o painel

#### Latência P95 do processamento de pix.cash_in.paid
```promql
histogram_quantile(0.95,
  rate(cashyin_cashin_paid_processing_duration_seconds_bucket[5m])
)
```

#### Latência P95 de claim do webhook de provider
```promql
histogram_quantile(0.95,
  rate(cashyin_provider_webhook_claim_latency_seconds_bucket[5m])
)
```

#### Latência P95 de entrega do webhook ao cliente
```promql
histogram_quantile(0.95,
  rate(cashyin_client_webhook_delivery_duration_seconds_bucket{
    event_type="pix.cash_in.paid"
  }[5m])
)
```

#### Idade atual do evento mais antigo esperando entrega ao cliente
```promql
cashyin_outbox_queue_oldest_age_seconds{
  event_type="pix.cash_in.paid",
  status=~"pending|processing"
}
```

#### Taxa de processamento com sucesso
```promql
rate(cashyin_cashin_paid_processing_total{result="updated"}[5m])
```

### Sinais de alerta

| Sinal | Threshold | Severidade |
|---|---|---|
| P95 processamento > 500ms | 500ms | warning |
| P95 claim worker1 > 5s | 5s | warning |
| P95 entrega ao cliente > 2.5s | 2.5s | warning |
| outbox oldest age `pix.cash_in.paid` > 30s | 30s | critical |
| noop_charge_not_found rate > 0.5% | 0.5% | warning (webhooks órfãos) |

### Meta operacional recomendada

Para pré-produção/produção de alto volume:

| Segmento | SLO |
|---|---|
| T_claim_worker1 (P95) | < 1s |
| T_processamento (P95) | < 300ms |
| T_claim_worker2 (P95) | < 2s |
| T_entrega_cliente (P95) | < 2.5s |
| **T_total estimado (P95)** | **< 6s** |
