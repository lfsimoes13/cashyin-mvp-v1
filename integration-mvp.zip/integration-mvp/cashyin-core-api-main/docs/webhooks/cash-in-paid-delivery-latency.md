# Low-latency delivery of `pix.cash_in.paid` (architecture + metrics)

Goal: deliver the public `pix.cash_in.paid` webhook to the client with a
**first-attempt start latency of 100–200 ms** whenever possible, measured from
the moment the cash-in is persisted as `paid` (and the outbox row is created)
until the dispatcher begins the first HTTP POST to the client endpoint.

This is achieved without weakening the transactional-outbox guarantees: the
HTTP POST never happens inside the financial transaction, and no DB locks are
held while calling the client.

## Latency segments and ownership

```mermaid
flowchart LR
  prov["Provider (Bents/Fyhub)"] -->|"external, NOT in target"| ingress["webhook_events"]
  ingress --> paid["tx: persist paid + ledger + outbox INSERT"]
  paid -->|outbox_creation_latency| ob["outbox_events.created_at"]
  ob -->|"first_attempt_start_latency (TARGET 100-200ms, CashYin-owned)"| poststart["first HTTP POST start"]
  poststart -->|"client response time (NOT owned)"| postend["first response / timeout"]
  postend -.->|success_latency| ok["delivered"]
```

| Segment | Metric | Owner | In the 100-200 ms target? |
|---|---|---|---|
| Provider → CashYin | `cashyin_provider_webhook_claim_latency_seconds` | Provider (external) | No (explicitly excluded) |
| Persist `paid` → outbox row | `cashyin_cash_in_paid_outbox_creation_latency_seconds` | CashYin (intra-tx) | Contributes (~0 by design) |
| `outbox_created_at` → POST start | `cashyin_client_webhook_first_attempt_start_latency_seconds` | **CashYin** | **Yes — this is the SLO** |
| POST start → first response | `cashyin_client_webhook_delivery_duration_seconds` | Client endpoint | Measured, not owned |
| `outbox_created_at` → first response | `cashyin_client_webhook_first_attempt_total_latency_seconds` | CashYin + client | Measured, not owned |
| `outbox_created_at` → delivered | `cashyin_client_webhook_success_latency_seconds` | CashYin + client + retries | Measured, not owned |

### Part-1 timestamps and calculations

| Concept | Source |
|---|---|
| `paid_persisted_at` | intra-tx; proven ~0 via the outbox-creation metric (Postgres `now()` is constant within a transaction, so a DB diff is 0 by construction) |
| `outbox_created_at` | `outbox_events.created_at` |
| `delivery_first_attempt_started_at` | `client_webhook_deliveries.first_attempt_started_at` (migration 0014) |
| `delivery_first_attempt_finished_at` | `client_webhook_deliveries.first_attempt_finished_at` (migration 0014) |
| `delivery_success_at` | `client_webhook_deliveries.delivered_at` |

```text
outbox_creation_latency_ms    = outbox_created_at              - paid_persisted_at
first_attempt_start_latency_ms = delivery_first_attempt_started_at  - outbox_created_at
first_attempt_total_latency_ms = delivery_first_attempt_finished_at - outbox_created_at
success_latency_ms             = delivery_success_at               - outbox_created_at
```

The two `first_attempt_*` columns are **internal observability only** — never
part of the public webhook payload. They are written with `COALESCE` semantics
so only the *first* attempt's instants are persisted (retries do not overwrite).
The test-only inspector `scripts/e2e/fyhub/paid-pipeline-timing.ts` surfaces all
four latencies for a single charge when given a `DATABASE_URL`.

## Architecture levers (what keeps it fast)

1. **Transactional outbox + `LISTEN/NOTIFY` wake-up (B3).** The outbox INSERT
   fires `pg_notify('cashyin_outbox_events_ready')` on commit
   (`migrations/0005_pg_notify_triggers.sql`); `PgNotifyWatcher` nudges the
   dispatcher loop in ~microseconds instead of waiting for the idle poll.
   **Requirement:** keep `WORKER_ENABLE_DB_NOTIFY=true` (default) in
   staging/prod. Without it, the loop falls back to `WORKER_IDLE_INTERVAL_MS`
   polling (200 ms–5 s), which blows the latency target.
2. **Outbox priority.** `pix.cash_in.paid` is enqueued at priority `10`
   (`src/modules/outbox/outbox-priority.ts`); the claim orders by
   `priority ASC, available_at ASC, created_at ASC`, so a burst of cash-out or
   terminal cash-in events cannot queue ahead of a paid event.
3. **Throttled stale-reaper (B2).** The dispatcher's stale-row reaper now runs
   at most once per `OUTBOX_REAPER_MIN_INTERVAL_MS` (default 30 s) instead of
   on every tick, removing a DB round-trip from the latency-critical claim path.
   Recovery is unaffected (a crashed row is still reclaimed within the interval
   plus the 5-minute stale threshold).
4. **HTTP keep-alive pool (B4).** `UndiciHttpClient` uses a dedicated keep-alive
   `Agent` so TLS connections to client endpoints are reused, removing the
   handshake from the first-attempt path. Tunable via
   `CLIENT_WEBHOOK_KEEPALIVE_TIMEOUT_MS`,
   `CLIENT_WEBHOOK_KEEPALIVE_MAX_TIMEOUT_MS`,
   `CLIENT_WEBHOOK_KEEPALIVE_CONNECTIONS`.
5. **Tighter first-attempt timeout.** `pix.cash_in.paid` uses
   `CLIENT_WEBHOOK_CASHIN_PAID_TIMEOUT_MS` (default 3 s) so a slow client does
   not pin the worker; retries pick it up.

## Dispatcher partitioning (B1) — default OFF

The dispatcher loop is single-threaded by design (one in-flight tick; horizontal
scale = more processes, each claiming with `FOR UPDATE SKIP LOCKED`). A single
slow non-critical delivery (e.g. a cash-out POST up to its timeout) can
head-of-line block a `pix.cash_in.paid`. To eliminate that, the dispatcher claim
accepts an **optional** `event_type` partition, mirroring the provider-webhook
worker partitioning (see
[../provider-integration/webhook-worker-partitioning.md](../provider-integration/webhook-worker-partitioning.md)).

When **no** `DISPATCHER_WORKER_*` var is set, the dispatcher drains the whole
queue exactly as before — full back-compat. **No new dispatcher entrypoint or
ECS topology is enabled by default.**

| Var | Meaning |
|---|---|
| `DISPATCHER_WORKER_EVENT_TYPES` | Comma list of `event_type` to include (e.g. `pix.cash_in.paid`). |
| `DISPATCHER_WORKER_EXCLUDE_EVENT_TYPES` | Comma list of `event_type` to exclude (e.g. everything except paid). |
| `OUTBOX_REAPER_MIN_INTERVAL_MS` | Min gap between stale-reaper sweeps (default 30 000). |

### Recommended worker matrix (when isolation is enabled)

| Worker | Env | Purpose |
|---|---|---|
| `dispatch-cashin-paid` | `DISPATCHER_WORKER_EVENT_TYPES=pix.cash_in.paid` | Dedicated critical path; never blocked by slow deliveries. |
| `dispatch-default` | `DISPATCHER_WORKER_EXCLUDE_EVENT_TYPES=pix.cash_in.paid` | Everything else (terminal cash-in, cash-out). |

Both run the **same** image/entrypoint
(`dist/main-webhook-dispatcher-worker.js`); only the env overlay differs. The
`FOR UPDATE SKIP LOCKED` claim guarantees the two partitions never contend.

### Recommended ECS topology (NOT applied — operational change)

The application code is live and back-compatible: today's single
`webhook-dispatcher` service keeps draining everything. To realise the
isolation, split that one ECS service into two services off the **same task
definition family**, each with a distinct `environment` overlay and
`desired_count`, e.g. in `infra/terraform/modules/ecs/workers.tf`:

```hcl
variable "webhook_dispatcher_partitions" {
  type = map(object({
    desired_count = number
    environment   = list(object({ name = string, value = string }))
  }))
  default = {
    "cashin-paid" = {
      desired_count = 2
      environment = [
        { name = "DISPATCHER_WORKER_EVENT_TYPES", value = "pix.cash_in.paid" },
      ]
    }
    "default" = {
      desired_count = 1
      environment = [
        { name = "DISPATCHER_WORKER_EXCLUDE_EVENT_TYPES", value = "pix.cash_in.paid" },
      ]
    }
  }
}
```

Use `for_each = var.webhook_dispatcher_partitions` on the dispatcher task
definition and service, append `each.value.environment`, set
`desired_count = each.value.desired_count`, and suffix the family/service name
with `each.key`. The command stays
`["node", "dist/main-webhook-dispatcher-worker.js"]` for every partition.

Scaling guidance: scale `cashin-paid` aggressively on
`first_attempt_start_latency` P95 and outbox queue age; `default` can tolerate
backlog.

> This split is deliberately deferred to a separate infra change so the
> application PR stays small and safe for the current production-test
> environment. Until it lands, optionally set the `DISPATCHER_WORKER_*` vars on
> the existing single service to validate the filter in staging.

## Follow-ups / known gaps

- **ECS dispatcher split (B1).** The dedicated `dispatch-cashin-paid` service is
  documented above but not applied; it needs a separate Terraform change to
  realise the isolation in production.
- **Cash-out internal outbox naming.** The active cash-out flow still enqueues
  internal outbox `event_type` values as `cashout.*` (`cashout.completed`,
  `cashout.failed`, `cashout.returned`). The desired naming standard, aligned
  with the public contract, is `pix.cash_out.*`. Note the public webhook
  clients already receive `pix.cash_out.completed` / `pix.cash_out.failed` /
  `pix.cash_out.returned` (the dispatcher maps `cashout.* -> pix.cash_out.*` in
  the envelope `event` field) — only the internal `outbox_events.event_type`
  token still uses `cashout.*`. Renaming it (with a backfill migration mirroring
  `0013`) is out of scope here and tracked as a separate flow.
- **Inspector outbox-creation latency.** `paid-pipeline-timing.ts` computes
  `outbox_creation_latency_ms` from `charge.paid_at` (provider business
  timestamp), which is a DB approximation; the precise figure is the Prometheus
  `cashyin_cash_in_paid_outbox_creation_latency_seconds` histogram.
