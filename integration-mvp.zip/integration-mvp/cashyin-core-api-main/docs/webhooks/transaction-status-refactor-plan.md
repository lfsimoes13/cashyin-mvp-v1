# Plano Técnico de Refatoração de Webhooks e Status Transacionais

**Autor:** Manus AI  
**Data:** 2026-05-23  
**Escopo:** CashYin Core API, eventos PIX Cash-In e PIX Cash-Out enviados a clientes, normalização de status transacionais e preparação para implementação segura por outro agente.

## 1. Resumo executivo

O sistema atual já possui uma base importante para auditoria, pois persiste webhooks de provedor em `webhook_events`, usa `outbox_events` para eventos assíncronos e tem tabelas transacionais separadas para `pix_charges` e `cashouts`. Entretanto, a implementação ainda não entrega um contrato cliente-final robusto para webhooks Cash-In/Cash-Out, e os nomes de status hoje estão misturados entre conceitos internos, nomes legados e termos de provedor. O principal risco é que **o mesmo estado financeiro seja representado por nomes diferentes** como `paid`, `confirmed`, `completed`, `refunded`, `reversed` ou `returned`, o que aumenta a chance de erro operacional, divergência contábil, integração incorreta por clientes e falhas de reconciliação.

A recomendação é introduzir uma camada canônica de domínio com dois modelos de status separados: **Cash-In** com `pending`, `paid`, `expired`, `cancelled` e `failed`; e **Cash-Out** com `processing`, `completed`, `failed` e `returned`. Os webhooks enviados aos clientes devem seguir o padrão `pix.cash_in.*` e `pix.cash_out.*`, com payload versionado, identificador único de evento, timestamp UTC, tipo de transação em `data.type`, status canônico em `data.status` e valores monetários determinísticos.

> A documentação BRZip usada como referência descreve webhooks como notificações HTTP POST em tempo real para evitar polling, com confirmação HTTP 200 e possibilidade de retry com backoff exponencial. Ela também apresenta eventos PIX Cash-In no padrão `pix.cash_in.*` e eventos PIX Cash-Out no padrão `pix.cash_out.*`.[1] [2]

## 2. Estado atual observado no repositório

A análise do repositório mostra que a estrutura atual está parcialmente preparada, mas ainda incompleta para o envio confiável de webhooks normalizados a clientes. O recebimento de webhook de provedor valida assinatura, grava o payload bruto e deduplica por identificador do provedor; porém, as reações de domínio, como transição de status, lançamento contábil, atualização transacional e despacho de webhook de cliente, ainda são explicitamente tratadas como fases futuras.

| Área | Estado atual | Risco técnico |
|---|---|---|
| Status de banco | `transaction_status` é um enum compartilhado com `created`, `pending`, `processing`, `confirmed`, `failed`, `cancelled`, `expired`, `reversed`. | O mesmo enum atende Cash-In e Cash-Out, forçando estados que não pertencem naturalmente a cada fluxo. |
| Cash-In | O provedor retorna `paid`, mas o serviço persiste `confirmed`. | Clientes e operadores podem ver `confirmed` enquanto a regra de negócio desejada fala em `paid`. |
| Cash-Out | O provedor retorna `confirmed` e `refunded`, mas o serviço persiste `confirmed` e `reversed`. | A nomenclatura desejada é `completed` e `returned`, portanto há divergência semântica. |
| Eventos internos | Criação de cobrança emite `pix.cash_in.created`; criação de cash-out emite `pix.cash_out.initiated` (tokens internos já normalizados; rows legados `cashout.*` continuam sendo drenados — ver migration 0015). | Nomes agora alinhados ao padrão público `pix.cash_in.*` e `pix.cash_out.*`. |
| Webhooks de provedor | `webhook_events` grava payload bruto, tipo e ID de evento. | Bom para auditoria, mas ainda não normaliza evento nem atualiza estado transacional. |
| Webhooks a clientes | Worker `webhook-delivery` está como placeholder. | Não há contrato real de entrega, retry, assinatura, observabilidade ou idempotência para cliente. |
| Outbox | `outbox_events` permite gravar eventos transacionais atômicos. | Falta tipagem dos eventos, payload builder e consumidor confiável. |

A principal decisão arquitetural é separar três camadas que hoje aparecem misturadas. A primeira é a camada de **provedor**, que pode usar nomes como `PAID`, `SUCCESS`, `CONFIRMED`, `REFUNDED` ou outros. A segunda é a camada de **domínio CashYin**, que deve usar apenas os status canônicos definidos neste documento. A terceira é a camada de **evento público**, que deve ter nomes estáveis, versionados e independentes do provedor.

## 3. Objetivos e não objetivos

O objetivo da refatoração é garantir que todo evento enviado ao cliente seja previsível, auditável e semanticamente correto. Isso exige que uma transação Cash-In nunca exponha status de Cash-Out e que uma transação Cash-Out nunca exponha status de Cash-In. Também exige que o payload público não dependa de campos brutos de provedores, porque a plataforma já tem arquitetura multi-provider e precisa preservar estabilidade mesmo quando trocar Bents por outro provedor.

| Categoria | Definição |
|---|---|
| Objetivo principal | Normalizar status e eventos públicos para `cash_in` e `cash_out`, com padrão `pix.cash_in.*` e `pix.cash_out.*`. |
| Objetivo operacional | Criar pipeline confiável de ingestão, normalização, persistência, outbox, entrega, retry, assinatura e auditoria. |
| Objetivo financeiro | Evitar prejuízos por dupla contabilização, transições inválidas, liquidação incorreta ou interpretação ambígua de status. |
| Não objetivo | Expor ao cliente detalhes internos de worker, endpoint interno de provedor ou mapeamento específico do Bents. |
| Não objetivo | Fazer analytics complexas no Core API. Métricas e relatórios pesados devem ser derivados de eventos e tabelas auditáveis, sem impactar baixa latência do core transacional. |

## 4. Modelo canônico de status

A recomendação é abandonar o uso de um único enum transacional compartilhado para os dois fluxos. Cash-In e Cash-Out têm ciclos de vida diferentes, eventos terminais diferentes e impactos financeiros distintos. A separação evita combinações inválidas, simplifica validação de API, reduz bugs e facilita manutenção.

### 4.1 Status canônicos de Cash-In

| Status | Significado | Terminal | Evento público recomendado | Observação financeira |
|---|---|---:|---|---|
| `pending` | Cobrança criada, QR Code gerado e aguardando pagamento. | Não | `pix.cash_in.received` | Não creditar saldo final nem reconhecer tarifa definitiva se a tarifa depende de pagamento. |
| `paid` | Pagamento recebido e confirmado. | Sim | `pix.cash_in.paid` | Creditar saldo, registrar `paid_at`, `e2e_id`, pagador e eventos de tarifa. |
| `expired` | Cobrança expirou sem pagamento. | Sim | `pix.cash_in.expired` | Não creditar saldo; cancelar estimativas dependentes de pagamento. |
| `cancelled` | Cobrança foi cancelada antes do pagamento. | Sim | `pix.cash_in.cancelled` | Não creditar saldo; preservar auditoria do motivo. |
| `failed` | Falha técnica ou operacional na criação/processamento da cobrança. | Sim | `pix.cash_in.failed` | Não creditar saldo; exige motivo e rastreabilidade. |

A referência BRZip lista `pix.cash_in.confirmed` para pagamento recebido e fundos creditados, e `pix.cash_in.received` para cobrança confirmada e QR Code pronto para pagamento.[1] Para reduzir ambiguidade interna, a recomendação do CashYin é usar `data.status = paid` para o estado financeiro final e emitir `pix.cash_in.paid` como evento público canônico. Se houver exigência de compatibilidade com nomenclatura BRZip, `pix.cash_in.confirmed` pode ser tratado como **alias legado de saída** ou **alias de entrada**, mas não deve ser o nome interno canônico.

### 4.2 Status canônicos de Cash-Out

| Status | Significado | Terminal | Evento público recomendado | Observação financeira |
|---|---|---:|---|---|
| `processing` | Pagamento enviado ao provedor ou banco e ainda em processamento. | Não | `pix.cash_out.processing` | Manter reserva de liquidez e não considerar cash-out liquidado definitivamente. |
| `completed` | Pagamento concluído com sucesso. | Sim | `pix.cash_out.completed` | Liquidar saída, registrar `completed_at` e `e2e_id`. |
| `failed` | Pagamento falhou antes de concluir. | Sim | `pix.cash_out.failed` | Liberar reserva ou estornar débito conforme política contábil. |
| `returned` | Pagamento foi devolvido pelo banco recebedor. | Sim | `pix.cash_out.returned` | Lançar retorno/reversão auditável, sem confundir com falha inicial. |

A referência BRZip lista `pix.cash_out.completed`, `pix.cash_out.failed` e `pix.cash_out.returned` como eventos Cash-Out.[2] O status `processing` deve existir no domínio e nas consultas porque ele representa o período entre a solicitação do pagamento e o resultado final, ainda que a referência externa não liste obrigatoriamente um evento de processamento.

## 5. Contrato público de webhook

O envelope público deve ser estável, versionado e preparado para retry idempotente. O formato abaixo mantém a estrutura desejada pelo usuário, mas adiciona campos mínimos de robustez: `id` para identificar unicamente o evento, `schema_version` para evolução controlada e valores monetários em centavos para evitar divergência de arredondamento.

```json
{
  "id": "evt_01HZY6Z9W4R2F9A8EMN2A4S7QK",
  "event": "pix.cash_in.paid",
  "schema_version": "2026-05-23",
  "timestamp": "2026-03-15T14:30:00.000Z",
  "data": {
    "id": "txn_abc123",
    "external_id": "order-12345",
    "type": "cash_in",
    "status": "paid",
    "amount": "150.00",
    "amount_cents": 15000,
    "currency": "BRL",
    "payer_name": "John Doe",
    "payer_document": "123.456.789-00",
    "created_at": "2026-03-15T14:28:00.000Z",
    "paid_at": "2026-03-15T14:30:00.000Z",
    "completed_at": "2026-03-15T14:30:00.000Z"
  }
}
```

| Campo | Obrigatório | Regra |
|---|---:|---|
| `id` | Sim | Identificador único do evento público, idempotente por entrega lógica. Recomenda-se prefixo `evt_`. |
| `event` | Sim | Nome no padrão `pix.cash_in.*` ou `pix.cash_out.*`. |
| `schema_version` | Sim | Versão do contrato público. Recomenda-se data ISO da versão inicial ou semver. |
| `timestamp` | Sim | Momento em UTC em que o evento público foi criado no CashYin. |
| `data.id` | Sim | ID canônico da transação CashYin, não o ID bruto do provedor. |
| `data.external_id` | Sim | ID informado pelo cliente na criação da operação. |
| `data.type` | Sim | Apenas `cash_in` ou `cash_out`. |
| `data.status` | Sim | Status canônico compatível com `data.type`. |
| `data.amount` | Sim | Valor decimal em string com duas casas, em BRL. |
| `data.amount_cents` | Sim | Valor inteiro em centavos, fonte de verdade para reconciliação automática. |
| `data.currency` | Sim | Inicialmente `BRL`. |
| Campos de tempo | Sim quando aplicável | `created_at`, `paid_at`, `completed_at`, `expired_at`, `cancelled_at`, `failed_at`, `returned_at`. |
| Campos de contraparte | Opcional | `payer_name`, `payer_document`, `e2e_id`, conforme disponibilidade e LGPD. |

### 5.1 Eventos Cash-In públicos

| Evento | `data.type` | `data.status` | Quando emitir | Campos temporais recomendados |
|---|---|---|---|---|
| `pix.cash_in.received` | `cash_in` | `pending` | Após a cobrança ser criada e o QR Code estar pronto. | `created_at`, `expires_at` |
| `pix.cash_in.paid` | `cash_in` | `paid` | Após confirmação de pagamento pelo provedor e atualização atômica do domínio. | `created_at`, `paid_at`, `completed_at` |
| `pix.cash_in.expired` | `cash_in` | `expired` | Após expiração definitiva da cobrança. | `created_at`, `expired_at` |
| `pix.cash_in.cancelled` | `cash_in` | `cancelled` | Após cancelamento definitivo. | `created_at`, `cancelled_at` |
| `pix.cash_in.failed` | `cash_in` | `failed` | Após falha definitiva de criação/processamento. | `created_at`, `failed_at` |

A referência externa inclui `pix.cash_in.refunded`.[1] Como o conjunto de status solicitado para Cash-In não inclui `refunded`, a recomendação é não introduzir esse estado no ciclo principal nesta fase. Se refund for obrigatório, trate como **evento de reversão separado** e não como substituição do status principal, por exemplo com `event = pix.cash_in.refunded`, `data.status = paid` e um objeto `refund` contendo `refund_id`, `amount_cents`, `refunded_at` e `reason`. Essa decisão evita quebrar clientes que esperam apenas os cinco status canônicos de Cash-In.

### 5.2 Eventos Cash-Out públicos

| Evento | `data.type` | `data.status` | Quando emitir | Campos temporais recomendados |
|---|---|---|---|---|
| `pix.cash_out.processing` | `cash_out` | `processing` | Após aceitar a solicitação, reservar liquidez e enviar ao provedor. | `created_at` |
| `pix.cash_out.completed` | `cash_out` | `completed` | Após confirmação definitiva de sucesso. | `created_at`, `completed_at` |
| `pix.cash_out.failed` | `cash_out` | `failed` | Após falha definitiva antes da conclusão. | `created_at`, `failed_at` |
| `pix.cash_out.returned` | `cash_out` | `returned` | Após devolução pelo banco recebedor. | `created_at`, `returned_at` |

## 6. Regras de transição de status

As transições devem ser validadas por máquina de estados, nunca por comparação ad hoc de strings. A implementação deve rejeitar ou ignorar transições inválidas de forma idempotente, registrar auditoria e nunca emitir webhook público duplicado para a mesma transição lógica.

| Fluxo | De | Para permitido | Proibido |
|---|---|---|---|
| Cash-In | `pending` | `paid`, `expired`, `cancelled`, `failed` | Voltar para `pending` após terminal; ir para qualquer status Cash-Out. |
| Cash-In | `paid` | Apenas evento auxiliar de refund se existir, sem trocar o status principal nesta fase. | `expired`, `cancelled`, `failed` sem processo formal de reversão. |
| Cash-In | `expired` | Nenhum. | `paid` sem reabertura explícita e reconciliação manual. |
| Cash-In | `cancelled` | Nenhum. | `paid` sem processo formal de exceção. |
| Cash-In | `failed` | Nenhum. | `paid`, `expired`, `cancelled` por evento atrasado sem revisão. |
| Cash-Out | `processing` | `completed`, `failed`, `returned` | Voltar para `processing` após terminal; ir para status Cash-In. |
| Cash-Out | `completed` | `returned` apenas se o banco devolver posteriormente e a regra contábil permitir. | `failed`, pois falha inicial e retorno pós-sucesso são eventos distintos. |
| Cash-Out | `failed` | Nenhum. | `completed` sem nova operação idempotente e reconciliação. |
| Cash-Out | `returned` | Nenhum. | `completed` ou `failed` depois do retorno final. |

A regra mais importante para evitar prejuízo financeiro é que **status terminal só pode ser alterado por um fluxo explícito de reversão ou correção auditada**. Eventos atrasados do provedor devem ser comparados com o estado atual, `event_id`, `provider_event_id`, timestamps e versão da transação antes de qualquer lançamento financeiro.

## 7. Mapeamento de provedores para domínio

O mapeamento de provedores deve ficar confinado aos adapters, como `src/providers/bents/bents.mapper.ts`, e nunca vazar para os serviços de domínio ou payloads públicos. Isso permite trocar provedor sem quebrar contrato de cliente.

| Provedor bruto | Domínio Cash-In | Evento público | Observação |
|---|---|---|---|
| `PENDING`, `CREATED`, `RECEIVED`, QR gerado | `pending` | `pix.cash_in.received` | QR pronto para pagamento. |
| `PAID`, `CONFIRMED`, `SUCCESS` | `paid` | `pix.cash_in.paid` | Pagamento confirmado. |
| `EXPIRED` | `expired` | `pix.cash_in.expired` | Cobrança expirada. |
| `CANCELLED`, `CANCELED` | `cancelled` | `pix.cash_in.cancelled` | Cobrança cancelada. |
| `FAILED`, `ERROR`, `REJECTED` | `failed` | `pix.cash_in.failed` | Falha definitiva. |

| Provedor bruto | Domínio Cash-Out | Evento público | Observação |
|---|---|---|---|
| `PROCESSING`, `PENDING`, `SENT` | `processing` | `pix.cash_out.processing` | Ainda não liquidado. |
| `CONFIRMED`, `PAID`, `SUCCESS`, `COMPLETED` | `completed` | `pix.cash_out.completed` | Pagamento concluído. |
| `FAILED`, `ERROR`, `REJECTED`, `CANCELLED` | `failed` | `pix.cash_out.failed` | Falha antes de sucesso. |
| `REFUNDED`, `RETURNED`, `DEVOLVED` | `returned` | `pix.cash_out.returned` | Retorno/devolução pelo banco recebedor. |

## 8. Alterações recomendadas no banco de dados

A opção mais segura é criar enums separados para cada fluxo, evitando que uma tabela aceite status que não pertencem a ela. Caso o ambiente já esteja em produção com dados reais, a migração precisa ser executada com estratégia de compatibilidade, backfill e validação antes do corte.

```sql
CREATE TYPE pix_charge_status AS ENUM (
  'pending',
  'paid',
  'expired',
  'cancelled',
  'failed'
);

CREATE TYPE cashout_status AS ENUM (
  'processing',
  'completed',
  'failed',
  'returned'
);
```

| Tabela | Alteração recomendada | Motivo |
|---|---|---|
| `pix_charges` | Migrar `status` para `pix_charge_status`. | Impedir `processing`, `confirmed` e `reversed` em Cash-In. |
| `cashouts` | Migrar `status` para `cashout_status`. | Impedir `pending`, `paid`, `expired` e `cancelled` em Cash-Out. |
| `webhook_events` | Manter payload bruto e adicionar campos de processamento se necessário: `normalized_event_type`, `normalized_transaction_id`, `processing_status`, `processing_error`. | Preservar auditoria e permitir reprocessamento controlado. |
| `outbox_events` | Manter genérica, mas padronizar `event_type` público e payload versionado. | Suportar múltiplos consumidores sem acoplar a tabela ao webhook HTTP. |
| Nova tabela `client_webhook_deliveries` | Registrar tentativas, resposta HTTP, assinatura, próximo retry e status de entrega. | Auditoria de entrega e troubleshooting com clientes. |

Migração sugerida de status legados:

| Tabela | Status legado | Status novo | Observação |
|---|---|---|---|
| `pix_charges` | `created`, `pending`, `processing` | `pending` | `processing` em Cash-In deve ser tratado como pendência, se existir. |
| `pix_charges` | `confirmed` | `paid` | Principal correção semântica. |
| `pix_charges` | `failed` | `failed` | Sem alteração. |
| `pix_charges` | `cancelled` | `cancelled` | Sem alteração. |
| `pix_charges` | `expired` | `expired` | Sem alteração. |
| `pix_charges` | `reversed` | Revisão manual ou evento de refund separado | Não existe status canônico equivalente nesta fase. |
| `cashouts` | `created`, `pending`, `processing` | `processing` | Antes do resultado final. |
| `cashouts` | `confirmed` | `completed` | Principal correção semântica. |
| `cashouts` | `failed`, `cancelled`, `expired` | `failed` | `cancelled`/`expired` devem manter `failure_reason` se houver. |
| `cashouts` | `reversed` | `returned` | Correção semântica para retorno bancário. |

## 9. Pipeline de processamento recomendado

O pipeline deve ser desenhado para garantir atomicidade entre mudança financeira e emissão de evento. O padrão recomendado é **inbound raw webhook → normalização → transição transacional → lançamentos financeiros → outbox público → entrega HTTP com retry**.

| Etapa | Responsabilidade | Garantia |
|---|---|---|
| 1. Receber webhook de provedor | Validar assinatura e preservar raw body. | Nenhuma transição ocorre sem auditoria do payload bruto. |
| 2. Deduplicar provider event | Usar `(provider_name, provider_event_id)` quando disponível. | Retries do provedor não duplicam processamento. |
| 3. Normalizar evento | Converter evento/status bruto em `cash_in`/`cash_out` e status canônico. | Provedor não vaza para domínio. |
| 4. Localizar transação | Encontrar por `provider_charge_id`, `provider_payment_id`, `txid`, `external_id` ou `e2e_id`, conforme fluxo. | Eventos órfãos ficam retidos para reconciliação, não são descartados silenciosamente. |
| 5. Validar transição | Aplicar máquina de estados. | Transição inválida é auditada e não causa lançamento financeiro indevido. |
| 6. Persistir atualização | Atualizar status, timestamps, E2E ID, pagador e metadados em transação DB. | Estado financeiro e dados auxiliares ficam consistentes. |
| 7. Lançar ledger/tarifas | Executar lançamentos financeiros idempotentes para eventos financeiros. | Evita dupla cobrança ou duplo crédito. |
| 8. Enfileirar outbox | Criar evento público `pix.cash_in.*` ou `pix.cash_out.*` no mesmo commit. | Se a transação foi atualizada, o evento público existe de forma durável. |
| 9. Entregar webhook ao cliente | Worker lê outbox ou tabela de deliveries, assina payload e envia. | Retry não altera estado financeiro; apenas tenta entrega. |
| 10. Registrar tentativas | Persistir status de HTTP, resposta e próximo retry. | Suporte e auditoria conseguem explicar cada entrega. |

## 10. Segurança, assinatura e idempotência de entrega

A referência BRZip descreve assinatura HMAC-SHA256 usando timestamp e raw body, com headers `x-webhook-timestamp` e `x-webhook-signature`.[1] Para o CashYin, recomenda-se adotar o mesmo conceito no webhook enviado aos clientes, acrescentando um identificador de evento para idempotência do consumidor.

| Header | Exemplo | Regra |
|---|---|---|
| `x-webhook-id` | `evt_01HZY6Z9W4R2F9A8EMN2A4S7QK` | Igual ao `id` do envelope. |
| `x-webhook-timestamp` | `2026-03-15T14:30:00.000Z` | UTC ISO 8601; o cliente deve rejeitar timestamps muito antigos. |
| `x-webhook-signature` | `sha256=...` | HMAC-SHA256 sobre `timestamp + "." + rawBody`. |
| `user-agent` | `CashYin-Webhooks/1.0` | Facilita allowlist e suporte. |

A entrega deve considerar HTTP `2xx` como sucesso e tratar `4xx`/`5xx`/timeout como falha com retry, exceto quando uma política explícita determinar que certos `4xx` permanentes encerram a entrega. Cada retry deve reenviar o **mesmo payload lógico**, com o mesmo `x-webhook-id`; alterar payload entre tentativas dificulta idempotência no cliente.

## 11. Compatibilidade e estratégia de rollout

A refatoração muda nomes importantes, portanto deve ser feita em fases. O sistema não deve trocar status e eventos em uma alteração única sem compatibilidade, porque clientes podem depender dos nomes antigos e dados históricos podem precisar de backfill.

| Fase | Descrição | Critério de conclusão |
|---|---|---|
| 1. Tipos e mapeadores canônicos | Criar tipos TypeScript separados, mapeadores de provedor e builders de payload. | Testes unitários cobrindo todos os status e eventos. |
| 2. Máquina de estados | Implementar transições permitidas por fluxo. | Transições inválidas são rejeitadas ou ignoradas idempotentemente. |
| 3. Migração compatível | Adicionar novos enums/colunas ou migrar status com backfill validado. | Nenhuma linha fica com status inválido. |
| 4. Outbox pública | Substituir eventos internos públicos por `pix.cash_in.*` e `pix.cash_out.*`. | Eventos novos têm payload versionado e `event_id`. |
| 5. Worker de entrega | Implementar assinatura, retry, logs e deliveries. | Webhooks são entregues com auditoria de tentativa. |
| 6. Consultas/listagens | Atualizar responses para expor status canônico. | Cliente vê os mesmos status em API e webhook. |
| 7. Modo compatibilidade | Se necessário, suportar aliases antigos por cliente. | Clientes migrados sem quebra. |
| 8. Corte final | Remover aliases e nomenclaturas legadas. | Monitoramento sem erros de integração. |

## 12. Impacto em extratos, listagens e consultas

O usuário solicitou que os novos status também apareçam em extratos ou listagens de transações. A recomendação é que qualquer endpoint de consulta retorne os mesmos campos canônicos usados no webhook. Isso reduz divergência entre o que o cliente recebe em tempo real e o que ele consulta depois.

| Campo em listagem | Cash-In | Cash-Out | Observação |
|---|---|---|---|
| `id` | Sim | Sim | ID CashYin. |
| `external_id` | Sim | Sim | Referência do cliente. |
| `type` | `cash_in` | `cash_out` | Nunca usar `pix_charge` ou `payment` no contrato cliente. |
| `status` | Um dos cinco status Cash-In | Um dos quatro status Cash-Out | Mesma enumeração do webhook. |
| `amount` | Decimal string | Decimal string | Exibir com duas casas. |
| `amount_cents` | Inteiro | Inteiro | Facilita reconciliação programática. |
| `created_at` | Sim | Sim | UTC. |
| `completed_at` | Quando pago | Quando concluído | Para Cash-In, pode espelhar `paid_at`. |
| `failed_at` | Quando falhou | Quando falhou | Recomendado para suporte. |
| `returned_at` | Não aplicável nesta fase | Quando retornado | Cash-Out somente. |

## 13. Testes obrigatórios

A implementação deve ser considerada incompleta se não houver testes de mapeamento, transição, payload público e idempotência. Em sistema financeiro, testes de nomes e transições são tão importantes quanto testes de cálculo, porque nomes errados geram integrações erradas.

| Tipo de teste | Casos mínimos |
|---|---|
| Unitário de status | Cada status bruto de provedor mapeia para exatamente um status canônico esperado. |
| Unitário de eventos | Cada status canônico gera exatamente um `event` público esperado. |
| Máquina de estados | Transições permitidas passam; transições proibidas não alteram estado nem geram outbox. |
| Payload builder | Valores em `amount`, `amount_cents`, `type`, `status`, timestamps e IDs são determinísticos. |
| Idempotência | Mesmo provider event não atualiza nem entrega duas vezes. |
| Migração | Backfill converte `confirmed` para `paid`/`completed` conforme tabela. |
| Worker de entrega | `2xx` marca sucesso; timeout/`5xx` agenda retry; payload e assinatura permanecem consistentes. |
| Consulta/listagem | API retorna status canônico igual ao último webhook público emitido. |

## 14. Checklist de implementação

| Item | Deve ser feito |
|---|---|
| Tipos | Criar `CashInStatus`, `CashOutStatus`, `TransactionType`, `PublicWebhookEventName`. |
| Constantes | Centralizar arrays e schemas Zod para evitar strings soltas. |
| Mapeadores | Isolar provider → domínio e domínio → evento público. |
| Banco | Separar enums ou aplicar CHECK constraints por tabela. |
| Services | Remover conversões `paid -> confirmed`, `confirmed -> confirmed`, `refunded -> reversed`. |
| Webhook inbound | Processar eventos brutos em camada separada, sem lógica específica espalhada. |
| Outbox | Enfileirar eventos públicos versionados no mesmo commit da transição. |
| Delivery | Implementar assinatura HMAC, retry, status de entrega e logs. |
| APIs | Atualizar criação, consulta, extrato e listagem para status canônico. |
| Docs | Documentar contrato público, headers, retries, exemplos e status. |

## 15. Decisões recomendadas

A decisão mais importante é tornar `paid` o nome canônico do Cash-In pago e `completed` o nome canônico do Cash-Out concluído. O termo `confirmed` deve ser removido do domínio público porque ele é ambíguo: em Cash-In pode significar pagamento confirmado, enquanto em Cash-Out pode significar pagamento concluído pelo provedor. O termo `reversed` também deve ser removido do contrato Cash-Out público e substituído por `returned`, porque o usuário quer distinguir claramente devolução bancária de falha inicial.

Também recomendo que o evento de criação/QR pronto seja `pix.cash_in.received`, com `data.status = pending`, porque esse nome aparece na referência e comunica que a cobrança foi recebida/confirmada pelo sistema para pagamento, não que o dinheiro foi recebido. Para o pagamento final, recomendo `pix.cash_in.paid`, mesmo que a referência use `pix.cash_in.confirmed`, porque o status desejado pelo usuário é `paid` e a padronização de nomes reduz custo de manutenção.

## 16. Referências

[1]: https://docs.brzip.com.br/guides/webhooks-integration#pix-cash-in-events "BRZip Webhooks Integration — PIX Cash-In Events"  
[2]: https://docs.brzip.com.br/guides/webhooks-integration#pix-cash-out-events "BRZip Webhooks Integration — PIX Cash-Out Events"
