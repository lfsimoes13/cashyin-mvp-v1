# Webhooks and transactional status documentation

This directory contains the domain documentation for CashYin transactional status normalization and public client webhook contracts.

| Document | Purpose |
|---|---|
| [`transaction-status-refactor-plan.md`](./transaction-status-refactor-plan.md) | Main technical plan for canonical Cash-In and Cash-Out statuses, public event names, webhook payloads, state transitions, outbox usage, idempotency, and delivery behavior. |
| [`webhook-refactor-source-findings.md`](./webhook-refactor-source-findings.md) | Supporting research and implementation findings used to justify the refactor. This file should be treated as reference material, not as the primary implementation source. |

Cursor/Opus should read `transaction-status-refactor-plan.md` first when implementing webhook status normalization. The source findings document should only be used to clarify context, constraints, and references.
