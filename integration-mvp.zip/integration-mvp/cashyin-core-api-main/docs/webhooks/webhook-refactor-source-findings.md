# Webhook Refactor Source Findings

Source URLs:

1. https://docs.brzip.com.br/guides/webhooks-integration#pix-cash-in-events
2. https://docs.brzip.com.br/guides/webhooks-integration#pix-cash-out-events

Key extracted facts from BRZip documentation:

- Webhooks deliver real-time HTTP POST notifications so clients do not need to poll for payment status changes.
- Delivery should be acknowledged with HTTP 200 by the receiving server.
- Failed deliveries can be retried with exponential backoff.
- Signatures are described as HMAC-SHA256 using `x-webhook-timestamp` and `x-webhook-signature` over `timestamp + "." + rawBody`.
- Supported PIX Cash-In events in the reference are:
  - `pix.cash_in.confirmed`: payment received and funds credited.
  - `pix.cash_in.received`: charge confirmed, QR Code generated and ready for payment.
  - `pix.cash_in.expired`: charge expired without payment.
  - `pix.cash_in.cancelled`: charge was cancelled.
  - `pix.cash_in.refunded`: payment was refunded to payer.
- Supported PIX Cash-Out events in the reference are:
  - `pix.cash_out.completed`: payment sent successfully.
  - `pix.cash_out.failed`: payment failed.
  - `pix.cash_out.returned`: payment returned by recipient bank.
- Reference notification payload shape:

```json
{
  "event": "pix.cash_in.received",
  "timestamp": "2026-03-15T14:30:00.000Z",
  "data": {
    "id": "txn_abc123",
    "external_id": "order-12345",
    "type": "cash_in",
    "status": "completed",
    "amount": "150.00",
    "payer_name": "John Doe",
    "payer_document": "123.456.789-00",
    "created_at": "2026-03-15T14:28:00.000Z",
    "completed_at": "2026-03-15T14:30:00.000Z"
  }
}
```

User-specific desired transaction statuses:

- Cash-In statuses:
  - `pending`: charge created, awaiting payment.
  - `paid`: payment received and confirmed.
  - `expired`: charge expired without payment.
  - `cancelled`: charge was cancelled.
  - `failed`: charge processing failed.
- Cash-Out statuses:
  - `processing`: payment is being processed.
  - `completed`: payment was successful.
  - `failed`: payment failed.
  - `returned`: payment was returned by recipient bank.

User-specific naming rule:

- Transaction/event data type names must be `cash_in` and `cash_out`.
- PIX Cash-In events must use the `pix.cash_in.*` pattern.
- PIX Cash-Out events must use the `pix.cash_out.*` pattern.

## Current CashYin implementation findings

- The database currently defines a shared `transaction_status` enum with `created`, `pending`, `processing`, `confirmed`, `failed`, `cancelled`, `expired`, and `reversed`, used by both `pix_charges` and `cashouts`.
- `PaymentService` currently maps provider cash-in `paid` to persisted `confirmed` and enqueues the internal outbox event `pix.cash_in.created`.
- `CashoutService` currently maps provider cash-out `confirmed` to persisted `confirmed`, maps provider `refunded` to persisted `reversed`, and enqueues the internal outbox event `pix.cash_out.initiated` (legacy `cashout.initiated` rows are still drained for backward compatibility; see migration 0015).
- `ProviderPixPayment` currently exposes cash-out provider statuses as `processing`, `confirmed`, `failed`, and `refunded`, which conflicts with the requested public/domain names `processing`, `completed`, `failed`, and `returned`.
- Provider webhook ingestion currently verifies signature, persists raw payload in `webhook_events`, and deduplicates by `(provider_name, provider_event_id)` when the provider event ID exists.
- Domain reactions to provider webhooks are not implemented yet; status transitions, ledger posting and client webhook dispatch are explicitly left as future phases.
- `outbox_events` exists and is suitable as a transactional boundary for public webhook events, but the worker for client webhook delivery is still a placeholder.

These findings justify separating provider status, domain status and public event naming into explicit mappers and state machines.
