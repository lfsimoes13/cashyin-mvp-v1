# Modelo de Ameaças de Autenticação e Autorização — CashYin Core API

**Data:** 2026-05-31
**Escopo:** A fronteira de autenticação/autorização do chamador que está sendo
introduzida na Core API (caminhos críticos de cobrança Pix + cash-out, webhooks e
futuros clientes BFF/diretos). Este documento norteia o roadmap de autenticação
em múltiplos PRs; o PR 1 entrega apenas a fundação tipada (ver
`docs/adr/auth-authorization-boundary.md`).

Este é um documento vivo. As mitigações marcadas com **(PR 1)** já existem hoje;
as demais estão planejadas para PRs posteriores e estão listadas para que não
sejam esquecidas.

## Ativos

- Recursos dos clientes e a capacidade de movimentá-los (cash-out).
- Isolamento de dados entre tenants (um cliente não pode ler/agir sobre recursos
  de outro).
- Credenciais de provedor, credenciais de cliente emitidas pela CashYin, segredos
  de sessão do BFF.
- Integridade do ledger, garantias de idempotência e entrega de outbox/webhook.

## Fronteiras de confiança

- Internet → Core API (clientes de API direta, provedores).
- Navegador → BFF → Core API (usuários humanos via futuro BFF).
- Provedor → ingestão de webhook.
- Core API → Postgres / Redis / provedores (saída).

## Ameaças e mitigações

### T1. Autorização quebrada de objeto/tenant via `clientId` do corpo
**Ameaça:** Os schemas públicos aceitam um `clientId` fornecido pelo chamador,
que dirige idempotência, precificação, liquidez, ledger e escopo de propriedade.
Um chamador autenticado poderia informar o id de outro tenant para ler ou agir
entre tenants (OWASP API1:2023 BOLA).
**Mitigações:**
- (PR 1) `AuthContext.clientId` é o tenant canônico derivado pelo servidor; o ADR
  registra que o `clientId` do corpo é transitório.
- (PR 2) `resolveAuthContext` deriva o tenant do principal autenticado no canal
  `api_direct`; os schemas públicos não aceitam `client_id` no corpo (resolvido do
  Bearer), e guards de escopo por rota são aplicados às rotas Pix sob
  `AUTH_ENFORCEMENT_MODE` (`shadow` mede, `enforce` nega com 403). O
  `requireClientAccess` segue disponível para rejeitar um eventual campo legado de
  compatibilidade que reapareça e divirja.

### T2. Ataques de replay contra requisições de API direta
**Ameaça:** Uma requisição de API direta capturada é reenviada para duplicar uma
cobrança ou cash-out.
**Mitigações:**
- (existente) O cash-out exige um `Idempotency-Key`; o cash-in deduplica por
  `(client_id, external_ref)`.
- (futuro) Assinatura HMAC de requisição sobre uma representação canônica
  incluindo timestamp e nonce, com janela de desvio de relógio apertada e cache
  de nonce, além de vínculo por `credentialId` por credencial no `AuthContext`.

### T3. Vazamento de credenciais
**Ameaça:** Chaves de cliente emitidas pela CashYin, segredos HMAC ou segredos de
provedor vazam via logs, corpos de erro, repositórios ou backups.
**Mitigações:**
- (PR 1) Os erros de autenticação são não vazantes: códigos estáveis + mensagens
  genéricas, nunca segredos/tokens/assinaturas/OTPs/cabeçalhos/payloads em
  `AppError.details`.
- (existente/contínuo) Segredos no AWS Secrets Manager; nunca commitados;
  redação de log. Plano de rotação de credenciais indexado por `credentialId`.

### T4. Roubo de token em fluxos de navegador
**Ameaça:** XSS ou armazenamento inseguro expõe a sessão/token de um usuário
humano.
**Mitigações:**
- (futuro, BFF) Tokens nunca chegam ao navegador como segredos bearer; o BFF
  mantém o estado da sessão e encaminha uma identidade interna confiável à Core.
  Usar cookies HttpOnly + Secure + SameSite, sessões de curta duração, CSP
  estrita e nenhum token em `localStorage`.

### T5. CSRF contra futuros cookies de sessão do BFF
**Ameaça:** Sessões baseadas em cookie do BFF são abusadas por requisições
cross-site.
**Mitigações:**
- (futuro, BFF) Cookies `SameSite=Lax/Strict`, tokens anti-CSRF ou verificações
  de origin/sec-fetch nas rotas que alteram estado, e requisições
  `channel=frontend_bff` carregando uma identidade de ator verificada em vez de
  cookies crus para dentro da Core.

### T6. Bypass de MFA / step-up no cash-out
**Ameaça:** Um atacante inicia um cash-out sem satisfazer o step-up, ou refaz
(replay) uma prova de step-up obtida para outra operação/anterior.
**Mitigações:**
- (PR 1) `requireCashoutStepUp` exige uma `StepUpProof` não expirada cujo
  `transactionHash` esteja vinculado à operação específica, comparada de forma
  timing-safe; `requireAnyAmr` impõe fatores aceitáveis. (Apenas guards — ainda
  não conectados.)
- (futuro) Emissão/verificação no servidor + persistência das provas de step-up,
  vínculo de uso único e imposição via `AUTH_ENFORCEMENT_MODE=enforce`.

### T7. Logging de segredo / OTP / assinatura
**Ameaça:** Material sensível é escrito em logs ou traces durante a autenticação.
**Mitigações:**
- (PR 1) Nenhum guard, erro ou campo de contexto registra segredos crus, OTPs,
  assinaturas, cookies, cabeçalhos `Authorization` ou payloads assinados crus. A
  `StepUpProof` carrega apenas um `transactionHash` opaco (nunca seu material de
  origem).
- (contínuo) Redação de logs estruturados e revisão de qualquer futuro
  preHandler de autenticação.

### T8. Erros operacionais
**Ameaça:** Executar comandos de pagamento real, deploys manuais em produção,
migrations em produção, burlar branch protection ou usar override de admin
causam indisponibilidade ou movimentação de recursos.
**Mitigações:**
- Uma branch por fluxo lógico; PRs revisados; gates de CI (lint/build/test)
  precisam passar antes do merge. Sem override de admin; sem alterações em branch
  protection/rulesets.
- Sem comandos de pagamento real/e2e, sem chamadas a APIs de produção, sem
  deploys manuais e sem migrations em produção a partir do trabalho de feature. O
  PR 1 não adiciona migrations e não altera comportamento em runtime, então seu
  raio de impacto operacional é zero.

## Atualização — PRs 3 a 6

- **T1 (autorização de tenant):** o `frontend_bff` agora deriva o `clientId` de
  `X-CashYin-Client-Id` (confiável, pois o BFF é confiável e a Core o valida).
  Endpoints `/v1/admin/*` derivam o tenant do principal (sem `:clientId` no path),
  fechando cross-tenant também na administração.
- **T-canal BFF:** confiança via segredo compartilhado timing-safe
  (`BFF_SHARED_SECRET`, obrigatório quando `BFF_AUTH_MODE=enforce`); token inválido
  → 401 sem fallback. O segredo vive em Secrets Manager, nunca é logado. Residual:
  um segredo compartilhado estático é replayável se vazar — endurecer com HMAC/mTLS
  por requisição é evolução futura.
- **T-step-up (cash-out):** provas de uso único vinculadas por hash da operação
  (`cashout_step_up_proofs`), consumo atômico; expiração curta. Imposta apenas para
  cash-outs humanos (`frontend_bff`).
- **T-replay (HMAC):** assinatura canônica + janela de timestamp + **nonce store
  compartilhado em Postgres** (`api_hmac_nonces`, migration `0020`): um nonce gasto
  em qualquer réplica é rejeitado nas demais dentro da janela (upsert atômico — ver
  `PgApiHmacNonceStore`). Resolve o antigo risco de replay entre instâncias.
  Chaves sem `signing_secret` (anteriores à migration `0019`) não assinam e devem
  ser rotacionadas antes do `enforce`. O digest é sobre o **JSON canônico**
  (`stableStringify`), não os bytes crus — o contrato de assinatura para clientes
  `api_direct` está documentado em `docs/auth/api-direct-hmac-signing.md` (D15);
  fidelidade de bytes/corpos não-JSON é evolução futura via raw body por rota.
- **T7 (logging):** as novas camadas seguem a regra — apenas razões coarse
  (`reason`), `actorUserId`, escopo e rota são logados; nunca tokens, segredos de
  assinatura, nonces de material sensível ou payloads.

## Riscos residuais (estado atual)

- Todas as camadas (escopo, BFF, step-up, HMAC) estão **atrás de flags com default
  `off`**; o raio de impacto em runtime até serem ligadas é zero. O rollout
  recomendado (shadow → enforce, com observação de métricas/logs) está no plano de
  implementação.
- Replay de nonce HMAC entre instâncias: **resolvido** com `api_hmac_nonces`
  (migration `0020`) + `PgApiHmacNonceStore` (store compartilhado).
- RBAC por usuário no canal BFF **foi implementado** (D7): `user_client_grants`
  + interseção com `DEFAULT_BFF_SCOPES`, encenado por `BFF_RBAC_MODE`; gestão via
  `/v1/admin/bff-grants` (`clients:manage`). A leitura administrativa de
  tarifas/roteamento (`/v1/admin/config/*`, somente leitura, `clients:read`)
  **foi implementada** com allow-list estrita (sem custo/margem/subsídio/metadata/
  segredos).
- mTLS e CSRF permanecem desenhados, não impostos.
