---
title: "Autenticação"
excerpt: "Como autenticar suas requisições à Void Payments API usando HTTP Basic Auth"
category: "Introdução"
---

A Void Payments API utiliza **HTTP Basic Auth** para autenticar todas as requisições. Além disso, há uma camada adicional de segurança via **validação de IP de origem**.

---

## Credenciais

Ao criar sua conta, você recebe duas credenciais:

| Credencial | Descrição | Visibilidade |
|------------|-----------|-------------|
| `clientId` | Identificador público da sua conta | Visível a qualquer momento no painel |
| `clientSecret` | Chave secreta de autenticação | **Exibida apenas uma vez** no momento da criação |

> ⚠️ **Atenção**
>
> O `clientSecret` é exibido **apenas uma vez** no momento da criação. Salve-o em um local seguro imediatamente. Se você perder o secret, será necessário gerar um novo par de credenciais.

---

## Como Autenticar

### Passo 1: Codificar as credenciais

Concatene o `clientId` e o `clientSecret` separados por `:` (dois-pontos) e codifique o resultado em **Base64**:

```
base64(clientId:clientSecret)
```

**Exemplo:**

```
clientId:     ck_live_a1b2c3d4e5f6
clientSecret: sk_live_f6e5d4c3b2a1

Concatenado:  ck_live_a1b2c3d4e5f6:sk_live_f6e5d4c3b2a1
Base64:       Y2tfbGl2ZV9hMWIyYzNkNGU1ZjY6c2tfbGl2ZV9mNmU1ZDRjM2IyYTE=
```

### Passo 2: Enviar no header Authorization

Inclua o valor Base64 no header `Authorization` com o prefixo `Basic `:

```http
Authorization: Basic Y2tfbGl2ZV9hMWIyYzNkNGU1ZjY6c2tfbGl2ZV9mNmU1ZDRjM2IyYTE=
```

### Exemplo completo com cURL

A maioria dos clientes HTTP suporta Basic Auth nativamente. Com cURL, use a flag `-u`:

```bash
curl -X GET "https://api.jadelink.xyz/v1/balance" \
  -u "ck_live_a1b2c3d4e5f6:sk_live_f6e5d4c3b2a1"
```

O cURL codifica automaticamente em Base64. O header gerado será:

```http
GET /v1/balance HTTP/1.1
Host: api.jadelink.xyz
Authorization: Basic Y2tfbGl2ZV9hMWIyYzNkNGU1ZjY6c2tfbGl2ZV9mNmU1ZDRjM2IyYTE=
```

---

## Exemplos por Linguagem

### Node.js

```javascript
const axios = require('axios');

const clientId = 'ck_live_a1b2c3d4e5f6';
const clientSecret = 'sk_live_f6e5d4c3b2a1';

const response = await axios.get('https://api.jadelink.xyz/v1/balance', {
  auth: {
    username: clientId,
    password: clientSecret,
  },
});

console.log(response.data);
// { balance: 15000, currency: "BRL", pix_evp: { key: "...", key_name: "..." } }
```

### Python

```python
import requests

client_id = 'ck_live_a1b2c3d4e5f6'
client_secret = 'sk_live_f6e5d4c3b2a1'

response = requests.get(
    'https://api.jadelink.xyz/v1/balance',
    auth=(client_id, client_secret)
)

print(response.json())
# {'balance': 15000, 'currency': 'BRL', 'pix_evp': {'key': '...', 'key_name': '...'}}
```

### PHP

```php
<?php
$clientId = 'ck_live_a1b2c3d4e5f6';
$clientSecret = 'sk_live_f6e5d4c3b2a1';

$ch = curl_init('https://api.jadelink.xyz/v1/balance');
curl_setopt($ch, CURLOPT_USERPWD, "$clientId:$clientSecret");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
curl_close($ch);

$data = json_decode($response, true);
print_r($data);
// ['balance' => 15000, 'currency' => 'BRL', 'pix_evp' => ['key' => '...', 'key_name' => '...']]
```

### Java

```java
import java.net.http.*;
import java.util.Base64;

String clientId = "ck_live_a1b2c3d4e5f6";
String clientSecret = "sk_live_f6e5d4c3b2a1";

String credentials = Base64.getEncoder()
    .encodeToString((clientId + ":" + clientSecret).getBytes());

HttpRequest request = HttpRequest.newBuilder()
    .uri(URI.create("https://api.jadelink.xyz/v1/balance"))
    .header("Authorization", "Basic " + credentials)
    .GET()
    .build();

HttpResponse<String> response = HttpClient.newHttpClient()
    .send(request, HttpResponse.BodyHandlers.ofString());

System.out.println(response.body());
// {"balance":15000,"currency":"BRL","pix_evp":{"key":"...","key_name":"..."}}
```

---

## Validação de IP

Além do Basic Auth, a API valida o **IP de origem** de cada requisição contra a lista de IPs autorizados configurada na sua conta.

### Como funciona

1. Sua conta possui uma **lista de IPs permitidos** (configurada no cadastro)
2. A cada requisição, o IP de origem é extraído e comparado com a lista
3. Se o IP **não estiver** na lista, a requisição é rejeitada com `403 Forbidden`

### Configuração

A lista de IPs permitidos é definida no momento do cadastro da conta. Para adicionar ou remover IPs, entre em contato com o suporte.

**Formatos suportados:**

| Formato | Exemplo | Descrição |
|---------|---------|-----------|
| IPv4 | `203.0.113.50` | IP específico |
| Wildcard | `*` | Permite qualquer IP (não recomendado para produção) |

> 🚧 **Recomendação de segurança**
>
> Em produção, **sempre configure IPs específicos**. O wildcard `*` deve ser usado apenas em ambientes de desenvolvimento/teste.

### Exemplo de erro

Se o IP não estiver autorizado:

```json
// HTTP 403 Forbidden
{
  "error": "IP_NOT_ALLOWED",
  "message": "IP 203.0.113.50 is not allowed."
}
```

---

## Fluxo Completo de Autenticação

A cada requisição, a API executa as seguintes verificações na ordem:

```
Requisição recebida
       │
       ▼
┌─────────────────────┐     ┌─────────────────────────────────┐
│ Header Authorization│─NO─►│ 401 - Missing Authorization     │
│ presente?           │     │ header. Use Basic Auth.          │
└────────┬────────────┘     └─────────────────────────────────┘
         │ YES
         ▼
┌─────────────────────┐     ┌─────────────────────────────────┐
│ Formato Basic Auth  │─NO─►│ 401 - Invalid Authorization     │
│ válido?             │     │ header format.                   │
└────────┬────────────┘     └─────────────────────────────────┘
         │ YES
         ▼
┌─────────────────────┐     ┌─────────────────────────────────┐
│ clientId e           │─NO─►│ 401 - Invalid credentials.      │
│ clientSecret válidos?│     │                                  │
└────────┬────────────┘     └─────────────────────────────────┘
         │ YES
         ▼
┌─────────────────────┐     ┌─────────────────────────────────┐
│ Usuário está ativo? │─NO─►│ 403 - User is inactive          │
│                     │     │ or suspended.                    │
└────────┬────────────┘     └─────────────────────────────────┘
         │ YES
         ▼
┌─────────────────────┐     ┌─────────────────────────────────┐
│ IP está na           │─NO─►│ 403 - IP {ip} is not allowed.   │
│ whitelist?           │     │                                  │
└────────┬────────────┘     └─────────────────────────────────┘
         │ YES
         ▼
┌─────────────────────┐     ┌─────────────────────────────────┐
│ Conta (account)      │─NO─►│ 403 - Account is inactive       │
│ está ativa?          │     │ or not found.                     │
└────────┬────────────┘     └─────────────────────────────────┘
         │ YES
         ▼
   ✅ Requisição autorizada
   (prossegue para o endpoint)
```

---

## Erros de Autenticação

### 401 Unauthorized

Indica que as credenciais estão ausentes, mal formatadas ou inválidas.

| Cenário | Código | Mensagem |
|---------|--------|----------|
| Header `Authorization` ausente | `INVALID_CREDENTIALS` | `Missing Authorization header. Use Basic Auth (client_id:client_secret).` |
| Formato do header inválido | `INVALID_CREDENTIALS` | `Invalid Authorization header format. Use Basic Auth (client_id:client_secret).` |
| `clientId` ou `clientSecret` incorretos | `INVALID_CREDENTIALS` | `Invalid credentials.` |

**Exemplo de resposta:**

```json
// HTTP 401 Unauthorized
{
  "error": "INVALID_CREDENTIALS",
  "message": "Missing Authorization header. Use Basic Auth (client_id:client_secret)."
}
```

### 403 Forbidden

Indica que as credenciais são válidas, mas a requisição foi bloqueada por uma restrição de segurança.

| Cenário | Código | Mensagem |
|---------|--------|----------|
| IP não autorizado | `IP_NOT_ALLOWED` | `IP {ip} is not allowed.` |
| Usuário inativo/suspenso | `USER_INACTIVE` | `User is inactive or suspended.` |
| Conta inativa/não encontrada | `ACCOUNT_INACTIVE` | `Account is inactive or not found.` |

**Exemplo de resposta:**

```json
// HTTP 403 Forbidden
{
  "error": "IP_NOT_ALLOWED",
  "message": "Request from unauthorized IP address."
}
```

---

## Boas Práticas de Segurança

### 1. Nunca exponha o clientSecret no frontend

O `clientSecret` deve ser mantido **exclusivamente no backend**. Nunca inclua em:

- Código JavaScript executado no navegador
- Aplicativos mobile (Android/iOS)
- Repositórios públicos (GitHub, GitLab)
- Logs de aplicação

```javascript
// ❌ ERRADO - Credenciais no frontend
fetch('https://api.jadelink.xyz/v1/balance', {
  headers: {
    'Authorization': 'Basic ' + btoa('client_id:client_secret')
  }
});

// ✅ CORRETO - Chamada via seu backend
fetch('/api/balance');  // Seu backend faz a chamada para a Void Payments API
```

### 2. Use variáveis de ambiente

Armazene as credenciais em variáveis de ambiente, nunca hardcoded no código:

```bash
# .env (NÃO commitar este arquivo)
VOIDXPAY_CLIENT_ID=ck_live_a1b2c3d4e5f6
VOIDXPAY_CLIENT_SECRET=sk_live_f6e5d4c3b2a1
```

```javascript
// Uso no código
const clientId = process.env.VOIDXPAY_CLIENT_ID;
const clientSecret = process.env.VOIDXPAY_CLIENT_SECRET;
```

### 3. Configure IPs específicos em produção

Evite usar wildcard (`*`) na lista de IPs. Configure apenas os IPs dos servidores que realmente precisam acessar a API.

### 4. Rotacione credenciais periodicamente

Solicite a geração de novas credenciais periodicamente e atualize suas configurações. Mantenha apenas credenciais ativas.

### 5. Monitore acessos não autorizados

Fique atento a respostas `401` e `403` nos logs da sua aplicação. Um volume alto pode indicar tentativas de acesso indevido ou configuração incorreta de IP.

---

## Testando a Autenticação

A maneira mais simples de testar se suas credenciais estão funcionando é consultar o saldo:

```bash
curl -X GET "https://api.jadelink.xyz/v1/balance" \
  -u "seu_client_id:seu_client_secret"
```

**Se autenticado com sucesso:**

```json
// HTTP 200 OK
{
  "balance": 15000,
  "currency": "BRL",
  "pix_evp": {
    "key": "91b48553-e11a-473f-b605-598c9e0cdad4",
    "key_name": "EMPRESA LTDA"
  }
}
```

> 📘 O campo `pix_evp` só está presente quando o usuário possui uma chave PIX EVP configurada.

**Se as credenciais forem inválidas:**

```json
// HTTP 401 Unauthorized
{
  "error": "INVALID_CREDENTIALS",
  "message": "Invalid credentials."
}
```

**Se o IP não estiver autorizado:**

```json
// HTTP 403 Forbidden
{
  "error": "IP_NOT_ALLOWED",
  "message": "IP 203.0.113.50 is not allowed."
}
```

---

## Suporte

Problemas com autenticação? Verifique os pontos mais comuns:

| Problema | Solução |
|----------|---------|
| `401 - Invalid credentials` | Confirme que `clientId` e `clientSecret` estão corretos |
| `403 - IP not allowed` | Verifique se o IP do seu servidor está na lista de IPs permitidos |
| `403 - User inactive` | Entre em contato com o suporte para reativar sua conta |
| `403 - Account inactive` | Entre em contato com o suporte para verificar o status da conta |

Em caso de dúvidas, entre em contato:

- 📧 **Email**: suporte@jadelink.xyz
