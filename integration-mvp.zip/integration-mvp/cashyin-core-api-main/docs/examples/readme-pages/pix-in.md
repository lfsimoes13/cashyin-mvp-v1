---
title: "PIX IN (Recebimento)"
excerpt: "Crie cobranças PIX e consulte transações de recebimento"
category: "API Reference"
---

O endpoint de PIX IN permite gerar cobranças via QR Code PIX e consultar transações de recebimento.

---

## Criar PIX IN

Gera um QR Code PIX para recebimento.

```
POST /v1/pix-in
```

### Headers

| Header | Tipo | Obrigatório | Descrição |
|--------|------|-------------|-----------|
| `Authorization` | string | Sim | `Basic {base64(clientId:clientSecret)}` |
| `Content-Type` | string | Sim | `application/json` |

### Body

```json
{
  "paymentMethod": "PIX",
  "customer": {
    "name": "João da Silva",
    "email": "joao@email.com",
    "phone": "11987654321",
    "document": {
      "type": "CPF",
      "number": "41076028772"
    }
  },
  "amount": 10000,
  "items": [
    {
      "title": "Produto X",
      "unitPrice": 10000,
      "quantity": 1,
      "externalRef": "sku-123"
    }
  ],
  "externalRef": "pedido-456",
  "description": "Pagamento do pedido #456",
  "postbackUrl": "https://meu-sistema.com/webhooks",
  "metadata": {
    "orderId": "456"
  }
}
```

| Campo | Tipo | Obrigatório | Descrição |
|-------|------|-------------|-----------|
| `paymentMethod` | string | Sim | Sempre `"PIX"` |
| `amount` | integer | Sim | Valor em **centavos** (mínimo: 100 = R$ 1,00) |
| `customer` | object | Sim | Dados do pagador |
| `customer.name` | string | Sim | Nome (2 a 100 caracteres) |
| `customer.email` | string | Sim | E-mail válido |
| `customer.phone` | string | Sim | Telefone (10 ou 11 dígitos) |
| `customer.document` | object | Sim | Documento do pagador |
| `customer.document.type` | string | Sim | `"CPF"` ou `"CNPJ"` |
| `customer.document.number` | string | Sim | Apenas dígitos |
| `items` | array | Sim | Lista de itens (mínimo 1) |
| `items[].title` | string | Sim | Título do item (1 a 100 caracteres) |
| `items[].unitPrice` | integer | Sim | Preço unitário em centavos |
| `items[].quantity` | integer | Sim | Quantidade (mínimo 1) |
| `items[].externalRef` | string | Não | Referência externa do item (máx 50 caracteres) |
| `externalRef` | string | Não | Referência externa (ex: ID do pedido no seu sistema) |
| `description` | string | Não | Descrição do pagamento (máx 500 caracteres) |
| `pix.expiresInDays` | integer | Não | Dias para expiração do QR Code (1 a 7, padrão: 1) |
| `pix.additionalInfo` | string | Não | Informação adicional no PIX (máx 140 caracteres) |
| `postbackUrl` | string | Não | URL para receber webhooks específicos desta transação (deve usar http ou https) |
| `metadata` | object | Não | Dados adicionais (key-value livre) |

### Resposta — `201 Created`

```json
{
  "id": "7427a0dd-2c05-4e73-be21-b4809a77e35f",
  "amount": 10000,
  "refundedAmount": null,
  "installments": 1,
  "paymentMethod": "PIX",
  "status": "waiting_payment",
  "createdAt": "2026-02-16T12:00:00.000Z",
  "updatedAt": "2026-02-16T12:00:00.000Z",
  "paidAt": null,
  "externalRef": "pedido-456",
  "customer": { ... },
  "payer": null,
  "pix": {
    "qrcode": "00020101021226850014br.gov.bcb.pix...",
    "qrcodeImage": null,
    "qrcodeImageUrl": "https://...",
    "expirationDate": "2026-02-17T12:00:00.000Z"
  },
  "fee": {
    "totalFee": 150,
    "netAmount": 9850
  },
  "items": [
    { "title": "Produto X", "quantity": 1 }
  ],
  "metadata": { "orderId": "456" }
}
```

> 📘 **Sobre o campo `payer`**
>
> O campo `payer` é `null` na criação e será preenchido automaticamente quando o pagamento for confirmado, com os dados de quem efetivamente realizou o pagamento. Isso permite identificar o pagador real, que pode ser diferente do `customer` (ex: um terceiro PJ ou PF pagando em nome do destinatário). Campos disponíveis: `name`, `document` (number, type), `institution`, `institutionName`.

### Status do PIX IN

| Status | Descrição |
|--------|-----------|
| `waiting_payment` | QR Code gerado, aguardando pagamento |
| `paid` | Pagamento confirmado — saldo creditado |
| `expired` | QR Code expirou sem pagamento |
| `canceled` | Pagamento cancelado |
| `refused` | Pagamento recusado |
| `refunded` | Pagamento reembolsado |
| `chargedback` | Chargeback recebido |
| `in_analysis` | Em análise antifraude |
| `failed` | Falha no processamento |

---

## Consultar PIX IN (busca unitária)

Busca uma transação específica por `id` interno, `externalRef` ou `end2EndId`.

```
GET /v1/pix-in?id={transactionId}
GET /v1/pix-in?externalRef={suaReferencia}
GET /v1/pix-in?end2EndId={endToEndId}
```

### Query Parameters

| Parâmetro | Tipo | Descrição |
|-----------|------|-----------|
| `id` | string | ID interno da transação (UUID) |
| `externalRef` | string | Referência externa definida na criação |
| `end2EndId` | string | Identificador end-to-end do PIX no Banco Central |

> 📘 A busca segue a prioridade: `id` → `externalRef` → `end2EndId`. Se nenhum encontrar resultado, retorna `404`.

### Resposta — `200 OK`

Retorna o mesmo formato do objeto de criação (ver acima).

### Resposta — `404 Not Found`

```json
{
  "error": "TRANSACTION_NOT_FOUND",
  "message": "Transaction not found."
}
```

---

## Listar PIX IN (com filtros e paginação)

Lista transações PIX IN com filtros opcionais e paginação via cursor.

```
GET /v1/pix-in
GET /v1/pix-in?status=paid&startDate=2026-02-01T00:00:00Z&endDate=2026-02-28T23:59:59Z&limit=50
```

### Query Parameters (Filtros)

| Parâmetro | Tipo | Padrão | Descrição |
|-----------|------|--------|-----------|
| `status` | string | — | Filtrar por status (`waiting_payment`, `paid`, `expired`, `canceled`, `refused`, `refunded`, `chargedback`, `in_analysis`, `failed`) |
| `startDate` | string | — | Data início (ISO 8601, ex: `2026-02-01T00:00:00Z`) |
| `endDate` | string | — | Data fim (ISO 8601, ex: `2026-02-28T23:59:59Z`) |
| `limit` | integer | `20` | Máximo de resultados por página (1 a 100) |
| `pageToken` | string | — | Cursor para próxima página (retornado na resposta anterior) |

> 📘 Os filtros `startDate` e `endDate` atuam sobre o campo `createdAt` da transação. Os resultados são retornados em **ordem decrescente** (mais recentes primeiro).

### Resposta — `200 OK`

```json
{
  "data": [
    {
      "id": "7427a0dd-2c05-4e73-be21-b4809a77e35f",
      "amount": 10000,
      "status": "paid",
      "paymentMethod": "PIX",
      "createdAt": "2026-02-16T12:00:00.000Z",
      "paidAt": "2026-02-16T12:05:30.000Z",
      "externalRef": "pedido-456",
      "pix": { ... },
      "fee": { "totalFee": 150, "netAmount": 9850 },
      "metadata": { "orderId": "456" }
    },
    ...
  ],
  "pagination": {
    "count": 20,
    "nextPageToken": "eyJhY2NvdW50SWQiOi..."
  }
}
```

### Paginação

A API usa **paginação baseada em cursor** (não offset). Para buscar a próxima página, envie o valor de `nextPageToken` retornado na resposta anterior:

```
GET /v1/pix-in?status=paid&limit=20&pageToken=eyJhY2NvdW50SWQiOi...
```

Quando `nextPageToken` for `null`, não há mais resultados.

### Exemplos de uso

**Listar todos os PIX IN pagos:**

```bash
curl -X GET "https://api.jadelink.xyz/v1/pix-in?status=paid" \
  -u "clientId:clientSecret"
```

**Listar PIX IN de um período específico:**

```bash
curl -X GET "https://api.jadelink.xyz/v1/pix-in?startDate=2026-02-01T00:00:00Z&endDate=2026-02-15T23:59:59Z&limit=50" \
  -u "clientId:clientSecret"
```

**Buscar por referência externa:**

```bash
curl -X GET "https://api.jadelink.xyz/v1/pix-in?externalRef=pedido-456" \
  -u "clientId:clientSecret"
```

---

## Reembolso de PIX IN

Solicita reembolso (total ou parcial) de uma transação PIX IN com status `paid`. Suporta múltiplos reembolsos parciais acumulados.

```
POST /v1/pix-in/{transactionId}/refund
```

### Body

```json
{
  "amount": 5000,
  "information": "Devolução por duplicidade de pagamento"
}
```

| Campo | Tipo | Obrigatório | Descrição |
|-------|------|-------------|-----------|
| `amount` | integer | Sim | Valor do reembolso em **centavos** (mínimo: 1) |
| `information` | string | Sim | Motivo do reembolso (máx 500 caracteres) |

### Regras de negócio

- O `amount` não pode exceder o valor original da transação
- A soma de todos os reembolsos parciais não pode exceder o valor original
- O status permanece `paid` em reembolsos parciais
- O status muda para `refunded` quando a soma total atinge o valor original
- O saldo do usuário é debitado proporcionalmente ao valor creditado

### Resposta — `200 OK`

```json
{
  "id": "7427a0dd-2c05-4e73-be21-b4809a77e35f",
  "status": "paid",
  "refundedAmount": 5000,
  "totalRefunded": 5000,
  "originalAmount": 10000,
  "remainingAmount": 5000,
  "providerFee": 0,
  "debitedFromBalance": 4650,
  "refundedAt": "2026-02-16T10:30:00.000Z"
}
```

| Campo | Tipo | Descrição |
|-------|------|-----------|
| `id` | string | ID da transação |
| `status` | string | Status atualizado (`paid` se parcial, `refunded` se total) |
| `refundedAmount` | integer | Valor deste reembolso em centavos |
| `totalRefunded` | integer | Soma total de todos os reembolsos em centavos |
| `originalAmount` | integer | Valor original da transação em centavos |
| `remainingAmount` | integer | Valor restante reembolsável em centavos |
| `providerFee` | integer | Taxa do provider para o reembolso em centavos |
| `debitedFromBalance` | integer | Valor efetivamente debitado do saldo em centavos |
| `refundedAt` | string | Timestamp ISO 8601 do reembolso |

> 🚧 **Importante**
>
> Nem todos os providers suportam reembolso de PIX IN. Se o provider não suportar, a API retorna `400` com o código `REFUND_NOT_SUPPORTED`.

---

## Fluxo Completo

```
1. POST /v1/pix-in               → 201 (status: waiting_payment, QR Code gerado)
2. Pagador escaneia e paga
3. Webhook pix-in.paid            → Saldo creditado automaticamente
4. GET /v1/pix-in?id={id}         → 200 (status: paid, paidAt preenchido)
5. POST /v1/pix-in/{id}/refund    → 200 (reembolso total ou parcial, opcional)
```

---

## Erros Específicos

| HTTP | Código | Cenário |
|------|--------|---------|
| `400` | `INVALID_REQUEST` | Campos obrigatórios ausentes ou inválidos |
| `400` | `INVALID_REQUEST` | `amount` menor que 100 centavos |
| `400` | `INVALID_REQUEST` | Documento (CPF/CNPJ) com dígitos inválidos |
| `400` | `VALIDATION_ERROR` | Transação não pode ser reembolsada (status inválido) |
| `400` | `VALIDATION_ERROR` | Valor do reembolso excede o valor restante |
| `400` | `REFUND_NOT_SUPPORTED` | Provider não suporta reembolso de PIX IN |
| `400` | `REFUND_NOT_AVAILABLE` | Funcionalidade de reversão PIX não habilitada no provider |
| `409` | `REFUND_CONFLICT` | Reembolso concorrente detectado |
| `502` | `PROCESSING_ERROR` | Falha na comunicação com o provider de pagamento |
