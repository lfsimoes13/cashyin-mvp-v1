---
title: "Cashout (Saque / Transferência PIX)"
excerpt: "Envie transferências PIX e consulte transações de saque"
category: "API Reference"
---

O endpoint de Cashout permite enviar transferências PIX a partir do saldo da sua conta e consultar transações de saque.

O endpoint suporta dois modos de pagamento mutuamente exclusivos:
- **Chave PIX** — informe `pix.pixKeyType` + `pix.pixKey` para enviar para uma chave de destino
- **PIX Copia e Cola** — informe `pix.pixCopyPaste` com o código BR Code completo (ex: gerado por um QR code de cobrança)

---

## Criar Cashout

Cria uma transferência PIX para o destino informado. O valor + taxa é debitado do saldo da conta imediatamente.

```
POST /v1/cashout
```

### Headers

| Header | Tipo | Obrigatório | Descrição |
|--------|------|-------------|-----------|
| `Authorization` | string | Sim | `Basic {base64(clientId:clientSecret)}` |
| `Content-Type` | string | Sim | `application/json` |

### Body — Modo 1: Chave PIX

```json
{
  "amount": 5000,
  "pix": {
    "pixKeyType": "CPF",
    "pixKey": "12345678909"
  },
  "beneficiary": {
    "name": "João da Silva",
    "document": "12345678909"
  },
  "description": "Pagamento ao fornecedor",
  "idempotencyKey": "order-456-payout",
  "postbackUrl": "https://meu-sistema.com/webhooks",
  "metadata": {
    "orderId": "456"
  }
}
```

### Body — Modo 2: PIX Copia e Cola

```json
{
  "amount": 5000,
  "pix": {
    "pixCopyPaste": "00020126580014br.gov.bcb.pix0114123456789012340217Pagamento exemplo5204000053039865802BR5913Fulano de Tal6008Brasilia62070503***6304ABCD"
  },
  "idempotencyKey": "invoice-789-pay",
  "metadata": {
    "invoiceId": "789"
  }
}
```

### Campos

| Campo | Tipo | Obrigatório | Descrição |
|-------|------|-------------|-----------|
| `amount` | integer | Sim | Valor em **centavos** (mínimo: 1 = R$ 0,01) |
| `pix` | object | Sim | Dados do destino PIX (chave PIX **ou** copia e cola — mutuamente exclusivos) |
| `pix.pixKeyType` | string | Condicional | Tipo da chave: `"CPF"`, `"CNPJ"`, `"EMAIL"`, `"PHONE"`, `"EVP"`. Obrigatório no modo chave PIX. |
| `pix.pixKey` | string | Condicional | Chave PIX de destino. Obrigatório no modo chave PIX. |
| `pix.pixCopyPaste` | string | Condicional | Código PIX copia e cola (BR Code EMV, mín. 50 caracteres). Obrigatório no modo copia e cola. |
| `beneficiary` | object | Não | Dados do destinatário (ignorado no modo copia e cola — o beneficiário já está no código PIX) |
| `beneficiary.name` | string | Não | Nome completo do destinatário (mín. 2 caracteres) |
| `beneficiary.document` | string | Não | CPF (11 dígitos) ou CNPJ (14 dígitos) do destinatário |
| `description` | string | Não | Descrição da transferência (máx 500 caracteres) |
| `idempotencyKey` | string | Não | Chave de idempotência para evitar duplicatas |
| `postbackUrl` | string | Não | URL para receber webhooks específicos desta transação (deve usar http ou https) |
| `metadata` | object | Não | Dados adicionais (key-value livre) |

> 📘 **Nota sobre `pix`**
>
> Os campos `pixKeyType`/`pixKey` e `pixCopyPaste` são **mutuamente exclusivos**. Envie um ou outro, nunca ambos.
> Se ambos forem enviados, a API retorna erro `400 INVALID_REQUEST`.

> 📘 **Nota sobre `beneficiary`**
>
> O campo `beneficiary` é opcional e se aplica apenas ao modo chave PIX. No modo copia e cola, o beneficiário já está embutido no código PIX e o campo é ignorado.
> Quando não informado no modo chave PIX, o sistema usa o nome do usuário da API como fallback para `beneficiary.name`.

### Resposta — `201 Created` (Modo Chave PIX)

```json
{
  "id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "type": "PixOut",
  "status": "pending",
  "amount": 5000,
  "currency": "BRL",
  "pix": {
    "keyType": "CPF",
    "keyValue": "12345678909"
  },
  "fee": {
    "totalFee": 100,
    "netAmount": 4900
  },
  "description": "Pagamento ao fornecedor",
  "metadata": { "orderId": "456" },
  "idempotencyKey": "order-456-payout",
  "createdAt": "2026-02-16T14:00:00.000Z"
}
```

### Resposta — `201 Created` (Modo Copia e Cola)

```json
{
  "id": "b2c3d4e5-f6a7-8901-bcde-f12345678901",
  "type": "PixOut",
  "status": "pending",
  "amount": 5000,
  "currency": "BRL",
  "pix": {
    "copyPaste": "00020126580014br.gov.bcb.pix0114123456789012340217Pagamento exemplo..."
  },
  "fee": {
    "totalFee": 100,
    "netAmount": 4900
  },
  "description": null,
  "metadata": { "invoiceId": "789" },
  "idempotencyKey": "invoice-789-pay",
  "createdAt": "2026-02-16T14:00:00.000Z"
}
```

> 📘 **Nota sobre o formato de `pix` na resposta**
>
> O objeto `pix` na resposta reflete o modo utilizado na criação:
> - Chave PIX: `{ "keyType": "...", "keyValue": "..." }`
> - Copia e Cola: `{ "copyPaste": "..." }`

### Status do Cashout

| Status | Descrição |
|--------|-----------|
| `pending` | Transferência criada, aguardando processamento |
| `processing` | Em processamento pelo banco |
| `completed` | Transferência concluída com sucesso |
| `failed` | Falha no processamento — saldo devolvido |
| `rejected` | Transferência rejeitada pelo banco — saldo devolvido |
| `cancelled` | Transferência cancelada — saldo devolvido |
| `refunded` | Valor estornado — saldo devolvido |

> 🚧 **Importante**
>
> Em caso de falha (`failed`, `rejected`, `cancelled`), o saldo é **devolvido automaticamente** à conta.

### Idempotência

Se o campo `idempotencyKey` for enviado e já existir uma transação com a mesma chave, a API retorna `409 Conflict`:

```json
{
  "error": "DUPLICATE_REQUEST",
  "message": "A transaction with this idempotencyKey already exists.",
  "existingTransactionId": "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
}
```

---

## Consultar Cashout (busca unitária)

Busca uma transação específica por `id` interno ou `reference` (providerTransactionId ou endToEnd).

```
GET /v1/cashout?id={transactionId}
GET /v1/cashout?reference={endToEndOuProviderTxId}
```

### Query Parameters

| Parâmetro | Tipo | Descrição |
|-----------|------|-----------|
| `id` | string | ID interno da transação (UUID) |
| `reference` | string | ID do provider ou código end-to-end (E2E) |

> 📘 Se ambos forem informados, a busca por `id` tem prioridade. Se não encontrar por `id`, busca por `reference` no providerTransactionId e depois no endToEnd.

### Resposta — `200 OK`

Retorna o mesmo formato do objeto de criação (ver acima).

### Resposta — `404 Not Found`

```json
{
  "error": "TRANSACTION_NOT_FOUND",
  "message": "Transaction not found."
}
```

---

## Listar Cashouts (com filtros e paginação)

Lista transações de cashout com filtros opcionais e paginação via cursor.

```
GET /v1/cashout
GET /v1/cashout?status=completed&startDate=2026-02-01T00:00:00Z&endDate=2026-02-28T23:59:59Z&limit=50
```

### Query Parameters (Filtros)

| Parâmetro | Tipo | Padrão | Descrição |
|-----------|------|--------|-----------|
| `status` | string | — | Filtrar por status (`pending`, `processing`, `completed`, `failed`, `rejected`, `cancelled`, `refunded`) |
| `startDate` | string | — | Data início (ISO 8601, ex: `2026-02-01T00:00:00Z`) |
| `endDate` | string | — | Data fim (ISO 8601, ex: `2026-02-28T23:59:59Z`) |
| `limit` | integer | `20` | Máximo de resultados por página (1 a 100) |
| `pageToken` | string | — | Cursor para próxima página (retornado na resposta anterior) |

> 📘 Os filtros `startDate` e `endDate` atuam sobre o campo `createdAt` da transação. Os resultados são retornados em **ordem decrescente** (mais recentes primeiro).

### Resposta — `200 OK`

```json
{
  "data": [
    {
      "id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
      "type": "PixOut",
      "status": "completed",
      "amount": 5000,
      "currency": "BRL",
      "pix": {
        "keyType": "CPF",
        "keyValue": "12345678909"
      },
      "fee": { "totalFee": 100, "netAmount": 4900 },
      "description": "Pagamento ao fornecedor",
      "idempotencyKey": "order-456-payout",
      "metadata": { "orderId": "456" },
      "createdAt": "2026-02-16T14:00:00.000Z",
      "updatedAt": "2026-02-16T14:05:00.000Z",
      "paidAt": "2026-02-16T14:05:00.000Z",
      "endToEnd": "E12345678202602161400abcdef123456",
      "errorMessage": null
    },
    ...
  ],
  "pagination": {
    "count": 20,
    "nextPageToken": "eyJhY2NvdW50SWQiOi..."
  }
}
```

> 📘 **Nota sobre o formato de `pix`**
>
> Na resposta de criação (201) e consulta (GET), o objeto `pix` retorna:
> - Cashout por chave PIX: `{ keyType, keyValue }`
> - Cashout por copia e cola: `{ copyPaste }`
>
> No webhook, o formato é normalizado para `{ key_type, key, end_to_end_id }` (para cashouts por chave) ou `{ copy_paste, end_to_end_id }` (para cashouts por copia e cola).

### Paginação

A API usa **paginação baseada em cursor** (não offset). Para buscar a próxima página, envie o valor de `nextPageToken` retornado na resposta anterior:

```
GET /v1/cashout?status=completed&limit=20&pageToken=eyJhY2NvdW50SWQiOi...
```

Quando `nextPageToken` for `null`, não há mais resultados.

### Exemplos de uso

**Listar todos os cashouts completados:**

```bash
curl -X GET "https://api.jadelink.xyz/v1/cashout?status=completed" \
  -u "clientId:clientSecret"
```

**Listar cashouts de um período específico:**

```bash
curl -X GET "https://api.jadelink.xyz/v1/cashout?startDate=2026-02-01T00:00:00Z&endDate=2026-02-15T23:59:59Z&limit=50" \
  -u "clientId:clientSecret"
```

**Listar cashouts com falha:**

```bash
curl -X GET "https://api.jadelink.xyz/v1/cashout?status=failed" \
  -u "clientId:clientSecret"
```

**Buscar por end-to-end:**

```bash
curl -X GET "https://api.jadelink.xyz/v1/cashout?reference=E12345678202602161400abcdef123456" \
  -u "clientId:clientSecret"
```

---

## Fluxo Completo

```
1. POST /v1/cashout               → 201 (status: pending, saldo debitado)
2. Provider processa a transferência
3. Webhook cashout.processing      → Transferência em processamento
4. Webhook cashout.completed       → PIX enviado com sucesso
5. GET /v1/cashout?id={id}         → 200 (status: completed, endToEnd preenchido)
```

**Em caso de falha:**

```
1. POST /v1/cashout               → 201 (status: pending, saldo debitado)
2. Webhook cashout.failed          → Saldo devolvido automaticamente
3. GET /v1/cashout?id={id}         → 200 (status: failed, errorMessage preenchido)
```

---

## Erros Específicos

| HTTP | Código | Cenário |
|------|--------|---------|
| `400` | `INVALID_REQUEST` | Campos obrigatórios ausentes ou inválidos |
| `400` | `INVALID_REQUEST` | Tipo de chave PIX inválido |
| `400` | `INSUFFICIENT_BALANCE` | Saldo insuficiente para valor + taxa |
| `409` | `DUPLICATE_REQUEST` | `idempotencyKey` já utilizada |
| `502` | `PROCESSING_ERROR` | Falha na comunicação com o provider |
