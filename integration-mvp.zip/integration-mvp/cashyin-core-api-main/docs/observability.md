# Observabilidade Operacional — CashYin Core API

> **Escopo:** métricas Prometheus para produção e pré-produção de alto volume. O fluxo mais crítico é `POST /v1/pix/cash-in/qrcode` e o processamento do evento `pix.cash_in.paid`. Toda configuração, alertas e dashboards devem priorizar cash-in.

---

## Sumário

1. [Visão geral](#1-visão-geral)
2. [Ativação e configuração](#2-ativação-e-configuração)
3. [Segurança do endpoint de métricas](#3-segurança-do-endpoint-de-métricas)
4. [Variáveis de ambiente](#4-variáveis-de-ambiente)
5. [Configuração Terraform / ECS](#5-configuração-terraform--ecs)
6. [Catálogo de métricas](#6-catálogo-de-métricas)
7. [Cardinalidade e labels a evitar](#7-cardinalidade-e-labels-a-evitar)
8. [Alertas recomendados](#8-alertas-recomendados)
9. [Dashboards](#9-dashboards)
10. [Integração com Prometheus / Amazon Managed Prometheus](#10-integração-com-prometheus--amazon-managed-prometheus)
11. [Como usar antes de ativar clientes de alto volume](#11-como-usar-antes-de-ativar-clientes-de-alto-volume)

---

## 1. Visão geral

A instrumentação é implementada em `src/shared/observability/metrics.ts` como um **registry in-process** que renderiza métricas no formato Prometheus text 0.0.4. Não há dependência de bibliotecas externas como `prom-client` — isso mantém o bundle leve e o startup rápido em Fargate.

As métricas são coletadas em dois pontos:

| Fonte | Como funciona |
|---|---|
| **In-process** | `MetricsRegistry.increment`, `setGauge`, `observe` chamados diretamente nos handlers e workers |
| **DB (scrape-time)** | `collectQueueMetrics()` executa duas queries agregadas em `webhook_events` e `outbox_events` a cada scrape |

O endpoint de métricas é `GET /internal/metrics` (configurável). Ele só é registrado quando `METRICS_ENABLED=true`.

---

## 2. Ativação e configuração

### Mínima (desenvolvimento)

Sem nenhuma variável adicional, as métricas já ficam ativas em `localhost:3000/internal/metrics` sem token de autenticação.

### Produção / pré-produção

```bash
METRICS_ENABLED=true
METRICS_PATH=/internal/metrics
METRICS_BEARER_TOKEN=<token-seguro-de-pelo-menos-32-chars>
CLIENT_WEBHOOK_TIMEOUT_MS=5000
CLIENT_WEBHOOK_CRITICAL_TIMEOUT_MS=2500
```

### Verificar disponibilidade

```bash
# Sem token
curl http://localhost:3000/internal/metrics

# Com token
curl -H "Authorization: Bearer $METRICS_BEARER_TOKEN" \
  http://localhost:3000/internal/metrics
```

A resposta deve ser `text/plain` no formato Prometheus. Se retornar `401`, o token está incorreto. Se retornar `404`, a rota não foi registrada (`METRICS_ENABLED=false`).

---

## 3. Segurança do endpoint de métricas

> **Risco**: o endpoint expõe contadores internos, latências e profundidade de filas. Mesmo sem dados pessoais, ele revela a topologia operacional do sistema.

### Recomendações por camada

| Camada | Recomendação |
|---|---|
| **Rede (preferencial)** | Expor apenas dentro da VPC. O ALB externo não deve rotear `/internal/*` para a Internet. Usar security group restrito à sub-rede do scraper Prometheus. |
| **Aplicação** | Configurar `METRICS_BEARER_TOKEN`. O handler verifica o header `Authorization: Bearer <token>` antes de retornar métricas. |
| **Labels** | Nunca incluir `client_id`, `txid`, `provider_charge_id`, IPs ou qualquer dado de alta cardinalidade nas labels. |

### Verificar que o ALB bloqueia `/internal/*`

No Terraform ou console AWS, confirme que o listener rule do ALB **não tem** uma regra que encaminha `/internal/*` para o target group da API. Se não houver regra específica, a regra default (`/*`) pode encaminhar a rota — adicione uma regra de `403` ou `redirect` para o path `/internal/*` no ALB.

### Exemplo de configuração segura para staging

```bash
METRICS_ENABLED=true
METRICS_PATH=/internal/metrics
METRICS_BEARER_TOKEN=$(openssl rand -hex 32)
```

---

## 4. Variáveis de ambiente

### Métricas

| Variável | Default | Staging | Produção inicial | Impacto operacional |
|---|---|---|---|---|
| `METRICS_ENABLED` | `true` | `true` | `true` | Desligar para desabilitar completamente o endpoint e o overhead de instrumentação |
| `METRICS_PATH` | `/internal/metrics` | `/internal/metrics` | `/internal/metrics` | Altere apenas se houver conflito de rota |
| `METRICS_BEARER_TOKEN` | — (sem token) | Token de 32 chars | Token de 32 chars | **Obrigatório em produção.** Sem token, qualquer processo na VPC pode ler as métricas |

### Timeouts de webhook ao cliente

| Variável | Default | Staging | Produção inicial | Impacto operacional |
|---|---|---|---|---|
| `CLIENT_WEBHOOK_TIMEOUT_MS` | `5000` | `5000` | `5000` | Timeout padrão para todos os eventos. Reduzir afeta clientes com endpoint lento |
| `CLIENT_WEBHOOK_CRITICAL_TIMEOUT_MS` | `2500` | `2500` | `2500` | Timeout específico para `pix.cash_in.paid`. Mais agressivo para garantir entrega rápida do evento mais crítico |

### Workers

| Variável | Default | Staging | Produção inicial | Impacto operacional |
|---|---|---|---|---|
| `WORKER_BUSY_INTERVAL_MS` | `50` | `50` | `50` | Sleep após tick com trabalho. Mantenha baixo em produção |
| `WORKER_IDLE_INTERVAL_MS` | `200` | `200` | `200` | Polling fallback quando LISTEN/NOTIFY está down. Mantenha ≤ 500ms |
| `WORKER_MAX_IDLE_INTERVAL_MS` | `5000` | `5000` | `5000` | Cap do backoff em idle. Ajuste para `1000` em produção de alto volume |
| `WORKER_ERROR_BACKOFF_MS` | `5000` | `5000` | `5000` | Sleep inicial após erro |
| `WORKER_MAX_ERROR_BACKOFF_MS` | `60000` | `60000` | `60000` | Cap do backoff em erro consecutivo |
| `WORKER_SHUTDOWN_TIMEOUT_MS` | `15000` | `15000` | `15000` | Deve ser < `stopTimeout` do ECS (30s) |
| `WORKER_ENABLE_DB_NOTIFY` | `true` | `true` | `true` | Desabilitar apenas em containers serverless sem TCP persistente |
| `WORKER_NOTIFY_RECONNECT_BASE_MS` | `1000` | `1000` | `1000` | Delay inicial para reconexão do LISTEN/NOTIFY |

---

## 5. Configuração Terraform / ECS

O módulo `infra/terraform/modules/ecs` já propaga todas as variáveis acima para as definições de task. Valores que devem ser sobrescritos por ambiente ficam em `terraform.tfvars` ou no workspace Terraform Cloud/Atlantis.

### Exemplo de configuração para produção inicial

```hcl
# infra/terraform/environments/prod/main.tf (ou tfvars equivalente)

module "ecs" {
  source = "../../modules/ecs"

  # Métricas
  metrics_enabled = true
  metrics_path    = "/internal/metrics"
  # METRICS_BEARER_TOKEN deve vir de Secrets Manager, não de tfvars em plaintext

  # Timeouts de webhook ao cliente
  client_webhook_timeout_ms          = 5000
  client_webhook_critical_timeout_ms = 2500

  # Workers — ajuste para alto volume
  worker_busy_interval_ms     = 50
  worker_idle_interval_ms     = 200
  worker_max_idle_interval_ms = 1000   # reduzido para alto volume
  worker_error_backoff_ms     = 5000
  worker_max_error_backoff_ms = 60000
  worker_shutdown_timeout_ms  = 15000
}
```

> **METRICS_BEARER_TOKEN no ECS**: não injete via `terraform.tfvars`. Coloque o token no Secrets Manager e adicione uma entrada em `api_secrets` no módulo ECS apontando para o ARN do secret. Caso contrário o token ficará em plaintext nos planos do Terraform.

### Verificar propagação

Após `terraform apply`, confirme que o task definition da API inclui as variáveis de ambiente esperadas:

```bash
aws ecs describe-task-definition \
  --task-definition cashyin-core-api-api \
  --query 'taskDefinition.containerDefinitions[0].environment' \
  --output table
```

---

## 6. Catálogo de métricas

### HTTP (API)

| Métrica | Tipo | Labels | Interpretação | Ação recomendada |
|---|---|---|---|---|
| `cashyin_http_requests_total` | Counter | `method`, `route`, `status_code` | Total de requests HTTP por rota e status | Calcular RPS e taxa de erro por rota |
| `cashyin_http_request_duration_seconds` | Histogram | `method`, `route`, `status_code` | Latência de cada request HTTP | Monitorar P95/P99 por rota |

### QR Code (cash-in)

| Métrica | Tipo | Labels | Interpretação | Ação recomendada |
|---|---|---|---|---|
| `cashyin_qrcode_create_total` | Counter | `provider`, `result` | Total de criações de QR Code (`success`, `dedup_hit`, `error`) | Taxa de erro e proporção de dedup |
| `cashyin_qrcode_create_duration_seconds` | Histogram | `provider`, `result` | Latência end-to-end do `POST /v1/pix/cash-in/qrcode` incluindo chamada ao provider | P95 > 1s é sinal de lentidão no provider |

Valores possíveis de `result`:
- `success` — charge criado com sucesso no provider e persistido localmente
- `dedup_hit` — request era uma retentativa com o mesmo `external_ref`; charge anterior retornado
- `error` — falha (provider, DB ou outra)

### Processamento de cash-in pago

| Métrica | Tipo | Labels | Interpretação | Ação recomendada |
|---|---|---|---|---|
| `cashyin_cashin_paid_processing_total` | Counter | `provider`, `result` | Total de eventos `pix.cash_in.paid` processados pelo worker | Taxa de noop e erros indica duplicatas ou problemas no provider |
| `cashyin_cashin_paid_processing_duration_seconds` | Histogram | `provider`, `result` | Duração do processamento de `pix.cash_in.paid` (DB + ledger + outbox) | P95 > 500ms sinaliza pressão no banco |

Valores possíveis de `result`:
- `updated` — status transicionado para `paid`, ledger postado, outbox enfileirado
- `noop_charge_not_found` — charge não encontrado (webhook órfão)
- `noop_already_paid` — webhook duplicado, charge já estava pago
- `error` — falha inesperada

### Provider Bents (HTTP outbound)

| Métrica | Tipo | Labels | Interpretação | Ação recomendada |
|---|---|---|---|---|
| `cashyin_provider_http_requests_total` | Counter | `provider`, `method`, `path`, `result`, `response_status`, `error_category` | Total de chamadas HTTP ao provider Bents | Taxa de erro por path e categoria |
| `cashyin_provider_http_request_duration_seconds` | Histogram | `provider`, `method`, `path`, `result`, `response_status`, `error_category` | Latência das chamadas HTTP ao provider | P95 > 800ms indica lentidão na Bents |
| `cashyin_provider_http_timeout_ms` | Gauge | `provider` | Timeout configurado para chamadas ao provider | Confirmar que está em 5000ms |

### Filas de provider webhook (DB, scrape-time)

| Métrica | Tipo | Labels | Interpretação | Ação recomendada |
|---|---|---|---|---|
| `cashyin_provider_webhook_queue_events` | Gauge | `provider`, `operation_type`, `normalized_status`, `processing_status` | Profundidade da fila de `webhook_events` por status | Backlog crescendo = worker parado ou lento |
| `cashyin_provider_webhook_queue_oldest_age_seconds` | Gauge | `provider`, `operation_type`, `normalized_status`, `processing_status` | Idade do evento mais antigo na fila | > 60s para `pix.cash_in.paid` é sinal de alerta crítico |

### Worker de provider webhook

| Métrica | Tipo | Labels | Interpretação | Ação recomendada |
|---|---|---|---|---|
| `cashyin_provider_webhook_processing_total` | Counter | `provider`, `operation_type`, `outcome` | Total de ticks do worker por resultado | Alto `retry` ou `dlq` = problemas sistêmicos |
| `cashyin_provider_webhook_processing_duration_seconds` | Histogram | `provider`, `operation_type`, `outcome` | Duração de cada tick do worker | P95 > 1s = pressão no banco ou no payment service |
| `cashyin_provider_webhook_claim_latency_seconds` | Histogram | `provider`, `operation_type`, `outcome` | Latência entre o ingresso do webhook e o claim pelo worker | P95 > 5s = workers muito lentos ou subutilizados |

### Filas de outbox (DB, scrape-time)

| Métrica | Tipo | Labels | Interpretação | Ação recomendada |
|---|---|---|---|---|
| `cashyin_outbox_queue_events` | Gauge | `aggregate_type`, `event_type`, `operation_type`, `status` | Profundidade da fila de `outbox_events` por tipo e status | Fila crescendo sem consumo = dispatcher parado |
| `cashyin_outbox_queue_oldest_age_seconds` | Gauge | `aggregate_type`, `event_type`, `operation_type`, `status` | Idade do evento mais antigo na fila de outbox | > 30s para `pix.cash_in.paid` = alerta |

### Webhook ao cliente (dispatcher)

| Métrica | Tipo | Labels | Interpretação | Ação recomendada |
|---|---|---|---|---|
| `cashyin_client_webhook_delivery_total` | Counter | `event_type`, `operation_type`, `result`, `status` | Total de tentativas de entrega de webhook ao cliente | Taxa de `failure` por event type |
| `cashyin_client_webhook_delivery_duration_seconds` | Histogram | `event_type`, `operation_type`, `result`, `status` | Duração da chamada HTTP ao endpoint do cliente (tempo de resposta do cliente) | P95 > `CLIENT_WEBHOOK_TIMEOUT_MS` = timeout frequente |
| `cashyin_client_webhook_timeout_ms` | Gauge | `event_type`, `operation_type` | Timeout configurado por tipo de evento | Confirmar `pix.cash_in.paid` usa `CLIENT_WEBHOOK_CASHIN_PAID_TIMEOUT_MS` |

#### Latência de entrega `pix.cash_in.paid` (Parte 1 — alvo 100–200 ms)

Todas medidas a partir de `outbox_events.created_at` (`outbox_created_at`). Veja [docs/webhooks/cash-in-paid-delivery-latency.md](webhooks/cash-in-paid-delivery-latency.md) para o orçamento de latência e a separação de responsabilidades (provider × CashYin × cliente).

| Métrica | Tipo | Labels | Segmento | Alvo |
|---|---|---|---|---|
| `cashyin_cash_in_paid_outbox_creation_latency_seconds` | Histogram | `provider` | Persistir `paid` → criar linha outbox (mesma transação) | ~0 (intra-tx) |
| `cashyin_client_webhook_first_attempt_start_latency_seconds` | Histogram | `event_type`, `operation_type` | `outbox_created_at` → início do POST (segmento controlado pela CashYin) | **P95 100–200 ms** |
| `cashyin_client_webhook_first_attempt_total_latency_seconds` | Histogram | `event_type`, `operation_type` | `outbox_created_at` → fim da 1ª tentativa (inclui resposta do cliente) | medir, não é o alvo |
| `cashyin_client_webhook_success_latency_seconds` | Histogram | `event_type`, `operation_type` | `outbox_created_at` → entrega bem-sucedida | medir, inclui retries/cliente |

> A meta de 100–200 ms aplica-se a `first_attempt_start_latency` (o que a CashYin controla). `first_attempt_total` e `success` incluem o tempo de resposta do endpoint do cliente, que a CashYin mede mas não controla. A latência externa do provider (Bents/Fyhub → CashYin) é medida separadamente por `cashyin_provider_webhook_claim_latency_seconds` e está **fora** da meta.

---

## 7. Cardinalidade e labels a evitar

Labels de alta cardinalidade causam explosão no número de séries Prometheus, aumentando uso de memória e degradando queries.

**Nunca adicione** estas labels às métricas:

| Label proibida | Motivo |
|---|---|
| `client_id` | Milhares de clientes × todas as métricas = explosão |
| `txid` | Um por transação — totalmente inaceitável |
| `provider_charge_id` | Igual ao `txid` |
| `external_ref` | Controlado pelo cliente, cardinalidade ilimitada |
| `e2e_id` | Um por transação Pix |
| `request_id` | Um por request HTTP |
| IP de cliente | Ilimitado |

**Labels seguras** (cardinalidade baixa e estável):

| Label | Valores possíveis |
|---|---|
| `provider` | `bents`, `unknown` |
| `result` | `success`, `error`, `dedup_hit`, etc. |
| `method` | `GET`, `POST` |
| `route` | paths fixos (ex: `/v1/pix/cash-in/qrcode`) |
| `status_code` | `200`, `201`, `400`, `500`, etc. |
| `operation_type` | `cash_in`, `cash_out`, `unknown` |
| `event_type` | `pix.cash_in.paid`, `pix.cash_in.expired`, etc. |
| `processing_status` | `pending`, `failed`, `processing`, `dlq` |

---

## 8. Alertas recomendados

Estes alertas cobrem os cenários mais críticos para pré-produção e produção inicial. Adicione-os como regras no Prometheus ou Amazon Managed Prometheus via CloudWatch Metrics Insights.

### Cash-in — QR Code

```yaml
# P95 alto no endpoint de QR Code
- alert: CashInQRCodeHighLatency
  expr: histogram_quantile(0.95, rate(cashyin_http_request_duration_seconds_bucket{route="/v1/pix/cash-in/qrcode"}[5m])) > 1.0
  for: 2m
  labels:
    severity: warning
  annotations:
    summary: "P95 do QR Code > 1s"

# P99 crítico — usuários já percebendo degradação
- alert: CashInQRCodeCriticalLatency
  expr: histogram_quantile(0.99, rate(cashyin_http_request_duration_seconds_bucket{route="/v1/pix/cash-in/qrcode"}[5m])) > 3.0
  for: 1m
  labels:
    severity: critical
  annotations:
    summary: "P99 do QR Code > 3s — degradação severa"

# Taxa de erro 5xx crescendo
- alert: CashInQRCode5xxRate
  expr: |
    rate(cashyin_http_requests_total{route="/v1/pix/cash-in/qrcode",status_code=~"5.."}[5m])
    /
    rate(cashyin_http_requests_total{route="/v1/pix/cash-in/qrcode"}[5m]) > 0.01
  for: 2m
  labels:
    severity: critical
  annotations:
    summary: "Taxa de erro 5xx no QR Code > 1%"
```

### Provider Bents

```yaml
# Latência P95 alta no provider
- alert: BentsProviderHighLatency
  expr: histogram_quantile(0.95, rate(cashyin_provider_http_request_duration_seconds_bucket{provider="bents"}[5m])) > 0.8
  for: 3m
  labels:
    severity: warning
  annotations:
    summary: "P95 do provider Bents > 800ms"

# Taxa de erro no provider
- alert: BentsProviderErrorRate
  expr: |
    rate(cashyin_provider_http_requests_total{provider="bents",result="failure"}[5m])
    /
    rate(cashyin_provider_http_requests_total{provider="bents"}[5m]) > 0.05
  for: 2m
  labels:
    severity: critical
  annotations:
    summary: "Taxa de erro no provider Bents > 5%"
```

### Filas de webhook de provider

```yaml
# Backlog crescendo
- alert: ProviderWebhookQueueBacklog
  expr: sum(cashyin_provider_webhook_queue_events{processing_status="pending"}) > 100
  for: 5m
  labels:
    severity: warning
  annotations:
    summary: "Fila de webhook de provider com > 100 eventos pendentes"

# Evento de pix.cash_in.paid com idade alta
- alert: CashInPaidWebhookStale
  expr: |
    max(cashyin_provider_webhook_queue_oldest_age_seconds{
      processing_status=~"pending|processing"
    }) > 60
  for: 2m
  labels:
    severity: critical
  annotations:
    summary: "Evento pix.cash_in.paid aguardando processamento há > 60s"
```

### Fila de outbox (cliente)

```yaml
# Backlog de outbox crescendo
- alert: OutboxQueueBacklog
  expr: sum(cashyin_outbox_queue_events{status="pending"}) > 200
  for: 5m
  labels:
    severity: warning
  annotations:
    summary: "Fila de outbox com > 200 eventos pendentes"

# pix.cash_in.paid aguardando entrega ao cliente
- alert: CashInPaidOutboxStale
  expr: |
    cashyin_outbox_queue_oldest_age_seconds{
      event_type="pix.cash_in.paid",
      status=~"pending|processing"
    } > 30
  for: 2m
  labels:
    severity: critical
  annotations:
    summary: "pix.cash_in.paid aguardando entrega ao cliente há > 30s"

# DLQ maior que zero
- alert: OutboxDLQNonZero
  expr: sum(cashyin_outbox_queue_events{status="dlq"}) > 0
  for: 1m
  labels:
    severity: critical
  annotations:
    summary: "Eventos na DLQ do outbox — requer ação manual"
```

### Webhook ao cliente

```yaml
# Taxa de falha de entrega
- alert: ClientWebhookDeliveryFailureRate
  expr: |
    rate(cashyin_client_webhook_delivery_total{result="failure"}[10m])
    /
    rate(cashyin_client_webhook_delivery_total[10m]) > 0.1
  for: 5m
  labels:
    severity: warning
  annotations:
    summary: "Taxa de falha de entrega de webhook ao cliente > 10%"

# Latência P95 alta de entrega de pix.cash_in.paid
- alert: CashInPaidWebhookDeliveryHighLatency
  expr: |
    histogram_quantile(0.95,
      rate(cashyin_client_webhook_delivery_duration_seconds_bucket{event_type="pix.cash_in.paid"}[5m])
    ) > 2.5
  for: 2m
  labels:
    severity: warning
  annotations:
    summary: "P95 de entrega de pix.cash_in.paid ao cliente > 2.5s"
```

### Workers — inatividade

```yaml
# Worker sem processar eventos por muito tempo (ausência de increment no counter)
# Use uma query que detecta ausência de atividade: se o rate for 0 por 5m
# em horário de pico, algo está errado.
- alert: ProviderWebhookWorkerIdle
  expr: |
    rate(cashyin_provider_webhook_processing_total[5m]) == 0
    and
    sum(cashyin_provider_webhook_queue_events{processing_status="pending"}) > 0
  for: 3m
  labels:
    severity: critical
  annotations:
    summary: "Worker de webhook de provider inativo com fila não vazia"
```

---

## 9. Dashboards

Consulte [`docs/dashboards.md`](./dashboards.md) para queries PromQL detalhadas e painel a painel.

---

## 10. Integração com Prometheus / Amazon Managed Prometheus

### Prometheus auto-hospedado (scrape config)

```yaml
scrape_configs:
  - job_name: cashyin-core-api
    scrape_interval: 15s
    scrape_timeout: 10s
    bearer_token: "<METRICS_BEARER_TOKEN>"
    static_configs:
      - targets:
          - "cashyin-api.internal:3000"  # endpoint interno na VPC
    metrics_path: /internal/metrics
```

### Amazon Managed Prometheus (AMP)

Use o AWS Distro for OpenTelemetry (ADOT) Collector ou o Prometheus Remote Write. Configure o scraper para apontar para o endpoint interno da API dentro da VPC, com autenticação via `Authorization: Bearer`.

```yaml
# Exemplo de configuração ADOT / Prometheus remote_write
remote_write:
  - url: "https://aps-workspaces.<region>.amazonaws.com/workspaces/<workspace-id>/api/v1/remote_write"
    sigv4:
      region: sa-east-1
    queue_config:
      max_samples_per_send: 1000
```

### Grafana

1. Adicione o Prometheus (ou AMP) como datasource em **Configuration → Data Sources**.
2. Importe os dashboards de `docs/dashboards.md` como JSON ou crie painéis manualmente usando as queries documentadas.
3. Configure variáveis de template `$provider` e `$route` para filtragem dinâmica.

---

## 11. Como usar antes de ativar clientes de alto volume

Antes de liberar o primeiro cliente com volume alto de transações, valide:

### 1. Baseline de latência

```promql
# P95 do QR Code em idle (sem volume)
histogram_quantile(0.95,
  rate(cashyin_http_request_duration_seconds_bucket{route="/v1/pix/cash-in/qrcode"}[5m])
)
```

Esperado em idle: < 200ms. Se já estiver alto, investigue DB pool ou cold start do Fargate.

### 2. Baseline de latência do provider

```promql
histogram_quantile(0.95,
  rate(cashyin_provider_http_request_duration_seconds_bucket{provider="bents"}[5m])
)
```

Esperado: < 300ms. Alta latência em idle = problema de rede/TLS com a Bents.

### 3. Filas zeradas

```promql
# Confirmar que não há eventos presos em pending antes de começar
sum(cashyin_provider_webhook_queue_events{processing_status="pending"})
sum(cashyin_outbox_queue_events{status="pending"})
```

Ambos devem ser 0 (ou muito próximos de 0).

### 4. DLQ zerada

```promql
sum(cashyin_outbox_queue_events{status="dlq"})
sum(cashyin_provider_webhook_queue_events{processing_status="dlq"})
```

Qualquer valor > 0 indica problema que deve ser resolvido antes de aumentar volume.

### 5. Testar com volume controlado

Execute `pnpm e2e` para um ciclo de cash-in completo e observe:

- `cashyin_qrcode_create_total{result="success"}` incrementando
- `cashyin_cashin_paid_processing_total{result="updated"}` incrementando após o webhook do provider
- `cashyin_client_webhook_delivery_total{result="success",event_type="pix.cash_in.paid"}` incrementando

Confirme que o `pix.cash_in.paid` sai da fila em < 5 segundos ponta a ponta.
