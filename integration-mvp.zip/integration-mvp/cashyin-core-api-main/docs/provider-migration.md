# Provider Migration Strategy

**Author:** Manus AI  
**Status:** Initial implementation guidance

Provider migration in CashYin is controlled through versioned assignments, not by overwriting a client field. This matters because cash-in, cash-out, refunds, MED events, reconciliation, and webhooks do not move at the same time. A safe migration must support overlap, draining, rollback, and independent cutovers per operation type.

| State | Meaning | Allowed Next States |
|---|---|---|
| `planned` | Migration has been designed but no traffic moved | `dual_write`, `rolled_back` |
| `dual_write` | New provider is validated with shadow or limited operations | `cashin_cutover`, `rolled_back` |
| `cashin_cutover` | New cash-in traffic uses the target provider | `cashout_cutover`, `rolled_back` |
| `cashout_cutover` | New cash-out traffic uses the target provider after liquidity readiness | `draining`, `rolled_back` |
| `draining` | Old provider handles only pending historical operations | `completed`, `rolled_back` |
| `completed` | Migration is closed and old assignment is inactive | none |

## Safe Migration Rules

Cash-in should usually move before cash-out because cash-out depends on available liquidity and provider operational balance. Cash-out should only move after CashYin has a target provider account with enough liquidity, active monitoring, and confirmed webhook delivery.

The old provider account must remain active for reconciliation and late webhooks until all pending charges, payments, refunds, MED events, and disputes are resolved. The team should never delete or immediately disable an old assignment after cutover.

## Avoiding Concentration Risk

Provider migration should avoid pushing a very large client or many clients into a single provider account at once. Assignments can support gradual distribution through weights and effective dates. The operational goal is to keep volume distributed across provider accounts while preserving deterministic routing per operation.

## Rollback

Rollback is an assignment change plus a reconciliation procedure. A rollback must not rewrite historical provider references. Historical operations remain tied to the provider account that executed them.

## References

[1]: https://www.postgresql.org/docs/current/transaction-iso.html "PostgreSQL Transaction Isolation"  
[2]: https://opentelemetry.io/docs/concepts/signals/traces/ "OpenTelemetry Traces"

