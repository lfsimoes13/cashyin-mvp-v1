# Security and Operational Controls

**Author:** Manus AI  
**Status:** Initial implementation guidance

CashYin processes financial operations and must be built with defense-in-depth. The first implementation includes HMAC helpers, a required idempotency header on cash-out (cash-in deduplicates by `external_ref`), strict request validation, structured error responses, and provider credential isolation through environment variables.

| Control | Rule |
|---|---|
| Provider secrets | Store only in environment or secret manager; never commit provider keys |
| Cash-out idempotency | Require `Idempotency-Key` on `POST /v1/pix/cash-out` (the operation that moves/reserves money); reject same key + different payload |
| Cash-in dedup | Cash-in (`POST /v1/pix/cash-in/qrcode`) uses no `Idempotency-Key`; dedup by `(client_id, external_ref)` business rule (`UNIQUE` constraint) |
| Webhook verification | Verify provider signatures before processing state transitions |
| Request validation | Validate all public payloads with Zod before calling services |
| Logging | Redact authorization headers and avoid logging secrets or full credentials |
| Ledger mutation | Never update or delete posted entries; use compensating entries |
| Cash-out approval | Require accounting balance reservation and provider liquidity reservation |
| Provider errors | Normalize provider errors into typed application errors and retain raw payload internally |

## Production Checklist

Before production, the team should add authentication middleware, persistent idempotency repository, durable raw-body capture for webhook signature verification, database transaction boundaries, Redis-backed operational locks, audit log retention policy, and provider-specific retry strategy. These controls must be implemented before live cash-out traffic is enabled.

## Secret Handling

`.env.example` documents required variables, but real `.env` files are ignored by Git. Provider API keys, webhook secrets, database credentials, and Redis credentials must be configured through the deployment platform secret store.

## References

[1]: https://cheatsheetseries.owasp.org/cheatsheets/Secrets_Management_Cheat_Sheet.html "OWASP Secrets Management Cheat Sheet"  
[2]: https://cheatsheetseries.owasp.org/cheatsheets/Logging_Cheat_Sheet.html "OWASP Logging Cheat Sheet"  
[3]: https://zod.dev/ "Zod Documentation"

