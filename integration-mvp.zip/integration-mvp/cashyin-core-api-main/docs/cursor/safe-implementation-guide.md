# Guia de boas práticas para implementar no Cursor com segurança

Autor: **Manus AI**  
Data: **2026-05-23**

## 1. Objetivo

Este guia consolida um fluxo seguro para configurar e usar o **Cursor** durante a implementação das mudanças discutidas para o CashYin, incluindo normalização de status, refatoração de webhooks, integração com providers, domínio, IP fixo de saída, auditoria, processamento assíncrono e entrega de eventos para clientes.

O objetivo principal é evitar **quebra de código**, **commits com erro**, **alterações arriscadas no core financeiro** e **mudanças grandes demais para revisar com segurança**.

## 2. Trabalhe sempre em branches específicas

Antes de pedir qualquer implementação ao Cursor, crie uma branch curta e isolada. Não misture refatoração de webhooks, status, infraestrutura e tarifas no mesmo commit ou na mesma branch, salvo quando houver dependência técnica inevitável.

| Tema | Branch sugerida |
|---|---|
| Normalização de status | `feat/normalize-transaction-statuses` |
| Refatoração de webhooks de clientes | `feat/client-webhook-events-v1` |
| Webhooks de providers | `feat/provider-webhook-ingress` |
| Processor assíncrono | `feat/provider-webhook-processor` |
| Infraestrutura, domínio e IP fixo | `docs/provider-infra-setup` |

Antes de começar uma branch, rode os comandos abaixo para confirmar que o projeto já parte de um estado saudável.

```bash
git checkout -b feat/provider-webhook-ingress
pnpm install
pnpm lint
pnpm build
pnpm test
```

Se qualquer comando falhar antes de começar, não implemente nada até entender o estado atual. Caso contrário, você pode acabar atribuindo à nova implementação um erro que já existia antes.

## 3. Crie regras do projeto no Cursor

Crie um arquivo de regras do Cursor, por exemplo:

```txt
.cursor/rules/cashyin-core-api.md
```

Use o conteúdo abaixo como regra base do projeto.

```md
# Regras de implementação do CashYin Core API

Você está trabalhando em um sistema financeiro crítico. Priorize segurança, idempotência, auditabilidade, consistência transacional e testes automatizados.

Nunca altere contratos públicos, status transacionais, migrations, ledger, tarifas, webhooks ou processamento de saldo sem explicar o impacto e sem adicionar ou atualizar testes.

Antes de modificar código, leia a documentação técnica relevante em `docs/`, especialmente:

- `docs/webhook-events-status-refactor-plan.md`
- `docs/provider-integration-infra-webhook-architecture.md`
- `docs/provider-webhook-url-security-standards.md`
- `docs/provider-integration-architecture-decision.md`
- `docs/prompts/opus-webhook-status-normalization.md`
- `docs/prompts/opus-provider-integration-infra-webhooks.md`

Não implemente lógica financeira diretamente dentro do request HTTP de webhook de provider. O endpoint deve validar, deduplicar, persistir e responder rápido. Processamento financeiro deve ocorrer em worker idempotente.

Não misture status bruto de provider com status canônico do CashYin. Sempre preserve `provider_status` e `provider_event_type` para auditoria.

Cash-In deve usar apenas: `pending`, `paid`, `expired`, `cancelled`, `failed`.

Cash-Out deve usar apenas: `processing`, `completed`, `failed`, `returned`.

Eventos públicos devem seguir o padrão:

- `pix.cash_in.*`
- `pix.cash_out.*`

Antes de finalizar qualquer alteração, execute obrigatoriamente:

```bash
pnpm lint
pnpm build
pnpm test
```

Não faça commit se qualquer validação falhar.

Commits devem ser pequenos, atômicos e com mensagem clara. Não misture documentação, migration, refatoração e feature no mesmo commit se puder separar.
```

Essa regra ajuda o Cursor a manter o contexto técnico correto e reduz a chance de ele fazer alterações amplas demais ou inconsistentes com a arquitetura definida.

## 4. Use o Cursor em modo incremental

O maior risco é pedir ao Cursor para implementar toda a arquitetura de uma vez. Para reduzir bugs, peça uma fase por vez e exija que ele explique os arquivos que pretende alterar antes de escrever código.

| Fase | Pedido seguro ao Cursor |
|---|---|
| 1 | “Leia as docs e me diga quais arquivos serão alterados antes de implementar.” |
| 2 | “Crie apenas os tipos e contratos, sem alterar comportamento.” |
| 3 | “Adicione testes dos novos tipos e mapeamentos.” |
| 4 | “Implemente a rota de ingress persistindo raw payload, sem efeito financeiro.” |
| 5 | “Implemente deduplicação com teste.” |
| 6 | “Implemente processor assíncrono com idempotência.” |
| 7 | “Integre outbox e webhooks de cliente.” |

Um bom prompt inicial para usar no Cursor é:

```md
Leia toda a documentação em `docs/` relacionada a webhooks, status transacionais e providers. Não altere código ainda.

Depois me devolva:

1. Arquivos que precisam ser alterados.
2. Riscos de quebra.
3. Ordem segura de implementação.
4. Testes que precisam ser criados antes ou junto da mudança.
5. Migrations necessárias.

Somente depois da minha aprovação implemente a primeira fase.
```

## 5. Exija checklist obrigatório antes de aceitar mudanças

Antes de aceitar qualquer alteração sugerida pelo Cursor, peça uma revisão objetiva baseada em checklist.

```md
Antes de finalizar, revise sua própria alteração usando este checklist:

- A mudança é compatível com os status canônicos definidos?
- Existe teste para o caminho feliz?
- Existe teste para payload inválido?
- Existe teste para duplicidade/idempotência?
- Existe teste para erro de provider?
- Algum contrato público foi alterado?
- Alguma migration pode quebrar dados existentes?
- O código preserva auditoria suficiente?
- `pnpm lint`, `pnpm build` e `pnpm test` passam?
```

Não aceite respostas vagas. O Cursor deve apontar arquivos, testes e comandos concretos.

## 6. Configure validação local antes de commit

Recomenda-se criar um script único de verificação no `package.json`, se ainda não existir.

```json
{
  "scripts": {
    "check": "pnpm lint && pnpm build && pnpm test"
  }
}
```

Depois, use sempre:

```bash
pnpm check
```

Se quiser elevar a segurança, configure um hook com Husky ou Lefthook para impedir commit quebrado. O mínimo recomendado é bloquear commit se `pnpm check` falhar.

## 7. Faça commits pequenos e auditáveis

Evite commits grandes como `implement webhooks`. Prefira commits por camada. Isso facilita revisão, rollback e auditoria.

| Tipo de alteração | Exemplo de mensagem |
|---|---|
| Tipos canônicos | `refactor: add canonical transaction status types` |
| Mapeamento de provider | `feat: add provider webhook adapter contract` |
| Migration | `feat: add provider webhook audit tables` |
| Rota de ingress | `feat: add provider webhook ingress routes` |
| Deduplicação | `feat: add provider webhook deduplication` |
| Worker | `feat: process provider webhooks asynchronously` |
| Testes | `test: cover provider webhook idempotency` |
| Documentação | `docs: update provider webhook implementation guide` |

Antes de cada commit, rode:

```bash
git diff --check
git status --short
pnpm check
git add <arquivos específicos>
git commit -m "feat: add provider webhook ingress routes"
```

Evite `git add .` quando houver muitos arquivos não revisados. Prefira adicionar arquivos específicos para impedir que mudanças acidentais entrem no commit.

## 8. Não altere migrations antigas sem necessidade

Como o sistema é financeiro, migrations antigas não devem ser reescritas se já foram aplicadas em algum ambiente. A regra deve ser:

> **Migrations antigas são imutáveis. Para evoluir schema, crie uma nova migration incremental.**

Prompt recomendado para o Cursor:

```md
Não edite migrations antigas já existentes. Se precisar alterar schema, crie uma nova migration incremental, reversível quando possível, e explique o impacto nos dados existentes.
```

## 9. Separe provider webhook de client webhook

Reforce no Cursor que existem dois fluxos diferentes de webhook. Confundir esses fluxos pode gerar payloads errados, duplicidade ou quebra de contrato com cliente.

| Tipo | Quem envia | Quem recebe | Objetivo |
|---|---|---|---|
| Provider webhook | Provider PIX | CashYin | Informar evento bruto externo. |
| Client webhook | CashYin | Cliente CashYin | Informar evento normalizado e público. |

Prompt recomendado:

```md
Não confunda webhooks recebidos de providers com webhooks enviados aos clientes. Provider webhook deve ser persistido, normalizado e processado. Client webhook deve ser gerado a partir do evento canônico CashYin e entregue via outbox com retry e assinatura.
```

## 10. Nunca aceite implementação sem idempotência

Para Cash-In, Cash-Out, ledger, tarifas e webhooks, idempotência é obrigatória. O Cursor deve provar isso com teste automatizado.

Prompt recomendado:

```md
Implemente idempotência obrigatória. O mesmo webhook recebido duas ou mais vezes não pode duplicar saldo, tarifa, ledger, status nem webhook enviado ao cliente. Adicione teste automatizado simulando webhook duplicado.
```

## 11. Fluxo ideal de trabalho no Cursor

Use este fluxo para cada fase de implementação.

| Passo | Ação |
|---|---|
| 1 | Peça análise sem código. |
| 2 | Aprove a lista de arquivos. |
| 3 | Peça implementação pequena. |
| 4 | Revise o diff no Cursor. |
| 5 | Rode `pnpm check`. |
| 6 | Peça correção se falhar. |
| 7 | Faça commit pequeno. |
| 8 | Só então avance para a próxima fase. |

Prompt prático para cada etapa:

```md
Implemente somente esta fase. Não faça mudanças fora do escopo. Ao final, liste exatamente:

1. Arquivos alterados.
2. Comportamento antes/depois.
3. Testes criados ou atualizados.
4. Riscos restantes.
5. Comandos executados e resultado.
```

## 12. Ordem recomendada de implementação

A ordem abaixo reduz risco porque primeiro estabelece contratos, depois auditoria, depois ingestão, e somente depois processamento financeiro.

| Ordem | Implementação | Motivo |
|---|---|---|
| 1 | Normalizar tipos/status canônicos em código. | Cria base única e reduz inconsistência. |
| 2 | Criar contratos de eventos públicos Cash-In/Cash-Out. | Define payload final para clientes. |
| 3 | Criar adapter contract para providers. | Permite multi-provider sem acoplamento. |
| 4 | Criar tabelas/auditoria de provider webhooks. | Garante rastreabilidade antes de processar. |
| 5 | Implementar ingress de provider webhooks. | Recebe e persiste sem efeito financeiro. |
| 6 | Implementar deduplicação. | Evita duplicidade antes de mexer em saldo. |
| 7 | Implementar processor assíncrono. | Aplica domínio de forma controlada. |
| 8 | Integrar outbox de client webhooks. | Entrega eventos públicos aos clientes. |
| 9 | Adicionar observabilidade e alertas. | Permite operação segura em produção. |
| 10 | Configurar DNS/IP fixo em ambiente real. | Só após endpoints e health checks estarem prontos. |

## 13. Regra final para evitar commit com erro

Adote esta regra operacional:

```md
Nenhum commit pode ser feito se:

- `pnpm lint` falhar;
- `pnpm build` falhar;
- `pnpm test` falhar;
- houver migration sem revisão;
- houver alteração de status sem teste;
- houver alteração de webhook sem teste de idempotência;
- houver alteração de payload público sem documentação;
- houver `console.log`, segredo, token ou dado sensível no diff.
```

## 14. Prompt curto para colar no Cursor antes de cada implementação

Use este prompt como padrão sempre que iniciar uma nova etapa.

```md
Você está trabalhando no CashYin Core API, um sistema financeiro crítico.

Antes de alterar código:

1. Leia as documentações relevantes em `docs/`.
2. Explique quais arquivos pretende alterar.
3. Explique riscos de quebra.
4. Informe quais testes serão criados ou atualizados.
5. Aguarde minha aprovação.

Durante a implementação:

- Não altere escopo fora da fase solicitada.
- Não edite migrations antigas.
- Não implemente lógica financeira síncrona em webhook de provider.
- Preserve raw payload, provider_status e provider_event_type para auditoria.
- Garanta idempotência.
- Adicione testes.

Ao finalizar:

- Liste arquivos alterados.
- Explique comportamento antes/depois.
- Rode `pnpm lint`, `pnpm build` e `pnpm test`.
- Não sugira commit se qualquer validação falhar.
```

## 15. Conclusão

A forma mais segura de usar o Cursor neste projeto é tratá-lo como um assistente de implementação incremental, e não como um executor de grandes refatorações de uma só vez. Para um sistema financeiro, cada alteração deve ser pequena, testável, auditável e reversível.

Se esse fluxo for seguido, a implementação tende a ser mais segura, revisável e alinhada com os requisitos de confiabilidade necessários para integrações PIX, webhooks de providers, ledger, tarifas e eventos enviados aos clientes.
