# CashYin Implementation Roadmap for Cursor

**Author:** Manus AI  
**Status:** Initial roadmap

The recommended implementation sequence is intentionally conservative. The goal is to make the core safe before adding dashboards, advanced reconciliation, or provider expansion.

| Phase | Objective | Done When |
|---|---|---|
| 1 | Durable repositories | Core services use PostgreSQL repositories instead of placeholders |
| 2 | Idempotency enforcement | Same key returns same response; mismatched hash returns conflict |
| 3 | Provider assignment routing | Client and operation resolve provider from versioned assignments |
| 4 | Ledger posting | Cash-in and cash-out transitions write balanced ledger entries |
| 5 | Liquidity reservation | Cash-out requires provider-account liquidity reservation |
| 6 | Webhook processing | Provider webhooks are verified, deduplicated, persisted, and mapped |
| 7 | Outbox workers | Client notifications are delivered asynchronously with retries |
| 8 | Contract tests | Bents mapper and provider behavior are covered by deterministic tests |

Do not implement Grafana dashboards, BI reporting, or advanced reconciliation in the first milestone. Those features should be built after the transactional path is correct and observable.

