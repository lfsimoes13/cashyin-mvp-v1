# Cursor/Opus prompt: webhook status refactor and provider ingress implementation

Use this prompt in Cursor/Opus when implementing the CashYin webhook status normalization and provider webhook ingress foundation.

```text
You are working on the CashYin Core API repository.

This is a financial processing core. Prioritize correctness, idempotency, auditability, append-only financial history, safe migrations, and small reviewable changes.

Before editing any file, read these documents in this order:

1. README.md
2. docs/architecture.md
3. docs/repository-structure.md
4. docs/database-schema.md
5. docs/multi-provider.md
6. docs/provider-migration.md
7. docs/security-and-operational-controls.md
8. docs/webhooks/transaction-status-refactor-plan.md
9. docs/provider-integration/provider-infra-webhook-architecture.md
10. docs/webhooks/webhook-refactor-source-findings.md
11. docs/cursor/safe-implementation-guide.md

Then inspect the current implementation, especially:

- migrations/
- src/modules/webhooks/
- src/modules/outbox/
- src/modules/payments/
- src/modules/cashouts/
- src/modules/ledger/
- src/modules/liquidity/
- src/modules/providers/
- src/providers/contracts/
- src/providers/bents/
- src/workers/outbox-dispatcher/
- src/workers/webhook-delivery/
- src/workers/reconciliation/
- package.json
- tests/ if present

Important context observed in the current repository:

- The current database uses one shared transaction_status enum for both pix_charges and cashouts.
- Cash-In and Cash-Out need separate canonical status models.
- Cash-In must use only: pending, paid, expired, cancelled, failed.
- Cash-Out must use only: processing, completed, failed, returned.
- Public client webhook events must use the pix.cash_in.* and pix.cash_out.* patterns.
- Provider-specific statuses must not leak into domain services or public client payloads.
- Provider webhook ingestion and client webhook delivery are different flows and must not be mixed.
- Provider webhook ingress must validate, deduplicate, persist raw payload, and respond quickly.
- Financial domain transitions, ledger effects, pricing effects, and client webhook outbox creation must happen in an idempotent processor, not inside the synchronous provider webhook HTTP request.

Do not start coding immediately.

First, produce a concise implementation review with:

1. Current files and modules that are relevant.
2. Current gaps compared with the documents.
3. Files you propose to create.
4. Files you propose to modify.
5. Migrations required.
6. Tests required.
7. Risks and assumptions.
8. A phased implementation order.

Wait for my approval before changing files.

Recommended implementation phases:

Phase 1 — Canonical status and public event foundation only

- Create explicit TypeScript types for CashInStatus, CashOutStatus, TransactionType, and PublicWebhookEventName.
- Create mapping helpers from canonical status to public event name.
- Create a state machine for allowed Cash-In and Cash-Out transitions.
- Create payload builder types for public client webhook envelopes.
- Add unit tests for all status mappings, event names, payload builders, and allowed/forbidden transitions.
- Do not modify database schema yet unless strictly necessary.
- Do not modify PaymentService or CashoutService behavior yet unless strictly necessary for compilation.
- Do not implement provider webhook processing yet.
- Do not implement client webhook delivery yet.

Phase 2 — Database migration foundation

- Do not edit old migrations.
- Create a new incremental migration.
- Replace or evolve the shared transaction_status model safely toward separate Cash-In and Cash-Out status constraints/enums.
- Add or evolve tables needed for provider webhook audit, deduplication, processing attempts, provider transaction references, outbox events, and client webhook deliveries, depending on what already exists.
- Include safe backfill logic for legacy statuses such as confirmed, reversed, created, pending, and processing.
- Add migration tests or documented verification queries where the project supports them.

Phase 3 — Provider webhook adapter contract

- Create a provider webhook adapter boundary that separates verify, parse, and normalize.
- Keep provider-specific logic under src/providers/<provider>/.
- Preserve raw payload, provider status, provider event type, provider transaction ID, provider event ID, headers redacted, and signature validation result for auditability.
- Do not let Bents-specific payloads leak into domain services.
- Add tests with sanitized fixtures.

Phase 4 — Provider webhook ingress

- Implement provider webhook ingress routes that support the target URL strategy from the docs.
- Support both a general provider webhook URL and operation-specific URLs if the provider allows separation.
- Validate signature using the real raw body, not JSON.stringify(request.body).
- Deduplicate by provider and provider event ID when available; otherwise use a documented fallback dedupe key.
- Persist the raw event and return quickly with 200 or 202.
- Do not update transaction status, ledger, balance, pricing, or client webhook delivery inside the ingress request.
- Add tests for valid signature, invalid signature, duplicate event, missing provider, malformed payload, and fast acknowledgement.

Phase 5 — Provider webhook processor

- Implement an asynchronous processor that locks pending provider webhook events safely.
- Normalize provider events into canonical CashYin transaction events.
- Apply state transitions idempotently.
- Persist status changes and enqueue public outbox events in the same database transaction.
- Do not duplicate ledger, balance, pricing, or outbox effects on retry.
- Send orphan or invalid events to a documented retry/DLQ/audit state instead of silently dropping them.
- Add tests for duplicate events, out-of-order events, invalid transitions, orphan events, and successful transitions.

Phase 6 — Client webhook delivery

- Implement client webhook delivery from outbox/client delivery records.
- Use stable event IDs.
- Sign payloads with HMAC-SHA256 using timestamp + "." + rawBody.
- Keep the same logical payload and event ID across retries.
- Treat 2xx as success and timeout/5xx as retryable failure.
- Record delivery attempts, HTTP status, response snippets, next retry time, and final status.
- Add tests for signature, retry scheduling, successful delivery, failed delivery, and idempotent retries.

Phase 7 — Public API/query consistency

- Update read/listing responses so clients see the same canonical statuses used in webhooks.
- Do not expose provider-specific raw statuses in public API responses.
- If legacy aliases are required, make them explicit, versioned, and client-scoped.
- Update documentation and tests.

Implementation constraints:

- Keep each phase small and reviewable.
- Do not mix provider webhook ingress, client webhook delivery, ledger, pricing, and infrastructure changes in one large diff.
- Do not edit old migrations unless the repository explicitly treats migrations as not-yet-applied development scaffolding. Prefer incremental migrations.
- Do not change public API contracts without updating docs and tests.
- Do not change provider contracts without updating docs and tests.
- Do not introduce provider-specific if/else branches in domain services.
- Do not update ledger entries in place.
- Do not perform financial effects in synchronous webhook ingress.
- Preserve raw payloads and audit fields.
- Use integer cents for money.
- Add tests for idempotency, duplicate webhooks, invalid transitions, and public payload shape.

Validation commands:

Run the available validation commands from package.json before finalizing:

- pnpm lint
- pnpm build
- pnpm test

If a command fails because of an existing unrelated issue, show the exact failure and explain why it is unrelated. Do not claim success if validation did not pass.

Final response after each implemented phase must include:

1. Files changed.
2. Migrations created.
3. Tests created or updated.
4. Behavior before and after.
5. Commands executed and results.
6. Remaining risks.
7. Next recommended phase.
```

## Approval prompt for Phase 1 only

After Cursor/Opus returns its implementation review and you approve it, use this narrower prompt to authorize only the first implementation step.

```text
The implementation plan is approved.

Implement Phase 1 only: canonical status and public event foundation.

Scope allowed:

- TypeScript types for CashInStatus, CashOutStatus, TransactionType, and PublicWebhookEventName.
- Canonical status to public event mapping helpers.
- Cash-In and Cash-Out state transition rules.
- Public webhook envelope/payload builder types or pure builders.
- Unit tests for mappings, events, payload shape, and valid/invalid transitions.

Scope not allowed:

- Do not modify database schema yet.
- Do not edit migrations yet.
- Do not change PaymentService behavior yet.
- Do not change CashoutService behavior yet.
- Do not implement provider webhook ingress yet.
- Do not implement provider webhook processor yet.
- Do not implement client webhook delivery yet.
- Do not change ledger, liquidity, pricing, or balances.
- Do not change public API routes yet.

Keep the diff small and reviewable.

Run:

- pnpm lint
- pnpm build
- pnpm test

At the end, report files changed, tests added, command results, and what remains for Phase 2.
```
