# Cursor Guidance for CashYin

**Author:** Manus AI  
**Status:** Initial coding-agent guidance

Cursor or any AI coding agent working in this repository must preserve the financial invariants defined in `docs/architecture.md`. This repository is not a generic CRUD API. It is a financial processing core where small mistakes can create balance, liquidity, audit, or provider reconciliation risks.

| Rule | Why It Matters |
|---|---|
| Do not change public write contracts without updating `docs/api-contracts.md` | API drift creates integration failures |
| Do not put provider-specific branches in domain services | Multi-provider support becomes expensive and unsafe |
| Do not update ledger entries in place | Financial audit history must remain append-only |
| Do not approve cash-out from client balance alone | Provider liquidity also determines execution safety |
| Do not use reporting queries on transactional write tables | High-volume writes must stay predictable |
| Always add or update tests for mappers and financial invariants | Provider behavior changes must be caught early |

## Recommended First Cursor Task

Ask Cursor to implement durable repositories behind the existing service boundaries. The first repository milestone should cover idempotency, provider assignments, PIX charges, cash-outs, ledger entries, liquidity reservations, webhook events, and outbox events.

## Suggested Prompt

```text
You are working on CashYin Core API. Read README.md, docs/architecture.md, docs/database-schema.md, docs/multi-provider.md, docs/provider-migration.md, and .cursor/rules before editing code. Implement the next milestone without changing the PaymentProvider interface unless the docs are updated first. Preserve ledger append-only behavior, require idempotency for all public writes, and keep provider-specific code under src/providers.
```

## Focused Implementation Prompts

| Prompt | When To Use |
|---|---|
| [`prompts/webhook-status-provider-ingress-implementation.md`](./prompts/webhook-status-provider-ingress-implementation.md) | Use this prompt when asking Cursor/Opus to review and implement the webhook status normalization, provider webhook ingress, provider processing, outbox, and client webhook delivery work in safe phases. |

## Pull Request Checklist

Every pull request should explain whether it changes public API behavior, provider behavior, database schema, ledger semantics, liquidity semantics, or migration behavior. If any answer is yes, the corresponding document in `docs/` must be updated in the same pull request.

