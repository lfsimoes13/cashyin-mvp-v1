# Database Schema Guidance

**Author:** Manus AI  
**Status:** Initial implementation guidance

The initial schema is defined in `migrations/0001_initial_schema.sql`. PostgreSQL is the recommended financial source of truth because CashYin needs relational constraints, transactional consistency, row-level locking, indexed lookup paths, and append-only audit tables.

| Table | Purpose |
|---|---|
| `clients` | Client identity and status |
| `providers` | Supported providers, starting with Bents |
| `provider_accounts` | Operational accounts at each provider |
| `client_provider_assignments` | Versioned routing by client and operation type |
| `idempotency_keys` | Public write deduplication and request hash enforcement |
| `pix_charges` | Cash-in charge lifecycle |
| `cashouts` | Cash-out payment lifecycle |
| `ledger_accounts` | Accounting accounts for clients and provider operations |
| `ledger_entries` | Append-only double-entry financial history |
| `liquidity_reservations` | Provider liquidity holds before cash-out execution |
| `provider_liquidity_snapshots` | Provider account liquidity observations |
| `webhook_events` | Raw provider event audit and deduplication |
| `outbox_events` | Transactional async event publishing |
| `provider_migrations` | Safe provider migration workflow |

## Partitioning

High-volume append-only tables should be partitioned by time. The initial migration demonstrates monthly partitioning for `ledger_entries`. The same approach should later be applied to large webhook and outbox history tables if volume requires it.

## Indexing Principles

Indexes should match API access patterns. The most important query paths are client transaction history by time, provider references for webhook correlation, pending outbox events, active liquidity reservations, and active provider assignments.

## Ledger Rule

The ledger must be balanced for every transaction. The sum of debits must equal the sum of credits. Updating or deleting posted ledger entries is forbidden. Reversals must use new compensating entries.

## References

[1]: https://www.postgresql.org/docs/current/ddl-partitioning.html "PostgreSQL Declarative Partitioning"  
[2]: https://www.postgresql.org/docs/current/explicit-locking.html "PostgreSQL Explicit Locking"  
[3]: https://www.postgresql.org/docs/current/indexes.html "PostgreSQL Indexes"

