# Provider integration documentation

This directory contains the architecture documentation for integrating external PIX providers into CashYin.

| Document | Purpose |
|---|---|
| [`provider-infra-webhook-architecture.md`](./provider-infra-webhook-architecture.md) | Main architecture document for provider infrastructure, fixed egress IP, DNS/domain strategy, provider webhook ingress, provider adapter boundaries, security controls, and asynchronous processing. |

This directory is focused on provider-facing infrastructure and internal ingestion architecture. Public client webhook behavior belongs in [`../webhooks/`](../webhooks/), while implementation prompts for Cursor/Opus belong in [`../cursor/prompts/`](../cursor/prompts/).
