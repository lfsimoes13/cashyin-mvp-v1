# Provider-webhook worker partitioning (Fase 1)

Isolates the critical **`pix.cash_in.paid`** path so a backlog of cash-out
(or non-paid cash-in) events can never delay payment-confirmed notifications.

## How it works

`webhook_events` already carries `operation_type`, `normalized_status_kind`
and `normalized_status`. The claim (`WebhookEventRepository.claimNextPending`)
now accepts an **optional** partition filter; the same Docker image runs as
several worker replicas, each configured via env vars to drain a disjoint
subset of the queue. `FOR UPDATE SKIP LOCKED` is preserved, so the replicas
never contend on the same row.

When **no** `WEBHOOK_WORKER_*` filter is set, the worker drains the whole
queue exactly as before (full back-compat).

## Env vars

| Var | Meaning |
|---|---|
| `WEBHOOK_WORKER_NAME` | Logical role; surfaced in logs + the `worker` metric label. |
| `WEBHOOK_WORKER_OPERATION_TYPE` | `cash_in` \| `cash_out`. |
| `WEBHOOK_WORKER_NORMALIZED_STATUS_KIND` | `cash_in` \| `cash_out` \| `unknown`. |
| `WEBHOOK_WORKER_NORMALIZED_STATUS` | Exact match, e.g. `paid`. |
| `WEBHOOK_WORKER_EXCLUDE_NORMALIZED_STATUS` | Comma list to exclude (NULL-safe). |
| `WEBHOOK_WORKER_EVENT_TYPES` | Comma list of `event_type` to include. |

All clauses are ANDed and applied after the status-eligibility group, so a
filter restricts both never-attempted (`pending`) and retry-eligible
(`failed`) rows.

### Recommended worker matrix

| Worker | Env | Priority |
|---|---|---:|
| `cashin-paid` | `OPERATION_TYPE=cash_in` + `NORMALIZED_STATUS=paid` | Max |
| `cashin-default` | `OPERATION_TYPE=cash_in` + `EXCLUDE_NORMALIZED_STATUS=paid` | Medium |
| `cashout` | `OPERATION_TYPE=cash_out` | Low |

## Required Terraform change (not yet applied)

The code is live and back-compatible: today's single `provider-webhook-worker`
keeps draining everything. To realise the isolation, split that one ECS
service into three services off the **same task definition family**, each with
a distinct `environment` overlay and `desired_count`.

In `infra/terraform/modules/ecs/workers.tf`, parameterise the worker by a
small map and use `for_each` (sketch):

```hcl
variable "provider_webhook_worker_partitions" {
  description = "Per-partition env + scaling for the provider-webhook worker fleet."
  type = map(object({
    desired_count = number
    environment   = list(object({ name = string, value = string }))
  }))
  default = {
    "cashin-paid" = {
      desired_count = 2
      environment = [
        { name = "WEBHOOK_WORKER_NAME", value = "cashin-paid" },
        { name = "WEBHOOK_WORKER_OPERATION_TYPE", value = "cash_in" },
        { name = "WEBHOOK_WORKER_NORMALIZED_STATUS", value = "paid" },
      ]
    }
    "cashin-default" = {
      desired_count = 1
      environment = [
        { name = "WEBHOOK_WORKER_NAME", value = "cashin-default" },
        { name = "WEBHOOK_WORKER_OPERATION_TYPE", value = "cash_in" },
        { name = "WEBHOOK_WORKER_EXCLUDE_NORMALIZED_STATUS", value = "paid" },
      ]
    }
    "cashout" = {
      desired_count = 1
      environment = [
        { name = "WEBHOOK_WORKER_NAME", value = "cashout" },
        { name = "WEBHOOK_WORKER_OPERATION_TYPE", value = "cash_out" },
      ]
    }
  }
}
```

Then make `aws_ecs_task_definition.provider_webhook_worker` and
`aws_ecs_service.provider_webhook_worker` use `for_each =
var.provider_webhook_worker_partitions`, append `each.value.environment` to
`local.worker_environment`, set `desired_count = each.value.desired_count`,
and suffix the family/service name with `each.key`. The command stays
`["node", "dist/src/main-provider-webhook-worker.js"]` for every partition.

Scaling guidance (per doc §P1): scale `cashin-paid` aggressively on
`webhook_event_oldest_age_seconds{operation_type="cash_in",normalized_status="paid"}`;
`cashout` can tolerate backlog.

> This split is deliberately deferred to a separate infra change so the
> application PR stays small and reviewable. Until it lands, set the
> `WEBHOOK_WORKER_*` vars on the existing single service to validate the
> filter in staging.
