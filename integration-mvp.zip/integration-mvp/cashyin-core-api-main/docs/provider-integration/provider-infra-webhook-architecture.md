# Arquitetura para integração com providers: IP fixo, domínio e webhooks

Autor: **Manus AI**  
Data: **2026-05-23**

## 1. Resumo executivo

A recomendação técnica é estruturar a integração com providers em três fluxos independentes: **saída do CashYin para providers**, **entrada de webhooks de providers para o CashYin** e **saída de webhooks do CashYin para clientes**. Essa separação reduz risco financeiro, melhora auditabilidade e evita que diferenças entre providers contaminem o domínio transacional central.

Para o **IP fixo de saída**, a solução deve ficar na infraestrutura, usando NAT Gateway, Cloud NAT ou mecanismo equivalente com um ou mais IPs públicos reservados. Esse IP ou pool de IPs será informado aos providers para allowlist. Serviços como NAT Gateway associam o tráfego outbound de workloads privados a IPs públicos estáticos/reservados, o que atende ao requisito de providers que exigem liberação prévia de origem.[1] [2]

Para o **domínio da API**, o padrão recomendado é expor a API pública em `https://api.cashyin.com`, com DNS gerenciado na Cloudflare, proxy ativo, TLS, WAF, rate limiting e origem protegida. Em registros com proxy ativo, a Cloudflare recebe o tráfego HTTP/HTTPS antes de encaminhar para a origem; no modo DNS-only, o DNS expõe diretamente o IP da origem.[3] Como a origem passa a enxergar conexões vindas dos ranges da Cloudflare, o firewall da origem deve permitir esses ranges e bloquear acesso direto não autorizado.[4]

Para **webhooks de providers**, a recomendação é não executar a lógica financeira no request HTTP recebido do provider. O endpoint deve validar assinatura, deduplicar, persistir o payload bruto, enfileirar processamento e responder rapidamente com `202 Accepted` para eventos novos ou `200 OK` para duplicados. O processamento de domínio deve ocorrer de forma assíncrona, idempotente e auditável, pois webhooks normalmente operam em modelo de entrega pelo menos uma vez, podendo gerar duplicidades, retries e eventos fora de ordem.

## 2. Decisão arquitetural recomendada

O melhor equilíbrio para o momento é manter o `core-api` como **fonte de verdade transacional**, mas separar operacionalmente os papéis em processos ou deployments distintos no mesmo repositório. Isso evita criar um microsserviço prematuro, mas já cria boundaries claros para segurança, escala e observabilidade.

| Componente | Responsabilidade | Deve fazer | Não deve fazer |
|---|---|---|---|
| `core-api` | API pública, criação de Cash-In/Cash-Out, consultas e domínio transacional. | Validar requests de clientes, criar transações, consultar saldo/ledger e publicar eventos internos. | Receber alto volume de callbacks de providers no mesmo processo crítico sem isolamento. |
| `provider-webhook-ingress` | Recebimento HTTP de webhooks dos providers. | Validar assinatura, preservar `rawBody`, deduplicar, persistir payload bruto e responder rápido. | Aplicar saldo, ledger, tarifa ou status final diretamente no request. |
| `provider-webhook-processor` | Normalização e aplicação idempotente de eventos recebidos. | Converter payloads específicos de providers para eventos canônicos CashYin e aplicar transições válidas. | Confiar cegamente em status bruto sem mapear e auditar provider/status original. |
| `webhook-dispatcher` | Entrega de webhooks CashYin para clientes. | Entregar eventos normalizados aos clientes com assinatura, retry, backoff e dead-letter. | Bloquear processamento financeiro aguardando resposta de cliente. |

A alternativa de criar um sistema totalmente separado para webhooks só deve ser adotada quando houver volume alto, necessidade regulatória específica, times independentes ou risco operacional que justifique mais complexidade. Como o código atual já possui `WebhookService`, preservação de `rawBody`, validação HMAC do provider Bents e tabela `webhook_events`, faz sentido evoluir o desenho dentro do repositório atual antes de extrair um serviço completamente separado.

## 3. Topologia proposta

A topologia proposta separa entrada pública, persistência, processamento assíncrono e saída com IP fixo. O DNS e a proteção de borda ficam na Cloudflare; a saída para providers fica atrás de NAT com IP fixo; e o banco/outbox preserva trilha de auditoria.

![Topologia de rede e componentes](https://private-us-east-1.manuscdn.com/sessionFile/7t7JgfKzz752Fx8jDHIeyi/sandbox/HfHOcU5ZWqNODp5vihSQoC-images_1779544282365_na1fn_L2hvbWUvdWJ1bnR1L2Nhc2h5aW4tY29yZS1hcGkvZG9jcy9kaWFncmFtcy9wcm92aWRlci1uZXR3b3JrLXRvcG9sb2d5.png?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvN3Q3SmdmS3p6NzUyRng4akRISWV5aS9zYW5kYm94L0hmSE9jVTVaV3FOT0RwNXZpaFNRb0MtaW1hZ2VzXzE3Nzk1NDQyODIzNjVfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwyTmhjMmg1YVc0dFkyOXlaUzFoY0drdlpHOWpjeTlrYVdGbmNtRnRjeTl3Y205MmFXUmxjaTF1WlhSM2IzSnJMWFJ2Y0c5c2IyZDUucG5nIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNzk4NzYxNjAwfX19XX0_&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=A8r8m~PBumNmvv0NDqfaxHghplq1Coi4hMw0oa9gm4KtjO4G6I4F9OJbxtt5vEQ60p59a5VCEonqNa8mxXI46cWqlFBLej8LXsDkawFicgPmnAyx2hv6Xf4qPaXoeNDYL6KkX9nO-4IlAMUCXItAhaFwHghdQ8AAmF1VV3cUtpEHiiXdoye-UT7euyzbgVoi0UqcJ-lcpKl4WsPg7wQA5~fs3fLbvEsorM581Sn7bXeE5ySH5F~XjNOstzIwi7-K9IV0CteLpYIQykqKqe5JxsonT~bJuiYG87PJQwbsH7lW-zh8Vtb44AMEtCHLOFolkEunHhXIZK1KNGoOfraUvg__)

| Fluxo | Origem | Destino | Controle principal | Observação |
|---|---|---|---|---|
| API pública | Cliente CashYin | `api.cashyin.com` | TLS, autenticação, rate limit e WAF | Fluxo de criação/consulta de transações. |
| Webhook provider inbound | Provider | `api.cashyin.com` ou `webhooks.cashyin.com` | Assinatura provider, replay protection, dedupe e raw payload | Não deve aplicar efeito financeiro síncrono. |
| Provider outbound | CashYin | API do provider | NAT com IP fixo, idempotency key e timeout | IP informado ao provider para allowlist. |
| Webhook cliente outbound | CashYin | URL do cliente | HMAC CashYin, retry e outbox | Evento público normalizado. |

## 4. IP fixo de saída

O IP fixo de saída é necessário para chamadas que o CashYin faz para providers, como criação de pagamento, consulta de status, confirmação, cancelamento ou outras chamadas autenticadas. Ele não é necessário para providers chamarem os webhooks do CashYin; nesse caso, o requisito é uma URL pública HTTPS estável.

A recomendação inicial é usar **um IP fixo por ambiente**: produção e homologação/sandbox não devem compartilhar o mesmo IP. Em produção crítica, recomenda-se planejar **dois ou mais IPs fixos** no NAT para melhorar capacidade, reduzir risco de exaustão de portas e permitir rotação controlada sem indisponibilidade. Todos os IPs do pool de produção devem ser cadastrados nos providers.

| Ambiente | IP de saída | Uso | Cadastro no provider |
|---|---|---|---|
| Produção | 1 a 2 IPs fixos reservados | Chamadas reais PIX e consultas financeiras | Obrigatório. |
| Staging/Homologação | 1 IP fixo separado | Testes integrados e sandbox de providers | Obrigatório quando provider tiver ambiente sandbox. |
| Desenvolvimento local | Sem IP fixo compartilhado | Testes locais e mocks | Não deve ser usado para transação real. |

A implementação ideal depende do ambiente de hospedagem final. Em AWS, o padrão é workloads em subnets privadas saindo via NAT Gateway com Elastic IP.[1] Em Google Cloud/Cloud Run, o padrão equivalente é rotear todo o tráfego de saída por VPC connector e Cloud NAT com IP externo reservado.[2] Em qualquer cloud, a regra de arquitetura permanece a mesma: **o código não deve escolher o IP de saída; a rede deve garantir o egress fixo**.

## 5. DNS Cloudflare e domínio `cashyin.com`

O domínio da API deve ser configurado como `api.cashyin.com`. Em fase inicial, webhooks de providers podem ficar no mesmo host por simplicidade. Em fase posterior, recomenda-se `webhooks.cashyin.com` para isolar WAF, logs, políticas de rate limit e roteamento.

| Host | Finalidade | Registro sugerido | Proxy Cloudflare | Justificativa |
|---|---|---|---|---|
| `api.cashyin.com` | API pública CashYin e endpoints versionados | `CNAME` para load balancer ou `A/AAAA` para origem | **Proxied** | Proteção da origem, TLS gerenciado, WAF e observabilidade. |
| `webhooks.cashyin.com` | Ingress dedicado de webhooks de providers | `CNAME` para ingress/load balancer de webhooks | **Proxied**, salvo incompatibilidade específica | Permite regras independentes por provider e reduz ruído no host principal. |
| `sandbox-api.cashyin.com` | API de homologação, se necessário | Registro separado para ambiente sandbox | Proxied | Evita misturar tráfego real e testes. |

A origem deve ser protegida para aceitar tráfego apenas da Cloudflare ou de rede interna confiável. Como registros proxied fazem o tráfego HTTP/HTTPS passar pela Cloudflare, o IP real do chamador é repassado por headers próprios e a aplicação/origem precisa confiar nesses headers somente quando a requisição realmente veio da Cloudflare.[3] [4]

## 6. Padrão de URLs para webhooks de providers

Providers variam: alguns aceitam uma única URL de webhook para todos os eventos, enquanto outros permitem configurar uma URL por tipo de evento. O CashYin deve suportar os dois modelos com paths previsíveis, versionados e específicos por provider.

| Capacidade do provider | URL CashYin recomendada | Exemplo |
|---|---|---|
| Apenas uma URL geral | `/v1/providers/{provider}/webhooks` | `https://api.cashyin.com/v1/providers/bents/webhooks` |
| URL separada para Cash-In | `/v1/providers/{provider}/webhooks/cash-in` | `https://api.cashyin.com/v1/providers/bents/webhooks/cash-in` |
| URL separada para Cash-Out | `/v1/providers/{provider}/webhooks/cash-out` | `https://api.cashyin.com/v1/providers/bents/webhooks/cash-out` |
| Canal futuro ou produto específico | `/v1/providers/{provider}/webhooks/{channel}` | `https://api.cashyin.com/v1/providers/acme/webhooks/pix` |

A URL não deve carregar segredo em query string. Tokens, assinaturas, timestamps e event IDs devem estar em headers ou no corpo assinado, conforme o padrão do provider. URLs aparecem em logs, ferramentas de monitoramento e painéis de provider; por isso, paths devem ser estáveis e não confidenciais.

## 7. Fluxo completo de recebimento e processamento

O fluxo correto para webhooks de provider deve ser orientado a **verificar, persistir, responder e processar depois**. Essa separação é essencial para lidar com retries, timeouts e indisponibilidade transitória sem duplicar efeitos financeiros.

![Sequência de recebimento e processamento](https://private-us-east-1.manuscdn.com/sessionFile/7t7JgfKzz752Fx8jDHIeyi/sandbox/HfHOcU5ZWqNODp5vihSQoC-images_1779544282365_na1fn_L2hvbWUvdWJ1bnR1L2Nhc2h5aW4tY29yZS1hcGkvZG9jcy9kaWFncmFtcy9wcm92aWRlci13ZWJob29rLXNlcXVlbmNl.png?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvN3Q3SmdmS3p6NzUyRng4akRISWV5aS9zYW5kYm94L0hmSE9jVTVaV3FOT0RwNXZpaFNRb0MtaW1hZ2VzXzE3Nzk1NDQyODIzNjVfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwyTmhjMmg1YVc0dFkyOXlaUzFoY0drdlpHOWpjeTlrYVdGbmNtRnRjeTl3Y205MmFXUmxjaTEzWldKb2IyOXJMWE5sY1hWbGJtTmwucG5nIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNzk4NzYxNjAwfX19XX0_&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=JSU06t5nUZ4iKtqO9QaNUgnl5PQAdssN73g5JdxVm0A-gb4ir7f0wVm9-A~FMeH8iOVFDIMTuCz3uEMzYteKjEO2-ztzySYXxX2HKpoJgxli1mV4r1wIf0VZPG4kerdtstNP8qUDfOa4qoS0D-OvwkNUrLBR9kz8E5APoYifwcn-MdBCRbiH5ogbVy0ALrDYIX-jaQ0uvU0S7Kif7qunWdOPh4vdGlBTaAyewRObs08PPqZfWHa-pZfom-hPSEZ~JCSrUM9NbWFZh2k-USunlqXH2sxwlxRzk63aHB4nd2UKErX5sR2IlM8r-d47so4hbi8tNt6Tw~pn56ng-f7s~A__)

| Etapa | Ação | Resultado esperado |
|---|---|---|
| 1 | Provider envia webhook para URL CashYin. | Requisição chega via Cloudflare/ingress com headers e raw body preservado. |
| 2 | `provider-webhook-ingress` identifica provider e adapter. | Request é roteado para validador específico. |
| 3 | Adapter valida assinatura usando raw body e headers. | Evento inválido é rejeitado com `401/403`; evento válido segue. |
| 4 | Adapter extrai metadados mínimos. | `provider_event_id`, `provider_transaction_id`, tipo, status bruto e data são capturados. |
| 5 | Sistema persiste `raw_payload`, headers redigidos e hash. | Auditoria preservada mesmo que parsing futuro mude. |
| 6 | Deduplicação por provider + event ID/hash. | Duplicados retornam `200 OK` sem reprocessar efeitos. |
| 7 | Evento novo é aceito e enfileirado. | Provider recebe `202 Accepted` rapidamente. |
| 8 | Worker normaliza evento e aplica transição. | Transação interna muda somente se a transição for válida e idempotente. |
| 9 | Outbox publica evento CashYin para cliente. | Cliente recebe payload padronizado, assinado e com retry. |

## 8. Normalização multi-provider

Cada provider deve ter um adapter próprio. O contrato do adapter deve separar validação criptográfica, parsing e normalização. O status bruto do provider deve ser armazenado para auditoria, mas o domínio do CashYin deve operar somente com status canônicos.

```ts
export interface ProviderWebhookAdapter {
  providerName: ProviderName;
  verify(input: ProviderWebhookVerificationInput): Promise<ProviderWebhookVerificationResult>;
  parse(input: ProviderWebhookParseInput): Promise<ProviderWebhookParsedEvent>;
  normalize(input: ProviderWebhookParsedEvent): Promise<ProviderWebhookNormalizedEvent>;
}
```

| Campo normalizado | Descrição | Obrigatoriedade |
|---|---|---|
| `provider_name` | Nome interno do provider. | Obrigatório. |
| `provider_event_id` | ID único do evento no provider, quando existir. | Obrigatório quando provider fornece; caso contrário usar hash determinístico. |
| `provider_transaction_id` | ID da transação no provider. | Obrigatório. |
| `cashyin_transaction_id` | ID interno resolvido pelo CashYin. | Obrigatório antes de aplicar transição. |
| `operation_type` | `cash_in` ou `cash_out`. | Obrigatório. |
| `provider_event_type` | Tipo original enviado pelo provider. | Obrigatório para auditoria. |
| `provider_status` | Status original enviado pelo provider. | Obrigatório para auditoria. |
| `normalized_status` | Status canônico CashYin. | Obrigatório para domínio. |
| `occurred_at` | Data/hora do evento na origem. | Obrigatório quando disponível; fallback para `received_at`. |
| `raw_payload_hash` | Hash do corpo bruto. | Obrigatório. |

Os status canônicos já definidos para Cash-In são `pending`, `paid`, `expired`, `cancelled` e `failed`. Para Cash-Out, são `processing`, `completed`, `failed` e `returned`. Essa separação evita misturar eventos públicos de cliente com status internos e torna migração entre providers menos arriscada.

![Decisão de roteamento por capacidade do provider](https://private-us-east-1.manuscdn.com/sessionFile/7t7JgfKzz752Fx8jDHIeyi/sandbox/HfHOcU5ZWqNODp5vihSQoC-images_1779544282365_na1fn_L2hvbWUvdWJ1bnR1L2Nhc2h5aW4tY29yZS1hcGkvZG9jcy9kaWFncmFtcy9wcm92aWRlci13ZWJob29rLXJvdXRpbmctZGVjaXNpb24.png?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvN3Q3SmdmS3p6NzUyRng4akRISWV5aS9zYW5kYm94L0hmSE9jVTVaV3FOT0RwNXZpaFNRb0MtaW1hZ2VzXzE3Nzk1NDQyODIzNjVfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwyTmhjMmg1YVc0dFkyOXlaUzFoY0drdlpHOWpjeTlrYVdGbmNtRnRjeTl3Y205MmFXUmxjaTEzWldKb2IyOXJMWEp2ZFhScGJtY3RaR1ZqYVhOcGIyNC5wbmciLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=f7nC11A9dQd3kt046L~PiaPXwBNlQ6wV8dSCnW~2RHI3rH-LfKEb0aJxNbIiwDkHCEiymekL8psnYoydp2ryKH1AaxuwzirPDHgODxsIOMMcebFhLv5XlJ0QATSYSdTrGhz2mtAp0MPzvEsLRFsSe97AvFYxykNHZHaiP43Rj7q9B72TQgx1~D5syoJWwI0Hekq44q1d-bUZ11jUoIqe4UlRSuAGB-DMb6TyboBSNhGdJniwZv5~Bu--kDbD6tRuMsCqn3yix6KQmHDkFCsGjCH8hkVTc7lBj5S4WOoAszo9amPoatob2nPOZ2NGGxqKlAOOa-kNfSfsz4C64Qj76w__)

## 9. Modelo de dados recomendado

O modelo atual já possui uma base para `webhook_events`, mas precisa evoluir para explicitar provider, dedupe, processamento, erros, raw payload e status de job. A intenção é permitir auditoria, reprocessamento e investigação de divergência.

| Tabela | Papel | Campos críticos recomendados |
|---|---|---|
| `provider_webhook_events` | Registro bruto e deduplicado do webhook recebido. | `id`, `provider_name`, `provider_event_id`, `raw_payload`, `raw_payload_hash`, `headers_redacted`, `received_at`, `signature_valid`, `dedupe_key`, `processing_status`. |
| `provider_webhook_processing_attempts` | Histórico de tentativas de processamento. | `event_id`, `attempt_number`, `started_at`, `finished_at`, `error_code`, `error_message`, `worker_id`. |
| `provider_transaction_references` | Mapeamento entre transação CashYin e IDs externos do provider. | `cashyin_transaction_id`, `provider_name`, `provider_transaction_id`, `provider_end_to_end_id`, `operation_type`. |
| `outbox_events` | Eventos CashYin para clientes e integrações internas. | `event_type`, `aggregate_id`, `payload`, `status`, `attempt_count`, `next_attempt_at`. |

As constraints devem impedir duplicidade por `provider_name + provider_event_id` quando o provider fornece ID estável. Quando não houver ID confiável, usar `provider_name + raw_payload_hash + provider_transaction_id + provider_event_type + occurred_at` como dedupe key, reconhecendo que essa deduplicação é menos perfeita e precisa ser documentada por provider.

## 10. Segurança e confiabilidade

A segurança deve combinar borda, transporte, aplicação e domínio. A Cloudflare ajuda na proteção HTTP, mas não substitui validação criptográfica do webhook no backend. O backend precisa validar assinatura com `rawBody`, proteger contra replay com timestamp quando o provider oferece esse dado, aplicar rate limit por provider e registrar eventos inválidos de forma segura.

| Risco | Controle recomendado | Onde implementar |
|---|---|---|
| Webhook falso | Validação HMAC/JWT/RSA conforme provider, usando raw body. | Adapter do provider. |
| Replay attack | Timestamp assinado, janela de tolerância e dedupe key. | Adapter + banco. |
| Evento duplicado | Constraint única e resposta idempotente. | Banco + ingress. |
| Evento fora de ordem | Máquina de estados com transições válidas e comparação temporal. | Processor de domínio. |
| Timeout do provider | Resposta rápida após persistência. | Ingress. |
| Duplicidade financeira | Idempotência por transação, ledger com constraints e transições atômicas. | Processor + banco. |
| Exposição da origem | Proxy Cloudflare, firewall aceitando ranges Cloudflare, origem privada quando possível. | Infraestrutura. |
| Vazamento de segredo | Nunca usar segredo em query string; redigir headers sensíveis. | Ingress + logs. |

## 11. Observabilidade e auditoria

Para evitar prejuízo financeiro, cada evento recebido de provider deve ser rastreável desde a entrada HTTP até a alteração de status, ledger e eventual webhook enviado ao cliente. Isso exige correlação por `request_id`, `provider_event_id`, `provider_transaction_id`, `cashyin_transaction_id` e `outbox_event_id`.

| Métrica/Log | Finalidade | Alerta recomendado |
|---|---|---|
| Taxa de webhooks inválidos por provider | Detectar segredo incorreto, ataque ou mudança de assinatura. | Aumento abrupto ou sequência de 401/403. |
| Tempo de resposta do ingress | Garantir que providers não façam retry por timeout. | P95 acima do limite acordado. |
| Lag de processamento | Detectar fila acumulada. | Eventos pendentes acima de limite por mais de N minutos. |
| Duplicados recebidos | Medir comportamento de retry do provider. | Aumento anormal pode indicar instabilidade. |
| Eventos em DLQ | Detectar parsing quebrado ou divergência de contrato. | Qualquer evento financeiro em DLQ deve gerar alerta. |
| Divergência status provider x CashYin | Detectar normalização incorreta. | Transições rejeitadas ou inconsistentes. |

## 12. Plano de implementação por fases

A implementação deve ser incremental, com entregas auditáveis e validação em ambiente sandbox antes de produção. O objetivo é reduzir risco e permitir integração progressiva com providers.

| Fase | Entrega | Critério de aceite |
|---|---|---|
| 1. Infra DNS e egress | `api.cashyin.com` configurado, TLS ativo, NAT com IP fixo por ambiente. | Health check público funcionando; chamada outbound confirma IP esperado; provider cadastra IP. |
| 2. Boundary de ingress | Criar `provider-webhook-ingress` como processo/deployment separado ou rota isolada com feature flag. | Recebe webhook, valida assinatura, persiste raw payload e responde `202/200` sem aplicar domínio. |
| 3. Modelo de dados | Evoluir tabelas de eventos, tentativas, dedupe e referências provider. | Constraints e migrations revisadas; testes de duplicidade passando. |
| 4. Adapters por provider | Separar `verify`, `parse` e `normalize` por provider. | Testes fixtures reais/sanitizados por provider cobrem cash_in e cash_out. |
| 5. Processor assíncrono | Worker aplica transições idempotentes e grava outbox. | Eventos repetidos não duplicam saldo, tarifa, ledger ou status. |
| 6. Dispatch para clientes | Entrega de webhooks CashYin normalizados com retry e assinatura. | Cliente recebe payload padronizado; falhas entram em retry/DLQ. |
| 7. Observabilidade | Dashboards, logs estruturados, alertas e runbooks. | Operação consegue rastrear um evento ponta a ponta em produção. |
| 8. Hardening produção | Rate limits por provider, WAF rules, firewall de origem e testes de carga. | Teste de carga e simulação de retries não causam inconsistência financeira. |

## 13. Recomendação final: core-api ou sistema separado?

A recomendação é **não criar um microsserviço totalmente separado agora**, mas também **não deixar tudo no mesmo processo crítico do core-api**. O melhor desenho é usar o mesmo repositório e domínio compartilhado, com processos/deployments separados: `core-api`, `provider-webhook-ingress`, `provider-webhook-processor` e `webhook-dispatcher`.

Esse modelo preserva velocidade de implementação, reuso de migrations, contratos e domínio, mas permite isolar escala, logs, rate limits e falhas. Se o volume crescer ou surgirem requisitos regulatórios, o `provider-webhook-ingress` pode ser extraído para um serviço independente sem reescrever os adapters, desde que os contratos propostos sejam respeitados.

## 14. Checklist para informar aos providers

Antes de habilitar produção com cada provider, o CashYin deve ter um checklist padronizado de credenciais, URLs e IPs.

| Item | Valor recomendado | Observação |
|---|---|---|
| IPs de saída produção | IP(s) fixo(s) do NAT de produção | Informar todos os IPs se houver pool. |
| IPs de saída sandbox | IP fixo do NAT sandbox | Nunca misturar com produção. |
| URL geral de webhook | `https://api.cashyin.com/v1/providers/{provider}/webhooks` | Usar quando provider aceita uma única URL. |
| URL Cash-In | `https://api.cashyin.com/v1/providers/{provider}/webhooks/cash-in` | Usar quando provider permite separar eventos. |
| URL Cash-Out | `https://api.cashyin.com/v1/providers/{provider}/webhooks/cash-out` | Usar quando provider permite separar eventos. |
| Segredo de webhook | Gerado por ambiente/provider | Armazenar em secret manager, não em código. |
| Método de assinatura | HMAC/JWT/RSA conforme provider | Documentar canonical string e headers assinados. |
| Ambiente | Sandbox ou produção | URLs, IPs e segredos devem ser separados. |

## 15. Referências

[1]: https://docs.aws.amazon.com/vpc/latest/userguide/vpc-nat-gateway.html "AWS VPC NAT Gateway"  
[2]: https://cloud.google.com/run/docs/configuring/static-outbound-ip "Google Cloud Run static outbound IP"  
[3]: https://developers.cloudflare.com/dns/proxy-status/ "Cloudflare DNS proxy status"  
[4]: https://developers.cloudflare.com/fundamentals/concepts/cloudflare-ip-addresses/ "Cloudflare IP addresses"  
[5]: https://cloudevents.io/ "CloudEvents specification"  
