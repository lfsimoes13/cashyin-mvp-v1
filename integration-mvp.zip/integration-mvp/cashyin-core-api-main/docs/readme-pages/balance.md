---
title: "Balance"
excerpt: "Check your account balance"
category: "API Reference"
---

Returns the current balance of your account.

```
GET /v1/balance
```

### Headers

| Header | Type | Required | Description |
|--------|------|----------|-------------|
| `Authorization` | string | Yes | `Bearer {api_key}` |

> Requires the `balance:read` scope (included in the default key scope set).

### Response — `200 OK`

```json
{
  "available_balance": 150000,
  "blocked_balance": 7515,
  "total_balance": 157515,
  "currency": "BRL",
  "updated_at": "2026-05-29T14:30:00.000Z"
}
```

| Field | Type | Description |
|-------|------|-------------|
| `available_balance` | integer | Funds available to spend, in **cents**. |
| `blocked_balance` | integer | Funds reserved for in-flight cash-outs, in **cents**. |
| `total_balance` | integer | `available_balance + blocked_balance`, in **cents**. |
| `currency` | string | Always `"BRL"`. |
| `updated_at` | string | ISO 8601 timestamp of the last balance change. |

> 📘 All amounts are integer **cents**. `blocked_balance` reflects amounts reserved while cash-out transfers are processing; when a transfer completes the reservation is released, and when it fails or is returned the amount moves back into `available_balance`.

---

## Example

```bash
curl -X GET "http://api.cashyin.com/v1/balance" \
  -H "Authorization: Bearer ck_your_api_key_here"
```
