---
title: "Pix Cash-in (Receiving)"
excerpt: "Create Pix QR Code charges and look up cash-in transactions"
category: "API Reference"
---

The cash-in endpoints let you generate Pix charges via QR Code and look up receiving transactions.

---

## Create a Cash-in Charge

Generates a Pix QR Code charge so a payer can pay you.

```
POST /v1/pix/cash-in/qrcode
```

### Headers

| Header | Type | Required | Description |
|--------|------|----------|-------------|
| `Authorization` | string | Yes | `Bearer {api_key}` |
| `Content-Type` | string | Yes | `application/json` |

> 📘 Cash-in does **not** use an `Idempotency-Key` header. See [Retry Safety](#retry-safety) below.

### Body

```json
{
  "external_ref": "order-12345",
  "amount": 15000,
  "description": "Order #12345"
}
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `external_ref` | string | **Yes** | Your own reference for this charge (1–120 chars). Maps to exactly one charge per account. |
| `amount` | integer | **Yes** | Charge amount in **cents** (positive, up to `100000000`). |
| `description` | string | No | Free-text description (max 140 chars). |

### Response — `201 Created`

On creation, only the fields known at charge time are returned. The `payer`
block and `paid_at` are **omitted** (not `null`) until the payment settles, and
`pix.e2e_id` only appears once a payment is confirmed.

```json
{
  "txid": "2bfe903bb8c94121ac9be074c92062f4",
  "external_ref": "order-12345",
  "amount": 15000,
  "pix": {
    "emv": "00020101021226850014br.gov.bcb.pix2563qrcode.example.com/pix/ff552266...",
    "expires_at": "2026-05-29T20:30:00.000Z"
  },
  "status": "pending",
  "description": "Order #12345",
  "created_at": "2026-05-29T19:30:00.000Z"
}
```

Once the charge is **paid**, the same shape gains `pix.e2e_id`, the `payer`
block and `paid_at`:

```json
{
  "txid": "2bfe903bb8c94121ac9be074c92062f4",
  "external_ref": "order-12345",
  "amount": 15000,
  "pix": {
    "emv": "00020101021226850014br.gov.bcb.pix2563qrcode.example.com/pix/ff552266...",
    "expires_at": "2026-05-29T20:30:00.000Z",
    "e2e_id": "E4397869720260529014139827217069"
  },
  "payer": {
    "name": "ALICE SOUZA",
    "document_number": "***456789**",
    "bank_name": "Banco Exemplo",
    "bank_ispb": "12345678",
    "branch": null,
    "account": null,
    "account_type": null
  },
  "status": "paid",
  "description": "Order #12345",
  "paid_at": "2026-05-29T19:35:12.000Z",
  "created_at": "2026-05-29T19:30:00.000Z"
}
```

| Field | Type | Description |
|-------|------|-------------|
| `txid` | string | CashYin-generated public Pix transaction id. **Use this to look up the charge.** |
| `amount` | integer | Charge amount in cents. |
| `external_ref` | string | Your reference, echoed back. |
| `pix` | object | Pix charge details — see [Pix object](#pix-object). |
| `status` | string | Charge status. See [Statuses](#cash-in-statuses). |
| `description` | string \| null | Description, echoed back. |
| `payer` | object | Real payer details. **Omitted** until paid. See [Payer](#payer-object). |
| `paid_at` | string | ISO 8601 payment timestamp. **Omitted** until paid. |
| `created_at` | string | ISO 8601 creation timestamp. |

### Pix object

| Field | Type | Description |
|-------|------|-------------|
| `emv` | string \| null | Pix copy-and-paste code (EMV / BR Code). |
| `expires_at` | string | ISO 8601 expiry of the QR Code. Omitted when not applicable. |
| `e2e_id` | string | Pix End-to-End id. **Omitted** until the payment is confirmed. |

### Payer object

The `payer` object is **omitted** on creation and is filled in automatically once the payment is confirmed, with the details of whoever actually paid.

| Field | Type | Description |
|-------|------|-------------|
| `name` | string \| null | Payer name. |
| `document_number` | string \| null | Payer document number. |
| `bank_name` | string \| null | Payer's bank name. |
| `bank_ispb` | string \| null | Payer's bank ISPB code. |
| `branch` | string \| null | Payer's bank branch. |
| `account` | string \| null | Payer's bank account. |
| `account_type` | string \| null | Payer's bank account type. |

### Cash-in statuses

| Status | Description |
|--------|-------------|
| `pending` | QR Code generated, awaiting payment. |
| `paid` | Payment confirmed — net amount credited to your balance. |
| `expired` | QR Code expired without payment. |
| `cancelled` | Charge cancelled. |
| `failed` | Processing failure. |
| `refunded` | Payment refunded. |

### Retry Safety

Cash-in does not use an `Idempotency-Key` header. Instead, retry safety is provided by `external_ref`:

- A given `external_ref` maps to **exactly one charge** for your account.
- Re-sending `POST /v1/pix/cash-in/qrcode` with the same `external_ref` returns the **original charge** (same `txid`, `201`), without creating a duplicate Pix charge.

> 📘 Any `Idempotency-Key` header you happen to send on cash-in is silently ignored — it is never read, validated, persisted or forwarded.

---

## Look Up a Cash-in Charge

Fetch a single charge by its `txid`.

```
GET /v1/pix/cash-in/{txid}
```

### Path parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `txid` | string | The `txid` returned when the charge was created. |

### Response — `200 OK`

Returns the same object shape as the create response (see above), reflecting the current status.

### Response — `404 Not Found`

Returned when the `txid` does not exist or belongs to another account.

```json
{
  "error": {
    "code": "charge_not_found",
    "message": "No charge found for txid=2bfe903bb8c94121ac9be074c92062f4",
    "request_id": "req-abc123"
  }
}
```

---

## Full Flow

```
1. POST /v1/pix/cash-in/qrcode   → 201 (status: pending, pix.emv generated)
2. Payer scans and pays
3. Webhook pix.cash_in.paid       → net amount credited automatically
4. GET /v1/pix/cash-in/{txid}     → 200 (status: paid, pix.e2e_id and payer populated)
```

---

## Example

```bash
curl -X POST "http://api.cashyin.com/v1/pix/cash-in/qrcode" \
  -H "Authorization: Bearer ck_your_api_key_here" \
  -H "Content-Type: application/json" \
  -d '{
    "external_ref": "order-12345",
    "amount": 15000,
    "description": "Order #12345"
  }'
```

---

## Specific Errors

| HTTP | Code | Scenario |
|------|------|----------|
| `422` | `validation_error` | Missing or invalid body fields. |
| `422` | `provider_assignment_not_found` | No active provider is configured for your account. |
| `404` | `charge_not_found` | `txid` not found (lookup). |
| `502` / `504` | `provider_request_failed` / `provider_timeout` | Failure communicating with the payment rail. |

See the [Errors](errors) page for the full reference.
