# CashYin API — Public Documentation

Client-facing reference for the CashYin Pix API. These pages describe the **public contract** only: public endpoints, public payloads, public errors, and outbound webhooks delivered to your endpoint.

> These are the **current** docs. `docs/examples/readme-pages/` is kept only as historical reference from a previous product and must not be treated as the current contract.

## Pages

| Page | Category | Contents |
|------|----------|----------|
| [API Overview](api-overview.md) | Getting Started | Base URL, conventions, fees, error format |
| [Authentication](authentication.md) | Getting Started | Bearer API key |
| [Pix Cash-in](pix-cash-in.md) | API Reference | Create QR charge, look up by `txid` |
| [Pix Cash-out](pix-cash-out.md) | API Reference | Create transfer, look up by `id`, idempotency |
| [Balance](balance.md) | API Reference | Account balance |
| [Webhooks Integration](webhooks-integration.md) | Webhooks | Setup, signature, `pix.cash_in.*` / `pix.cash_out.*` events, payloads, retries |
| [Errors](errors.md) | API Reference | Error envelope and codes |

## OpenAPI

The machine-readable API reference (importable into ReadMe / Swagger UI / Redoc) lives at
[`../openapi/cashyin-api-reference.yaml`](../openapi/cashyin-api-reference.yaml). It covers the same
public endpoints and webhook payloads as these pages.

## Contract highlights

- **Base URL:** `http://api.cashyin.com/v1`
- **Auth:** `Authorization: Bearer ck_...`
- **Money:** integer BRL cents
- **Pix End-to-End id:** always `e2e_id` (public contract)
- **Cash-in:** no `Idempotency-Key`; retry-safe via `external_ref`
- **Cash-out:** requires `Idempotency-Key`
- **Fees:** never exposed in the cash-out contract — clients see only the Pix `amount`; no fee, cost or margin composition is returned in responses or webhooks
- **Webhook signature:** `x-cashyin-signature: sha256=<hmac-sha256(raw_body, signing_secret)>`
