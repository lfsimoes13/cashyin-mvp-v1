---
title: "Webhooks Integration"
excerpt: "Configure and integrate outbound webhooks to receive real-time Pix notifications from CashYin"
category: "Webhooks"
---

Webhooks let your system receive real-time HTTP notifications whenever events occur in your CashYin account — such as confirmed Pix cash-in payments, completed cash-outs, and terminal charge states.

Instead of polling the API for status changes, CashYin POSTs event data to your endpoint as soon as it happens.

---

## How It Works

1. Your **webhook URL** and **signing secret** are configured for your account (during onboarding / provisioning).
2. When an event occurs (e.g. a Pix payment is confirmed), CashYin sends an **HTTP POST** to your URL with a JSON body.
3. Your server **validates the signature**, processes the notification, and returns **HTTP 2xx**.
4. If delivery fails, CashYin **retries automatically** with exponential backoff; exhausted deliveries go to a dead-letter queue for follow-up.

```text
Charge created (API)     →  no webhook (status: pending)
Payment confirmed        →  POST pix.cash_in.paid
Your server returns 2xx  →  delivery acknowledged
```

> 📘 Cash-in charges in `pending` are **not** sent as webhooks. You already have the QR Code from `POST /v1/pix/cash-in/qrcode`.

---

## Step 1 — Configure Your Endpoint

Webhook delivery is configured **per account** by the CashYin operations team (not via a public self-service API). You provide:

| Item | Description |
|------|-------------|
| **Target URL** | HTTPS endpoint that accepts `POST` requests |
| **Events** | Which notifications to receive (e.g. all `pix.cash_in.*` and `pix.cash_out.*`, or a subset) |
| **Signing secret** | Shared secret used to verify `x-cashyin-signature` |

When your endpoint is provisioned, you receive a signing secret in the format:

```text
whk_<64 hexadecimal characters>
```

> ⚠️ **Store the signing secret securely** as soon as you receive it. Treat it like a password — anyone with the secret can forge plausible webhook payloads if they guess your URL.

### Endpoint requirements

Your endpoint must:

- ✅ Accept **HTTP POST**
- ✅ Use **HTTPS**
- ✅ Respond with **HTTP 2xx** within a few seconds
- ✅ Verify **`x-cashyin-signature`** on every request
- ✅ Process events **idempotently** (at-least-once delivery)

---

## Step 2 — Validate Signatures

Every webhook delivery includes an HMAC signature in the request headers.

| Header | Description |
|--------|-------------|
| `Content-Type` | `application/json` |
| `x-cashyin-signature` | `sha256=<hex>` — HMAC-SHA256 of the **raw request body** using your signing secret |

### How signing works

1. Read the **raw request body bytes** (before JSON parsing).
2. Compute `HMAC-SHA256(signing_secret, raw_body)`.
3. Format the digest as `sha256=<lowercase hex>`.
4. Compare with the `x-cashyin-signature` header using a **constant-time** comparison.

> ⚠️ Always use the **raw body**. Re-serializing JSON can change field order or whitespace and break verification.

```javascript
const crypto = require('crypto');

function verifyCashYinWebhook(rawBody, signatureHeader, signingSecret) {
  const expected =
    'sha256=' + crypto.createHmac('sha256', signingSecret).update(rawBody).digest('hex');

  if (!signatureHeader || !signatureHeader.startsWith('sha256=')) {
    return false;
  }

  try {
    return crypto.timingSafeEqual(
      Buffer.from(signatureHeader),
      Buffer.from(expected)
    );
  } catch {
    return false;
  }
}

// Express example — use raw body parser
app.post(
  '/webhooks/cashyin',
  express.raw({ type: 'application/json' }),
  (req, res) => {
    const signature = req.headers['x-cashyin-signature'];
    if (!verifyCashYinWebhook(req.body, signature, process.env.CASHYIN_WEBHOOK_SECRET)) {
      return res.status(401).send('invalid signature');
    }

    const event = JSON.parse(req.body.toString());

    // Acknowledge immediately; process async
    res.status(200).send('ok');

    processWebhookAsync(event).catch(console.error);
  }
);
```

```python
import hmac
import hashlib

def verify_cashyin_webhook(raw_body: bytes, signature_header: str, signing_secret: str) -> bool:
    expected = 'sha256=' + hmac.new(
        signing_secret.encode(),
        raw_body,
        hashlib.sha256
    ).hexdigest()

    if not signature_header or not signature_header.startswith('sha256='):
        return False

    return hmac.compare_digest(signature_header, expected)
```

---

## Supported Events

### Pix Cash-in Events

The `pending` status is **not** webhooked (the charge was just created via the API).

| Event | Description |
|-------|-------------|
| `pix.cash_in.paid` | Payment confirmed — **net amount credited** to your balance (after fee). **Most important event.** |
| `pix.cash_in.expired` | QR Code expired without payment |
| `pix.cash_in.cancelled` | Charge was cancelled |
| `pix.cash_in.failed` | Processing failure |
| `pix.cash_in.refunded` | Payment was refunded |

**Typical flow:**

```text
(API: charge created, pending)  →  pix.cash_in.paid
```

**Alternative flows:**

```text
pix.cash_in.expired
pix.cash_in.cancelled
pix.cash_in.failed
pix.cash_in.paid  →  pix.cash_in.refunded
```

### Pix Cash-out Events

Cash-out webhooks notify you of **terminal** transfer states only. The
intermediate `processing` stage is **not** delivered as a webhook — query
`GET /v1/pix/cash-out/{id}` if you need the in-flight status.

| Event | Description |
|-------|-------------|
| `pix.cash_out.completed` | Transfer settled successfully |
| `pix.cash_out.failed` | Transfer failed — **amount returned** to your balance |
| `pix.cash_out.returned` | Transfer returned by the rail — **amount returned** to your balance |

**Typical flow:**

```text
(API: cash-out created, processing — no webhook)  →  pix.cash_out.completed
```

**On failure:**

```text
pix.cash_out.failed
pix.cash_out.returned
```

> 📘 `pix.cash_out.processing` is **not** sent to clients. You receive a
> webhook only once the transfer reaches a final state
> (`completed` / `failed` / `returned`).

---

## Notification Payload

Every delivery is an HTTP POST with `Content-Type: application/json`. All events share the same **envelope**; the `data` object shape depends on the operation type.

### Envelope

```json
{
  "id": "evt_ob_0001",
  "event": "pix.cash_in.paid",
  "schema_version": "2026-06-01",
  "timestamp": "2026-05-29T19:45:00.000Z",
  "data": { }
}
```

| Field | Type | Description |
|-------|------|-------------|
| `id` | string | Unique event id (prefix `evt_`). **Stable across retries** — use for idempotency. |
| `event` | string | Event name, e.g. `pix.cash_in.paid`. |
| `schema_version` | string | Payload schema version (currently `"2026-06-01"`). |
| `timestamp` | string | ISO 8601 UTC when the event was emitted. |
| `data` | object | Transaction snapshot at event time (see below). |

The `data` object uses the **same shape** as the REST responses (nested `pix`
and `receiver`/`payer` blocks, no `type` field, null fields omitted).

### Cash-in `data` object

| Field | Type | Description |
|-------|------|-------------|
| `txid` | string | CashYin public Pix transaction id (lookup key). |
| `amount` | integer | Charge amount in **cents**. |
| `external_ref` | string | Your reference from `POST /v1/pix/cash-in/qrcode`. |
| `pix` | object | Pix charge details (`emv`, `expires_at`, `e2e_id`). |
| `status` | string | `paid`, `expired`, `cancelled`, `failed`, or `refunded`. |
| `payer` | object | Real payer block (see below). **Omitted** until paid. |
| `paid_at` | string | ISO 8601 payment timestamp. **Omitted** until paid. |
| `created_at` | string | ISO 8601 creation timestamp. |
| `description` | string \| null | Description from creation. |

**`pix` object:**

| Field | Type | Description |
|-------|------|-------------|
| `emv` | string \| null | Pix copy-and-paste (EMV) code. |
| `expires_at` | string | ISO 8601 QR Code expiry. Omitted when not applicable. |
| `e2e_id` | string | Pix End-to-End id. **Omitted** until paid. |

**`payer` object** (populated when the payment is confirmed):

| Field | Type | Description |
|-------|------|-------------|
| `name` | string \| null | Payer name. |
| `document_number` | string \| null | Payer document. |
| `bank_name` | string \| null | Payer's bank name. |
| `bank_ispb` | string \| null | Payer's bank ISPB. |
| `branch` | string \| null | Payer's bank branch. |
| `account` | string \| null | Payer's bank account. |
| `account_type` | string \| null | Payer's bank account type. |

### Cash-out `data` object

| Field | Type | Description |
|-------|------|-------------|
| `id` | string (UUID) | Cash-out identifier (lookup key). |
| `external_ref` | string \| null | Your reference from `POST /v1/pix/cash-out` (`null` if omitted). |
| `status` | string | `completed`, `failed`, or `returned` (cash-out webhooks are terminal-only). |
| `amount` | integer | Transfer amount in **cents**. |
| `currency` | string | Always `"BRL"`. |
| `pix` | object | Pix destination block (`key`, `key_type`, `e2e_id`). |
| `receiver` | object | **Canonical** receiver block. Always present; children are `null` until the provider reports them. See below. |
| `created_at` | string | ISO 8601 creation timestamp. |
| `completed_at` | string | Present only on `pix.cash_out.completed`. |
| `failed_at` | string | Present only on `pix.cash_out.failed`. |
| `returned_at` | string | Present only on `pix.cash_out.returned`. |
| `failure_reason` | string | Why the transfer did not settle (e.g. `provider_rejected`). Present only on `failed`/`returned`. |

**`pix` object:**

| Field | Type | Description |
|-------|------|-------------|
| `key` | string | Destination Pix key. |
| `key_type` | string | Key type (`CPF`, `CNPJ`, `EMAIL`, `PHONE`, `EVP`). |
| `e2e_id` | string | Pix End-to-End id (present once known; for async providers it may arrive on the confirming webhook). |

**`receiver` object** (canonical; always present with nullable children):

| Field | Type | Description |
|-------|------|-------------|
| `name` | string \| null | Receiver name. |
| `document_number` | string \| null | Receiver CPF/CNPJ (exactly as the provider sends it — already masked). |
| `bank_name` | string \| null | Receiver bank name. |
| `bank_ispb` | string \| null | Receiver bank ISPB. |
| `branch` | string \| null | Receiver bank branch. |
| `account` | string \| null | Receiver account. |
| `account_type` | string \| null | Receiver account type. |

> 📘 Only the terminal timestamp matching the event is included. `processing` events have no `completed_at` / `failed_at` / `returned_at`. The cash-out `data` never exposes fee, cost or margin composition — `amount` is the Pix amount you requested. Receiver identity is exposed only inside the nested `receiver` object — there are no flat `receiver_name` / `receiver_document` fields, and there is no top-level `type` field.

### Transaction statuses in payloads

**Cash-in (`data.status`):**

| Status | Description |
|--------|-------------|
| `paid` | Payment confirmed |
| `expired` | QR Code expired |
| `cancelled` | Charge cancelled |
| `failed` | Processing failure |
| `refunded` | Refunded after payment |

**Cash-out (`data.status`):** webhooks are sent for terminal states only.

| Status | Description |
|--------|-------------|
| `completed` | Settled successfully |
| `failed` | Failed — balance returned |
| `returned` | Returned — balance returned |

> 📘 `processing` is an internal in-flight state visible via
> `GET /v1/pix/cash-out/{id}`, but it is never delivered as a webhook.

---

## Payload Examples

### `pix.cash_in.paid`

Use this event to fulfil orders and release goods or services. The **net amount** (charge amount minus the R$ 0.15 fee) is credited when this event fires.

```json
{
  "id": "evt_ob_0001",
  "event": "pix.cash_in.paid",
  "schema_version": "2026-06-01",
  "timestamp": "2026-05-29T19:45:00.000Z",
  "data": {
    "txid": "2bfe903bb8c94121ac9be074c92062f4",
    "amount": 15000,
    "external_ref": "order-12345",
    "pix": {
      "emv": "00020101021226850014br.gov.bcb.pix...",
      "expires_at": "2026-05-29T20:30:00.000Z",
      "e2e_id": "E0000000020260529194500abcdef01"
    },
    "status": "paid",
    "payer": {
      "name": "Maria Souza",
      "document_number": "98765432100",
      "bank_name": "Banco Example S.A.",
      "bank_ispb": "20855875",
      "branch": "0001",
      "account": "12345-6",
      "account_type": null
    },
    "paid_at": "2026-05-29T19:45:00.000Z",
    "created_at": "2026-05-29T19:30:00.000Z",
    "description": "Order #12345"
  }
}
```

### `pix.cash_in.expired`

```json
{
  "id": "evt_ob_0002",
  "event": "pix.cash_in.expired",
  "schema_version": "2026-06-01",
  "timestamp": "2026-05-30T20:30:01.000Z",
  "data": {
    "txid": "2bfe903bb8c94121ac9be074c92062f4",
    "amount": 15000,
    "external_ref": "order-12345",
    "pix": {
      "emv": "00020101021226850014br.gov.bcb.pix...",
      "expires_at": "2026-05-29T20:30:00.000Z"
    },
    "status": "expired",
    "created_at": "2026-05-29T19:30:00.000Z",
    "description": "Order #12345"
  }
}
```

### `pix.cash_out.completed`

```json
{
  "id": "evt_ob_co_0001",
  "event": "pix.cash_out.completed",
  "schema_version": "2026-06-01",
  "timestamp": "2026-05-29T19:55:00.000Z",
  "data": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "external_ref": "payout-9876",
    "status": "completed",
    "amount": 7500,
    "currency": "BRL",
    "pix": {
      "key": "60311124000110",
      "key_type": "CNPJ",
      "e2e_id": "E0000000020260529195500cashout01"
    },
    "receiver": {
      "name": "Alice Souza",
      "document_number": "60311124000110",
      "bank_name": "A55 SCD S.A.",
      "bank_ispb": "48756121",
      "branch": null,
      "account": null,
      "account_type": null
    },
    "created_at": "2026-05-29T19:30:00.000Z",
    "completed_at": "2026-05-29T19:55:00.000Z"
  }
}
```

### `pix.cash_out.failed`

```json
{
  "id": "evt_ob_co_0002",
  "event": "pix.cash_out.failed",
  "schema_version": "2026-06-01",
  "timestamp": "2026-05-29T19:55:00.000Z",
  "data": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "external_ref": "payout-9876",
    "status": "failed",
    "amount": 7500,
    "currency": "BRL",
    "pix": {
      "key": "60311124000110",
      "key_type": "CNPJ"
    },
    "receiver": {
      "name": "Alice Souza",
      "document_number": "60311124000110",
      "bank_name": null,
      "bank_ispb": null,
      "branch": null,
      "account": null,
      "account_type": null
    },
    "created_at": "2026-05-29T19:30:00.000Z",
    "failed_at": "2026-05-29T19:55:00.000Z",
    "failure_reason": "provider_rejected"
  }
}
```

> 🚧 On `pix.cash_out.failed` or `pix.cash_out.returned`, the transfer amount is **returned automatically** to your available balance.

---

## Automatic Retries

CashYin delivers webhooks **at least once**. If your endpoint returns a non-2xx status, times out, or is unreachable, the delivery is retried with exponential backoff.

**Counted as failure:**

- HTTP status outside `2xx`
- Request timeout
- Network error (connection refused, DNS failure, etc.)

**Counted as success:**

- HTTP `2xx`

| Phase | Behaviour |
|-------|-----------|
| Initial delivery | Immediate POST after the domain event is enqueued |
| Retries | Exponential backoff (base ~30s, cap ~1 hour) |
| Max attempts | **8** attempts per delivery |
| After exhaustion | Event moves to **dead-letter** (`dlq`) for manual follow-up |

> 📘 The same event may arrive more than once. Always deduplicate using the envelope `id` (`evt_*`).

---

## Best Practices

1. **Always validate signatures** — Reject any request where `x-cashyin-signature` does not match the raw body.
2. **Return HTTP 2xx quickly** — Acknowledge first; run business logic asynchronously. Slow handlers cause unnecessary retries.
3. **Handle duplicates** — Store processed `evt_*` ids (24h TTL is usually enough) before side effects.
4. **Branch on `event`, not only `data.status`** — The `event` field is the canonical notification type.
5. **Use `pix.e2e_id` for bank reconciliation** — Present on paid cash-in and completed cash-out; never confuse it with `txid` (cash-in only).
6. **Do not expose the signing secret** — Keep `whk_...` in server-side env vars only.
7. **Use HTTPS** — Plain HTTP endpoints are not suitable for production webhook URLs.
8. **Test with real-shaped payloads** — Use the examples above in a staging receiver before going live.

### Idempotency example

```javascript
async function processWebhookAsync(event) {
  const key = `webhook:${event.id}`;
  if (await cache.get(key)) return;

  switch (event.event) {
    case 'pix.cash_in.paid':
      await fulfilOrder(event.data);
      break;
    case 'pix.cash_out.completed':
      await markPayoutComplete(event.data);
      break;
    case 'pix.cash_out.failed':
    case 'pix.cash_out.returned':
      await markPayoutFailed(event.data);
      break;
    // handle other events as needed
  }

  await cache.set(key, true, 86_400);
}
```

---

## Related Documentation

- [Pix Cash-in API](pix-cash-in) — create charges and look up by `txid`
- [Pix Cash-out API](pix-cash-out) — create transfers and look up by `id`
- [API Overview](api-overview) — authentication, fees, and conventions
