---
title: "API Overview"
excerpt: "Everything you need to start integrating with the CashYin API"
category: "Getting Started"
---

The **CashYin API** lets your application receive and send money over Pix programmatically. With it you can generate Pix charges (QR Code) to receive payments (cash-in), send Pix transfers from your balance (cash-out), check your balance, and track every transaction in real time through outbound webhooks.

---

## Quick Start

To start using the API you need:

1. **An API key** — a single bearer credential issued for your account.
2. **A webhook URL** — so your system is notified in real time about transaction status changes.

> 📘 **First integration?**
>
> Read the [Authentication](authentication) page to configure your API key before you begin.

---

## Base URL

| Environment | Base URL |
|-------------|----------|
| **Production** | `http://api.cashyin.com/v1` |

All endpoint paths are relative to the base URL. For example:

```
POST http://api.cashyin.com/v1/pix/cash-in/qrcode
GET  http://api.cashyin.com/v1/balance
```

---

## Core Features

### Pix Cash-in (receiving)

Generate Pix charges and receive payments directly into your balance.

| Endpoint | Description |
|----------|-------------|
| `POST /v1/pix/cash-in/qrcode` | Create a Pix QR Code charge |
| `GET /v1/pix/cash-in/{txid}` | Look up a charge by its `txid` |

**Summary flow:**

```
1. POST /v1/pix/cash-in/qrcode  → QR Code generated (status: pending)
2. Payer scans and pays the QR Code
3. Webhook pix.cash_in.paid      → Net amount credited to your balance
```

See [Pix Cash-in — API Reference](pix-cash-in) for full details.

### Pix Cash-out (sending)

Send money to any Pix key from your account balance.

| Endpoint | Description |
|----------|-------------|
| `POST /v1/pix/cash-out` | Create a Pix transfer to a destination key |
| `GET /v1/pix/cash-out/{id}` | Look up a cash-out by its `id` |

**Summary flow:**

```
1. POST /v1/pix/cash-out        → Amount + fee debited (status: processing)
2. Pix rail processes the transfer
3. Webhook pix.cash_out.completed → Transfer sent successfully
```

> 🚧 **Important**
>
> If a cash-out fails (`failed` or `returned`), the amount is **returned automatically** to your balance.

See [Pix Cash-out — API Reference](pix-cash-out) for full details.

### Balance

Check your available balance at any time.

| Endpoint | Description |
|----------|-------------|
| `GET /v1/balance` | Returns your available, blocked and total balance in cents |

See [Balance — API Reference](balance).

### Webhooks

Receive real-time notifications whenever a transaction status changes.

| Event family | Examples |
|--------------|----------|
| **Cash-in** | `pix.cash_in.paid`, `pix.cash_in.expired`, `pix.cash_in.cancelled`, `pix.cash_in.failed`, `pix.cash_in.refunded` |
| **Cash-out** | `pix.cash_out.processing`, `pix.cash_out.completed`, `pix.cash_out.failed`, `pix.cash_out.returned` |

See [Webhooks Integration](webhooks-integration).

---

## Authentication

Every request to `/v1/*` is authenticated with an **API key** sent as a Bearer token in the `Authorization` header.

```bash
curl -X GET "http://api.cashyin.com/v1/balance" \
  -H "Authorization: Bearer ck_your_api_key_here"
```

> ⚠️ **Security**
>
> Never expose your API key in frontend code (browser JavaScript, mobile apps). The API must be consumed exclusively from your **backend**.

See the [Authentication](authentication) page for details.

---

## API Conventions

### Monetary values

All monetary values are represented in **cents** (integers). This avoids rounding problems with decimal numbers.

| Real value | Value in cents | JSON field |
|------------|----------------|------------|
| R$ 1.00 | `100` | `"amount": 100` |
| R$ 50.00 | `5000` | `"amount": 5000` |
| R$ 100.00 | `10000` | `"amount": 10000` |
| R$ 1,250.99 | `125099` | `"amount": 125099` |

### Currency

The default (and only currently supported) currency is **BRL** (Brazilian Real). The `currency` field always returns `"BRL"`.

### Date and time format

All timestamps use **ISO 8601** in UTC:

```
2026-05-29T07:09:26.615Z
```

### Identifiers

| Identifier | Used by | Description |
|------------|---------|-------------|
| `txid` | Cash-in | CashYin-generated public Pix transaction id. The canonical lookup key for cash-in. |
| `id` | Cash-out | UUID v4. The canonical lookup key for cash-out. |
| `external_ref` | Both | Your own reference (e.g. order id). Returned in lookups and webhooks. |
| `pix.e2e_id` | Both | Pix End-to-End identifier assigned by the Pix rail at settlement. Available (nested under `pix`) once a cash-in is `paid` or a cash-out is `completed`. Use it for bank reconciliation. |

> 📘 The Pix End-to-End identifier is always exposed as **`pix.e2e_id`** (nested under the `pix` block) across the entire public contract (responses and webhooks).

### External reference

The `external_ref` field lets you tie a transaction to an identifier in your own system (order id, invoice number). It is:

- **Required** on cash-in creation; **optional** on cash-out creation.
- **Returned** in lookups and webhooks.
- For cash-in, it is also the **retry-safety key** — see Idempotency below.

### Idempotency

| Flow | Mechanism |
|------|-----------|
| **Cash-in** | Does **not** use an `Idempotency-Key` header. Retry-safety is provided by `external_ref`: a given `external_ref` maps to exactly one charge. Re-sending the same `external_ref` returns the original charge. |
| **Cash-out** | **Requires** an `Idempotency-Key` header. Re-sending the same key with the same body replays the original response; the same key with a different body returns `409`. |

See [Pix Cash-out](pix-cash-out) for the full idempotency behaviour.

---

## Request and Response Format

### Content-Type

All requests with a body (POST) must use `Content-Type: application/json`. All responses are returned as JSON.

### Success response

```json
// POST /v1/pix/cash-in/qrcode → 201 Created
{
  "txid": "2bfe903bb8c94121ac9be074c92062f4",
  "external_ref": "order-12345",
  "amount": 15000,
  "pix": {
    "emv": "00020101021226850014br.gov.bcb.pix...",
    "expires_at": "2026-05-29T20:30:00.000Z"
  },
  "status": "pending",
  "description": "Order #12345",
  "created_at": "2026-05-29T19:30:00.000Z"
}
```

### Error response

All errors follow the same envelope:

```json
{
  "error": {
    "code": "ERROR_CODE",
    "message": "Human-readable description of the error.",
    "request_id": "req-abc123"
  }
}
```

The `request_id` echoes the request identifier and is useful when contacting support. See the [Errors](errors) page for the full list of codes.

---

## Fees

A fixed fee is charged to your account per Pix transaction:

| Operation | Fee charged to you |
|-----------|--------------------|
| Cash-in | **R$ 0.15** (`15` cents) per transaction |
| Cash-out | **R$ 0.15** (`15` cents) per transaction |

- **Cash-in**: the **net amount** (`amount − fee`) is credited to your balance when the payment is confirmed.
- **Cash-out**: the transfer **amount** is debited from your balance when the transfer is created. Any applicable fee is applied internally and is **not** itemised in the cash-out response or webhooks.

> 📘 The cash-out public contract never returns fee, cost or margin fields — you see only the Pix `amount` you requested. No internal pricing composition is ever exposed.

---

## Next Steps

1. **[Authentication](authentication)** — Configure your API key.
2. **[Pix Cash-in](pix-cash-in)** — Create Pix charges and look up transactions.
3. **[Pix Cash-out](pix-cash-out)** — Send Pix transfers and look up transactions.
4. **[Balance](balance)** — Check your account balance.
5. **[Webhooks Integration](webhooks-integration)** — Receive payment and transfer notifications.
6. **[Errors](errors)** — Understand the error format and codes.
