---
title: "Errors"
excerpt: "Error format and codes returned by the CashYin API"
category: "API Reference"
---

All API errors share the same JSON envelope and an appropriate HTTP status code.

---

## Error Format

```json
{
  "error": {
    "code": "validation_error",
    "message": "Invalid PIX charge payload",
    "request_id": "req-abc123"
  }
}
```

| Field | Type | Description |
|-------|------|-------------|
| `code` | string | Stable, machine-readable error code. |
| `message` | string | Human-readable description. |
| `request_id` | string | Identifier of the request. Include it when contacting support. |

> 📘 Always branch your error handling on `error.code`, not on `error.message` (messages may change).

---

## Common Codes

### Authentication

| HTTP | Code | When |
|------|------|------|
| `401` | `unauthorized` | Missing `Authorization` header, non-Bearer scheme, or invalid/revoked API key. |

### Validation

| HTTP | Code | When |
|------|------|------|
| `422` | `validation_error` | The request body failed validation (missing or invalid fields). |
| `400` | `idempotency_key_required` | `Idempotency-Key` header missing on a cash-out request. |

### Cash-out / balance

| HTTP | Code | When |
|------|------|------|
| `422` | `insufficient_funds` | Balance is lower than the amount required for this transfer. |
| `409` | `idempotency_key_conflict` | Same `Idempotency-Key` reused with a different body. |
| `409` | `idempotency_in_progress` | A request with the same `Idempotency-Key` is still being processed. |

### Provider configuration

| HTTP | Code | When |
|------|------|------|
| `422` | `provider_assignment_not_found` | No active payment provider is configured for your account. |

### Not found

| HTTP | Code | When |
|------|------|------|
| `404` | `charge_not_found` | Cash-in `txid` not found or not owned by your account. |
| `404` | `cashout_not_found` | Cash-out `id` not found or not owned by your account. |

### Upstream / processing

| HTTP | Code | When |
|------|------|------|
| `502` | `provider_request_failed` | The payment rail returned an error. |
| `504` | `provider_timeout` | The payment rail did not respond in time. |
| `502` | `provider_network_error` | Network failure reaching the payment rail. |
| `500` | `internal_error` | Unexpected server error. |

---

## Handling Examples

### Validation error — `422`

```json
{
  "error": {
    "code": "validation_error",
    "message": "Invalid cash-out payload",
    "request_id": "req-abc123"
  }
}
```

### Insufficient funds — `422`

```json
{
  "error": {
    "code": "insufficient_funds",
    "message": "Insufficient balance for this cash-out",
    "request_id": "req-abc123"
  }
}
```

### Idempotency conflict — `409`

```json
{
  "error": {
    "code": "idempotency_key_conflict",
    "message": "Idempotency-Key was reused with a different request body",
    "request_id": "req-abc123"
  }
}
```
