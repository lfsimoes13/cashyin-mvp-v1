---
title: "Pix Cash-out (Sending)"
excerpt: "Send Pix transfers from your balance and look up cash-out transactions"
category: "API Reference"
---

The cash-out endpoints let you send Pix transfers to a destination key from your account balance and look up sending transactions.

---

## Create a Cash-out

Creates a Pix transfer to the destination key. The transfer **amount** is debited from your available balance when the transfer is created.

> 📘 All monetary values are integer **BRL cents** in the field `amount` (e.g. `7500` = R$ 75,00). The CashYin public contract never returns a decimal `amount` string nor an `amount_cents` field.

```
POST /v1/pix/cash-out
```

### Headers

| Header | Type | Required | Description |
|--------|------|----------|-------------|
| `Authorization` | string | Yes | `Bearer {api_key}` |
| `Content-Type` | string | Yes | `application/json` |
| `Idempotency-Key` | string | **Yes** | Unique key to make the request retry-safe. See [Idempotency](#idempotency). |

### Body

```json
{
  "external_ref": "payout-9876",
  "amount": 7500,
  "pix": {
    "key_type": "CNPJ",
    "key": "60311124000110"
  },
  "receiver": {
    "name": "Alice Souza",
    "document_number": "60311124000110"
  },
  "description": "Supplier payment"
}
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `external_ref` | string | No | Your own reference for this transfer (1–120 chars). |
| `amount` | integer | **Yes** | Transfer amount in **cents** (positive, up to `100000000`). |
| `pix` | object | **Yes** | Destination Pix key block. |
| `pix.key` | string | **Yes** | Destination Pix key. Must be well-formed for `pix.key_type` — see [Pix key formats](#pix-key-formats). |
| `pix.key_type` | string | **Yes** | Pix key type. One of `CPF`, `CNPJ`, `EMAIL`, `PHONE`, `EVP`. |
| `receiver` | object | No | Receiver identity block. |
| `receiver.name` | string | No | Receiver's name (1–140 chars). |
| `receiver.document_number` | string | No | Receiver's `CPF` (11 digits) or `CNPJ` (14 digits), digits only. |
| `description` | string | No | Free-text description (max 140 chars). |

#### Pix key formats

`pix.key` is validated against `pix.key_type` (BACEN / DICT). A key that does
not match its type is rejected with `422 validation_error` before any balance
is reserved.

| `key_type` | Format | Example |
|------------|--------|---------|
| `CPF` | 11 digits, digits only (`^\d{11}$`) | `12345678901` |
| `CNPJ` | 14 digits, digits only (`^\d{14}$`) | `12345678000199` |
| `PHONE` | E.164: `+` then country code and number (`^\+[1-9]\d{1,14}$`) | `+5511999998888` |
| `EMAIL` | E-mail address (case-insensitive) | `alice@example.com` |
| `EVP` | Random key (lowercase hex UUID) | `f17a24fa-d422-4d66-bfe0-1dd0e565cc1e` |

### Response — `201 Created`

A cash-out resource is **always created** and returned with `201 Created`. The
HTTP status reflects **resource creation**, never payment finality — read the
body `status` (and poll the lookup endpoint) for the canonical current state.
CashYin does not assume how your provider behaves:

- **Synchronous provider** — the transfer may already be `completed`, with
  `pix.e2e_id` and `receiver` populated immediately.
- **Asynchronous provider** — the response is `processing`, with no
  `pix.e2e_id` yet and a `receiver` whose children are `null`; the final status
  (and any missing `pix.e2e_id`/`receiver` detail) arrives later via
  [webhook](webhooks-integration).

The `Location` header carries the canonical lookup URL, e.g.
`Location: /v1/pix/cash-out/550e8400-e29b-41d4-a716-446655440000`.

Null terminal timestamps (`completed_at`, `failed_at`, `returned_at`) are
**omitted** rather than serialized as `null`.

**Synchronous completion:**

```json
{
  "id": "550e8400-e29b-41d4-a716-446655440000",
  "external_ref": "payout-9876",
  "status": "completed",
  "amount": 7500,
  "currency": "BRL",
  "pix": {
    "key": "60311124000110",
    "key_type": "CNPJ",
    "e2e_id": "E0000000020260529195500cashout01"
  },
  "receiver": {
    "name": "Alice Souza",
    "document_number": "60311124000110",
    "bank_name": "A55 SCD S.A.",
    "bank_ispb": "48756121",
    "branch": null,
    "account": null,
    "account_type": null
  },
  "created_at": "2026-05-29T19:30:00.000Z",
  "completed_at": "2026-05-29T19:30:00.000Z"
}
```

**Asynchronous acceptance:**

```json
{
  "id": "550e8400-e29b-41d4-a716-446655440000",
  "external_ref": "payout-9876",
  "status": "processing",
  "amount": 7500,
  "currency": "BRL",
  "pix": {
    "key": "60311124000110",
    "key_type": "CNPJ"
  },
  "receiver": {
    "name": null,
    "document_number": null,
    "bank_name": null,
    "bank_ispb": null,
    "branch": null,
    "account": null,
    "account_type": null
  },
  "created_at": "2026-05-29T19:30:00.000Z"
}
```

| Field | Type | Description |
|-------|------|-------------|
| `id` | string (UUID) | Cash-out identifier. **Use this to look up the transfer.** |
| `external_ref` | string \| null | Your reference, echoed back (`null` if omitted). |
| `status` | string | Transfer status. See [Statuses](#cash-out-statuses). |
| `amount` | integer | Transfer amount in **cents**. |
| `currency` | string | Always `"BRL"`. |
| `pix` | object | Pix destination block. |
| `pix.key` | string | Destination Pix key. |
| `pix.key_type` | string | Pix key type (`CPF`, `CNPJ`, `EMAIL`, `PHONE`, `EVP`). |
| `pix.e2e_id` | string | Pix End-to-End id. **Omitted** until known (may arrive via webhook). |
| `receiver` | object | **Canonical** receiver block. Always present; children are `null` until the provider reports them. |
| `receiver.name` | string \| null | Receiver's name. |
| `receiver.document_number` | string \| null | Receiver's CPF/CNPJ (returned exactly as the provider sends it — already masked). |
| `receiver.bank_name` | string \| null | Receiver bank name. |
| `receiver.bank_ispb` | string \| null | Receiver bank ISPB (SPB participant id). |
| `receiver.branch` | string \| null | Receiver bank branch. |
| `receiver.account` | string \| null | Receiver account. |
| `receiver.account_type` | string \| null | Receiver account type. |
| `created_at` | string | ISO 8601 creation timestamp. |
| `completed_at` | string | When the transfer settled. **Omitted** unless `status` is `completed`. |
| `failed_at` | string | When the transfer failed. **Omitted** unless `status` is `failed`. |
| `returned_at` | string | When the transfer was returned. **Omitted** unless `status` is `returned`. |
| `failure_reason` | string | Reason text on `failed`/`returned`, when available. |

> 📘 **`201 Created` always; payment finality is in the body `status`, not the HTTP code.** An idempotent replay (same `Idempotency-Key` + same body) returns `200 OK` with the existing resource. Track the final outcome via [webhooks](webhooks-integration) or by polling the lookup endpoint.
>
> Receiver identity is exposed only inside the nested `receiver` object (`receiver.name`, `receiver.document_number`, …). There are no flat top-level `receiver_name` / `receiver_document` fields in the response, and there is no top-level `type` field.

### Cash-out statuses

| Status | Description | Balance impact |
|--------|-------------|----------------|
| `processing` | Transfer accepted, being processed by the Pix rail. | Amount debited. |
| `completed` | Transfer settled successfully. | — (already debited) |
| `failed` | Processing failure. | **Amount returned** to your balance. |
| `returned` | Transfer returned by the rail. | **Amount returned** to your balance. |

> 🚧 **Important**
>
> On `failed` or `returned`, the transfer amount is **returned automatically** to your balance.

### Idempotency

Cash-out **requires** an `Idempotency-Key` header to prevent duplicate transfers.

- **Same key + same body** → the original resource is replayed with `200 OK` (no second transfer).
- **Same key + different body** → `409 idempotency_key_conflict`.
- **Same key while the first request is still in flight** → `409 idempotency_in_progress`.

Use a unique, deterministic key per logical transfer (for example, your payout id):

```http
Idempotency-Key: payout-9876
```

If the header is missing, the API returns `400 idempotency_key_required`.

---

## Look Up a Cash-out

Fetch a single transfer by its `id`.

```
GET /v1/pix/cash-out/{id}
```

### Path parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `id` | string (UUID) | The `id` returned when the cash-out was created. |

### Response — `200 OK`

Returns the same object shape as the create response (see above), reflecting the current status.

### Response — `404 Not Found`

Returned when the `id` does not exist or belongs to another account.

```json
{
  "error": {
    "code": "cashout_not_found",
    "message": "No cash-out found for id=550e8400-e29b-41d4-a716-446655440000",
    "request_id": "req-abc123"
  }
}
```

---

## Full Flow

Synchronous provider (e.g. Bents today):

```
1. POST /v1/pix/cash-out          → 201 (status: completed, pix.e2e_id + receiver populated)
2. Webhook pix.cash_out.completed  → confirms settlement (idempotent)
3. GET /v1/pix/cash-out/{id}       → 200 (status: completed)
```

Asynchronous provider:

```
1. POST /v1/pix/cash-out          → 201 (status: processing, amount debited)
2. Pix rail processes the transfer
3. Webhook pix.cash_out.completed  → transfer settled (pix.e2e_id + receiver filled)
4. GET /v1/pix/cash-out/{id}       → 200 (status: completed)
```

**On failure (async):**

```
1. POST /v1/pix/cash-out          → 201 (status: processing, amount debited)
2. Webhook pix.cash_out.failed     → amount returned to balance automatically
3. GET /v1/pix/cash-out/{id}       → 200 (status: failed)
```

---

## Example

```bash
curl -X POST "http://api.cashyin.com/v1/pix/cash-out" \
  -H "Authorization: Bearer ck_your_api_key_here" \
  -H "Content-Type: application/json" \
  -H "Idempotency-Key: payout-9876" \
  -d '{
    "external_ref": "payout-9876",
    "amount": 7500,
    "pix": {
      "key_type": "CNPJ",
      "key": "60311124000110"
    },
    "receiver": {
      "name": "Alice Souza",
      "document_number": "60311124000110"
    },
    "description": "Supplier payment"
  }'
```

---

## Specific Errors

| HTTP | Code | Scenario |
|------|------|----------|
| `400` | `idempotency_key_required` | `Idempotency-Key` header missing. |
| `422` | `validation_error` | Missing or invalid body fields. |
| `422` | `insufficient_funds` | Balance is lower than the amount required for this transfer. |
| `422` | `provider_assignment_not_found` | No active provider is configured for your account. |
| `409` | `idempotency_key_conflict` | Same `Idempotency-Key` reused with a different body. |
| `409` | `idempotency_in_progress` | A request with the same key is still being processed. |
| `404` | `cashout_not_found` | `id` not found (lookup). |
| `502` / `504` | `provider_request_failed` / `provider_timeout` | Failure communicating with the payment rail. |

See the [Errors](errors) page for the full reference.
