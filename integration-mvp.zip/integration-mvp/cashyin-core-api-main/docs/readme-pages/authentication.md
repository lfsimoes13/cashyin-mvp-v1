---
title: "Authentication"
excerpt: "How to authenticate your requests to the CashYin API"
category: "Getting Started"
---

The CashYin API authenticates every request to `/v1/*` with an **API key** sent as a Bearer token in the `Authorization` header.

---

## API Key

When your account is provisioned you receive a single API key:

| Credential | Description | Visibility |
|------------|-------------|------------|
| API key | Secret bearer credential used to authenticate all requests | Shown once at provisioning time |

The key starts with the prefix `ck_` followed by a long hexadecimal string, for example:

```
ck_3f9a1c2b4d5e6f7081929394a5b6c7d8e9f0a1b2c3d4e5f60718293a4b5c6d7e
```

> ⚠️ **Important**
>
> Store your API key securely as soon as you receive it. Treat it like a password — anyone with the key can move money on your behalf.

---

## How to Authenticate

Send the API key in the `Authorization` header using the `Bearer` scheme:

```http
Authorization: Bearer ck_3f9a1c2b4d5e6f7081929394a5b6c7d8e9f0a1b2c3d4e5f60718293a4b5c6d7e
```

### Example with cURL

```bash
curl -X GET "http://api.cashyin.com/v1/balance" \
  -H "Authorization: Bearer ck_3f9a1c2b4d5e6f7081929394a5b6c7d8e9f0a1b2c3d4e5f60718293a4b5c6d7e"
```

---

## Examples by Language

### Node.js

```javascript
const response = await fetch('http://api.cashyin.com/v1/balance', {
  headers: {
    Authorization: `Bearer ${process.env.CASHYIN_API_KEY}`,
  },
});

const balance = await response.json();
console.log(balance);
// { available_balance: 150000, blocked_balance: 0, total_balance: 150000, currency: "BRL", updated_at: "..." }
```

### Python

```python
import os
import requests

response = requests.get(
    'http://api.cashyin.com/v1/balance',
    headers={'Authorization': f"Bearer {os.environ['CASHYIN_API_KEY']}"},
)

print(response.json())
# {'available_balance': 150000, 'blocked_balance': 0, 'total_balance': 150000, 'currency': 'BRL', 'updated_at': '...'}
```

### PHP

```php
<?php
$apiKey = getenv('CASHYIN_API_KEY');

$ch = curl_init('http://api.cashyin.com/v1/balance');
curl_setopt($ch, CURLOPT_HTTPHEADER, ["Authorization: Bearer {$apiKey}"]);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
curl_close($ch);

print_r(json_decode($response, true));
```

---

## Authentication Errors

When authentication fails the API returns `401 Unauthorized` with the `unauthorized` code:

| Scenario | HTTP | Code | Message |
|----------|------|------|---------|
| Missing `Authorization` header | `401` | `unauthorized` | `Missing Authorization header` |
| Header not using Bearer scheme | `401` | `unauthorized` | `Authorization must use Bearer scheme` |
| Invalid or revoked API key | `401` | `unauthorized` | `Invalid API key` |

**Example response:**

```json
// HTTP 401 Unauthorized
{
  "error": {
    "code": "unauthorized",
    "message": "Invalid API key",
    "request_id": "req-abc123"
  }
}
```

---

## Security Best Practices

### 1. Never expose your API key in the frontend

The API key must live **exclusively on your backend**. Never include it in:

- Browser JavaScript
- Mobile apps (Android/iOS)
- Public repositories (GitHub, GitLab)
- Application logs

```javascript
// ❌ WRONG — credentials in the frontend
fetch('http://api.cashyin.com/v1/balance', {
  headers: { Authorization: 'Bearer ck_...' }
});

// ✅ CORRECT — call through your own backend
fetch('/api/balance'); // your backend calls the CashYin API server-side
```

### 2. Use environment variables

Store the key in an environment variable, never hardcoded:

```bash
# .env (do NOT commit this file)
CASHYIN_API_KEY=ck_3f9a1c2b4d5e6f7081929394a5b6c7d8e9f0a1b2c3d4e5f60718293a4b5c6d7e
```

### 3. Rotate your key if it leaks

If you suspect your API key has been exposed, contact support to have it rotated immediately.

---

## Testing Authentication

The simplest way to confirm your key works is to check your balance:

```bash
curl -X GET "http://api.cashyin.com/v1/balance" \
  -H "Authorization: Bearer ck_your_api_key_here"
```

A `200 OK` with your balance confirms the key is valid.
