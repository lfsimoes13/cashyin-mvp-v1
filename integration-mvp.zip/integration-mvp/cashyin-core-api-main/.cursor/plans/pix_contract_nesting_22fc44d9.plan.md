---
name: Pix contract nesting
overview: Reestruturar os contratos públicos de cash-in e cash-out para objetos aninhados (pix/receiver/payer), remover type/qr_code_image/campos nulos, renomear/ajustar colunas no banco, e centralizar a serialização pública num único módulo reutilizado por REST e webhooks. Sem retrocompatibilidade.
todos:
  - id: branch-serializer
    content: Criar branch feat/public-contract-pix-nesting e o módulo central src/modules/transactions/public-serialization.ts (counterparty + toPublicCashIn/toPublicCashOut + omissão de nulos)
    status: completed
  - id: cashout-request
    content: Aninhar request do cash-out (cashout.schemas.ts), atualizar toCreateCashoutInput e canonicalCashoutHash (step-up) para caminhos aninhados
    status: completed
  - id: cashout-response
    content: Cash-out response via módulo central (remover type, pix:{key,key_type,e2e_id?}, receiver document_number, omitir timestamps nulos) + wiring na rota
    status: completed
  - id: cashin-db
    content: Migration 0021 (rename qr_code->pix_emv, drop qr_code_image, add payer_account_type) + repositório + provider-types/bents mapper/webhook extractors
    status: completed
  - id: cashin-response
    content: Cash-in response via módulo central (remover type/qr_code_image, pix:{emv,expires_at,e2e_id?}, payer document_number, omitir payer/paid_at nulos)
    status: completed
  - id: webhooks
    content: payload-builder usa serializer central para data de cash-in/cash-out; subir PUBLIC_WEBHOOK_SCHEMA_VERSION; ajustar outbox payloads e dispatcher pickers
    status: completed
  - id: tests
    content: Atualizar todos os testes unit para o novo contrato + specs do módulo central
    status: completed
  - id: e2e-harness
    content: Atualizar harness E2E fyhub (types/client/scenarios/webhook-receiver) para o novo contrato
    status: completed
  - id: docs-postman
    content: Atualizar readme-pages, openapi yaml e Postman collection
    status: completed
  - id: validate
    content: Aplicar migration local, rodar lint/build/test verdes e commitar na branch nova
    status: completed
isProject: false
---

# Padronização dos contratos públicos Pix (cash-in / cash-out)

Branch nova: `feat/public-contract-pix-nesting`. Sem `/v2`, sem retrocompatibilidade, livre para alterar tabelas.

## Decisões aplicadas
- EMV do cash-in: chave `pix.emv`; coluna no banco `pix_emv`.
- Documento: `document_number` em request E response, para `receiver` e `payer`.
- Omitir campos nulos: `e2e_id` (sob `pix`), `payer`, `paid_at`, e timestamps terminais (`completed_at`/`failed_at`/`returned_at`).
- Remover `type` de todos os payloads públicos (REST + webhooks).

## Formas-alvo

Counterparty compartilhado (usado por `receiver` e `payer`):
`{ name, document_number, bank, ispb, branch, account, account_type }` (campos nulos viram `null`, exceto quando o objeto inteiro é omitido).

Cash-out request `POST /v1/pix/cash-out`:
```
{ "external_ref?": "...", "amount": 7500,
  "pix": { "key_type": "CNPJ", "key": "603..." },
  "receiver?": { "name": "...", "document_number": "603..." },
  "description?": "..." }
```
Cash-out response (GET/POST): remove `type`; `pix:{key,key_type,e2e_id?}`; `receiver:{...}`; omite timestamps terminais nulos; `failure_reason?` em failed/returned.

Cash-in response `POST /v1/pix/cash-in/qrcode` (criação): remove `type`/`qr_code_image`; `pix:{emv, expires_at}` (sem `e2e_id` ainda); sem `payer`/`paid_at`. Quando pago: `pix:{emv, expires_at, e2e_id}` + `payer:{...}` + `paid_at`.

## 1. Módulo central de serialização (chave do "mudar fácil no futuro")
Criar `src/modules/transactions/public-serialization.ts` como ÚNICA fonte da forma pública:
- `toPublicPixCounterparty(src)` -> objeto counterparty (receiver/payer).
- `toPublicCashOut(src)` e `toPublicCashIn(src)` recebendo um "source" normalizado (camelCase, timestamps `Date|string|null`), aplicando aninhamento + omissão de nulos.
- Tipos públicos exportados (`PublicCashOut`, `PublicCashIn`, `PublicPixCounterparty`).
REST e webhooks passam a chamar essas funções (eliminando `toPublicCashout` em [cashout.service.ts](src/modules/cashouts/cashout.service.ts) e `buildResponseFromRecord` em [payment.service.ts](src/modules/payments/payment.service.ts) como definições paralelas).

## 2. Cash-out request + step-up
- [src/modules/cashouts/cashout.schemas.ts](src/modules/cashouts/cashout.schemas.ts): `createCashoutBodySchema` aninhado (`pix:{key_type,key}`, `receiver?:{name?,document_number?}`); `toCreateCashoutInput` mapeia para o input interno flat (inalterado).
- [src/modules/cashouts/cashout-step-up.ts](src/modules/cashouts/cashout-step-up.ts): `canonicalCashoutHash` lê `body.pix.key`, `body.pix.key_type`, `body.receiver?.document_number`.
- Idempotência interna (`hashRequest` em [cashout.service.ts](src/modules/cashouts/cashout.service.ts)) não muda (input interno permanece flat).

## 3. Cash-out response
- [cashout.service.ts](src/modules/cashouts/cashout.service.ts): remover `toPublicCashout`/`PublicCashoutResponse` antigos; rota [cashout.routes.ts](src/modules/cashouts/cashout.routes.ts) usa `toPublicCashOut` do módulo central. Internamente segue flat (colunas `cashouts` inalteradas).

## 4. Cash-in banco + repositório + provider
- Migration nova `migrations/0021_*.sql` em `pix_charges`: `RENAME qr_code -> pix_emv`; `DROP COLUMN qr_code_image`; `ADD COLUMN payer_account_type TEXT`.
- [src/modules/payments/cash-in.repository.ts](src/modules/payments/cash-in.repository.ts): colunas/insert/select/`mapRow`/`markPaid` (usa `pix_emv`, remove `qr_code_image`, adiciona `payer_account_type`; renomeia chaves do payer para `bank/ispb/branch/account/account_type`).
- [src/providers/contracts/provider-types.ts](src/providers/contracts/provider-types.ts): `ProviderPixCharge` renomeia `qr_code -> emv`, remove `qr_code_image`.
- [src/providers/bents/bents.mapper.ts](src/providers/bents/bents.mapper.ts): mapeia `pix_copia_e_cola -> emv`; remove mapeamento de imagem. Webhook adapter ([bents-webhook.adapter.ts](src/providers/bents/bents-webhook.adapter.ts)) + `extractCashInPaidExtras` ([webhook-event.processor.ts](src/modules/webhooks/webhook-event.processor.ts)) passam a popular `payer_account_type` quando disponível.

## 5. Cash-in response
- [payment.service.ts](src/modules/payments/payment.service.ts): `CashInResponse` e construção via `toPublicCashIn` central; remover `type`/`qr_code_image`; omitir `payer`/`paid_at`; `e2e_id`/`expires_at`/`emv` sob `pix`. Atualizar payload do outbox (remover `qr_code_image`, usar `emv`, incluir `payer.account_type`).

## 6. Webhooks/eventos
- [src/modules/transactions/payload-builder.ts](src/modules/transactions/payload-builder.ts): `data` de cash-in/cash-out passa a vir de `toPublicCashIn`/`toPublicCashOut` (mesma forma do REST). Remover `type`/`qr_code_image`.
- Subir `PUBLIC_WEBHOOK_SCHEMA_VERSION`.
- [client-webhook.dispatcher.ts](src/modules/webhooks/client-webhook.dispatcher.ts): pickers alinhados (emv, payer.account_type).

## 7. Testes (atualizar para o novo contrato)
`tests/unit/`: `cashout-public-contract.spec.ts`, `cashout-step-up.spec.ts`, `cashout-service.spec.ts`, `payment-service.spec.ts`, `transaction-payload-builder.spec.ts`, `client-webhook-dispatcher.spec.ts`, `bents-mapper.spec.ts`, `bents-provider.spec.ts`, `bents-webhook-adapter.spec.ts`, `webhook-service.spec.ts`, `webhook-event-processor.spec.ts`, `cashout-repository-sql.spec.ts`, `e2e-fyhub-client.spec.ts`, `e2e-webhook-receiver.spec.ts`. Adicionar specs do novo módulo central.

## 8. Harness E2E (mantém build verde)
`scripts/e2e/fyhub/`: `types.ts`, `cashyin.client.ts`, `webhook-receiver.ts`, `scenarios/*` (request aninhado, `pix.emv`, `document_number`, sem `type`/`qr_code_image`).

## 9. Docs + Postman
- `docs/readme-pages/`: `pix-cash-in.md`, `pix-cash-out.md`, `webhooks-integration.md`, `api-overview.md`.
- `docs/openapi/cashyin-api-reference.yaml`: schemas request/response/webhook.
- `postman/cashyin-core-api.postman_collection.json`: bodies aninhados + asserts atualizados.

## 10. Validação
Aplicar migration no Postgres local; `pnpm lint && pnpm build && pnpm test` verdes; validar amostras de payload; commit na branch nova.

## Riscos / notas
- Mudança breaking (aceita: sem clientes reais). DB alterado de forma destrutiva (`DROP qr_code_image`).
- Provedor pode não enviar `account_type` do payer; coluna fica `null` até existir.
- `completed_at` também será omitido quando nulo (consistência com `failed_at`/`returned_at` e com os webhooks).